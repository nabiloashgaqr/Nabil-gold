from services.database import DatabaseService


def _db(tmp_path):
    return DatabaseService({"database": {"url": None, "key": None,
        "local_fallback_file": str(tmp_path / "trades.json")}})


def _decision(kind, current=1.35559, entry=1.35439):
    return {
        "symbol": "GBP/USD", "decision": "BUY", "confidence": 66.5,
        "execution_path_id": "PATH_5_TWO_AGENT_AUCTION",
        "current_price": current,
        "signal": {
            "type": "BUY", "entry_kind": kind, "order_type": kind,
            "entry": {"price": entry, "kind": kind},
            "stop_loss": 1.34717, "tp1": 1.35797, "tp2": 1.36277,
        },
    }


def test_buy_limit_directional_token_is_pending_not_open(tmp_path):
    db = _db(tmp_path)
    db.save_trade(_decision("BUY_LIMIT"))
    row = db.get_open_trades()[0]
    assert row["order_kind"] == "BUY_LIMIT"
    assert row["status"] == "PENDING"


def test_fx_limit_never_uses_absolute_one_cent_market_threshold(tmp_path):
    db = _db(tmp_path)
    # Only one FX point away: still a LIMIT lifecycle; MT5 decides whether it
    # fills immediately. It must never enter the OPEN->MARKET recovery lane.
    db.save_trade(_decision("BUY_LIMIT", current=1.35440, entry=1.35439))
    assert db.get_open_trades()[0]["status"] == "PENDING"


def test_market_kind_remains_open(tmp_path):
    db = _db(tmp_path)
    db.save_trade(_decision("MARKET", current=1.35439, entry=1.35439))
    row = db.get_open_trades()[0]
    assert row["order_kind"] == "MARKET"
    assert row["status"] == "OPEN"
