# Gold AI Signals — GitHub Actions Edition

نظام تجريبي/تعليمي لتحليل الذهب XAU/USD وإرسال إشارات إلى Telegram، مصمم ليعمل بدون VPS عبر GitHub Actions + Supabase.

> ⚠️ تنبيه: هذا المشروع للمساعدة في التحليل والتجربة والتعليم فقط. ليس توصية مالية ولا ضماناً للربح. اختبر دائماً على Paper Trading أولاً.

## ما تم بناؤه حتى الآن

### المرحلة الأولى

- هيكل مشروع متوافق مع GitHub Actions.
- 3 Workflows:
  - `.github/workflows/analyze.yml` كل ساعة.
  - `.github/workflows/update_trades.yml` كل ساعة.
  - `.github/workflows/daily_report.yml` يومياً الساعة 23:00 UTC.
- سكريبتات التشغيل داخل `scripts/`.
- خدمة أسعار `MarketDataService` عبر Twelve Data مع fallback تجريبي.
- خدمة Telegram برسائل HTML منظمة.
- خدمة قاعدة بيانات `DatabaseService` عبر Supabase مع fallback محلي للاختبار.
- وكلاء تحليل أساسيون + نسخ خفيفة للوكلاء المتقدمين حتى يعمل النظام end-to-end.
- إدارة مخاطر وقرار مبدئي مع شرط توافق 3 وكلاء وثقة 70%.
- اختبارات أساسية.

### المرحلة الثانية

- ترقية `SMCAgent` لاكتشاف Market Structure و BOS/CHoCH و Order Blocks و Liquidity Sweeps و FVG و Premium/Discount.
- ترقية `PriceActionAgent` لاكتشاف Engulfing و Pin Bar و Doji و Inside Bar و Morning/Evening Star و Three Soldiers/Crows مع تحليل الكسر والرفض.
- ترقية `MultiTimeframeAgent` بتحليل موزون للفريمات 4H/1H/15m/5m ومنع التعارض مع الفريم الأعلى.
- تحسين `DecisionAgent` لاستخدام ثقة مرجحة مطبّعة مع تفاصيل `raw_agent_scores` و `weights_used`.
- إضافة اختبارات للوكلاء المتقدمين.

### المرحلة الثالثة

- ترقية `NewsRiskAgent` لفحص الأخبار عالية/متوسطة التأثير من `storage/news_events.json` أو `NEWS_EVENTS_JSON`.
- تطبيق قواعد منع التداول قبل الخبر العالي بـ 30 دقيقة وبعده بـ 15 دقيقة، مع تحذير قبل 60 دقيقة.
- إضافة تصنيف جلسة السوق وحالة `SAFE` / `CAUTION` / `DANGER` / `HIGH_VOLATILITY`.
- ترقية `RiskManagementAgent` لحساب SL/TP من ATR والدعم/المقاومة و SMC Order Blocks.
- تطبيق فلاتر الرفض: ATR منخفض، spread مرتفع، R:R ضعيف، SL واسع، الهدف قريب، عدد صفقات مفتوحة، وخسائر متتالية.
- تمرير سياق المحفظة من Supabase إلى التحليل: عدد صفقات اليوم، الصفقات المفتوحة، والخسائر المتتالية.
- إضافة اختبارات للفلاتر والحماية.

### المرحلة الرابعة

- ترقية `OpenTradesManager` لمتابعة الصفقات المفتوحة وتحديث حالتها كل تشغيل لـ `update_trades.yml`.
- إرسال تحديثات Telegram عند الاقتراب من TP1 بنسبة 80%، تحقق TP1، اقتراح Break Even، تحقق TP2، ضرب SL/BE، وطول مدة الصفقة.
- منع تكرار رسائل التحديث عبر حقل `updates_sent`.
- دعم حالات الصفقة: `OPEN`, `TP1_HIT`, `TP2_HIT`, `SL_HIT`, `BE_HIT`, `EXPIRED`, `MANUAL_CLOSE`.
- إضافة حقول تتبع للصفقة مثل `entry_time`, `initial_stop_loss`, `sl_moved_to_entry`, `partial_close`, `result`, `signal_snapshot`.
- تحديث `scripts/run_trade_updates.py` ليستخدم وكيل إدارة الصفقات بدلاً من منطق مبسط داخل السكريبت.
- تحسين رسائل Telegram الخاصة بإدارة الصفقات.

### المرحلة الخامسة — الاختبارات الشاملة ✅

- **75 اختبار شامل** تغطي جميع مكونات المشروع (75/75 نجاح):
  - `test_agents.py` (3 اختبارات) — المرحلة الأولى: Technical, Classical, Decision agents
  - `test_advanced_agents.py` (3 اختبارات) — المرحلة الثانية: SMC, PriceAction, MultiTimeframe agents
  - `test_filters_and_risk.py` (4 اختبارات) — المرحلة الثالثة: NewsRisk, RiskManagement agents
  - `test_open_trades_manager.py` (5 اختبارات) — المرحلة الرابعة: OpenTradesManager lifecycle
  - `test_services.py` (15 اختبار) — الخدمات: MarketData, Database, Telegram
  - `test_utils.py` (20 اختبار) — المؤشرات والحسابات: SMA, EMA, RSI, MACD, ATR, Bollinger, Swings, Pivots, Fibonacci, Helpers
  - `test_integration.py` (10 اختبارات) — تكامل end-to-end: Pipeline, News blocking, Portfolio limits, Database persistence, Signal fields, Decision weights, Daily report
  - `test_trading_session.py` (10 اختبارات) — ساعات التداول: SessionAgent, quality filters, weekend/Friday rules
- ملف `pytest.ini` لإعدادات الاختبارات مع دعم coverage.
- **تشغيل الاختبارات:** `python -m pytest tests/`

### المرحلة السادسة — ساعات التداول القابلة للتخصيص ✅

- **`TradingSessionAgent`** جديد يتحقق من ساعات التداول المسموحة لكل جلسة:
  - **London** (8:00-16:00 UTC, أيام 1-5, جودة HIGH) — أفضل وقت للذهب
  - **London-NY Overlap** (13:00-17:00 UTC, أيام 1-5, جودة BEST) — أعلى حجم وسيولة
  - **New York** (14:00-21:00 UTC, أيام 1-5, جودة HIGH)
  - **Asian** (1:00-6:00 UTC, أيام 1-5, جودة LOW) — تقلبات أقل
- **جميع الإعدادات في `config.json`** قابلة للتعديل بدون تغيير الكود:
  ```json
  "trading_hours": {
    "enabled": true,
    "min_quality_required": "HIGH",
    "exclude_weekends": true,
    "friday_cutoff_hour": 20,
    "sessions": [...]
  }
  ```
- **تعديل جودة الجلسة يؤثر على الثقة**: BEST=0 penalty, HIGH=0, MEDIUM=-5%, LOW=-10%, NONE=-15%
- **منع التداول خارج الجلسات**: DecisionAgent يتحقق من `trading_hours_filter`
- **رسائل Telegram** تتضمن معلومات الجلسة والجودة عند إرسال الإشارة
- **تحديث كل ساعة**: `analyze.yml` و `update_trades.yml` يعملان كل ساعة `0 * * * *`
- يمكن تغيير التكرار في `config.json` → `schedule.analysis_interval_minutes`

## هيكل المشروع

```text
gold-ai-signals/
├── .github/workflows/
│   ├── analyze.yml          # كل ساعة
│   ├── update_trades.yml    # كل ساعة
│   └── daily_report.yml     # يومياً 23:00 UTC
├── agents/
│   ├── base_agent.py
│   ├── technical_agent.py
│   ├── classical_agent.py
│   ├── smc_agent.py
│   ├── price_action_agent.py
│   ├── multitimeframe_agent.py
│   ├── news_risk_agent.py
│   ├── risk_management_agent.py
│   ├── decision_agent.py
│   ├── open_trades_manager.py
│   ├── daily_report_agent.py
│   └── trading_session_agent.py   # جديد!
├── services/
│   ├── market_data.py
│   ├── telegram_bot.py
│   └── database.py
├── scripts/
│   ├── run_analysis.py
│   ├── run_trade_updates.py
│   └── run_daily_report.py
├── storage/
│   ├── news_events.json
│   └── trades.json
├── tests/                   # 75 اختبار
├── utils/
│   ├── helpers.py
│   └── indicators.py
├── config.json              # كل الإعدادات هنا!
├── requirements.txt
├── pytest.ini
└── README.md
```

## الإعداد على GitHub

### 1) إنشاء Telegram Bot

1. افتح `@BotFather`.
2. أرسل `/newbot`.
3. احفظ `Bot Token`.
4. احصل على `chat_id` للقناة/المجموعة/الحساب.

### 2) إنشاء Supabase

أنشئ مشروعاً مجانياً ثم افتح SQL Editor وشغّل:

```sql
CREATE TABLE IF NOT EXISTS trades (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    entry_price DECIMAL(10,2),
    entry_time TIMESTAMP,
    stop_loss DECIMAL(10,2),
    initial_stop_loss DECIMAL(10,2),
    tp1 DECIMAL(10,2),
    tp2 DECIMAL(10,2),
    confidence INTEGER,
    status TEXT DEFAULT 'OPEN',
    current_price DECIMAL(10,2),
    current_pnl DECIMAL(10,2),
    current_pnl_points DECIMAL(10,2),
    sl_moved_to_entry BOOLEAN DEFAULT FALSE,
    partial_close BOOLEAN DEFAULT FALSE,
    updates_sent JSONB DEFAULT '[]'::jsonb,
    result TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    closed_at TIMESTAMP,
    close_time TIMESTAMP,
    close_price DECIMAL(10,2),
    final_pnl DECIMAL(10,2),
    reasons JSONB,
    signal_snapshot JSONB,
    last_updated TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);
CREATE INDEX IF NOT EXISTS idx_trades_created_at ON trades(created_at);
```

ثم احفظ:

- `SUPABASE_URL`
- `SUPABASE_KEY`

### 3) Twelve Data

1. افتح <https://twelvedata.com>
2. أنشئ حساباً مجانياً.
3. احفظ `TWELVE_DATA_API_KEY`.

### 4) GitHub Secrets

من Repository Settings → Secrets and variables → Actions أضف:

- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`
- `TWELVE_DATA_API_KEY`
- `SUPABASE_URL`
- `SUPABASE_KEY`

### 5) تشغيل GitHub Actions

- افتح تبويب Actions.
- فعّل Workflows إذا طُلب ذلك.
- يمكنك التشغيل يدوياً من `Run workflow`.

## التشغيل المحلي للاختبار

```bash
cd gold-ai-signals
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/run_analysis.py
python scripts/run_trade_updates.py
python scripts/run_daily_report.py
python -m pytest tests/ -v    # تشغيل الاختبارات
```

## تخصيص ساعات التداول

في `config.json` يمكنك تعديل:

```json
"trading_hours": {
  "enabled": true,
  "min_quality_required": "HIGH",
  "exclude_weekends": true,
  "friday_cutoff_hour": 20,
  "sessions": [
    {
      "name": "London-NY Overlap",
      "start_hour": 13,
      "end_hour": 17,
      "days": [1, 2, 3, 4, 5],
      "quality": "BEST",
      "description": "أفضل فترة"
    },
    {
      "name": "London",
      "start_hour": 8,
      "end_hour": 16,
      "days": [1, 2, 3, 4, 5],
      "quality": "HIGH",
      "description": "جلسة لندن"
    }
  ]
}
```

## اقتراحات للتطوير المستقبلي

### 🔴 عالي الأولوية

1. **📊 لوحة أداء محسّنة (Performance Dashboard)**
   - تتبع Win Rate لكل وكيل على حدة
   - تحليل الأداء حسب الجلسة (London vs NY vs Asian)
   - تتبع Drawdown مع تنبيهات
   - حساب Profit Factor الأسبوعي/الشهري

2. **📈 Trailing Stop متقدم**
   - تفعيل trailing stop بعد TP1
   - مسافة متحركة بناءً على ATR
   - إغلاق جزئي عند TP1 (50%) وحماية الباقي

3. **🔗 ربط مصدر أخبار تلقائي**
   - ربط Forex Factory أو Investing.com API
   - تحديث أحداث الأخبار تلقائياً يومياً
   - تصنيف الأحداث حسب العملة والتأثير

### 🟡 متوسط الأولوية

4. **📉 Backtesting Engine**
   - محاكاة الاستراتيجية على بيانات تاريخية
   - مقارنة الأداء مع/بدون فلتر الأخبار
   - اختبار أوزان الوكلاء المختلفة

5. **🎯 Multi-Pair Support**
   - إضافة أزواج أخرى (XAU/EUR, EUR/USD)
   - ربط تحليل الارتباط بين الأزواج
   - تخصيص لكل زوج

6. **📱 تنبيهات ذكية**
   - تنبيه عند وصول RSI لحدود حرجة
   - تنبيه عند كسر مستويات رئيسية
   - تقرير أسبوعي ملخص

### 🟢 تطوير طويل الأمد

7. **🤖 Machine Learning Enhancements**
   - تدريب نموذج تصنيف للإشارات
   - تحسين أوزان الوكلاء تلقائياً
   - كشف الأنماط المتكررة

8. **📊 تصور بياني (Chart Visualization)**
   - إرسال صور شموع مع مستويات للدخول/الوقف
   - مؤشرات فنية على الصورة
   - رسم الفيبوناتشي والمقاومة/الدعم

9. **🔄 النسخ الاحتياطي التلقائي**
   - تصدير trades.json لكل أسبوع
   - أرشفة الإشارات القديمة
   - حفظ إعدادات نسخة كل شهر

---

## ملاحظات مهمة حول GitHub Actions Minutes

- **التحليل**: كل ساعة (24 مرة/يوم)
- **تحديث الصفقات**: كل ساعة (24 مرة/يوم)
- **التقرير**: مرة يومياً (1 مرة/يوم)

**إجمالي**: ~49 تشغيل/يوم = ~1,470 تشغيل/شهر

لتقليل الاستهلاك:

```yaml
# analyze.yml - كل ساعتين
- cron: '0 */2 * * *'

# update_trades.yml - كل ساعتين
- cron: '30 */2 * * *'
```

أو اجعل المستودع **Public** (دقائق غير محدودة).

## إدخال الأخبار يدوياً

يمكن وضع أحداث أخبار في `storage/news_events.json` بالشكل:

```json
[
  {
    "event": "US CPI",
    "time": "2026-06-17T13:30:00Z",
    "impact": "HIGH",
    "currency": "USD",
    "expected": "3.1%",
    "previous": "3.3%"
  }
]
```

## تحذير مالي

كل رسالة Signal تتضمن تحذيراً بأن الإشارة ليست توصية مالية. لا تستخدم النظام على حساب حقيقي قبل اختبار طويل وتقييم مخاطر مستقل.