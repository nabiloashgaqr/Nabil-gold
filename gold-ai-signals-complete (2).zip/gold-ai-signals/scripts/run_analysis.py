"""سكريبت التحليل الرئيسي.

يعمل كل 15 دقيقة عبر GitHub Actions. يجلب بيانات الذهب، يشغل الوكلاء، يطبق
إدارة المخاطر والقرار، ثم يحفظ ويرسل الإشارة إذا كانت مؤهلة.
"""

from __future__ import annotations

import logging
import os
import sys
from datetime import datetime, timezone
from typing import Any, Dict

# إضافة المسار الرئيسي للمشروع عند التشغيل من GitHub Actions
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.classical_agent import ClassicalAgent
from agents.decision_agent import DecisionAgent
from agents.multitimeframe_agent import MultiTimeframeAgent
from agents.news_risk_agent import NewsRiskAgent
from agents.price_action_agent import PriceActionAgent
from agents.risk_management_agent import RiskManagementAgent
from agents.smc_agent import SMCAgent
from agents.technical_agent import TechnicalAgent
from agents.trading_session_agent import TradingSessionAgent
from services.database import DatabaseService
from services.market_data import MarketDataService
from services.telegram_bot import TelegramService
from utils.helpers import load_config, setup_logging

setup_logging()
logger = logging.getLogger(__name__)


def run_agent(agent_name: str, agent: Any, data: Dict[str, Any]) -> Dict[str, Any]:
    """Run one agent safely so one failure does not stop the workflow."""
    try:
        logger.info("Running agent: %s", agent_name)
        return agent.analyze(data)
    except Exception as exc:  # noqa: BLE001
        logger.exception("Agent %s failed", agent_name)
        return {"agent": agent_name, "direction": "NEUTRAL", "confidence": 0, "summary": f"فشل الوكيل: {exc}"}


def main() -> None:
    """الدالة الرئيسية للتحليل."""
    logger.info("بدء التحليل: %s", datetime.now(timezone.utc).isoformat())
    config = load_config()
    telegram = TelegramService(config)

    try:
        # ── فحص ساعات التداول أولاً ──
        from agents.trading_session_agent import TradingSessionAgent
        session = TradingSessionAgent(config).check()
        logger.info(
            "🔍 الجلسة: %s | الجودة: %s | مسموح: %s",
            session.get("current_session") or "خارج الجلسة",
            session.get("session_quality", "N/A"),
            session.get("trading_allowed"),
        )

        if not session.get("trading_allowed"):
            logger.info(
                "🚫 خارج ساعات التداول (%s) - لا تحليل حالياً. السبب: %s",
                session.get("current_session") or "غير محدد",
                session.get("reason", ""),
            )
            return  # ══ لا تحليل خارج الجلسات ══

        # ── خارج ساعات التداول = لا تحليل ولا إشارات ══
        market_data = MarketDataService(config)
        database = DatabaseService(config)

        logger.info("جلب بيانات السوق...")
        data = market_data.get_gold_data()
        if not data:
            logger.error("فشل في جلب البيانات")
            return

        # سياق الحساب/المحفظة مطلوب لفلاتر الحماية في وكيل المخاطر والقرار.
        open_trades = database.get_open_trades()
        today_signals = database.get_today_signals_count()
        consecutive_losses = database.get_consecutive_losses()

        # تشغيل وكلاء التحليل
        all_results: Dict[str, Any] = {
            "technical": run_agent("technical", TechnicalAgent(config), data),
            "classical": run_agent("classical", ClassicalAgent(config), data),
            "smc": run_agent("smc", SMCAgent(config), data),
            "price_action": run_agent("price_action", PriceActionAgent(config), data),
            "multitimeframe": run_agent("multitimeframe", MultiTimeframeAgent(config), data),
            "current_price": data["current_price"],
            "spread_points": data.get("spread_points"),
            "portfolio": {
                "open_trades_count": len(open_trades),
                "today_signals_count": today_signals,
                "consecutive_losses": consecutive_losses,
            },
        }

        logger.info("تشغيل وكيل جلسة التداول...")
        all_results["session"] = session  # reuse the already-checked session

        logger.info("تشغيل وكيل الأخبار...")
        all_results["news"] = NewsRiskAgent(config).check()

        logger.info("تشغيل وكيل إدارة المخاطر...")
        all_results["risk"] = RiskManagementAgent(config).evaluate(all_results)

        logger.info("تشغيل وكيل القرار...")
        decision = DecisionAgent(config).decide(all_results)
        logger.info("القرار: %s - الثقة: %s%% - %s", decision.get("decision"), decision.get("confidence"), decision.get("summary"))

        if decision.get("decision") in {"BUY", "SELL"}:
            settings = config.get("risk_settings", {})
            max_daily = int(settings.get("max_daily_signals", 8))
            max_open = int(settings.get("max_open_trades", 3))
            today_signals = database.get_today_signals_count()
            open_trades = database.get_open_trades()
            if today_signals >= max_daily:
                logger.info("تم الوصول للحد الأقصى من الإشارات اليومية: %s", max_daily)
                return
            if len(open_trades) >= max_open:
                logger.info("تم الوصول للحد الأقصى للصفقات المفتوحة: %s", max_open)
                return

            trade_id = database.save_trade(decision)
            decision["trade_id"] = trade_id
            if decision.get("signal"):
                decision["signal"]["trade_id"] = trade_id
            telegram.send_signal(decision)
            logger.info("تم حفظ/إرسال الإشارة: %s", trade_id)
        else:
            logger.info("لا توجد إشارة مؤهلة حالياً. الأسباب/التحذيرات: %s", decision.get("warnings"))

        logger.info("اكتمل التحليل بنجاح")
    except Exception as exc:  # noqa: BLE001
        logger.exception("خطأ في التحليل")
        telegram.send_error_alert(str(exc))


if __name__ == "__main__":
    main()
