"""Basic tests for phase-one agents."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from agents.classical_agent import ClassicalAgent
from agents.decision_agent import DecisionAgent
from agents.risk_management_agent import RiskManagementAgent
from agents.technical_agent import TechnicalAgent


def sample_market_data(count: int = 240) -> dict:
    start = datetime.now(timezone.utc) - timedelta(minutes=15 * count)
    price = 2300.0
    candles = []
    for i in range(count):
        price += 0.25 + (0.15 if i % 5 == 0 else -0.05)
        candles.append(
            {
                "time": (start + timedelta(minutes=15 * i)).isoformat().replace("+00:00", "Z"),
                "open": round(price - 0.4, 2),
                "high": round(price + 1.2, 2),
                "low": round(price - 1.1, 2),
                "close": round(price, 2),
                "volume": 1000,
            }
        )
    return {"symbol": "XAU/USD", "timeframe": "15m", "data": candles, "current_price": candles[-1]["close"], "timeframes": {"15m": {"data": candles}}}


def test_technical_agent_returns_required_keys() -> None:
    result = TechnicalAgent().analyze(sample_market_data())
    assert result["agent"] == "technical"
    assert result["direction"] in {"BUY", "SELL", "NEUTRAL"}
    assert 0 <= result["confidence"] <= 100
    assert "indicators_raw" in result


def test_classical_agent_returns_levels() -> None:
    result = ClassicalAgent().analyze(sample_market_data())
    assert result["agent"] == "classical"
    assert "support_levels" in result
    assert "resistance_levels" in result


def test_decision_agent_waits_without_three_agent_agreement() -> None:
    data = sample_market_data()
    technical = TechnicalAgent().analyze(data)
    classical = ClassicalAgent().analyze(data)
    results = {
        "technical": technical,
        "classical": classical,
        "smc": {"agent": "smc", "direction": "NEUTRAL", "confidence": 0},
        "price_action": {"agent": "price_action", "direction": "NEUTRAL", "confidence": 0},
        "multitimeframe": {"agent": "multitimeframe", "direction": "NEUTRAL", "confidence": 0},
        "news": {"market_status": "SAFE", "can_trade": True, "summary": "safe"},
        "current_price": data["current_price"],
    }
    results["risk"] = RiskManagementAgent().evaluate(results)
    decision = DecisionAgent().decide(results)
    assert decision["decision"] in {"WAIT", "BUY", "SELL", "AVOID"}
    assert "filters_passed" in decision
