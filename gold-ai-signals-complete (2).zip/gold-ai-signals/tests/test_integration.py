"""End-to-end integration tests for full signal pipeline."""

from __future__ import annotations

import json
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from agents.technical_agent import TechnicalAgent
from agents.classical_agent import ClassicalAgent
from agents.smc_agent import SMCAgent
from agents.price_action_agent import PriceActionAgent
from agents.multitimeframe_agent import MultiTimeframeAgent
from agents.news_risk_agent import NewsRiskAgent
from agents.risk_management_agent import RiskManagementAgent
from agents.decision_agent import DecisionAgent
from agents.daily_report_agent import DailyReportAgent
from services.market_data import MarketDataService
from services.database import DatabaseService


# ───────────────────────────── Data Fixtures ──────────────────────────────────


def make_data(uptrend: bool = True, count: int = 240, base: float = 2350.0) -> dict:
    """Create market data simulating uptrend or downtrend."""
    start = datetime.now(timezone.utc) - timedelta(minutes=15 * count)
    candles_15m = []
    price = base
    for i in range(count):
        if uptrend:
            drift = 0.15 + (0.08 if i % 7 == 0 else 0.0)
        else:
            drift = -0.15 - (0.08 if i % 7 == 0 else 0.0)
        # Add some noise
        open_p = price
        close_p = price + drift
        high_p = max(open_p, close_p) + 0.5
        low_p = min(open_p, close_p) - 0.5
        candles_15m.append({
            "time": (start + timedelta(minutes=15 * i)).isoformat().replace("+00:00", "Z"),
            "open": round(open_p, 2),
            "high": round(high_p, 2),
            "low": round(low_p, 2),
            "close": round(close_p, 2),
            "volume": 1000 + i,
        })
        price = close_p

    # Copy for other timeframes
    def copy_candles(src):
        result = []
        for i, c in enumerate(src):
            result.append({
                "time": c["time"],
                "open": c["open"],
                "high": c["high"],
                "low": c["low"],
                "close": c["close"],
                "volume": c["volume"],
            })
        return result

    return {
        "symbol": "XAU/USD",
        "timeframe": "15m",
        "data": candles_15m,
        "current_price": candles_15m[-1]["close"],
        "timeframes": {
            "5m": {"data": copy_candles(candles_15m[-60:])},
            "15m": {"data": candles_15m},
            "1H": {"data": copy_candles(candles_15m)},
            "4H": {"data": copy_candles(candles_15m)},
        },
    }


def base_config():
    return {
        "symbol": "XAU/USD",
        "timeframes": ["5m", "15m", "1H", "4H"],
        "primary_timeframe": "15m",
        "trend_timeframe": "4H",
        "agent_weights": {
            "technical": 0.20,
            "classical": 0.20,
            "smc": 0.25,
            "price_action": 0.15,
            "multitimeframe": 0.15,
        },
        "risk_settings": {
            "min_confidence": 70,
            "min_rr_ratio": 1.5,
            "max_daily_signals": 8,
            "max_open_trades": 3,
            "default_risk_percent": 1.0,
            "atr_multiplier_sl": 1.5,
            "atr_multiplier_tp1": 2.0,
            "atr_multiplier_tp2": 3.5,
        },
        "filters": {
            "no_signal_before_news_minutes": 30,
            "no_signal_after_news_minutes": 15,
            "max_spread_points": 5,
            "min_atr_for_entry": 1.0,
            "max_consecutive_losses": 3,
        },
    }


# ───────────────────────────── Full Pipeline ───────────────────────────────────


def test_full_pipeline_uptrend_generates_buy_signal():
    """In strong uptrend, pipeline should generate BUY signal."""
    config = base_config()
    data = make_data(uptrend=True, count=240)

    # Run all analytical agents
    tech = TechnicalAgent(config).analyze(data)
    classical = ClassicalAgent(config).analyze(data)
    smc = SMCAgent(config).analyze(data)
    pa = PriceActionAgent(config).analyze(data)
    mtf = MultiTimeframeAgent(config).analyze(data)

    # News check
    news = NewsRiskAgent(config).check()

    # Build results for risk management
    results = {
        "technical": tech,
        "classical": classical,
        "smc": smc,
        "price_action": pa,
        "multitimeframe": mtf,
        "news": news,
        "current_price": data["current_price"],
        "spread_points": 2.0,
        "portfolio": {"open_trades_count": 0, "today_signals_count": 0, "consecutive_losses": 0},
    }

    # Risk management
    risk = RiskManagementAgent(config).evaluate(results)

    # Decision
    results["risk"] = risk
    decision = DecisionAgent(config).decide(results)

    # In strong uptrend with all agents agreeing → should be BUY
    assert decision["decision"] in {"BUY", "SELL", "WAIT", "AVOID"}
    assert "filters_passed" in decision
    assert "confidence" in decision
    assert "summary" in decision


def test_full_pipeline_downtrend_generates_sell_signal():
    """In strong downtrend, pipeline should generate SELL signal."""
    config = base_config()
    data = make_data(uptrend=False, count=240)

    tech = TechnicalAgent(config).analyze(data)
    classical = ClassicalAgent(config).analyze(data)
    smc = SMCAgent(config).analyze(data)
    pa = PriceActionAgent(config).analyze(data)
    mtf = MultiTimeframeAgent(config).analyze(data)
    news = NewsRiskAgent(config).check()

    results = {
        "technical": tech,
        "classical": classical,
        "smc": smc,
        "price_action": pa,
        "multitimeframe": mtf,
        "news": news,
        "current_price": data["current_price"],
        "spread_points": 2.0,
        "portfolio": {"open_trades_count": 0, "today_signals_count": 0, "consecutive_losses": 0},
    }
    results["risk"] = RiskManagementAgent(config).evaluate(results)
    decision = DecisionAgent(config).decide(results)

    assert decision["decision"] in {"BUY", "SELL", "WAIT", "AVOID"}
    assert "signal" in decision or decision["decision"] == "WAIT"


def test_decision_with_news_danger_blocks_signal():
    """High-impact news in DANGER status must block signals."""
    config = base_config()

    # Create data with news danger
    with tempfile.TemporaryDirectory() as tmpdir:
        news_path = Path(tmpdir) / "news_events.json"
        event_time = (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat().replace("+00:00", "Z")
        news_path.write_text(json.dumps([{"event": "FOMC Rate Decision", "time": event_time, "impact": "HIGH", "currency": "USD"}]))

        agent = NewsRiskAgent(config)
        agent.events_path = news_path
        news = agent.check()

        assert news["market_status"] == "DANGER"
        assert news["can_trade"] is False

        # Pipeline must respect news block
        data = make_data(uptrend=True, count=240)
        results = {
            "technical": {"direction": "BUY", "confidence": 90, "indicators_raw": {"atr": 3.0}, "key_levels": {}},
            "classical": {"direction": "BUY", "confidence": 80, "support_levels": [], "resistance_levels": []},
            "smc": {"direction": "BUY", "confidence": 85, "entry_suggestion": {}},
            "price_action": {"direction": "BUY", "confidence": 75},
            "multitimeframe": {"direction": "BUY", "confidence": 80},
            "news": news,
            "current_price": data["current_price"],
            "spread_points": 2.0,
            "portfolio": {"open_trades_count": 0, "today_signals_count": 0, "consecutive_losses": 0},
        }
        results["risk"] = RiskManagementAgent(config).evaluate(results)
        decision = DecisionAgent(config).decide(results)

        assert decision["decision"] in {"AVOID", "WAIT"}


def test_decision_blocks_on_consecutive_losses():
    """Consecutive losses must block new signals."""
    config = base_config()
    results = {
        "technical": {"direction": "BUY", "confidence": 85, "indicators_raw": {"atr": 3.0}, "key_levels": {}},
        "classical": {"direction": "BUY", "confidence": 80, "support_levels": [], "resistance_levels": []},
        "smc": {"direction": "BUY", "confidence": 85, "entry_suggestion": {}},
        "price_action": {"direction": "BUY", "confidence": 75},
        "multitimeframe": {"direction": "BUY", "confidence": 80},
        "news": {"market_status": "SAFE", "can_trade": True, "summary": "safe"},
        "current_price": 2350.0,
        "spread_points": 2.0,
        "portfolio": {
            "open_trades_count": 0,
            "today_signals_count": 0,
            "consecutive_losses": 3,  # At limit
        },
    }
    results["risk"] = RiskManagementAgent(config).evaluate(results)
    decision = DecisionAgent(config).decide(results)

    assert results["risk"]["approved"] is False
    assert "Cooling" in str(results["risk"]["rejection_reason"])


def test_database_saves_and_trades_survive_pipeline():
    """Trade saved to DB must be retrievable with correct fields."""
    with tempfile.TemporaryDirectory() as tmpdir:
        local_path = Path(tmpdir) / "trades.json"
        config = base_config()
        config["database"] = {"local_fallback_file": str(local_path)}
        db = DatabaseService(config)

        # Simulate a BUY signal
        decision = {
            "decision": "BUY",
            "signal": {
                "type": "BUY",
                "entry": {"price": 2350.0, "low": 2349.5, "high": 2350.5},
                "stop_loss": 2344.0,
                "tp1": 2356.0,
                "tp2": 2362.0,
                "rr_ratio": 2.0,
            },
            "confidence": 78,
            "current_price": 2350.0,
            "reasons": ["Technical BUY", "SMC bullish"],
        }

        trade_id = db.save_trade(decision)
        assert trade_id.startswith("TRADE_")

        # Retrieve
        open_trades = db.get_open_trades()
        assert len(open_trades) == 1
        trade = open_trades[0]
        assert trade["id"] == trade_id
        assert trade["type"] == "BUY"
        assert trade["entry_price"] == 2350.0
        assert trade["stop_loss"] == 2344.0
        assert trade["tp1"] == 2356.0
        assert trade["tp2"] == 2362.0
        assert trade["status"] == "OPEN"
        assert "reasons" in trade
        assert "signal_snapshot" in trade


def test_signal_includes_all_required_fields():
    """Signal dictionary must have all fields for Telegram."""
    config = base_config()
    data = make_data(uptrend=True, count=240)

    results = {
        "technical": TechnicalAgent(config).analyze(data),
        "classical": ClassicalAgent(config).analyze(data),
        "smc": SMCAgent(config).analyze(data),
        "price_action": TechnicalAgent(config).analyze(data),
        "multitimeframe": MultiTimeframeAgent(config).analyze(data),
        "news": NewsRiskAgent(config).check(),
        "current_price": data["current_price"],
        "spread_points": 2.0,
        "portfolio": {"open_trades_count": 0, "today_signals_count": 0, "consecutive_losses": 0},
    }
    results["risk"] = RiskManagementAgent(config).evaluate(results)
    decision = DecisionAgent(config).decide(results)

    if decision["decision"] in {"BUY", "SELL"}:
        signal = decision["signal"]
        # All required fields for Telegram formatting
        assert "type" in signal
        assert "entry" in signal
        assert "stop_loss" in signal
        assert "tp1" in signal
        assert "tp2" in signal
        assert "rr_ratio" in signal
        assert "confidence" in signal
        assert signal["entry"]["price"] > 0
        assert signal["stop_loss"] > 0
        assert signal["tp1"] > 0
        assert signal["tp2"] > signal["tp1"]


def test_daily_report_agent():
    """DailyReportAgent must handle all trade status combinations."""
    config = base_config()
    agent = DailyReportAgent(config)

    # TP1_HIT status is ALSO counted as open trade, so use it only for wins test
    # MANUAL_CLOSE with pnl>0 is a win; SL/EXPIRED are losses; only OPEN counts as open
    trades = [
        {"status": "TP2_HIT", "current_pnl": 12.0, "final_pnl": 12.0},        # win
        {"status": "SL_HIT", "current_pnl": -8.0, "final_pnl": -8.0},         # loss
        {"status": "MANUAL_CLOSE", "current_pnl": 6.0, "final_pnl": 6.0},     # win (pnl>0)
        {"status": "SL_HIT", "current_pnl": -5.0, "final_pnl": -5.0},         # loss
        {"status": "OPEN"},                                                    # open only
        {"status": "EXPIRED", "current_pnl": -2.0, "final_pnl": -2.0},        # loss
    ]

    report = agent.generate(trades)
    assert "stats" in report
    assert "text" in report
    assert report["stats"]["total"] == 6
    # TP2_HIT(12), MANUAL_CLOSE(6) = wins(2); SL_HIT(-8), SL_HIT(-5), EXPIRED(-2) = losses(3); OPEN = open(1)
    assert report["stats"]["wins"] == 2
    assert report["stats"]["losses"] == 3
    assert report["stats"]["open"] == 1
    assert "net_points" in report["stats"]
    assert "win_rate" in report["stats"]
    assert "profit_factor" in report["stats"]
    assert len(report["text"]) > 50  # Non-empty report


def test_agent_weights_in_decision():
    """Decision agent must use configured weights correctly."""
    config = base_config()
    data = make_data(uptrend=True, count=240)

    # Run agents for real results
    tech = TechnicalAgent(config).analyze(data)
    classical = ClassicalAgent(config).analyze(data)
    smc = SMCAgent(config).analyze(data)
    pa = PriceActionAgent(config).analyze(data)
    mtf = MultiTimeframeAgent(config).analyze(data)
    news = NewsRiskAgent(config).check()

    results = {
        "technical": tech,
        "classical": classical,
        "smc": smc,
        "price_action": pa,
        "multitimeframe": mtf,
        "news": news,
        "current_price": data["current_price"],
        "spread_points": 2.0,
        "portfolio": {"open_trades_count": 0, "today_signals_count": 0, "consecutive_losses": 0},
    }
    results["risk"] = RiskManagementAgent(config).evaluate(results)
    decision = DecisionAgent(config).decide(results)

    assert "weights_used" in decision
    assert "raw_agent_scores" in decision
    assert "total_weighted_score" in decision
    # In strong uptrend, decision should be BUY (or at least not WAIT due to bad weights)
    assert decision["decision"] in {"BUY", "SELL", "WAIT"}
    assert "agents_agreement" in decision
    # Check that weights are used in decision scoring
    for agent in ["technical", "classical", "smc", "price_action", "multitimeframe"]:
        assert agent in decision["weights_used"]
        assert agent in decision["raw_agent_scores"]


def test_news_agent_safe_when_no_events():
    """News agent must return SAFE when no events are configured."""
    config = base_config()
    with tempfile.TemporaryDirectory() as tmpdir:
        news_path = Path(tmpdir) / "news_events.json"
        news_path.write_text("[]")
        agent = NewsRiskAgent(config)
        agent.events_path = news_path
        result = agent.check()
        assert result["market_status"] == "SAFE"
        assert result["can_trade"] is True
        assert len(result["upcoming_events"]) == 0


def test_risk_agent_uses_smc_entry_suggestion():
    """Risk management must prefer SMC entry suggestion when valid."""
    config = base_config()
    results = {
        "current_price": 2355.0,
        "spread_points": 2.0,
        "technical": {"direction": "BUY", "confidence": 80, "indicators_raw": {"atr": 3.0}, "key_levels": {"nearest_support": 2340.0, "nearest_resistance": 2365.0}},
        "classical": {"direction": "BUY", "confidence": 75, "support_levels": [2340.0], "resistance_levels": [2365.0]},
        "smc": {"direction": "BUY", "confidence": 85, "entry_suggestion": {"type": "BUY", "entry": 2352.0, "sl": 2341.0, "tp": 2360.0}, "order_blocks": []},
        "price_action": {"direction": "BUY", "confidence": 70},
        "multitimeframe": {"direction": "BUY", "confidence": 75},
        "portfolio": {"open_trades_count": 0, "today_signals_count": 0, "consecutive_losses": 0},
    }
    risk = RiskManagementAgent(config).evaluate(results)
    assert risk["approved"] is True
    assert risk["direction"] == "BUY"
    # Entry should be close to SMC suggestion
    assert abs(risk["entry"]["price"] - 2352.0) < 5.0