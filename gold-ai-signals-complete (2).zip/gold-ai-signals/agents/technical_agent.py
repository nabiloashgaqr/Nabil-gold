"""Technical Analysis Agent.

يحلل RSI/MACD/EMA/SMA/Bollinger/ATR ويعيد قراراً خوارزمياً مبدئياً مناسباً
للمرحلة الأولى، مع بنية مخرجات قابلة للتطوير في المراحل التالية.
"""

from __future__ import annotations

from typing import Any, Dict, List

from agents.base_agent import BaseAgent
from utils.indicators import (
    calculate_atr,
    calculate_bollinger_bands,
    calculate_ema,
    calculate_macd,
    calculate_rsi,
    calculate_sma,
    detect_support_resistance,
)


class TechnicalAgent(BaseAgent):
    """Analyze technical indicators and infer direction/confidence."""

    name = "technical"

    def analyze(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            candles = market_data.get("data", [])
            if len(candles) < 60:
                return self._empty_result("بيانات غير كافية للتحليل الفني")

            closes = [float(c["close"]) for c in candles]
            current_price = closes[-1]

            rsi_series = calculate_rsi(candles, 14)
            rsi = self._last_value(rsi_series, 50.0)
            macd = calculate_macd(candles)
            macd_latest = macd.get("latest", {"macd": 0.0, "signal": 0.0, "histogram": 0.0})  # type: ignore[assignment]
            ema20 = self._last_value(calculate_ema(candles, 20), current_price)
            ema50 = self._last_value(calculate_ema(candles, 50), current_price)
            sma200 = self._last_value(calculate_sma(candles, 200), self._last_value(calculate_sma(candles, min(100, len(candles))), current_price))
            bb = calculate_bollinger_bands(candles, 20, 2)
            bb_latest = bb.get("latest", {"upper": current_price, "middle": current_price, "lower": current_price})  # type: ignore[assignment]
            atr = self._last_value(calculate_atr(candles, 14), 1.0)
            levels = detect_support_resistance(candles, lookback=60)

            score = 0
            signals: List[str] = []

            # Moving average structure
            if current_price > ema20 > ema50:
                score += 2
                signals.append("Price above EMA20/EMA50 - bullish structure")
            elif current_price < ema20 < ema50:
                score -= 2
                signals.append("Price below EMA20/EMA50 - bearish structure")
            elif current_price > ema50:
                score += 1
                signals.append("Price above EMA50")
            elif current_price < ema50:
                score -= 1
                signals.append("Price below EMA50")

            if ema50 > sma200:
                score += 1
                signals.append("EMA50 above SMA200 - long-term bullish bias")
            elif ema50 < sma200:
                score -= 1
                signals.append("EMA50 below SMA200 - long-term bearish bias")

            # MACD
            hist = float(macd_latest.get("histogram", 0.0))  # type: ignore[union-attr]
            macd_value = float(macd_latest.get("macd", 0.0))  # type: ignore[union-attr]
            macd_signal = float(macd_latest.get("signal", 0.0))  # type: ignore[union-attr]
            if macd_value > macd_signal and hist > 0:
                score += 2
                signals.append("MACD above signal with positive histogram")
            elif macd_value < macd_signal and hist < 0:
                score -= 2
                signals.append("MACD below signal with negative histogram")

            # RSI
            if rsi < 30:
                score += 2
                signals.append("RSI oversold - potential bullish reversal")
            elif rsi > 70:
                score -= 2
                signals.append("RSI overbought - potential bearish reversal")
            elif 50 <= rsi <= 65:
                score += 1
                signals.append("RSI supports bullish momentum")
            elif 35 <= rsi < 50:
                score -= 1
                signals.append("RSI supports bearish momentum")

            # Bollinger location
            bb_upper = float(bb_latest.get("upper", current_price))  # type: ignore[union-attr]
            bb_middle = float(bb_latest.get("middle", current_price))  # type: ignore[union-attr]
            bb_lower = float(bb_latest.get("lower", current_price))  # type: ignore[union-attr]
            band_width = max(bb_upper - bb_lower, 0.0001)
            if current_price <= bb_lower + band_width * 0.15:
                score += 1
                signals.append("Price near lower Bollinger Band")
            elif current_price >= bb_upper - band_width * 0.15:
                score -= 1
                signals.append("Price near upper Bollinger Band")
            elif current_price > bb_middle:
                score += 0.5
                signals.append("Price above Bollinger middle band")
            elif current_price < bb_middle:
                score -= 0.5
                signals.append("Price below Bollinger middle band")

            direction = "NEUTRAL"
            if score >= 3:
                direction = "BUY"
            elif score <= -3:
                direction = "SELL"

            trend = "SIDEWAYS"
            if ema20 > ema50 and current_price > ema50:
                trend = "BULLISH"
            elif ema20 < ema50 and current_price < ema50:
                trend = "BEARISH"

            confidence = min(88, max(35, int(45 + abs(score) * 8))) if direction != "NEUTRAL" else min(50, int(25 + abs(score) * 5))
            momentum = "STRONG" if abs(score) >= 6 else "MODERATE" if abs(score) >= 3 else "WEAK"
            overbought_oversold = "OVERBOUGHT" if rsi > 70 else "OVERSOLD" if rsi < 30 else "NORMAL"

            supports = sorted([level for level in levels.get("supports", []) if level < current_price], reverse=True)
            resistances = sorted([level for level in levels.get("resistances", []) if level > current_price])
            nearest_support = supports[0] if supports else min(float(c["low"]) for c in candles[-20:])
            nearest_resistance = resistances[0] if resistances else max(float(c["high"]) for c in candles[-20:])
            entry_buffer = max(atr * 0.10, 0.30)

            return {
                "agent": self.name,
                "direction": direction,
                "confidence": confidence,
                "trend": trend,
                "momentum": momentum,
                "overbought_oversold": overbought_oversold,
                "signals": signals,
                "entry_zone": {"low": round(current_price - entry_buffer, 2), "high": round(current_price + entry_buffer, 2)},
                "key_levels": {
                    "nearest_support": round(nearest_support, 2),
                    "nearest_resistance": round(nearest_resistance, 2),
                },
                "indicators_raw": {
                    "rsi": round(rsi, 2),
                    "macd": {
                        "macd": round(macd_value, 4),
                        "signal": round(macd_signal, 4),
                        "histogram": round(hist, 4),
                    },
                    "ema_20": round(ema20, 2),
                    "ema_50": round(ema50, 2),
                    "sma_200": round(sma200, 2),
                    "atr": round(atr, 2),
                    "bb": {"upper": round(bb_upper, 2), "middle": round(bb_middle, 2), "lower": round(bb_lower, 2)},
                },
                "summary": f"الاتجاه {trend} مع زخم {momentum}، RSI={rsi:.1f} والإشارة الفنية {direction}",
            }
        except Exception as exc:  # noqa: BLE001
            self.logger.exception("Technical analysis failed")
            return self._empty_result(f"فشل التحليل الفني: {exc}")

    def _last_value(self, values: List[float | None], default: float = 0.0) -> float:
        for value in reversed(values):
            if value is not None:
                return float(value)
        return default

    def _empty_result(self, summary: str) -> Dict[str, Any]:
        return {
            "agent": self.name,
            "direction": "NEUTRAL",
            "confidence": 0,
            "trend": "SIDEWAYS",
            "momentum": "WEAK",
            "overbought_oversold": "NORMAL",
            "signals": [],
            "entry_zone": {"low": 0.0, "high": 0.0},
            "key_levels": {"nearest_support": 0.0, "nearest_resistance": 0.0},
            "indicators_raw": {},
            "summary": summary,
        }
