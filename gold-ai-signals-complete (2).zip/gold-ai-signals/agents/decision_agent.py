"""Decision Agent.

يدمج نتائج الوكلاء بالأوزان، يطبق فلاتر الأخبار/المخاطر/الثقة/التوافق/
ساعات التداول، ثم ينتج قرار BUY/SELL/WAIT/AVOID ورسالة signal موحدة للحفظ والإرسال.
"""

from __future__ import annotations

from typing import Any, Dict, List

from agents.base_agent import BaseAgent
from utils.helpers import load_config


class DecisionAgent(BaseAgent):
    """Weighted consensus decision maker."""

    name = "decision"
    ANALYTIC_AGENTS = ["technical", "classical", "smc", "price_action", "multitimeframe"]

    def __init__(self, config: Dict[str, Any] | None = None) -> None:
        super().__init__(config or load_config())
        self.weights = self.config.get(
            "agent_weights",
            {"technical": 0.20, "classical": 0.20, "smc": 0.25, "price_action": 0.15, "multitimeframe": 0.15},
        )
        self.risk_settings = self.config.get("risk_settings", {})
        self.weight_sum = sum(float(self.weights.get(agent, 0)) for agent in self.ANALYTIC_AGENTS) or 1.0

    def decide(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Merge agent results and produce the final decision."""
        try:
            weighted_scores: Dict[str, float] = {}
            raw_agent_scores: Dict[str, Dict[str, Any]] = {}
            buy_agents: List[str] = []
            sell_agents: List[str] = []
            neutral_agents: List[str] = []

            for agent in self.ANALYTIC_AGENTS:
                result = results.get(agent, {}) or {}
                direction = str(result.get("direction", "NEUTRAL")).upper()
                confidence = max(0.0, min(100.0, float(result.get("confidence", 0) or 0)))
                weight = float(self.weights.get(agent, 0))
                multiplier = 1 if direction == "BUY" else -1 if direction == "SELL" else 0
                score = confidence * weight * multiplier
                weighted_scores[agent] = round(score, 2)
                raw_agent_scores[agent] = {"direction": direction, "confidence": round(confidence, 2), "weight": weight, "weighted_score": round(score, 2)}
                if direction == "BUY":
                    buy_agents.append(agent)
                elif direction == "SELL":
                    sell_agents.append(agent)
                else:
                    neutral_agents.append(agent)

            total_score = round(sum(weighted_scores.values()), 2)
            raw_direction = "BUY" if total_score > 0 else "SELL" if total_score < 0 else "WAIT"
            confidence = int(round(abs(total_score) / self.weight_sum))
            confidence = max(0, min(100, confidence))

            agreeing_agents = buy_agents if raw_direction == "BUY" else sell_agents if raw_direction == "SELL" else []
            disagreeing_agents = sell_agents if raw_direction == "BUY" else buy_agents if raw_direction == "SELL" else buy_agents + sell_agents

            news = results.get("news", {}) or {}
            risk = results.get("risk", {}) or {}
            session = results.get("session", {}) or {}
            portfolio = results.get("portfolio", {}) or {}
            min_confidence = int(self.risk_settings.get("min_confidence", 70))
            max_daily_signals = int(self.risk_settings.get("max_daily_signals", 8))
            today_signals_count = int(portfolio.get("today_signals_count", 0) or 0)
            market_status = str(news.get("market_status", "SAFE")).upper()

            # CAUTION does not block trading, but it trims confidence slightly.
            if market_status in {"CAUTION", "HIGH_VOLATILITY"}:
                confidence = max(0, confidence - (8 if market_status == "CAUTION" else 15))

            # Session quality adjustment
            session_quality = str(session.get("session_quality", "UNKNOWN")).upper()
            quality_penalty = {"BEST": 0, "HIGH": 0, "MEDIUM": -5, "LOW": -10, "NONE": -15, "UNKNOWN": 0}.get(session_quality, 0)
            if quality_penalty < 0:
                confidence = max(0, confidence + quality_penalty)

            filters = {
                "news_filter": bool(news.get("can_trade", True)) and market_status not in {"DANGER", "HIGH_VOLATILITY"},
                "risk_filter": bool(risk.get("approved", False)),
                "confidence_filter": confidence >= min_confidence,
                "agreement_filter": len(agreeing_agents) >= 3,
                "daily_limit_filter": today_signals_count < max_daily_signals,
                "trading_hours_filter": bool(session.get("trading_allowed", True)),
            }

            decision = raw_direction if raw_direction in {"BUY", "SELL"} else "WAIT"
            if not filters["news_filter"]:
                decision = "AVOID"
            elif not filters["trading_hours_filter"]:
                decision = "AVOID"
            elif not all(filters.values()):
                decision = "WAIT"

            reasons = self._collect_reasons(results, raw_direction, filters, session)
            warnings = self._collect_warnings(results, filters, market_status, session)
            signal = self._build_signal(decision, confidence, risk, results) if decision in {"BUY", "SELL"} else None

            return {
                "agent": self.name,
                "timestamp": self.now_iso(),
                "decision": decision,
                "confidence": confidence,
                "current_price": round(float(results.get("current_price", 0) or 0), 2),
                "agents_agreement": {
                    "buy_count": len(buy_agents),
                    "sell_count": len(sell_agents),
                    "neutral_count": len(neutral_agents),
                    "agreeing_agents": agreeing_agents,
                    "disagreeing_agents": disagreeing_agents,
                    "neutral_agents": neutral_agents,
                },
                "weighted_scores": weighted_scores,
                "raw_agent_scores": raw_agent_scores,
                "weights_used": {agent: float(self.weights.get(agent, 0)) for agent in self.ANALYTIC_AGENTS},
                "total_weighted_score": total_score,
                "normalized_confidence_basis": round(abs(total_score) / self.weight_sum, 2),
                "filters_passed": filters,
                "session_info": {
                    "current_session": session.get("current_session"),
                    "session_quality": session_quality,
                    "trading_allowed": session.get("trading_allowed", True),
                    "reason": session.get("reason", ""),
                },
                "signal": signal,
                "reasons": reasons,
                "warnings": warnings,
                "summary": self._summary(decision, confidence, agreeing_agents, warnings, session),
            }
        except Exception as exc:  # noqa: BLE001
            self.logger.exception("Decision failed")
            return {
                "agent": self.name,
                "timestamp": self.now_iso(),
                "decision": "WAIT",
                "confidence": 0,
                "agents_agreement": {"buy_count": 0, "sell_count": 0, "neutral_count": 5, "agreeing_agents": [], "disagreeing_agents": [], "neutral_agents": self.ANALYTIC_AGENTS},
                "weighted_scores": {},
                "raw_agent_scores": {},
                "total_weighted_score": 0,
                "filters_passed": {"news_filter": False, "risk_filter": False, "confidence_filter": False, "agreement_filter": False, "daily_limit_filter": True, "trading_hours_filter": True},
                "signal": None,
                "reasons": [f"فشل وكيل القرار: {exc}"],
                "warnings": [],
                "summary": "فشل القرار - انتظار",
            }

    def _build_signal(self, decision: str, confidence: int, risk: Dict[str, Any], results: Dict[str, Any]) -> Dict[str, Any]:
        entry = risk.get("entry", {})
        stop = risk.get("stop_loss", {})
        take_profit = risk.get("take_profit", {})
        tp1 = take_profit.get("tp1", {})
        tp2 = take_profit.get("tp2", {})
        return {
            "type": decision,
            "entry": {
                "price": round(float(entry.get("price", results.get("current_price", 0)) or 0), 2),
                "low": round(float(entry.get("zone", {}).get("low", entry.get("price", 0)) or 0), 2),
                "high": round(float(entry.get("zone", {}).get("high", entry.get("price", 0)) or 0), 2),
            },
            "stop_loss": round(float(stop.get("price", 0) or 0), 2),
            "tp1": round(float(tp1.get("price", 0) or 0), 2),
            "tp2": round(float(tp2.get("price", 0) or 0), 2),
            "rr_ratio": round(float(tp2.get("rr_ratio", 0) or 0), 2),
            "confidence": confidence,
            "current_price": round(float(results.get("current_price", 0) or 0), 2),
        }

    def _collect_reasons(
        self,
        results: Dict[str, Any],
        direction: str,
        filters: Dict[str, bool],
        session: Dict[str, Any],
    ) -> List[str]:
        reasons: List[str] = []
        for agent in self.ANALYTIC_AGENTS:
            result = results.get(agent, {}) or {}
            if result.get("direction") == direction:
                summary = result.get("summary")
                if summary:
                    reasons.append(f"{agent}: {summary}")
        news = results.get("news", {}) or {}
        risk = results.get("risk", {}) or {}
        if filters.get("news_filter"):
            reasons.append(news.get("summary", "لا توجد أخبار عالية الخطورة حالياً"))
        if filters.get("risk_filter"):
            reasons.append(risk.get("summary", "إدارة المخاطر مقبولة"))
        if session.get("current_session"):
            reasons.append(f"✅ جلسة {session.get('current_session')} ({session.get('session_quality', 'UNKNOWN')})")
        return reasons[:8] or ["الشروط غير مكتملة - انتظار"]

    def _collect_warnings(
        self,
        results: Dict[str, Any],
        filters: Dict[str, bool],
        market_status: str,
        session: Dict[str, Any],
    ) -> List[str]:
        warnings: List[str] = []
        if market_status == "CAUTION":
            warnings.append("حالة السوق CAUTION - تم تخفيض الثقة")
        if market_status == "HIGH_VOLATILITY":
            warnings.append("تذبذب عالٍ بعد/حول خبر - منع التداول")
        if not filters.get("news_filter"):
            warnings.append("فلتر الأخبار منع التداول")
        if not filters.get("risk_filter"):
            warnings.append(f"فلتر المخاطر: {results.get('risk', {}).get('rejection_reason', 'غير مقبول')}")
        if not filters.get("confidence_filter"):
            warnings.append("الثقة أقل من الحد الأدنى")
        if not filters.get("agreement_filter"):
            warnings.append("لا يوجد توافق 3 وكلاء على الأقل")
        if not filters.get("daily_limit_filter"):
            warnings.append("تم الوصول للحد الأقصى من الإشارات اليومية")
        if not filters.get("trading_hours_filter"):
            warnings.append(f"خارج ساعات التداول: {session.get('reason', 'غير مسموح')}")
        for agent in self.ANALYTIC_AGENTS:
            for warning in results.get(agent, {}).get("warnings", []) or []:
                warnings.append(f"{agent}: {warning}")
        return warnings[:10]

    def _summary(
        self,
        decision: str,
        confidence: int,
        agreeing_agents: List[str],
        warnings: List[str],
        session: Dict[str, Any],
    ) -> str:
        session_info = f" [{session.get('current_session', 'غير محدد')}]" if session.get("current_session") else ""
        if decision in {"BUY", "SELL"}:
            return f"إشارة {decision} بثقة {confidence}% - توافق {len(agreeing_agents)} وكلاء{session_info}"
        if decision == "AVOID":
            return "تجنب التداول بسبب الأخبار/المخاطر/الساعات"
        return f"انتظار - الشروط غير مكتملة ({'; '.join(warnings[:2])})"