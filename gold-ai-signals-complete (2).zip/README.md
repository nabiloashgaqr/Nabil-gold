# 🏆 Gold AI Signals - نظام إشارات التداول الذكي

<div align="center">

![Gold AI Signals](https://img.shields.io/badge/Gold%20AI%20Signals-🤖%20AI%20Powered-blue)
![Python](https://img.shields.io/badge/Python-3.10+-green)
![GitHub Actions](https://img.shields.io/badge/GitHub%20Actions-Automated-orange)
![Telegram](https://img.shields.io/badge/Telegram-Notifications-red)

</div>

## 🎯 ما هو Gold AI Signals؟

نظام إرسال إشارات تداول **XAU/USD** يعمل بالكامل على **GitHub Actions** بشكل مجاني، يستخدم **الذكاء الاصطناعي** (OpenAI/Anthropic/Grok/Gemini) لتحليل السوق ويتعلم من أخطائه ذاتياً.

## ✨ الميزات الرئيسية

| الميزة | الوصف |
|--------|-------|
| 🤖 **12 وكيل ذكي** | تحليل من وجهات نظر متعددة |
| 🧠 **تعلم ذاتي** | يتعلم من كل صفقة ويحسن قراراته |
| 📊 **AI Providers** | OpenAI, Anthropic, Grok, Gemini |
| 📱 **إشعارات Telegram** | إرسال الإشارات فوراً |
| ⏰ **ساعات التداول** | 11:00 - 17:00 UTC (الأحد-الخميس) |
| 🔄 **مجاناً 100%** | GitHub Actions (2000 دقيقة/شهر) |

## 🔥 الشروط الجديدة للإشارات

```
✅ حد أدنى: 3 وكلاء يوافقون
✅ نسبة توافق: فوق 60%
✅ لا حد أقصى للصفقات - أرسل كل إشارة تتحقق شروطها!
```

### كيف يتم إرسال الإشارة؟

```
1️⃣ تحليل السوق من 12 وكيل
         ↓
2️⃣ جمع الأصوات مع الأوزان المتعلمة
         ↓
3️⃣ التحقق: 3 وكلاء + 60% توافق؟
         ↓
4️⃣ إذا نعم → إرسال إشارة Telegram
         ↓
5️⃣ التعلم من النتيجة وتحسين الأوزان
```

## 📁 هيكل المشروع

```
gold-ai-signals/
├── agents/                    # الوكلاء الـ 12
│   ├── technical_agent.py
│   ├── smc_agent.py
│   ├── decision_agent.py
│   └── ... (12 agents total)
├── services/                  # الخدمات
│   ├── ai_service.py          # OpenAI/Anthropic/Grok/Gemini
│   ├── learning_service.py    # التعلم الذكي
│   ├── telegram_bot.py        # إشعارات
│   └── ...
├── scripts/                   # سكريبتات التشغيل
│   ├── run_analysis.py        # التحليل الرئيسي
│   └── run_learning.py        # التعلم اليومي
├── .github/workflows/         # GitHub Actions
│   ├── analyze.yml            # كل 15 دقيقة
│   ├── update_trades.yml      # كل ساعة
│   └── daily_report.yml       # تقرير يومي
├── config.json                # الإعدادات
└── tests/                     # الاختبارات
```

## 🚀 البدء السريع

### 1️⃣ استنساخ المشروع

```bash
git clone https://github.com/YOUR_USERNAME/gold-ai-signals.git
cd gold-ai-signals
```

### 2️⃣ إضافة GitHub Secrets

| Secret | الوصف |
|--------|-------|
| `TELEGRAM_BOT_TOKEN` | توكن بوت تلجرام |
| `TELEGRAM_CHAT_ID` | معرف المحادثة |
| `OPENAI_API_KEY` | مفتاح OpenAI (أو Anthropic/Grok/Gemini) |
| `SUPABASE_URL` | رابط Supabase |
| `SUPABASE_KEY` | مفتاح Supabase |
| `TWELVE_DATA_API_KEY` | مفتاح Twelve Data (اختياري) |

### 3️⃣ تشغيل SQL Schema في Supabase

```sql
-- انسخ محتوى supabase_schema.sql إلى SQL Editor في Supabase
```

### 4️⃣ تفعيل Workflows

اذهب إلى GitHub → Actions → Enable workflows

## 📊 كيف يعمل التعلم الذكي؟

```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│   📅 كل يوم (23:00 UTC)                                 │
│                                                         │
│   1️⃣ جلب الصفقات المغلقة (آخر 7 أيام)                  │
│         ↓                                               │
│   2️⃣ تحليل أداء كل وكيل                                │
│         ↓                                               │
│   3️⃣ تحديث الأوزان (↑ الفائزين، ↓ الخاسرين)           │
│         ↓                                               │
│   4️⃣ حفظ في قاعدة البيانات                             │
│         ↓                                               │
│   5️⃣ تطبيق الأوزان الجديدة في التحليل القادم           │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### أوزان الوكلاء الحالية (تتحسن مع الوقت):

```json
{
  "technical": "20%",
  "classical": "20%",
  "smc": "25%",
  "price_action": "15%",
  "multitimeframe": "20%"
}
```

## 🎯 شروط إرسال الإشارة

```json
{
  "signal_requirements": {
    "min_agents_agree": 3,
    "min_agreement_percentage": 60,
    "allow_all_signals": true
  }
}
```

### مثال عملي:

| السيناريو | القرار |
|-----------|--------|
| 3 وكلاء BUY + 0 SELL = 100% | ✅ إرسال BUY |
| 4 وكلاء BUY + 1 SELL = 80% | ✅ إرسال BUY |
| 2 وكلاء BUY + 0 SELL = 100% | ❌ انتظار |
| 3 BUY + 3 SELL = 50% | ❌ انتظار |

## 📱 رسالة الإشارة في Telegram

```
━━━━━━━━━━━━━━━━━━━━
🟢 القرار النهائي
━━━━━━━━━━━━━━━━━━━━
📊 الإشارة: BUY
🎯 الثقة: 85%

🔥 متطلبات التوافق:
├ الوكلاء: 3/3 ✅
├ التوافق: 100% ✅

🗳️ أصوات الوكلاء:
├ شراء: 3 (100%)
├ بيع: 0 (0%)
└ انتظار: 2

🤖 AI: OpenAI
├ القوة: Strong
└ R/R: 2.5

🧠 التعلم الذكي: ✅ مفعّل
├ Win Rate: 65%
━━━━━━━━━━━━━━━━━━━━
```

## 🧪 الاختبارات

```bash
# تشغيل جميع الاختبارات
python -m pytest tests/ -v

# اختبار معين
python -m pytest tests/test_decision_requirements.py -v
```

**النتيجة:** 175 اختبار ناجح ✅

## 📈 نسبة النجاح المستهدفة

```
🎯 الهدف: فوق 80%

كيف نوصل؟:
──────────
✅ تحليل من 12 وكيل (وجهات نظر متعددة)
✅ تعلم ذاتي من كل صفقة
✅ إدارة مخاطر صارمة (SL/TP)
✅ إرسال إشارات فقط عند توافق عالي
✅ لا مشاعر، لا panic selling
```

## ⚠️ إدارة المخاطر

```yaml
Stop Loss: 1.5 × ATR
Take Profit 1: 2.0 × ATR
Take Profit 2: 3.5 × ATR
Risk per trade: 1-2%
Max daily risk: 6%
Trailing stop: 20 نقطة من السعر الحالي
Partial close: 50% عند TP1
```

## 🔧 الإعدادات القابلة للتخصيص

```json
{
  "risk_settings": {
    "min_confidence": 60,
    "min_rr_ratio": 1.5,
    "atr_multiplier_sl": 1.5,
    "atr_multiplier_tp1": 2.0,
    "atr_multiplier_tp2": 3.5
  },
  "signal_requirements": {
    "min_agents_agree": 3,
    "min_agreement_percentage": 60,
    "allow_all_signals": true
  },
  "learning": {
    "enabled": true,
    "max_weight_change": 0.25,
    "momentum_weight": 0.4,
    "aggressive_mode": true
  }
}
```

## 📊 GitHub Actions Minutes

| Workflow | التكرار | الدقائق/الشهر |
|----------|---------|---------------|
| analyze.yml | كل 15 دقيقة | ~960 |
| update_trades.yml | كل ساعة | ~270 |
| daily_report.yml | يومياً | ~60 |
| **الإجمالي** | | **~1,290** |

✅ **Plan Free (2,000 دقيقة): كافي!**

## 🤝 المساهمة

نرحب بمساهماتكم! يرجى:
1. Fork المشروع
2. إنشاء branch للميزة
3. كتابة اختبارات
4. Pull request

## 📄 الرخصة

MIT License - مجاني للاستخدام الشخصي والتجاري

---

<div align="center">

**صُنع بـ ❤️ للمتداولين العرب**

**Gold AI Signals - Trade Smart, Trade Safe**

</div>