"""Tick-level manager (VPS, mt5_demo only).

Analysis stays on the 5-minute cycle; EXECUTION management runs EVERY TICK:
pending activation, breakeven, TP1 partial, trailing, and broker-side closes
are detected and applied tick-by-tick through MT5, with DB writes and cards
only on state changes. MT5 is the execution authority; the DB mirrors it.

Pure decision helpers are unit-tested (tests/test_tick_manager_logic.py).
"""
from __future__ import annotations

# --- VPS: load .env if present (real env vars ALWAYS win over .env) ---
try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv()  # override=False: task-wrapper vars take precedence
except Exception:
    pass

import json
import logging
import os
import sys
import time
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.trading_rules import stop_rule, trailing_params  # noqa: E402
from utils.instruments import point_size, config_for_instrument, normalize_symbol  # noqa: E402
# magic_for is needed inside _handle_row (module scope); mt5_executor keeps
# its MetaTrader5 import lazy, so this top-level import is safe on any OS.
from services.mt5_executor import magic_for  # noqa: E402
from services.execution_paths import path_header  # noqa: E402

logger = logging.getLogger("tick_manager")
LOOP_SLEEP = float(os.environ.get("TICK_LOOP_SLEEP", 0.25))
ROWS_REFRESH_SECONDS = float(os.environ.get("TICK_ROWS_REFRESH", 3.0))


# ── pure decisions (unit-tested) ────────────────────────────────────────────

def decide_be(
    side: str, entry: float, current: float, risk_points: float,
    be_points: float, min_be_rr: float, already: bool, point_value: float = 0.10,
) -> bool:
    """Arm breakeven once price travelled >= be_points AND >= min_be_rr
    (both in codebase points; fav converted from price)."""
    if already or entry <= 0 or risk_points <= 0:
        return False
    fav_points = ((entry - current) if side == "SELL" else (current - entry)) / point_value
    return fav_points >= be_points and fav_points >= min_be_rr * risk_points


def decide_trailing(
    side: str, entry: float, current_stop: float, favorable_extreme: float,
    gap_points: float, step_points: float, point_value: float,
) -> Optional[float]:
    """Ratchet the stop behind the favorable extreme (gap), in steps."""
    if side == "BUY":
        candidate = favorable_extreme - gap_points * point_value
        if candidate > entry and candidate >= current_stop + step_points * point_value:
            return round(candidate, 2)
    else:
        candidate = favorable_extreme + gap_points * point_value
        if candidate < entry and candidate <= current_stop - step_points * point_value:
            return round(candidate, 2)
    return None


def decide_tp1(side: str, tp1: float, candle_low: float, candle_high: float,
               done: bool) -> bool:
    if done or tp1 <= 0:
        return False
    # BUY TP1 (above entry) is touched when the HIGH reaches it; SELL when
    # the LOW does. The old inverted form booked halves AT A LOSS the moment
    # price sat below an above-entry target (MT5 journal 2026-08-10 09:50).
    return (candle_high >= tp1) if side == "BUY" else (candle_low <= tp1)



def corrected_execution_stop(
    side: str,
    actual_entry: float,
    current_stop: float,
    planned_entry: float,
    planned_stop: float,
    *,
    min_liquidity_points: float = 200.0,
    safety_buffer_points: float = 70.0,
    cap_points: float = 400.0,
    point_value: float = 0.10,
) -> tuple[Optional[float], float, float]:
    """Normalize the initial broker stop after actual market fill.

    The liquidity law selects a planned stop in [200+70, 400] points. A better
    market fill can silently shrink that distance (live: 4392.63 -> 4368 =
    246.3 pts). Keep the structural stop when its actual distance is legal;
    otherwise move it to preserve the planned/floor distance, capped at 400.
    Returns (new_stop_or_None, required_points, actual_points).
    """
    if point_value <= 0 or actual_entry <= 0 or current_stop <= 0:
        return None, 0.0, 0.0
    side = str(side or "").upper()
    risk_side = ((side == "BUY" and current_stop < actual_entry)
                 or (side == "SELL" and current_stop > actual_entry))
    if not risk_side:
        return None, 0.0, 0.0  # BE/trailing protection must never be widened
    floor_points = max(0.0, min_liquidity_points + safety_buffer_points)
    planned_points = (
        abs(planned_entry - planned_stop) / point_value
        if planned_entry > 0 and planned_stop > 0 else floor_points
    )
    required = min(max(planned_points, floor_points), cap_points)
    actual = abs(actual_entry - current_stop) / point_value
    target_points = required if actual < required - 0.5 else cap_points if actual > cap_points + 0.5 else None
    if target_points is None:
        return None, round(required, 1), round(actual, 1)
    new_stop = (actual_entry - target_points * point_value
                if side == "BUY" else actual_entry + target_points * point_value)
    return round(new_stop, 2), round(required, 1), round(actual, 1)


def _row_fresh(row: Dict[str, Any], max_age_minutes: float = 60.0) -> bool:
    """A row is placement-eligible only within max_age of created_at.
    Live incident 2026-08-10: a finished TP1_HIT row with no ticket was
    resurrected into fresh market orders every tick."""
    from datetime import datetime, timezone
    raw = str(row.get("created_at") or "")
    if not raw:
        return False
    try:
        created = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except Exception:  # noqa: BLE001
        return False
    if created.tzinfo is None:
        created = created.replace(tzinfo=timezone.utc)
    age = (datetime.now(timezone.utc) - created).total_seconds() / 60.0
    return 0 <= age <= max_age_minutes


def classify_broker_exit(side: str, deal_price: float, entry: float,
                         stop: float, tp2: float) -> str:
    """Map a broker-side exit price to our status labels.

    The broker only closes on SL/TP, so an exit between stop and TP2 means
    the (already moved) trailing/breakeven stop was the trigger. Pure +
    unit-tested (tests/test_mt5_execution_correctness.py).
    """
    eps = 1e-9
    if side == "BUY":
        if tp2 and deal_price >= tp2 - eps:
            return "TP2_HIT"
        if deal_price <= (stop or entry) + eps:
            return "SL_HIT"
        return "TRAILING_SL_HIT"
    if tp2 and deal_price <= tp2 + eps:
        return "TP2_HIT"
    if deal_price >= (stop or entry) - eps:
        return "SL_HIT"
    return "TRAILING_SL_HIT"


# ── live loop ───────────────────────────────────────────────────────────────

def _iso_from_epoch(ts: float | int | None) -> str | None:
    """UTC ISO stamp (Z) from a broker epoch; None when absent/invalid."""
    try:
        value = float(ts)
        if value <= 0:
            return None
        return datetime.fromtimestamp(value, tz=timezone.utc).isoformat().replace("+00:00", "Z")
    except (TypeError, ValueError, OSError):
        return None


def _now_iso_stamp() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _close_stamp(exit_info: Dict[str, Any] | None, now_ts: float | None = None) -> str:
    """BUILD 22 (2026-08-21): the REAL close time for a broker-closed trade.

    The live mirror wrote status/close_price but never closed_at, so every
    post-exit guard (post-TP2 2.5h block, WIN/LOSS cooldowns, the daily
    report) measured from the OPEN time - the 09:16 pending slipped through
    three minutes after a real 09:13 TP2. Prefer the broker deal's own time.

    BUILD 22.1: the broker clock runs ~3h AHEAD of the VPS clock (observed
    on the tick stores and on the 2026-08-21 backfill scan). A future stamp
    would make ``hours_since`` negative and the post-TP2 guard skips
    negative ages (fail-open). Future deal times are therefore clamped to
    the discovery moment - the live path detects a close within seconds, so
    the stamp stays within seconds of the truth and is never in the future.
    """
    if isinstance(exit_info, dict):
        try:
            deal_ts = float(exit_info.get("time") or 0)
        except (TypeError, ValueError):
            deal_ts = 0.0
        ref = float(now_ts if now_ts is not None else time.time())
        if deal_ts > 0 and deal_ts <= ref + 300:
            return _iso_from_epoch(deal_ts) or _now_iso_stamp()
        if deal_ts > ref + 300:
            logger.info(
                "broker deal time %.0fs ahead of the VPS clock - clamping "
                "the close stamp to the discovery moment", deal_ts - ref)
    return _now_iso_stamp()


class TickManager:
    def __init__(self, config: Dict[str, Any], telegram=None, database=None):
        self.config = config
        self.telegram = telegram
        self.database = database
        self._extremes: Dict[str, float] = {}
        self._trail = trailing_params(config)
        # BUILD 19 (2026-08-20): per-symbol law cache. The live loop used the
        # BASE (gold) trailing/stop for EVERY row - a live WTI position
        # shipped the gold stop band (270 pts = $2.70 on oil, live
        # 2026-08-20 21:37) and gold trailing 150/40. Each trade is now
        # managed with ITS OWN instrument's laws.
        self._symbol_law_cache: Dict[str, Dict[str, Any]] = {}
        self._partial_alerted: set = set()  # refused-partial reported once/trade
        self._placement_retry_at: Dict[str, float] = {}  # stop 4x/sec refusal/log floods
        self._auction_heartbeat_at = 0.0
        self._auction_prune_at = 0.0
        self._auction_store = None
        self._auction_last_msc = 0
        self._notification_row: Dict[str, Any] | None = None
        # BUILD 22: per-trade last prices so a rich card always reports ITS
        # own symbol's price (a gold card once showed the oil price because
        # _last_price was shared across rows).
        self._last_prices: Dict[str, float] = {}
        auction_cfg = config.get("auction_flow", {}) or {}
        if bool(auction_cfg.get("enabled", False)):
            from services.auction_flow_store import AuctionFlowStore
            self._auction_store = AuctionFlowStore(
                str(auction_cfg.get("storage_path") or "storage/auction_flow.sqlite3")
            )
            try:
                self._auction_store.ensure_writable_attribute()
                # Immediate startup write under the Scheduled Task identity.
                # A permission/ACL problem now fails with a clear traceback
                # instead of a silent stale heartbeat loop.
                self._auction_store.mark_heartbeat()
                self._auction_last_msc = int(
                    (self._auction_store.meta() or {}).get("last_tick_ts_ms", 0) or 0
                )
            except Exception:
                logger.exception("Auction Flow store startup write failed")
                raise
        # Secondary tick collectors for shadow instruments (operator
        # 2026-08-17): each shadow symbol gets ITS OWN suffixed store so the
        # oil auction agent never reads gold ticks. Same loop, no second
        # process; failures here must never break gold execution.
        # BUILD 18 (2026-08-20): the collector now covers EVERY enabled
        # non-base instrument (live WTI/USD and shadow symbols alike). The
        # WTI auction agent reads the suffixed store; while WTI was shadow
        # this loop fed it, and after the build-14 LIVE promotion nothing
        # did - Path 4/5 went silent for oil (auction_state
        # LIVE_TICK_FEED_STALE, 25h-old ticks). One collector, one source.
        self._shadow_ticks: list[tuple[str, Any]] = []
        self._shadow_last_msc: dict[str, int] = {}
        self._aux_selected: set[str] = set()      # symbols subscribed in Market Watch
        self._aux_warned_at: dict[str, float] = {}  # once-per-hour warnings
        try:
            from utils.instruments import enabled_instruments as _en_insts, normalize_symbol as _norm
            from services.auction_flow_store import AuctionFlowStore as _AFS
            from pathlib import Path as _P
            auction_cfg2 = config.get("auction_flow", {}) or {}
            base_path = _P(str(auction_cfg2.get("storage_path") or "storage/auction_flow.sqlite3"))
            _base_sym = _norm(str(config.get("symbol") or "XAU/USD"))
            for _inst in _en_insts(config):
                _sym = _norm(str(_inst.get("symbol") or ""))
                if not _sym or _sym == _base_sym:
                    continue
                _stem = _sym.replace("/", "").lower()
                _spath = base_path.with_name(f"{base_path.stem}_{_stem}{base_path.suffix}")
                _store = _AFS(str(_spath))
                _store.mark_heartbeat()
                self._shadow_ticks.append((_sym, _store))
                self._shadow_last_msc[_sym] = int((_store.meta() or {}).get("last_tick_ts_ms", 0) or 0)
            if self._shadow_ticks:
                logger.info("Aux tick collectors (live + shadow): %s", [t[0] for t in self._shadow_ticks])
        except Exception:
            logger.exception("Aux tick collector init failed (gold unaffected)")
            self._shadow_ticks = []

    def _collect_shadow_ticks(self, mt5, executor, now: float) -> None:
        """Record the latest tick for every non-base instrument's own store
        (live WTI/USD + shadow symbols). Execution paths stay untouched.

        BUILD 18.1: a symbol that is not selected in the terminal's Market
        Watch returns None or a stale/zero-price tick from symbol_info_tick -
        the store then shows a fresh heartbeat with ZERO new rows (exactly the
        VPS symptom). Each aux symbol is therefore selected explicitly, a
        zero-time tick falls back to the wall clock, and the first real tick
        is announced so the log proves the feed.
        """
        for _sym, _store in self._shadow_ticks:
            try:
                broker_symbol = executor._sym(_sym)
                if _sym not in self._aux_selected:
                    try:
                        if hasattr(mt5, "symbol_select"):
                            mt5.symbol_select(broker_symbol, True)
                        self._aux_selected.add(_sym)
                    except Exception:  # noqa: BLE001
                        pass  # selection is best-effort; the tick read decides
                tick = mt5.symbol_info_tick(broker_symbol)
                if tick is None:
                    if now - self._aux_warned_at.get(_sym, 0.0) >= 3600.0:
                        self._aux_warned_at[_sym] = now
                        logger.warning(
                            "aux tick unavailable for %s (%s) - symbol not in "
                            "Market Watch?", _sym, broker_symbol)
                    continue
                msc = int(getattr(tick, "time_msc", 0) or 0)
                if msc <= 0:
                    # Broker gave no timestamp (non-subscribed symbols do this):
                    # use the wall clock so a real quote still records.
                    msc = int(time.time() * 1000)
                if msc >= self._shadow_last_msc.get(_sym, 0):
                    if _store.record_tick(tick):
                        if not self._shadow_last_msc.get(_sym):
                            logger.info("aux live tick feed started for %s (%s)",
                                        _sym, broker_symbol)
                        self._shadow_last_msc[_sym] = msc
                if now - getattr(self, "_shadow_hb_at", 0.0) >= 5.0:
                    _store.mark_heartbeat()
            except Exception:  # noqa: BLE001 - aux feed must not break gold
                logger.debug("aux tick collect failed for %s", _sym)
        if now - getattr(self, "_shadow_hb_at", 0.0) >= 5.0:
            self._shadow_hb_at = now

    def _collect_auction_tick(self, mt5, executor, now: float) -> None:
        """Collect the broker tick book even when no trade is open.

        The same scheduled Tick Manager owns both execution management and the
        Auction Flow feed. No second loop/process is permitted.
        """
        if self._auction_store is None:
            return
        symbol = str(self.config.get("symbol") or "XAU/USD")
        broker_symbol = executor._sym(symbol)
        newest = self._auction_last_msc
        loaded = 0
        if self._auction_last_msc > 0 and hasattr(mt5, "copy_ticks_from"):
            try:
                start = datetime.fromtimestamp(
                    self._auction_last_msc / 1000.0, tz=timezone.utc
                )
                batch = mt5.copy_ticks_from(
                    broker_symbol, start, 5000,
                    getattr(mt5, "COPY_TICKS_ALL", 0),
                )
                if batch is not None:
                    fresh = [
                        tick for tick in batch
                        if int(tick["time_msc"] or 0) > self._auction_last_msc
                    ]
                    if fresh:
                        loaded = self._auction_store.bulk_record_ticks(fresh)
                        newest = max(int(tick["time_msc"] or 0) for tick in fresh)
            except Exception as exc:  # noqa: BLE001
                logger.debug("auction incremental tick copy failed: %s", exc)
        if loaded == 0:
            tick = mt5.symbol_info_tick(broker_symbol)
            if tick is not None and int(getattr(tick, "time_msc", 0) or 0) >= self._auction_last_msc:
                if self._auction_store.record_tick(tick):
                    newest = int(getattr(tick, "time_msc", 0) or newest)
        self._auction_last_msc = max(self._auction_last_msc, newest)
        if now - self._auction_heartbeat_at >= 5.0:
            self._auction_store.mark_heartbeat()
            self._auction_heartbeat_at = now
        if now - self._auction_prune_at >= 3600.0:
            auction_cfg = self.config.get("auction_flow", {}) or {}
            self._auction_store.prune(
                second_days=int(auction_cfg.get("second_retention_days", 7) or 7),
                minute_days=int(auction_cfg.get("minute_retention_days", 90) or 90),
            )
            self._auction_prune_at = now

    @staticmethod
    def _write_heartbeat(path: str = "tick_heartbeat.json") -> None:
        """Atomically publish a valid heartbeat; never expose an empty file."""
        tmp = f"{path}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"ts": datetime.now(timezone.utc).isoformat()}, fh)
            fh.flush()
            os.fsync(fh.fileno())
        try:
            os.replace(tmp, path)
        except PermissionError:
            # Windows reader lock; heartbeat is periodic — next beat rewrites.
            try:
                os.unlink(tmp)
            except OSError:
                pass

    def _placement_due(self, trade_id: str) -> bool:
        """Retry broker refusals every 5s, not four times per second."""
        now = time.monotonic()
        if now < self._placement_retry_at.get(trade_id, 0.0):
            return False
        self._placement_retry_at[trade_id] = now + 5.0
        return True

    def _flip_dependencies_open(self, row: Dict[str, Any], executor) -> List[str]:
        """Broker positions that must close before this opposite entry."""
        if not row.get("opposite_exit_required"):
            return []
        alive: List[str] = []
        for tid in row.get("opposite_trade_ids") or []:
            if executor._position_by_magic(magic_for(str(tid))) is not None:
                alive.append(str(tid))
        if not alive:
            updates = {"opposite_exit_required": False,
                       "opposite_exit_completed": True}
            self.database.update_trade(str(row.get("id")), updates)
            row.update(updates)
        return alive

    def _send_execution_signal(
        self, row: Dict[str, Any], *, actual_entry: float | None = None,
        actual_stop: float | None = None,
    ) -> None:  # pragma: no cover - VPS/Telegram integration
        """Deliver the rich signal only after an MT5 position/order exists.

        New demo rows carry ``telegram_signal_sent=False``. Old rows omit the
        field and are deliberately not re-announced during deployment.
        """
        if row.get("telegram_signal_sent") is not False or not self.telegram:
            return
        decision = deepcopy(row.get("signal_snapshot") or {})
        if not isinstance(decision, dict) or not decision:
            logger.error("cannot send execution signal for %s: no snapshot", row.get("id"))
            return
        decision["trade_id"] = str(row.get("id") or decision.get("trade_id") or "")
        signal = decision.setdefault("signal", {})
        if actual_entry and actual_entry > 0:
            entry = signal.setdefault("entry", {})
            entry["price"] = round(float(actual_entry), 2)
            decision["current_price"] = round(float(actual_entry), 2)
        if actual_stop and actual_stop > 0:
            signal["stop_loss"] = round(float(actual_stop), 2)
        custom = decision.get("_telegram_pending_message")
        try:
            sent = bool(
                self.telegram.send_message(str(custom), urgent=True)
                if custom else self.telegram.send_signal(decision)
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("execution signal delivery crashed for %s: %s", row.get("id"), exc)
            return
        if not sent:
            logger.warning("execution signal delivery returned False for %s; retrying", row.get("id"))
            return
        sent_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        updates = {"telegram_signal_sent": True,
                   "telegram_signal_sent_at": sent_at}
        self.database.update_trade(str(row.get("id")), updates)
        row.update(updates)  # cached row must not resend before the 3s refresh

    def _normalize_execution_stop(self, row, pos, executor, side: str) -> float:
        """Broker-first enforcement of the 270..400 initial stop law."""
        self._notification_row = row if isinstance(row, dict) else None
        current = float(row.get("stop_loss") or getattr(pos, "sl", 0) or 0)
        # New rows carry the flag; legacy live rows are eligible only when their
        # signal snapshot proves the original planned entry/stop.
        snapshot = row.get("signal_snapshot") or {}
        if isinstance(snapshot, str):
            try:
                snapshot = json.loads(snapshot)
            except Exception:
                snapshot = {}
        signal = (snapshot.get("signal") or {}) if isinstance(snapshot, dict) else {}
        eligible = row.get("execution_stop_normalized") is False or bool(signal)
        protected = bool(row.get("sl_moved_to_entry") or row.get("partial_close"))
        if not eligible or protected:
            return current
        planned_entry = float(((signal.get("entry") or {}).get("price"))
                              or row.get("entry_price") or 0)
        planned_stop = float(signal.get("stop_loss") or row.get("initial_stop_loss")
                             or current or 0)
        rule = self._per_symbol_laws(row)["stop"]
        corrected, required_pts, actual_pts = corrected_execution_stop(
            side, float(getattr(pos, "price_open", 0) or row.get("entry_price") or 0),
            current, planned_entry, planned_stop,
            min_liquidity_points=float(rule["min_liquidity_points"]),
            safety_buffer_points=float(rule["safety_buffer_points"]),
            cap_points=float(rule["max_stop_points"]),
            point_value=point_size(row.get("symbol") or "XAU/USD", self.config),
        )
        tid = str(row.get("id"))
        if corrected is None:
            updates = {"execution_stop_normalized": True,
                       "execution_stop_points": actual_pts}
            self.database.update_trade(tid, updates)
            row.update(updates)
            return current
        if executor.apply_stop(tid, corrected, float(row.get("tp2") or 0),
                               row.get("symbol")):
            updates = {
                "stop_loss": corrected, "initial_stop_loss": corrected,
                "execution_stop_normalized": True,
                "execution_stop_points": required_pts,
            }
            self.database.update_trade(tid, updates)
            row.update(updates)
            self._notify(
                f"🧪 DEMO: MT5 applied: execution stop corrected from "
                f"{current:.2f} ({actual_pts:.1f} pts) to {corrected:.2f} "
                f"({required_pts:.1f} pts; liquidity law)")
            return corrected
        return current  # broker refusal: DB untouched, retry on the next tick

    def _per_symbol_laws(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """BUILD 19: the stop/trailing/breakeven laws for THIS trade's symbol.

        The tick manager is constructed with the base (gold) config. A WTI
        row must be managed with the WTI instrument profile (stop band
        60/21/120, trailing 70/25, breakeven +70) instead of the gold values
        the base config carries. config_for_instrument merges the per-symbol
        DEFAULT_INSTRUMENTS profile into the base config; the result is
        cached per symbol so the hot loop never re-merges.
        """
        symbol = normalize_symbol(str(row.get("symbol") or self.config.get("symbol") or "XAU/USD"))
        laws = self._symbol_law_cache.get(symbol)
        if laws is not None:
            return laws
        try:
            if symbol == normalize_symbol(str(self.config.get("symbol") or "XAU/USD")):
                cfg = self.config
            else:
                cfg = config_for_instrument(self.config, {"symbol": symbol})
            laws = {"trailing": trailing_params(cfg), "stop": stop_rule(cfg)}
        except Exception:  # noqa: BLE001 - fall back to the old base behaviour
            laws = {"trailing": self._trail, "stop": stop_rule(self.config)}
        self._symbol_law_cache[symbol] = laws
        return laws

    def _seed_extreme(self, executor, row: Dict[str, Any], pos, side: str) -> float:
        """Restart-lossless extreme: seed from the broker's M1 candles since
        the position opened (operator directive 2026-08-10: the trailing must
        respect the highest price reached, including gaps while we were down).
        """
        from services.mt5_executor import _mt5_ready
        mt5 = _mt5_ready()
        sym = executor._sym(str(row.get("symbol") or "XAU/USD"))
        seed = float(row.get("entry_price") or 0)
        try:
            open_time = int(getattr(pos, "time", 0) or 0)
            if open_time > 0:
                rates = mt5.copy_rates_range(
                    sym, getattr(mt5, "TIMEFRAME_M1", 1),
                    open_time, int(time.time()))
                if rates is not None and len(rates):
                    if side == "BUY":
                        seed = max(float(r["high"]) for r in rates)
                    else:
                        seed = min(float(r["low"]) for r in rates)
        except Exception as exc:  # noqa: BLE001
            logger.warning("extreme seeding failed (%s); using entry", exc)
        return seed

    def _pending_stale(self, row: Dict[str, Any], tick) -> bool:
        """Demo mirror of the paper pending_freshness rules (config-driven):
        cancel when older than stale_after_hours, OR the thesis is dead
        (plan invalidation breached), OR - only when the operator re-enables
        the legacy rule - when price ran away stale_after_excursion_points.

        2026-08-19 (build 12, operator order): the arbitrary excursion kill
        is OFF by default. A $25 drift used to cancel a pending whose thesis
        was intact and whose price later returned. The market-based kill is
        now ONLY the plan invalidation breach.
        """
        pf = (self.config.get("pending_freshness") or {})
        if not pf.get("enabled", True):
            return False
        from datetime import datetime, timezone
        raw = str(row.get("created_at") or "")
        try:
            created = datetime.fromisoformat(raw.replace("Z", "+00:00"))
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            age_h = (datetime.now(timezone.utc) - created).total_seconds() / 3600.0
        except Exception:  # noqa: BLE001
            return False
        if age_h >= float(pf.get("stale_after_hours", 6)):
            return True
        side = str(row.get("type") or row.get("side") or "").upper()
        price = float(getattr(tick, "bid" if side == "BUY" else "ask", 0.0) or 0.0)
        entry = float(row.get("entry_price") or 0)
        if entry <= 0 or price <= 0:
            return False
        # thesis-death kill (operator order): plan invalidation breached
        if bool(pf.get("invalidation_kill_enabled", True)):
            inv = row.get("invalidation_level")
            if not isinstance(inv, (int, float)):
                snap = row.get("signal_snapshot") or {}
                plan = snap.get("session_plan") if isinstance(snap, dict) else None
                inv = (plan or {}).get("invalidation_level") if isinstance(plan, dict) else None
            if isinstance(inv, (int, float)) and float(inv) > 0:
                if side == "BUY" and price < float(inv):
                    return True
                if side == "SELL" and price > float(inv):
                    return True
        # legacy excursion rule - OFF unless the operator re-enables it
        if bool(pf.get("excursion_kill_enabled", False)):
            excursion = (price - entry) if side == "BUY" else (entry - price)
            return excursion >= float(pf.get("stale_after_excursion_points", 250)) * 0.10
        return False


    def _reconcile_pending(self, rows, executor) -> None:  # pragma: no cover
        """Broker pending orders whose DB row is gone (cancelled/replaced)
        must be cancelled at the broker too — otherwise ghost fills."""
        active = {magic_for(str(r.get("id"))) for r in rows}
        for o in executor.open_orders():
            mg = getattr(o, "magic", None)
            if mg is not None and mg not in active:
                if executor.cancel_order(int(o.ticket)):
                    self._notification_row = None
                    self._notify(
                        f"🧪 DEMO: stale pending #{int(o.ticket)} cancelled "
                        f"at broker (row no longer active)")

    def _reconcile_opposite_exposure(self, rows, executor) -> None:  # pragma: no cover - broker integration
        """Repair legacy BUY+SELL overlap: newest side survives, older exits."""
        groups: Dict[str, List[tuple[Dict[str, Any], Any, float]]] = {}
        for row in rows or []:
            if str(row.get("status") or "").upper() not in {"OPEN", "PARTIAL", "TP1_HIT"}:
                continue
            side = str(row.get("type") or row.get("side") or "").upper()
            if side not in {"BUY", "SELL"}:
                continue
            pos = executor._position_by_magic(magic_for(str(row.get("id"))))
            if pos is None:
                continue
            opened = float(getattr(pos, "time", 0) or 0)
            if opened <= 0:
                try:
                    opened = datetime.fromisoformat(
                        str(row.get("entry_time") or row.get("created_at") or "").replace("Z", "+00:00")
                    ).timestamp()
                except Exception:
                    opened = 0.0
            symbol = str(row.get("symbol") or "XAU/USD").upper()
            groups.setdefault(symbol, []).append((row, pos, opened))

        for symbol, items in groups.items():
            sides = {str(r.get("type") or r.get("side") or "").upper() for r, _, _ in items}
            if len(sides) < 2:
                continue
            newest = max(
                items,
                key=lambda item: (item[2], int(getattr(item[1], "ticket", 0) or 0)),
            )
            newest_side = str(newest[0].get("type") or newest[0].get("side") or "").upper()
            for row, _pos, _opened in items:
                side = str(row.get("type") or row.get("side") or "").upper()
                if side == newest_side:
                    continue
                tid = str(row.get("id"))
                if not executor.close_position(tid, row.get("symbol")):
                    continue
                lc = executor.last_close
                entry = float(row.get("entry_price") or 0)
                # BUILD 22.2: points in the ROW's symbol scale (oil = $0.01,
                # gold = $0.10). The hardcoded *10 printed "-12 pts" for a
                # -120-point oil close.
                pv = point_size(str(row.get("symbol") or "XAU/USD"), self.config)
                pnl = (float(lc.get("price") or 0) - entry) / pv
                if side == "SELL":
                    pnl = -pnl
                updates = {
                    "status": "THESIS_EXIT", "requested_exit": False,
                    "requested_exit_reason": "OPPOSITE_ENTRY_RECONCILIATION",
                    "close_price": lc.get("price"), "pnl_points": round(pnl, 1),
                    "reasons": [f"Closed older {side} because newer {newest_side} exposure exists"],
                }
                self.database.update_trade(tid, updates)
                row.update(updates)
                self._notification_row = row
                self._notify(
                    f"🧪 DEMO: MT5 applied: legacy opposite-exposure guard "
                    f"closed older {side} @ {float(lc.get('price') or 0):.2f} · "
                    f"kept newer {newest_side} · ticket {lc.get('ticket')}")

    def _magic_rows(self) -> List[Dict[str, Any]]:
        rows = self.database.get_open_trades() or []
        return [r for r in rows if str(r.get("status") or "") in
                {"PENDING", "OPEN", "TP1_HIT", "PARTIAL"}]

    def run_forever(self) -> None:  # pragma: no cover - VPS only
        from services.mt5_executor import Mt5DemoExecutor, magic_for, _mt5_ready
        mt5 = _mt5_ready()  # initialize ONCE — the terminal must be attached
        executor = Mt5DemoExecutor(self.config, telegram=self.telegram)
        # DB rows are throttled (Supabase free-tier protection — live incident:
        # usage-limit badge): ticks stay 0.25s via symbol_info_tick, while the
        # trade BOOK refreshes every ROWS_REFRESH_SECONDS. Row state changes
        # (new signal / status flip) are rare; 3s staleness is invisible.
        rows: List[Dict[str, Any]] = []
        rows_at = 0.0
        beat_at = 0.0
        while True:
            try:
                now = time.time()
                # Always feed Auction Flow first. The old loop requested a tick
                # only inside `for row in rows`, so a flat book meant no flow
                # data at all. This call is independent of open positions.
                self._collect_auction_tick(mt5, executor, now)
                self._collect_shadow_ticks(mt5, executor, now)
                if now - rows_at >= ROWS_REFRESH_SECONDS:
                    rows = self._magic_rows()
                    rows_at = now
                    self._reconcile_opposite_exposure(rows, executor)
                    self._reconcile_pending(rows, executor)
                if now - beat_at >= 30:
                    try:
                        self._write_heartbeat()
                    except Exception as exc:  # noqa: BLE001
                        logger.warning("tick heartbeat write failed: %s", exc)
                    finally:
                        # Do not hammer the disk four times/second on failure.
                        beat_at = now
                for row in rows:
                    # Route through the broker symbol map (XAU/USD -> XAUUSD.s);
                    # a raw slash-strip goes blind on suffix brokers.
                    sym = executor._sym(str(row.get("symbol") or "XAU/USD"))
                    tick = mt5.symbol_info_tick(sym)
                    if tick is None:
                        continue
                    self._handle_row(row, tick, executor, mt5)
            except Exception as exc:  # noqa: BLE001 - loop must survive
                logger.warning("tick cycle error: %s", exc)
            time.sleep(LOOP_SLEEP)

    def _handle_row(self, row, tick, executor, mt5) -> None:  # pragma: no cover
        self._notification_row = row if isinstance(row, dict) else None
        tid = str(row.get("id"))
        side = str(row.get("type") or row.get("side") or "").upper()
        magic = magic_for(tid)
        pos = executor._position_by_magic(magic)
        status = str(row.get("status") or "")
        if status not in {"PENDING", "OPEN", "TP1_HIT", "PARTIAL"}:
            return  # cached row was closed/cancelled before the next DB refresh
        if pos is None and row.get("close_price") is not None:
            return  # exit already booked; never manage/resurrect a closed row
        if pos is None and self._flip_dependencies_open(row, executor):
            return  # old opposite MT5 position must close broker-first

        if status == "PENDING":
            if row.get("requested_exit"):
                _now_iso2 = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
                cancel_updates = {"status": "CANCELLED", "result": "CANCELLED",
                                  "requested_exit": False,
                                  "cancel_reason_code": "THESIS_EXIT_BEFORE_ACTIVATION",
                                  "cancel_reason": "thesis exit before activation",
                                  "reasons": ["thesis exit before activation"],
                                  "closed_at": _now_iso2, "close_time": _now_iso2}
                self.database.update_trade(tid, cancel_updates)
                row.update(cancel_updates)
                return
            if self._pending_stale(row, tick):
                # Stale pending (age / invalidation breach / legacy excursion):
                # cancel in the DB; _reconcile_pending cancels the broker order
                # and cards it. If it was never placed, card here instead.
                had_ticket = bool(row.get("mt5_ticket"))
                _now_iso = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
                stale_updates = {"status": "CANCELLED", "result": "CANCELLED",
                                 "cancel_reason_code": "TICK_STALE_RUNAWAY",
                                 "cancel_reason": "stale pending (freshness mirror)",
                                 "reasons": ["stale pending (freshness mirror)"],
                                 "closed_at": _now_iso, "close_time": _now_iso}
                self.database.update_trade(tid, stale_updates)
                row.update(stale_updates)
                if not had_ticket:
                    self._notify(
                        f"🧪 DEMO: MT5 applied: stale pending cancelled "
                        f"(age/excursion) — never placed")
                return
            if pos is not None:  # broker filled the pending
                # Book the ACTUAL fill price: PnL/BE/trailing must run on the
                # broker's execution, not our planned level.
                fill_updates = {"status": "OPEN",
                                "entry_price": round(float(pos.price_open), 2),
                                "mt5_ticket": int(pos.ticket)}
                self.database.update_trade(tid, fill_updates)
                row.update(fill_updates)
                actual_stop = self._normalize_execution_stop(row, pos, executor, side)
                self._send_execution_signal(
                    row, actual_entry=float(pos.price_open), actual_stop=actual_stop)
                self._notify(
                    f"🧪 DEMO: MT5 applied: pending filled @ "
                    f"{pos.price_open:.2f} · ticket {int(pos.ticket)} "
                    f"(actual fill)")
            elif not row.get("mt5_ticket"):
                # The pending order has never been sent to MT5 — send it now.
                # ensure_ticket is idempotent (position + outstanding order).
                if not self._placement_due(tid):
                    return
                kind = str(row.get("order_type") or "").upper()
                if not kind.endswith("LIMIT"):
                    kind = "BUY_LIMIT" if side == "BUY" else "SELL_LIMIT"
                ticket = executor.ensure_ticket(
                    tid, side, kind, float(row.get("entry_price") or 0),
                    float(row.get("stop_loss") or 0),
                    float(row.get("tp2") or 0), row.get("symbol"))
                if ticket:
                    self._placement_retry_at.pop(tid, None)
                    updates = {"mt5_ticket": ticket}
                    self.database.update_trade(tid, updates)
                    row.update(updates)
                    lo = executor.last_order
                    self._send_execution_signal(row)
                    if not lo.get("existing"):
                        self._notify(
                            f"🧪 DEMO: MT5 applied: {lo.get('kind', 'LIMIT')} "
                            f"order placed · vol {lo.get('volume')} @ "
                            f"{lo.get('price', float(row.get('entry_price') or 0)):.2f} "
                            f"· ticket {ticket}")
                    else:
                        logger.info("repaired missing DB ticket for existing pending %s -> %s",
                                    tid, ticket)
            # If Telegram was unavailable after broker placement, retry the
            # rich card on later ticks without touching the existing order.
            if row.get("mt5_ticket"):
                self._send_execution_signal(row)
            return
        if pos is None:
            # Never-placed OPEN rows (no ticket, no close) are ALWAYS
            # placement-eligible whatever their age — the card already went
            # to Telegram; silently starving them (old 60-min gate) is the
            # "card but no MT5 order" gap. Resurrection protection applies
            # only to rows that already have a close/ticket history.
            never_placed = (not row.get("mt5_ticket")) and \
                row.get("close_price") is None
            eligible = (status == "PENDING") or \
                (status == "OPEN" and (never_placed or _row_fresh(row)))
            if (not row.get("mt5_ticket")) and eligible:
                # PENDING rows stay placement-eligible for their whole life
                # (paper keeps pendings alive for hours; staleness cancella-
                # tion happens in the DB and _reconcile_pending mirrors it at
                # the broker). OPEN rows only while fresh — finished or stale
                # rows must NEVER be resurrected into new orders.
                if not self._placement_due(tid):
                    return
                ticket = executor.ensure_ticket(
                    tid, side, "MARKET", 0.0,
                    float(row.get("stop_loss") or 0),
                    float(row.get("tp2") or 0), row.get("symbol"))
                if ticket:
                    self._placement_retry_at.pop(tid, None)
                    pos2 = executor._position_by_magic(magic)
                    upd: Dict[str, Any] = {"mt5_ticket": ticket}
                    if pos2 is not None:
                        upd["entry_price"] = round(float(pos2.price_open), 2)
                        upd["mt5_ticket"] = int(pos2.ticket)
                    elif float((executor.last_order or {}).get("price") or 0) > 0:
                        upd["entry_price"] = round(float(executor.last_order["price"]), 2)
                    self.database.update_trade(tid, upd)
                    row.update(upd)
                    actual_entry = float(upd.get("entry_price") or 0)
                    actual_stop = float(row.get("stop_loss") or 0)
                    if pos2 is not None:
                        actual_stop = self._normalize_execution_stop(
                            row, pos2, executor, side)
                        self._send_execution_signal(
                            row, actual_entry=actual_entry or None,
                            actual_stop=actual_stop or None)
                    # If positions_get needs another terminal tick, defer the
                    # rich card until the position exists and its stop is legal.
                    if not (executor.last_order or {}).get("existing"):
                        if actual_entry:
                            self._notify(
                                f"🧪 DEMO: MT5 applied: MARKET filled · vol "
                                f"{executor.lot} @ {actual_entry:.2f} · "
                                f"ticket {upd['mt5_ticket']}")
                        else:
                            self._notify(
                                f"🧪 DEMO: MT5 applied: MARKET order sent · "
                                f"ticket {ticket}")
                    else:
                        logger.info("repaired missing DB ticket for existing position %s -> %s",
                                    tid, upd["mt5_ticket"])
                return
            # broker closed it (SL / TP2 / trailing stop)
            # Mirror the REAL broker exit: deal price + realized P&L, not
            # the live tick at the moment we noticed the position was gone.
            exit_info = executor.last_exit(tid)
            entry = float(row.get("entry_price") or 0)
            stop = float(row.get("stop_loss") or 0)
            tp2 = float(row.get("tp2") or 0)
            if exit_info and exit_info["price"] > 0:
                close = exit_info["price"]
                status = classify_broker_exit(side, close, entry, stop, tp2)
                # BUILD 22.2: points in the ROW's symbol scale. The hardcoded
                # *10 printed "-12 pts / -120.00$" for an oil close that was
                # actually -120 pts (the $ side comes from the broker deal).
                _pv_close = point_size(str(row.get("symbol") or "XAU/USD"), self.config)
                pnl_pts = (close - entry) / _pv_close
                if side == "SELL":
                    pnl_pts = -pnl_pts
                # BUILD 22: stamp the REAL close (broker deal time) so every
                # post-exit guard measures from the exit, not from the open.
                _closed = _close_stamp(exit_info)
                close_updates = {"status": status, "close_price": round(close, 2),
                                 "pnl_points": round(pnl_pts, 1),
                                 "closed_at": _closed, "close_time": _closed}
                self.database.update_trade(tid, close_updates)
                row.update(close_updates)
                self._notify(
                    f"🧪 DEMO: MT5 applied: position closed @ {close:.2f} "
                    f"({status}) · vol {exit_info.get('volume')} · "
                    f"ticket {exit_info.get('position')} "
                    f"{pnl_pts:+.0f} pts / {exit_info['profit']:+.2f}$")
            else:
                keep = status if status in {"TP1_HIT", "PARTIAL"} else "SL_HIT"
                close = tick.bid if side == "BUY" else tick.ask
                _closed = _now_iso_stamp()
                fallback_updates = {"status": keep, "close_price": round(close, 2),
                                    "closed_at": _closed, "close_time": _closed}
                self.database.update_trade(tid, fallback_updates)
                row.update(fallback_updates)
                self._notify(
                    f"🧪 DEMO: position closed by broker @ {close:.2f} "
                    f"(no exit deal found — labelled {keep}, verify)")
            return

        # A market DEAL can be accepted one terminal tick before positions_get
        # exposes it. Reconcile the broker's actual fill on every sight instead
        # of leaving the planned Telegram quote in the book forever.
        actual_entry = round(float(getattr(pos, "price_open", 0.0) or 0.0), 2)
        actual_ticket = int(getattr(pos, "ticket", 0) or 0)
        mirror_updates: Dict[str, Any] = {}
        may_reconcile_entry = bool(row.get("mt5_ticket")) or \
            row.get("telegram_signal_sent") is False
        if (may_reconcile_entry and actual_entry > 0
                and abs(actual_entry - float(row.get("entry_price") or 0)) > 0.01):
            mirror_updates["entry_price"] = actual_entry
        may_reconcile_ticket = bool(row.get("mt5_ticket")) or \
            row.get("telegram_signal_sent") is False
        if (may_reconcile_ticket and actual_ticket
                and int(row.get("mt5_ticket") or 0) != actual_ticket):
            mirror_updates["mt5_ticket"] = actual_ticket
        if mirror_updates:
            self.database.update_trade(tid, mirror_updates)
            row.update(mirror_updates)
            logger.info("reconciled broker fill for %s: %s", tid, mirror_updates)
        actual_stop = self._normalize_execution_stop(row, pos, executor, side)
        self._send_execution_signal(
            row, actual_entry=actual_entry or None,
            actual_stop=actual_stop or None)

        # thesis-exit handoff: analysis requested, broker executes first.
        if row.get("requested_exit"):
            if pos is None:
                self.database.update_trade(tid, {"requested_exit": False})
            elif executor.close_position(tid, row.get("symbol")):
                lc = executor.last_close
                _pv_thesis = point_size(str(row.get("symbol") or "XAU/USD"), self.config)
                pnl = (lc["price"] - float(row.get("entry_price") or 0)) / _pv_thesis
                if side == "SELL":
                    pnl = -pnl
                exit_reason = str(row.get("requested_exit_reason") or "THESIS_EXIT")
                _closed = _now_iso_stamp()
                thesis_updates = {"status": "THESIS_EXIT", "requested_exit": False,
                                  "requested_exit_reason": exit_reason,
                                  "close_price": lc["price"],
                                  "pnl_points": round(pnl, 1),
                                  "closed_at": _closed, "close_time": _closed,
                                  "reasons": [exit_reason]}
                self.database.update_trade(tid, thesis_updates)
                row.update(thesis_updates)
                label = ("opposite-entry flip exit" if exit_reason == "OPPOSITE_ENTRY_FLIP"
                         else "entry-grade thesis exit")
                self._notify(
                    f"🧪 DEMO: MT5 applied: {label} closed @ "
                    f"{lc['price']:.2f} · vol {lc['volume']} · "
                    f"ticket {lc['ticket']} · {pnl:+.0f} pts")
            return
        if row.get("requested_partial") and pos is not None \
                and not row.get("partial_close"):
            if executor.partial_close_at_tp1(tid, 0.5, row.get("symbol")):
                lp = executor.last_partial
                scale_updates = {"requested_partial": False,
                                 "partial_close": True, "status": "PARTIAL"}
                self.database.update_trade(tid, scale_updates)
                row.update(scale_updates)
                if not lp.get("existing"):
                    self._notify(
                        f"🧪 DEMO: MT5 applied: thesis scale-out closed · vol "
                        f"{lp.get('volume')} @ {lp.get('price', 0):.2f} · "
                        f"remaining {lp.get('remaining')} · ticket "
                        f"{lp.get('ticket')}")

        entry = float(row.get("entry_price") or 0)
        stop = float(row.get("stop_loss") or 0)
        tp1 = float(row.get("tp1") or 0)
        risk = abs(entry - float(row.get("initial_stop_loss") or stop))
        # BUILD 19: per-symbol laws + per-symbol point value (oil = $0.01,
        # gold = $0.10). The hardcoded gold pv broke every oil distance math
        # in the live loop.
        _laws = self._per_symbol_laws(row)
        _trail = _laws["trailing"]
        pv = point_size(str(row.get("symbol") or "XAU/USD"), self.config)
        risk_points = risk / pv  # price delta -> codebase points
        # Use the price at which the position can actually be closed:
        # BUY closes on Bid; SELL closes on Ask. This keeps BE/TP1/trailing
        # aligned with MT5 rather than triggering one spread too early.
        price = tick.bid if side == "BUY" else tick.ask
        try:
            self._last_price = float(price or 0.0)
            self._last_prices[str(row.get("id") or "")] = float(price or 0.0)
        except (TypeError, ValueError):  # noqa: BLE001
            pass
        if tid not in self._extremes:
            # first sight (fresh start/restart): seed from broker history so
            # peaks hit while we were down still ratchet the stop.
            self._extremes[tid] = self._seed_extreme(executor, row, pos, side)
        extreme = self._extremes[tid]
        extreme = max(extreme, price) if side == "BUY" else min(extreme, price)
        self._extremes[tid] = extreme

        # 0) SL drift guard: a manually/broker-moved stop that is WORSE than
        # the book's level is restored every tick (operator directive).
        broker_sl = float(getattr(pos, "sl", 0) or 0)
        db_stop = float(row.get("stop_loss") or 0)
        tp2 = float(row.get("tp2") or 0)
        if broker_sl > 0 and db_stop > 0 and abs(broker_sl - db_stop) > 0.5:
            worse = (broker_sl < db_stop) if side == "BUY" else \
                (broker_sl > db_stop)
            if worse and executor.apply_stop(tid, db_stop, tp2,
                                             row.get("symbol")):
                self._notify(
                    f"🧪 DEMO: MT5 applied: SL drift corrected back to "
                    f"{db_stop:.2f} (broker had {broker_sl:.2f})")

        # 1) breakeven
        if decide_be(side, entry, price, risk_points,
                     _trail["early_breakeven_points"], 0.5,
                     bool(row.get("sl_moved_to_entry"))):
            # Move FIRST at the broker; the card is sent ONLY when the
            # broker confirms. On refusal nothing is booked, so the next
            # tick retries (operator directive: truthful messages only).
            if executor.apply_stop(tid, entry, float(row.get("tp2") or 0),
                                   row.get("symbol")):
                be_updates = {"sl_moved_to_entry": True, "stop_loss": entry}
                self.database.update_trade(tid, be_updates)
                row.update(be_updates)
                stop = entry
                self._notify(f"🧪 DEMO: breakeven armed @ {entry:.2f} "
                             f"(confirmed at broker)")

        # 2) TP1 partial — close ONLY the half (operator directive). Book it
        # only when the broker actually executed it. On refusal: keep
        # retrying every tick and report the broker's reason once per trade.
        # decide_tp1 expects candle low/high. On a live tick the executable
        # BUY high is Bid and the executable SELL low is Ask.
        if decide_tp1(side, tp1, tick.ask, tick.bid,
                      bool(row.get("partial_close"))):
            if executor.partial_close_at_tp1(tid, 0.5, row.get("symbol")):
                self._partial_alerted.discard(tid)
                partial_updates = {"partial_close": True,
                                   "status": "TP1_HIT"}
                self.database.update_trade(tid, partial_updates)
                row.update(partial_updates)
                lp = executor.last_partial
                if not lp.get("existing"):
                    self._notify(
                        f"🧪 DEMO: MT5 applied: TP1 partial closed · vol "
                        f"{lp.get('volume')} @ {lp.get('price', tp1):.2f} · "
                        f"remaining {lp.get('remaining')} · ticket "
                        f"{lp.get('ticket')}")
                else:
                    logger.info("restored TP1 mirror from broker history for %s", tid)
            elif tid not in self._partial_alerted:
                self._partial_alerted.add(tid)
                self._notify(
                    f"🧪 DEMO: TP1 partial REJECTED for {tid}: "
                    f"{getattr(executor, 'last_error', 'unknown')} — "
                    f"retrying every tick")

        # 3) trailing ratchet
        new_stop = decide_trailing(side, entry, stop, extreme,
                                   _trail["distance_points"],
                                   _trail["step_points"], pv)
        if new_stop:
            if executor.apply_stop(tid, new_stop, float(row.get("tp2") or 0),
                                   row.get("symbol")):
                self.database.update_trade(tid, {"stop_loss": new_stop})
                row["stop_loss"] = new_stop
                self._notify(f"🧪 DEMO: trailing stop moved to {new_stop:.2f} "
                             f"(confirmed at broker)")
            # refusal: apply_stop logged the retcode; DB untouched -> retried

    def _notify(self, text: str, row: Dict[str, Any] | None = None) -> None:  # pragma: no cover
        """Send a broker lifecycle card with admission path on line one.

        BUILD 16 (2026-08-20): management events now ride the unified rich
        card builder (send_trade_events) so a trailing move / breakeven arm /
        protected close looks exactly like the 5-minute-cycle cards the
        operator approved. Only events we can map to a real trade event are
        upgraded; informational lines (drift corrections, retry notes) stay
        plain so no card ever claims a state the broker did not confirm.
        """
        context = row if isinstance(row, dict) and row else self._notification_row
        if (self.telegram and isinstance(context, dict) and context
                and hasattr(self.telegram, "send_trade_events")):
            parsed = self._rich_card_payload(text, context)
            if parsed:
                event, updates, new_status, pnl = parsed
                evaluation = {
                    "old_status": str(context.get("status") or "OPEN").upper(),
                    "new_status": new_status or str(context.get("status") or "OPEN").upper(),
                    "updates": updates,
                    "pnl_points": pnl,
                    "cancel_reason_code": str(context.get("cancel_reason_code") or ""),
                    "reasons": context.get("reasons") or [],
                }
                try:
                    _card_price = self._last_prices.get(
                        str(context.get("id") or ""),
                        getattr(self, "_last_price", 0.0) or 0.0)
                    sent = bool(self.telegram.send_trade_events(
                        context, [event], _card_price, pnl, evaluation,
                    ))
                    if sent:
                        logger.info("[card] %s", text)
                        return
                except Exception:  # noqa: BLE001
                    pass  # fall through to the plain card
        header = (
            path_header(context)
            if isinstance(context, dict) and context
            else "🛣️ <b>NO EXECUTION PATH — BROKER RECONCILIATION</b>"
        )
        body = str(text or "")
        if not body.lstrip().startswith("🛣️"):
            body = f"{header}\n{body}"
        logger.info("[card] %s", body)  # visibility: cards hit the log too
        if self.telegram:
            try:
                self.telegram.send_message(body)
            except Exception:  # noqa: BLE001
                pass

    @staticmethod
    def _rich_card_payload(text: str, row: Dict[str, Any]) -> Any:
        """Map a tick-manager lifecycle line to (event, updates, new_status, pnl).

        Returns None when the line is informational-only (stays plain).
        """
        text = str(text or "")
        status = str(row.get("status") or "OPEN").upper()
        pnl = 0.0
        for key in ("pnl_points", "final_pnl", "current_pnl_points"):
            try:
                pnl = float(row.get(key))
                break
            except (TypeError, ValueError):
                continue
        import re as _re

        def _price_after(token: str) -> float | None:
            m = _re.search(token + r"\s+([0-9]+\.[0-9]+)", text)
            return float(m.group(1)) if m else None

        # trailing ratchet (broker-confirmed)
        m = _re.search(r"trailing stop moved to ([0-9]+\.[0-9]+)", text)
        if m:
            new_sl = float(m.group(1))
            return ("TRAILING_SL_UPDATED", {"stop_loss": new_sl}, status, pnl)
        # breakeven armed
        m = _re.search(r"breakeven armed @ ([0-9]+\.[0-9]+)", text)
        if m:
            be_price = float(m.group(1))
            return ("MOVE_SL_TO_BE", {"stop_loss": be_price, "sl_moved_to_entry": True}, status, pnl)
        # protected/plain stop close written by the broker mirror
        m = _re.search(r"position closed @ ([0-9]+\.[0-9]+) \((\w+)\)", text)
        if m:
            close = float(m.group(1))
            closed_status = m.group(2).upper()
            event = closed_status if closed_status in {
                "SL_HIT", "TP2_HIT", "BE_HIT", "THESIS_EXIT", "MANUAL_CLOSE"} else "SL_HIT"
            if event == "SL_HIT" and row.get("sl_moved_to_entry") and float(row.get("stop_loss") or 0) > float(row.get("entry_price") or 0):
                event = "TRAILING_SL_HIT"
            updates = {"close_price": close, "final_pnl": pnl, "pnl_points": pnl}
            # BUILD 22.2: carry the broker's REAL dollar profit from the
            # manager line ("+675 pts / +337.30$") so the rich card prints
            # the true realized USD next to the points.
            m_usd = _re.search(r"([+-][0-9]+\.[0-9]{2})\$", text)
            if m_usd:
                updates["realized_usd"] = float(m_usd.group(1))
            return (event, updates, closed_status, pnl)
        # broker closed without a deal found
        m = _re.search(r"position closed by broker @ ([0-9]+\.[0-9]+) \(no exit deal", text)
        if m:
            close = float(m.group(1))
            return ("SL_HIT", {"close_price": close, "final_pnl": pnl}, status, pnl)
        # thesis exits
        if "thesis exit" in text or "opposite-entry flip exit" in text or "legacy opposite-exposure guard" in text:
            close = _price_after("closed @")
            updates = {"close_price": close, "final_pnl": pnl, "pnl_points": pnl} if close else {}
            updates["reasons"] = [text]
            return ("THESIS_EXIT", updates, "THESIS_EXIT", pnl)
        # partial closes
        m = _re.search(r"TP1 partial closed", text)
        if m:
            px = _price_after("@")
            return ("TP1_HIT", {"partial_close": True, "close_price": px}, "TP1_HIT", pnl)
        m = _re.search(r"thesis scale-out closed", text)
        if m:
            px = _price_after("@")
            return ("THESIS_SCALE_OUT", {"partial_close": True, "scale_out_price": px}, "PARTIAL", pnl)
        # pending lifecycle
        if "stale pending cancelled" in text or "cancelled (row no longer active)" in text:
            return ("PENDING_CANCELLED", {
                "cancel_reason": text, "reasons": [text],
                "cancel_reason_code": row.get("cancel_reason_code") or "TICK_LIFECYCLE",
            }, "CANCELLED", pnl)
        # fills (only when the broker really filled; placement confirmations
        # stay plain - the rich activation card is sent by _send_execution_signal)
        m = _re.search(r"pending filled @ ([0-9]+\.[0-9]+)", text)
        if m:
            return ("ORDER_FILLED", {"entry_price": float(m.group(1))}, "OPEN", pnl)
        return None


def main() -> None:  # pragma: no cover - VPS only
    from services.database import DatabaseService
    from services.telegram_bot import TelegramService
    from utils.helpers import load_config
    from utils.single_instance import acquire_single_instance

    logging.basicConfig(level=logging.INFO)
    if not acquire_single_instance("tick_manager.pid", "run_tick_manager.py"):
        logger.info("tick manager already running; exiting duplicate instance")
        return
    cfg = load_config()
    if os.environ.get("EXECUTION_MODE") != "mt5_demo":
        logger.info("tick manager idle (EXECUTION_MODE != mt5_demo)")
        return
    TickManager(cfg, TelegramService(cfg), DatabaseService(cfg)).run_forever()


if __name__ == "__main__":
    main()
