"""Read-only evidence adapter for existing production artifacts.

The adapter never imports production databases or broker executors. It reads
atomic JSON artifacts and Auction Flow SQLite files opened with mode=ro, then
normalizes them into immutable, timestamped shadow evidence snapshots.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional
from uuid import uuid4

from .models import utc_now


def normalize_symbol(value: Any) -> str:
    raw = str(value or "").upper().replace("_", "/").replace("-", "/")
    compact = "".join(ch for ch in raw if ch.isalnum())
    aliases = {
        "XAUUSD": "XAU/USD", "GOLD": "XAU/USD",
        "WTIUSD": "WTI/USD", "USOIL": "WTI/USD", "XTIUSD": "WTI/USD",
        "EURUSD": "EUR/USD", "GBPUSD": "GBP/USD", "USDCAD": "USD/CAD",
        "USDJPY": "USD/JPY",
    }
    if compact in aliases:
        return aliases[compact]
    # Brokers commonly append suffixes (.s, m, pro). Match only a known
    # canonical prefix; never infer between unrelated instruments.
    for broker_base in sorted(aliases, key=len, reverse=True):
        if compact.startswith(broker_base):
            return aliases[broker_base]
    return raw if "/" in raw else compact


def _iso_from_any(value: Any, fallback_mtime: float = 0.0) -> str:
    try:
        if isinstance(value, (int, float)) or str(value or "").replace(".", "", 1).isdigit():
            return datetime.fromtimestamp(float(value), timezone.utc).isoformat().replace("+00:00", "Z")
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    except Exception:
        return datetime.fromtimestamp(fallback_mtime, timezone.utc).isoformat().replace("+00:00", "Z")


def read_json_stable(path: str | Path) -> tuple[Dict[str, Any], str, float]:
    """Read a complete artifact without ever modifying or locking its writer."""
    p = Path(path)
    before = p.stat()
    raw = p.read_bytes()
    after = p.stat()
    if before.st_mtime_ns != after.st_mtime_ns or before.st_size != after.st_size:
        raise RuntimeError(f"source changed while being read: {p}")
    data = json.loads(raw.decode("utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError(f"expected JSON object: {p}")
    return data, hashlib.sha256(raw).hexdigest(), after.st_mtime


@dataclass(frozen=True)
class EvidenceSnapshot:
    symbol: str
    known_at: str
    market: Dict[str, Any]
    agents: Dict[str, Any]
    auction: Dict[str, Any]
    original_context: Dict[str, Any] = field(default_factory=dict)
    source_times: Dict[str, str] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    evidence_id: str = field(default_factory=lambda: uuid4().hex)
    recorded_at: str = field(default_factory=utc_now)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class ReadOnlyAuctionReader:
    """Read recent broker-feed aggregates through SQLite immutable read mode."""
    def __init__(self, path: str | Path):
        self.path = Path(path)

    def recent(self, limit: int = 300) -> Dict[str, Any]:
        if not self.path.exists():
            return {"available": False, "reason": "missing"}
        uri = f"file:{self.path.resolve().as_posix()}?mode=ro"
        with sqlite3.connect(uri, uri=True, timeout=2) as conn:
            conn.row_factory = sqlite3.Row
            tables = {r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
            if "seconds" not in tables:
                return {"available": False, "reason": "seconds table missing"}
            rows = list(conn.execute(
                "SELECT * FROM seconds ORDER BY ts DESC LIMIT ?", (max(1, min(limit, 3600)),)))
            meta = dict(conn.execute("SELECT key,value FROM meta")) if "meta" in tables else {}
        rows.reverse()
        return {"available": True, "meta": meta,
                "seconds": [dict(r) for r in rows], "row_count": len(rows)}


class EvidenceAdapter:
    def __init__(self, config: Mapping[str, Any], root: str | Path = ".") -> None:
        self.config = dict(config)
        self.root = Path(root)

    def _path(self, value: str | Path) -> Path:
        p = Path(value)
        return p if p.is_absolute() else self.root / p

    def capture(self, symbol: str) -> EvidenceSnapshot:
        symbol = normalize_symbol(symbol)
        warnings: List[str] = []
        times: Dict[str, str] = {}
        market: Dict[str, Any] = {}
        agents: Dict[str, Any] = {}
        original: Dict[str, Any] = {}

        shared_path = self._path(self.config.get("shared_market_data_path", "storage/shared_market_data.json"))
        try:
            data, digest, mtime = read_json_stable(shared_path)
            source_symbol = normalize_symbol(data.get("symbol") or
                                             (data.get("shared_market_data") or {}).get("symbol"))
            if source_symbol and source_symbol != symbol:
                warnings.append(f"shared market symbol mismatch: {source_symbol}")
            else:
                market = {**data, "_source_sha256": digest}
            times["shared_market"] = _iso_from_any(
                data.get("written_at") or (data.get("shared_market_data") or {}).get("generated_at"), mtime)
        except Exception as exc:
            warnings.append(f"shared market unavailable: {exc}")

        compact = symbol.replace("/", "")
        pattern = str(self.config.get("agent_book_pattern", "storage/agent_books/{symbol}.json"))
        agent_path = self._path(pattern.format(symbol=compact, normalized=symbol))
        try:
            data, digest, mtime = read_json_stable(agent_path)
            book_symbol = normalize_symbol(data.get("symbol") or
                                           (data.get("shared_market_data") or {}).get("symbol"))
            # Empty symbol is allowed but explicitly warned; a different symbol is rejected.
            if book_symbol and book_symbol != symbol:
                warnings.append(f"agent book symbol mismatch: {book_symbol}")
            else:
                agents = {**data, "_source_sha256": digest}
                if not book_symbol:
                    warnings.append("agent book has no symbol identity")
            times["agent_book"] = _iso_from_any(
                data.get("generated_at") or (data.get("shared_market_data") or {}).get("generated_at"), mtime)
        except Exception as exc:
            warnings.append(f"agent book unavailable: {exc}")

        export_pattern = self.config.get("original_context_pattern")
        if export_pattern:
            export_path = self._path(str(export_pattern).format(symbol=compact, normalized=symbol))
            try:
                data, digest, mtime = read_json_stable(export_path)
                export_symbol = normalize_symbol(data.get("symbol"))
                if export_symbol and export_symbol != symbol:
                    warnings.append(f"original context symbol mismatch: {export_symbol}")
                else:
                    original = {**data, "_source_sha256": digest}
                times["original_context"] = _iso_from_any(data.get("generated_at"), mtime)
            except Exception as exc:
                warnings.append(f"original context unavailable: {exc}")

        auction_paths = self.config.get("auction_flow_paths", {}) or {}
        auction_path = auction_paths.get(symbol) or auction_paths.get(compact)
        auction = ReadOnlyAuctionReader(self._path(auction_path)).recent(
            int(self.config.get("auction_seconds_limit", 300))) if auction_path else {
                "available": False, "reason": "path not configured"}
        if auction.get("seconds"):
            times["auction"] = _iso_from_any(auction["seconds"][-1].get("ts"))
        if not auction.get("available"):
            warnings.append(f"auction unavailable: {auction.get('reason')}")

        candidates = [v for v in times.values() if v]
        known_at = max(candidates) if candidates else utc_now()
        return EvidenceSnapshot(symbol=symbol, known_at=known_at, market=market,
                                agents=agents, auction=auction,
                                original_context=original, source_times=times,
                                warnings=warnings)
