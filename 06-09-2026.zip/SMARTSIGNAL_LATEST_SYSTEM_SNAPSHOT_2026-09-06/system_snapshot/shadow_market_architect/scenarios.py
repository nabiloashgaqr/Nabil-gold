"""Phase-4 dual-sided shadow scenario factory.

Every horizon receives an explicit BUY and SELL hypothesis. The factory uses
only evidence known at snapshot time, keeps missing evidence visible, and never
turns a mere narrative/POI into a READY trade.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

from .evidence import EvidenceSnapshot
from .models import Horizon, ScenarioSide, ScenarioSnapshot, ScenarioStatus
from .regime import MarketStateSnapshot


@dataclass(frozen=True)
class ZoneCandidate:
    low: float
    high: float
    label: str
    side: Optional[str] = None
    quality: float = 0.0
    source: str = "evidence"

    @property
    def mid(self) -> float:
        return (self.low + self.high) / 2.0


def _f(v: Any) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _side(v: Any) -> Optional[str]:
    s = str(v or "").upper()
    if "BUY" in s or "BULL" in s or "DEMAND" in s or "SUPPORT" in s or "DISCOUNT" in s:
        return "BUY"
    if "SELL" in s or "BEAR" in s or "SUPPLY" in s or "RESIST" in s or "PREMIUM" in s:
        return "SELL"
    return None


def extract_zones(data: Any, path: str = "root") -> List[ZoneCandidate]:
    """Extract explicitly-labelled POI/zone structures, not arbitrary OHLC lows."""
    found: List[ZoneCandidate] = []
    if isinstance(data, list):
        for i, value in enumerate(data):
            found.extend(extract_zones(value, f"{path}[{i}]"))
        return found
    if not isinstance(data, Mapping):
        return found
    path_l = path.lower()
    zone_context = any(x in path_l for x in (
        "zone", "poi", "entry", "order_block", "orderblock", "fvg",
        "support", "resistance", "supply", "demand"))
    low = _f(data.get("low") or data.get("zone_low") or data.get("lower"))
    high = _f(data.get("high") or data.get("zone_high") or data.get("upper"))
    if zone_context and low > 0 and high > 0 and low != high:
        if low > high:
            low, high = high, low
        label = str(data.get("label") or data.get("type") or data.get("name") or path.split(".")[-1])
        side = _side(data.get("side") or data.get("direction") or data.get("type") or label or path)
        quality = _f(data.get("quality") or data.get("score") or data.get("confidence"))
        found.append(ZoneCandidate(low, high, label, side, quality, path))
    for key, value in data.items():
        if isinstance(value, (Mapping, list)):
            found.extend(extract_zones(value, f"{path}.{key}"))
    # Stable de-duplication protects metrics from the same POI repeated by agents.
    unique: Dict[tuple, ZoneCandidate] = {}
    for z in found:
        unique[(round(z.low, 8), round(z.high, 8), z.side)] = z
    return list(unique.values())


def _current_price(market: Mapping[str, Any]) -> float:
    for obj in (market, market.get("shared_market_data") or {}):
        if isinstance(obj, Mapping):
            for key in ("current_price", "mid", "price", "close"):
                x = _f(obj.get(key))
                if x > 0:
                    return x
            bid, ask = _f(obj.get("bid")), _f(obj.get("ask"))
            if bid > 0 and ask > 0:
                return (bid + ask) / 2
    return 0.0


def _family_id(symbol: str, horizon: Horizon, playbook: str, side: str,
               zone: Optional[ZoneCandidate]) -> str:
    material = [symbol, horizon.value, playbook, side]
    if zone:
        material.extend([round(zone.low, 8), round(zone.high, 8)])
    return hashlib.sha256(json.dumps(material, sort_keys=True).encode()).hexdigest()[:20]


class DualSidedScenarioFactory:
    PLAYBOOKS = {
        "TREND_CONTINUATION": ("TREND_PULLBACK", "EXTREME_FAILED_AUCTION"),
        "EXPANSION": ("FIRST_PULLBACK_AFTER_EXPANSION", "FAILED_AUCTION_REVERSAL"),
        "RANGE_ROTATION": ("RANGE_EDGE_ROTATION", "RANGE_EDGE_ROTATION"),
        "COMPRESSION": ("BREAKOUT_RETEST", "BREAKOUT_RETEST"),
        "EXHAUSTION": ("MATURE_TREND_PULLBACK", "EXTREME_REVERSAL"),
        "TRANSITION": ("BREAKOUT_RETEST", "FAILED_AUCTION_REVERSAL"),
        "SHOCK_NEWS": ("POST_SHOCK_CONTINUATION", "POST_SHOCK_FAILED_AUCTION"),
        "UNCERTAIN": ("NO_TRADE_OBSERVATION", "NO_TRADE_OBSERVATION"),
    }

    def __init__(self, config: Mapping[str, Any] | None = None):
        self.config = dict(config or {})

    @staticmethod
    def _zone_for(side: str, zones: Sequence[ZoneCandidate], price: float) -> Optional[ZoneCandidate]:
        matching = [z for z in zones if z.side in {side, None}]
        if not matching:
            return None
        def rank(z: ZoneCandidate):
            side_location_penalty = 0
            if price > 0:
                if side == "BUY" and z.mid > price:
                    side_location_penalty = 1
                if side == "SELL" and z.mid < price:
                    side_location_penalty = 1
            return (side_location_penalty, -z.quality, abs(z.mid-price) if price else 0)
        return sorted(matching, key=rank)[0]

    def _status(self, state: MarketStateSnapshot, side: str,
                zone: Optional[ZoneCandidate], price: float, is_primary: bool) -> ScenarioStatus:
        if state.state.value == "UNCERTAIN" or state.strength <= 0:
            return ScenarioStatus.WATCH
        if zone is None or price <= 0:
            return ScenarioStatus.WATCH
        inside = zone.low <= price <= zone.high
        if inside:
            # Location alone arms observation; READY requires a phase-5 entry trigger.
            return ScenarioStatus.INSIDE_POI
        width = max(zone.high-zone.low, abs(price)*1e-6)
        distance = min(abs(price-zone.low), abs(price-zone.high))
        if distance <= width * float(self.config.get("approaching_zone_widths", 1.0)):
            return ScenarioStatus.APPROACHING
        return ScenarioStatus.WATCH

    def build(self, evidence: EvidenceSnapshot,
              states: Sequence[MarketStateSnapshot]) -> List[ScenarioSnapshot]:
        price = _current_price(evidence.market)
        zones = extract_zones(evidence.agents)
        output: List[ScenarioSnapshot] = []
        for state in states:
            primary = state.direction if state.direction in {"BUY", "SELL"} else None
            primary_pb, counter_pb = self.PLAYBOOKS[state.state.value]
            for side in ("BUY", "SELL"):
                is_primary = side == primary
                playbook = primary_pb if (is_primary or primary is None) else counter_pb
                zone = self._zone_for(side, zones, price)
                status = self._status(state, side, zone, price, is_primary)
                missing = []
                if price <= 0: missing.append("current_price")
                if zone is None: missing.append(f"{side.lower()}_poi")
                if state.state.value == "UNCERTAIN": missing.append("classified_market_state")
                if playbook.startswith("EXTREME") or "FAILED_AUCTION" in playbook:
                    missing.extend(["sweep_or_failed_auction", "reclaim", "micro_structure_shift"])
                elif "BREAKOUT_RETEST" in playbook:
                    missing.extend(["break_acceptance", "retest", "failed_reclaim"])
                else:
                    missing.append("entry_trigger")
                evidence_payload = {
                    "market_state_id": state.state_id,
                    "market_state": state.state.value,
                    "market_direction": state.direction,
                    "market_strength": state.strength,
                    "current_price": price,
                    "is_primary_direction": is_primary,
                    "zone_source": zone.source if zone else None,
                    "zone_label": zone.label if zone else None,
                    "zone_quality": zone.quality if zone else None,
                    "missing_evidence": list(dict.fromkeys(missing)),
                    "source_evidence_id": evidence.evidence_id,
                }
                output.append(ScenarioSnapshot(
                    symbol=evidence.symbol, side=ScenarioSide(side), horizon=state.horizon,
                    playbook=playbook, status=status, known_at=evidence.known_at,
                    evidence=evidence_payload, config_version=str(self.config.get("version", "phase4")),
                    family_id=_family_id(evidence.symbol, state.horizon, playbook, side, zone),
                    entry_low=zone.low if zone else None, entry_high=zone.high if zone else None,
                    preferred_entry=zone.mid if zone else None,
                ))
        return output
