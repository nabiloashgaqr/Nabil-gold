"""Exclusive SQLite persistence for Shadow Market Architect.

No production database object is accepted by this API. The path is constrained
to a dedicated shadow SQLite filename to make accidental production writes
structurally impossible.
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Iterable

from .models import ScenarioSnapshot, ShadowEvent, utc_now
from .evidence import EvidenceSnapshot
from .regime import MarketStateSnapshot
from .entries import EntryPlan, VirtualOrder
from .positions import VirtualPosition
from .gaps import GapComparison
from .reporting import MetricRollup
from .calibration import CalibrationRun

DEFAULT_PATH = Path("storage/shadow_market_architect.sqlite3")


class ShadowStore:
    def __init__(self, path: str | Path = DEFAULT_PATH) -> None:
        self.path = Path(path)
        if self.path.suffix.lower() not in {".sqlite", ".sqlite3", ".db"}:
            raise ValueError("shadow store must be a local SQLite database")
        if "shadow" not in self.path.name.lower():
            raise ValueError("shadow store filename must explicitly contain 'shadow'")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.schema_path = Path(__file__).with_name("schema.sql")

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def initialize(self) -> None:
        with self.connect() as conn:
            conn.executescript(self.schema_path.read_text(encoding="utf-8"))
            columns={row[1] for row in conn.execute("PRAGMA table_info(shadow_virtual_trades)")}
            for name in ("family_id", "order_id"):
                if name not in columns:
                    conn.execute(f"ALTER TABLE shadow_virtual_trades ADD COLUMN {name} TEXT")
            gap_columns={row[1] for row in conn.execute("PRAGMA table_info(shadow_gap_comparisons)")}
            if "family_id" not in gap_columns:
                conn.execute("ALTER TABLE shadow_gap_comparisons ADD COLUMN family_id TEXT")
            conn.execute(
                "INSERT OR REPLACE INTO shadow_metadata(key,value,updated_at) VALUES(?,?,?)",
                ("schema_version", "1", utc_now()),
            )

    def append_event(self, event: ShadowEvent) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO shadow_events
                (event_id,scenario_id,event_type,symbol,known_at,recorded_at,payload_json)
                VALUES(?,?,?,?,?,?,?)""",
                (event.event_id, event.scenario_id, event.event_type, event.symbol,
                 event.known_at, event.recorded_at,
                 json.dumps(event.payload, ensure_ascii=False, sort_keys=True)),
            )

    def append_snapshot(self, snapshot: ScenarioSnapshot) -> None:
        d = snapshot.to_dict()
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO shadow_scenario_snapshots
                (scenario_id,family_id,symbol,side,horizon,playbook,status,known_at,
                 recorded_at,config_version,entry_low,entry_high,preferred_entry,
                 invalidation,tp1,tp2,tp3,expiry_at,evidence_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (d["scenario_id"], d["family_id"], d["symbol"], d["side"],
                 d["horizon"], d["playbook"], d["status"], d["known_at"],
                 d["recorded_at"], d["config_version"], d["entry_low"],
                 d["entry_high"], d["preferred_entry"], d["invalidation"],
                 d["tp1"], d["tp2"], d["tp3"], d["expiry_at"],
                 json.dumps(d["evidence"], ensure_ascii=False, sort_keys=True)),
            )

    def append_evidence(self, snapshot: EvidenceSnapshot) -> None:
        d = snapshot.to_dict()
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO shadow_evidence_snapshots
                (evidence_id,symbol,known_at,recorded_at,source_times_json,market_json,
                 agents_json,auction_json,original_context_json,warnings_json)
                VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (d["evidence_id"], d["symbol"], d["known_at"], d["recorded_at"],
                 json.dumps(d["source_times"], sort_keys=True),
                 json.dumps(d["market"], ensure_ascii=False, sort_keys=True),
                 json.dumps(d["agents"], ensure_ascii=False, sort_keys=True),
                 json.dumps(d["auction"], ensure_ascii=False, sort_keys=True),
                 json.dumps(d["original_context"], ensure_ascii=False, sort_keys=True),
                 json.dumps(d["warnings"], ensure_ascii=False)))

    def append_market_state(self, snapshot: MarketStateSnapshot) -> None:
        d = snapshot.to_dict()
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO shadow_market_state_snapshots
                (state_id,symbol,horizon,state,direction,strength,known_at,recorded_at,
                 source_timeframe,features_json,reasons_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (d["state_id"],d["symbol"],d["horizon"],d["state"],d["direction"],
                 d["strength"],d["known_at"],d["recorded_at"],d["source_timeframe"],
                 json.dumps(d["features"],sort_keys=True),
                 json.dumps(d["reasons"],ensure_ascii=False)))

    def append_entry_plan(self, plan: EntryPlan) -> None:
        d=plan.to_dict()
        with self.connect() as conn:
            conn.execute("""INSERT INTO shadow_entry_plans
            (plan_id,scenario_id,family_id,symbol,side,method,decision,known_at,plan_json)
            VALUES(?,?,?,?,?,?,?,?,?)""",(d["plan_id"],d["scenario_id"],d["family_id"],
            d["symbol"],d["side"],d["method"],d["decision"],d["known_at"],
            json.dumps(d,ensure_ascii=False,sort_keys=True)))

    def append_virtual_order(self, order: VirtualOrder) -> None:
        d=order.to_dict(); now=d.get("filled_at") or d["created_at"]
        with self.connect() as conn:
            conn.execute("""INSERT INTO shadow_virtual_orders
            (order_id,scenario_id,symbol,side,order_type,status,created_at,updated_at,payload_json)
            VALUES(?,?,?,?,?,?,?,?,?)""",(d["order_id"],d["scenario_id"],d["symbol"],d["side"],
            d["method"],d["status"],d["created_at"],now,json.dumps(d,ensure_ascii=False,sort_keys=True)))

    def upsert_virtual_position(self, position: VirtualPosition) -> None:
        d=position.to_dict()
        if d["status"] == "OPEN" and d.get("closed_at"):
            raise ValueError("OPEN virtual position cannot have closed_at")
        with self.connect() as conn:
            conn.execute("""INSERT INTO shadow_virtual_trades
            (trade_id,scenario_id,family_id,order_id,symbol,side,status,opened_at,closed_at,entry_price,close_price,pnl_points,pnl_r,payload_json)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(trade_id) DO UPDATE SET
            status=excluded.status,closed_at=excluded.closed_at,close_price=excluded.close_price,
            pnl_points=excluded.pnl_points,pnl_r=excluded.pnl_r,payload_json=excluded.payload_json""",
            (d["position_id"],d["scenario_id"],d["family_id"],d["order_id"],d["symbol"],d["side"],d["status"],
             d["opened_at"],d["closed_at"],d["entry_price"],d["close_price"],d["realized_points"],d["realized_r"],
             json.dumps(d,ensure_ascii=False,sort_keys=True)))

    def append_gap_comparison(self, comparison: GapComparison) -> None:
        d=comparison.to_dict()
        with self.connect() as conn:
            conn.execute("""INSERT OR REPLACE INTO shadow_gap_comparisons
            (comparison_id,original_trade_id,scenario_id,family_id,symbol,gap_type,compared_at,details_json)
            VALUES(?,?,?,?,?,?,?,?)""",(d["comparison_id"],d["original_trade_id"],d["scenario_id"],d["family_id"],
            d["symbol"],d["gap_type"],d["compared_at"],json.dumps(d["details"],ensure_ascii=False,sort_keys=True)))

    def virtual_positions(self) -> list[dict]:
        with self.connect() as conn:
            rows=conn.execute("""SELECT t.payload_json,s.horizon,s.playbook FROM shadow_virtual_trades t
            LEFT JOIN shadow_scenario_snapshots s ON s.snapshot_id=(SELECT MAX(s2.snapshot_id) FROM shadow_scenario_snapshots s2 WHERE s2.scenario_id=t.scenario_id)""").fetchall()
            out=[]
            for row in rows:
                d=json.loads(row[0]);d.setdefault("horizon",row[1]);d.setdefault("playbook",row[2]);out.append(d)
            return out

    def gap_comparisons(self) -> list[dict]:
        with self.connect() as conn:
            return [{**json.loads(r[1]),"gap_type":r[0]} for r in conn.execute("SELECT gap_type,details_json FROM shadow_gap_comparisons")]

    def upsert_daily_metric(self, metric: MetricRollup) -> None:
        d=metric.to_dict()
        with self.connect() as conn:
            conn.execute("""INSERT INTO shadow_daily_metrics(metric_date,symbol,horizon,playbook,metrics_json,calculated_at)
            VALUES(?,?,?,?,?,?) ON CONFLICT(metric_date,symbol,horizon,playbook) DO UPDATE SET
            metrics_json=excluded.metrics_json,calculated_at=excluded.calculated_at""",(d["metric_date"],d["symbol"],d["horizon"],d["playbook"],json.dumps(d,sort_keys=True),d["calculated_at"]))

    def daily_metrics(self) -> list[dict]:
        with self.connect() as conn:
            return [json.loads(r[0]) for r in conn.execute("SELECT metrics_json FROM shadow_daily_metrics ORDER BY metric_date,symbol,horizon,playbook")]

    def append_calibration_run(self, run: CalibrationRun) -> None:
        d=run.to_dict()
        with self.connect() as conn:
            conn.execute("INSERT OR REPLACE INTO shadow_calibration_runs(run_id,generated_at,payload_json) VALUES(?,?,?)",
                         (d["run_id"],d["generated_at"],json.dumps(d,ensure_ascii=False,sort_keys=True)))

    def events(self) -> Iterable[sqlite3.Row]:
        with self.connect() as conn:
            return list(conn.execute("SELECT * FROM shadow_events ORDER BY known_at,event_id"))
