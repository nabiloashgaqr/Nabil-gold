from shadow_market_architect.evidence import EvidenceSnapshot
from shadow_market_architect.models import Horizon, MarketState, ScenarioStatus
from shadow_market_architect.regime import MarketStateSnapshot
from shadow_market_architect.scenarios import DualSidedScenarioFactory, extract_zones


def ev(price=100, agents=None):
    return EvidenceSnapshot("XAU/USD", "2026-09-05T10:00:00Z",
                            {"current_price":price}, agents or {}, {})


def st(h, state, direction="NEUTRAL", strength=70):
    return MarketStateSnapshot("XAU/USD", h, state, direction, strength,
                               "2026-09-05T10:00:00Z", "M5", {}, [])


def test_factory_always_publishes_buy_and_sell_for_every_horizon():
    states=[st(Horizon.SCALP,MarketState.TREND_CONTINUATION,"SELL"),
            st(Horizon.INTRADAY,MarketState.RANGE_ROTATION),
            st(Horizon.STRUCTURAL,MarketState.COMPRESSION)]
    out=DualSidedScenarioFactory().build(ev(),states)
    assert len(out)==6
    for h in Horizon:
        assert {x.side.value for x in out if x.horizon==h}=={"BUY","SELL"}


def test_trend_primary_and_counter_hypotheses_are_not_conflated():
    out=DualSidedScenarioFactory().build(ev(),[
        st(Horizon.INTRADAY,MarketState.TREND_CONTINUATION,"SELL")])
    by_side={x.side.value:x for x in out}
    assert by_side["SELL"].playbook=="TREND_PULLBACK"
    assert by_side["SELL"].evidence["is_primary_direction"] is True
    assert by_side["BUY"].playbook=="EXTREME_FAILED_AUCTION"
    assert "reclaim" in by_side["BUY"].evidence["missing_evidence"]


def test_explicit_buy_and_sell_pois_are_selected_by_side():
    agents={"smc":{"demand_zone":{"low":94,"high":96,"type":"DEMAND","quality":80},
                   "supply_zone":{"low":104,"high":106,"type":"SUPPLY","quality":85}}}
    out=DualSidedScenarioFactory().build(ev(95,agents),[
        st(Horizon.INTRADAY,MarketState.RANGE_ROTATION)])
    by_side={x.side.value:x for x in out}
    assert (by_side["BUY"].entry_low,by_side["BUY"].entry_high)==(94,96)
    assert by_side["BUY"].status==ScenarioStatus.INSIDE_POI
    assert (by_side["SELL"].entry_low,by_side["SELL"].entry_high)==(104,106)


def test_location_alone_never_marks_trade_ready():
    agents={"smc":{"buy_poi":{"low":99,"high":101,"side":"BUY"}}}
    scenario=[x for x in DualSidedScenarioFactory().build(ev(100,agents),[
        st(Horizon.SCALP,MarketState.EXPANSION,"BUY")]) if x.side.value=="BUY"][0]
    assert scenario.status==ScenarioStatus.INSIDE_POI
    assert scenario.status!=ScenarioStatus.READY
    assert "entry_trigger" in scenario.evidence["missing_evidence"]


def test_no_market_data_stays_watch_and_exposes_missing_inputs():
    evidence=EvidenceSnapshot("EUR/USD","2026-09-05T10:00:00Z",{}, {}, {})
    out=DualSidedScenarioFactory().build(evidence,[
        MarketStateSnapshot("EUR/USD",Horizon.SCALP,MarketState.UNCERTAIN,"NEUTRAL",0,
                            evidence.known_at,None,{},["insufficient closed bars"])])
    assert all(x.status==ScenarioStatus.WATCH for x in out)
    assert all("current_price" in x.evidence["missing_evidence"] for x in out)


def test_zone_extractor_ignores_ordinary_candle_ohlc():
    data={"timeframes":{"M5":[{"open":100,"high":102,"low":99,"close":101}]},
          "smc":{"sell_poi":{"low":105,"high":107,"side":"SELL"}}}
    zones=extract_zones(data)
    assert len(zones)==1 and zones[0].low==105


def test_family_id_is_stable_for_same_predeclared_opportunity():
    agents={"smc":{"sell_poi":{"low":104,"high":106,"side":"SELL"}}}
    factory=DualSidedScenarioFactory()
    a=factory.build(ev(100,agents),[st(Horizon.INTRADAY,MarketState.TREND_CONTINUATION,"SELL")])
    b=factory.build(ev(101,agents),[st(Horizon.INTRADAY,MarketState.TREND_CONTINUATION,"SELL")])
    sa=[x for x in a if x.side.value=="SELL"][0]; sb=[x for x in b if x.side.value=="SELL"][0]
    assert sa.family_id==sb.family_id
