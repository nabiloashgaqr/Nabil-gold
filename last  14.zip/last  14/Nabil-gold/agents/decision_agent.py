"""Decision Agent — classic 5-agent weighted consensus.

No external model final gate is used. The final signal is calculated from the
five analysis agents only:

- Unified Trend
- Classical
- SMC
- Price Action
- Auction Flow

Rules:
- Ignore agents below ``agent_min_confidence`` (default 70%).
- A normal entry needs at least 2 qualified agents in the same direction.
- Their net weighted confidence after subtracting opposition must be >=72%.
- Counter-trend trades against Daily Bias need at least 2 qualified agents and
  net confidence >=75%.
"""

from __future__ import annotations

import logging
from typing import Any, Dict

from agents.base_agent import BaseAgent
from services.strategy_profiles import select_strategy_profile
from utils.helpers import get_agent_weights

logger = logging.getLogger(__name__)


class DecisionAgent(BaseAgent):
    """Final decision from weighted consensus + safety filters."""

    name = "decision"

    def __init__(self, config: Dict[str, Any], learning_service: Any = None, **_kwargs):
        super().__init__(config)
        self.learning_service = learning_service
        self.min_confidence = float(config.get("risk_settings", {}).get("min_confidence", 65) or 65)
        self.min_rr_ratio = float(config.get("risk_settings", {}).get("min_rr_ratio", 1.5) or 1.5)

        signal_req = config.get("signal_requirements", {}) or {}
        self.min_agents_agree = int(signal_req.get("min_agents_agree", 3) or 3)
        self.min_agreement_pct = float(signal_req.get("min_agreement_percentage", 1) or 1)
        self.allow_all_signals = bool(signal_req.get("allow_all_signals", False))
        self.agent_min_confidence = int(signal_req.get("agent_min_confidence", 67) or 67)
        self.min_consensus_confidence = float(signal_req.get("min_consensus_confidence", 72) or 72)

        # ── Two-Agent Entry Path (Path 2) ──
        tae_cfg = signal_req.get("two_agent_entry") or {}
        self.two_agent_enabled = bool(tae_cfg.get("enabled", False))
        self.tae_min_agents = int(tae_cfg.get("min_agents_agree", 2) or 2)
        self.tae_min_confidence = float(tae_cfg.get("min_consensus_confidence", 72) or 72)
        tae_macro = tae_cfg.get("macro_confirmation") or {}
        self.tae_macro_enabled = bool(tae_macro.get("enabled", True))
        self.tae_macro_min_conf = float(tae_macro.get("min_confidence", 55) or 55)
        tae_gemini = tae_cfg.get("gemini_confirmation") or {}
        self.tae_gemini_enabled = bool(tae_gemini.get("enabled", True))
        self.tae_gemini_min_conf = float(tae_gemini.get("min_confidence", 70) or 70)
        self.tae_cross_distance = int(tae_cfg.get("cross_entry_distance_points", 200) or 200)

        self.default_weights = get_agent_weights(config)
        self.current_weights = self._load_weights()
        # Operator 2026-08-11: canonical config weights are the only decision
        # weights unless the legacy behaviour is explicitly re-enabled.
        self.profile_weight_overrides_enabled = bool(
            config.get("strategy_profile_weight_overrides_enabled", False))
        self.unify_agent_min_confidence = bool(
            config.get("unify_agent_min_confidence", True))
        learning_cfg = config.get("learning", {}) or {}
        # Canonical live book: learning may recommend changes, but it may not
        # silently alter the confidence used for voting unless the operator
        # explicitly opts in. Telegram and execution therefore read one book.
        self.learning_confidence_adjustments_enabled = bool(
            learning_cfg.get("auto_adjust_confidence", False)
        )
        self.voting_agents = set(self.default_weights)
        self.active_profile: Dict[str, Any] = {
            "name": "classic_consensus",
            "resolved_setup_type": "CLASSIC_CONSENSUS",
            "min_agents_agree": self.min_agents_agree,
            "min_consensus_confidence": self.min_consensus_confidence,
            "agent_min_confidence": self.agent_min_confidence,
            "lead_agent": None,
            "require_lead_alignment": False,
        }

    def _load_weights(self) -> Dict[str, float]:
        """Load weights with config.json as the single source of truth.

        Priority: config.json → default_weights (from get_agent_weights).
        DB weights are NOT used for decisions — only for learning recommendations
        and dashboard display.  The user manually updates config.json + Supabase
        when they accept a learning recommendation.
        """
        return get_agent_weights(self.config)

    def update_weights(self, new_weights: Dict[str, float]) -> None:
        self.current_weights = {k: float(v) for k, v in new_weights.items()}
        logger.info("Updated agent weights: %s", self.current_weights)

    def get_adjusted_confidence(self, agent_name: str, base_confidence: float) -> float:
        if not self.learning_service or not self.learning_confidence_adjustments_enabled:
            return base_confidence
        recommendation = self.learning_service.get_agent_recommendation(agent_name)
        if recommendation == "INCREASE_CONFIDENCE":
            return min(base_confidence * 1.1, 95)
        if recommendation == "DECREASE_CONFIDENCE":
            return max(base_confidence * 0.9, 50)
        return base_confidence

    def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        agents_results = data.get("all_agents_results", data)
        indicators = data.get("indicators", {})
        session_info = data.get("session", data.get("session_info", {}))

        profile = self._strategy_profile(agents_results)
        self.active_profile = profile
        votes = self._collect_votes(agents_results, profile=profile)
        classic = self._classic_decision(votes, profile=profile)
        final_signal, final_confidence, reasoning = self._final_decision(classic, session_info)
        result = {
            "agent": self.name,
            "signal": final_signal,
            "decision": final_signal,
            "confidence": final_confidence,
            "reasoning": reasoning,
            "votes": votes,
            "weights": self._weights_for_profile(profile, agents_results=agents_results),
            "classic": classic,
            "strategy_profile": profile,
            "learning": self._get_learning_info(),
            "risk_assessment": self._assess_risk(final_signal, indicators),
            "entry_attribution": self._entry_attribution(final_signal, classic, agents_results),
            "agent_structured": self._agent_structured_payload(agents_results),
            "reason_codes": self._merged_reason_codes(agents_results),
            "timestamp": self.now_iso(),
        }
        return self._apply_safety_filters(result, agents_results)

    async def analyze_async(self, data: Dict[str, Any]) -> Dict[str, Any]:
        agents_results = data.get("all_agents_results", data)
        # Learning service is used only for confidence adjustments and
        # recommendations — NOT for overriding the active weights.
        # Weights come exclusively from config.json (single source of truth).
        return self.analyze({**data, "all_agents_results": agents_results})

    def _profile_overridden_in_config(self, profile: Dict[str, Any]) -> bool:
        """True when config.json tunes this profile's agent bar explicitly.

        Distinguishes a deliberate per-profile setting from the constant
        compiled into services/strategy_profiles.py. Only the former may
        outrank ``signal_requirements.agent_min_confidence``.
        """
        overrides = (self.config.get("strategy_profiles") or {}) if isinstance(self.config, dict) else {}
        entry = overrides.get(str(profile.get("name") or "")) if isinstance(overrides, dict) else None
        return isinstance(entry, dict) and "agent_min_confidence" in entry

    def _strategy_profile(self, agents_results: Dict[str, Any]) -> Dict[str, Any]:
        profile = select_strategy_profile(self.config, agents_results)
        profile.setdefault("min_agents_agree", self.min_agents_agree)
        profile.setdefault("min_consensus_confidence", self.min_consensus_confidence)

        # A BUILT-IN DEFAULT MUST NOT OUTRANK A CONFIGURED VALUE.
        #
        # `setdefault` only fills a key that is MISSING, and every profile in
        # services/strategy_profiles.py ships a hard-coded
        # `agent_min_confidence` (70 for classic_consensus, 68 for the
        # reversal families). The number in config.json was therefore never
        # applied here: editing it looked like it had no effect, because on
        # this path it genuinely had none.
        #
        # Measured 2026-08-04: config set to 67, select_strategy_profile
        # still returned 70 for classic_consensus.
        #
        # `strategy_profiles` in config.json stays authoritative -- an
        # operator who tunes one profile means it. What loses is the value
        # compiled into the source, which is a default and nothing more.
        if self.unify_agent_min_confidence or not self._profile_overridden_in_config(profile):
            profile["agent_min_confidence"] = self.agent_min_confidence
        if not self.profile_weight_overrides_enabled:
            # Do not even publish a dormant override in the active profile: it
            # made diagnostics claim one policy while votes used another.
            profile.pop("weight_overrides", None)
            profile["weight_policy"] = "canonical_config_only"
        profile.setdefault("lead_agent", None)
        profile.setdefault("require_lead_alignment", False)
        return profile

    def _learning_context(self, agents_results: Dict[str, Any], profile: Dict[str, Any] | None = None) -> Dict[str, Any]:
        profile = profile or {}
        setup_context = agents_results.get("setup_context") or {}
        smc = agents_results.get("smc", {}) or {}
        smc_structure = smc.get("setup_structure") or {}
        technical = agents_results.get("unified_trend") or agents_results.get("technical", {}) or {}
        technical_regime = technical.get("market_regime") or {}
        session = agents_results.get("session", {}) or agents_results.get("session_info", {}) or {}
        return {
            "setup_type": str(profile.get("resolved_setup_type") or setup_context.get("setup_type") or smc_structure.get("setup_type") or "CLASSIC_CONSENSUS"),
            "lead_agent": str(profile.get("lead_agent") or setup_context.get("lead_agent") or smc_structure.get("lead_agent") or ""),
            "session_label": str(session.get("current_session") or session.get("session") or session.get("session_name") or ""),
            "regime": str((technical_regime or {}).get("volatility_regime") or "").upper(),
        }

    def _weights_for_profile(self, profile: Dict[str, Any] | None = None, agents_results: Dict[str, Any] | None = None) -> Dict[str, float]:
        profile = profile or {}
        weights = dict(self.current_weights)
        if not self.profile_weight_overrides_enabled:
            # Canonical policy: no setup-profile or contextual-learning weight
            # can silently replace config.json::agent_weights.
            return weights

        # Legacy opt-in path retained only for controlled historical replay.
        overrides = profile.get("weight_overrides") or {}
        if isinstance(overrides, dict) and overrides:
            for name, value in overrides.items():
                try:
                    weights[name] = float(value)
                except (TypeError, ValueError):
                    continue
            total = sum(v for v in weights.values() if v > 0)
            if total > 0:
                weights = {k: v / total for k, v in weights.items()}
        if self.learning_service and agents_results:
            try:
                learning_ctx = self._learning_context(agents_results, profile)
                contextual = self.learning_service.get_contextual_weight_overrides(
                    setup_type=learning_ctx.get("setup_type"),
                    lead_agent=learning_ctx.get("lead_agent"),
                    session_label=learning_ctx.get("session_label"),
                    regime=learning_ctx.get("regime"),
                )
                if isinstance(contextual, dict) and contextual:
                    names = set(weights) | set(contextual)
                    blended = {name: (float(weights.get(name, 0.0)) * 0.65 + float(contextual.get(name, weights.get(name, 0.0))) * 0.35) for name in names}
                    total = sum(v for v in blended.values() if v > 0)
                    if total > 0:
                        weights = {k: v / total for k, v in blended.items()}
            except Exception:  # noqa: BLE001
                logger.exception("Contextual learning weight override failed")
        return weights

    def _collect_votes(self, agents_results: Dict[str, Any], profile: Dict[str, Any] | None = None) -> Dict[str, list]:
        profile = profile or {}
        min_agent_conf = int(profile.get("agent_min_confidence", self.agent_min_confidence) or self.agent_min_confidence)
        profile_weights = self._weights_for_profile(profile, agents_results=agents_results)
        votes = {"BUY": [], "SELL": [], "WAIT": []}
        legacy_to_new = {"technical": "unified_trend", "multitimeframe": "auction_flow"}
        for agent_name, result in agents_results.items():
            canonical_name = agent_name if agent_name in self.voting_agents else legacy_to_new.get(agent_name)
            if canonical_name not in self.voting_agents or not isinstance(result, dict):
                continue
            # A historical snapshot may carry the old key. Never count it when
            # the new canonical agent is present in the same book.
            if (agent_name in legacy_to_new and canonical_name != agent_name
                    and isinstance(agents_results.get(canonical_name), dict)):
                continue
            signal = str(result.get("signal") or result.get("direction") or "WAIT").upper()
            if signal in {"NEUTRAL", "HOLD", "NO_TRADE", "NONE", ""}:
                signal = "WAIT"
            if signal not in votes:
                signal = "WAIT"
            try:
                confidence = float(result.get("confidence", 0) or 0)
            except (TypeError, ValueError):
                confidence = 0
            if confidence < min_agent_conf:
                continue
            weight = float(profile_weights.get(canonical_name, self.default_weights.get(canonical_name, 0.15)) or 0.15)
            adjusted = self.get_adjusted_confidence(canonical_name, confidence)
            score = (adjusted / 100.0) * weight
            votes[signal].append({
                "agent": agent_name,
                "confidence": confidence,
                "adjusted_confidence": adjusted,
                "weight": weight,
                "score": score,
                "learning_adjusted": confidence != adjusted,
                "reason_codes": list(result.get("reason_codes", []) or [])[:8],
                "evidence": list(result.get("evidence", []) or [])[:5],
                "confidence_breakdown": result.get("confidence_breakdown", {}) or {},
            })
        return votes

    def _classic_decision(self, votes: Dict[str, list], profile: Dict[str, Any] | None = None) -> Dict[str, Any]:
        profile = profile or {}
        buy = self._direction_metrics("BUY", votes, profile=profile)
        sell = self._direction_metrics("SELL", votes, profile=profile)
        candidates = [("BUY", buy), ("SELL", sell)]
        valid = [(side, m) for side, m in candidates if m["valid"]]

        decision = "WAIT"
        confidence = 50.0
        rejection_reason = None
        min_agents = int(profile.get("min_agents_agree", self.min_agents_agree) or self.min_agents_agree)
        min_conf = float(profile.get("min_consensus_confidence", self.min_consensus_confidence) or self.min_consensus_confidence)
        agent_min_conf = int(profile.get("agent_min_confidence", self.agent_min_confidence) or self.agent_min_confidence)
        if valid:
            decision, selected = max(valid, key=lambda item: (item[1]["edge"], item[1]["confidence"]))
            confidence = selected["confidence"]
        else:
            total_voting = len(votes["BUY"]) + len(votes["SELL"])
            best = max([buy, sell], key=lambda m: (m["support_count"], m["confidence"], m["edge"]))
            if total_voting == 0:
                rejection_reason = f"No qualified agents (need >= {agent_min_conf}%)"
            elif best.get("profile_block_reason"):
                rejection_reason = best["profile_block_reason"]
            elif best["support_count"] < min_agents:
                rejection_reason = f"Need at least {min_agents} agreeing agents with weighted confidence >= {min_conf:.0f}%"
            elif best["edge"] <= 0:
                rejection_reason = "Opposing agents offset the setup (weighted edge <= 0)"
            elif best["confidence"] < min_conf:
                rejection_reason = f"Net weighted confidence {best['confidence']:.0f}% below {min_conf:.0f}% after opposition penalty"
            else:
                rejection_reason = "No valid weighted consensus edge"

        buy_count = len(votes["BUY"])
        sell_count = len(votes["SELL"])
        total = buy_count + sell_count
        buy_pct = (buy_count / total * 100) if total else 0
        sell_pct = (sell_count / total * 100) if total else 0
        directional = votes["BUY"] + votes["SELL"]
        strongest = max(directional, key=lambda x: x.get("score", 0), default=None)
        strongest_ctx = None
        if strongest:
            strongest_signal = "BUY" if strongest in votes["BUY"] else "SELL"
            strongest_ctx = {
                "agent": strongest.get("agent"),
                "signal": strongest_signal,
                "confidence": round(float(strongest.get("confidence", 0)), 1),
                "adjusted_confidence": round(float(strongest.get("adjusted_confidence", strongest.get("confidence", 0))), 1),
                "weight": strongest.get("weight"),
                "score": round(float(strongest.get("score", 0)), 3),
                "mode": "classic_consensus",
                "reason_codes": strongest.get("reason_codes", []),
                "evidence": strongest.get("evidence", []),
            }

        selected_metrics = buy if decision == "BUY" else sell if decision == "SELL" else None
        supporting_evidence = self._supporting_evidence(decision, selected_metrics, votes)

        # ── Two-Agent Candidate Detection (for Path 2) ──
        two_agent = None
        if not valid and self.two_agent_enabled:
            for side, m in [("BUY", buy), ("SELL", sell)]:
                if (m["edge"] > 0
                        and m["support_count"] >= self.tae_min_agents
                        and m["support_count"] < self.min_agents_agree
                        and m["confidence"] >= self.tae_min_confidence):
                    two_agent = {
                        "side": side,
                        "support_count": m["support_count"],
                        "opposition_count": m["opposition_count"],
                        "edge": m["edge"],
                        "confidence": m["confidence"],
                        "supporters": m["supporters"],
                        "opponents": m["opponents"],
                        "support_weight": m["support_weight"],
                    }
                    break

        return {
            "decision": decision,
            "confidence": round(float(confidence), 1),
            "buy_score": buy["support_score"],
            "sell_score": sell["support_score"],
            "buy_net_score": buy["edge"],
            "sell_net_score": sell["edge"],
            "buy_count": buy_count,
            "sell_count": sell_count,
            "buy_agreement_pct": round(buy_pct, 1),
            "sell_agreement_pct": round(sell_pct, 1),
            "total_voting_agents": total,
            "strongest_agent": strongest.get("agent") if strongest else None,
            "strongest_directional": strongest_ctx,
            "supporting_evidence": supporting_evidence,
            "rejection_reason": rejection_reason,
            "two_agent": two_agent,
            "profile": {
                "name": profile.get("name", "classic_consensus"),
                "resolved_setup_type": profile.get("resolved_setup_type", "CLASSIC_CONSENSUS"),
                "lead_agent": profile.get("lead_agent"),
                "require_lead_alignment": bool(profile.get("require_lead_alignment", False)),
            },
            "consensus": {
                "mode": "unified_5_agent_weighted_consensus",
                "selected": selected_metrics,
                "BUY": buy,
                "SELL": sell,
                "rules": {
                    "agent_min_confidence": agent_min_conf,
                    "min_agents_agree": min_agents,
                    "min_consensus_confidence": min_conf,
                },
            },
        }

    def _agent_structured_payload(self, agents_results: Dict[str, Any]) -> Dict[str, Any]:
        payload: Dict[str, Any] = {}
        aliases = {"unified_trend": "technical", "auction_flow": "multitimeframe"}
        for name in self.voting_agents:
            output_name = name
            result = agents_results.get(name) or {}
            if not isinstance(result, dict) or not result:
                legacy = aliases.get(name)
                result = agents_results.get(legacy) or {} if legacy else {}
                if isinstance(result, dict) and result:
                    output_name = str(legacy)
            if not isinstance(result, dict) or not result:
                continue
            payload[output_name] = {
                "signal": result.get("signal") or result.get("direction") or "WAIT",
                "confidence": result.get("confidence", 0),
                "reason_codes": list(result.get("reason_codes", []) or [])[:10],
                "evidence": list(result.get("evidence", []) or [])[:6],
                "invalidations": list(result.get("invalidations", []) or [])[:5],
                "confidence_breakdown": result.get("confidence_breakdown", {}) or {},
                "data_quality": result.get("data_quality", {}) or {},
            }
        return payload

    def _merged_reason_codes(self, agents_results: Dict[str, Any]) -> list[str]:
        codes: list[str] = []
        for result in agents_results.values():
            if isinstance(result, dict):
                codes.extend(str(c) for c in (result.get("reason_codes", []) or []) if c)
        seen = []
        for code in codes:
            if code not in seen:
                seen.append(code)
        return seen[:20]

    def _entry_attribution(self, signal: str, classic: Dict[str, Any], agents_results: Dict[str, Any]) -> Dict[str, Any]:
        """Explain why the setup was entered or why WAIT was selected.

        Stored inside signal_snapshot for post-trade review; no schema change is
        required.  It separates entry drivers, blockers and regime context so a
        later closed trade can be attributed without re-running old agents.
        """
        signal = str(signal or "WAIT").upper()
        selected = ((classic.get("consensus") or {}).get("selected") or {}) if isinstance(classic, dict) else {}
        supporters = list(selected.get("supporters") or []) if signal in {"BUY", "SELL"} else []
        opponents = list(selected.get("opponents") or []) if signal in {"BUY", "SELL"} else []
        structured = self._agent_structured_payload(agents_results)

        def agent_score(name: str) -> float:
            result = agents_results.get(name) or {}
            try:
                confidence = float(result.get("confidence", 0) or 0)
            except (TypeError, ValueError):
                confidence = 0.0
            canonical = {"technical": "unified_trend", "multitimeframe": "auction_flow"}.get(name, name)
            weight = float(self.current_weights.get(canonical, self.default_weights.get(canonical, 0.15)) or 0.15)
            return confidence * weight

        ranked = sorted(supporters, key=agent_score, reverse=True)
        primary = ranked[0] if ranked else (((classic.get("strongest_directional") or {}).get("agent")) if isinstance(classic, dict) else None)
        mtf = agents_results.get("unified_trend") or agents_results.get("multitimeframe", {}) or {}
        classical = agents_results.get("classical", {}) or {}
        technical = agents_results.get("unified_trend") or agents_results.get("technical", {}) or {}
        news = agents_results.get("news", {}) or {}
        daily = agents_results.get("daily_bias", {}) or {}

        blockers: list[str] = []
        if news and (news.get("can_trade") is False or str(news.get("market_status", "")).upper() == "DANGER"):
            blockers.append("news_event_risk")
        if str(mtf.get("entry_permission", "")).upper() in {"BLOCKED", "NOT_RECOMMENDED"}:
            blockers.append("mtf_entry_permission")
        bias = str(daily.get("bias", "NEUTRAL")).upper()
        if signal == "BUY" and bias == "BEARISH":
            blockers.append("daily_bias_against_buy")
        elif signal == "SELL" and bias == "BULLISH":
            blockers.append("daily_bias_against_sell")

        timing_state = mtf.get("timing_state") or "UNKNOWN"
        failure_mode = "NONE"
        if signal == "WAIT":
            failure_mode = "NO_VALID_CONSENSUS"
        elif blockers:
            failure_mode = str(blockers[0]).upper()
        elif str(timing_state).upper() in {"LATE", "EXHAUSTED", "EARLY"}:
            failure_mode = f"TIMING_{str(timing_state).upper()}"

        macro = news.get("macro_direction") if isinstance(news, dict) else {}
        return {
            "mode": "post_trade_ready",
            "signal": signal,
            "primary_entry_driver": primary,
            "supporting_agents": ranked,
            "opposing_agents": opponents,
            "blockers": blockers,
            "failure_mode": failure_mode,
            "timing_state": timing_state,
            "mtf_failure_mode": mtf.get("mtf_failure_mode"),
            "entry_permission": mtf.get("entry_permission"),
            "pattern_quality": classical.get("pattern_quality", {}),
            "breakout_quality": classical.get("breakout_quality", {}),
            "technical_regime": technical.get("market_regime") or {},
            "event_risk": news.get("event_risk", {}) if isinstance(news, dict) else {},
            "macro_direction": macro if isinstance(macro, dict) else {},
            "daily_bias": {"bias": daily.get("bias"), "confidence": daily.get("confidence"), "strength_band": daily.get("strength_band")},
            "agent_reason_codes": {name: structured.get(name, {}).get("reason_codes", []) for name in structured},
        }

    def _supporting_evidence(self, decision: str, selected_metrics: Dict[str, Any] | None, votes: Dict[str, list]) -> list[str]:
        """Build concise human-readable consensus evidence for the signal message."""
        if decision not in {"BUY", "SELL"} or not selected_metrics:
            return []
        supporters = selected_metrics.get("supporters", []) or []
        opponents = selected_metrics.get("opponents", []) or []
        confidence = float(selected_metrics.get("confidence", 0) or 0)
        support_count = int(selected_metrics.get("support_count", 0) or 0)
        support_avg = float(selected_metrics.get("support_avg_confidence", 0) or 0)
        opposition_count = int(selected_metrics.get("opposition_count", 0) or 0)
        edge = float(selected_metrics.get("edge", 0) or 0)

        names = {
            "unified_trend": "Unified Trend",
            "classical": "Classical",
            "smc": "SMC",
            "price_action": "Price Action",
            "auction_flow": "Auction Flow",
        }
        support_labels = [names.get(str(a), str(a).replace("_", " ").title()) for a in supporters]
        opponent_labels = [names.get(str(a), str(a).replace("_", " ").title()) for a in opponents]

        evidence: list[str] = []
        if support_labels:
            evidence.append(
                f"Qualified supporters: {', '.join(support_labels)} backed {decision} "
                f"with weighted confidence {confidence:.0f}%"
            )
        if support_count:
            evidence.append(
                f"Consensus quality: {support_count} qualified agent(s), "
                f"average supporter confidence {support_avg:.0f}%, weighted edge {edge:.2f}"
            )
        if opposition_count:
            evidence.append(f"Opposition check: {opposition_count} opposing agent(s) were deducted from the final score")
        elif opponent_labels:
            evidence.append(f"Opposition check: no qualified opposing vote against {decision}")
        return evidence

    def _direction_metrics(self, side: str, votes: Dict[str, list], profile: Dict[str, Any] | None = None) -> Dict[str, Any]:
        profile = profile or {}
        opposite = "SELL" if side == "BUY" else "BUY"
        supporters = votes.get(side, []) or []
        opponents = votes.get(opposite, []) or []
        support_score = sum(float(v.get("score", 0) or 0) for v in supporters)
        opposition_score = sum(float(v.get("score", 0) or 0) for v in opponents)
        edge = support_score - opposition_score
        support_weight = sum(float(v.get("weight", 0) or 0) for v in supporters)
        support_count = len(supporters)
        if support_weight > 0:
            support_avg = sum(float(v.get("adjusted_confidence", v.get("confidence", 0)) or 0) * float(v.get("weight", 0) or 0) for v in supporters) / support_weight
        else:
            support_avg = 0.0
        opposition_ratio = opposition_score / max(support_score, 0.0001)
        opposition_penalty = min(30.0, opposition_ratio * 30.0)
        confidence = max(0.0, min(95.0, support_avg - opposition_penalty))
        min_agents = int(profile.get("min_agents_agree", self.min_agents_agree) or self.min_agents_agree)
        min_conf = float(profile.get("min_consensus_confidence", self.min_consensus_confidence) or self.min_consensus_confidence)
        lead_agent = profile.get("lead_agent")
        require_lead = bool(profile.get("require_lead_alignment", False)) and bool(lead_agent)
        supporters_names = [v.get("agent") for v in supporters]
        profile_block_reason = None
        if require_lead and lead_agent not in supporters_names:
            profile_block_reason = f"{profile.get('name', 'profile')} requires lead agent {lead_agent} to align with {side}"
        valid = bool(
            edge > 0
            and support_count >= min_agents
            and confidence >= min_conf
            and not profile_block_reason
        )
        # Two-agent candidate: 2 agents meet thresholds but < profile min_agents for full entry
        two_agent_valid = bool(
            edge > 0
            and support_count >= 2
            and support_count < min_agents
            and confidence >= min_conf
            and not profile_block_reason
        )
        return {
            "side": side,
            "support_count": support_count,
            "opposition_count": len(opponents),
            "support_score": round(support_score, 4),
            "opposition_score": round(opposition_score, 4),
            "edge": round(edge, 4),
            "support_weight": round(support_weight, 4),
            "support_avg_confidence": round(support_avg, 1),
            "opposition_penalty": round(opposition_penalty, 1),
            "confidence": round(confidence, 1),
            "valid": valid,
            "two_agent_valid": two_agent_valid,
            "supporters": supporters_names,
            "opponents": [v.get("agent") for v in opponents],
            "profile_block_reason": profile_block_reason,
            "lead_agent_aligned": (lead_agent in supporters_names) if lead_agent else None,
        }

    def _final_decision(self, classic: Dict[str, Any], ai_or_session: Dict[str, Any], session_info: Dict[str, Any] | None = None) -> tuple[str, float, str]:
        # Backward-compatible signature: older tests/callers passed (classic, ai, session).
        # External AI is ignored in classic consensus mode.
        if session_info is None:
            session_info = ai_or_session
        if not session_info.get("allow_signals", True):
            return "WAIT", 0, f"Reports session ({session_info.get('current_session', 'Unknown')}) - no signals sent"
        if not session_info.get("trading_allowed"):
            return "WAIT", 0, "Outside trading hours"
        final_signal = str(classic.get("decision", "WAIT")).upper()
        final_conf = float(classic.get("confidence", 0) or 0)
        profile_name = ((classic.get("profile") or {}).get("name") or "classic_consensus")
        setup_type = ((classic.get("profile") or {}).get("resolved_setup_type") or "CLASSIC_CONSENSUS")
        profile_label = "Classic consensus" if profile_name == "classic_consensus" else f"Profile {profile_name}"
        if final_signal not in {"BUY", "SELL"}:
            return "WAIT", round(final_conf, 1), f"{profile_label} WAIT ({setup_type}): {classic.get('rejection_reason') or 'No valid weighted consensus'}"
        if final_conf < self.min_confidence:
            return "WAIT", round(final_conf, 1), f"{profile_label} {final_signal} blocked: confidence {final_conf:.0f}% below {self.min_confidence:.0f}%"
        selected = (classic.get("consensus", {}) or {}).get("selected") or {}
        reason = (
            f"{profile_label} ({setup_type}) = {final_signal}; confidence {final_conf:.0f}% "
            f"(min {self.min_confidence:.0f}%), support={selected.get('support_count', 0)} agent(s), "
            f"opposition={selected.get('opposition_count', 0)} agent(s), edge={selected.get('edge', 0)}"
        )
        return final_signal, round(final_conf, 1), reason

    def _get_learning_info(self) -> Dict[str, Any]:
        info = {"enabled": self.learning_service is not None, "current_weights": self.current_weights.copy()}
        if self.learning_service and getattr(self.learning_service, "learning_history", None):
            last = self.learning_service.learning_history[-1]
            info.update({"last_update": last.report_date, "trades_analyzed": last.total_trades_analyzed, "overall_win_rate": last.overall_win_rate})
        return info

    def _assess_risk(self, signal: str, indicators: Dict[str, Any]) -> Dict[str, Any]:
        factors = []
        score = 0
        rsi = float(indicators.get("rsi", 50) or 50)
        if rsi > 75 or rsi < 25:
            factors.append("RSI in extreme zone")
            score += 1
        spread = float(indicators.get("spread", 0) or 0)
        if spread > 5:
            factors.append(f"High spread: {spread}")
            score += 1
        atr = float(indicators.get("atr", 0) or 0)
        if atr and atr < 1.0:
            factors.append("Low ATR - weak volatility")
            score += 1
        assessment = "Acceptable ✅" if score == 0 else "Moderate ⚠️" if score == 1 else "High ❌"
        return {"score": score, "assessment": assessment, "factors": factors}

    def _same_direction_vote_count(self, result: Dict[str, Any], signal: str) -> int:
        votes = result.get("votes", {}) or {}
        side_votes = votes.get(str(signal).upper(), []) if isinstance(votes, dict) else []
        if isinstance(side_votes, list):
            return len(side_votes)
        classic = result.get("classic", {}) or {}
        return int(classic.get("buy_count" if signal == "BUY" else "sell_count", 0) or 0)

    def _apply_safety_filters(self, result: Dict[str, Any], agents_results: Dict[str, Any]) -> Dict[str, Any]:
        warnings = list(result.get("warnings", []) or [])
        signal = str(result.get("signal", "WAIT")).upper()

        session = agents_results.get("session", {}) or {}
        if session and not session.get("trading_allowed", True):
            warnings.append(f"Session blocked: {session.get('reason', 'outside trading hours')}")
            signal = "WAIT"
        if session and not session.get("allow_signals", True):
            warnings.append(f"Signals disabled in current session: {session.get('current_session')}")
            signal = "WAIT"

        news = agents_results.get("news", {}) or {}
        if news and (news.get("can_trade") is False or str(news.get("market_status", "")).upper() == "DANGER"):
            warnings.append(f"News blocked: {news.get('summary', news.get('market_status', 'DANGER'))}")
            signal = "WAIT"

        daily_bias = agents_results.get("daily_bias", {}) or {}
        if signal in {"BUY", "SELL"} and daily_bias.get("enabled", True):
            bias = str(daily_bias.get("bias", "NEUTRAL")).upper()
            bias_conf = float(daily_bias.get("confidence") or 0)
            db = self.config.get("daily_bias_filter", {}) or {}
            required_agents = int(db.get("contrarian_min_agents_for_lower_confidence", 3) or 3)
            required_conf = float(db.get("contrarian_min_confidence", 80) or 80)
            block_below = float(db.get("block_strong_contrarian_below", 80) or 80)
            is_contrarian = (bias == "BULLISH" and signal == "SELL") or (bias == "BEARISH" and signal == "BUY")
            same_count = self._same_direction_vote_count(result, signal)
            signal_conf = float(result.get("confidence") or 0)
            if is_contrarian:
                # Block counter-trend when daily bias itself is very strong
                if block_below > 0 and bias_conf >= block_below:
                    warnings.append(
                        f"Daily Bias (4H) blocks counter-trend: bias={bias} ({bias_conf}% ≥ {block_below}% threshold). "
                        f"No counter-trend allowed when daily bias is this strong."
                    )
                    signal = "WAIT"
                elif same_count < required_agents or signal_conf < required_conf:
                    warnings.append(
                        f"Daily Bias (4H) blocks counter-trend: bias={bias} ({bias_conf}%), signal={signal}. "
                        f"Counter-trend requires ≥{required_agents} qualified agents and confidence ≥{required_conf}% "
                        f"({same_count} qualified agent(s), confidence {signal_conf:.0f}%)."
                    )
                    signal = "WAIT"

        risk = agents_results.get("risk", {}) or {}
        if signal in {"BUY", "SELL"} and risk and not risk.get("approved", False):
            warnings.append(f"Risk rejected: {risk.get('rejection_reason', 'not approved')}")
            signal = "WAIT"

        if signal in {"BUY", "SELL"}:
            profile_warning = self._profile_entry_warning(result, agents_results)
            if profile_warning:
                warnings.append(profile_warning)
                signal = "WAIT"

        if signal != result.get("signal"):
            reason = "; ".join(warnings[-3:]) or "Safety filter blocked signal"
            result["reasoning"] = f"{result.get('reasoning', '')} | {reason}".strip(" |")
            result["confidence"] = 0 if signal == "WAIT" else result.get("confidence", 0)
        result["signal"] = signal
        result["decision"] = signal
        result["warnings"] = warnings
        return result

    def _structure_quality_rank(self, value: str | None) -> int:
        mapping = {"WEAK": 0, "MODERATE": 1, "STRONG": 2}
        return mapping.get(str(value or "").upper(), -1)

    def _profile_entry_warning(self, result: Dict[str, Any], agents_results: Dict[str, Any]) -> str | None:
        profile = result.get("strategy_profile") or self.active_profile or {}
        if not profile or str(profile.get("name", "classic_consensus")) == "classic_consensus":
            return None
        smc = agents_results.get("smc", {}) or {}
        setup = smc.get("setup_structure") or {}
        liquidity = smc.get("liquidity", {}) or {}
        market_structure = smc.get("market_structure") or {}

        required_quality = profile.get("min_structure_quality")
        actual_quality = market_structure.get("structure_quality")
        if required_quality and actual_quality not in {None, "", "UNKNOWN"}:
            if self._structure_quality_rank(actual_quality) < self._structure_quality_rank(str(required_quality)):
                return f"{profile.get('name')} blocks entry: structure quality {actual_quality or 'UNKNOWN'} below {required_quality}"

        min_poi_rank = float(profile.get("min_poi_rank_score", 0) or 0)
        poi_rank = float(setup.get("poi_rank_score") or 0)
        if min_poi_rank > 0 and ("poi_rank_score" in setup or poi_rank > 0) and poi_rank < min_poi_rank:
            return f"{profile.get('name')} blocks entry: POI rank {poi_rank:.0f} below {min_poi_rank:.0f}"

        required_states = [str(x).upper() for x in (profile.get("required_trigger_states") or []) if x]
        trigger_state = str(setup.get("trigger_state") or "").upper()
        if required_states and trigger_state and trigger_state not in required_states:
            return f"{profile.get('name')} blocks entry: trigger state {trigger_state or 'UNKNOWN'} not in {required_states}"

        min_trigger = float(profile.get("min_trigger_score", 0) or 0)
        trigger_score = float(setup.get("trigger_score") or 0)
        if min_trigger > 0 and ("trigger_score" in setup or trigger_score > 0) and trigger_score < min_trigger:
            return f"{profile.get('name')} blocks entry: trigger score {trigger_score:.0f} below {min_trigger:.0f}"

        required_sweep = str(profile.get("require_sweep_confirmation") or "").upper()
        if required_sweep:
            sweep = (liquidity.get("recent_sweep") or {}) if isinstance(liquidity, dict) else {}
            if sweep:
                sweep_conf = str(sweep.get("confirmation") or "").upper()
                if not sweep.get("occurred"):
                    return f"{profile.get('name')} blocks entry: no qualifying liquidity sweep"
                if self._structure_quality_rank(sweep_conf) < self._structure_quality_rank(required_sweep):
                    return f"{profile.get('name')} blocks entry: sweep confirmation {sweep_conf or 'UNKNOWN'} below {required_sweep}"
        return None

    def _calculate_quality_score(self, analysis: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        confidence = float(analysis.get("confidence") or 0)
        risk = context.get("risk", {}) or {}
        news = context.get("news", {}) or {}
        session = context.get("session", {}) or {}
        classic = analysis.get("classic", {}) or {}
        signal = str(analysis.get("signal", "WAIT")).upper()
        tp2 = ((risk.get("take_profit", {}) or {}).get("tp2", {}) or {})
        rr = float(tp2.get("rr_ratio") or 0)
        agreement = float(classic.get("buy_agreement_pct" if signal == "BUY" else "sell_agreement_pct", 0) or 0)
        components = {
            "confidence": min(confidence, 100) * 0.30,
            "agreement": min(agreement, 100) * 0.20,
            "risk_reward": min(max((rr / 3.0) * 20.0, 0), 20.0),
            "risk_approved": 10.0 if risk.get("approved") else 0.0,
        }
        news_status = str(news.get("market_status", "SAFE")).upper()
        components["news"] = 10.0 if news_status == "SAFE" and news.get("can_trade", True) else 5.0 if news.get("can_trade", True) else 0.0
        sq = str(session.get("session_quality", session.get("quality", "LOW"))).upper()
        components["session"] = {"BEST": 10.0, "HIGH": 9.0, "MEDIUM": 6.0, "LOW": 3.0}.get(sq, 0.0) if session.get("trading_allowed", True) else 0.0
        penalty = min(len(analysis.get("warnings", []) or []) * 4.0, 12.0)
        raw = max(0.0, min(100.0, sum(components.values()) - penalty))
        grade, label = ("A+", "Elite") if raw >= 90 else ("A", "Strong") if raw >= 80 else ("B", "Good") if raw >= 70 else ("C", "Acceptable") if raw >= 60 else ("D", "Weak")
        return {"score": round(raw, 1), "grade": grade, "label": label, "components": {k: round(v, 1) for k, v in components.items()}, "penalty": round(penalty, 1), "rr_ratio": round(rr, 2), "agreement_pct": round(agreement, 1)}

    def _order_type(self, signal: str, entry: float, current_price: float | None) -> str:
        oe = self.config.get("order_execution", {}) or {}
        entry_style = str(oe.get("entry_style", "market")).lower()
        if entry_style in ("market", "fixed_risk"):
            return f"{signal}_MARKET"
        try:
            entry = float(entry)
            current = float(current_price or entry)
        except (TypeError, ValueError):
            return f"{signal}_MARKET"
        threshold = float(oe.get("market_threshold_points" if entry_style == "hybrid" else "pending_threshold_points", 30) or 30) / (10.0 if entry_style == "hybrid" else 1.0)
        if abs(entry - current) <= max(threshold, 0.01):
            return f"{signal}_MARKET"
        # Entries are MARKET or LIMIT. Never STOP -- see the note in
        # scripts/run_analysis.py::_planned_order_type. A level that cannot be
        # waited for at a better price is taken at the market rather than
        # chased to a worse one.
        if signal == "BUY":
            return "BUY_LIMIT" if entry < current else "BUY_MARKET"
        if signal == "SELL":
            return "SELL_LIMIT" if entry > current else "SELL_MARKET"
        return "UNKNOWN"

    def _to_trade_decision(self, analysis: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        final_signal = str(analysis.get("signal", "WAIT")).upper()
        risk = context.get("risk", {}) or {}
        current_price = context.get("current_price")
        signal_payload: Dict[str, Any] = {}
        if final_signal in {"BUY", "SELL"}:
            entry_info = risk.get("entry", {}) or {}
            entry_zone = entry_info.get("zone", {}) or {}
            sl = risk.get("stop_loss", {}) or {}
            tp = risk.get("take_profit", {}) or {}
            tp1 = tp.get("tp1", {}) or {}
            tp2 = tp.get("tp2", {}) or {}
            entry_price = entry_info.get("price") or current_price
            order_type = entry_info.get("order_type") or self._order_type(final_signal, float(entry_price or 0), current_price)
            entry_kind = entry_info.get("kind") or ("MARKET" if order_type.endswith("MARKET") else order_type.split("_")[-1])
            signal_payload = {
                "type": final_signal,
                "entry": {
                    "price": entry_price,
                    "low": entry_zone.get("low", entry_price),
                    "high": entry_zone.get("high", entry_price),
                    "kind": entry_kind,
                    "order_type": order_type,
                    "basis": entry_info.get("basis", ""),
                    "current_price": entry_info.get("current_price", current_price),
                    "distance_points": entry_info.get("distance_points", 0.0),
                },
                "stop_loss": sl.get("price", 0),
                "tp1": tp1.get("price", 0),
                "tp2": tp2.get("price", 0),
                "tp1_rr": tp1.get("rr_ratio", 0),
                "tp2_rr": tp2.get("rr_ratio", 0),
                "rr_ratio": tp2.get("rr_ratio", tp1.get("rr_ratio", 0)),
                "order_type": order_type,
                "entry_kind": entry_kind,
                "position_size": risk.get("position_size", {}),
                "risk_summary": risk.get("summary", ""),
            }
        reasons = [analysis.get("reasoning", "")]
        if signal_payload.get("risk_summary"):
            reasons.append(signal_payload.get("risk_summary"))
        reasons.extend(analysis.get("warnings", []) or [])
        # Determine entry mode and path
        two_agent_info = (analysis.get("classic", {}) or {}).get("two_agent")
        final_two_agent = (two_agent_info or {}) if isinstance(two_agent_info, dict) and final_signal in {"BUY", "SELL"} else None
        entry_mode = ("two_agent_consensus" if final_two_agent else "three_agent_consensus") if final_signal in {"BUY", "SELL"} else "wait"
        entry_path = 2 if final_two_agent else (1 if final_signal in {"BUY", "SELL"} else 0)

        return {
            "decision": final_signal,
            "signal": signal_payload,
            "confidence": analysis.get("confidence", 0),
            "quality": self._calculate_quality_score(analysis, context),
            "current_price": current_price,
            "reasons": [r for r in reasons if r],
            "warnings": analysis.get("warnings", []),
            "votes": analysis.get("votes", {}),
            "weights": analysis.get("weights", {}),
            "classic": analysis.get("classic", {}),
            "supportive_evidence": (analysis.get("classic", {}) or {}).get("supporting_evidence", []),
            "entry_attribution": analysis.get("entry_attribution", {}),
            "agent_structured": analysis.get("agent_structured", {}),
            "reason_codes": analysis.get("reason_codes", []),
            "agent_context": (analysis.get("classic", {}) or {}).get("strongest_directional"),
            "strategy_profile": analysis.get("strategy_profile", {}),
            "consensus_mode": True,
            "entry_mode": entry_mode,
            "entry_path": entry_path,
            "learning": analysis.get("learning", {}),
            "risk": risk,
            "risk_assessment": analysis.get("risk_assessment", {}),
            "session_info": context.get("session", {}),
            "news": context.get("news", {}),
            "daily_bias": context.get("daily_bias", {}),
            "dynamic_risk": context.get("dynamic_risk", {}),
            "summary": analysis.get("reasoning", ""),
            "timestamp": analysis.get("timestamp", self.now_iso()),
        }

    def decide(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return self._to_trade_decision(self.analyze(data), data.get("all_agents_results", data))

    async def decide_async(self, data: Dict[str, Any]) -> Dict[str, Any]:
        analysis = await self.analyze_async(data)
        return self._to_trade_decision(analysis, data.get("all_agents_results", data))

    def get_decision_message(self, result: Dict[str, Any]) -> str:
        signal = result.get("signal", "WAIT")
        confidence = result.get("confidence", 0)
        votes = result.get("votes", {})
        classic = result.get("classic", {})
        lines = ["━━━━━━━━━━━━━━━━━━━━", "🧭 *Final Decision*", "━━━━━━━━━━━━━━━━━━━━", f"📊 Signal: *{signal}*", f"🎯 Confidence: *{confidence}%*", ""]
        lines.append("🔥 Agreement requirements:")
        lines.append(f"├ Agents: {classic.get('total_voting_agents', 0)}/{self.min_agents_agree}")
        lines.append(f"└ Min weighted confidence: {self.min_consensus_confidence:.0f}%")
        lines.append("")
        lines.append("🗳️ Agent votes:")
        lines.append(f"├ BUY: {len(votes.get('BUY', []))} ({classic.get('buy_agreement_pct', 0):.0f}%)")
        lines.append(f"├ SELL: {len(votes.get('SELL', []))} ({classic.get('sell_agreement_pct', 0):.0f}%)")
        lines.append(f"└ WAIT: {len(votes.get('WAIT', []))}")
        if classic.get("rejection_reason") and signal == "WAIT":
            lines.append(f"❌ Wait reason: {classic['rejection_reason']}")
        lines.append("━━━━━━━━━━━━━━━━━━━━")
        return "\n".join(lines)
