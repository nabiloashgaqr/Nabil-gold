"""Execution-readiness labels must match canonical Entry/Thesis admission."""
from __future__ import annotations

from services.session_planner import SessionPlannerService


CONFIG = {
    "agent_weights": {
        "unified_trend": 0.20,
        "classical": 0.25,
        "smc": 0.20,
        "price_action": 0.20,
        "auction_flow": 0.15,
    },
    "signal_requirements": {
        "agent_min_confidence": 67,
        "min_agents_agree": 3,
        "min_consensus_confidence": 72,
        "two_agent_entry": {
            "enabled": True,
            "min_agents_agree": 2,
            "min_consensus_confidence": 72,
            "macro_confirmation": {"enabled": True, "min_confidence": 55},
            "gemini_confirmation": {"enabled": True, "min_confidence": 70},
        },
    },
    "session_planner": {"agent_alignment_min_confidence": 67},
}


def _primary() -> dict:
    return {
        "setup_state": "ENTRY_ARMED",
        "trigger_state": "REJECTION_CONFIRMED",
        "trigger_ready": True,
    }


def _two_agent_book() -> dict:
    # Exact shape and key values from the 2026-08-13 06:02 live snapshot.
    return {
        "unified_trend": {"signal": "WAIT", "confidence": 50.6},
        "classical": {"signal": "BUY", "confidence": 60.9},
        "smc": {"signal": "BUY", "confidence": 73.1},
        "price_action": {"signal": "BUY", "confidence": 73.5},
        "auction_flow": {"signal": "WAIT", "confidence": 51.0},
    }


def _readiness(book: dict, macro: dict) -> dict:
    return SessionPlannerService(CONFIG)._execution_readiness(
        planner_source="setup_candidates",
        direction="BUY",
        primary=_primary(),
        standby=None,
        all_results=book,
        preferred_execution_family="MITIGATION_LADDER",
        macro=macro,
    )


def test_two_agents_plus_opposite_macro_cannot_be_market_execution_ready() -> None:
    readiness = _readiness(
        _two_agent_book(),
        {"bias": "BEARISH_GOLD", "confidence": 84.0},
    )
    admission = readiness["execution_admission"]

    assert admission["support_count"] == 2
    assert admission["confidence"] == 73.3
    assert admission["allow"] is False
    assert readiness["has_smc_alignment"] is True
    assert readiness["admission_allow"] is False
    assert readiness["state"] == "WATCH_EXECUTION"
    assert readiness["state"] not in {"PENDING_EXECUTION_READY", "MARKET_EXECUTION_READY"}


def test_two_agents_become_ready_only_with_same_direction_macro() -> None:
    readiness = _readiness(
        _two_agent_book(),
        {"bias": "BULLISH_GOLD", "confidence": 84.0},
    )

    assert readiness["admission_allow"] is True
    assert readiness["admission_path"] == "TWO_AGENT_MACRO"
    assert readiness["state"] == "MARKET_EXECUTION_READY"


def test_three_agent_consensus_remains_ready_without_external_confirmation() -> None:
    book = _two_agent_book()
    book["classical"] = {"signal": "BUY", "confidence": 80.0}
    readiness = _readiness(
        book,
        {"bias": "BEARISH_GOLD", "confidence": 84.0},
    )

    assert readiness["admission_allow"] is True
    assert readiness["admission_path"] == "THREE_AGENT_CONSENSUS"
    assert readiness["state"] == "MARKET_EXECUTION_READY"
