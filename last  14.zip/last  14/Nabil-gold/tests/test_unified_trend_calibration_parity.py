import pytest

from agents.unified_trend_agent import UnifiedTrendAgent
from scripts.build_agent_calibrations import _edge_from_family_by_tf


def test_calibration_edge_matches_live_unified_edge_definition():
    config = {"unified_trend": {"timeframe_weights": {"5m": .10, "15m": .20, "1H": .30, "4H": .40}}}
    by_tf = {
        "5m": {"ema": -.8, "structure": -.4, "momentum": .1, "macd": .2, "rsi": .3},
        "15m": {"ema": -.4, "structure": -.2, "momentum": .2, "macd": -.1, "rsi": .1},
        "1H": {"ema": .6, "structure": .2, "momentum": -.3, "macd": -.2, "rsi": -.5},
        "4H": {"ema": .9, "structure": .8, "momentum": .3, "macd": -.5, "rsi": -.3},
    }
    live = sum(UnifiedTrendAgent.weighted_family_scores(by_tf, config).values()) / 5
    assert _edge_from_family_by_tf(by_tf, config) == pytest.approx(live, abs=1e-12)


def test_training_edge_has_no_coherence_penalty():
    config = {"unified_trend": {}}
    by_tf = {tf: {"ema": .8, "structure": -.8, "momentum": .8, "macd": -.8, "rsi": .2} for tf in ("5m", "15m", "1H", "4H")}
    assert _edge_from_family_by_tf(by_tf, config) == pytest.approx(.04, abs=1e-12)
