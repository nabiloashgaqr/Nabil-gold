"""One-number normalized confidence for Unified Trend and Auction Flow."""
from __future__ import annotations

from pathlib import Path

from services.agent_confidence_audit import _calibrated_expected
from services.normalized_confidence import normalized_logistic_confidence


# Coefficients reconstructed from the live VPS calibration outputs reported on
# 2026-08-13. They pin the exact operational defect: raw Logistic probability
# could never reach the canonical 67% agent bar even at strength=1.
UNIFIED_LIVE_CURVE = {
    "logistic": {"a": 0.0009464225, "b": 0.3664733520},
}
AUCTION_LIVE_CURVE = {
    "logistic": {"a": -0.1193965366, "b": 0.4666169632},
}


def test_normalized_curve_uses_the_full_canonical_50_to_95_scale() -> None:
    for calibration in (UNIFIED_LIVE_CURVE, AUCTION_LIVE_CURVE):
        low = normalized_logistic_confidence(0.0, calibration)
        high = normalized_logistic_confidence(1.0, calibration)
        assert low["valid"] is True
        assert high["valid"] is True
        assert low["score"] == 50.0
        assert high["score"] == 95.0


def test_live_unified_edge_stays_below_bar_because_evidence_is_mixed() -> None:
    result = normalized_logistic_confidence(0.1789, UNIFIED_LIVE_CURVE)
    assert result["valid"] is True
    assert round(result["score"], 1) == 58.1
    assert result["score"] < 67.0


def test_live_auction_edge_becomes_one_logical_qualified_score() -> None:
    result = normalized_logistic_confidence(0.6400, AUCTION_LIVE_CURVE)
    assert result["valid"] is True
    assert round(result["score"], 1) == 79.0
    assert result["score"] >= 67.0
    assert not any("probability" in key.lower() for key in result)


def test_confidence_is_monotonic_and_crosses_67_near_038_edge() -> None:
    for calibration in (UNIFIED_LIVE_CURVE, AUCTION_LIVE_CURVE):
        scores = [
            normalized_logistic_confidence(strength, calibration)["score"]
            for strength in (0.0, 0.1, 0.2, 0.3, 0.38, 0.5, 0.75, 1.0)
        ]
        assert scores == sorted(scores)
        assert scores[3] < 67.0
        assert scores[4] >= 67.0


def test_independent_audit_recalculates_the_same_one_number() -> None:
    cases = (
        (0.1789, UNIFIED_LIVE_CURVE),
        (0.6400, AUCTION_LIVE_CURVE),
    )
    for edge, calibration in cases:
        expected = _calibrated_expected({"raw_edge": -edge}, calibration)
        actual = normalized_logistic_confidence(edge, calibration)["score"]
        assert expected is not None
        assert abs(expected - actual) < 1e-9


def test_flat_curve_is_held_at_wait_50() -> None:
    result = normalized_logistic_confidence(
        1.0, {"logistic": {"a": 0.0, "b": 0.01}},
    )
    assert result["valid"] is False
    assert result["score"] == 50.0
    assert result["reason"] == "CALIBRATION_HAS_NO_DISCRIMINATING_POWER"


def test_optional_missing_calibration_has_explicit_linear_fallback() -> None:
    result = normalized_logistic_confidence(0.4, None)
    assert result["valid"] is True
    assert result["mode"] == "linear_edge_fallback"
    assert result["score"] == 68.0


def test_new_agents_no_longer_publish_a_second_probability_number() -> None:
    root = Path(__file__).resolve().parents[1]
    for rel in ("agents/unified_trend_agent.py", "agents/auction_flow_agent.py"):
        source = (root / rel).read_text(encoding="utf-8")
        assert "calibrated_probability" not in source
        assert '"voting_confidence"' in source
        assert "normalized_logistic_confidence" in source
