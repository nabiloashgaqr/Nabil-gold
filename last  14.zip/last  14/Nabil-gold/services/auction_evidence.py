"""Pure graded Auction Flow evidence transforms.

These functions keep pressure, value location and acceptance/rejection on a
continuous -1..+1 scale. They contain no voting threshold, weight, order or
risk logic and can be shared by live analysis and future calibration builds.
"""
from __future__ import annotations

import math
from typing import Any, Dict, Iterable, Mapping, Tuple


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def clip(value: float) -> float:
    return max(-1.0, min(1.0, float(value)))


def normalized_flow_pressure(raw_imbalance: float, *, scale: float = 0.12) -> float:
    """Expand small tick imbalances smoothly without hard clipping.

    ``scale`` is the raw imbalance producing tanh(1) ~= 0.76 evidence. The
    transform is monotonic, symmetric and remains bounded in -1..+1.
    """
    scale = max(1e-6, abs(_f(scale, 0.12)))
    return clip(math.tanh(_f(raw_imbalance) / scale))


def soft_value_score(raw_atr_distance: float, *, scale_atr: float = 2.0) -> float:
    """Convert signed ATR distance to bounded value evidence without a ±1 wall."""
    scale_atr = max(1e-6, abs(_f(scale_atr, 2.0)))
    return clip(math.tanh(_f(raw_atr_distance) / scale_atr))


def value_location_score(
    price: float, vwap: float, poc: float, atr: float, *, scale_atr: float = 2.0,
) -> float:
    atr = max(abs(_f(atr)), 1e-9)
    raw = ((_f(price) - _f(vwap)) / atr + (_f(price) - _f(poc)) / atr) / 2.0
    return soft_value_score(raw, scale_atr=scale_atr)


def _trailing_streak(values: list[float], predicate) -> list[float]:
    streak: list[float] = []
    for value in reversed(values):
        if not predicate(value):
            break
        streak.append(value)
    streak.reverse()
    return streak


def graded_acceptance_rejection(
    rows: Iterable[Mapping[str, Any]],
    pressure: float,
    vah: float,
    val: float,
    atr: float,
    *,
    window: int = 5,
) -> Tuple[float, str, Dict[str, float]]:
    """Return continuous response evidence, state and transparent components.

    Initiative acceptance requires the latest three closes outside value and
    pressure in the same direction, as before. Its magnitude now reflects:
    duration outside value (35%), depth (30%), pressure (25%) and continuation
    away from value (10%). Responsive rejection is graded by excursion (40%),
    return depth (35%) and pressure (25%).
    """
    recent = [dict(row) for row in rows][-max(3, int(window or 5)):]
    closes = [_f(row.get("close")) for row in recent]
    atr = max(abs(_f(atr)), 1e-9)
    pressure = clip(pressure)
    neutral = {
        "duration": 0.0,
        "depth": 0.0,
        "pressure": abs(pressure),
        "continuation": 0.0,
        "excursion": 0.0,
        "return_depth": 0.0,
    }
    if len(closes) >= 3 and all(close > vah for close in closes[-3:]) and pressure > 0:
        streak = _trailing_streak(closes, lambda close: close > vah)
        duration = min(1.0, len(streak) / max(float(window or 5), 1.0))
        depth = math.tanh(sum(max(0.0, close - vah) for close in streak) / max(len(streak), 1) / atr)
        continuation = math.tanh(max(0.0, streak[-1] - streak[0]) / atr) if len(streak) > 1 else 0.0
        strength = clip(0.35 * duration + 0.30 * depth + 0.25 * abs(pressure) + 0.10 * continuation)
        return strength, "INITIATIVE_BUY_ACCEPTANCE", {
            **neutral, "duration": duration, "depth": depth,
            "continuation": continuation,
        }
    if len(closes) >= 3 and all(close < val for close in closes[-3:]) and pressure < 0:
        streak = _trailing_streak(closes, lambda close: close < val)
        duration = min(1.0, len(streak) / max(float(window or 5), 1.0))
        depth = math.tanh(sum(max(0.0, val - close) for close in streak) / max(len(streak), 1) / atr)
        continuation = math.tanh(max(0.0, streak[0] - streak[-1]) / atr) if len(streak) > 1 else 0.0
        strength = clip(0.35 * duration + 0.30 * depth + 0.25 * abs(pressure) + 0.10 * continuation)
        return -strength, "INITIATIVE_SELL_ACCEPTANCE", {
            **neutral, "duration": duration, "depth": depth,
            "continuation": continuation,
        }
    if recent and any(_f(row.get("high")) > vah for row in recent) and closes[-1] < vah and pressure < 0:
        excursion = math.tanh(max(0.0, max(_f(row.get("high")) for row in recent) - vah) / atr)
        return_depth = math.tanh(max(0.0, vah - closes[-1]) / atr)
        strength = clip(0.40 * excursion + 0.35 * return_depth + 0.25 * abs(pressure))
        return -strength, "RESPONSIVE_SELL_REJECTION", {
            **neutral, "excursion": excursion, "return_depth": return_depth,
        }
    if recent and any(_f(row.get("low")) < val for row in recent) and closes[-1] > val and pressure > 0:
        excursion = math.tanh(max(0.0, val - min(_f(row.get("low")) for row in recent)) / atr)
        return_depth = math.tanh(max(0.0, closes[-1] - val) / atr)
        strength = clip(0.40 * excursion + 0.35 * return_depth + 0.25 * abs(pressure))
        return strength, "RESPONSIVE_BUY_REJECTION", {
            **neutral, "excursion": excursion, "return_depth": return_depth,
        }
    return 0.0, "BALANCED_AUCTION", neutral
