"""Shared entry-grade directional admission for thesis exits and flip guards."""
from __future__ import annotations

from typing import Any, Dict

from utils.helpers import get_agent_weights

VOTING_AGENTS = ("unified_trend", "classical", "smc", "price_action", "auction_flow")
LEGACY_AGENT_ALIASES = {"unified_trend": "technical", "auction_flow": "multitimeframe"}


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _direction(detail: Dict[str, Any] | None) -> str:
    value = str((detail or {}).get("direction") or (detail or {}).get("signal") or "WAIT").upper()
    return "WAIT" if value in {"NEUTRAL", "HOLD", "NO_TRADE", "NONE", ""} else value


def _smc_conditional_map(details: Dict[str, Any]) -> tuple[Dict[str, Any], Dict[str, Any]]:
    """Return (SMC result, selected conditional map) without inventing a vote."""
    smc = details.get("smc") or {}
    if not isinstance(smc, dict):
        return {}, {}
    candidate = smc.get("conditional_map") or smc.get("setup_structure") or {}
    return smc, candidate if isinstance(candidate, dict) else {}


def _map_quality(candidate: Dict[str, Any]) -> float:
    value = candidate.get("quality_score", candidate.get("poi_quality_score"))
    if value in {None, ""}:
        setup_quality = candidate.get("setup_quality") or {}
        if isinstance(setup_quality, dict):
            value = setup_quality.get("score")
    return _f(value, 0.0)


def _map_structure_quality(smc: Dict[str, Any], candidate: Dict[str, Any]) -> str:
    details = candidate.get("details") or {}
    if not isinstance(details, dict):
        details = {}
    market_structure = smc.get("market_structure") or {}
    if not isinstance(market_structure, dict):
        market_structure = {}
    return str(
        candidate.get("structure_quality")
        or details.get("structure_quality")
        or market_structure.get("structure_quality")
        or "WEAK"
    ).upper()


def path4_candidate_matches(admission: Dict[str, Any], candidate: Dict[str, Any] | None) -> bool:
    """Prove the order candidate is the exact SMC map that earned Path 4."""
    if str((admission or {}).get("path") or "") != "SMC_MAP_AUCTION_CONFIRMATION":
        return False
    current = candidate if isinstance(candidate, dict) else {}
    expected_id = str(admission.get("smc_map_id") or "")
    expected_key = str(admission.get("smc_map_state_key") or "")
    if expected_id and str(current.get("id") or ""):
        return expected_id == str(current.get("id") or "")
    if expected_key and str(current.get("state_key") or ""):
        return expected_key == str(current.get("state_key") or "")
    expected_entry = _f(admission.get("smc_map_entry_price"), 0.0)
    current_entry = _f(current.get("entry_price"), 0.0)
    expected_side = str(admission.get("target_side") or "").upper()
    current_side = _direction(current)
    return bool(
        expected_entry > 0 and current_entry > 0
        and abs(expected_entry - current_entry) <= 0.011
        and expected_side == current_side
    )


def _external_confirmation(
    target_side: str,
    details: Dict[str, Any],
    config: Dict[str, Any],
) -> Dict[str, Any]:
    signal_cfg = (config.get("signal_requirements") or {}) if isinstance(config, dict) else {}
    path2 = signal_cfg.get("two_agent_entry") or {}
    macro_cfg = path2.get("macro_confirmation") or {}
    gemini_cfg = path2.get("gemini_confirmation") or {}

    macro = details.get("macro_fundamental") or details.get("macro") or {}
    macro_side = _direction(macro)
    macro_conf = _f(macro.get("confidence"), 0.0)
    macro_min = _f(macro_cfg.get("min_confidence"), 55.0)
    if bool(macro_cfg.get("enabled", True)) and macro_side == target_side and macro_conf >= macro_min:
        return {"allow": True, "source": "macro", "confidence": macro_conf}

    gemini = details.get("gemini") or details.get("gemini_review") or {}
    gemini_side = _direction(gemini)
    gemini_conf = _f(gemini.get("confidence"), 0.0)
    gemini_min = _f(gemini_cfg.get("min_confidence"), 70.0)
    available = gemini.get("available", True) if isinstance(gemini, dict) else False
    if (bool(gemini_cfg.get("enabled", True)) and available
            and gemini_side == target_side and gemini_conf >= gemini_min):
        return {"allow": True, "source": "gemini", "confidence": gemini_conf}
    return {"allow": False, "source": None, "confidence": 0.0}


def evaluate_directional_admission(
    target_side: str,
    agent_details: Dict[str, Any] | None,
    config: Dict[str, Any],
    *,
    allow_path4: bool = True,
) -> Dict[str, Any]:
    """Apply the operator's exact three entry theses to ``target_side``.

    1) >=3 qualified agents with net weighted confidence >=72;
    2) exactly/at least 2 qualified agents at the same confidence + Macro;
    3) exactly/at least 2 qualified agents at the same confidence + Gemini.
    Qualified opposition is deducted with the same formula as DecisionAgent.
    """
    target_side = str(target_side or "").upper()
    details = agent_details if isinstance(agent_details, dict) else {}
    if target_side not in {"BUY", "SELL"} or not details:
        return {"allow": False, "path": None, "available": False,
                "supporters": [], "opponents": [], "confidence": 0.0}

    sig = config.get("signal_requirements") or {}
    min_agent_conf = _f(sig.get("agent_min_confidence"), 67.0)
    min_agents = int(sig.get("min_agents_agree", 3) or 3)
    min_consensus = _f(sig.get("min_consensus_confidence"), 72.0)
    path2 = sig.get("two_agent_entry") or {}
    path2_min_agents = int(path2.get("min_agents_agree", 2) or 2)
    path2_min_conf = _f(path2.get("min_consensus_confidence"), min_consensus)
    weights = get_agent_weights(config)
    opposite = "SELL" if target_side == "BUY" else "BUY"

    supporters = []
    opponents = []
    support_score = 0.0
    opposition_score = 0.0
    support_weight = 0.0
    weighted_conf_sum = 0.0
    for name in VOTING_AGENTS:
        used_name = name
        detail = details.get(name)
        if not isinstance(detail, dict):
            legacy = LEGACY_AGENT_ALIASES.get(name)
            detail = details.get(legacy) if legacy else None
            if isinstance(detail, dict):
                used_name = str(legacy)
        if not isinstance(detail, dict):
            continue
        confidence = _f(detail.get("confidence"), 0.0)
        if confidence < min_agent_conf:
            continue
        side = _direction(detail)
        weight = _f(weights.get(name), 0.0)
        score = confidence / 100.0 * weight
        if side == target_side:
            supporters.append(used_name)
            support_score += score
            support_weight += weight
            weighted_conf_sum += confidence * weight
        elif side == opposite:
            opponents.append(used_name)
            opposition_score += score

    support_avg = weighted_conf_sum / support_weight if support_weight else 0.0
    edge = support_score - opposition_score
    opposition_ratio = opposition_score / max(support_score, 0.0001)
    opposition_penalty = min(30.0, opposition_ratio * 30.0)
    confidence = max(0.0, min(95.0, support_avg - opposition_penalty))

    common = {
        "available": True,
        "target_side": target_side,
        "supporters": supporters,
        "opponents": opponents,
        "support_count": len(supporters),
        "opposition_count": len(opponents),
        "support_score": round(support_score, 4),
        "opposition_score": round(opposition_score, 4),
        "edge": round(edge, 4),
        "confidence": round(confidence, 1),
        "min_agent_confidence": min_agent_conf,
        "min_consensus_confidence": min_consensus,
    }

    if len(supporters) >= min_agents and edge > 0 and confidence >= min_consensus:
        return {**common, "allow": True, "path": "THREE_AGENT_CONSENSUS",
                "reason": f"{len(supporters)} qualified agents admit {target_side} at {confidence:.1f}%"}

    if (bool(path2.get("enabled", True)) and len(supporters) >= path2_min_agents
            and edge > 0 and confidence >= path2_min_conf):
        external = _external_confirmation(target_side, details, config)
        if external.get("allow"):
            source = str(external.get("source") or "").upper()
            return {
                **common, "allow": True, "path": f"TWO_AGENT_{source}",
                "confirm_source": external.get("source"),
                "confirm_confidence": external.get("confidence"),
                "reason": (
                    f"{len(supporters)} qualified agents admit {target_side} at "
                    f"{confidence:.1f}% + {external.get('source')} "
                    f"{_f(external.get('confidence')):.1f}%"
                ),
            }

    # PATH 4 is deliberately a map-confirmation route, not a synthetic SMC
    # vote.  The SMC agent may still be WAIT: its selected conditional map is
    # judged on map quality/revisit/dominance/trigger/structure, while Auction
    # Flow must independently point the same way at >= its own threshold.
    # Any qualified opposite core vote blocks the route.
    path4 = sig.get("path4_smc_map_auction") or {}
    if allow_path4 and bool(path4.get("enabled", False)):
        smc, smc_map = _smc_conditional_map(details)
        map_direction = _direction(smc_map)
        map_quality = _map_quality(smc_map)
        return_probability = _f(smc_map.get("return_probability_score", smc_map.get("return_probability")), 0.0)
        dominance = _f(smc_map.get("thesis_dominance_score", smc_map.get("dominance")), 0.0)
        trigger_score = _f(smc_map.get("trigger_score"), 0.0)
        trigger_ready = bool(smc_map.get("trigger_ready", False))
        structure_quality = _map_structure_quality(smc, smc_map)
        structure_rank = {"WEAK": 0, "MODERATE": 1, "STRONG": 2}
        minimum_structure = str(path4.get("min_structure_quality", "MODERATE") or "MODERATE").upper()

        auction = details.get("auction_flow") or details.get("multitimeframe") or {}
        if not isinstance(auction, dict):
            auction = {}
        auction_direction = _direction(auction)
        auction_confidence = _f(auction.get("confidence"), 0.0)

        min_quality = _f(path4.get("min_map_quality"), 60.0)
        min_return = _f(path4.get("min_return_probability"), 55.0)
        min_dominance = _f(path4.get("min_dominance"), 70.0)
        min_trigger = _f(path4.get("min_trigger_score"), 70.0)
        min_auction = _f(path4.get("min_auction_confidence"), 72.0)
        max_opposition = int(path4.get("max_qualified_opposition", 0) or 0)

        path4_checks = {
            "map_direction": map_direction == target_side,
            "map_quality": map_quality >= min_quality,
            "return_probability": return_probability >= min_return,
            "dominance": dominance >= min_dominance,
            "trigger_score": trigger_score >= min_trigger,
            "trigger_ready": trigger_ready,
            "structure_quality": structure_rank.get(structure_quality, -1) >= structure_rank.get(minimum_structure, 1),
            "auction_direction": auction_direction == target_side,
            "auction_confidence": auction_confidence >= min_auction,
            "qualified_opposition": len(opponents) <= max_opposition,
        }
        if smc_map and all(path4_checks.values()):
            return {
                **common,
                "allow": True,
                "path": "SMC_MAP_AUCTION_CONFIRMATION",
                # The map is evidence, never a sixth vote and never an SMC
                # confidence. ``supporters`` remains the real core vote book.
                "smc_map_counted_as_vote": False,
                "smc_map_id": smc_map.get("id"),
                "smc_map_state_key": smc_map.get("state_key"),
                "smc_map_entry_price": smc_map.get("entry_price"),
                "smc_map_direction": map_direction,
                "smc_map_quality": round(map_quality, 1),
                "smc_return_probability": round(return_probability, 1),
                "smc_dominance": round(dominance, 1),
                "smc_trigger_score": round(trigger_score, 1),
                "smc_trigger_ready": trigger_ready,
                "smc_structure_quality": structure_quality,
                "auction_direction": auction_direction,
                "auction_confidence": round(auction_confidence, 1),
                "path4_checks": path4_checks,
                "order_policy": "LIMIT_ONLY_AT_SMC_POI",
                "reason": (
                    f"SMC conditional {target_side} map confirmed by Auction Flow "
                    f"{auction_confidence:.1f}%; quality={map_quality:.1f}, "
                    f"return={return_probability:.1f}, dominance={dominance:.1f}, "
                    f"trigger={trigger_score:.1f}, opposition={len(opponents)}"
                ),
            }

    return {
        **common, "allow": False, "path": None,
        "reason": (
            f"{target_side} admission failed: support={len(supporters)}, "
            f"opposition={len(opponents)}, net={confidence:.1f}%"
        ),
    }
