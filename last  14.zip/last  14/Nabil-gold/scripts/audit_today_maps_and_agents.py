"""Read-only audit of every local session-map snapshot created today.

Reports each numeric planner component, each configured floor, the qualified
support/opposition book, shared admission result and grouped blockers. It never
runs execution, sends Telegram or writes a trade.
"""
from __future__ import annotations

import json
import os
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from services.map_quality import bounded_map_display_quality
from services.thesis_consensus import evaluate_directional_admission
from utils.helpers import get_agent_weights, load_config

CORE = ("unified_trend", "classical", "smc", "price_action", "auction_flow")


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _dt(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    try:
        if isinstance(value, (int, float)) or str(value).isdigit():
            return datetime.fromtimestamp(float(value), tz=timezone.utc)
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except Exception:
        return None


def _payload(row: Dict[str, Any]) -> Dict[str, Any]:
    payload = row.get("payload")
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except Exception:
            payload = {}
    return payload if isinstance(payload, dict) else row


def _row_time(row: Dict[str, Any], plan: Dict[str, Any]) -> datetime | None:
    for value in (
        row.get("analysis_run_at"), row.get("updated_at"), row.get("created_at"),
        plan.get("plan_created_at"), plan.get("created_at"),
    ):
        parsed = _dt(value)
        if parsed:
            return parsed
    return None


def _agent_details(plan: Dict[str, Any]) -> Dict[str, Any]:
    opinions = plan.get("agent_opinions") or []
    if not opinions:
        opinions = ((plan.get("execution_audit") or {}).get("agent_reads") or [])
    details: Dict[str, Any] = {}
    for op in opinions:
        if not isinstance(op, dict):
            continue
        key = str(op.get("key") or op.get("agent") or "")
        if key:
            details[key] = {
                "direction": op.get("direction") or op.get("signal") or "WAIT",
                "confidence": _f(op.get("confidence")),
            }
    macro = plan.get("macro_plan") or {}
    if isinstance(macro, dict) and macro:
        direction = str(macro.get("direction") or macro.get("signal") or "WAIT").upper()
        if direction in {"BUY", "SELL"}:
            details["macro_fundamental"] = {
                "direction": direction,
                "confidence": _f(macro.get("confidence")),
            }
    return details


def _quality_score(primary: Dict[str, Any]) -> float:
    q = primary.get("setup_quality") or {}
    return _f(primary.get("quality_score"), _f(q.get("score")) if isinstance(q, dict) else 0.0)


def _rank(value: str) -> int:
    return {"WEAK": 0, "MODERATE": 1, "STRONG": 2}.get(str(value or "").upper(), -1)


def main() -> int:
    config = load_config()
    tz_name = str((config.get("schedule") or {}).get("timezone") or "Asia/Hebron")
    zone = ZoneInfo(tz_name)
    today = datetime.now(timezone.utc).astimezone(zone).date()
    path = ROOT / "storage" / "session_plans.json"
    if not path.exists():
        raise SystemExit(f"No session plan storage: {path}")
    raw = json.loads(path.read_text(encoding="utf-8"))
    rows = [row for row in raw if isinstance(row, dict)]
    selected = []
    for row in rows:
        plan = _payload(row)
        stamp = _row_time(row, plan)
        if stamp and stamp.astimezone(zone).date() == today:
            selected.append((stamp, row, plan))
    selected.sort(key=lambda item: item[0])

    planner = config.get("session_planner") or {}
    floors = {
        "min_plan_score": _f(planner.get("min_plan_score"), 62),
        "min_primary_dominance": _f(planner.get("min_primary_dominance"), 50),
        "min_return_probability": _f(planner.get("min_return_probability"), 42),
        "min_primary_quality_score": _f(planner.get("min_primary_quality_score"), 70),
        "min_trigger_score": _f(planner.get("min_trigger_score"), 40),
        "agent_min_confidence": _f(planner.get("agent_alignment_min_confidence"), 67),
        "min_supporting_agents": int(planner.get("min_supporting_agents_for_ready", 2) or 2),
        "max_opposing_agents": int(planner.get("max_opposing_agents_for_ready", 1) or 1),
        "required_structure_quality": str(planner.get("require_structure_quality") or "MODERATE"),
    }

    audits: List[Dict[str, Any]] = []
    blockers_counter: Counter[str] = Counter()
    for stamp, row, plan in selected:
        primary = plan.get("primary_poi") or {}
        if not isinstance(primary, dict):
            primary = {}
        side = str(plan.get("session_bias") or plan.get("authority_direction") or "WAIT").upper()
        dominance = _f(primary.get("thesis_dominance_score"))
        return_probability = _f(primary.get("return_probability_score"))
        setup_quality = _quality_score(primary)
        trigger_score = _f(primary.get("trigger_score"))
        planner_score = _f(plan.get("planner_confidence"))
        structure_quality = str(plan.get("structure_quality") or ((primary.get("details") or {}).get("structure_quality") if isinstance(primary.get("details"), dict) else "") or "UNKNOWN").upper()
        details = _agent_details(plan)
        admission = evaluate_directional_admission(side, details, config) if side in {"BUY", "SELL"} and details else {
            "allow": False, "path": None, "support_count": 0,
            "opposition_count": 0, "confidence": 0.0,
            "reason": "agent opinions unavailable or map has no side",
        }
        observed_core = sum(1 for name in CORE if name in details)
        qualified_core = {
            name: details[name] for name in CORE if name in details
            and str(details[name].get("direction") or "WAIT").upper() in {"BUY", "SELL"}
            and _f(details[name].get("confidence")) >= floors["agent_min_confidence"]
        }
        blockers: List[str] = []
        if not plan.get("plan_ready"):
            blockers.append(str(plan.get("plan_reason") or "plan_not_ready"))
        if primary:
            if dominance < floors["min_primary_dominance"]:
                blockers.append(f"dominance {dominance:.1f} < {floors['min_primary_dominance']:.1f}")
            if return_probability < floors["min_return_probability"]:
                blockers.append(f"return_probability {return_probability:.1f} < {floors['min_return_probability']:.1f}")
            if setup_quality < floors["min_primary_quality_score"]:
                blockers.append(f"setup_quality {setup_quality:.1f} < {floors['min_primary_quality_score']:.1f}")
            if str(primary.get("setup_state") or "").upper() == "DETECTED" and trigger_score < floors["min_trigger_score"]:
                blockers.append(f"trigger {trigger_score:.1f} < {floors['min_trigger_score']:.1f}")
        if structure_quality not in {"UNKNOWN", ""} and _rank(structure_quality) < _rank(floors["required_structure_quality"]):
            blockers.append(f"structure {structure_quality} < {floors['required_structure_quality']}")
        # Support/opposition are meaningful only after the planner has a BUY
        # or SELL target.  Counting every WAIT snapshot as "support 0" made the
        # first audit claim 10 support failures although four WAIT maps really
        # had one qualified directional agent and had already failed an
        # earlier map-quality gate.
        if (side in {"BUY", "SELL"} and observed_core > 0
                and int(admission.get("support_count", 0) or 0) < floors["min_supporting_agents"]):
            blockers.append(f"qualified_support {admission.get('support_count', 0)} < {floors['min_supporting_agents']}")
        if (side in {"BUY", "SELL"}
                and int(admission.get("opposition_count", 0) or 0) > floors["max_opposing_agents"]):
            blockers.append(f"qualified_opposition {admission.get('opposition_count', 0)} > {floors['max_opposing_agents']}")

        map_ready = bool(plan.get("plan_ready"))
        execution_admitted = bool(map_ready and admission.get("allow"))
        stored_readiness_state = str((plan.get("execution_readiness") or {}).get("state") or "")
        stored_execution_ready = stored_readiness_state in {
            "PENDING_EXECUTION_READY", "MARKET_EXECUTION_READY",
        }
        readiness_matches_admission = (
            not map_ready or stored_execution_ready == bool(admission.get("allow"))
        )
        if map_ready and not admission.get("allow"):
            blockers.append(f"shared_admission_blocked: {admission.get('reason')}")
        if not readiness_matches_admission:
            blockers.append(
                "stored_readiness_mismatch: "
                f"{stored_readiness_state or 'NONE'} vs shared allow={bool(admission.get('allow'))}"
            )
        if not blockers:
            blockers.append("NONE")
        for blocker in set(blockers):
            blockers_counter[blocker] += 1

        audits.append({
            "time_utc": stamp.isoformat(),
            "time_local": stamp.astimezone(zone).isoformat(),
            "snapshot_id": row.get("id") or plan.get("snapshot_id"),
            "plan_id": plan.get("plan_id"),
            "side": side,
            "status": plan.get("plan_status"),
            # ``ready`` is retained as the historical structural-map field.
            # It is not execution permission; that truth is explicit below.
            "ready": map_ready,
            "map_ready": map_ready,
            "execution_admitted": execution_admitted,
            "execution_block_reason": None if execution_admitted else admission.get("reason"),
            "stored_execution_ready": stored_execution_ready,
            "readiness_matches_shared_admission": readiness_matches_admission,
            "reason": plan.get("plan_reason"),
            "planner_source": plan.get("planner_source"),
            "legacy_planner_score": planner_score,
            "map_display_quality": bounded_map_display_quality(plan, config),
            "authority_state": plan.get("authority_state"),
            "execution_readiness": plan.get("execution_readiness"),
            "primary": {
                "setup_type": primary.get("setup_type"),
                "setup_state": primary.get("setup_state"),
                "selection_role": primary.get("selection_role"),
                "dominance": dominance,
                "return_probability": return_probability,
                "setup_quality": setup_quality,
                "trigger_state": primary.get("trigger_state"),
                "trigger_score": trigger_score,
                "structure_quality": structure_quality,
            },
            "agents": {
                "observed_core": observed_core,
                "qualified_core": qualified_core,
                "reads": details,
                "admission": admission,
            },
            "blockers": blockers,
        })

    qualified_appearances: Counter[str] = Counter()
    qualified_count_distribution: Counter[str] = Counter()
    for row in audits:
        qualified = list((row.get("agents") or {}).get("qualified_core") or {})
        qualified_appearances.update(qualified)
        qualified_count_distribution[str(len(qualified))] += 1

    map_ready_count = sum(1 for row in audits if row["map_ready"])
    execution_admitted_count = sum(1 for row in audits if row["execution_admitted"])
    summary = {
        "date_local": today.isoformat(),
        "timezone": tz_name,
        "rows": len(audits),
        # Backward-compatible aliases are structural map counts only.
        "ready": map_ready_count,
        "not_ready": len(audits) - map_ready_count,
        "map_ready": map_ready_count,
        "map_not_ready": len(audits) - map_ready_count,
        "execution_admitted": execution_admitted_count,
        "map_ready_but_execution_blocked": sum(
            1 for row in audits if row["map_ready"] and not row["execution_admitted"]
        ),
        "stored_readiness_mismatches": sum(
            1 for row in audits if not row["readiness_matches_shared_admission"]
        ),
        "by_status": dict(Counter(str(row.get("status") or "UNKNOWN") for row in audits)),
        "qualified_core_count_distribution": dict(sorted(qualified_count_distribution.items())),
        "qualified_agent_appearances": dict(qualified_appearances.most_common()),
        "top_blockers": blockers_counter.most_common(25),
        "floors": floors,
    }
    output = {"generated_at": datetime.now(timezone.utc).isoformat(), "read_only": True, "summary": summary, "maps": audits}
    out_dir = ROOT / "diagnostics"
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    json_path = out_dir / f"today_maps_audit_{stamp}.json"
    txt_path = out_dir / f"today_maps_audit_{stamp}.txt"
    json_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = [
        "TODAY MAPS + AGENT GATES AUDIT (READ ONLY)",
        "=" * 64,
        f"Date/timezone: {today} / {tz_name}",
        (
            f"Rows: {summary['rows']} | MAP READY: {summary['map_ready']} | "
            f"EXECUTION ADMITTED: {summary['execution_admitted']} | "
            f"MAP NOT READY: {summary['map_not_ready']}"
        ),
        f"Raw planner status: {summary['by_status']}",
        f"Map-ready but execution-blocked: {summary['map_ready_but_execution_blocked']}",
        f"Stored readiness/shared-admission mismatches: {summary['stored_readiness_mismatches']}",
        f"Qualified core count by map: {summary['qualified_core_count_distribution']}",
        f"Qualified agent appearances: {summary['qualified_agent_appearances']}",
        "",
        "CONFIGURED FLOORS",
    ]
    for key, value in floors.items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "TOP BLOCKERS"])
    for blocker, count in summary["top_blockers"]:
        lines.append(f"- {count}x {blocker}")
    lines.extend(["", "ALL MAP SNAPSHOTS"])
    for row in audits:
        primary = row["primary"]
        admission = row["agents"]["admission"]
        lines.extend([
            "-" * 64,
            (
                f"{row['time_local']} | {row['side']} | {row['status']} | "
                f"map_ready={row['map_ready']} | execution_admitted={row['execution_admitted']}"
            ),
            f"reason: {row['reason']}",
            (
                f"readiness truth: stored_ready={row['stored_execution_ready']} "
                f"matches_shared={row['readiness_matches_shared_admission']} "
                f"block={row['execution_block_reason']}"
            ),
            f"map quality: {row['map_display_quality'].get('score')}/100 (legacy planner={row['legacy_planner_score']}) | authority={row['authority_state']}",
            f"setup: {primary.get('setup_type')} / {primary.get('setup_state')} / trigger {primary.get('trigger_state')}",
            f"points: dominance={primary.get('dominance')} return={primary.get('return_probability')} quality={primary.get('setup_quality')} trigger={primary.get('trigger_score')} structure={primary.get('structure_quality')}",
            f"agents: observed={row['agents']['observed_core']} qualified={list(row['agents']['qualified_core'])}",
            f"admission: allow={admission.get('allow')} path={admission.get('path')} support={admission.get('support_count')} opposition={admission.get('opposition_count')} net={admission.get('confidence')}%",
            f"blockers: {row['blockers']}",
        ])
    lines.extend(["", f"JSON: {json_path}", f"TXT : {txt_path}"])
    text = "\n".join(lines)
    txt_path.write_text(text, encoding="utf-8")
    print("\n".join(lines[: min(len(lines), 80)]))
    if len(lines) > 80:
        print(f"... full {len(audits)}-map audit saved to {txt_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
