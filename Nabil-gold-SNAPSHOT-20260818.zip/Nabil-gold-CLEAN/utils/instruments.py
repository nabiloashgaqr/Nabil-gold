"""Instrument metadata and point conversion helpers.

The project stores PnL/SL/TP distances in broker-style *points*:
- Gold XAU/USD: 1 point = 0.10 USD (10 points = 1.00)
- FX non-JPY: 1 point = 0.00001 (10 points = 1 pip)
- FX JPY pairs: 1 point = 0.001 (10 points = 1 pip)
- WTI oil: 1 point = 0.01 USD
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List


DEFAULT_INSTRUMENTS: Dict[str, Dict[str, Any]] = {
    "XAU/USD": {
        "symbol": "XAU/USD", "name": "Gold", "category": "metal",
        "point_size": 0.10, "price_decimals": 2,
        "min_sl_distance_points": 400, "trailing_distance": 150, "trailing_step": 40,
        # duplicate_zone 200 -> 150 (operator 2026-08-18): the second-entry
        # distance family (cross_entry / scale_in_trigger / duplicate zone)
        # moved to 150 together. Qualification gates are untouched.
        "early_breakeven_points": 200, "duplicate_zone_points": 150,
    },
    "WTI/USD": {
        "symbol": "WTI/USD", "name": "WTI Crude Oil", "category": "oil",
        "point_size": 0.01, "price_decimals": 2,
        # Oil uses 0.01 USD per point. A balanced intraday floor is $1.20,
        # with earlier protection and a tighter trailing profile than gold.
        "min_sl_distance_points": 120, "trailing_distance": 70, "trailing_step": 25,
        # duplicate_zone 100 -> 75 (operator 2026-08-18): follows gold's
        # 200 -> 150 at the same 0.5 ratio so shadow measurement mirrors
        # the live second-entry policy.
        "early_breakeven_points": 70, "duplicate_zone_points": 75,
        # Gold's canonical trading_rules block (200/70/400 stop law, 150/40
        # trailing, 250-point post-TP2 gate) is written in GOLD points and
        # would be a 10x scale error on oil. These are the same laws at the
        # oil scale, derived with the 0.3 ratio implied by the stop floors
        # (120/400); trailing/breakeven keep the operator's tuned 70/25/70.
        "trading_rules": {
            "stop": {"enabled": True, "min_liquidity_points": 60,
                     "safety_buffer_points": 21, "max_stop_points": 120},
            "targets": {"min_tp1_rr": 0.8, "tp2_multiple": 2.0,
                        "max_beyond_points": 60},
            "trailing": {"enabled": True, "distance_points": 70,
                         "step_points": 25, "activation_at": "BREAKEVEN",
                         "early_breakeven_points": 70},
            "post_tp2": {"enabled": True, "min_distance_points": 75,
                         "window_hours": 2.5},
        },
        # Planner geometry is also expressed in points; the global block is
        # gold-scale and would inflate oil zones 10x (a 60-point entry-zone
        # floor is $0.60 on oil vs $6.00 on gold). Same 0.3 ratio.
        "session_planner": {
            "fallback_zone_half_width_points": 36,
            # 45 = gold's 150 (operator 2026-08-18) at the 0.3 oil ratio.
            "standby_min_distance_points": 45,
            "max_primary_zone_width_points": 135,
            "max_standby_zone_width_points": 135,
            "min_zone_width_points": 2,
            "min_entry_zone_width_points": 18,
            "min_thesis_objective_points": 9,
        },
        # Cross-path minimum distance between stacked entries (gold: 150
        # since 2026-08-18; oil keeps the 0.3 scale ratio -> 45).
        "cross_entry_distance_points": 45,
        # Add (scale-in) trigger at the oil scale: gold's 150 x 0.3 = 45
        # points = $0.45. Without this the WTI shadow inherited the gold
        # 150 and logged "need >=150 pts" — a 1.8% pullback bar at $84.
        "scale_in_trigger_points": 45,
        # Auction Flow for oil starts UNCALIBRATED: its per-symbol tick store
        # (auction_flow_wtiusd.sqlite3) fills from the live feed and a proper
        # curve is built later with build_agent_calibrations --symbol WTI.s.
        # Until then the agent runs on the explicit linear fallback instead
        # of refusing every cycle (and the gold curve is barred by the
        # calibration symbol guard).
        "auction_flow": {"calibration_required": False},
    },
}

ALIASES = {
    "XAUUSD": "XAU/USD",
    "GOLD": "XAU/USD",
    "WTI": "WTI/USD",
    "USOIL": "WTI/USD",
    "OIL": "WTI/USD",
    "OIL/W": "WTI/USD",
    "WTICO_USD": "WTI/USD",
}


def normalize_symbol(symbol: Any) -> str:
    text = str(symbol or "XAU/USD").strip().upper().replace(" ", "")
    if text in ALIASES:
        return ALIASES[text]
    if "/" not in text and len(text) == 6:
        text = f"{text[:3]}/{text[3:]}"
    return text


def instrument_map(config: Dict[str, Any] | None = None) -> Dict[str, Dict[str, Any]]:
    mapping = deepcopy(DEFAULT_INSTRUMENTS)
    for item in (config or {}).get("instruments", []) or []:
        if not isinstance(item, dict):
            continue
        symbol = normalize_symbol(item.get("symbol"))
        base = mapping.get(symbol, {"symbol": symbol})
        base.update(item)
        base["symbol"] = symbol
        mapping[symbol] = base
    return mapping


def get_instrument(config: Dict[str, Any] | None = None, symbol: Any = None) -> Dict[str, Any]:
    symbol = normalize_symbol(symbol or (config or {}).get("symbol") or "XAU/USD")
    mapping = instrument_map(config)
    return deepcopy(mapping.get(symbol, {"symbol": symbol, "point_size": 0.00001, "price_decimals": 5}))


def point_size(symbol: Any = None, config: Dict[str, Any] | None = None) -> float:
    return float(get_instrument(config, symbol).get("point_size", 0.00001) or 0.00001)


def price_decimals(symbol: Any = None, config: Dict[str, Any] | None = None) -> int:
    return int(get_instrument(config, symbol).get("price_decimals", 5) or 5)


def points_to_price(points: float, symbol: Any = None, config: Dict[str, Any] | None = None) -> float:
    return float(points or 0) * point_size(symbol, config)


def price_to_points(price_delta: float, symbol: Any = None, config: Dict[str, Any] | None = None) -> float:
    ps = point_size(symbol, config)
    return float(price_delta or 0) / ps if ps else 0.0


def enabled_instruments(config: Dict[str, Any]) -> List[Dict[str, Any]]:
    configured = config.get("symbols") or config.get("enabled_symbols")
    if not configured:
        return [get_instrument(config, config.get("symbol", "XAU/USD"))]
    result: List[Dict[str, Any]] = []
    mapping = instrument_map(config)
    for item in configured:
        if isinstance(item, str):
            symbol = normalize_symbol(item)
            enabled = True
            overrides: Dict[str, Any] = {}
        elif isinstance(item, dict):
            symbol = normalize_symbol(item.get("symbol"))
            enabled = bool(item.get("enabled", True))
            overrides = dict(item)
        else:
            continue
        if not enabled:
            continue
        spec = deepcopy(mapping.get(symbol, {"symbol": symbol}))
        spec.update(overrides)
        spec["symbol"] = symbol
        result.append(spec)
    return result or [get_instrument(config, config.get("symbol", "XAU/USD"))]


def config_for_instrument(base_config: Dict[str, Any], instrument: Dict[str, Any]) -> Dict[str, Any]:
    cfg = deepcopy(base_config)
    symbol = normalize_symbol(instrument.get("symbol"))
    spec = get_instrument(base_config, symbol)
    spec.update(instrument)
    spec["symbol"] = symbol
    cfg["symbol"] = symbol
    cfg["instrument"] = spec

    cfg.setdefault("risk_settings", {})["min_sl_distance_points"] = spec.get(
        "min_sl_distance_points", cfg.get("risk_settings", {}).get("min_sl_distance_points", 400)
    )
    cfg.setdefault("trailing_stop", {})["trailing_distance"] = spec.get(
        "trailing_distance", cfg.get("trailing_stop", {}).get("trailing_distance", 150)
    )
    cfg["trailing_stop"]["trailing_step"] = spec.get(
        "trailing_step", cfg.get("trailing_stop", {}).get("trailing_step", 40)
    )
    cfg["trailing_stop"]["early_breakeven_points"] = spec.get(
        "early_breakeven_points", cfg.get("trailing_stop", {}).get("early_breakeven_points", 200)
    )
    cfg.setdefault("duplicate_signal_filter", {})["price_zone_points"] = spec.get(
        "duplicate_zone_points", cfg.get("duplicate_signal_filter", {}).get("price_zone_points", 50)
    )
    # Per-instrument trading_rules override the global (gold-scale) block so
    # the one canonical law set is always expressed in THIS instrument's
    # points (operator 2026-08-16, WTI shadow onboarding).
    inst_rules = spec.get("trading_rules")
    if isinstance(inst_rules, dict) and inst_rules:
        merged = deepcopy(cfg.get("trading_rules") or {})
        for section, values in inst_rules.items():
            if isinstance(values, dict):
                base = dict(merged.get(section) or {})
                base.update(values)
                merged[section] = base
            else:
                merged[section] = values
        cfg["trading_rules"] = merged
    # Same for the per-instrument auction_flow overrides.
    inst_auction = spec.get("auction_flow")
    if isinstance(inst_auction, dict) and inst_auction:
        base = deepcopy(cfg.get("auction_flow") or {})
        base.update(inst_auction)
        cfg["auction_flow"] = base
    # Same for planner point-geometry and the cross-entry spacing.
    inst_planner = spec.get("session_planner")
    if isinstance(inst_planner, dict) and inst_planner:
        base = deepcopy(cfg.get("session_planner") or {})
        base.update(inst_planner)
        cfg["session_planner"] = base
    if spec.get("cross_entry_distance_points"):
        two = cfg.setdefault("signal_requirements", {}).setdefault("two_agent_entry", {})
        two["cross_entry_distance_points"] = spec["cross_entry_distance_points"]
    # Scale-in trigger is expressed in POINTS and the global block is
    # gold-scale: 150 gold points = $15 (0.34% of price) but 150 oil points
    # = $1.50 (a 1.8% move at $84) — first live log line for WTI read
    # "need >=150 pts below entry" (2026-08-18 11:41), an impossible bar
    # that would have starved the shadow book of adds. Same fix pattern as
    # cross_entry above.
    if spec.get("scale_in_trigger_points"):
        fr = cfg.setdefault("order_execution", {}).setdefault("fixed_risk", {})
        fr["scale_in_trigger_points"] = spec["scale_in_trigger_points"]
    return cfg
