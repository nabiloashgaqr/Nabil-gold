"""Gemini-based review service.
Independent discretionary analyst for trading signals and performance.
Macro-aware version — July 2026
"""

from __future__ import annotations

import json
import logging
import os
import re
from typing import Any, Dict, List

import requests

from utils.helpers import sanitize_prompt_text

logger = logging.getLogger(__name__)


class GeminiReviewService:
    """Independent expert analyzer using Gemini Flash."""

    API_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

    # Set when the daily request quota (RPD) is exhausted. That quota resets at
    # midnight Pacific, so every remaining call in this process is guaranteed to
    # fail: retrying them only burns wall-clock time. A run used to spend 36s of
    # its 71s sleeping between retries that could not possibly succeed.
    _daily_quota_exhausted = False
    _daily_quota_reason = ""

    # Model availability is per-key, not per-doc: a published id can still be
    # refused with 404. Once a working model is found, or all of them fail,
    # remember it so the rest of the run does not repeat the discovery.
    _resolved_model = ""
    _model_unavailable = False
    _model_unavailable_reason = ""

    # Set on the first HTTP 401/403: the credential itself is refused, so
    # every later call in this process is guaranteed to fail no matter which
    # model it targets. Cleared only by reset_quota_state (new process).
    _auth_rejected = False
    _auth_rejected_reason = ""

    # Ordered by cost per call: the cheapest that answers wins.
    DEFAULT_FALLBACK_MODELS = (
        "gemini-2.5-flash-lite",
        "gemini-2.5-flash",
        "gemini-flash-latest",
    )

    @classmethod
    def reset_quota_state(cls) -> None:
        """Clear the daily-quota and model latches (new process, or tests)."""
        cls._daily_quota_exhausted = False
        cls._daily_quota_reason = ""
        cls._resolved_model = ""
        cls._model_unavailable = False
        cls._model_unavailable_reason = ""
        cls._auth_rejected = False
        cls._auth_rejected_reason = ""

    def __init__(self, config: Dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self.api_key = os.environ.get("GEMINI_API_KEY") or ""
        llm_cfg = self.config.get("llm_review") or {}
        # Flash-Lite by default: the analysis cycle runs every 5 minutes and
        # makes up to four review calls each time, which overruns the ~250
        # requests/day free-tier allowance of gemini-2.5-flash roughly twofold
        # and produced a permanent HTTP 429. Flash-Lite carries a ~1000/day
        # allowance on the same key, which covers the real call volume.
        # Override with GEMINI_MODEL, or llm_review.model in config.json.
        self.model = (
            os.environ.get("GEMINI_MODEL")
            or str(llm_cfg.get("model") or "").strip()
            or "gemini-2.5-flash-lite"
        )
        self.enabled = bool(self.api_key)
        self.timeout = int(os.environ.get("GEMINI_TIMEOUT_SECONDS", "20") or 20)
        self.max_retries = int(llm_cfg.get("max_retries", 3))
        self.retry_delay = int(llm_cfg.get("retry_delay_seconds", 3))
        # A per-minute 429 is worth waiting out; the ceiling keeps a single
        # review from stalling a 5-minute analysis cycle.
        self.max_retry_delay = int(llm_cfg.get("max_retry_delay_seconds", 20) or 20)
        # Candidates tried in order when the configured model is refused.
        configured = llm_cfg.get("fallback_models")
        self.fallback_models = [
            str(m).strip() for m in (configured or self.DEFAULT_FALLBACK_MODELS) if str(m).strip()
        ]
        # A model already proven to work this run wins over the configured one.
        if GeminiReviewService._resolved_model:
            self.model = GeminiReviewService._resolved_model
        self._attempted_models: List[str] = [self.model]
        self.session = requests.Session()

    def _next_fallback_model(self) -> str | None:
        """Next candidate not yet tried in this call chain."""
        for candidate in self.fallback_models:
            if candidate not in self._attempted_models:
                self._attempted_models.append(candidate)
                return candidate
        return None

    # ---- 429 classification ------------------------------------------------

    @staticmethod
    def _classify_429(resp: Any) -> tuple[str, int | None]:
        """Tell a daily quota (RPD) apart from a per-minute one (RPM).

        Both arrive as HTTP 429, but they need opposite handling: RPM clears in
        seconds, RPD not until midnight Pacific. Treating them alike is why a
        run retried for 36 seconds against a quota that had no chance of
        clearing. Returns the kind plus any server-advised delay.
        """
        body = ""
        try:
            body = (resp.text or "")[:2000]
        except Exception:  # noqa: BLE001
            body = ""
        lowered = body.lower()

        retry_after: int | None = None
        header = {}
        try:
            header = resp.headers or {}
        except Exception:  # noqa: BLE001
            header = {}
        raw_header = header.get("Retry-After") or header.get("retry-after")
        if raw_header:
            try:
                retry_after = int(float(str(raw_header).strip()))
            except (TypeError, ValueError):
                retry_after = None
        if retry_after is None:
            match = re.search(r'"retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s"', body)
            if match:
                try:
                    retry_after = int(float(match.group(1)))
                except (TypeError, ValueError):
                    retry_after = None

        daily_markers = (
            "perday", "per day", "requestsperday", "free_tier_requests",
            "generaterequestsperdayperproject",
        )
        if any(marker in lowered for marker in daily_markers):
            return "daily", retry_after
        # A very long advised wait is a daily bucket in all but name.
        if retry_after is not None and retry_after >= 120:
            return "daily", retry_after
        return "minute", retry_after

    def review_signal(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Independent expert review of a trade setup — macro aware."""
        if not self.enabled: return self._unavailable("API key missing")
        compact = self._compact_signal_payload(payload)
        prompt = (
            "You are an Independent Senior Hedge Fund Trader specialized in XAU/USD.\n"
            "Evaluate INDEPENDENTLY — give YOUR own verdict (BUY, SELL, or WAIT).\n"
            "Be CONCISE. No repetition, no filler.\n"
            "NEVER mention or explain individual agents, their names, or their votes.\n"
            "Give YOUR OWN independent market opinion only.\n"
            "Consider: macro_direction (DXY, yields, Fed, risk_sentiment).\n"
            "If macro conflicts with technicals, lower confidence.\n"
            "Return STRICT JSON:\n"
            "{\n"
            "  \"verdict\": \"BUY|SELL|WAIT\",\n"
            "  \"confidence\": 0-100,\n"
            "  \"reason\": \"one concise sentence, mention macro driver if relevant\",\n"
            "  \"macro_alignment\": \"ALIGNED|CONFLICT|NEUTRAL\",\n"
            "  \"risk_level\": \"LOW|MEDIUM|HIGH\",\n"
            "  \"invalidation\": \"one short invalidation level/condition\"\n"
            "}\n"
            f"\n\nDATA:\n{json.dumps(compact, ensure_ascii=False)}"
        )
        return self._generate_json(prompt, kind="signal")

    def analyze_market_context(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Form an independent discretionary opinion from market context — macro aware."""
        if not self.enabled: return self._unavailable("API key missing")
        compact = self._compact_market_payload(payload)
        prompt = (
            "You are a Professional Institutional Analyst for Gold.\n"
            "Analyze technical + macro context independently.\n"
            "Be CONCISE. No repetition, no filler.\n"
            "NEVER mention or explain individual agents or their votes.\n"
            "Give YOUR OWN independent market opinion only.\n"
            "Use macro_direction (DXY, yields, Fed, risk_sentiment) as PRIMARY filter, "
            "then confirm with technical regime.\n"
            "Return STRICT JSON:\n"
            "{ \"market_bias\": \"BULLISH/BEARISH/NEUTRAL\", "
            "\"action\": \"BUY/SELL/WAIT\", "
            "\"macro_read\": \"BULLISH_GOLD|BEARISH_GOLD|NEUTRAL\", "
            "\"reason\": \"short sentence including macro driver\" }\n"
            f"\n\nDATA:\n{json.dumps(compact, ensure_ascii=False)}"
        )
        return self._generate_json(prompt, kind="market")

    def interpret_news_context(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Interpret news risk in concise bullet points — macro aware."""
        if not self.enabled: return self._unavailable("API key missing")
        compact = self._compact_news_payload(payload)
        prompt = (
            "Analyze news + macro context for XAU/USD.\n"
            "Be CONCISE. No repetition, no filler.\n"
            "NEVER mention or explain individual agents or their votes.\n"
            "Give YOUR OWN independent opinion only.\n"
            "Incorporate macro_direction if present (DXY, yields, Fed).\n"
            "Return STRICT JSON:\n"
            "{ \"risk_level\": \"LOW/MEDIUM/HIGH/EXTREME\", "
            "\"summary_bullets\": [\"point1\", \"point2\", \"point3\"], "
            "\"trading_advice\": \"sentence\", "
            "\"macro_bias\": \"BULLISH_GOLD|BEARISH_GOLD|NEUTRAL\" }\n"
            f"\n\nDATA:\n{json.dumps(compact, ensure_ascii=False)}"
        )
        return self._generate_json(prompt, kind="news")

    def interpret_macro_context(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Standalone macro interpretation — NEW July 2026."""
        if not self.enabled: return self._unavailable("API key missing")
        compact = self._compact_macro_payload(payload)
        prompt = (
            "You are a Senior Macro Strategist for Gold (XAU/USD).\n"
            "Give an INDEPENDENT macro verdict — do NOT just repeat the input bias.\n"
            "Be CONCISE. No repetition, no filler.\n"
            "NEVER mention or explain individual agents or their votes.\n"
            "Give YOUR OWN independent opinion only.\n"
            "Weigh DXY + real yields heaviest, then Fed tone, then risk sentiment.\n"
            "Return STRICT JSON:\n"
            "{\n"
            "  \"macro_verdict\": \"BULLISH_GOLD|BEARISH_GOLD|NEUTRAL\",\n"
            "  \"confidence\": 0-100,\n"
            "  \"primary_driver\": \"DXY|YIELDS|FED|RISK|GROWTH|INFLATION\",\n"
            "  \"reason\": \"one sentence with key macro driver\",\n"
            "  \"invalidation\": \"what would flip the view\",\n"
            "  \"trade_bias\": \"BUY|SELL|WAIT\",\n"
            "  \"time_horizon\": \"INTRADAY|SWING|POSITION\"\n"
            "}\n"
            f"\n\nDATA:\n{json.dumps(compact, ensure_ascii=False)}"
        )
        return self._generate_json(prompt, kind="macro")

    def interpret_post_news(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Post-news analysis: after a major event, analyze its impact on gold.

        Uses actual vs forecast numbers, price reaction, and DXY macro context
        to give a special recommendation (not a trade entry signal).
        """
        if not self.enabled: return self._unavailable("API key missing")
        compact = self._compact_post_news_payload(payload)
        prompt = (
            "You are a Senior Gold Market Analyst. A major economic event just released.\n"
            "Analyze the IMPACT on Gold (XAU/USD) specifically.\n"
            "Be CONCISE. No repetition, no filler.\n"
            "NEVER mention or explain individual agents or their votes.\n"
            "Give YOUR OWN independent opinion only.\n"
            "Consider: actual vs forecast surprise, DXY/dollar strength, price reaction.\n"
            "This is NOT an entry signal, it is an informed observation.\n"
            "Return STRICT JSON: "
            "{ 'event': 'event name', 'surprise': 'BETTER/WORSE/IN_LINE', "
            "'gold_impact': 'BULLISH/BEARISH/NEUTRAL', 'dxy_impact': 'STRENGTHENING/WEAKENING/NEUTRAL', "
            "'recommendation': 'one clear sentence about gold outlook', "
            "'confidence': 1-100, 'key_insight': 'one sentence explaining the main takeaway' }"
            f"\n\nDATA:\n{json.dumps(compact, ensure_ascii=False)}"
        )
        return self._generate_json(prompt, kind="post_news")

    def summarize_learning(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Independent learning summary in points."""
        if not self.enabled: return self._unavailable("API key missing")
        compact = self._compact_learning_payload(payload)
        prompt = (
            "Summarize trading performance CONCISELY.\n"
            "NEVER mention or explain individual agents or their votes.\n"
            "Give YOUR OWN independent opinion only.\n"
            "Return STRICT JSON: "
            "{ 'execution_score': 1-10, 'key_lessons': ['p1', 'p2', 'p3'], 'adjustment': 'sentence' }"
            f"\n\nDATA:\n{json.dumps(compact, ensure_ascii=False)}"
        )
        return self._generate_json(prompt, kind="learning")

    def summarize_daily_report(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Independent daily summary in points."""
        if not self.enabled: return self._unavailable("API key missing")
        compact = self._compact_daily_report_payload(payload)
        prompt = (
            "Summarize the day CONCISELY.\n"
            "NEVER mention or explain individual agents or their votes.\n"
            "Give YOUR OWN independent opinion only.\n"
            "Return STRICT JSON: "
            "{ 'verdict': 'CLEAN/FRAGILE/NEUTRAL', 'key_points': ['p1', 'p2', 'p3'], 'summary': 'sentence' }"
            f"\n\nDATA:\n{json.dumps(compact, ensure_ascii=False)}"
        )
        return self._generate_json(prompt, kind="daily")

    def summarize_weekly_report(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Independent weekly summary in points."""
        if not self.enabled: return self._unavailable("API key missing")
        compact = self._compact_weekly_report_payload(payload)
        prompt = (
            "Summarize the week CONCISELY.\n"
            "NEVER mention or explain individual agents or their votes.\n"
            "Give YOUR OWN independent opinion only.\n"
            "Return STRICT JSON: "
            "{ 'edge_efficiency': 'val', 'market_regime': 'val', 'strategic_points': ['p1', 'p2', 'p3'], 'strategic_pivot': 'sentence' }"
            f"\n\nDATA:\n{json.dumps(compact, ensure_ascii=False)}"
        )
        return self._generate_json(prompt, kind="weekly")

    def _generate_json(self, prompt: str, kind: str = "generic") -> Dict[str, Any]:
        import time as _time
        # Short-circuit: the daily quota is gone, so this call cannot succeed.
        if GeminiReviewService._daily_quota_exhausted:
            reason = GeminiReviewService._daily_quota_reason or "daily quota exhausted"
            logger.info("Gemini %s skipped: %s", kind, reason)
            return self._unavailable(reason, kind=kind)
        # Every candidate already failed this run; do not re-discover that.
        if GeminiReviewService._model_unavailable:
            reason = GeminiReviewService._model_unavailable_reason or "no usable Gemini model"
            logger.info("Gemini %s skipped: %s", kind, reason)
            return self._unavailable(reason, kind=kind)
        # The key itself was refused earlier in this run. A rejected key does
        # not become valid three seconds later, or on the next call.
        if GeminiReviewService._auth_rejected:
            reason = GeminiReviewService._auth_rejected_reason or "API key rejected (HTTP 401/403)"
            logger.info("Gemini %s skipped: %s", kind, reason)
            return self._unavailable(reason, kind=kind)

        last_error = ""
        for attempt in range(1, self.max_retries + 1):
            try:
                url = self.API_URL.format(model=self.model)
                resp = self.session.post(url, params={"key": self.api_key}, json={"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"temperature": 0.2, "responseMimeType": "application/json"}}, timeout=self.timeout)
                if resp.status_code != 200:
                    last_error = f"HTTP {resp.status_code}"
                    # 401/403 = the KEY is refused, not the model and not the
                    # rate. Retrying cannot help, and neither can the model
                    # fallback list — every model shares the same credential.
                    # Observed live on 2026-08-17: the .env key (previously
                    # leaked on a public GitHub repo) started returning 401,
                    # and each affected cycle burned ~9s in doomed retries.
                    # Latch it once, log loudly, and skip Gemini for the rest
                    # of this process; the operator must rotate GEMINI_API_KEY.
                    if resp.status_code in (401, 403):
                        reason = (
                            f"API key rejected (HTTP {resp.status_code}) — "
                            "rotate GEMINI_API_KEY in .env; skipping Gemini for this run"
                        )
                        GeminiReviewService._auth_rejected = True
                        GeminiReviewService._auth_rejected_reason = reason
                        logger.error("Gemini %s: %s", kind, reason)
                        return self._unavailable(reason, kind=kind)
                    # A 404 means this model id does not exist for this key --
                    # availability differs between accounts, so a name that is
                    # valid in the docs can still be refused. Retrying cannot
                    # help: the model will not appear three seconds later.
                    #
                    # This is the same fault the 429 handling was written to
                    # fix, in a different disguise: treating a permanent
                    # failure as a transient one burned 36 seconds per cycle.
                    # Fall forward through the configured alternatives instead,
                    # and remember the working one for the rest of the run.
                    if resp.status_code == 404:
                        nxt = self._next_fallback_model()
                        if nxt:
                            logger.warning(
                                "Gemini %s: model %s unavailable for this key (404) — trying %s",
                                kind, self.model, nxt,
                            )
                            self.model = nxt
                            GeminiReviewService._resolved_model = nxt
                            continue
                        reason = (
                            f"no usable Gemini model for this key; tried "
                            f"{', '.join(self._attempted_models)}"
                        )
                        GeminiReviewService._model_unavailable = True
                        GeminiReviewService._model_unavailable_reason = reason
                        logger.error("Gemini %s: %s", kind, reason)
                        return self._unavailable(reason, kind=kind)
                    if resp.status_code == 429:
                        quota_kind, retry_after = self._classify_429(resp)
                        if quota_kind == "daily":
                            reason = (
                                f"daily quota exhausted (RPD) on model {self.model}; "
                                "resets at midnight Pacific"
                            )
                            GeminiReviewService._daily_quota_exhausted = True
                            GeminiReviewService._daily_quota_reason = reason
                            logger.warning(
                                "Gemini %s: %s — skipping remaining LLM calls this run",
                                kind, reason,
                            )
                            return self._unavailable(reason, kind=kind)
                        last_error = "HTTP 429 (rate limited)"
                        if attempt < self.max_retries:
                            # Honour the server's advice; otherwise back off
                            # exponentially rather than linearly.
                            delay = retry_after if retry_after is not None else self.retry_delay * (2 ** (attempt - 1))
                            delay = max(1, min(int(delay), self.max_retry_delay))
                            logger.warning(
                                "Gemini %s attempt %d/%d rate limited (RPM) — retry in %ds",
                                kind, attempt, self.max_retries, delay,
                            )
                            _time.sleep(delay)
                            continue
                        return self._unavailable(last_error, kind=kind)
                    if attempt < self.max_retries:
                        delay = self.retry_delay * attempt
                        logger.warning("Gemini %s attempt %d/%d failed: %s — retry in %ds", kind, attempt, self.max_retries, last_error, delay)
                        _time.sleep(delay)
                        continue
                    return self._unavailable(last_error, kind=kind)
                text = self._extract_text(resp.json())
                if not text:
                    last_error = "Empty API result"
                    if attempt < self.max_retries:
                        delay = self.retry_delay * attempt
                        logger.warning("Gemini %s attempt %d/%d: empty result — retry in %ds", kind, attempt, self.max_retries, delay)
                        _time.sleep(delay)
                        continue
                    return self._unavailable(last_error, kind=kind)
                parsed = json.loads(text)
                parsed["available"] = True
                parsed["kind"] = kind
                parsed["suppressed"] = False
                parsed["quality"] = self._quality_label(parsed, kind)
                parsed["attempts"] = attempt
                if self._is_generic_output(parsed, kind):
                    parsed["available"] = False
                    parsed["suppressed"] = True
                    parsed["suppress_reason"] = "generic_or_insufficient_output"
                    logger.info("Gemini %s review suppressed: generic/insufficient output (attempt %d)", kind, attempt)
                return parsed
            except Exception as e:
                last_error = str(e)
                if attempt < self.max_retries:
                    delay = self.retry_delay * attempt
                    logger.warning("Gemini %s attempt %d/%d exception: %s — retry in %ds", kind, attempt, self.max_retries, last_error, delay)
                    _time.sleep(delay)
                else:
                    logger.error("Gemini %s failed after %d attempts: %s", kind, self.max_retries, last_error)
        return self._unavailable(last_error, kind=kind)

    def _extract_text(self, data: Dict[str, Any]) -> str:
        candidates = data.get("candidates") or []
        for c in candidates:
            for p in (c.get("content") or {}).get("parts") or []:
                if p.get("text"): return str(p.get("text"))
        return ""

    # ---- compact payload builders (macro-aware) ----

    def _compact_signal_payload(self, p: Dict[str, Any]) -> Dict[str, Any]:
        d = p.get("decision", {}) or {}
        s = d.get("signal", {}) or {}
        ar = p.get("all_results", {}) or {}
        # Macro extraction — try 3 locations
        macro = (
            (ar.get("news", {}) or {}).get("macro_direction")
            or (ar.get("macro_fundamental", {}) or {}).get("macro_direction")
            or {}
        )
        # Agent votes summary
        votes_summary = {}
        for name in ("technical", "multitimeframe", "classical", "smc", "price_action", "auction_flow"):
            r = ar.get(name, {}) or {}
            if r:
                votes_summary[name] = {
                    "signal": r.get("signal") or r.get("direction"),
                    "confidence": r.get("confidence", 0)
                }
        return {
            "symbol": p.get("symbol"),
            "decision": d.get("decision"),
            "confidence": d.get("confidence"),
            "entry": s.get("entry", {}).get("price"),
            "sl": s.get("stop_loss"),
            "tp1": s.get("tp1"),
            "tp2": s.get("tp2"),
            "rr": s.get("rr_ratio"),
            # --- macro block ---
            "macro_direction": {
                "bias": macro.get("bias"),
                "confidence": macro.get("confidence"),
                "score": macro.get("score"),
                "drivers": (macro.get("drivers") or [])[:4],
                "confidence_breakdown": macro.get("confidence_breakdown"),
                "invalidations": (macro.get("invalidations") or [])[:2],
            } if macro else None,
            "daily_bias": {
                "bias": (ar.get("daily_bias", {}) or {}).get("bias"),
                "confidence": (ar.get("daily_bias", {}) or {}).get("confidence"),
            },
            "technical_regime": (ar.get("technical", {}) or {}).get("market_regime"),
            "news_status": (ar.get("news", {}) or {}).get("market_status"),
            "agent_votes": votes_summary,
            "quality": d.get("quality"),
            "current_price": p.get("current_price"),
        }

    def _compact_market_payload(self, p: Dict[str, Any]) -> Dict[str, Any]:
        d = p.get("decision", {}) or {}
        ar = p.get("all_results", {}) or {}
        macro = (
            (ar.get("news", {}) or {}).get("macro_direction")
            or (ar.get("macro_fundamental", {}) or {}).get("macro_direction")
            or {}
        )
        tech = ar.get("technical", {}) or {}
        return {
            "symbol": p.get("symbol"),
            "price": p.get("current_price"),
            "bias": (ar.get("daily_bias", {}) or {}).get("bias"),
            "rsi": tech.get("rsi"),
            "macro_direction": {
                "bias": macro.get("bias"),
                "confidence": macro.get("confidence"),
                "score": macro.get("score"),
                "drivers": macro.get("drivers", [])[:3],
                "breakdown": macro.get("confidence_breakdown"),
            } if macro else None,
            "technical_regime": tech.get("market_regime"),
            "session": (ar.get("session", {}) or {}).get("current_session"),
        }

    def _compact_news_payload(self, p: Dict[str, Any]) -> Dict[str, Any]:
        news = p.get("news", {}) or {}
        macro = news.get("macro_direction") or {}
        # also try top-level macro_agent
        if not macro and p.get("macro_agent"):
            macro = (p.get("macro_agent", {}) or {}).get("macro_direction", {}) or {}
        return {
            "symbol": p.get("symbol"),
            "news": {
                "market_status": news.get("market_status"),
                "can_trade": news.get("can_trade"),
                "risk_level": news.get("risk_level"),
                "upcoming_events": (news.get("upcoming_events") or [])[:2],
            },
            "macro_direction": {
                "bias": macro.get("bias"),
                "confidence": macro.get("confidence"),
                "drivers": (macro.get("drivers") or [])[:3],
            } if macro else None,
            "daily_bias": p.get("daily_bias"),
        }

    def _compact_macro_payload(self, p: Dict[str, Any]) -> Dict[str, Any]:
        """Full macro agent output for standalone macro review."""
        # Accept either raw macro_direction or full agent result
        md = p.get("macro_direction") or p.get("macro") or p
        # if it's the full agent result, unwrap
        if "macro_direction" in md and isinstance(md.get("macro_direction"), dict):
            md = md["macro_direction"]
        return {
            "bias": md.get("bias"),
            "confidence": md.get("confidence"),
            "score": md.get("score"),
            "drivers": md.get("drivers", []),
            "reason_codes": md.get("reason_codes", [])[:8],
            "evidence": md.get("evidence", [])[:6],
            "confidence_breakdown": md.get("confidence_breakdown", {}),
            "invalidations": md.get("invalidations", []),
            "data_quality": md.get("data_quality", {}),
            "warnings": md.get("warnings", []),
            "summary": md.get("summary"),
        }

    def _compact_post_news_payload(self, p: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "symbol": p.get("symbol", "XAU/USD"),
            "event_name": p.get("event_name"),
            "actual": p.get("actual"),
            "forecast": p.get("forecast"),
            "previous": p.get("previous"),
            "impact_tier": p.get("impact_tier"),
            "minutes_since_release": p.get("minutes_since_release"),
            "current_price": p.get("current_price"),
            "price_before_event": p.get("price_before_event"),
            "price_change_since_event": p.get("price_change_since_event"),
            "dxy_macro": p.get("dxy_macro"),
            "session": p.get("session"),
        }

    def _compact_learning_payload(self, p: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "date": p.get("report_date"),
            "wr": p.get("overall_win_rate"),
            "total": p.get("total_trades_analyzed"),
            "rr_efficiency": p.get("rr_efficiency"),
            "session_breakdown": p.get("session_breakdown"),
            "day_of_week_breakdown": p.get("day_of_week_breakdown"),
            "news_proximity": p.get("news_proximity"),
            "regime_fit": p.get("regime_fit"),
        }

    def _compact_daily_report_payload(self, p: Dict[str, Any]) -> Dict[str, Any]:
        stats = p.get("stats") or {}
        return {
            "date": p.get("report_date"),
            "stats": stats,
            "net": p.get("closed_net_points"),
            "rr_efficiency": p.get("rr_efficiency") or stats.get("rr_efficiency"),
            "session_breakdown": p.get("session_breakdown") or stats.get("session_breakdown"),
            "news_proximity": p.get("news_proximity") or stats.get("news_proximity"),
            "regime_fit": p.get("regime_fit") or stats.get("regime_fit"),
        }

    def _compact_weekly_report_payload(self, p: Dict[str, Any]) -> Dict[str, Any]:
        stats = p.get("stats") or {}
        return {
            "period": p.get("period"),
            "stats": stats,
            "time_of_week_breakdown": p.get("time_of_week_breakdown") or stats.get("time_of_week"),
            "rr_distribution": p.get("rr_distribution") or stats.get("rr_efficiency"),
            "environment_fit": p.get("environment_fit") or stats.get("regime_fit"),
            "news_proximity": p.get("news_proximity") or stats.get("news_proximity"),
        }

    def _quality_texts(self, payload: Dict[str, Any]) -> List[str]:
        values: List[str] = []
        for key in (
            "summary", "reason", "trading_advice", "adjustment", "strategic_pivot",
            "edge_efficiency", "market_regime", "verdict", "market_bias", "action",
            "macro_verdict", "primary_driver", "invalidation", "key_insight", "recommendation",
            "macro_alignment",
        ):
            value = payload.get(key)
            if value is not None:
                values.append(str(value))
        for key in ("key_points", "summary_bullets", "key_lessons", "strategic_points"):
            items = payload.get(key) or []
            if isinstance(items, list):
                values.extend(str(item) for item in items if item is not None)
        return [" ".join(v.split()).strip() for v in values if str(v).strip()]

    def _is_generic_output(self, payload: Dict[str, Any], kind: str = "generic") -> bool:
        texts = self._quality_texts(payload)
        if not texts:
            return True
        # Only check texts long enough to indicate a truly generic response.
        # Short values like "N/A", "Hold", "Neutral" are normal JSON values,
        # not signs the entire output is generic.
        long_texts = [t for t in texts if len(t) >= 12]
        generic_markers = (
            "insufficient data", "not enough data", "cannot determine",
            "unable to determine", "more data is needed",
        )
        if long_texts:
            combined_long = " ".join(long_texts).lower()
            if any(marker in combined_long for marker in generic_markers):
                return True
        meaningful = [t for t in texts if len(t) >= 12 and len(set(t.lower().split())) >= 3]
        if kind in {"daily", "weekly", "learning", "news", "macro"} and not meaningful:
            return True
        return False

    def _quality_label(self, payload: Dict[str, Any], kind: str = "generic") -> str:
        return "generic" if self._is_generic_output(payload, kind) else "ok"

    def _unavailable(self, reason: str, kind: str = "generic") -> Dict[str, Any]:
        return {"available": False, "summary": reason, "reason": reason, "kind": kind, "suppressed": False}

def get_gemini_review_service(config: Dict[str, Any] | None = None) -> GeminiReviewService:
    return GeminiReviewService(config)
