"""A rejected API key must be latched, never retried, and loudly reported.

Observed live 2026-08-17 (VPS log demo_analysis.log lines 25331-25333 and
again 25468-25470): every Path-2 Gemini confirmation returned

    Gemini signal attempt 1/3 failed: HTTP 401 — retry in 3s
    Gemini signal attempt 2/3 failed: HTTP 401 — retry in 6s

A 401 means the CREDENTIAL is refused — the same key that was leaked on a
public GitHub repository earlier this month. Retrying cannot help, and the
model-fallback list cannot help either, because every model shares the same
key. Each affected cycle burned ~9 seconds sleeping between doomed retries.

This mirrors the 404 (missing model) and 429-RPD (daily quota) latches: a
permanent failure is recognised on the first response, remembered for the
rest of the process, and surfaced with an actionable reason.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import pytest

import services.llm_review as llm

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))

_UNAUTHORIZED = json.dumps({
    "error": {"code": 401, "message": "API key not valid. Please pass a valid API key.",
              "status": "UNAUTHENTICATED"}
})


class _Response:
    def __init__(self, status, body, headers=None):
        self.status_code = status
        self.text = body
        self.headers = headers or {}

    def json(self):
        return json.loads(self.text)


class _Session:
    """Always refuses the key; records every request made."""

    def __init__(self, status=401):
        self.status = status
        self.calls = 0

    def post(self, url, **_kwargs):
        self.calls += 1
        return _Response(self.status, _UNAUTHORIZED)


@pytest.fixture(autouse=True)
def _reset():
    llm.GeminiReviewService.reset_quota_state()
    yield
    llm.GeminiReviewService.reset_quota_state()


def _service(session):
    service = llm.GeminiReviewService(CONFIG)
    service.api_key = "leaked-and-revoked-key"
    service.enabled = True
    service.session = session
    return service


def _payload():
    return {"symbol": "XAU/USD", "decision": {}, "all_results": {}}


def test_a_401_is_never_retried() -> None:
    """One request, no sleeps: the key will not heal itself in 3 seconds."""
    session = _Session(status=401)
    service = _service(session)

    started = time.time()
    result = service.review_signal(_payload())
    elapsed = time.time() - started

    assert result["available"] is False
    assert session.calls == 1, f"retried a rejected key {session.calls} times"
    assert elapsed < 1.0, f"slept {elapsed:.1f}s on a permanent auth error"


def test_a_403_is_treated_the_same_way() -> None:
    session = _Session(status=403)
    service = _service(session)

    assert service.review_signal(_payload())["available"] is False
    assert session.calls == 1


def test_the_rejection_is_latched_for_the_whole_run() -> None:
    """Later calls short-circuit without touching the network again."""
    session = _Session(status=401)
    service = _service(session)

    service.review_signal(_payload())
    service.analyze_market_context(_payload())
    service.review_signal(_payload())

    assert session.calls == 1, "a latched auth rejection went back to the API"


def test_the_reason_tells_the_operator_what_to_do() -> None:
    """The message must name the fix (rotate GEMINI_API_KEY), not just the code."""
    service = _service(_Session(status=401))

    result = service.review_signal(_payload())

    assert "401" in str(result.get("reason"))
    assert "GEMINI_API_KEY" in str(result.get("reason"))


def test_the_model_fallback_list_is_not_walked_on_auth_errors() -> None:
    """404 walks the model list; 401 must not — the key fails on every model."""
    session = _Session(status=401)
    service = _service(session)

    service.analyze_market_context(_payload())

    assert session.calls == 1


def test_reset_clears_the_latch_for_a_new_process() -> None:
    session = _Session(status=401)
    service = _service(session)
    service.review_signal(_payload())
    assert llm.GeminiReviewService._auth_rejected is True

    llm.GeminiReviewService.reset_quota_state()

    assert llm.GeminiReviewService._auth_rejected is False
    assert llm.GeminiReviewService._auth_rejected_reason == ""
