import json
from pathlib import Path

from shadow_market_architect.entries import EntryArchitect,EntryMethod,VirtualBroker,VirtualOrderStatus
from shadow_market_architect.models import Horizon,ScenarioSide,ScenarioSnapshot,ScenarioStatus

ROOT=Path(__file__).resolve().parents[2]
CFG=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
ECFG={"gold_risk_points":300,"gold_min_risk_points":270,"gold_max_risk_points":400,"tp1_rr":1,"tp2_rr":2,"tp3_rr":3}

def scenario(symbol='XAU/USD',side='BUY',playbook='TREND_PULLBACK',entry=4400,events=None):
 return ScenarioSnapshot(symbol=symbol,side=ScenarioSide(side),horizon=Horizon.INTRADAY,
  playbook=playbook,status=ScenarioStatus.APPROACHING,known_at='2026-09-05T10:00:00Z',
  evidence={"events":events or {}},config_version='phase5',family_id='fam',
  entry_low=entry-1,entry_high=entry+1,preferred_entry=entry)

def test_limit_plan_has_symmetric_three_target_geometry():
 a=EntryArchitect(ECFG,CFG)
 buy=a.plan(scenario(side='BUY'));sell=a.plan(scenario(side='SELL'))
 assert buy.method==sell.method==EntryMethod.LIMIT
 assert (buy.stop_loss,buy.tp1,buy.tp2,buy.tp3)==(4370,4430,4460,4490)
 assert (sell.stop_loss,sell.tp1,sell.tp2,sell.tp3)==(4430,4370,4340,4310)

def test_canonical_instrument_ratios_scale_risk_points():
 a=EntryArchitect(ECFG,CFG)
 assert a.plan(scenario('XAU/USD',entry=4400)).risk_points==300
 assert a.plan(scenario('WTI/USD',entry=80)).risk_points==150
 assert a.plan(scenario('EUR/USD',entry=1.1)).risk_points==450
 # R33.5: USD/JPY runs its own x2.0 law -> gold 300 x 2.0 = 600
 assert a.plan(scenario('USD/JPY',entry=150)).risk_points==600

def test_breakout_and_reversal_wait_until_mandatory_events_complete():
 a=EntryArchitect(ECFG,CFG)
 wait=a.plan(scenario(playbook='BREAKOUT_RETEST'))
 assert wait.method==EntryMethod.PENDING_TRIGGER and wait.decision=='WATCH_TRIGGER'
 ready=a.plan(scenario(playbook='BREAKOUT_RETEST',events={"break_acceptance":1,"retest":1,"failed_reclaim":1}))
 assert ready.method==EntryMethod.BREAKOUT_RETEST_MARKET
 rev=a.plan(scenario(playbook='EXTREME_REVERSAL',events={"sweep_or_failed_auction":1,"reclaim":1,"micro_structure_shift":1}))
 assert rev.method==EntryMethod.SWEEP_RECLAIM_MARKET

def test_no_zone_and_no_trade_playbook_pass_without_inventing_entry():
 a=EntryArchitect(ECFG,CFG)
 s=scenario(playbook='NO_TRADE_OBSERVATION');
 p=a.plan(s)
 assert p.method==EntryMethod.PASS
 nozone=ScenarioSnapshot(symbol='XAU/USD',side=ScenarioSide.BUY,horizon=Horizon.SCALP,
  playbook='TREND_PULLBACK',status=ScenarioStatus.WATCH,known_at=s.known_at,evidence={},config_version='x')
 assert a.plan(nozone).method==EntryMethod.PASS

def test_limit_uses_executable_side_and_never_fills_before_creation():
 a=EntryArchitect(ECFG,CFG);o=a.virtual_order(a.plan(scenario(side='BUY')));b=VirtualBroker(CFG)
 assert not b.on_tick(o,bid=4399,ask=4399.5,known_at='2026-09-05T09:59:59Z')
 assert b.on_tick(o,bid=4399,ask=4399.5,known_at='2026-09-05T10:00:01Z')
 assert o.fill_price==4399.5 and o.status==VirtualOrderStatus.FILLED
 sell=a.virtual_order(a.plan(scenario(side='SELL')))
 assert not b.on_tick(sell,bid=4399.9,ask=4400.1,known_at='2026-09-05T10:00:01Z')
 assert b.on_tick(sell,bid=4400.2,ask=4400.4,known_at='2026-09-05T10:00:02Z')

def test_market_fill_records_spread_slippage_and_reprices_all_levels():
 cfg={**ECFG,"market_slippage_points":2};a=EntryArchitect(cfg,CFG)
 p=a.plan(scenario(side='BUY',playbook='BREAKOUT_RETEST',events={"break_acceptance":1,"retest":1,"failed_reclaim":1}))
 o=a.virtual_order(p);b=VirtualBroker(CFG,cfg)
 assert b.on_tick(o,bid=4401,ask=4401.5,known_at='2026-09-05T10:00:01Z')
 assert o.fill_price==4401.7 and o.spread_points==5 and o.slippage_points==2
 assert o.stop_loss==4371.7 and o.tp1==4431.7 and o.tp2==4461.7

def test_pending_trigger_never_fills_as_if_it_were_a_broker_order():
 a=EntryArchitect(ECFG,CFG);o=a.virtual_order(a.plan(scenario(playbook='EXTREME_REVERSAL')))
 assert not VirtualBroker(CFG).on_tick(o,bid=5000,ask=5001,known_at='2026-09-05T11:00:00Z')
 assert o.status==VirtualOrderStatus.PENDING
