import json
from pathlib import Path
import pytest
from shadow_market_architect.entries import EntryArchitect,VirtualBroker
from shadow_market_architect.models import Horizon,ScenarioSide,ScenarioSnapshot,ScenarioStatus
from shadow_market_architect.positions import VirtualPositionManager,VirtualPositionStatus
ROOT=Path(__file__).resolve().parents[2];CFG=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
PCFG={"gold_be_lock_points":40,"scale_out_fractions":{"tp1":.5,"tp2":.25}}
def position(symbol='XAU/USD',side='BUY',entry=4400):
 s=ScenarioSnapshot(symbol=symbol,side=ScenarioSide(side),horizon=Horizon.INTRADAY,playbook='TREND_PULLBACK',status=ScenarioStatus.READY,known_at='2026-09-05T10:00:00Z',evidence={},config_version='p6',family_id='fam',entry_low=entry-1,entry_high=entry+1,preferred_entry=entry)
 a=EntryArchitect({"gold_risk_points":300,"gold_min_risk_points":270,"gold_max_risk_points":400},CFG);o=a.virtual_order(a.plan(s));q=(entry-1,entry) if side=='BUY' else (entry,entry+1)
 assert VirtualBroker(CFG).on_tick(o,bid=q[0],ask=q[1],known_at='2026-09-05T10:00:01Z')
 return VirtualPositionManager(CFG,PCFG).open_from_order(o)
def test_buy_partial_accounting_be_is_profit_lock_and_final_result():
 m=VirtualPositionManager(CFG,PCFG);p=position();m.on_tick(p,bid=4430,ask=4430.2,known_at='2026-09-05T10:01:00Z')
 assert p.closed_fraction==.5 and p.realized_points==150 and p.stop_loss>=4404 and p.protected
 assert next(e for e in p.events if e['event']=='STOP_TO_PROFIT')['locked_points']==40
 m.on_tick(p,bid=4460,ask=4460.2,known_at='2026-09-05T10:02:00Z');assert p.closed_fraction==.75 and p.realized_points==300
 m.on_tick(p,bid=4490,ask=4490.2,known_at='2026-09-05T10:03:00Z')
 assert p.status==VirtualPositionStatus.CLOSED and p.closed_at and p.realized_points==525 and p.result=='WIN'
def test_sell_is_symmetric_and_stop_result_uses_profit_sign():
 m=VirtualPositionManager(CFG,PCFG);p=position(side='SELL');m.on_tick(p,bid=4369.8,ask=4370,known_at='2026-09-05T10:01:00Z')
 assert p.stop_loss<=4396 and p.realized_points==150
 assert next(e for e in p.events if e['event']=='STOP_TO_PROFIT')['locked_points']==40
 m.on_tick(p,bid=4395.8,ask=4396,known_at='2026-09-05T10:02:00Z')
 assert p.status==VirtualPositionStatus.CLOSED and p.result=='WIN' and p.realized_points>0
def test_normal_stop_loss_and_no_open_status_with_closed_at():
 m=VirtualPositionManager(CFG,PCFG);p=position();m.on_tick(p,bid=4369,ask=4369.2,known_at='2026-09-05T10:01:00Z')
 assert p.status==VirtualPositionStatus.CLOSED and p.closed_at and p.result=='LOSS' and p.realized_points==-310
def test_trailing_never_moves_backward_and_new_stop_not_hit_same_tick():
 m=VirtualPositionManager(CFG,PCFG);p=position();m.on_tick(p,bid=4430,ask=4430.2,known_at='2026-09-05T10:01:00Z');old=p.stop_loss
 m.on_tick(p,bid=4460,ask=4460.2,known_at='2026-09-05T10:02:00Z');assert p.status==VirtualPositionStatus.OPEN and p.stop_loss>=old
 raised=p.stop_loss;m.on_tick(p,bid=4455,ask=4455.2,known_at='2026-09-05T10:03:00Z');assert p.stop_loss==raised
def test_each_instrument_uses_own_be_and_trailing_numbers():
 m=VirtualPositionManager(CFG,PCFG)
 # R33.5: USD/JPY BE lock follows its own x2.0 law -> 40 x 2.0 = 80
 expected={'XAU/USD':40,'WTI/USD':20,'EUR/USD':60,'USD/JPY':80}
 entries={'XAU/USD':4400,'WTI/USD':80,'EUR/USD':1.1,'USD/JPY':150}
 for sym,lock in expected.items():
  p=position(sym,entry=entries[sym]);pv=__import__('utils.instruments',fromlist=['point_size']).point_size(sym,CFG)
  m.on_tick(p,bid=p.tp1,ask=p.tp1+pv,known_at='2026-09-05T10:01:00Z')
  assert next(e for e in p.events if e['event']=='STOP_TO_PROFIT')['locked_points']==lock
def test_only_one_open_position_per_symbol_side_but_opposite_side_allowed():
 m=VirtualPositionManager(CFG,PCFG);buy=position();
 # Reuse a separately filled order through helper's resulting order fields is unnecessary: guard existing directly.
 s=position(side='SELL');assert s.side=='SELL'
 with pytest.raises(ValueError):
  # construct a filled BUY order by following the same path
  q=position();m.open_from_order(type('O',(),dict(status=__import__('shadow_market_architect.entries',fromlist=['VirtualOrderStatus']).VirtualOrderStatus.FILLED,filled_at=q.opened_at,fill_price=q.entry_price,stop_loss=q.stop_loss,tp1=q.tp1,tp2=q.tp2,tp3=q.tp3,order_id='x',scenario_id='x',family_id='x',symbol=q.symbol,side=q.side))(),[buy])
