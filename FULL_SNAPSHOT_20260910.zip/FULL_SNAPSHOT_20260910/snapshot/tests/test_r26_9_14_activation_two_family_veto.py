# -*- coding: utf-8 -*-
"""R26.9.14 — the pending-ACTIVATION veto counts DISTINCT FAMILIES, not names.

Operator law (2026-09-02: "فيتو تفعيل المعلّقة — نعم اجعله من عائلتين
الوكيلين"): a pending order is cancelled at touch only when >= 2 qualified
opponents come from TWO DIFFERENT families. The family doctrine
(2026-08-17): technical, multitimeframe and classical read the same trend
inputs and are wrong TOGETHER — the whole trend family opposing is ONE
correlated voice, not a flip. Unlisted voices (macro_fundamental,
oil_macro, auction_flow) are each their own family.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from agents.open_trades_manager import OpenTradesManager

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
# R35: this file tests the legacy lane explicitly
CONFIG.setdefault("pending_freshness", {}).setdefault("activation_book_gate", {})["enabled"] = True
CONFIG.setdefault("pending_freshness", {}).setdefault("activation_macro_gate", {})["enabled"] = False


def _manager(**gate_overrides):
    cfg = json.loads(json.dumps(CONFIG))
    gate = cfg.setdefault("pending_freshness", {}).setdefault("activation_book_gate", {})
    gate.update({"enabled": True, "min_opposing_agents": 2,
                 "cancel_orphaned_add": True})
    gate.update(gate_overrides)
    return OpenTradesManager(cfg)


def _book(agents: dict, symbol: str = "XAU/USD") -> dict:
    book = dict(agents)
    book["symbol"] = symbol
    return book


def test_whole_trend_family_opposing_is_one_voice_not_a_flip():
    """technical + multitimeframe + classical (ALL trend family) oppose a
    BUY pending: one correlated voice -> NO veto, the pending activates."""
    book = _book({
        "technical": {"direction": "SELL", "confidence": 70.0},
        "multitimeframe": {"direction": "SELL", "confidence": 69.0},
        "classical": {"direction": "SELL", "confidence": 68.0},
        "smc": {"direction": "WAIT", "confidence": 40.0},
        "price_action": {"direction": "WAIT", "confidence": 40.0},
    })
    verdict = _manager()._activation_book_veto(book, "BUY")
    assert verdict["veto"] is False
    assert verdict["opponents"] == ["technical", "multitimeframe", "classical"]
    assert verdict["opponent_families"] == ["trend"], (
        "three trend readers are ONE family — the evidence row must say so")


def test_two_families_opposing_cancel_the_activation():
    """technical (trend) + smc (structure) oppose: TWO families -> veto."""
    book = _book({
        "technical": {"direction": "SELL", "confidence": 70.0},
        "smc": {"direction": "SELL", "confidence": 68.0},
        "multitimeframe": {"direction": "WAIT", "confidence": 40.0},
        "classical": {"direction": "WAIT", "confidence": 40.0},
        "price_action": {"direction": "WAIT", "confidence": 40.0},
    })
    verdict = _manager()._activation_book_veto(book, "BUY")
    assert verdict["veto"] is True
    assert verdict["opponents"] == ["technical", "smc"]
    assert verdict["opponent_families"] == ["structure", "trend"]


def test_macro_voice_is_its_own_family():
    """technical (trend) + the routed macro verdict (own family) oppose a
    GOLD pending: two families -> veto."""
    book = _book({
        "technical": {"direction": "SELL", "confidence": 70.0},
        "macro_fundamental": {"direction": "SELL", "confidence": 66.0},
        "multitimeframe": {"direction": "WAIT", "confidence": 40.0},
        "classical": {"direction": "WAIT", "confidence": 40.0},
        "smc": {"direction": "WAIT", "confidence": 40.0},
        "price_action": {"direction": "WAIT", "confidence": 40.0},
    }, symbol="XAU/USD")
    verdict = _manager()._activation_book_veto(book, "BUY")
    assert verdict["veto"] is True
    assert "macro_fundamental" in verdict["opponents"]
    assert verdict["opponent_families"] == ["macro_fundamental", "trend"]


def test_single_opponent_still_cannot_veto():
    """One qualified opponent (whatever family) is not a flip — unchanged."""
    book = _book({
        "smc": {"direction": "SELL", "confidence": 80.0},
        "technical": {"direction": "WAIT", "confidence": 40.0},
    })
    verdict = _manager()._activation_book_veto(book, "BUY")
    assert verdict["veto"] is False
