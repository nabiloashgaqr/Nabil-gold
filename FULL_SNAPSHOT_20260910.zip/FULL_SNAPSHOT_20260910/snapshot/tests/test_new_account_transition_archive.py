import json
from pathlib import Path

import pytest

from scripts import reset_for_new_demo_account as reset


def put(root: Path, name: str, value):
    path = root / "storage" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def test_dry_plan_reports_rows_without_changing_files(tmp_path):
    rows = [{"id": "old", "status": "CLOSED"}]
    put(tmp_path, "trades.json", rows)
    assert reset.plan(tmp_path)["trade_rows"] == 1
    assert json.loads((tmp_path / "storage/trades.json").read_text()) == rows


def test_transition_refuses_active_rows_without_explicit_broker_ack(tmp_path):
    put(tmp_path, "trades.json", [{"id": "live", "status": "OPEN"}])
    with pytest.raises(RuntimeError, match="active/pending"):
        reset.transition(tmp_path, regenerate_dashboard=False)
    assert json.loads((tmp_path / "storage/trades.json").read_text())[0]["id"] == "live"


def test_transition_archives_then_cleans_dashboard_book_and_preserves_learning(tmp_path):
    old = [{"id": "closed", "status": "TP2_HIT"}, {"id": "pending", "status": "PENDING"}]
    put(tmp_path, "trades.json", old)
    put(tmp_path, "decision_audit.json", [{"reason": "old review evidence"}])
    put(tmp_path, "daily_report.json", {"old": True})
    put(tmp_path, "learning_history.json", [{"lesson": "keep"}])
    put(tmp_path, "path_performance/trades.json", [{"path": 2, "result": "WIN"}])

    archive = reset.transition(tmp_path, archive_active=True, regenerate_dashboard=False)

    assert json.loads((archive / "trades.json").read_text()) == old
    manifest = json.loads((archive / "MANIFEST.json").read_text())
    assert manifest["trade_rows"] == 2
    assert manifest["active_rows_archived"] == 1
    assert manifest["files"]["trades.json"]["sha256"]
    assert json.loads((tmp_path / "storage/trades.json").read_text()) == []
    assert json.loads((tmp_path / "storage/decision_audit.json").read_text()) == []
    assert json.loads((tmp_path / "storage/daily_report.json").read_text()) == {}
    assert json.loads((tmp_path / "storage/learning_history.json").read_text()) == [{"lesson": "keep"}]
    assert json.loads((tmp_path / "storage/path_performance/trades.json").read_text())[0]["result"] == "WIN"
    marker = json.loads((tmp_path / "storage/account_transition.json").read_text())
    assert marker["old_trade_rows"] == 2
