from services.admission_discipline_gates import path23_two_family_block

CFG={"signal_requirements":{"family_diversity":{"path23_require_two_families":True}}}

def decision(path="PATH_3_TWO_AGENT_GEMINI"):
 return {"decision":"SELL","execution_path_id":path,"votes":{"SELL":[
  {"agent":"technical"},{"agent":"multitimeframe"},{"agent":"classical"}]}}

def test_three_trend_agents_plus_gemini_is_refused():
 reason=path23_two_family_block(decision(),CFG,{})
 assert reason and "families=['trend']" in reason

def test_trend_plus_structure_is_admitted():
 d=decision(); d["votes"]["SELL"]=[{"agent":"technical"},{"agent":"smc"}]
 assert path23_two_family_block(d,CFG,{}) is None

def test_external_auction_does_not_count_as_second_core_family():
 d=decision(); d["votes"]["SELL"]=[{"agent":"technical"},{"agent":"auction_flow"}]
 assert path23_two_family_block(d,CFG,{}) is not None
