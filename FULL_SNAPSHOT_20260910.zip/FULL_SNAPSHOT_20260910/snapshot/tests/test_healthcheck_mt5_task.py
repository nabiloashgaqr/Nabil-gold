from pathlib import Path


def test_healthcheck_treats_detached_mt5_terminal_as_task_worker():
    """ONLOGON wrapper may be Ready while terminal64.exe remains healthy."""
    root = Path(__file__).resolve().parents[1]
    body = (root / "scripts" / "system_healthcheck.py").read_text(encoding="utf-8")
    assert "^terminal64\\.exe$" in body
    assert '"SS_MT5Terminal": "terminal64.exe"' in body
    assert 'marker == name' in body
