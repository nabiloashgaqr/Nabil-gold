"""R25.7-D (2026-08-28, operator order) — the WTI+FX liquidity stop band.

"اجعل ستوب الفوركس والنفط كله بين 230 نقطة وحد اعلي 330 نقطة حسب السيولة
وليس ثابت" — applied with GOLD'S OWN liquidity addition (2026-08-07b):
liquidity closer than 160 points is swept noise, the stop sits the exact
gold +70 buffer beyond the first qualified level, cap 330  =>  [230, 330],
liquidity-dependent, never fixed. And everything the band moves follows the
gold law: TP1 = 0.8R, TP2 = 2x TP1, trailing 150/40, breakeven +150,
partial 50% at TP1, lots solved for [$225, $400].
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from agents.open_trades_manager import OpenTradesManager
from scripts.run_tick_manager import corrected_execution_stop
from services.risk_usd import lot_for_stop, usd_loss
from utils.instruments import DEFAULT_INSTRUMENTS, config_for_instrument, point_size
from utils.trading_rules import stop_rule, trailing_params

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))

FIVE = ("WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")


def _sym_cfg(symbol: str) -> dict:
    inst = next(i for i in CONFIG["instruments"] if i["symbol"] == symbol)
    return config_for_instrument(CONFIG, inst)


@pytest.mark.parametrize("symbol", FIVE)
def test_stop_band_matches_the_r26_1_symbol_table(symbol):
    """R26.1: WTI factor 0.5 -> [135,200]; FX factor 1.5 -> [405,600] (R26.9.3).

    floor = noise floor + the gold-style safety buffer; cap from the table."""
    from tests._band_table import FLOOR, CAP, NOISE, BUFFER
    rule = stop_rule(_sym_cfg(symbol))
    assert rule["min_liquidity_points"] == float(NOISE[symbol])
    assert rule["safety_buffer_points"] == float(BUFFER[symbol])
    assert rule["max_stop_points"] == float(CAP[symbol])
    assert rule["min_liquidity_points"] + rule["safety_buffer_points"] == float(FLOOR[symbol])
    inst = next(i for i in CONFIG["instruments"] if i["symbol"] == symbol)
    assert inst["min_sl_distance_points"] == int(CAP[symbol])


def test_gold_law_is_untouched():
    rule = stop_rule(_sym_cfg("XAU/USD"))
    assert (rule["min_liquidity_points"], rule["safety_buffer_points"],
            rule["max_stop_points"]) == (200.0, 70.0, 400.0)


@pytest.mark.parametrize("symbol", FIVE)
@pytest.mark.parametrize("planned_at", ("floor", "cap"))
def test_corrected_stops_clamp_into_the_new_band(symbol, planned_at):
    """The fill-truth normalizer clamps into the per-symbol law band."""
    from tests._band_table import FLOOR, CAP
    planned = FLOOR[symbol] if planned_at == "floor" else CAP[symbol]
    pv = point_size(symbol, CONFIG)
    px = {"WTI/USD": 71.39, "EUR/USD": 1.08123, "GBP/USD": 1.35504,
          "USD/CAD": 1.39022, "USD/JPY": 160.153}[symbol]
    entry = px + 50 * pv                      # BUY filled above the plan
    planned_stop = entry - planned * pv
    narrow_stop = entry - (planned - 100) * pv  # fill shrank the distance
    rule = stop_rule(_sym_cfg(symbol))
    stop, required, _actual = corrected_execution_stop(
        "BUY", entry, narrow_stop, entry + 2 * pv, planned_stop,
        min_liquidity_points=rule["min_liquidity_points"],
        safety_buffer_points=rule["safety_buffer_points"],
        cap_points=rule["max_stop_points"],
        point_value=pv,
        digits=3 if symbol.endswith('JPY') else (2 if pv >= 0.01 else 5),
    )
    assert stop is not None
    pts = (entry - stop) / pv
    from tests._band_table import FLOOR, CAP
    assert FLOOR[symbol] - 1e-6 <= pts <= CAP[symbol] + 1e-6


def test_lot_snap_rounds_up_so_the_floor_is_never_missed():
    """raw 1.1739 lots: round() shipped $269.10 (< $225); ceil ships $271.40."""
    lot = lot_for_stop("EUR/USD", 405, CONFIG)
    assert usd_loss("EUR/USD", 405, lot) >= 225.0


@pytest.mark.parametrize("symbol", FIVE)
def test_one_lot_covers_the_whole_band_inside_225_400(symbol):
    """The lot solved at the floor keeps the loss legal even at the cap."""
    from tests._band_table import FLOOR, CAP
    lot = lot_for_stop(symbol, FLOOR[symbol], CONFIG)
    assert 225.0 - 1e-6 <= usd_loss(symbol, FLOOR[symbol], lot) <= 420.0 + 1e-6
    assert usd_loss(symbol, CAP[symbol], lot) <= 420.0 + 1e-6


def test_gold_reference_lots_unchanged():
    assert lot_for_stop("XAU/USD", 270, CONFIG) == pytest.approx(0.10)
    assert lot_for_stop("XAU/USD", 400, CONFIG) == pytest.approx(0.07)


@pytest.mark.parametrize("symbol", FIVE)
def test_targets_share_gold_ratios_while_distances_scale(symbol):
    """R26.1: the RR ratios are the gold law for every symbol (TP1=0.8R,
    TP2=2xTP1); only the point-DISTANCE window (max_beyond) scales with the
    symbol's stop factor (wider FX band -> wider pool-search window)."""
    targets = _sym_cfg(symbol)["trading_rules"]["targets"]
    gold = _sym_cfg("XAU/USD")["trading_rules"]["targets"]
    assert targets["min_tp1_rr"] == gold["min_tp1_rr"] == 0.8
    assert targets["tp2_multiple"] == gold["tp2_multiple"] == 2.0
    from tests._band_table import CAP
    factor = CAP[symbol] / 400.0
    assert abs(targets["max_beyond_points"] - round(200 * factor)) <= 1.0


@pytest.mark.parametrize("symbol", FIVE)
def test_trailing_and_breakeven_scale_with_the_symbol_factor(symbol):
    # Management numbers are self-consistent and carried by both the default
    # instrument and the resolved config (values scale by the symbol factor).
    inst = DEFAULT_INSTRUMENTS[symbol]
    trail = inst["trading_rules"]["trailing"]
    assert trail["distance_points"] == inst["trailing_distance"]
    assert trail["step_points"] == inst["trailing_step"]
    rule = trailing_params(_sym_cfg(symbol))
    assert rule["distance_points"] == float(inst["trailing_distance"])
    assert rule["step_points"] == float(inst["trailing_step"])


@pytest.mark.parametrize("symbol", FIVE)
def test_partial_close_stays_the_gold_50pct_at_tp1(symbol):
    """الإغلاق الجزئي: 50% عند TP1 — قانون الذهب، موحّد لكل الرموز."""
    inst = next(i for i in CONFIG["instruments"] if i["symbol"] == symbol)
    mgr = OpenTradesManager(config_for_instrument(CONFIG, inst))
    row = {"id": "T", "symbol": symbol, "type": "BUY", "status": "OPEN",
           "entry_price": 1.0, "stop_loss": 0.9, "tp1": 2.0, "tp2": 3.0,
           "sl_moved_to_entry": False, "updates_sent": []}
    params = mgr._management_params(row, symbol)
    assert params["partial_close_fraction"] == pytest.approx(0.5)
    assert params["auto_be"] is True
    assert float(params["min_breakeven_rr"]) == pytest.approx(0.5)


@pytest.mark.parametrize("symbol,entry,sl,solved", [
    ("XAU/USD", 4395.00, 4365.00, 0.09),   # 300 pts -> 225/3000 = 0.09
    ("WTI/USD", 71.39, 68.79, 0.11),       # 260 pts -> 225/2600 = 0.1038 -> 0.11
    ("EUR/USD", 1.08123, 1.07893, 1.18),   # 230 pts -> 1.1739 -> 1.18
    ("GBP/USD", 1.35504, 1.35244, 1.04),   # 260 pts -> 225/2600 = 1.0385 -> 1.04
    ("USD/CAD", 1.39022, 1.38760, 1.44),   # 250 pts -> 225/179.8 = 1.5015 -> 1.51
    ("USD/JPY", 160.153, 159.883, 1.61),   # 225 pts -> 225/168.6 = 1.6016 -> 1.61
])
def test_executor_ships_the_solved_lot(monkeypatch, symbol, entry, sl, solved):
    """The ORDER carries the law's volume, not the config default 0.1."""
    from services.mt5_executor import Mt5DemoExecutor

    ex = Mt5DemoExecutor.__new__(Mt5DemoExecutor)
    ex.config = CONFIG
    ex.lot = 0.10
    assert ex._order_lot(symbol, entry, sl) == pytest.approx(solved)


def test_executor_falls_back_to_config_lot_without_a_stop():
    from services.mt5_executor import Mt5DemoExecutor

    ex = Mt5DemoExecutor.__new__(Mt5DemoExecutor)
    ex.config = CONFIG
    ex.lot = 0.10
    assert ex._order_lot("EUR/USD", 1.08123, 0.0) == pytest.approx(0.10)
