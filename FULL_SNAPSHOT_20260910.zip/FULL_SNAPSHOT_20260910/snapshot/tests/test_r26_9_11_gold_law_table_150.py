# -*- coding: utf-8 -*-
"""R26.9.11 — the COMPLETE gold law table, 150 as the add base.

Operator correction (2026-09-02): "الذهب الأساسي وقس عليه الباقي: ستوبه بين
200/70/400، ونقل ستوب للدخول بعد +150 (تقريبا 0.5R)، وتعزيز -150، والهدف
الأول عند 0.8R". The add trigger's gold base is 150 — the SERVER config had
drifted to 225 and an analysis table propagated that stale number. This file
freezes the whole management law in one table, measured on the SHIPPED
config through the live resolvers:

                       gold (x1.0)   WTI (x0.5)    FX (x1.5)
  stop rule            200/70/400    100/35/200    300/105/600
  stop band            [225,400]     [135,200]     [405,600]
  breakeven (+)        150           75            225
  add trigger (-)      150           75            225  (= 27 pips)
  TP1 rung             0.8R          0.8R          0.8R
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from utils.helpers import load_config
from utils.instruments import config_for_instrument
from utils.trading_rules import trailing_params, stop_rule_for_symbol, target_ratios_for_symbol
from scripts.run_analysis import _scaled_add_trigger

FX4 = ("EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")
FX_FACTOR = {"EUR/USD": 1.5, "GBP/USD": 1.5, "USD/CAD": 1.5, "USD/JPY": 2.0}  # R33.5
SIX = ("XAU/USD", "WTI/USD") + FX4


def _cfg(symbol: str) -> dict:
    return config_for_instrument(load_config(), {"symbol": symbol})


# ── the base itself: the shipped config carries the gold law, 150 ──────────

def test_shipped_config_carries_the_gold_add_base_150():
    fr = ((load_config().get("order_execution") or {}).get("fixed_risk")) or {}
    assert fr.get("scale_in_trigger_points") == 150, (
        "the gold law's add base is -150 (operator 2026-08-18 'خُفضت من 200' "
        "and 2026-09-02 'تعزيز -150'); a stale 225 must never ship again")


# ── the complete table ─────────────────────────────────────────────────────

def test_stop_rules_table():
    want = {"XAU/USD": (200.0, 70.0, 400.0), "WTI/USD": (100.0, 35.0, 200.0)}
    for s in FX4:
        want[s] = (200.0 * FX_FACTOR[s], 70.0 * FX_FACTOR[s], 400.0 * FX_FACTOR[s])  # R33.5 factor
    for sym, (lo, buf, cap) in want.items():
        r = stop_rule_for_symbol(_cfg(sym), sym)
        assert (r["min_liquidity_points"], r["safety_buffer_points"], r["max_stop_points"]) == (lo, buf, cap), sym


def test_breakeven_table():
    want = {"XAU/USD": 150.0, "WTI/USD": 75.0}
    for s in FX4:
        want[s] = 150.0 * FX_FACTOR[s]
    for sym, v in want.items():
        assert trailing_params(_cfg(sym))["early_breakeven_points"] == v, sym


def test_add_trigger_table():
    want = {"XAU/USD": 150.0, "WTI/USD": 75.0}
    for s in FX4:
        want[s] = 150.0 * FX_FACTOR[s]
    for sym, v in want.items():
        # empty fr -> the config's own value flows through the engine's default
        assert _scaled_add_trigger({}, _cfg(sym), sym) == v, sym


def test_add_trigger_in_pips_forex_is_27():
    # 225 points on a 0.0001-point FX pair = 27 pips — a LIVING add window
    # against a 405-600 pt stop (the JPY 04:42 trade had a real window).
    from utils.instruments import point_size
    assert _scaled_add_trigger({}, _cfg("USD/JPY"), "USD/JPY") * point_size("USD/JPY") * 10 == 300.0 * 0.001 * 10  # R33.5: 30 pips


def test_tp1_rung_is_08r_everywhere():
    for sym in SIX:
        r = target_ratios_for_symbol(_cfg(sym), sym)
        assert r["min_tp1_rr"] == 0.8, sym


def test_gold_numbers_are_byte_identical_through_the_merged_shape():
    """The same law in BOTH config shapes (raw and instrument-merged) — the
    R26.9.6 lesson applied to the whole table."""
    raw = dict(load_config())
    raw["symbol"] = "XAU/USD"
    assert _scaled_add_trigger({}, raw, "XAU/USD") == 150.0
    assert trailing_params(raw)["early_breakeven_points"] == 150.0
