# -*- coding: utf-8 -*-
"""R26.9.13 — macro flip-speed law (operator order 2026-09-03
«قلب سريع طبعا وغير متهور منضبط يكتشف الانقلاب مبكرا ولا يظل نائما يوم كامل»).

Covers the three deliverables:
  1. the fix        — macro_context_core two-eye law + agent v2 weights
                      (fast flip, dedup Fed, disagreement cap, age decay)
  2. the measurement— sim_macro_flip_replay A/B helpers (no network here:
                      synthetic series only)
  3. the discipline — veto bar 60 vs confirm bar 55, refresh triggers
                      (stale_age, calendar_window), flip-flop dampening
"""

import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from agents.macro_fundamental_agent import MacroFundamentalAgent  # noqa: E402
from services.macro_context_core import build_context as core_build  # noqa: E402
from services.thesis_consensus import count_veto_opponents  # noqa: E402

NOW = datetime(2026, 9, 2, 15, 0, tzinfo=timezone.utc)


def _series(base: float = 100.0, hours: int = 130, drift: float = 0.0,
            vol: float = 0.0, seed: int = 7):
    """Deterministic hourly series ending at NOW-1h (5d+ of lookback)."""
    pts, x = [], 0.0
    step = (timedelta(hours=1))
    t0 = NOW - timedelta(hours=hours)
    for i in range(hours + 1):
        x = base * (1.0 + drift * i + vol * (((i * 37) % 11) - 5) / 100.0)
        pts.append((t0 + step * i, round(x, 4)))
    return pts


def _basket(drift_usd: float):
    """FX pairs that aggregate into DXY (inverse for xxx/USD quotes)."""
    return {
        "EURUSD=X": _series(100.0, drift=-drift_usd),
        "USDJPY=X": _series(150.0, drift=drift_usd),
        "GBPUSD=X": _series(100.0, drift=-drift_usd),
        "USDCAD=X": _series(1.35, drift=drift_usd),
        "AUDUSD=X": _series(100.0, drift=-drift_usd),
    }


def _crush_last(series_map, hours=24, pct_per_point=0.004, window=None):
    """Cumulative selloff: point k inside the window is scaled by
    (1-pct)^k so the whole leg really moves ~-pct*hours over the window."""
    for sym, inverse in [("EURUSD=X", True), ("USDJPY=X", False),
                         ("GBPUSD=X", True), ("USDCAD=X", False),
                         ("AUDUSD=X", True)]:
        pts = series_map.get(sym)
        if not pts:
            continue
        span = window or timedelta(hours=hours)
        k = 0
        for i, (t, c) in enumerate(pts):
            if t > NOW - span:
                f = (1.0 - pct_per_point) ** k
                pts[i] = (t, round(c * (f if not inverse else 1.0 / f), 6))
                k += 1


def _agent(symbol="XAU/USD", **kw):
    a = MacroFundamentalAgent({"symbol": symbol}, **kw)
    a._now_fn = lambda: NOW
    return a


# ── 1. core law: the two eyes ──────────────────────────────────────────────

def test_v2_fast_eye_flips_within_24h_while_5d_still_down():
    """THE incident: a 24h dollar selloff on top of a 5d dollar uptrend.
    v1 (5d net) must stay 'rising'; v2's fast eye must say 'falling'."""
    series = _basket(drift_usd=0.001)          # +0.10%/h up-drift = strong 5d up
    _crush_last(series)                        # ... then a real 24h dollar selloff
    c1 = core_build(series, as_of=NOW, v1_compat=True)
    c2 = core_build(series, as_of=NOW, v1_compat=False)
    assert c1["dxy_trend"] == "rising"          # the sleeping eye
    assert c2["dxy_trend"] == "falling"         # the 24h eye
    assert c2["dxy_trend_slow"] == "rising"     # slow eye keeps context
    assert c2["dominant_disagreement"] is True


def test_v1_compat_keeps_fixed_threshold_and_slow_labels():
    series = _basket(drift_usd=0.0)             # flat basket
    series["^TNX"] = _series(4.2, drift=0.0005)
    c1 = core_build(series, as_of=NOW, v1_compat=True)
    c2 = core_build(series, as_of=NOW, v1_compat=False)
    assert c1["schema"] == "v1" and c2["schema"] == "v2"
    # v1 wrapper block the deployed agent/tests expect (yields present ->
    # the core macro fields are not missing)
    mf = c1["data_quality"]["missing_fields"]
    assert isinstance(mf, list) and "us10y_trend" not in mf and "dxy_trend" not in mf
    # v1 fidelity: deployed never populated the curve spread
    assert c1.get("yield_curve_spread") in (None,)


def test_v2_ecb_read_from_crosses_breaks_circularity():
    """Euro firm vs BOTH EURGBP and EURJPY -> HAWKISH ECB without EURUSD."""
    series = _basket(0.0)
    series["EURGBP=X"] = _series(100.0, drift=0.0015)   # euro up vs GBP
    series["EURJPY=X"] = _series(160.0, drift=0.0015)   # euro up vs JPY
    c2 = core_build(series, as_of=NOW, v1_compat=False)
    assert str(c2["ecb_tone"]).lower() == "hawkish"


# ── 2. agent v2: weights, dedup, cap, decay ────────────────────────────────

def test_fed_deduplicated_eur_no_longer_double_counts():
    """v1: hawkish Fed + rising 10y voted ~3.8 combined; v2 dedups to <2.5."""
    # v1 derived Fed tone FROM the 10y series and let it vote AGAIN at
    # 1.8 alongside yields 2.0 (the same story, 3.8 strong). v2 leads with
    # the yield leg (research: real rates drive gold) and trims the Fed
    # echo to a secondary 1.2 — same dollar-bloc total, no double vote.
    ctx = {"generated_at": NOW.isoformat().replace("+00:00", "Z"),
           "dxy_trend": "RISING", "dxy_trend_slow": "RISING",
           "us10y_trend": "RISING", "us10y_trend_slow": "RISING",
           "fed_tone": "hawkish"}
    v1 = _agent("XAU/USD", v1_compat=True).macro_direction(dict(ctx))
    v2 = _agent("XAU/USD").macro_direction(dict(ctx))
    b1, b2 = v1["confidence_breakdown"], v2["confidence_breakdown"]
    assert abs(b2["central_banks"]) < abs(b1["central_banks"])      # echo trimmed
    assert abs(b2["yields"]) > abs(b1["yields"])                    # yields lead
    assert abs(v2["score"]) <= abs(v1["score"]) + 0.05              # bloc not inflated
    assert v2["score"] < 0 and v1["score"] < 0                      # same side


def test_dominant_disagreement_caps_below_confirm_and_veto_bars():
    ctx = {"generated_at": NOW.isoformat().replace("+00:00", "Z"),
           "schema": "v2", "dominant_disagreement": True,
           "dxy_trend": "RISING", "dxy_trend_slow": "RISING",
           "us10y_trend": "RISING", "us10y_trend_slow": "RISING",
           "fed_tone": "hawkish"}
    out = _agent("USD/JPY").macro_direction(ctx)
    assert out["confidence"] <= 54               # below 55 confirm AND 60 veto


def test_age_decay_punishes_stale_reads():
    fresh = {"schema": "v2", "dxy_trend": "FALLING", "fed_tone": "dovish",
             "us10y_trend": "FALLING",
             "generated_at": (NOW - timedelta(minutes=10)).isoformat().replace("+00:00", "Z")}
    stale = dict(fresh, generated_at=(NOW - timedelta(hours=5)).isoformat().replace("+00:00", "Z"))
    a = _agent("XAU/USD")
    f, s = a.macro_direction(fresh), a.macro_direction(stale)
    assert f["decay_factor"] == 1.0 and s["decay_factor"] == 0.60  # 5h bucket
    assert f["confidence"] > s["confidence"]
    assert s["schema"] == "v2" and s["age_minutes"] == pytest.approx(300.0, abs=1.0)


def test_stale_hard_veto_dies_but_fresh_direction_survives():
    """The exact incident mechanics: a 5h-stale bearish read loses its veto;
    a fresh bearish read on real displacement keeps it."""
    def ctx(minutes):
        return {"schema": "v2", "dxy_trend": "RISING", "us10y_trend": "RISING",
                "fed_tone": "hawkish", "risk_sentiment": "risk_on",
                "oil_trend": "falling",
                "generated_at": (NOW - timedelta(minutes=minutes)).isoformat().replace("+00:00", "Z")}
    a = _agent("XAU/USD")
    stale = a.macro_direction(ctx(300))
    fresh = a.macro_direction(ctx(5))
    assert stale["bias"] == "BEARISH_GOLD" and stale["confidence"] < 60
    assert fresh["bias"] == "BEARISH_GOLD" and fresh["confidence"] >= 60


def test_gold_flips_bullish_on_dollar_selloff_same_day():
    """Fast eye: 24h of dollar-down + yields-down flips gold NOW, not in 5d."""
    series = _basket(drift_usd=0.0005)
    _crush_last(series, hours=20, pct_per_point=0.004)
    series["^TNX"] = _series(4.2, drift=-0.002)         # yields falling 5d
    series["DX-Y.NYB"] = _series(100.0, drift=-0.001)
    ctx = core_build(series, as_of=NOW, v1_compat=False)
    out = _agent("XAU/USD").macro_direction(ctx)
    assert out["bias"] == "BULLISH_GOLD" and out["confidence"] >= 55
    assert "MACRO_DXY_BULLISH_GOLD" in out["reason_codes"]


# ── 3. discipline: veto bar, refresh triggers, flip-flops ──────────────────

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def _book(macro_conf):
    return {"technical": {"direction": "WAIT", "confidence": 30},
            "multitimeframe": {"direction": "WAIT", "confidence": 30},
            "classical": {"direction": "WAIT", "confidence": 30},
            "smc": {"direction": "WAIT", "confidence": 30},
            "price_action": {"direction": "WAIT", "confidence": 30},
            "macro_fundamental": {"direction": "SELL", "confidence": macro_conf}}


def test_veto_bar_is_60_confirm_bar_stays_55():
    # 59% counter-macro: NO veto anymore (the old bar was 55)
    assert "macro_fundamental" not in count_veto_opponents("BUY", _book(59), CONFIG)["opponents"]
    # 60% still vetoes
    assert "macro_fundamental" in count_veto_opponents("BUY", _book(60), CONFIG)["opponents"]
    # the CONFIRMATION bar is a separate, unchanged lane: 55
    from services.thesis_consensus import _external_confirmation
    conf = _external_confirmation(
        "BUY", {"macro_fundamental": {"direction": "BUY", "confidence": 56}}, CONFIG)
    assert conf and conf["source"] == "macro" and conf["allow"] is True
    conf54 = _external_confirmation(
        "BUY", {"macro_fundamental": {"direction": "BUY", "confidence": 54}}, CONFIG)
    assert not (conf54 or {}).get("allow")


def test_flip_flop_discipline_v2_not_chattier_than_v1():
    """Alternating dollar noise must not make v2 flip more often than v1 —
    the disagreement cap + halved legs keep it at least as steady."""
    flips = {"v1": 0, "v2": 0}
    for mode in flips:
        agent = _agent("XAU/USD", v1_compat=(mode == "v1"))
        prev = None
        for h in range(0, 130, 6):              # every 6h across 5d+
            series = _basket(drift_usd=0.0004)
            # alternate the last-24h direction each step (regime noise)
            inv = (h // 6) % 2 == 0
            if inv:
                _crush_last(series)
            else:
                for sym in series:
                    series[sym] = [(t, c) for t, c in series[sym]]  # keep 5d up-drift
            series["^TNX"] = _series(4.2, drift=0.0002)
            ctx = core_build(series, as_of=NOW, v1_compat=(mode == "v1"))
            bias = agent.macro_direction(ctx)["bias"]
            side = 1 if bias.startswith("BULLISH") else (-1 if bias.startswith("BEARISH") else 0)
            if prev is not None and side and prev and side != prev:
                flips[mode] += 1
            if side:
                prev = side
    assert flips["v2"] <= flips["v1"] + 1       # never chattier (±1 tolerance)


def test_refresh_triggers_stale_age(tmp_path, monkeypatch):
    """A 70-minute-old context must trigger a rebuild even with no shock."""
    from scripts import run_analysis as ra
    storage = tmp_path / "storage"
    (storage / "macro").mkdir(parents=True)
    ctx_file = storage / "macro_context.json"
    ctx_file.write_text(json.dumps(
        {"generated_at": (datetime.now(timezone.utc) - timedelta(minutes=70)
                          ).isoformat().replace("+00:00", "Z")}), encoding="utf-8")
    built = []

    class _P:
        def __init__(self, cfg):
            pass

        def build_context(self):
            built.append(1)
            return {"ok": True, "generated_at": datetime.now(timezone.utc).isoformat()}

    monkeypatch.setattr("services.macro_data_provider.MacroDataProvider", _P)
    candles = [{"high": 10, "low": 9, "close": 9.5 + (i % 3) * 0.1,
                "open": 9.4, "volume": 100} for i in range(30)]

    class _DB:
        def save_macro_context(self, c):
            built.append("saved")

    marker = tmp_path / "marker.json"
    ra._maybe_refresh_macro_context(
        {"timeframes": {"15m": {"data": candles}}}, {}, _DB(), marker_path=marker,
        context_path=ctx_file,
        events_path=storage / "macro" / "economic_events.json")
    assert built == [1, "saved"]
    assert json.loads(marker.read_text(encoding="utf-8"))["reason"] == "stale_age"


def test_refresh_triggers_calendar_window(tmp_path, monkeypatch):
    """A tier-1 release 10 minutes ahead must trigger a rebuild."""
    from scripts import run_analysis as ra
    storage = tmp_path / "storage"
    (storage / "macro").mkdir(parents=True)
    (storage / "macro" / "economic_events.json").write_text(json.dumps([
        {"event": "US CPI", "currency": "USD", "impact": "HIGH",
         "date": (datetime.now(timezone.utc) + timedelta(minutes=10)
                  ).isoformat().replace("+00:00", "Z")}]), encoding="utf-8")
    # fresh context (not stale) so ONLY the calendar path can fire
    (storage / "macro_context.json").write_text(json.dumps(
        {"generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")}),
        encoding="utf-8")
    built = []

    class _P:
        def __init__(self, cfg):
            pass

        def build_context(self):
            built.append(1)
            return {"ok": True}

    monkeypatch.setattr("services.macro_data_provider.MacroDataProvider", _P)
    candles = [{"high": 10, "low": 9, "close": 9.5, "open": 9.4, "volume": 100}] * 30

    class _DB:
        def save_macro_context(self, c):
            built.append("saved")

    marker = tmp_path / "marker.json"
    ra._maybe_refresh_macro_context(
        {"timeframes": {"15m": {"data": candles}}},
        {"macro_refresh": {"cooldown_minutes": 0}}, _DB(), marker_path=marker,
        context_path=storage / "macro_context.json",
        events_path=storage / "macro" / "economic_events.json")
    assert built == [1, "saved"]
    assert json.loads(marker.read_text(encoding="utf-8"))["reason"] == "calendar_window"


def test_no_trigger_when_fresh_and_quiet(tmp_path, monkeypatch):
    """Fresh context + no shock + no calendar => NO rebuild (respect the
    provider's own hourly cadence)."""
    from scripts import run_analysis as ra
    storage = tmp_path / "storage"
    (storage / "macro").mkdir(parents=True)
    (storage / "macro_context.json").write_text(json.dumps(
        {"generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")}),
        encoding="utf-8")
    built = []

    class _P:
        def __init__(self, cfg):
            pass

        def build_context(self):
            built.append(1)
            return {"ok": True}

    monkeypatch.setattr("services.macro_data_provider.MacroDataProvider", _P)
    candles = [{"high": 10, "low": 9, "close": 9.5, "open": 9.4, "volume": 100}] * 30

    class _DB:
        def save_macro_context(self, c):
            built.append("saved")

    ra._maybe_refresh_macro_context(
        {"timeframes": {"15m": {"data": candles}}}, {}, _DB(),
        marker_path=tmp_path / "marker.json",
        context_path=storage / "macro_context.json",
        events_path=storage / "macro" / "economic_events.json")
    assert built == []


def test_replay_helpers_slice_without_lookahead():
    from scripts.sim_macro_flip_replay import _slice
    pts = [(NOW - timedelta(hours=h), float(h)) for h in range(5, 0, -1)]
    got = _slice(pts, NOW - timedelta(hours=3), NOW - timedelta(hours=1))
    assert [c for _, c in got] == [2.0, 1.0]    # strictly inside (lo, hi]
