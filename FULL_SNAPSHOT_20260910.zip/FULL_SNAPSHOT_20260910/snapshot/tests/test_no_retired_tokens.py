# -*- coding: utf-8 -*-
"""R25.12: the tree-wide retired-token lint + the model-law consistency.

Three guarantees, enforced on EVERY suite run:

1. NO retired model id appears anywhere in the code tree (production code,
   scripts, tests, config.json). Prose documents (.md/.txt) are outside the
   law's scope on purpose - the law governs CODE and CONFIG, not prose.
   Runtime state (storage/) is excluded: historical files on a live VPS are
   purged by the R25.11 load/persist law, not by this lint.

2. config.json's llm_review chain IS the law (services/model_law.py):
   model == PRIMARY_MODEL and fallback_models == FALLBACK_MODELS.

3. The review service's built-in defaults ARE the law (single source).

A new retired id is added exactly once - to RETIRED_PATTERNS below - and
the whole tree is guarded from that moment on.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

from services.model_law import (  # noqa: E402
    ENFORCEMENT_FILES,
    FALLBACK_MODELS,
    PRIMARY_MODEL,
    PRODUCTION_CHAIN,
)
import services.llm_review as llm  # noqa: E402

#: Retired ids, as precise regexes so the ALLOWED ids can never match.
#:  - gemini-flash-latest            (the legacy alias)
#:  - gemini-2.5*                    (the whole previous generation)
#:  - bare "gemini-flash"            (legacy tier name, no generation)
#:  - bare "gemini-flash-lite"       (legacy tier name, no generation)
RETIRED_PATTERNS = (
    re.compile(r"gemini-flash-latest"),
    re.compile(r"gemini-2\.5"),
    re.compile(r"gemini-flash(?![\-0-9a-z])"),
    re.compile(r"gemini-flash-lite(?![\-0-9a-z])"),
)

#: Directories never scanned (runtime state, caches, foreign trees).
#: "backups" holds frozen byte-exact rollback copies of PRE-FIX code written
#: by the installers themselves (R33.5/R34/R35/snapshot runs) - an archive,
#: not the shipped tree; scanning it re-flags files already fixed live.
EXCLUDED_DIRS = {
    "storage", "__pycache__", ".pytest_cache", ".git", ".venv", "venv",
    "build", "dist", "out", "target", "coverage", "node_modules", "_portable",
    ".ruff_cache", ".mypy_cache", "backups", "releases",
}


def _iter_py_files():
    # The enforcement files (this lint, the packaging tool, its unit test)
    # are EXEMPT: they must name the retired ids to build the patterns that
    # forbid them (the wanted-poster, not a hiding place). Exemption is by
    # RELATIVE path from the shared law list, so staged/simulated copies of
    # the tree are exempt identically. Every other .py is scanned.
    for path in ROOT.rglob("*.py"):
        if path.relative_to(ROOT).as_posix() in ENFORCEMENT_FILES:
            continue
        if any(part in EXCLUDED_DIRS for part in path.relative_to(ROOT).parts):
            continue
        if path.name.endswith(".bak.py") or ".bak" in path.name:
            continue
        yield path


def _read_text_safe(path: Path) -> str | None:
    """VPS 2026-08-29 live lesson: a locked / access-denied file on the
    operator's box (held by a service or with a broken ACL) raised
    PermissionError from a plain read_text and killed the whole suite.
    A LOCKED file is an ops condition, not a retired-token violation:
    skip it with a printed warning so the lint judges the READABLE tree."""
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except (PermissionError, OSError) as exc:
        print(f"  [lint-skip] unreadable (locked?) file: "
              f"{path.relative_to(ROOT)} -> {exc.__class__.__name__}")
        return None


def test_no_retired_model_tokens_anywhere_in_the_tree():
    offenders = []
    for path in _iter_py_files():
        text = _read_text_safe(path)
        if text is None:
            continue
        for lineno, line in enumerate(text.splitlines(), start=1):
            for pat in RETIRED_PATTERNS:
                if pat.search(line):
                    offenders.append("%s:%d: %s" % (
                        path.relative_to(ROOT), lineno, line.strip()[:90]))
                    break
    assert not offenders, (
        "retired model ids crept back into the tree (%d place(s)):\n  %s"
        % (len(offenders), "\n  ".join(offenders[:12])))


def test_config_json_carries_no_retired_token_and_matches_the_law():
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    raw = (ROOT / "config.json").read_text(encoding="utf-8")
    for pat in RETIRED_PATTERNS:
        assert not pat.search(raw), (
            "config.json contains a retired model id (%r)" % pat.pattern)
    llm_cfg = cfg.get("llm_review") or {}
    assert llm_cfg.get("model") == PRIMARY_MODEL
    assert list(llm_cfg.get("fallback_models") or []) == list(FALLBACK_MODELS)
    # and nothing outside the law's universe is configured
    assert llm_cfg.get("model") in PRODUCTION_CHAIN
    assert set(llm_cfg.get("fallback_models") or []) <= set(PRODUCTION_CHAIN)


def test_review_service_defaults_are_the_law():
    assert tuple(llm.GeminiReviewService.DEFAULT_FALLBACK_MODELS) == tuple(PRODUCTION_CHAIN)
