import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
"""Comprehensive unit tests for multi-instrument parity across Gold, WTI, and 4 Forex pairs.

Verifies:
1. Precision & decimal conversions (5-digit FX vs 3-digit JPY vs 2-digit Gold/Oil).
2. Institutional point conversion factors (400-pt stop, 150-pt trailing, 200-pt BE, TP1/TP2).
3. Instrument-specific Macro Fundamental analysis (USD Base vs Quote rules, Rate differentials, Safe-haven flows).
4. SMC, Classical, Technical, Price Action, Auction Flow, Session Planner, and Risk Management across all 6 symbols.
5. End-to-end execution and plan creation for all enabled instruments.
"""

import os
import sys
from copy import deepcopy
import pytest

# Ensure project root is on sys.path for direct pytest invocation
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.classical_agent import ClassicalAgent
from agents.auction_flow_agent import AuctionFlowAgent
from agents.technical_agent import TechnicalAgent
from agents.multitimeframe_agent import MultiTimeframeAgent
from agents.decision_agent import DecisionAgent
from agents.macro_fundamental_agent import MacroFundamentalAgent
from agents.price_action_agent import PriceActionAgent
from agents.smc_agent import SMCAgent
from agents.risk_management_agent import RiskManagementAgent
from services.session_planner import SessionPlannerService
from services.thesis_consensus import evaluate_directional_admission
from utils.helpers import load_config
from utils.instruments import (
    enabled_instruments, config_for_instrument, normalize_symbol,
    point_size, price_decimals, round_price, format_price, price_to_points, points_to_price,
)


def _make_candles(base_price, step, count=80):
    candles = []
    p = base_price
    for i in range(count):
        o = p
        c = p + step
        h = max(o, c) + abs(step) * 0.5
        l = min(o, c) - abs(step) * 0.5
        candles.append({"time": 1700000000 + i * 300, "open": o, "high": h, "low": l, "close": c, "volume": 100})
        p = c
    return candles


def test_instrument_metadata_and_decimal_rules():
    cfg = load_config()
    symbols_and_decimals = {
        "EUR/USD": 5,
        "GBP/USD": 5,
        "USD/CAD": 5,
        "USD/JPY": 3,
        "XAU/USD": 2,
        "WTI/USD": 2,
    }
    for sym, expected_dec in symbols_and_decimals.items():
        assert price_decimals(sym, cfg) == expected_dec

    assert point_size("EUR/USD", cfg) == 0.00001
    assert point_size("GBP/USD", cfg) == 0.00001
    assert point_size("USD/CAD", cfg) == 0.00001
    assert point_size("USD/JPY", cfg) == 0.001
    assert point_size("XAU/USD", cfg) == 0.10
    assert point_size("WTI/USD", cfg) == 0.01

    assert format_price(1.085423, "EUR/USD", cfg) == "1.08542"
    assert format_price(1.276541, "GBP/USD", cfg) == "1.27654"
    assert format_price(1.365419, "USD/CAD", cfg) == "1.36542"
    assert format_price(155.1234, "USD/JPY", cfg) == "155.123"
    assert format_price(4650.555, "XAU/USD", cfg) == "4650.56"
    assert format_price(74.555, "WTI/USD", cfg) == "74.56"


def test_macro_fundamental_rules_all_symbols():
    cfg = load_config()
    
    strong_usd = {
        "dxy_trend": "UP",
        "us10y_trend": "UP",
        "fed_tone": "HAWKISH",
        "risk_sentiment": "RISK_OFF",
    }
    
    def isolated_macro_config(sym):
        """Build a deterministic unit-test config.

        The production flip guard deliberately persists per-symbol state in
        storage/macro/flip_guard.json.  A parity unit test must neither read
        that live state nor write back to it; otherwise its verdict depends on
        which macro direction production committed during the previous four
        hours.  Economic-event files are disabled for the same isolation
        reason: this test exercises only the explicit synthetic context below.
        """
        inst = next(i for i in enabled_instruments(cfg) if i["symbol"] == sym)
        icfg = deepcopy(config_for_instrument(cfg, inst))
        icfg.setdefault("macro_stall", {})["flip_guard_persist"] = False
        icfg.setdefault("macro_economic_events", {})["enabled"] = False
        return icfg

    # USD Base pairs rise on strong USD
    for sym in ("USD/CAD", "USD/JPY"):
        res = MacroFundamentalAgent(isolated_macro_config(sym)).analyze(
            {"macro_context": strong_usd}
        )
        assert res["signal"] == "BUY"
        assert res["trade_bias"] == "BUY"
        
    # USD Quote pairs drop on strong USD
    for sym in ("EUR/USD", "GBP/USD", "XAU/USD"):
        res = MacroFundamentalAgent(isolated_macro_config(sym)).analyze(
            {"macro_context": strong_usd}
        )
        assert res["signal"] == "SELL"
        assert res["trade_bias"] == "SELL"


def test_session_planner_all_instruments():
    cfg = load_config()
    sample_prices = {
        "EUR/USD": 1.08500,
        "GBP/USD": 1.27500,
        "USD/CAD": 1.36500,
        "USD/JPY": 155.200,
        "XAU/USD": 4650.00,
        "WTI/USD": 75.00,
    }
    planner = SessionPlannerService(cfg)
    
    for sym, curr_p in sample_prices.items():
        inst = [i for i in enabled_instruments(cfg) if i["symbol"] == sym][0]
        icfg = config_for_instrument(cfg, inst)
        dec = price_decimals(sym, icfg)
        step = points_to_price(10, sym, icfg)
        # R26.1: ATR must scale with the symbol's own stop band so the
        # liquidity-derived targets clear the R:R grade floor. Forex now
        # carries a 600-900 point band; a hard-coded 180-point ATR left the
        # synthetic setup at R:R 1.6 (grade D -> rejected). Use the cap.
        from utils.trading_rules import stop_rule
        cap_pts = stop_rule(icfg).get("max_stop_points", 400)
        realistic_atr = points_to_price(float(cap_pts), sym, icfg)
        candles = _make_candles(curr_p, step, 80)
        
        # Test generation of zones and execution maps
        agent_results = {
            "symbol": sym,
            "current_price": curr_p,
            "classical": {"direction": "BUY", "confidence": 75, "key_levels": {"nearest_support": curr_p - step * 5, "nearest_resistance": curr_p + step * 20}},
            "smc": {"direction": "BUY", "confidence": 75, "dealing_range": {"low": curr_p - step * 10, "high": curr_p + step * 25}},
            "technical": {"direction": "BUY", "confidence": 75, "atr": realistic_atr},
            "multitimeframe": {"direction": "BUY", "confidence": 80, "alignment": "FULL", "setup_type": "TREND_CONTINUATION"},
            "price_action": {"direction": "BUY", "confidence": 70},
            "daily_bias": {"bias": "BULLISH"},
        }
        
        risk_agent = RiskManagementAgent(icfg)
        risk_res = risk_agent.evaluate(agent_results)
        
        assert risk_res.get("approved") is True
        assert risk_res["entry"]["price"] is not None
        assert risk_res["stop_loss"]["price"] is not None
        assert risk_res["take_profit"]["tp1"]["price"] is not None
        
        # Validate that price formatting respects exact decimal count
        formatted_entry = format_price(risk_res["entry"]["price"], sym, icfg)
        assert len(formatted_entry.split(".")[1]) == dec
        formatted_sl = format_price(risk_res["stop_loss"]["price"], sym, icfg)
        assert len(formatted_sl.split(".")[1]) == dec
        formatted_tp = format_price(risk_res["take_profit"]["tp1"]["price"], sym, icfg)
        assert len(formatted_tp.split(".")[1]) == dec


def test_points_to_price_inversion_all_instruments():
    cfg = load_config()
    for inst in enabled_instruments(cfg):
        sym = inst["symbol"]
        pts = 250.0
        price_dist = points_to_price(pts, sym, cfg)
        converted_pts = price_to_points(price_dist, sym, cfg)
        assert abs(pts - converted_pts) < 1e-6
