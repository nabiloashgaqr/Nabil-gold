# -*- coding: utf-8 -*-
"""R26.4 (2026-09-01): macro symmetry on the thesis-exit mirror.

The hard macro veto (R26.2, admission_discipline_gates.counter_macro_block)
refuses an ENTRY against a confident macro verdict on every path except
PATH 9 / scalp. The thesis-exit mirror used to run only
``evaluate_directional_admission`` -- never that veto -- so a macro-ALIGNED
open position could be closed by a Path 3/5 agent flip that the entry gate
would itself have refused as counter-macro.

R26.4 reuses the single-source gate in the mirror: a counter-macro opposite
"admission" does NOT confirm the exit of a macro-aligned position. When macro
itself flips (or is absent/below floor), the veto clears and the exit
proceeds as before. Fail-open: a guard error never holds a trade.
"""
from __future__ import annotations

import pytest

from agents.open_trades_manager import OpenTradesManager
from utils.helpers import load_config


@pytest.fixture(scope="module")
def manager():
    cfg = load_config()
    cfg.setdefault("trade_management", {}).setdefault("thesis_exit", {})["enabled"] = True
    m = OpenTradesManager(cfg)
    # Production mode: mirror admission + macro-aligned hold both on.
    assert m.thesis_exit_mirror_entry_admission is True
    m.thesis_exit_require_macro_aligned = True
    return m


def _book(macro_side: str | None, macro_conf: float, *, via: str = "gemini"):
    """A two-family agent pair (technical=trend, price_action=structure)
    flipping BUY, plus macro and a Path-3 (gemini) or Path-5 (auction)
    confirmer -- enough for an opposite TWO_AGENT admission."""
    book: dict = {
        "technical": {"direction": "BUY", "confidence": 80},
        "price_action": {"direction": "BUY", "confidence": 76},
    }
    if macro_side is not None:
        book["macro_fundamental"] = {"direction": macro_side, "confidence": macro_conf}
    if via == "gemini":
        book["gemini"] = {"direction": "BUY", "confidence": 75, "available": True}
    elif via == "auction":
        book["auction_flow"] = {"direction": "BUY", "confidence": 75}
    return book


def _review(manager, trade_type: str, book):
    """Exercise the review branch the live engine uses (mirror mode)."""
    return manager._thesis_exit_review(
        {"symbol": "EUR/USD"},
        trade_type=trade_type,
        symbol="EUR/USD",
        current_price=1.160,
        recent_candles=None,
        hours_open=1.0,
        pnl_points=-30.0,
        max_favorable_excursion=10.0,
        tp1=1.150,
        entry=1.160,
        partial_close=False,
        agent_details=book,
    )


def test_macro_aligned_counter_macro_flip_is_held(manager):
    """Holding a SELL; macro SELL 78; a BUY flip earns Path-3 admission.

    The entry gate would hard-veto that BUY (counter-macro), so the mirror
    must NOT confirm the exit. It defends and keeps the original stop.
    """
    book = _book("SELL", 78, via="gemini")
    vote = manager._agent_exit_vote(book, "SELL")
    assert vote["verdict"] == "DEFEND"
    assert vote.get("macro_aligned_hold") is True

    review = _review(manager, "SELL", book)
    assert review["exit_now"] is False
    assert review["kind"] == "THESIS_HELD_MACRO_ALIGNED"


def test_macro_aligned_counter_macro_flip_held_via_auction(manager):
    """Same shield on Path 5 (two agents + auction), which also lacks any
    internal macro veto."""
    book = _book("SELL", 78, via="auction")
    vote = manager._agent_exit_vote(book, "SELL")
    assert vote["verdict"] == "DEFEND"
    assert vote.get("macro_aligned_hold") is True


def test_macro_itself_flipped_confirms_exit(manager):
    """Genuine regime change: macro flips to the opposite side (BUY) at the
    same confidence. The veto clears and the SELL is closed."""
    book = _book("BUY", 78, via="gemini")
    vote = manager._agent_exit_vote(book, "SELL")
    assert vote["verdict"] == "CONFIRM"
    assert vote.get("macro_aligned_hold") is not True
    review = manager._thesis_exit_review(
        {"symbol": "EUR/USD"}, trade_type="SELL", symbol="EUR/USD",
        current_price=1.160, recent_candles=None, hours_open=1.0,
        pnl_points=-30.0, max_favorable_excursion=10.0, tp1=1.150,
        entry=1.160, partial_close=False, agent_details=book)
    assert review["exit_now"] is True
    assert review["kind"] == "ENTRY_GRADE_OPPOSITE_THESIS"


def test_counter_macro_position_exits_fast(manager):
    """Holding BUY AGAINST a confident macro (SELL); the opposite SELL flip
    is macro-aligned and must confirm immediately (that trade should not
    linger)."""
    book = {
        "technical": {"direction": "SELL", "confidence": 80},
        "price_action": {"direction": "SELL", "confidence": 76},
        "macro_fundamental": {"direction": "SELL", "confidence": 78},
        "gemini": {"direction": "SELL", "confidence": 75, "available": True},
    }
    vote = manager._agent_exit_vote(book, "BUY")
    assert vote["verdict"] == "CONFIRM"


def test_macro_below_floor_does_not_shield(manager):
    """Macro opposed but under the 55 floor carries no veto weight: the flip
    confirms (same as a neutral macro)."""
    book = _book("SELL", 50, via="gemini")
    vote = manager._agent_exit_vote(book, "SELL")
    assert vote["verdict"] == "CONFIRM"


def test_flag_disabled_restores_legacy_confirm(manager):
    """Operator opt-out: require_macro_aligned_exit=false restores the pre-R26.4
    behaviour (the flip confirms regardless of macro)."""
    manager.thesis_exit_require_macro_aligned = False
    try:
        book = _book("SELL", 78, via="gemini")
        vote = manager._agent_exit_vote(book, "SELL")
        assert vote["verdict"] == "CONFIRM"
    finally:
        manager.thesis_exit_require_macro_aligned = True


def test_missing_book_fails_open_silent(manager):
    """No agent book at all -> SILENT/unavailable, never an exception and
    never a false exit (legacy emergency path unchanged)."""
    vote = manager._agent_exit_vote(None, "SELL")
    assert vote["verdict"] == "SILENT"
    assert vote.get("available") is False
