# -*- coding: utf-8 -*-
"""R26.6 regression: the stop band and target law are PER SYMBOL everywhere.

Root cause found in the post-decision auditor: _stop_law read the BASE (gold)
200/70/400 block for every symbol, so a legal 405-point forex stop (band
[405,600], R26.9.3 ×1.5) was flagged STOP_OUT_OF_BAND, and a legal 116-point WTI stop
([135,200]) was mis-measured against gold too. The live executor
(clamp_stop_price) already merged the instrument block; now the auditor uses
the SAME single-source per-symbol loader, and targets_law merges the
instrument targets block (max_beyond 375 forex vs 200 gold).
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.helpers import load_config  # noqa: E402
from utils import trading_rules as TR  # noqa: E402
from services import post_decision_auditor as auditor  # noqa: E402


CFG = load_config()

EXPECT_BAND = {
    "XAU/USD": (270.0, 400.0),   # gold 200/70/400
    "WTI/USD": (135.0, 200.0),   # oil 100/35/200
    "EUR/USD": (405.0, 600.0),   # forex 300/105/600 (R26.9.3 ×1.5)
    "GBP/USD": (405.0, 600.0),
    "USD/CAD": (405.0, 600.0),
    "USD/JPY": (540.0, 800.0),   # R33.5: leaves forex to its own x2.0 law
}


def test_stop_rule_for_symbol_bands():
    for sym, (floor, cap) in EXPECT_BAND.items():
        rule = TR.stop_rule_for_symbol(CFG, sym)
        got_floor = rule["min_liquidity_points"] + rule["safety_buffer_points"]
        assert got_floor == floor, (sym, got_floor, floor)
        assert rule["max_stop_points"] == cap, (sym, rule["max_stop_points"], cap)


def test_stop_law_in_auditor_is_per_symbol():
    for sym, (floor, cap) in EXPECT_BAND.items():
        icfg = dict(CFG, symbol=sym)
        law = auditor._stop_law(icfg, sym)
        assert law["noise"] + law["buffer"] == floor, (sym, law)
        assert law["cap"] == cap, (sym, law)


def _decision(symbol, side, entry, stop, tp1, tp2):
    return {
        "symbol": symbol,
        "decision": side,
        "execution_path_id": "PATH_1_THREE_AGENT_CONSENSUS",
        "current_price": entry,
        "signal": {
            "type": side, "order_type": side,
            "entry": {"price": entry},
            "stop_loss": stop, "tp1": tp1, "tp2": tp2,
        },
    }


def test_auditor_no_longer_flags_legal_forex_stop():
    # EUR/USD SELL, 405-point stop = exactly the forex band floor.
    d = _decision("EUR/USD", "SELL", 1.15961, 1.15961 + 405 * 0.00001, 1.15529, 1.15097)
    findings = auditor.audit_decision(d, CFG, {}, [])["findings"]
    codes = [f["code"] for f in findings if f["severity"] == "WARN"]
    assert "STOP_OUT_OF_BAND" not in codes, codes


def test_auditor_still_flags_true_forex_violation():
    # A 250-point EUR/USD stop is BELOW the forex floor (405) -> must warn.
    d = _decision("EUR/USD", "SELL", 1.16000, 1.16250, 1.15800, 1.15500)
    findings = auditor.audit_decision(d, CFG, {}, [])["findings"]
    codes = [f["code"] for f in findings if f["severity"] == "WARN"]
    assert "STOP_OUT_OF_BAND" in codes, codes


def test_auditor_wti_legal_stop_not_measured_against_gold():
    # WTI band is [135,200]; 116 points (legacy real violation) must be flagged
    # under WTI's band, while a 150-point WTI stop must be accepted.
    d_ok = _decision("WTI/USD", "SELL", 82.23, 82.23 + 150 * 0.01, 81.50, 80.70)
    f_ok = [x["code"] for x in auditor.audit_decision(d_ok, CFG, {}, [])["findings"]
            if x["severity"] == "WARN"]
    assert "STOP_OUT_OF_BAND" not in f_ok, f_ok
    d_bad = _decision("WTI/USD", "SELL", 82.23, 82.23 + 116 * 0.01, 81.50, 81.20)
    f_bad = [x["code"] for x in auditor.audit_decision(d_bad, CFG, {}, [])["findings"]
             if x["severity"] == "WARN"]
    assert "STOP_OUT_OF_BAND" in f_bad, f_bad


def test_target_ratios_for_symbol_max_beyond():
    gold = TR.target_ratios_for_symbol(CFG, "XAU/USD")
    fx = TR.target_ratios_for_symbol(CFG, "EUR/USD")
    wti = TR.target_ratios_for_symbol(CFG, "WTI/USD")
    assert gold["max_beyond_points"] == 200.0
    assert fx["max_beyond_points"] == 300.0
    assert wti["max_beyond_points"] == 100.0


def test_executor_clamp_uses_same_per_symbol_band():
    # clamp_stop_price must clamp a too-wide forex stop to the FOREX cap
    # 600 (R26.9.3 ×1.5), not the gold cap 400.
    entry = 1.16000
    # SELL stop 1500 pts away (0.0150) -> clamp back to 600 pts (0.0060)
    clamped = TR.clamp_stop_price(direction="SELL", entry=entry, stop=entry + 0.0150,
                                  cfg=CFG, symbol="EUR/USD")
    import utils.instruments as IN
    pts = IN.price_to_points(clamped - entry, "EUR/USD", CFG)
    assert abs(pts - 600.0) <= 1.0, (clamped, pts)
