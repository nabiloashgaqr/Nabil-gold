"""R25.1: the config merge (root cause of the 12 VPS test failures).

The installer never touched config.json, so the live config stayed on the
pre-R24 law. The merge applies every shipped key, preserves live-only keys,
writes a backup, and is idempotent.
"""
from pathlib import Path
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

_spec = importlib.util.spec_from_file_location(
    "apply_r25_merge", ROOT / "config_patch" / "APPLY_R25_CONFIG_MERGE.py")
merge_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(merge_mod)

SHIPPED = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def _old_live_config(tmp_root: Path) -> Path:
    """A pre-R24 production config with a local tweak we must NOT lose."""
    live = {
        "split_execution": {"convert_touched_zone_to_market": True},
        "pending_freshness": {"stale_after_hours": 6},
        "telegram": {"chat_id": "LOCAL-TWEAK-123"},   # live-only tweak
        "filters": {"max_spread_points_by_symbol": {"XAU/USD": 5.0}},
    }
    tmp_root.mkdir(parents=True, exist_ok=True)
    path = tmp_root / "config.json"
    path.write_text(json.dumps(live), encoding="utf-8")
    return path


def test_merge_applies_the_r24_r25_laws(tmp_path, monkeypatch):
    live_path = _old_live_config(tmp_path)
    # run through argv so main() parses --root like the installer does.
    # R25.9: monkeypatched - the bare assignment leaked argv into the rest
    # of the session and the next in-process CLI (R25.8 scrub argparse)
    # saw a foreign --root and SystemExit(2)'d on the VPS suite.
    monkeypatch.setattr("sys.argv", ["x", "--root", str(tmp_path)])
    assert merge_mod.main() == 0
    live = json.loads(live_path.read_text(encoding="utf-8"))
    assert live["split_execution"]["convert_touched_zone_to_market"] is False
    assert live["pending_freshness"]["stale_after_hours"] == 8  # R35 (operator 2026-09-08): law amended 12 -> 8
    assert live["r24_gates"]["enabled"] is True
    assert live["r25_scalp"]["mode"] == "live"
    assert live["pending_freshness"]["activation_book_gate"]["r25_contextual"]["enabled"] is True
    # the local tweak and the R13 caps survive untouched
    assert live["telegram"]["chat_id"] == "LOCAL-TWEAK-123"
    assert live["filters"]["max_spread_points_by_symbol"]["XAU/USD"] == 5.0
    # a timestamped backup of the old law exists
    backups = list(tmp_path.glob("config.json.bak_r25_*"))
    assert backups and "true" in backups[0].read_text(encoding="utf-8")


def test_merge_is_idempotent(tmp_path, monkeypatch):
    _old_live_config(tmp_path)
    monkeypatch.setattr("sys.argv", ["x", "--root", str(tmp_path)])
    assert merge_mod.main() == 0
    # second run: nothing left to change
    assert merge_mod.main() == 0


def test_merge_keeps_a_live_only_key_not_in_shipped(tmp_path, monkeypatch):
    live_path = _old_live_config(tmp_path)
    live = json.loads(live_path.read_text(encoding="utf-8"))
    live["operator_note"] = {"keep_me": True}
    live_path.write_text(json.dumps(live), encoding="utf-8")
    monkeypatch.setattr("sys.argv", ["x", "--root", str(tmp_path)])
    merge_mod.main()
    live = json.loads(live_path.read_text(encoding="utf-8"))
    assert live["operator_note"] == {"keep_me": True}
    assert live["r25_scalp"]["enabled"] is True
