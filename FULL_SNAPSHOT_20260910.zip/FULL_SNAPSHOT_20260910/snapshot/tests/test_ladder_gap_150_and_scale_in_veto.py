"""Ladder legs sit 150 apart; a scale-in dies on 2 qualified opponents.

Operator 2026-08-18: 'نفذ هذا التصميم بين رجلي السلم والمسافة 150 نقطة...
وعمم... لصفقة التعزيز ان لا يكون هناك 2 معارضين او اكثر'.

  * session_planner.standby_min_distance_points 60 -> 150: the ladder's
    two legs join the unified second-entry distance family (cross_entry /
    scale_in_trigger / duplicate zone, all 150). At 60 the two stops were
    nearly identical — one adverse move killed both legs together.
  * Scale-in hard opposition veto: the shared admission's weighted penalty
    can still admit a book carrying two qualified dissenters when the
    supporters are heavy; for AVERAGING an existing position the rule is
    absolute — >= 2 qualified opponents means no add, whatever the net.
"""

from __future__ import annotations

import io
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


# ── ladder gap 150 ──────────────────────────────────────────────────────────

def test_standby_min_distance_is_150():
    assert float(CONFIG["session_planner"]["standby_min_distance_points"]) == 150


def test_oil_planner_geometry_is_gold_times_04():
    """BUILD 31 R3 (operator order '0.4 حسابيا للكل'): the WTI planner
    override is gold's global geometry x0.4 (standby 60 = 150x0.4,
    max width 180 = 450x0.4, entry zone 24 = 60x0.4)."""
    from utils.instruments import DEFAULT_INSTRUMENTS
    pl = DEFAULT_INSTRUMENTS["WTI/USD"]["session_planner"]
    g = CONFIG["session_planner"]
    # R26.1: WTI planner geometry is gold x0.5 (75 = 150x0.5, 225 = 450x0.5,
    # 30 = 60x0.5).
    assert pl["standby_min_distance_points"] == g["standby_min_distance_points"] * 0.5 == 75
    assert pl["max_primary_zone_width_points"] == g["max_primary_zone_width_points"] * 0.5 == 225
    assert pl["min_entry_zone_width_points"] == g["min_entry_zone_width_points"] * 0.5 == 30
    assert float(CONFIG["session_planner"]["standby_min_distance_points"]) == 150  # gold unchanged


def test_oil_scale_in_trigger_is_gold_times_04():
    """BUILD 31 R3: the second-entry family is gold x0.4 (60/60/60 for
    oil, 150/150/150 for gold) — one ratio for both symbols."""
    import json
    from utils.instruments import DEFAULT_INSTRUMENTS, config_for_instrument, get_instrument
    assert DEFAULT_INSTRUMENTS["WTI/USD"]["scale_in_trigger_points"] == 150  # R26.9.15: gold base; engine x0.5 -> 75
    assert DEFAULT_INSTRUMENTS["XAU/USD"].get("scale_in_trigger_points", 150) == 150
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    wti = config_for_instrument(cfg, get_instrument(cfg, "WTI/USD"))
    gold = config_for_instrument(cfg, get_instrument(cfg, "XAU/USD"))
    assert float(wti["order_execution"]["fixed_risk"]["scale_in_trigger_points"]) == 150  # R26.9.15 gold base
    assert float(gold["order_execution"]["fixed_risk"]["scale_in_trigger_points"]) == 150


def test_planner_enforces_the_distance_between_legs():
    """A standby closer than the floor is refused by _validated_standby."""
    from services.session_planner import SessionPlannerService
    planner = SessionPlannerService(CONFIG)
    primary = {"entry_price": 4400.0, "stop_loss": 4373.0, "direction": "BUY",
               "poi_zone": {"top": 4405.0, "bottom": 4395.0}}
    near = {"entry_price": 4290.0 + 111.0, "stop_loss": 4350.0, "direction": "BUY",
            "poi_zone": {"top": 4404.0, "bottom": 4398.0}}  # 99 pts away
    far = {"entry_price": 4380.0, "stop_loss": 4350.0, "direction": "BUY",
           "poi_zone": {"top": 4383.0, "bottom": 4377.0}}   # 200 pts away
    assert planner._validated_standby(primary, near, symbol="XAU/USD") is None
    assert planner._validated_standby(primary, far, symbol="XAU/USD") is not None


def test_the_whole_150_family_agrees():
    """cross_entry, scale_in_trigger, duplicate zone, ladder gap: one number."""
    sig = CONFIG["signal_requirements"]["two_agent_entry"]
    assert int(sig["cross_entry_distance_points"]) == 150
    assert float(CONFIG["order_execution"]["fixed_risk"]["scale_in_trigger_points"]) == 150
    assert float(CONFIG["duplicate_signal_filter"]["price_zone_points"]) == 150
    assert float(CONFIG["session_planner"]["standby_min_distance_points"]) == 150


# ── scale-in hard opposition veto ───────────────────────────────────────────

SRC = io.open(ROOT / "scripts" / "run_analysis.py", encoding="utf-8").read()


def test_scale_in_has_the_hard_veto():
    # R26.9.13 (operator 2026-09-02): the veto fires on >= 2 qualified
    # opponents ACROSS TWO FAMILIES — one correlated family is one voice.
    block = SRC.split("Hard opposition veto (operator 2026-08-18")[1][:6000]
    assert "oppose_count >= 2 and len(_veto_families) >= 2" in block
    assert "continue" in block
    # 2026-08-18f choice A: the census is the shared VETO_AGENTS counter
    # (five voters + auction_flow), not the admission's voter-only count.
    assert "count_veto_opponents" in block


def test_the_veto_is_the_only_agent_condition():
    """UPDATED 2026-08-18b: the operator removed the fresh-consensus
    requirement entirely — the veto is not merely FIRST, it is the ONLY
    agent gate on an add. No allow-check may follow it."""
    veto_at = SRC.index("Hard opposition veto (operator 2026-08-18")
    scale_tail = SRC[veto_at:veto_at + 6000]
    assert 'if not admission.get("allow")' not in scale_tail, (
        "a fresh-admission requirement crept back into the scale-in path")


def test_the_veto_names_the_opponents_in_the_log():
    block = SRC.split("Hard opposition veto (operator 2026-08-18")[1][:6000]
    assert '_veto.get("opponents")' in block
    # R26.9.13: the one-family pass must leave its evidence row too
    assert "ONE_FAMILY_PASS" in block


def test_scale_in_keeps_the_full_shared_admission():
    """The veto is IN ADDITION to qualification, never instead of it."""
    scale_block = SRC.split("Scale-in is a NEW entry")[1][:3000]
    assert "evaluate_directional_admission" in scale_block
