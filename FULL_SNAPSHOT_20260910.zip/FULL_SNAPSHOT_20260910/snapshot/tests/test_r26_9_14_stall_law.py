# -*- coding: utf-8 -*-
"""R26.9.14 — محور أ + قانون ركود الدافع + مفتاح التباعد + حارس الانقلاب
(operator order 2026-09-03: «محور أ + قانون ركود الدافع + مفتاح التباعد +
طبق مع سكربت يفحص ويقيس هل كنا سندخلها البارحة»)."""

import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from agents.macro_fundamental_agent import MacroFundamentalAgent  # noqa: E402
from services.macro_context_core import (  # noqa: E402
    STALL_FADE_FLOOR,
    STALL_GRACE_HOURS,
    build_context as core_build,
    series_stats,
)

NOW = datetime(2026, 9, 2, 15, 0, tzinfo=timezone.utc)


def _series(base=100.0, hours=130, drift=0.0, points=None):
    if points is not None:
        return [(NOW - timedelta(hours=hours) + timedelta(hours=i), v)
                for i, v in enumerate(points)]
    pts = []
    t0 = NOW - timedelta(hours=hours)
    for i in range(hours + 1):
        pts.append((t0 + timedelta(hours=i), round(base * (1.0 + drift * i), 4)))
    return pts


def _basket(drift_usd=0.0):
    return {
        "EURUSD=X": _series(100.0, drift=-drift_usd),
        "USDJPY=X": _series(150.0, drift=drift_usd),
        "GBPUSD=X": _series(100.0, drift=-drift_usd),
        "USDCAD=X": _series(1.35, drift=drift_usd),
        "AUDUSD=X": _series(100.0, drift=-drift_usd),
    }


def _agent(symbol="XAU/USD", **kw):
    a = MacroFundamentalAgent({"symbol": symbol}, **kw)
    a._flip_guard = {}          # hermetic: never inherit/写 the live sidecar
    a._flip_guard_save = lambda state, _a=a: setattr(_a, "_flip_guard", state)
    a._now_fn = lambda: NOW
    return a


# ── 1. the stall law's raw material ────────────────────────────────────────

def test_stall_age_runs_from_genuine_extension_not_retest():
    # 5d rising; yesterday (t-22h) high 103; today at t-1h RETESTS 103.05
    # (within margin) — the voice must age from YESTERDAY's high.
    pts = _series(100.0, drift=0.00004)             # near-flat course
    for i, (t, c) in enumerate(pts):
        if abs((NOW - t).total_seconds() / 3600.0 - 22) < 0.5:
            pts[i] = (t, 103.0)                     # yesterday's high
        if abs((NOW - t).total_seconds() / 3600.0 - 1) < 0.5:
            pts[i] = (t, 103.03)                    # today's retest (no break)
    st = series_stats(pts, as_of=NOW, v1=False)
    assert st["stall_peak_age_24h"] > 20            # aged from the TRUE extreme
    assert st["peak_age_24h"] < 2                   # naive age would be ~1h


def test_fade_monotonic_with_floor_and_instant_restore():
    def tnx_fade_for(age_h):
        pts = _series(4.2, drift=0.0004)            # rising course
        for i, (t, c) in enumerate(pts):
            if abs((NOW - t).total_seconds() / 3600.0 - age_h) < 0.5:
                pts[i] = (t, 4.5)                   # the extension
        sm = _basket(0.0)
        sm["^TNX"] = pts
        ctx = core_build(sm, as_of=NOW, v1_compat=False)
        return ctx.get("yields_fade"), ctx.get("yields_stall_age_hours")

    fresh = tnx_fade_for(1.0)
    assert fresh == (1.0, 1.0)                      # inside grace: full voice
    mid = tnx_fade_for(8.0)
    assert 0 < mid[0] < 1.0                          # fading
    old = tnx_fade_for(40.0)
    assert old[0] == pytest.approx(STALL_FADE_FLOOR)  # floor, never silence
    rising = tnx_fade_for(1.0)
    assert rising[0] == 1.0                          # new extreme restores


def test_divergence_key_lights_only_when_symbol_moves_and_drivers_stall():
    sm = _basket(0.0004)                             # dollar rising week
    sm["^TNX"] = _series(4.2, drift=0.0004)          # yields rising week
    # both drivers' extremes are > 20h old (no extension today)
    for i, (t, c) in enumerate(sm["^TNX"]):
        if abs((NOW - t).total_seconds() / 3600.0 - 22) < 0.5:
            sm["^TNX"][i] = (t, 4.5)
    for sym in ("EURUSD=X", "GBPUSD=X", "AUDUSD=X"):
        for i, (t, c) in enumerate(sm[sym]):
            if abs((NOW - t).total_seconds() / 3600.0 - 22) < 0.5:
                sm[sym][i] = (t, c * 0.96)           # euro trough yesterday
    sm["symbol_price"] = _series(4300.0, drift=0.0)
    sm["symbol_price"][-6:] = [(t, c * 1.012) for t, c in sm["symbol_price"][-6:]]
    ctx = core_build(sm, as_of=NOW, v1_compat=False)
    assert ctx["symbol_momentum"] == "up"
    assert ctx["divergence_key"] is True
    assert ctx["divergence_direction"] == "up"
    # without the symbol series the key can never fire (no circularity)
    sm2 = {k: v for k, v in sm.items() if k != "symbol_price"}
    ctx2 = core_build(sm2, as_of=NOW, v1_compat=False)
    assert ctx2["divergence_key"] is False


def test_ultra_eye_degrades_marginal_fast_label():
    # basket fast (24h) barely rising while the 8h eye falls -> flat.
    # Shape per member (EUR terms): flat 5d, -0.25% over hours [-24,-8]
    # (dollar marginally UP over 24h), then +0.13% over the last 8h (dollar
    # clearly DOWN intraday) -> the basket fast label is a marginal RISING
    # that the 8h eye must degrade to flat.
    sm = {}
    shapes = {"EURUSD=X": 100.0, "GBPUSD=X": 100.0, "AUDUSD=X": 100.0,
              "USDJPY=X": 150.0, "USDCAD=X": 1.35}
    for sym, base in shapes.items():
        inverse = sym in {"EURUSD=X", "GBPUSD=X", "AUDUSD=X"}
        pts = []
        for i in range(131):
            t = NOW - timedelta(hours=130 - i)
            h_ago = 130 - i
            f = 1.0
            if h_ago < 24:
                f = 1.0 - 0.0025 * (24 - h_ago) / 16.0      # EUR -0.25% ramp
            if h_ago < 8:
                f = (1.0 - 0.0025) * (1 + 0.0013 * (8 - h_ago) / 8.0)
            v = base * (f if inverse else 1.0 / f)
            pts.append((t, round(v, 6)))
        sm[sym] = pts
    ctx = core_build(sm, as_of=NOW, v1_compat=False)
    assert ctx["dxy_trend_ultra"] == "falling"
    assert ctx["dxy_trend"] == "flat"               # marginal rising killed


def test_fed_echo_inherits_the_yields_fade():
    ctx = {"generated_at": NOW.isoformat().replace("+00:00", "Z"), "schema": "v2",
           "dxy_trend": "RISING", "us10y_trend": "RISING", "fed_tone": "hawkish",
           "yields_fade": 0.0}
    out = _agent("XAU/USD").macro_direction(dict(ctx))
    assert out["confidence_breakdown"]["central_banks"] == pytest.approx(0.0)


def test_v1_context_untouched_by_the_stall_law():
    sm = _basket(0.0004)
    sm["^TNX"] = _series(4.2, drift=0.0004)
    ctx = core_build(sm, as_of=NOW, v1_compat=True)
    for field in ("dxy_fade", "yields_fade", "divergence_key",
                  "macro_flip_armed", "dxy_trend_ultra", "stall_law"):
        assert field not in ctx


def test_config_gate_off_reproduces_pure_v2():
    sm = _basket(0.0004)
    sm["^TNX"] = _series(4.2, drift=0.0004)
    for i, (t, c) in enumerate(sm["^TNX"]):
        if abs((NOW - t).total_seconds() / 3600.0 - 22) < 0.5:
            sm["^TNX"][i] = (t, 4.5)
    off = core_build(sm, as_of=NOW, v1_compat=False, stall_enabled=False)
    assert off.get("yields_fade", 1.0) == 1.0
    assert off.get("divergence_key") in (None, False)


# ── 2. the flip guard ──────────────────────────────────────────────────────

def _bull_ctx(minutes=0):
    return {"generated_at": (NOW - timedelta(minutes=minutes)).isoformat().replace("+00:00", "Z"),
            "schema": "v2", "dxy_trend": "FALLING", "dxy_trend_slow": "FALLING",
            "us10y_trend": "FALLING", "us10y_trend_slow": "FALLING",
            "fed_tone": "dovish"}


def _bear_ctx(strong=False):
    # weak: only the dollar leg (|score| ~2.0 < 3.5)
    ctx = {"generated_at": NOW.isoformat().replace("+00:00", "Z"), "schema": "v2",
           "dxy_trend": "RISING", "dxy_trend_slow": "RISING"}
    if strong:                                        # |score| >= 3.5 breaks through
        ctx.update({"us10y_trend": "RISING", "us10y_trend_slow": "RISING",
                    "fed_tone": "hawkish", "risk_sentiment": "risk_on",
                    "oil_trend": "falling"})
    return ctx


def test_flip_guard_blocks_weak_reversal_inside_window():
    a = _agent("XAU/USD")
    first = a.macro_direction(_bull_ctx())           # committed BULL >= 70
    assert first["bias"] == "BULLISH_GOLD" and first["confidence"] >= 70
    blocked = a.macro_direction(_bear_ctx())          # weak opposite, 0h later
    assert blocked["bias"] == "NEUTRAL"
    assert blocked["confidence"] <= 54
    assert "MACRO_FLIP_GUARD" in blocked["reason_codes"]


def test_strong_evidence_breaks_the_guard_immediately():
    a = _agent("XAU/USD")
    a.macro_direction(_bull_ctx())
    strong = a.macro_direction(_bear_ctx(strong=True))
    assert strong["bias"] == "BEARISH_GOLD"           # |score| >= 3.5 passes


def test_guard_expires_after_window():
    a = _agent("XAU/USD")
    a.macro_direction(_bull_ctx())
    later = NOW + timedelta(hours=5)
    a._now_fn = lambda: later
    expired = a.macro_direction(dict(_bear_ctx(),
                                     generated_at=later.isoformat().replace("+00:00", "Z")))
    assert expired["bias"] == "BEARISH_GOLD"


def test_guard_is_per_symbol():
    gold = _agent("XAU/USD")
    gold.macro_direction(_bull_ctx())
    eur = _agent("EUR/USD")
    eur_ctx = {"generated_at": NOW.isoformat().replace("+00:00", "Z"), "schema": "v2",
               "dxy_ex_eur_trend": "RISING", "dxy_trend_slow": "RISING",
               "us10y_trend": "RISING", "us10y_trend_slow": "RISING",
               "fed_tone": "hawkish"}
    out = eur.macro_direction(eur_ctx)                # gold's guard must not apply
    assert "MACRO_FLIP_GUARD" not in out["reason_codes"]


# ── 3. end-to-end: the incident shape ──────────────────────────────────────

def test_the_incident_flip_arrives_at_the_break_not_seven_hours_later():
    """Gold basing all morning while both drivers stall, then the dollar
    breaks: v2-full must confirm BUY at the BREAK hour (13:00-shape)."""
    break_t = NOW                                     # the 13:00-shape stamp
    t0 = break_t - timedelta(hours=130)
    stamps = [t0 + timedelta(hours=i) for i in range(131)]

    def mk(basing_hours):
        drift = 0.0                                   # flat weekly dollar course
        sm = {}
        for sym, inv, k in (("EURUSD=X", True, 10000.0), ("USDJPY=X", False, 150.0),
                            ("GBPUSD=X", True, 10000.0), ("USDCAD=X", False, 1.35),
                            ("AUDUSD=X", True, 10000.0)):
            pts = []
            for t in stamps:
                # dollar index: rising week -> 24h stall -> a -1.4% BREAK
                d = 100.0 * (1 + drift * (t - t0).total_seconds() / 3600.0)
                h_ago = (break_t - t).total_seconds() / 3600.0
                if 4 <= h_ago < 24:
                    d = sm_plateau
                elif h_ago < 4:
                    d = sm_plateau * (0.9965 ** (4 - h_ago))
                v = (k / d) if inv else (k * d / 100.0)
                pts.append((t, round(v, 6)))
            sm[sym] = pts
        # yields: rising week, genuine extension 22h ago, dead flat since
        ypts = []
        for t in stamps:
            c = 4.2 * (1 + drift * (t - t0).total_seconds() / 3600.0)
            if break_t - t <= timedelta(hours=22):
                c = 4.5
            ypts.append((t, round(c, 4)))
        sm["^TNX"] = ypts
        # risk-off + oil up (the incident's contributing legs)
        sm["^VIX"] = [(t, 26.0) for t in stamps]
        sm["CL=F"] = [(t, round(80.0 * (1 + 0.0008 * (t - t0).total_seconds() / 3600.0), 4))
                      for t in stamps]
        # gold: bases then breaks up
        gpts = []
        for t in stamps:
            c = 4330.0
            h_ago = (break_t - t).total_seconds() / 3600.0
            if h_ago < basing_hours:
                c = 4330.0 + (basing_hours - h_ago) * 3.0
            gpts.append((t, round(c, 2)))
        sm["symbol_price"] = gpts
        return sm

    sm_plateau = 100.0                                # stalled dollar level
    agent = _agent("XAU/USD")
    # at the basing hour (4h before the break): armed/neutral — NOT bearish
    ctx_base = core_build(mk(4), as_of=break_t - timedelta(hours=4), v1_compat=False)
    agent._now_fn = lambda: break_t - timedelta(hours=4)
    basing = agent.macro_direction(ctx_base)
    assert basing["bias"] != "BEARISH_GOLD"           # the 4300s are un-vetoed
    # at the break hour: BUY confirmed
    agent._now_fn = lambda: break_t
    ctx_break = core_build(mk(0), as_of=break_t, v1_compat=False)
    out = agent.macro_direction(ctx_break)
    assert out["bias"] == "BULLISH_GOLD" and out["confidence"] >= 55


def test_flip_armed_on_ultra_conflict():
    """The 8h eye contradicting the 5d course arms the flip state."""
    pts = []
    t0 = NOW - timedelta(hours=130)
    for i in range(131):
        t = t0 + timedelta(hours=i)
        c = 100.0 * (1 + 0.0006 * i)              # clear 5d rise (+7.8%)
        if NOW - t < timedelta(hours=8):
            c *= 0.99                              # -1% over the last 8h
        pts.append((t, round(c, 4)))
    sm = _basket(0.0)
    sm["^TNX"] = pts
    ctx = core_build(sm, as_of=NOW, v1_compat=False)
    assert ctx["us10y_trend_ultra"] == "falling"
    assert ctx["us10y_trend_slow"] == "rising"
    assert ctx["macro_flip_armed"] is True


def test_guard_persistence_requires_the_config_flag(tmp_path, monkeypatch):
    """Repository tests stay hermetic: a sidecar on disk is ignored unless
    macro_stall.flip_guard_persist is set (it is, in the live config.json)."""
    import json as _json
    sidecar = ROOT / "storage" / "macro" / "flip_guard.json"
    saved = {}
    if sidecar.exists():
        saved = {"content": sidecar.read_text(encoding="utf-8")}
        sidecar.unlink()
    sidecar.parent.mkdir(parents=True, exist_ok=True)
    sidecar.write_text(_json.dumps({
        "XAU/USD": {"bias": "BULLISH_GOLD", "conf": 78,
                    "at": NOW.isoformat()}}), encoding="utf-8")
    try:
        plain = MacroFundamentalAgent({"symbol": "XAU/USD"})
        assert plain._flip_guard_load() == {}          # no flag -> ignored
        live_cfg = {"symbol": "XAU/USD",
                    "macro_stall": {"flip_guard_persist": True}}
        live = MacroFundamentalAgent(live_cfg)
        g = live._flip_guard_load()
        assert g.get("bias") == "BULLISH_GOLD"          # flag -> loaded
    finally:
        sidecar.unlink(missing_ok=True)
        if saved.get("content"):
            sidecar.write_text(saved["content"], encoding="utf-8")
