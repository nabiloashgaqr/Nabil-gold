# -*- coding: utf-8 -*-
"""R26.9.15 — ONE code for the add trigger: the GOLD base 150 everywhere.

Operator law (2026-09-02): the add trigger is gold's -150, scaled per
symbol ONLY by the ratio (WTI x0.5 -> 75, FX x1.5 -> 225 = 27 pips). The
instrument specs used to carry PRE-SCALED values (FX 225 / WTI 75) which
config_for_instrument injected into order_execution.fixed_risk — and the
R26.9.7 engine then applied the ratio AGAIN:

  * live EUR/USD cycle 2026-09-02 14:06 logged: "need >= 405 pts above
    entry" — 225 x 1.5 = 405 (48.6 pips!), nearly double the lawful 225;
  * WTI silently demanded 75 x 0.5 = 37.5 — HALF the lawful 75.

Gold alone was right (150 x 1.0). Now every stored trigger — root config,
instrument spec, config instruments rows — is the GOLD base 150, and the
engine alone scales. This file freezes the law through the REAL production
path (config_for_instrument + _scaled_add_trigger), the shape the old
empty-fr test bypassed.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from utils.instruments import config_for_instrument, instrument_map
from scripts.run_analysis import _scaled_add_trigger
from utils.helpers import load_config

# the frozen law table (R26.9.11): add trigger per symbol
LAW = {"XAU/USD": 150.0, "WTI/USD": 75.0,
       "EUR/USD": 225.0, "GBP/USD": 225.0,
       "USD/CAD": 225.0, "USD/JPY": 300.0}  # R33.5: JPY on its own x2.0 law


def _merged(symbol: str) -> dict:
    return config_for_instrument(load_config(), {"symbol": symbol})


def test_every_stored_trigger_is_the_gold_base():
    """Root config + every instrument spec + every config row: 150, the
    gold base. A pre-scaled value anywhere is the 405-defect coming back."""
    cfg = load_config()
    root_fr = (cfg.get("order_execution", {}).get("fixed_risk", {}) or {})
    assert float(root_fr.get("scale_in_trigger_points", 150)) == 150.0
    for sym, spec in instrument_map(cfg).items():
        v = spec.get("scale_in_trigger_points")
        assert v is None or float(v) == 150.0, (
            "%s spec carries a pre-scaled trigger %r — the engine would "
            "double-scale it" % (sym, v))
    for row in cfg.get("instruments", []) or []:
        v = row.get("scale_in_trigger_points")
        assert v is None or float(v) == 150.0, (
            "%s config row carries a pre-scaled trigger %r" % (row.get("symbol"), v))


def test_production_path_trigger_is_the_law_for_all_six():
    """Through config_for_instrument (what the live loop runs with) into
    _scaled_add_trigger: exactly the frozen table — no 405, no 37.5."""
    for sym, want in LAW.items():
        merged = _merged(sym)
        fr = merged.get("order_execution", {}).get("fixed_risk", {}) or {}
        got = _scaled_add_trigger(fr, merged, sym)
        assert got == want, "%s: engine trigger %s != law %s (double-scale?)" % (
            sym, got, want)


def test_fx_law_is_27_pips_not_48():
    """The operator's own words: the FX add window is 27 pips (225 pts on a
    0.0001-point pair) — the 405 double-scale made it 48.6 pips and shut
    the window the JPY trade proved real."""
    merged = _merged("USD/JPY")
    fr = merged.get("order_execution", {}).get("fixed_risk", {}) or {}
    pts = _scaled_add_trigger(fr, merged, "USD/JPY")
    assert pts * 0.001 / 0.01 == 30.0  # R33.5: 300 pts x 0.001 = 0.30 JPY = 30 pips (pip 0.01)
