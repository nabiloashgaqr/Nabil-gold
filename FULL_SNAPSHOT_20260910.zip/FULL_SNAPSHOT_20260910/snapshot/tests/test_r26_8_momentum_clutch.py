# -*- coding: utf-8 -*-
"""R26.8 — Momentum clutch (trailing Mode 2).

In a strong impulse the normal fixed-gap trail (price - 150 pts on gold) is
shaken out by an ordinary pullback before price resumes. The clutch detects the
impulse and anchors the stop to the latest swing STRUCTURE with an ATR-scaled
margin instead of chasing the tick. In calm markets the normal trail is used.

Hard guarantees under test:
  * calm market -> clutch inactive (Mode 1 normal trail);
  * strong directional impulse -> clutch active;
  * the clutch stop only ever TIGHTENS (never widens an already-tighter stop);
  * it never crosses the breakeven / locked-profit floor;
  * disabled / missing data -> fail-open (no crash, falls back to Mode 1).
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.helpers import load_config  # noqa: E402
from utils import trading_rules as TR  # noqa: E402
from agents.open_trades_manager import OpenTradesManager  # noqa: E402

CFG = load_config()
SYM = "XAU/USD"


def _candle(o, h, l, c):
    return {"open": o, "high": h, "low": l, "close": c, "time": "2026-09-01T00:00:00Z"}


# Realistic gold M5 geometry: a calm candle range ~20 pts ($2), point=0.1.
CalmHalf = 1.0  # high/low $1 from close => 20 pt candle range


def _sell_calm(n=22):
    out = []
    b = 4450.0
    for _ in range(n):  # ~20-pt range, $0.05 drift down
        b -= 0.05
        out.append(_candle(b + 0.05, b + CalmHalf, b - CalmHalf, b))
    b = out[-1]["close"]
    out.append(_candle(b, b + CalmHalf, b - CalmHalf, b - 0.05))  # forming candle
    return out


def _sell_impulse():
    out = []
    b = 4450.0
    for _ in range(18):  # calm drift
        b -= 0.05
        out.append(_candle(b + 0.05, b + CalmHalf, b - CalmHalf, b))
    # one CLOSED impulse M5 candle: solid 60-pt ($6) body down
    o = out[-1]["close"]
    out.append(_candle(o, o + 0.5, o - 6.0, o - 6.0))
    # new still-forming candle
    b = out[-1]["close"]
    out.append(_candle(b, b + CalmHalf, b - CalmHalf, b - 0.05))
    return out


def _buy_impulse():
    out = []
    b = 4400.0
    for _ in range(18):
        b += 0.05
        out.append(_candle(b - 0.05, b + CalmHalf, b - CalmHalf, b))
    o = out[-1]["close"]
    out.append(_candle(o, o + 6.0, o - 0.5, o + 6.0))  # 60-pt impulse up
    b = out[-1]["close"]
    out.append(_candle(b, b + CalmHalf, b - CalmHalf, b + 0.05))
    return out


def _mgr():
    return OpenTradesManager(CFG)


def test_clutch_defaults_present_and_enabled():
    p = TR.momentum_clutch_params(CFG, SYM)
    assert p["enabled"] is True
    assert p["atr_k"] > 0
    assert p["min_gap_points"] <= p["max_gap_points"]
    assert p["anchor_lookback"] >= 3


def test_calm_market_uses_normal_mode():
    m = _mgr()
    st = m._clutch_state("SELL", _sell_calm(), SYM)
    assert st["active"] is False


def test_down_impulse_activates_clutch():
    m = _mgr()
    st = m._clutch_state("SELL", _sell_impulse(), SYM)
    assert st["active"] is True, st
    assert st["atr_pts"] > 0


def test_up_impulse_activates_clutch():
    m = _mgr()
    st = m._clutch_state("BUY", _buy_impulse(), SYM)
    assert st["active"] is True, st


def test_clutch_never_loosens_a_tighter_stop_sell():
    m = _mgr()
    candles = _sell_impulse()
    st = m._clutch_state("SELL", candles, SYM)
    # A stop already deep in profit (tight, near price) must be left untouched.
    tight = min(c["low"] for c in candles) + 1.0  # very tight favourable stop
    out = m._compute_clutch_stop("SELL", tight, 4450.0, candles, SYM, 0.0, st["atr_pts"])
    assert out is None, f"clutch must not loosen tight stop, got {out}"


def test_clutch_moves_stop_toward_structure_sell():
    m = _mgr()
    candles = _sell_impulse()
    st = m._clutch_state("SELL", candles, SYM)
    loose = 4460.0  # wide stop near original
    out = m._compute_clutch_stop("SELL", loose, 4450.0, candles, SYM, 0.0, st["atr_pts"])
    assert out is not None
    # For a SELL the new stop must be TIGHTER (lower) than the loose one and
    # never above entry (no giving back past breakeven with lock=0 it may sit at
    # entry, but here structure is below entry so it must be <= entry).
    assert out <= loose
    assert out <= 4450.0 + 1e-9


def test_clutch_stop_for_buy_never_below_floor():
    m = _mgr()
    candles = _buy_impulse()
    st = m._clutch_state("BUY", candles, SYM)
    loose = 4390.0
    out = m._compute_clutch_stop("BUY", loose, 4400.0, candles, SYM, 0.0, st["atr_pts"])
    assert out is not None
    assert out >= loose           # ratchet only up
    assert out >= 4400.0 - 1e-9   # never below entry when profit lock is 0 floor


def test_clutch_fail_open_on_disabled():
    import utils.trading_rules as TR2
    cfg = {**CFG}
    # disable via canonical block
    tr = dict(cfg.get("trading_rules", {}))
    tr["momentum_clutch"] = {"enabled": False}
    cfg["trading_rules"] = tr
    m = OpenTradesManager(cfg)
    st = m._clutch_state("SELL", _sell_impulse(), SYM)
    assert st["active"] is False


def test_clutch_fail_open_on_no_candles():
    m = _mgr()
    st = m._clutch_state("SELL", None, SYM)
    assert st["active"] is False
    out = m._compute_clutch_stop("SELL", 4460.0, 4450.0, None, SYM, 0.0, 0.0)
    assert out is None


def test_early_detection_on_first_burst_candle():
    """A single closed 5m candle whose body is >=3x the prior noise and >=35pts
    arms the clutch immediately, even though the 14-bar ATR still reflects the
    prior calm range (this is the 'catch it from the start' guarantee)."""
    m = _mgr()
    candles = _sell_impulse()
    st = m._clutch_state("SELL", candles, SYM)
    assert st["active"] is True
    # early detector fired on the first burst, not only the slow ATR tests
    assert st.get("burst_early") is True or st.get("big_candle") is True


def test_ordinary_candle_does_not_arm():
    """An ordinary ~20pt M5 candle (1x the calm noise) must NOT arm the clutch;
    only a true acceleration does."""
    out = []
    b = 4450.0
    for _ in range(18):
        b -= 0.05
        out.append(_candle(b + 0.05, b + CalmHalf, b - CalmHalf, b))
    o = out[-1]["close"]
    out.append(_candle(o, o + 0.2, o - 2.0, o - 2.0))  # 20-pt ordinary red candle
    b = out[-1]["close"]
    out.append(_candle(b, b + CalmHalf, b - CalmHalf, b - 0.05))
    st = _mgr()._clutch_state("SELL", out, SYM)
    assert st["active"] is False
