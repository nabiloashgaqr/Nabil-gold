# -*- coding: utf-8 -*-
"""R26.9.12 — the add's macro seat belongs to the voice THAT MAY JUDGE.

Operator law (2026-09-02): "الذهب هو المرجع — طبّق نفس القوانين مع النسبة".
In GOLD's add engine the macro voice sits in the admission book: it joins
the shared admission and the >=2-opponents hard veto. The pass-through
compactor shipped the DOLLAR/gold verdict into every symbol's add book
(and the oil entry arrived signal-WAIT, its lean unread) — so WTI adds
were judged by the gold regime and FX adds by the dollar vote, while
oil_macro never had a seat. The seat is now filled by the ROUTED reader
(services.macro_voice — the same one Paths 1/2/6 use):

  gold -> macro_fundamental verdict (byte-identical to the old behavior)
  WTI  -> oil_macro verdict (dollar macro can never judge crude)
  FX   -> the per-symbol bias (BULLISH_EURUSD ...), never the dollar vote
  no committed verdict -> empty seat (fail-open), like gold on a silent day
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))


class _TG:
    def send_message(self, *a, **k):
        return True


def _run(monkeypatch, db, results, cfg):
    import asyncio
    import scripts.run_analysis as ra
    monkeypatch.setattr(ra, "database", db, raising=False)
    asyncio.run(ra._check_scale_in(cfg, results, db.open_trades, db, _TG(),
                                   demo_execution=True))


class _DB:
    def __init__(self, open_trades):
        self.open_trades = open_trades
        self.audit_rows = []

    def save_decision_audit(self, entry):
        self.audit_rows.append(entry)
        return "AUDIT_TEST"

    def get_recent_trades(self, limit=50):
        return []

    def new_trade_id(self):
        return "TRD_TEST_1"

    def save_trade(self, trade):
        pass


def _cfg():
    return {
        "order_execution": {"mode": "paper", "entry_style": "fixed_risk",
                            "fixed_risk": {"scale_in_enabled": True,
                                           "scale_in_trigger_points": 150,
                                           "scale_in_max": 1,
                                           "scale_in_size_ratio": 1.0}},
        "duplicate_signal_filter": {"open_trade": {"max_open_same_direction": 2},
                                    "cooldown": {"after_loss_minutes": 90}},
        "signal_requirements": {"agent_min_confidence": 65},
        "database": {"url": None, "key": None},
    }


def _parent(symbol, side, entry, sl, tp1, tp2):
    return {"id": "P1", "trade_id": "P1", "symbol": symbol, "type": side,
            "status": "OPEN", "entry_price": entry, "stop_loss": sl,
            "tp1": tp1, "tp2": tp2, "signal": {"direction": side}}


def test_gold_add_keeps_its_macro_verdict(tmp_path, monkeypatch):
    """Gold is the reference and stays byte-identical: the gold macro
    OPPOSING the add (BULLISH vs the SELL add) counts toward the veto."""
    db = _DB([_parent("XAU/USD", "SELL", 4400.0, 4430.0, 4370.0, 4340.0)])
    results = {
        "current_price": 4420.0, "symbol": "XAU/USD",  # 200 pts above: trigger met
        "technical": {"direction": "SELL", "confidence": 82.0},
        "classical": {"direction": "SELL", "confidence": 72.0, "resistance": [4420.0]},
        "multitimeframe": {"direction": "SELL", "confidence": 57.0},
        "smc": {"direction": "SELL", "confidence": 59.5},
        "price_action": {"direction": "BUY", "confidence": 68.0},   # opponent #2
        "auction_flow": {"direction": "WAIT", "confidence": 50.0},
        "macro_fundamental": {"macro_direction": {"bias": "BULLISH_GOLD",
                                                  "confidence": 66.0}},
    }
    _run(monkeypatch, db, results, _cfg())
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    assert rows and rows[-1]["outcome"] == "BLOCKED"
    reason = rows[-1]["reason"]
    assert "hard veto" in reason
    assert "macro_fundamental@66" in reason
    assert "price_action@68" in reason


def test_wti_add_judged_by_oil_never_by_dollar(tmp_path, monkeypatch):
    """The live defect: a BUY add on WTI with the DOLLAR macro SELL 74 +
    one SELL opponent. The dollar regime is STRIPPED (only 1 real
    opponent -> no veto, the add proceeds on its own merit)."""
    db = _DB([_parent("WTI/USD", "BUY", 88.00, 87.00, 88.90, 89.80)])
    results = {
        "current_price": 86.30, "symbol": "WTI/USD",  # 170 pts below: trigger met
        "technical": {"direction": "BUY", "confidence": 82.0},
        "classical": {"direction": "BUY", "confidence": 72.0, "support": [86.30]},
        "multitimeframe": {"direction": "BUY", "confidence": 57.0},
        "smc": {"direction": "BUY", "confidence": 59.5},
        "price_action": {"direction": "SELL", "confidence": 68.0},  # 1 real opponent
        "auction_flow": {"direction": "WAIT", "confidence": 50.0},
        "macro_fundamental": {"direction": "SELL", "confidence": 74.0},  # DOLLAR
        "oil_macro": {"signal": "WAIT", "direction": "WAIT", "confidence": 44.0},
    }
    _run(monkeypatch, db, results, _cfg())
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    assert rows, "an add decision must always leave a row"
    reason = rows[-1]["reason"]
    assert "hard veto" not in reason, (
        "the dollar/gold macro must never veto a WTI add — that was the defect")
    assert rows[-1]["outcome"] == "ENTERED"
    assert "1 qualified opponent(s) < 2" in reason


def test_wti_add_vetoed_by_its_own_oil_voice(tmp_path, monkeypatch):
    """The seat is real: oil_macro SELL 70 against the BUY add + one SELL
    opponent -> hard veto naming oil_macro@70."""
    db = _DB([_parent("WTI/USD", "BUY", 88.00, 87.00, 88.90, 89.80)])
    results = {
        "current_price": 86.30, "symbol": "WTI/USD",
        "technical": {"direction": "BUY", "confidence": 82.0},
        "classical": {"direction": "BUY", "confidence": 72.0, "support": [86.30]},
        "multitimeframe": {"direction": "BUY", "confidence": 57.0},
        "smc": {"direction": "BUY", "confidence": 59.5},
        "price_action": {"direction": "SELL", "confidence": 68.0},
        "auction_flow": {"direction": "WAIT", "confidence": 50.0},
        "oil_macro": {"signal": "WAIT", "direction": "SELL", "confidence": 70.0},
    }
    _run(monkeypatch, db, results, _cfg())
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    assert rows and rows[-1]["outcome"] == "BLOCKED"
    reason = rows[-1]["reason"]
    assert "hard veto" in reason
    assert "oil_macro@70" in reason


def test_fx_add_uses_its_own_bias_not_the_dollar_vote(tmp_path, monkeypatch):
    """EUR BUY add: the agent's TOP-LEVEL dollar vote is BUY 74 (would
    SUPPORT the add), but the EUR bias is BEARISH_EURUSD 76. The seat is
    filled from the BIAS: macro SELL@76 + one SELL opponent -> veto."""
    db = _DB([_parent("EUR/USD", "BUY", 1.16000, 1.15500, 1.16400, 1.16800)])
    results = {
        "current_price": 1.15700, "symbol": "EUR/USD",  # 300 pts below (trigger 150x1.8=270)
        "technical": {"direction": "BUY", "confidence": 82.0},
        "classical": {"direction": "BUY", "confidence": 72.0, "support": [1.15700]},
        "multitimeframe": {"direction": "BUY", "confidence": 57.0},
        "smc": {"direction": "BUY", "confidence": 59.5},
        "price_action": {"direction": "SELL", "confidence": 68.0},
        "auction_flow": {"direction": "WAIT", "confidence": 50.0},
        "macro_fundamental": {"direction": "BUY", "confidence": 74.0,   # dollar
                              "macro_direction": {"bias": "BEARISH_EURUSD",
                                                  "confidence": 76.0}},  # EUR truth
    }
    _run(monkeypatch, db, results, _cfg())
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    assert rows and rows[-1]["outcome"] == "BLOCKED"
    reason = rows[-1]["reason"]
    assert "hard veto" in reason
    assert "macro_fundamental@76" in reason   # the EUR bias, not the dollar 74


def test_silent_macro_leaves_the_seat_empty(tmp_path, monkeypatch):
    """No committed verdict anywhere -> no macro seat (fail-open), exactly
    like gold on a silent day; one opponent alone cannot veto."""
    db = _DB([_parent("WTI/USD", "BUY", 88.00, 87.00, 88.90, 89.80)])
    results = {
        "current_price": 86.30, "symbol": "WTI/USD",
        "technical": {"direction": "BUY", "confidence": 82.0},
        "classical": {"direction": "BUY", "confidence": 72.0, "support": [86.30]},
        "multitimeframe": {"direction": "BUY", "confidence": 57.0},
        "smc": {"direction": "BUY", "confidence": 59.5},
        "price_action": {"direction": "SELL", "confidence": 68.0},
        "auction_flow": {"direction": "WAIT", "confidence": 50.0},
        "macro_fundamental": {"direction": "SELL", "confidence": 74.0},  # stripped
        "oil_macro": {"signal": "WAIT", "direction": "WAIT", "confidence": 0.0},
    }
    _run(monkeypatch, db, results, _cfg())
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    assert rows and rows[-1]["outcome"] == "ENTERED"
    assert "hard veto" not in rows[-1]["reason"]
