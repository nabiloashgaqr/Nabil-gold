from utils.instruments import DEFAULT_INSTRUMENTS
from utils.trading_rules import stop_rule, trailing_params, protection_params

FX = ("EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")
# R33.5 (2026-09-08, operator order): USD/JPY left the x1.5 FX class and
# runs its OWN x2.0 law; EUR/GBP/CAD stay x1.5 byte-for-byte.
FX_FACTOR = {"EUR/USD": 1.5, "GBP/USD": 1.5, "USD/CAD": 1.5, "USD/JPY": 2.0}

def test_all_fx_laws_are_gold_x_the_symbol_factor():
    for symbol in FX:
        f = FX_FACTOR[symbol]
        inst = DEFAULT_INSTRUMENTS[symbol]
        assert inst["distance_ratio"] == f
        assert inst["min_sl_distance_points"] == int(400 * f)
        assert inst["duplicate_zone_points"] == int(150 * f)
        assert inst["trading_rules"]["stop"] == {
            "enabled": True, "min_liquidity_points": int(200 * f),
            "safety_buffer_points": int(70 * f), "max_stop_points": int(400 * f)}
        assert inst["trading_rules"]["trailing"]["distance_points"] == int(150 * f)
        assert inst["trading_rules"]["trailing"]["step_points"] == int(40 * f)
        assert inst["trading_rules"]["trailing"]["early_breakeven_points"] == int(150 * f)
        assert inst["trading_rules"]["protection"]["be_lock_points"] == int(40 * f)

def test_gold_and_oil_are_unchanged():
    assert DEFAULT_INSTRUMENTS["XAU/USD"]["trailing_distance"] == 150
    assert DEFAULT_INSTRUMENTS["WTI/USD"]["trailing_distance"] == 75
