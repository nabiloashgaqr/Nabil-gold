"""R26.9.11 + R26.9.12 (2026-09-03, FX stop & TP1-partial audits) — regression tests.

Two defects let EUR/USD SELL trades announce "profit locked" on Telegram
while the broker never received the stop:

1. Precedence: the 2026-08-07 canonical «تريلنج موحد 150/40 للكل» outranked
   the per-instrument trailing calibrations, so FX ran with GOLD's 150-pt
   early breakeven (15 pips) while the cards displayed the correct 225.
2. Truth: scripts/run_trade_updates._sync_demo_execution ignored
   executor.apply_stop's return, so a rejected stop still looked booked and
   the announcement re-fired every 5-min cycle.

These tests pin the fixed behaviour:
  * F1 — instrument trailing block outranks the canonical block (verbatim);
    instruments without a block scale by the law ratio; symbol=None and
    gold are byte-for-byte unchanged.
  * F2 — demo mode defers stop-move announcements to broker confirmation;
    a failed apply reverts the DB stop and tells the truth.
  * F3 — repeated apply failures escalate.
"""

import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from utils import trading_rules as tr  # noqa: E402
from utils.helpers import load_config  # noqa: E402


# ── F1: law-ratio / instrument precedence ───────────────────────────────────

def test_fx_early_breakeven_uses_instrument_law_not_gold_canon():
    cfg = load_config()
    p = tr.trailing_params(cfg, "continuation_profile", "EUR/USD")
    assert p["early_breakeven_points"] == 225.0      # 150 x 1.5
    assert p["distance_points"] == 225.0
    assert p["step_points"] == 60.0


def test_wti_trailing_halves():
    cfg = load_config()
    p = tr.trailing_params(cfg, "continuation_profile", "WTI/USD")
    assert p["early_breakeven_points"] == 75.0       # 150 x 0.5
    assert p["step_points"] == 20.0


def test_gold_and_symbolless_calls_unchanged():
    cfg = load_config()
    gold = tr.trailing_params(cfg, "continuation_profile", "XAU/USD")
    assert gold["early_breakeven_points"] == 150.0
    legacy = tr.trailing_params(cfg, "continuation_profile", None)
    assert legacy == gold


def test_merged_instrument_config_does_not_double_scale():
    """The Telegram-card path resolves against config_for_instrument(cfg)
    (already carrying the instrument's own 225/60/225); passing the symbol
    again must NOT scale those numbers a second time."""
    from utils.instruments import config_for_instrument
    cfg = load_config()
    merged = config_for_instrument(cfg, {"symbol": "EUR/USD"})
    p = tr.trailing_params(merged, symbol="EUR/USD")
    assert p["early_breakeven_points"] == 225.0
    assert p["distance_points"] == 225.0
    assert p["step_points"] == 60.0


# ── F2/F3: demo stop-sync truth ─────────────────────────────────────────────

class _FakeExecutor:
    def __init__(self, cfg=None, telegram=None):
        self.last_error = "TRADE_RETCODE_INVALID"
        self.calls = []

    def alive(self):
        return True

    def halted(self):
        return False

    def apply_stop(self, tid, sl, tp, sym):
        self.calls.append((tid, sl))
        return False

    def reconcile(self, rows):
        return []

    @property
    def last_close(self):
        return None


class _OkExecutor(_FakeExecutor):
    def apply_stop(self, tid, sl, tp, sym):
        self.calls.append((tid, sl))
        return True


class _DeadExecutor(_FakeExecutor):
    def alive(self):
        return False


class _FakeDB:
    def __init__(self):
        self.writes = []

    def update_trade(self, tid, upd):
        self.writes.append((tid, dict(upd)))

    def get_open_trades(self):
        return []


class _FakeTg:
    def __init__(self):
        self.msgs = []

    def send_message(self, text, **kw):
        self.msgs.append(text)
        return True

    def send_trade_event(self, trade, event, price, pnl, evaluation=None, **kw):
        self.msgs.append(f"EVENT:{event}")
        return True


def _row(**over):
    base = {"id": "T1", "symbol": "EUR/USD", "type": "SELL", "mt5_ticket": 123,
            "status": "OPEN", "stop_loss": 1.16618, "sl_moved_to_entry": False,
            "tp2": 1.14748, "current_price": 1.15714,
            "stop_sync_fail_count": 0}
    base.update(over)
    return base


def _eval(**over):
    base = {"trade_id": "T1", "new_status": "OPEN", "events": ["MOVE_SL_TO_BE"],
            "updates": {"stop_loss": 1.15898, "sl_moved_to_entry": True,
                        "current_price": 1.15714, "current_pnl": 184.0}}
    base.update(over)
    return base


@pytest.fixture
def demo_mode(monkeypatch):
    monkeypatch.setenv("EXECUTION_MODE", "mt5_demo")
    import services.mt5_executor as mte
    real = getattr(mte, "Mt5DemoExecutor", None)
    yield mte
    # restore the GENUINE class — deleting it would break later tests that
    # import services.mt5_executor.Mt5DemoExecutor in the same session.
    if real is not None:
        mte.Mt5DemoExecutor = real


def _sync(mte, executor_cls, cfg, db, tg):
    mte.Mt5DemoExecutor = executor_cls
    from scripts.run_trade_updates import _sync_demo_execution
    _sync_demo_execution(cfg, {}, "EUR/USD", [_row()], [_eval()], db, tg)


def test_failed_apply_reverts_db_and_warns_honestly(demo_mode):
    from utils.helpers import load_config
    cfg = load_config()
    db, tg = _FakeDB(), _FakeTg()
    _sync(demo_mode, _FakeExecutor, cfg, db, tg)
    # DB reverted to the pre-cycle stop (the broker's truth)
    assert any(w[0] == "T1" and w[1].get("stop_loss") == 1.16618 for w in db.writes)
    assert any(w[0] == "T1" and w[1].get("sl_moved_to_entry") is False for w in db.writes)
    # flagged for retry + counted
    assert any(w[0] == "T1" and w[1].get("stop_sync_pending") is True
               and w[1].get("stop_sync_fail_count") == 1 for w in db.writes)
    # the truth: a warning, never a success card
    assert tg.msgs and any("فشل نقل الستوب" in m for m in tg.msgs)
    assert not any(m.startswith("EVENT:") for m in tg.msgs)


def test_repeated_failures_escalate(demo_mode):
    from utils.helpers import load_config
    cfg = load_config()
    import scripts.run_trade_updates as rtu
    mte = demo_mode
    mte.Mt5DemoExecutor = _FakeExecutor
    db, tg = _FakeDB(), _FakeTg()
    rtu._sync_demo_execution(cfg, {}, "EUR/USD", [_row(stop_sync_fail_count=1)],
                             [_eval()], db, tg)
    assert any("🚨" in m for m in tg.msgs)


def test_successful_apply_announces_broker_confirmed_card(demo_mode):
    from utils.helpers import load_config
    cfg = load_config()
    db, tg = _FakeDB(), _FakeTg()
    _sync(demo_mode, _OkExecutor, cfg, db, tg)
    assert any(m == "EVENT:MOVE_SL_TO_BE" for m in tg.msgs)
    assert any(w[1].get("stop_sync_pending") is False
               and w[1].get("stop_sync_fail_count") == 0 for w in db.writes)


def test_dead_executor_flags_instead_of_silence(demo_mode):
    from utils.helpers import load_config
    cfg = load_config()
    db, tg = _FakeDB(), _FakeTg()
    _sync(demo_mode, _DeadExecutor, cfg, db, tg)
    assert any(w[1].get("stop_sync_pending") is True for w in db.writes)
    assert any("الوسيط" in m or "unavailable" in m for m in tg.msgs)


def test_manager_defers_stop_events_only_in_demo(monkeypatch):
    from agents.open_trades_manager import OpenTradesManager
    mgr = OpenTradesManager.__new__(OpenTradesManager)
    mgr.config = {"execution": {"execution_mode": "paper"}}
    monkeypatch.delenv("EXECUTION_MODE", raising=False)
    assert mgr._demo_deferred_stop_events(["MOVE_SL_TO_BE", "TP1_HIT"]) == set()
    monkeypatch.setenv("EXECUTION_MODE", "mt5_demo")
    deferred = mgr._demo_deferred_stop_events(
        ["MOVE_SL_TO_BE", "TP1_HIT", "TRAILING_SL_UPDATED", "CLUTCH_STRUCTURE_TRAIL"])
    assert deferred == {"MOVE_SL_TO_BE", "TP1_HIT",
                        "TRAILING_SL_UPDATED", "CLUTCH_STRUCTURE_TRAIL"}


def test_paper_mode_sync_is_a_no_op(monkeypatch):
    monkeypatch.delenv("EXECUTION_MODE", raising=False)
    from scripts.run_trade_updates import _sync_demo_execution
    # explicit paper cfg — load_config() may be a shared/cached object that
    # other tests in the same session have already flipped to demo.
    db, tg = _FakeDB(), _FakeTg()
    _sync_demo_execution({"execution": {"execution_mode": "paper"}}, {},
                         "EUR/USD", [_row()], [_eval()], db, tg)
    assert db.writes == [] and tg.msgs == []


# ── R26.9.12: TP1 partial broker-truth ─────────────────────────────────────

class _FakeExecutorT1(_FakeExecutor):
    """partial refused, stop would succeed (not exercised here)."""

    def __init__(self, cfg=None, telegram=None):
        super().__init__(cfg, telegram)
        self.last_partial = None

    def partial_close_at_tp1(self, tid, fraction, sym):
        self.last_error = "slice 0.05 below broker volume_min 0.01"
        return False


class _OkPartialExecutor(_FakeExecutorT1):
    def __init__(self, cfg=None, telegram=None):
        super().__init__(cfg, telegram)
        self.last_partial = {"volume": 0.19, "price": 1.15689, "remaining": 0.19,
                             "ticket": 123, "existing": False}

    def partial_close_at_tp1(self, tid, fraction, sym):
        return True


class _MirrorPartialExecutor(_OkPartialExecutor):
    """Broker history already had the partial (tick manager announced it)."""

    def __init__(self, cfg=None, telegram=None):
        super().__init__(cfg, telegram)
        self.last_partial = {"volume": 0.19, "price": 1.15689, "remaining": 0.19,
                             "ticket": 123, "existing": True}


def _eval_tp1(**over):
    base = {"trade_id": "T1", "new_status": "TP1_HIT",
            "events": ["TP1_HIT"],
            "updates": {"stop_loss": 1.15898, "sl_moved_to_entry": True,
                        "status": "TP1_HIT", "partial_close": True,
                        "realized_pnl_points": 92.0, "closed_fraction": 0.5,
                        "current_price": 1.15714, "current_pnl": 184.0}}
    base.update(over)
    return base


def _sync_tp1(mte, executor_cls, cfg, db, tg):
    mte.Mt5DemoExecutor = executor_cls
    from scripts.run_trade_updates import _sync_demo_execution
    _sync_demo_execution(cfg, {}, "EUR/USD", [_row()], [_eval_tp1()], db, tg)


def test_failed_tp1_partial_reverts_paper_booking_and_warns(demo_mode):
    from utils.helpers import load_config
    cfg = load_config()
    db, tg = _FakeDB(), _FakeTg()
    _sync_tp1(demo_mode, _FakeExecutorT1, cfg, db, tg)
    flat = {}
    for tid, upd in db.writes:
        flat.update(upd)
    # paper booking reverted: partial not closed, status back to pre-cycle
    assert flat.get("partial_close") is False
    assert flat.get("status") == "OPEN"
    assert flat.get("realized_pnl_points") is None
    assert flat.get("partial_sync_pending") is True
    assert flat.get("partial_sync_fail_count") == 1
    assert any("فشل إغلاق النصف" in m for m in tg.msgs)
    assert not any(m.startswith("EVENT:") for m in tg.msgs)


def test_failed_tp1_partial_escalates(demo_mode):
    from utils.helpers import load_config
    cfg = load_config()
    db, tg = _FakeDB(), _FakeTg()
    import scripts.run_trade_updates as rtu
    demo_mode.Mt5DemoExecutor = _FakeExecutorT1
    rtu._sync_demo_execution(cfg, {}, "EUR/USD",
                             [_row(partial_sync_fail_count=1)], [_eval_tp1()], db, tg)
    assert any("🚨" in m for m in tg.msgs)


def test_successful_tp1_partial_announces_broker_confirmed(demo_mode):
    from utils.helpers import load_config
    cfg = load_config()
    db, tg = _FakeDB(), _FakeTg()
    _sync_tp1(demo_mode, _OkPartialExecutor, cfg, db, tg)
    assert any(m == "EVENT:TP1_HIT" for m in tg.msgs)
    flat = {}
    for tid, upd in db.writes:
        flat.update(upd)
    assert flat.get("partial_sync_pending") is False
    assert flat.get("partial_sync_fail_count") == 0


def test_mirror_restore_does_not_reannounce(demo_mode):
    from utils.helpers import load_config
    cfg = load_config()
    db, tg = _FakeDB(), _FakeTg()
    _sync_tp1(demo_mode, _MirrorPartialExecutor, cfg, db, tg)
    assert not any(m == "EVENT:TP1_HIT" for m in tg.msgs)


def test_manager_defers_tp1_card_in_demo(monkeypatch):
    from agents.open_trades_manager import OpenTradesManager
    mgr = OpenTradesManager.__new__(OpenTradesManager)
    mgr.config = {"execution": {"execution_mode": "mt5_demo"}}
    monkeypatch.setenv("EXECUTION_MODE", "mt5_demo")
    deferred = mgr._demo_deferred_stop_events(["TP1_HIT", "TP2_HIT"])
    assert deferred == {"TP1_HIT"}
