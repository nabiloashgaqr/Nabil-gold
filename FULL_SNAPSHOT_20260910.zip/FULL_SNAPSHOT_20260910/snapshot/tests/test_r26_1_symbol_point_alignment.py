# -*- coding: utf-8 -*-
"""R26.1 (2026-08-31): per-symbol point alignment.

Gold is the reference stop law [225, 400] points. WTI uses factor 0.5
([135, 200]); the four forex pairs use factor 1.5 ([405, 600] system points
= 60-90 pips). Every derived concept (trail, breakeven, zones, post-TP2) is
scaled by the same factor. Sizing (lot_for_stop) keeps the realised stop
loss inside the same ~$225-400 dollar band for every symbol, and gold is
untouched.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from utils.instruments import DEFAULT_INSTRUMENTS, point_size  # noqa: E402

FLOOR_CAP = {
    "XAU/USD": (270.0, 400.0),
    "WTI/USD": (135.0, 200.0),
    "EUR/USD": (405.0, 600.0),
    "GBP/USD": (405.0, 600.0),
    "USD/CAD": (405.0, 600.0),
    "USD/JPY": (540.0, 800.0),   # R33.5: own x2.0 law
}


def _stop(it):
    s = it["trading_rules"]["stop"]
    return (float(s["min_liquidity_points"]) + float(s["safety_buffer_points"]),
            float(s["max_stop_points"]))


def test_stop_floor_and_cap_match_table():
    for sym, (floor, cap) in FLOOR_CAP.items():
        got_floor, got_cap = _stop(DEFAULT_INSTRUMENTS[sym])
        assert (got_floor, got_cap) == (floor, cap), sym


def test_min_sl_distance_equals_cap():
    for sym, (_, cap) in FLOOR_CAP.items():
        assert float(DEFAULT_INSTRUMENTS[sym]["min_sl_distance_points"]) == cap, sym


def test_gold_reference_unchanged():
    g = DEFAULT_INSTRUMENTS["XAU/USD"]["trading_rules"]
    assert g["stop"]["min_liquidity_points"] == 200
    assert g["stop"]["safety_buffer_points"] == 70
    assert g["stop"]["max_stop_points"] == 400
    assert DEFAULT_INSTRUMENTS["XAU/USD"]["trailing_distance"] == 150


def test_derived_concepts_scaled_by_factor():
    # trail / breakeven / post-TP2 scale with the same factor as the stop
    gold_trail = DEFAULT_INSTRUMENTS["XAU/USD"]["trailing_distance"]
    wti = DEFAULT_INSTRUMENTS["WTI/USD"]
    assert wti["trailing_distance"] == round(gold_trail * 0.5)
    assert wti["trading_rules"]["post_tp2"]["min_distance_points"] == round(250 * 0.5)
    fx = DEFAULT_INSTRUMENTS["EUR/USD"]
    # R26.9.3 (operator 2026-09-01): factor 1.5 — clean scaled values
    assert fx["trailing_distance"] == 225
    assert fx["trading_rules"]["post_tp2"]["min_distance_points"] == 375
    # ratio-less concepts stay shared
    for sym in FLOOR_CAP:
        t = DEFAULT_INSTRUMENTS[sym]["trading_rules"]["targets"]
        assert t["min_tp1_rr"] == 0.8 and t["tp2_multiple"] == 2.0


def test_forex_floor_is_48_6_to_60_pips():
    # R26.9.3 (operator 2026-09-01): the FX factor is 1.5 (was 2.25)
    for sym in ("EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"):
        ps = point_size(sym)
        pip = 0.01 if sym.endswith("JPY") else 0.0001
        floor_pips = 405 * ps / pip
        cap_pips = 600 * ps / pip
        assert abs(floor_pips - 40.5) < 1e-6, sym
        assert abs(cap_pips - 60.0) < 1e-6, sym


def test_dollar_risk_holds_band_for_every_symbol():
    from services.risk_usd import lot_for_stop, usd_loss
    for sym, (floor, cap) in FLOOR_CAP.items():
        for pts in (floor, cap):
            lot = lot_for_stop(sym, pts)
            assert lot > 0
            loss = usd_loss(sym, pts, lot)
            # sized to the ~$225 target and never above the $400 ceiling
            assert 250.0 <= loss <= 410.0, (sym, pts, lot, loss)


if __name__ == "__main__":
    import pytest
    sys.exit(pytest.main([__file__, "-v"]))
