"""R25 gates: contradiction law verified + contextual veto + scalp-fade plan.

Operator round 2026-08-28. Numbers are the incident's own:
range [4588.83-4616.73], cancelled BUY LIMIT 4571.84, top price 4612.56.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from agents.open_trades_manager import OpenTradesManager
from scripts.run_analysis import (  # noqa: E402
    _planner_execution_gate,
    _r25_book_site_basis,
    _r25_scalp_execute,
    r25_scalp_fade_plan,
)
from services.agent_book_store import (  # noqa: E402
    load_agent_book, save_agent_book,
)

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
# R35: this file tests the legacy lane explicitly
CONFIG.setdefault("pending_freshness", {}).setdefault("activation_book_gate", {})["enabled"] = True
CONFIG.setdefault("pending_freshness", {}).setdefault("activation_macro_gate", {})["enabled"] = False

RANGE = {"high": 4616.73, "low": 4588.83}
BUY_LEVEL = 4571.84


def _manager():
    return OpenTradesManager(json.loads(json.dumps(CONFIG)))


def _base_decision(price=4612.56, phase="RANGING", adx=21.9):
    return {
        "current_price": price,
        "market_context": {"technical_regime": {"market_phase": phase,
                                                "adx_value": adx}},
        "agent_details": {
            "smc": {"label": "SMC", "direction": "SELL", "confidence": 70.0,
                    "conditional_map": {"details": {"dealing_range": RANGE}}},
        },
    }


def _evening_book():
    """The 2026-08-28 evening book: two qualified SELL voices, MTF neutral."""
    return {
        "classical": {"label": "Classical", "direction": "SELL",
                      "confidence": 67.5},
        "smc": {"label": "SMC", "direction": "SELL", "confidence": 70.0},
        "multitimeframe": {"label": "Multi-Timeframe", "direction": "NO_TRADE",
                           "confidence": 0.0},
    }


def _trade(order_type="LIMIT", entry=BUY_LEVEL):
    return {"order_type": order_type, "entry_price": entry, "id": "T_R25"}


# ── R25-1: the contradiction law (verified existing max_opposing cap) ──────

def test_r25_1_two_qualified_opponents_refuse_a_buy_plan():
    gate = _planner_execution_gate(
        {"decision": "BUY", "agent_details": _evening_book()}, CONFIG)
    assert gate["allow"] is False
    assert gate["kind"] == "OPPOSED_BY_LIVE_AGENTS"
    assert "2 qualified agents oppose" in str(gate["reason"])


def test_r25_1_single_opponent_does_not_trip_the_cap():
    book = {
        "technical": {"label": "Technical", "direction": "BUY",
                      "confidence": 90.0},
        "multitimeframe": {"label": "Multi-Timeframe", "direction": "BUY",
                           "confidence": 88.0},
        "price_action": {"label": "Price Action", "direction": "BUY",
                         "confidence": 85.0},
        "classical": {"label": "Classical", "direction": "SELL",
                      "confidence": 67.5},
        "smc": {"label": "SMC", "direction": "WAIT", "confidence": 30.0},
    }
    gate = _planner_execution_gate(
        {"decision": "BUY", "agent_details": book}, CONFIG)
    assert gate.get("kind") != "OPPOSED_BY_LIVE_AGENTS"


# ── R25-4: the contextual veto at activation ────────────────────────────────

def _book_site(classical=None, smc=None, extra=None, site=True):
    book = {}
    if site:
        book["_site"] = {"range_high": RANGE["high"],
                         "range_low": RANGE["low"]}
    cl = {"direction": "SELL", "confidence": 73.0}
    cl.update(classical or {})
    book["classical"] = cl
    sm = {"direction": "SELL", "confidence": 70.0}
    sm.update(smc or {})
    book["smc"] = sm
    book.update(extra or {})
    return book


def test_r25_4_site_locked_pair_does_not_veto_the_planned_buy():
    book = _book_site(
        classical={"patterns_score": 2.0},
        smc={"basis_text": "Buy after liquidity sweep / bullish structure "
                           "from Discount or Order Block"},
        extra={"multitimeframe": {"direction": "NO_TRADE", "confidence": 0.0}},
    )
    v = _manager()._activation_book_veto(book, "BUY", trade=_trade())
    assert v["veto"] is False
    assert v["opponents"] == []
    assert sorted(v["skipped_site_locked"]) and \
        v["skipped_site_locked"][0].startswith("classical::")


def test_r25_4_system_voices_still_veto_at_the_discount():
    # R26.9.14 (operator 2026-09-02): the veto needs TWO FAMILIES - the
    # surviving system voices are technical (trend) + price_action
    # (structure); two trend readers alone are ONE correlated voice.
    book = _book_site(
        classical={"patterns_score": 2.0},
        smc={"basis_text": "Buy after liquidity sweep from Discount"},
        extra={"technical": {"direction": "SELL", "confidence": 75.0},
               "price_action": {"direction": "SELL", "confidence": 72.0}},
    )
    v = _manager()._activation_book_veto(book, "BUY", trade=_trade())
    assert v["veto"] is True
    assert v["opponents"] == ["technical", "price_action"]


def test_r25_4_market_order_keeps_full_protection():
    book = _book_site(classical={"patterns_score": 2.0},
                      smc={"basis_text": "buy from Discount"})
    v = _manager()._activation_book_veto(
        book, "BUY", trade=_trade(order_type="MARKET"))
    assert v["veto"] is True and not v["skipped_site_locked"]


def test_r25_4_mid_range_level_counts_voices():
    book = _book_site(classical={"patterns_score": 2.0},
                      smc={"basis_text": "buy from Discount"})
    v = _manager()._activation_book_veto(
        book, "BUY", trade=_trade(entry=4600.0))  # 40% of the range
    assert v["veto"] is True


def test_r25_4_missing_range_counts_voices():
    book = _book_site(site=False,
                      classical={"patterns_score": 2.0},
                      smc={"basis_text": "buy from Discount"})
    v = _manager()._activation_book_veto(book, "BUY", trade=_trade())
    assert v["veto"] is True


def test_r25_4_old_format_book_counts_voices():
    book = {  # pre-R25 book: directions only, no site, no basis
        "classical": {"direction": "SELL", "confidence": 73.0},
        "smc": {"direction": "SELL", "confidence": 70.0},
    }
    v = _manager()._activation_book_veto(book, "BUY", trade=_trade())
    assert v["veto"] is True


def test_r25_4_below_confidence_floor_voice_never_skipped():
    book = _book_site(
        classical={"patterns_score": 2.0, "confidence": 66.0},
        smc={"basis_text": "buy from Discount", "confidence": 66.0},
        extra={"technical": {"direction": "SELL", "confidence": 71.0},
               "multitimeframe": {"direction": "SELL", "confidence": 71.0}},
    )
    v = _manager()._activation_book_veto(book, "BUY", trade=_trade())
    assert v["veto"] is True
    assert v["skipped_site_locked"] == []
    # sub-floor site voices stay COUNTED (conservative), never skipped
    assert "classical" in v["opponents"] and "smc" in v["opponents"]


def test_r25_4_macro_is_protected():
    book = _book_site(
        classical={"patterns_score": 2.0},
        smc={"basis_text": "buy from Discount"},
        extra={"macro_fundamental": {"direction": "SELL", "confidence": 80.0},
               "technical": {"direction": "SELL", "confidence": 72.0}},
    )
    v = _manager()._activation_book_veto(book, "BUY", trade=_trade())
    assert v["veto"] is True
    assert "macro_fundamental" in v["opponents"]


# ── R25-2: the scalp-fade plan ──────────────────────────────────────────────

def _sell_book(cl=73.0, smc=70.0, mtf=("NO_TRADE", 0.0)):
    return {
        "classical": {"direction": "SELL", "confidence": cl},
        "smc": {"direction": "SELL", "confidence": smc,
                "conditional_map": {"details": {"dealing_range": RANGE}}},
        "multitimeframe": {"direction": mtf[0], "confidence": mtf[1]},
    }


def test_r25_2_full_plan_on_the_incident_range():
    d = _base_decision()
    d["agent_details"].update(_sell_book())
    res = r25_scalp_fade_plan(
        d, CONFIG, trigger_state="REJECTION_CONFIRMED",
        price=4612.56, plan_buy_entry=BUY_LEVEL)
    assert res["ok"] is True and res["side"] == "SELL"
    p = res["plan"]
    assert p["entry"] == 4611.15            # 80% retest of [4588.83-4616.73]
    assert p["sl"] == pytest_approx(4646.15)   # fixed 350 system pts ($35)
    assert p["stop_points"] == 350.0
    assert p["t1_mid"] == pytest_approx(4591.50)   # midpoint to the final
    assert p["t3_handoff_cap"] == BUY_LEVEL  # final = the opposite pending
    assert p["trail_distance_pts"] == pytest_approx(97.65)  # 35% span, sys pts
    assert p["ttl_minutes"] == 45.0 and p["size_fraction"] == 0.5
    assert p["mode"] == CONFIG["r25_scalp"]["mode"] == "live"


def pytest_approx(x, tol=0.02):
    class _A(float):
        def __eq__(self, other):
            return abs(float(self) - float(other)) <= tol
    return _A(x)


def test_r25_2_buy_mirror_at_the_discount():
    d = _base_decision(price=4592.0)
    d["agent_details"].update(_sell_book())
    d["agent_details"]["classical"] = {"direction": "BUY", "confidence": 75.0}
    d["agent_details"]["smc"] = {"direction": "BUY", "confidence": 72.0,
                                 "conditional_map":
                                     {"details": {"dealing_range": RANGE}}}
    res = r25_scalp_fade_plan(
        d, CONFIG, trigger_state="REJECTION_CONFIRMED",
        price=4592.0, plan_sell_entry=4650.0)
    assert res["ok"] is True and res["side"] == "BUY"
    p = res["plan"]
    assert p["entry"] == 4594.41            # 20% of the span
    assert p["sl"] == pytest_approx(4559.41)  # 350 pts below entry
    assert p["t1_mid"] == pytest_approx(4622.21)  # midpoint to 4650
    assert p["t3_handoff_cap"] == 4650.0


def test_r25_2_no_trigger_no_trade():
    d = _base_decision()
    d["agent_details"].update(_sell_book())
    res = r25_scalp_fade_plan(d, CONFIG, trigger_state="TOUCH_NO_REJECTION",
                              price=4612.56)
    assert res["ok"] is False and "waiting rejection trigger" in res["reason"]


def test_r25_2_mtf_directional_blocks_the_fade():
    d = _base_decision()
    d["agent_details"].update(_sell_book(mtf=("BUY", 88.0)))
    res = r25_scalp_fade_plan(d, CONFIG, trigger_state="REJECTION_CONFIRMED",
                              price=4612.56)
    assert res["ok"] is False and "MTF directional" in res["reason"]


def test_r25_2_trending_market_blocks_the_fade():
    d = _base_decision(phase="TRENDING")
    d["agent_details"].update(_sell_book())
    res = r25_scalp_fade_plan(d, CONFIG, trigger_state="REJECTION_CONFIRMED",
                              price=4612.56)
    assert res["ok"] is False and "not range-fade" in res["reason"]


def test_r25_2_strong_adx_blocks_the_fade():
    d = _base_decision(adx=30.0)
    d["agent_details"].update(_sell_book())
    res = r25_scalp_fade_plan(d, CONFIG, trigger_state="REJECTION_CONFIRMED",
                              price=4612.56)
    assert res["ok"] is False and "above 25" in res["reason"]


def test_r25_2_mid_range_price_is_no_fade():
    d = _base_decision(price=4602.78)
    d["agent_details"].update(_sell_book())
    res = r25_scalp_fade_plan(d, CONFIG, trigger_state="REJECTION_CONFIRMED",
                              price=4602.78)
    assert res["ok"] is False and "premium floor" in res["reason"]


def test_r25_2_no_two_family_agreement_no_fade():
    d = _base_decision()
    d["agent_details"].update(_sell_book(smc=55.0))
    res = r25_scalp_fade_plan(d, CONFIG, trigger_state="REJECTION_CONFIRMED",
                              price=4612.56)
    assert res["ok"] is False and "no two-family agreement" in res["reason"]


def test_r25_2_no_pending_level_derives_final_from_the_stop():
    """Operator law: without an opposite pending level, targets derive from
    the 350-pt stop (2R fallback = 700 pts) - and the partial sits at the
    midpoint of THAT distance."""
    d = _base_decision()
    d["agent_details"].update(_sell_book())
    res = r25_scalp_fade_plan(d, CONFIG, trigger_state="REJECTION_CONFIRMED",
                              price=4612.56, plan_buy_entry=0.0)
    assert res["ok"] is True
    p = res["plan"]
    assert p["t3_handoff_cap"] == pytest_approx(4541.15)  # 4611.15 - 700 pts
    assert p["t1_mid"] == pytest_approx(4576.15)         # midpoint to 2R


def test_r25_2_unknown_range_abstains():
    d = _base_decision()
    d["agent_details"].update(_sell_book())
    d["agent_details"]["smc"] = {"direction": "SELL", "confidence": 70.0}
    res = r25_scalp_fade_plan(d, CONFIG, trigger_state="REJECTION_CONFIRMED",
                              price=4612.56)
    assert res["ok"] is False and "no known range" in res["reason"]


def _armed_decision():
    d = _base_decision()
    d["symbol"] = "XAU/USD"
    d["session_plan"] = {"session_bias": "BUY",
                         "primary_poi": {"entry_price": BUY_LEVEL,
                                         "trigger_state":
                                             "REJECTION_CONFIRMED"}}
    d["agent_details"].update(_sell_book())
    return d


def test_r25_2_live_mode_places_a_real_limit(tmp_path, monkeypatch):
    """Operator order 2026-08-28 evening: the scalp trades, not journals."""
    monkeypatch.chdir(tmp_path)
    import tests.test_session_plan_ladder as t
    from utils.helpers import load_trades
    db, tg = t._db(tmp_path), t._Telegram()
    import logging
    logging.disable(logging.INFO)
    try:
        _r25_scalp_execute(_armed_decision(), "XAU/USD", CONFIG,
                           db, tg, [], demo_execution=False)
    finally:
        logging.disable(logging.NOTSET)
    assert len(tg.sent) == 1, "live mode must deliver the scalp"
    scalp = tg.sent[0]
    sig = scalp["signal"]
    assert sig["order_type"] == "SELL_LIMIT"
    assert sig["entry"]["kind"] == "LIMIT"
    assert sig["entry"]["price"] == 4611.15
    assert sig["stop_loss"] == pytest_approx(4646.15)
    assert sig["tp1"] == pytest_approx(4591.50)   # the midpoint partial
    assert sig["tp2"] == BUY_LEVEL, "the runner caps at the BUY hand-off"
    assert scalp["setup_context"]["r25_scalp"] is True
    rows = load_trades(db.local_path)
    assert rows and rows[0]["signal_snapshot"]["setup_context"]["r25_scalp"] is True


def test_r25_2_one_scalp_at_a_time(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    import tests.test_session_plan_ladder as t
    db, tg = t._db(tmp_path), t._Telegram()
    existing = [{"symbol": "XAU/USD", "status": "PENDING",
                 "signal_snapshot": {"setup_context": {"r25_scalp": True}}}]
    import logging
    logging.disable(logging.INFO)
    try:
        _r25_scalp_execute(_armed_decision(), "XAU/USD", CONFIG,
                           db, tg, existing, demo_execution=False)
    finally:
        logging.disable(logging.NOTSET)
    assert tg.sent == []


def test_r25_2_r24_0_supremacy_refuses_a_grade_f_scalp(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    import tests.test_session_plan_ladder as t
    db, tg = t._db(tmp_path), t._Telegram()
    d = _armed_decision()
    d["risk"] = {"approved": False,
                 "trade_grade": {"grade": "F", "score": 39},
                 "rejection_reason": "unit-test veto"}
    import logging
    logging.disable(logging.INFO)
    try:
        _r25_scalp_execute(d, "XAU/USD", CONFIG, db, tg, [],
                           demo_execution=False)
    finally:
        logging.disable(logging.NOTSET)
    assert tg.sent == [], "R24-0 refuses every order, scalp included"


# ── R25-3: the scalp's own time contract (BUILD 29 law untouched) ───────────

def test_r25_3_scalp_row_times_out_without_progress():
    m = _manager()
    trade = {"signal_snapshot": {"setup_context": {"r25_scalp": True}}}
    res = m._r25_scalp_time_exit(trade, hours_open=61 / 60.0,
                                 pnl_points=0.0, tp1=4602.78, entry=4611.15)
    assert res and res["action"] == "CLOSE" and "time-stop" in res["reason"]


def test_r25_3_normal_rows_keep_the_build29_law():
    m = _manager()
    trade = {"signal_snapshot": {"setup_context": {}}}
    assert m._r25_scalp_time_exit(trade, hours_open=99.0, pnl_points=0.0,
                                  tp1=4602.78, entry=4611.15) is None


def test_r25_3_young_scalp_row_is_not_killed():
    m = _manager()
    trade = {"signal_snapshot": {"setup_context": {"r25_scalp": True}}}
    assert m._r25_scalp_time_exit(trade, hours_open=0.5, pnl_points=0.0,
                                  tp1=4602.78, entry=4611.15) is None


def test_r25_3_progressing_runner_is_not_killed():
    m = _manager()
    trade = {"signal_snapshot": {"setup_context": {"r25_scalp": True}}}
    res = m._r25_scalp_time_exit(trade, hours_open=61 / 60.0,
                                 pnl_points=5.0, tp1=4602.78, entry=4611.15)
    assert res is None  # 58% of the way to T1: the clock does not kill it


# ── the book carries the site basis (store round-trip) ──────────────────────

def test_book_store_roundtrip_carries_site_and_basis(tmp_path):
    details = {
        "classical": {"direction": "SELL", "confidence": 73.0,
                      "patterns_score": 2.0},
        "smc": {"direction": "SELL", "confidence": 70.0,
                "basis_text": "Buy after liquidity sweep from Discount"},
    }
    save_agent_book("XAU/USD", details, root=tmp_path,
                    site_context={"range_high": RANGE["high"],
                                  "range_low": RANGE["low"]})
    loaded = load_agent_book("XAU/USD", root=tmp_path)
    assert loaded["classical"]["patterns_score"] == 2.0
    assert "discount" in loaded["smc"]["basis_text"].lower()
    assert loaded["_site"]["range_low"] == RANGE["low"]


def test_book_site_basis_enrichment_from_all_results():
    all_results = {
        "classical": {"timeframe_analysis": {
            "5m": {"score_components": {"patterns_and_quality": 2.0}},
            "15m": {"score_components": {"patterns_and_quality": 0.0}},
        }},
        "smc": {"setup_structure": {
            "entry_reason": "Buy after liquidity sweep from Discount"}},
    }
    out = _r25_book_site_basis(all_results, {
        "classical": {"direction": "SELL", "confidence": 73.0},
        "smc": {"direction": "SELL", "confidence": 70.0},
    })
    assert out["classical"]["patterns_score"] == 2.0
    assert "discount" in out["smc"]["basis_text"].lower()


# ── the operator's wait: the pending now lives 12h ──────────────────────────

def test_stale_after_hours_is_8():
    assert CONFIG["pending_freshness"]["stale_after_hours"] == 8  # R35: unknown quality ruled as MEDIUM
    m = _manager()
    assert m.pending_freshness_stale_after_hours == 8.0
