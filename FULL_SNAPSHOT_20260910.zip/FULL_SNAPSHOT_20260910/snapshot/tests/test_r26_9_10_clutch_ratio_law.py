# -*- coding: utf-8 -*-
"""R26.9.10 — the momentum clutch's POINT thresholds obey the ratio law.

Operator order (2026-09-01): "قوانين الذهب كاملة مع فرق النسبة: النفط 0.5
والفوركس 1.5". The clutch's multipliers (atr_k, speed_atr_mult, ...) are
ratios and stay symbol-agnostic, but three thresholds are GOLD points and
were shipping verbatim to every symbol (verified: gold == WTI == EUR on
burst_min_points 35 / gap [150,400]) — the last unscaled distance family
in the management stack. They now scale by the law's own ratio (stop caps:
400 -> 200 WTI / 600 FX):

    gold  burst 35      gap [150, 400]   (unchanged, byte-identical)
    WTI   burst 17.5    gap [ 75, 200]
    FX    burst 63      gap [225, 600]

An instrument block that sets a point field explicitly is honoured VERBATIM
(no double scaling).
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from utils.helpers import load_config
from utils.instruments import config_for_instrument
from utils.trading_rules import momentum_clutch_params

FX4 = ("EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")


def _cfg(symbol: str) -> dict:
    return config_for_instrument(load_config(), {"symbol": symbol})


def test_gold_clutch_unchanged():
    p = momentum_clutch_params(_cfg("XAU/USD"), "XAU/USD")
    assert p["burst_min_points"] == 35.0
    assert p["min_gap_points"] == 150.0
    assert p["max_gap_points"] == 400.0


def test_wti_clutch_half():
    p = momentum_clutch_params(_cfg("WTI/USD"), "WTI/USD")
    assert p["burst_min_points"] == 17.5
    assert p["min_gap_points"] == 75.0
    assert p["max_gap_points"] == 200.0


FX_FACTOR = {"EUR/USD": 1.5, "GBP/USD": 1.5, "USD/CAD": 1.5, "USD/JPY": 2.0}  # R33.5


def test_fx_clutch_scales_by_the_symbol_factor():
    for sym in FX4:
        f = FX_FACTOR[sym]
        p = momentum_clutch_params(_cfg(sym), sym)
        assert p["burst_min_points"] == 35.0 * f, sym
        assert p["min_gap_points"] == 150.0 * f, sym
        assert p["max_gap_points"] == 400.0 * f, sym


def test_multipliers_never_scaled():
    gold = momentum_clutch_params(_cfg("XAU/USD"), "XAU/USD")
    for sym in ("WTI/USD", "EUR/USD", "USD/JPY"):
        p = momentum_clutch_params(_cfg(sym), sym)
        for k in ("atr_period", "atr_k", "burst_vs_noise_mult",
                  "candle_atr_mult", "speed_atr_mult", "speed_lookback",
                  "anchor_lookback", "enabled"):
            assert p[k] == gold[k], (sym, k)


def test_explicit_instrument_point_override_verbatim():
    """An instrument block that names a point field wins verbatim — the
    ratio must not double-scale an explicit operator choice. (The config
    row REPLACES the spec's trading_rules wholesale — instrument_map does a
    shallow update — so the row must carry the full block plus the one
    override, exactly like a real operator edit.)"""
    from utils.instruments import get_instrument
    base = load_config()
    spec = get_instrument(base, "EUR/USD")            # full default spec (deep copy)
    tr = dict(spec.get("trading_rules") or {})
    tr["momentum_clutch"] = {"burst_min_points": 50.0}
    row = dict(spec)
    row["symbol"] = "EUR/USD"
    row["trading_rules"] = tr
    insts = [dict(i) for i in base.get("instruments") or []
             if str(i.get("symbol") or "").upper() not in {"EUR/USD"}]
    insts.append(row)
    cfg = dict(base)
    cfg["instruments"] = insts
    p = momentum_clutch_params(cfg, "EUR/USD")
    assert p["burst_min_points"] == 50.0          # explicit — verbatim
    assert p["min_gap_points"] == 225.0           # not named — still scaled
    assert p["max_gap_points"] == 600.0
