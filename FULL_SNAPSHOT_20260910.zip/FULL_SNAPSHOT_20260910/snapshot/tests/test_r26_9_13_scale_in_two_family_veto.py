# -*- coding: utf-8 -*-
"""R26.9.13 — the add's hard veto counts DISTINCT FAMILIES, not names.

Operator law (2026-09-02: "لا تعزيز إذا كان هناك وكيلين معارضين من عائلتين"):
two qualified opponents veto the add ONLY when they come from TWO different
families. The family doctrine (2026-08-17): technical, multitimeframe and
classical read the same trend inputs and are wrong TOGETHER — two of them
opposing is ONE correlated voice, not two. Unlisted voices (auction_flow,
macro_fundamental, oil_macro) are each their own family.

Frozen for all SIX traded pairs with each pair's own law geometry (trigger
150xratio — FX 270 pts, WTI 75, gold 150 — and lawful in-band parent stops).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

# (symbol, entry, lawful parent-stop in points) — gold 300 in [270,400],
# WTI 160 in [135,200], FX 600 in [486,720]
SIX_PAIRS = [
    ("XAU/USD", 4400.00, 300.0),
    ("WTI/USD", 88.000, 160.0),
    ("EUR/USD", 1.16000, 600.0),
    ("GBP/USD", 1.35500, 600.0),
    ("USD/CAD", 1.37000, 600.0),
    ("USD/JPY", 145.000, 600.0),
]


class _TG:
    def send_message(self, *a, **k):
        return True


class _DB:
    def __init__(self, open_trades):
        self.open_trades = open_trades
        self.audit_rows = []
        self.saved = []

    def save_decision_audit(self, entry):
        self.audit_rows.append(entry)
        return "AUDIT_TEST"

    def get_recent_trades(self, limit=50):
        return []

    def new_trade_id(self):
        return "TRD_TEST_1"

    def save_trade(self, trade):
        self.saved.append(trade)


def _cfg():
    return {
        "order_execution": {"mode": "paper", "entry_style": "fixed_risk",
                            "fixed_risk": {"scale_in_enabled": True,
                                           "scale_in_trigger_points": 150,
                                           "scale_in_max": 1,
                                           "scale_in_size_ratio": 1.0}},
        "duplicate_signal_filter": {"open_trade": {"max_open_same_direction": 2},
                                    "cooldown": {"after_loss_minutes": 90}},
        "signal_requirements": {"agent_min_confidence": 65},
        "database": {"url": None, "key": None},
    }


def _scenario(symbol, entry, stop_pts):
    """SELL parent + a 400-pt pullback price built with the CODE's own
    point converter (>= every scaled trigger: 270/150/75)."""
    import scripts.run_analysis as ra
    price = entry + ra.points_to_price(400.0, symbol=symbol)
    parent = {"id": "P1", "trade_id": "P1", "symbol": symbol, "type": "SELL",
              "status": "OPEN", "entry_price": entry,
              "stop_loss": entry + ra.points_to_price(stop_pts, symbol=symbol),
              "tp1": entry - ra.points_to_price(300.0, symbol=symbol),
              "tp2": entry - ra.points_to_price(400.0, symbol=symbol),
              "signal": {"direction": "SELL"}}
    return parent, price


def _book(symbol, price, opponents):
    book = {
        "current_price": price, "symbol": symbol,
        "technical": {"direction": "SELL", "confidence": 82.0},
        "classical": {"direction": "SELL", "confidence": 72.0,
                      "resistance": [price]},
        "multitimeframe": {"direction": "SELL", "confidence": 57.0},
        "smc": {"direction": "SELL", "confidence": 59.5},
        "price_action": {"direction": "WAIT", "confidence": 50.0},
        "auction_flow": {"direction": "WAIT", "confidence": 50.0},
    }
    book.update(opponents)
    return book


def _run(monkeypatch, db, results):
    import asyncio
    import scripts.run_analysis as ra
    monkeypatch.setattr(ra, "database", db, raising=False)
    asyncio.run(ra._check_scale_in(_cfg(), results, db.open_trades, db, _TG(),
                                   demo_execution=True))


@pytest.mark.parametrize("symbol,entry,stop_pts", SIX_PAIRS, ids=[s for s, _, _ in SIX_PAIRS])
def test_two_same_family_opponents_do_not_veto(tmp_path, monkeypatch, symbol, entry, stop_pts):
    """technical + classical both oppose (both TREND family): one correlated
    voice — the add proceeds and leaves a ONE_FAMILY_PASS evidence row."""
    parent, price = _scenario(symbol, entry, stop_pts)
    db = _DB([parent])
    results = _book(symbol, price, {
        "technical": {"direction": "BUY", "confidence": 70.0},   # trend
        # an opposing classical still maps structure levels (resistance)
        "classical": {"direction": "BUY", "confidence": 68.0,   # trend
                      "resistance": [price]},
    })
    _run(monkeypatch, db, results)
    assert db.saved, "%s: one-family opposition must not block a lawful add" % symbol
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    assert not any("hard veto" in str(r.get("reason")) for r in rows)
    assert any(r.get("outcome") == "ONE_FAMILY_PASS" and "trend" in str(r.get("reason"))
               for r in rows), "%s: the pass must name the single family" % symbol


@pytest.mark.parametrize("symbol,entry,stop_pts", SIX_PAIRS, ids=[s for s, _, _ in SIX_PAIRS])
def test_two_family_opponents_veto_on_every_pair(tmp_path, monkeypatch, symbol, entry, stop_pts):
    """technical (trend) + smc (structure) oppose: TWO families -> hard
    veto, on every one of the six pairs."""
    parent, price = _scenario(symbol, entry, stop_pts)
    db = _DB([parent])
    results = _book(symbol, price, {
        "technical": {"direction": "BUY", "confidence": 70.0},   # trend
        "smc": {"direction": "BUY", "confidence": 68.0},         # structure
    })
    _run(monkeypatch, db, results)
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    assert rows and rows[-1]["outcome"] == "BLOCKED", "%s: two families must veto" % symbol
    reason = rows[-1]["reason"]
    assert "hard veto" in reason
    assert "2 families" in reason
    assert "technical@70" in reason and "smc@68" in reason
    assert not db.saved
