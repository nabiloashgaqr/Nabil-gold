# -*- coding: utf-8 -*-
"""R26.9.12b — the add's stop obeys the symbol's law band; the size is FULL.

Operator law (2026-09-02: "طبّق قانون الذهب بالضبط مع النسبة" + "التعزيز
بحجم كامل"): a scale-in is a NEW entry, so its stop passes the SAME
execution-boundary clamp every other door already enforces (R26.9.9), and
its size ratio is 1.0x of the parent.

The clone defect: the add copied the parent's CURRENT stop geometry. If
management had already moved the parent stop (BE lock +150xratio, trailing
ratchet), the copied distance was the MOVED one:
  * a BE-locked FX parent handed its add a 225-pt stop (27 pips!) — far
    under the 405-pt floor of the FX band [405, 600];
  * a legacy wide parent (the 1025-pt GBP stop of 2026-09-01) handed its
    add a stop over the 600 cap.
XAU/USD returns the (0, 0) band -> clamp is a no-op -> the gold add's clone
stays byte-identical, the reference behaviour verbatim.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))


class _TG:
    def send_message(self, *a, **k):
        return True


def _run(monkeypatch, db, results, cfg):
    import asyncio
    import scripts.run_analysis as ra
    monkeypatch.setattr(ra, "database", db, raising=False)
    asyncio.run(ra._check_scale_in(cfg, results, db.open_trades, db, _TG(),
                                   demo_execution=True))


class _DB:
    def __init__(self, open_trades):
        self.open_trades = open_trades
        self.audit_rows = []
        self.saved = []

    def save_decision_audit(self, entry):
        self.audit_rows.append(entry)
        return "AUDIT_TEST"

    def get_recent_trades(self, limit=50):
        return []

    def new_trade_id(self):
        return "TRD_TEST_1"

    def save_trade(self, trade):
        self.saved.append(trade)


def _cfg(ratio=1.0):
    fr = {"scale_in_enabled": True,
          "scale_in_trigger_points": 150,
          "scale_in_max": 1}
    if ratio is not None:
        fr["scale_in_size_ratio"] = ratio
    return {
        "order_execution": {"mode": "paper", "entry_style": "fixed_risk",
                            "fixed_risk": fr},
        "duplicate_signal_filter": {"open_trade": {"max_open_same_direction": 2},
                                    "cooldown": {"after_loss_minutes": 90}},
        "signal_requirements": {"agent_min_confidence": 65},
        "database": {"url": None, "key": None},
    }


def _parent(symbol, side, entry, sl, tp1, tp2):
    return {"id": "P1", "trade_id": "P1", "symbol": symbol, "type": side,
            "status": "OPEN", "entry_price": entry, "stop_loss": sl,
            "tp1": tp1, "tp2": tp2, "signal": {"direction": side}}


def _clean_sell_book(price, level, symbol):
    """A clean SELL-side book (zero qualified opponents) + structure level."""
    return {
        "current_price": price, "symbol": symbol,
        "technical": {"direction": "SELL", "confidence": 82.0},
        "classical": {"direction": "SELL", "confidence": 60.0,
                      "resistance": [level]},
        "multitimeframe": {"direction": "SELL", "confidence": 57.0},
        "smc": {"direction": "SELL", "confidence": 59.5},
        "price_action": {"direction": "WAIT", "confidence": 50.0},
        "auction_flow": {"direction": "WAIT", "confidence": 50.0},
    }


def _pts(symbol, price_delta):
    """The CODE's own converter is the law (FX 1pt = 0.00001: 225 pts = 27
    pips; gold 1pt = 0.1) - never hand-computed divisors."""
    import scripts.run_analysis as ra
    return abs(ra.price_to_points(price_delta, symbol=symbol))


def test_be_locked_fx_parent_add_stop_floored_to_law(tmp_path, monkeypatch):
    """GBP SELL parent BE-locked at entry-225pts (27 pips): the naive clone
    would give the add a 225-pt stop. The law floors it to 405 pts — and the
    size ratio rides the confirmed 1.0x."""
    db = _DB([_parent("GBP/USD", "SELL", 1.35504, 1.35234, 1.35186, 1.35000)])
    results = _clean_sell_book(1.35800, 1.35800, "GBP/USD")  # 296 pts pullback >= 225
    _run(monkeypatch, db, results, _cfg(ratio=1.0))
    assert db.saved, "the add must enter (clean book, distance met)"
    sig = db.saved[0]["signal"]
    stop_pts = _pts("GBP/USD", sig["stop_loss"] - 1.35800)
    assert 404 <= stop_pts <= 406, "stop must be floored to the 405-pt law floor, got %.0f" % stop_pts
    assert sig["scale_in_size_ratio"] == 1.0
    assert any(r.get("outcome") == "ENTERED" for r in db.audit_rows
               if r.get("stage") == "scale_in")


def test_legacy_wide_fx_parent_add_stop_capped_to_law(tmp_path, monkeypatch):
    """SUPERSEDED AGAIN 2026-09-10 (R47 'لكلٍّ مسافته، ولا يتيم', reversing
    R42 one day later): the add now clones the parent's stop DISTANCE at
    its own entry and the inherited-flag is gone, so the 600-pt FX band
    clamp applies to EVERY add. Clone here: child entry + parent's 1025
    pts -> capped back to 600 pts from the child's entry."""
    db = _DB([_parent("GBP/USD", "SELL", 1.35504, 1.36529, 1.35186, 1.35000)])
    results = _clean_sell_book(1.35800, 1.35800, "GBP/USD")
    _run(monkeypatch, db, results, _cfg(ratio=1.0))
    assert db.saved
    sig = db.saved[0]["signal"]
    stop = sig["stop_loss"]
    # 600-pt cap from the CHILD's own entry (SELL: above entry)
    from utils.instruments import points_to_price
    child_entry = sig.get("entry_price")
    if not isinstance(child_entry, (int, float)) or child_entry <= 0:
        ev = sig.get("evaluation") or sig.get("signal_snapshot") or {}
        ent = (sig.get("entry") or (ev.get("levels") or {}).get("entry")
               or (ev.get("signal") or {}).get("entry_price"))
        if isinstance(ent, dict):
            ent = ent.get("price")
        if isinstance(ent, (int, float)) and ent > 0:
            child_entry = float(ent)
    assert isinstance(child_entry, (int, float)) and child_entry > 0, (
        f"signal has no numeric entry to anchor: {sig!r}")
    child_entry = float(child_entry)
    assert abs(stop - (child_entry + points_to_price(600, "GBP/USD"))) < 2e-5, (
        "R47: distance clone capped to the 600-pt band at the child's "
        f"own entry ({child_entry}), got {stop!r}")


def test_gold_add_clone_stays_byte_identical(tmp_path, monkeypatch):
    """Gold is the reference and is UNTOUCHED: a BE-locked gold parent
    (entry-150) still hands the add the exact 150-pt clone — the clamp is a
    no-op on the (0, 0) gold band."""
    db = _DB([_parent("XAU/USD", "SELL", 4400.0, 4385.0, 4370.0, 4340.0)])
    results = _clean_sell_book(4420.0, 4420.0, "XAU/USD")  # 200 pts >= 150
    _run(monkeypatch, db, results, _cfg(ratio=1.0))
    assert db.saved
    stop = db.saved[0]["signal"]["stop_loss"]
    assert stop == 4435.0, "gold clone must stay byte-identical (4420+15), got %r" % stop


def test_missing_size_ratio_defaults_to_full(tmp_path, monkeypatch):
    """No scale_in_size_ratio key in config -> FULL size (1.0x), the
    operator-confirmed law; the legacy 0.5 fallback is dead."""
    db = _DB([_parent("GBP/USD", "SELL", 1.35504, 1.30000, 1.35186, 1.35000)])
    results = _clean_sell_book(1.35800, 1.35800, "GBP/USD")  # 496-pt stop: in band
    _run(monkeypatch, db, results, _cfg(ratio=None))
    assert db.saved
    sig = db.saved[0]["signal"]
    assert sig["scale_in_size_ratio"] == 1.0
    stop_pts = _pts("GBP/USD", sig["stop_loss"] - 1.35800)
    assert 405 <= stop_pts <= 600.1, "in-band clone must pass the clamp untouched"
