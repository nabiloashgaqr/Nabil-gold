"""THE single source of truth for the stop / targets / trailing / post-TP2 laws.

Operator directive 2026-08-07 (full audit): one place owns the maths and the
fallback defaults; every door (run_analysis, the risk agent, the session
planner fallback, open-trades management, the post-TP2 guard) calls this
module and nothing else. `tests/test_one_source_of_trading_rules.py` fails if
any other module mentions the rule keys or re-implements the formulae.

The DATA stays in config.json; this module owns the FORMULAE and the default
values used when a key is absent. Changing a number in config.json binds
every door at once -- that is the whole point.
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

from utils.instruments import (points_to_price, price_to_points, round_price,
                               point_size, get_instrument)

# ── the only fallback defaults in the codebase ─────────────────────────────
DEFAULT_STOP_RULE = {"min_liquidity_points": 200.0, "safety_buffer_points": 70.0,
                     "max_stop_points": 400.0}
DEFAULT_MIN_TP1_RR = 0.8
DEFAULT_TP2_MULTIPLE = 2.0
DEFAULT_MAX_TP2_BEYOND_POINTS = 200.0
DEFAULT_POST_TP2 = {"min_distance_points": 250.0, "window_hours": 2.5}
DEFAULT_TRAILING = {"enabled": False, "distance_points": 150.0, "step_points": 40.0}


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _block(cfg: Dict[str, Any], name: str) -> Dict[str, Any]:
    """Phase 2: the canonical `trading_rules.<name>` block wins; the legacy
    sections (risk_settings / trade_management / trailing_stop /
    post_tp2_reentry) remain read-compatible aliases."""
    return ((cfg or {}).get("trading_rules") or {}).get(name) or {}


# ── stops ───────────────────────────────────────────────────────────────────

def stop_rule(cfg: Dict[str, Any]) -> Dict[str, float]:
    """The liquidity-rule stop parameters (200 / 70 / 400 on gold today)."""
    raw = _block(cfg, "stop") or ((cfg or {}).get("risk_settings") or {}).get("stop_from_liquidity") or {}
    out = dict(DEFAULT_STOP_RULE)
    for key in out:
        if _f(raw.get(key), 0.0) > 0:
            out[key] = _f(raw.get(key))
    out["enabled"] = bool(raw.get("enabled", True))
    return out


def stop_rule_for_symbol(cfg: Dict[str, Any], symbol: Any) -> Dict[str, float]:
    """Single source of truth for the PER-SYMBOL stop law (R26.6).

    Base canonical block (gold 200/70/400) overridden by the instrument spec's
    own trading_rules.stop when present (WTI 100/35/200; FX 300/105/600 — ×1.5, final law).
    Every door that needs a stop band — the live clamp AND the observational
    auditor — must call THIS so they can never disagree per symbol.
    """
    rule = stop_rule(cfg)
    try:
        spec = get_instrument(cfg, symbol) or {}
        inst_stop = ((spec.get("trading_rules") or {}).get("stop")) or None
        if isinstance(inst_stop, dict):
            for key in list(rule.keys()):
                if key not in inst_stop:
                    continue
                rule[key] = (bool(inst_stop[key]) if key == "enabled"
                             else _f(inst_stop[key]))
    except Exception:  # noqa: BLE001 - fall back to the base block
        pass
    return rule


def risk_floor_points(cfg: Dict[str, Any], symbol: Any) -> float:
    """FLOOR in POINTS of the symbol's risk band via the single source
    (min_liquidity_points + safety_buffer_points): XAU 270, EUR/GBP/CAD
    405, USD/JPY 540, WTI 135. For MOVE-side guards (R45-v2(b)) -- unlike
    law_band_points, gold does NOT zero out here: the stop RULE is per
    symbol by construction and the reference pair keeps its own law.
    0.0 only when the rule block is absent/disabled."""
    try:
        rule = stop_rule_for_symbol(cfg, symbol)
        if not rule.get("enabled", False):
            return 0.0
        return float(rule.get("min_liquidity_points") or 0.0) \
            + float(rule.get("safety_buffer_points") or 0.0)
    except Exception:  # noqa: BLE001 - guards must fail-open
        return 0.0


def law_band_points(cfg: Dict[str, Any], symbol: Any) -> Tuple[float, float]:
    """(floor, cap) in POINTS of the symbol's lawful stop band (R26.9.5/6).

    Gold's laws apply in full with only the ratio differing (operator
    2026-09-01: "قوانين الذهب تُطبَّق كاملة مع فرق النسبة: النفط 0.5
    والفوركس 1.8"): floor = min_liquidity_points + safety_buffer_points and
    cap = max_stop_points, per instrument -- gold 270-400, WTI x0.5
    135-200, FX x1.5 405-600.

    R26.9.6: the R26.9.5 detection ("symbol rule differs from the canonical
    block") never fired LIVE, because the live loop passes an
    instrument-MERGED config whose canonical block already IS the symbol's
    law -- the two always compared equal and every FX/WTI plan kept the
    gold-calibrated 'Wide stop' -10 on a lawful stop (proven: EUR stop 686
    pts, method liquidity_rule_300_600, note 'Wide stop'). Detection is now
    law-based, not config-shape-based:

      * XAU/USD -- the reference pair -- always returns (0, 0): legacy ATR
        axis, byte-identical behaviour.
      * A symbol whose resolved rule equals the gold DEFAULT block (i.e. it
        carries no law of its own -- unknown/test instruments) returns
        (0, 0): legacy axis, untouched.
      * A symbol with its own law (numbers differ from the gold default and
        the rule is enabled) returns that law's band, whatever shape the
        config arrived in (raw or instrument-merged).
    """
    try:
        from utils.instruments import normalize_symbol as _norm_sym
        if _norm_sym(symbol) == "XAU/USD":
            return 0.0, 0.0
    except Exception:  # noqa: BLE001
        return 0.0, 0.0
    rule = stop_rule_for_symbol(cfg, symbol)
    if not bool(rule.get("enabled", True)):
        return 0.0, 0.0
    floor = _f(rule.get("min_liquidity_points")) + _f(rule.get("safety_buffer_points"))
    cap = _f(rule.get("max_stop_points"))
    if not (0 < floor <= cap):
        return 0.0, 0.0
    if (floor, cap) == (
        _f(DEFAULT_STOP_RULE.get("min_liquidity_points"))
        + _f(DEFAULT_STOP_RULE.get("safety_buffer_points")),
        _f(DEFAULT_STOP_RULE.get("max_stop_points")),
    ):
        # no law of its own -- the gold defaults resolved through
        return 0.0, 0.0
    return floor, cap


def zone_touch_width_points(cfg: Dict[str, Any], symbol: Any) -> float:
    """R43 (operator order 2026-09-09): ONE source for the zone-touch watch
    width. Default law stays intact: gold base zone_width_points x the
    canonical distance ratio (XAU x1.0 -> 80, WTI x0.5 -> 40, FX x1.5).
    Per-symbol overrides (order_execution.zone_touch_activation.
    zone_width_points_overrides, e.g. {"WTI/USD": 60.0}) take precedence
    verbatim - declared in the SYMBOL's OWN points, never mixed.
    """
    zcfg = (((cfg.get("order_execution") or {})
             .get("zone_touch_activation")) or {})
    overrides = zcfg.get("zone_width_points_overrides") or {}
    if isinstance(overrides, dict) and overrides:
        s = str(symbol or "").upper().replace("/", "")
        for k, v in overrides.items():
            if str(k).upper().replace("/", "") == s:
                return float(v)
    return float(zcfg.get("zone_width_points", 80) or 80) * float(
        distance_ratio(cfg, symbol))


def distance_ratio(cfg: Dict[str, Any], symbol: Any) -> float:
    """The operator's ratio law as a multiplier (R26.9.7): gold 1.0,
    WTI x0.5, FX x1.5.

    "قوانين الذهب تُطبَّق كاملة مع فرق النسبة" — every gold-calibrated
    DISTANCE in points must scale by the symbol's ratio. The ratio is
    DERIVED from the law's own caps (symbol cap / gold cap), never
    re-declared: change a cap in the law and every distance scaling
    through this follows automatically. Symbols with no law of their own
    resolve to the gold defaults -> 1.0 (legacy behaviour, untouched).
    Works in BOTH config shapes (raw and instrument-merged).
    """
    try:
        cap = _f(stop_rule_for_symbol(cfg, symbol).get("max_stop_points"))
    except Exception:  # noqa: BLE001
        return 1.0
    gold = _f(DEFAULT_STOP_RULE.get("max_stop_points"))
    if cap <= 0 or gold <= 0:
        return 1.0
    return cap / gold


def stop_from_liquidity_points(
    *,
    direction: str,
    entry: float,
    liquidity_map: Dict[str, Any] | None,
    cfg: Dict[str, Any],
    symbol: str,
    rule: Dict[str, Any] | None = None,
) -> float:
    """Distance in POINTS of the rule stop from entry.

    Liquidity closer than min_liquidity_points is noise; the stop sits
    safety_buffer_points beyond the first eligible level; beyond
    max_stop_points (or none eligible) ships the cap directly.
    """
    if rule is not None:
        merged = dict(DEFAULT_STOP_RULE)
        for key in merged:
            if _f(rule.get(key), 0.0) > 0:
                merged[key] = _f(rule.get(key))
        merged["enabled"] = bool(rule.get("enabled", True))
        rule = merged
    else:
        rule = stop_rule(cfg)
    if not rule["enabled"]:
        flat = _f(((cfg or {}).get("risk_settings") or {}).get("min_sl_distance_points"), 0.0)
        return flat
    liquidity_map = liquidity_map or {}
    side = "sell_side" if direction == "BUY" else "buy_side"
    distances: List[float] = []
    for raw in list(liquidity_map.get(side) or []):
        level = _f(raw, 0.0)
        if level <= 0:
            continue
        if (level < entry) if direction == "BUY" else (level > entry):
            distances.append(abs(price_to_points(entry - level, symbol)))
    eligible = sorted(d for d in distances if d >= rule["min_liquidity_points"])
    if not eligible or eligible[0] > rule["max_stop_points"]:
        return rule["max_stop_points"]
    return min(eligible[0] + rule["safety_buffer_points"], rule["max_stop_points"])


# ── targets ─────────────────────────────────────────────────────────────────

def clamp_stop_price(*, direction: str, entry: float, stop: float,
                     cfg: Dict[str, Any], symbol: str) -> float:
    """The band law applied to a PRICE level (R25.7-E, live 2026-08-28).

    Live incident: the PATH 6 pre-arm anchored its stop to the leg origin
    + 1.0xATR and shipped a gold SELL LIMIT with a 708.6-pt stop (cap 400)
    on a crash-day ATR. A stop whose distance from entry falls outside the
    symbol's [floor, cap] band is clamped back inside: floor =
    min_liquidity_points + safety_buffer_points, cap = max_stop_points.
    A wrong-side stop (at/beyond entry — BE, trailing, protection) is
    returned UNTOUCHED: this clamp is for INITIAL risk stops only, and
    protection is never widened here.
    """
    # The band is PER SYMBOL, from the single-source loader
    # (gold 200/70/400 -> [270,400]; WTI 100/35/200 -> [135,200];
    # FX 300/105/600 -> [405,600]).
    rule = stop_rule_for_symbol(cfg, symbol)
    entry = float(entry or 0.0)
    stop = float(stop or 0.0)
    if not rule.get("enabled", False) or entry <= 0 or stop <= 0:
        return stop
    pv = point_size(symbol, cfg)
    if pv <= 0:
        return stop
    side = str(direction or "").upper()
    if side not in {"BUY", "SELL"}:
        return stop
    wrong_side = ((side == "BUY" and stop >= entry)
                  or (side == "SELL" and stop <= entry))
    if wrong_side:
        return stop
    pts = abs(entry - stop) / pv
    floor = float(rule["min_liquidity_points"]) + float(rule["safety_buffer_points"])
    cap = float(rule["max_stop_points"])
    if pts > cap:
        target = cap
    elif pts < floor:
        target = floor
    else:
        return stop
    clamped = entry - target * pv if side == "BUY" else entry + target * pv
    return round_price(clamped, symbol, cfg)


def target_ratios(cfg: Dict[str, Any], risk: Dict[str, Any] | None = None,
                  default_min_tp1_rr: float = DEFAULT_MIN_TP1_RR) -> Dict[str, float]:
    """default_min_tp1_rr=0.0 reproduces the old VALIDATOR semantics (skip the
    check when the key is absent); the target law itself enforces 0.8."""
    canon = _block(cfg, "targets")
    risk = risk if risk is not None else ((cfg or {}).get("risk_settings") or {})
    def _pick(canon_key: str, legacy_key: str, default: float) -> float:
        if _f(canon.get(canon_key), 0.0) > 0:
            return _f(canon.get(canon_key))
        return _f(risk.get(legacy_key), default)
    return {
        "min_tp1_rr": _pick("min_tp1_rr", "min_tp1_rr", default_min_tp1_rr) or default_min_tp1_rr,
        "tp2_multiple": _pick("tp2_multiple", "min_tp2_multiple_of_tp1", DEFAULT_TP2_MULTIPLE) or DEFAULT_TP2_MULTIPLE,
        "max_beyond_points": _pick("max_beyond_points", "max_tp2_beyond_tp1_points", DEFAULT_MAX_TP2_BEYOND_POINTS),
    }


def target_ratios_for_symbol(cfg: Dict[str, Any], symbol: Any,
                             risk: Dict[str, Any] | None = None,
                             default_min_tp1_rr: float = DEFAULT_MIN_TP1_RR) -> Dict[str, float]:
    """Per-symbol target ratios (R26.6) — single source, mirrors the stop law.

    The instrument spec's trading_rules.targets (max_beyond 450 on forex vs
    200 on gold; WTI 100) overrides the canonical block. Every door sizing
    targets must call THIS so a symbol's wider pool-search band is honoured.
    """
    ratios = target_ratios(cfg, risk, default_min_tp1_rr)
    try:
        spec = get_instrument(cfg, symbol) or {}
        inst_tgt = ((spec.get("trading_rules") or {}).get("targets")) or None
        if isinstance(inst_tgt, dict):
            for key in ("min_tp1_rr", "tp2_multiple", "max_beyond_points"):
                if key in inst_tgt and _f(inst_tgt.get(key), 0.0) > 0:
                    ratios[key] = _f(inst_tgt[key])
    except Exception:  # noqa: BLE001 - fall back to the base ratios
        pass
    return ratios


def scalp_rr_floors(config: dict | None = None) -> dict:
    """R25.4 (operator 2026-08-28): the SCALP row's own RR floors.

    The R25-2 scalp geometry is fixed-stop (350 system pts) with a
    midpoint partial and a pending-level final, so it validates under its
    own floors (r25_scalp.rr_floors), NOT the day-trade 0.8R/1.5R pair.
    Owned here like every rule key - callers never read the keys directly.
    """
    cfg = (config or {}).get("r25_scalp") or {}
    floors = cfg.get("rr_floors") or {}
    return {
        "min_tp1_rr": float(floors.get("min_tp1_rr", 0.5) or 0.5),
        "min_tp2_rr": float(floors.get("min_tp2_rr", 1.0) or 1.0),
    }


def targets_law(
    *,
    direction: str,
    entry: float,
    risk_price: float,
    levels: List[float] | None,
    cfg: Dict[str, Any],
    symbol: str,
    risk_cfg: Dict[str, Any] | None = None,
) -> Tuple[float, float, bool]:
    """(tp1, tp2, used_pool) under the operator's target law.

    TP1 = a real pool within max_beyond of the 0.8R rung, else the rung.
    TP2 = double the TP1 distance; a pool AFTER the adjusted level within
    max_beyond (200 pts) is a better objective and wins (farthest in band).
    """
    ratios = target_ratios_for_symbol(cfg, symbol, risk_cfg)
    max_beyond = points_to_price(ratios["max_beyond_points"], symbol)

    def _dist(level: float) -> float:
        return abs(level - entry)

    ordered = sorted(
        {lv for lv in (levels or []) if _f(lv, 0.0) > 0 and
         ((lv > entry) if direction == "BUY" else (lv < entry))},
        key=_dist,
    )

    # BUILD 18 (2026-08-20): per-instrument absolute target caps. Gold ships
    # liquidity objectives ~2% away; on WTI the same law shipped TP2 477 pts
    # (5.5% of price) from round-number pools. Far pools beyond the caps are
    # DROPPED before the band math, so the 0.8R rung / 2xTP1 fallbacks ship
    # instead. No cap key (0) = historical behaviour unchanged.
    _tgt_cfg = ((cfg or {}).get("trading_rules") or {}).get("targets") or {}
    _max_tp2_pts = _f(_tgt_cfg.get("max_tp2_points"), 0.0)
    if _max_tp2_pts > 0:
        _cap_price = points_to_price(_max_tp2_pts, symbol)
        ordered = [lv for lv in ordered if _dist(lv) <= _cap_price]

    def _level(rr_r: float) -> float:
        return entry + risk_price * rr_r if direction == "BUY" else entry - risk_price * rr_r

    d_ratio = _dist(_level(ratios["min_tp1_rr"]))
    tp1_pools = [lv for lv in ordered if d_ratio <= _dist(lv) <= d_ratio + max_beyond]
    used_pool = bool(tp1_pools)
    tp1 = min(tp1_pools, key=_dist) if tp1_pools else _level(ratios["min_tp1_rr"])

    d1 = _dist(tp1)
    d2_default = ratios["tp2_multiple"] * d1
    beyond = [lv for lv in ordered if d2_default < _dist(lv) <= d2_default + max_beyond]
    if beyond:
        tp2 = max(beyond, key=_dist)
        used_pool = True
    else:
        tp2 = (entry + d2_default) if direction == "BUY" else (entry - d2_default)
    # BUILD 18: absolute clamp as a last line (a wide stop config could still
    # push the 2x rung past the cap; the cap is about DISTANCE, not R:R).
    if _max_tp2_pts > 0:
        _cap_price = points_to_price(_max_tp2_pts, symbol)
        if _dist(tp2) > _cap_price:
            tp2 = (entry + _cap_price) if direction == "BUY" else (entry - _cap_price)
            if _dist(tp2) < _dist(tp1):
                tp2 = tp1
    return round_price(tp1, symbol, cfg), round_price(tp2, symbol, cfg), used_pool


# ── protection / trailing / breakeven ──────────────────────────────────────

def protection_params(cfg: Dict[str, Any], symbol: Any = None) -> Dict[str, float]:
    """Canonical per-symbol protection law.

    This is the only runtime source for the BE profit lock.  Instrument rows
    may override ``trading_rules.protection.be_lock_points``; the root block is
    the compatibility fallback for gold/unknown symbols.
    """
    root = _block(cfg, "protection")
    spec = get_instrument(cfg, symbol) if symbol is not None else {}
    inst = ((spec.get("trading_rules") or {}).get("protection") or {})
    points = _f(inst.get("be_lock_points"), _f(root.get("be_lock_points"), 0.0))
    return {"be_lock_points": max(0.0, points)}


def breakeven_stop(cfg: Dict[str, Any], symbol: Any, direction: str,
                   entry: float) -> float:
    """Return BE inside profit: BUY entry+margin, SELL entry-margin."""
    margin = points_to_price(protection_params(cfg, symbol)["be_lock_points"], symbol, cfg)
    price = float(entry) + margin if str(direction).upper() == "BUY" else float(entry) - margin
    return round_price(price, symbol, cfg)


def is_protected(direction: str, entry: float, stop: float,
                 marker: bool = False) -> bool:
    """Protection is evidence OR geometry, never the marker alone."""
    if marker:
        return True
    side = str(direction or "").upper()
    return bool(entry > 0 and stop > 0 and
                ((side == "BUY" and stop >= entry) or
                 (side == "SELL" and stop <= entry)))


def tighten_only_stop(direction: str, current_stop: float,
                      candidate: float) -> float | None:
    """Return a ratchet-only candidate; ``None`` means it would move back."""
    cur, cand = _f(current_stop), _f(candidate)
    if cand <= 0:
        return None
    if cur <= 0:
        return cand
    side = str(direction or "").upper()
    if (side == "BUY" and cand <= cur) or (side == "SELL" and cand >= cur):
        return None
    return cand


def trailing_params(cfg: Dict[str, Any], profile: str | None = None,
                    symbol: Any = None) -> Dict[str, Any]:
    """Single source for trailing, with the precedence the engine always had:

        canonical trading_rules.trailing  >  specialised profile  >  root
        trade_management  >  default_profile  >  legacy trailing_stop.

    2026-08-07 "150/40 للكل": the shipped config carries the canonical block,
    so every profile gets 150/40 regardless. Legacy configs without the
    canonical block keep the old profile freedom (root outranks
    default_profile; specialised profiles outrank root). early_breakeven
    follows the same chain (unification covered trailing only).
    """
    canon = _block(cfg, "trailing")
    profiles = ((cfg or {}).get("trade_management") or {}).get("profiles") or {}
    pname = profile or "default_profile"
    prof = profiles.get(pname) or {}
    is_default = pname == "default_profile"
    tm = (cfg or {}).get("trade_management") or {}
    ts = (cfg or {}).get("trailing_stop") or {}
    out = dict(DEFAULT_TRAILING)

    def _pick(canon_k: str | None, prof_k: str, tm_k: str, ts_k: str, dflt: float) -> float:
        if canon_k and _f(canon.get(canon_k), 0.0) > 0:
            return _f(canon.get(canon_k))
        if not is_default and _f(prof.get(prof_k), 0.0) > 0:
            return _f(prof.get(prof_k))
        if _f(tm.get(tm_k), 0.0) > 0:
            return _f(tm.get(tm_k))
        if _f(prof.get(prof_k), 0.0) > 0:
            return _f(prof.get(prof_k))
        if _f(ts.get(ts_k), 0.0) > 0:
            return _f(ts.get(ts_k))
        return dflt

    out["enabled"] = bool(canon.get("enabled", prof.get("trailing_enabled",
        tm.get("trailing_stop_enabled", ts.get("enabled", out["enabled"])))) or out["enabled"])
    out["distance_points"] = _pick("distance_points", "trailing_distance_points",
                                   "trailing_distance_points", "trailing_distance",
                                   out["distance_points"])
    out["step_points"] = _pick("step_points", "trailing_step_points",
                               "trailing_step_points", "trailing_step",
                               out["step_points"])
    # 2026-08-07 (operator): early breakeven unified at 150 for ALL profiles;
    # the canonical key now outranks profiles like the rest of trailing.
    out["early_breakeven_points"] = _pick("early_breakeven_points", "early_breakeven_points",
                                          "early_breakeven_points", "early_breakeven_points",
                                          200.0)
    out["activation_at"] = str(canon.get("activation_at", tm.get("trailing_activation_at", "TP1")))

    # R26.9.11 (operator 2026-09-03, FX stop audit): fix the precedence
    # that armed FX breakeven 15 pips into FX noise. The 2026-08-07
    # «تريلنج موحد 150/40 للكل» canonical block outranked everything, so FX
    # ran with GOLD's 150-pt early breakeven while the instrument blocks
    # (EUR 225/60/225 = x1.5) and the cards were already correct.
    #
    # Law (R26.9.7 «قوانين الذهب كاملة مع فرق النسبة»): with a symbol, every
    # gold-point trailing distance scales by distance_ratio (FX x1.5,
    # WTI x0.5, gold 1.0 -> no-op). Per-key skip when the passed cfg already
    # carries THIS instrument's own number (instrument-merged configs from
    # config_for_instrument) so a merged call never double-scales.
    # symbol=None keeps the legacy behaviour byte-for-byte.
    try:
        if symbol is not None:
            _inst = (((get_instrument(cfg, symbol) or {}).get("trading_rules") or {})
                     .get("trailing"))
            _inst = _inst if isinstance(_inst, dict) else {}
            _ratio = distance_ratio(cfg, symbol)
            if abs(_ratio - 1.0) > 1e-9:
                for _src, _dst in (("distance_points", "distance_points"),
                                   ("step_points", "step_points"),
                                   ("early_breakeven_points", "early_breakeven_points")):
                    _iv = _f(_inst.get(_src), 0.0)
                    _cv = _f((canon or {}).get(_src), 0.0)
                    if _iv > 0 and _cv == _iv:
                        continue  # cfg already holds this instrument's number
                    if _f(out.get(_dst), 0.0) > 0:
                        out[_dst] = _f(out[_dst]) * _ratio
    except Exception:  # noqa: BLE001 - fail open to the unscaled values
        pass
    return out


# ── momentum clutch (R26.8) ─────────────────────────────────────────────────
# During a strong impulse the normal fixed-gap trail (price - 150 pts) is
# shaken out by a normal pullback, after which price resumes. The clutch
# anchors the stop to the latest confirmed STRUCTURE (last swing extreme)
# with an ATR-scaled safety margin instead of chasing the tick. It can only
# ever HOLD a looser (structure-aware) stop during the impulse; it never
# widens an already-tighter stop and never gives back locked profit.
DEFAULT_MOMENTUM_CLUTCH = {
    "enabled": True,
    "atr_period": 14,
    "atr_k": 1.3,              # safety margin = k * ATR beyond the structure
    # R26.8 EARLY acceleration detection on the M5 frame (fires on the FIRST
    # impulse candle via burst_vs_noise; big/fast ATR tests confirm continuation):
    #  * burst_vs_noise: one CLOSED 5m candle whose body is >= 3x the prior
    #    noise range and >= 35 pts - catches acceleration before ATR catches up;
    #  * candle_atr_mult: a single body >= 2 ATR (catches it in elevated ATR);
    #  * speed: two candles covering >= 3 ATR confirms a sustained run.
    "burst_vs_noise_mult": 3.0,
    "burst_min_points": 35.0,
    "candle_atr_mult": 2.0,
    "speed_atr_mult": 3.0,
    "speed_lookback": 2,       # 2-candle window = catch it from the start
    "anchor_lookback": 5,      # swing extreme tracked over last 5 closed 5m candles
    "min_gap_points": 150.0,   # floor on the ATR margin (never looser than trail)
    "max_gap_points": 400.0,   # cap on the ATR margin (gold)
}


def momentum_clutch_params(cfg: Dict[str, Any], symbol: Any = None) -> Dict[str, Any]:
    """Single source for the momentum-clutch rule, with a per-instrument
    trading_rules.momentum_clutch override (oil/forex scale differently).

    fail-open: any unreadable config falls back to the gold defaults.

    R26.9.10 (operator 2026-09-01: "قوانين الذهب كاملة مع فرق النسبة — نفط
    0.5 وفوركس 1.8"): the POINT-based thresholds are GOLD points and must
    scale by the law's ratio like every other distance. The defaults ship
    gold numbers (burst 35, gap [150,400]); WTI resolves x0.5 and the four
    forex pairs x1.5 (derived from the stop caps -- single source, never
    re-declared). An instrument block that sets a point field explicitly is
    honoured VERBATIM (no double scaling); multipliers and periods are
    symbol-agnostic and never scaled.
    """
    out = dict(DEFAULT_MOMENTUM_CLUTCH)
    _POINT_KEYS = ("burst_min_points", "min_gap_points", "max_gap_points")
    inst_point_keys: set = set()
    try:
        block = ((cfg or {}).get("trading_rules") or {}).get("momentum_clutch") or {}
        for k, dflt in out.items():
            if k == "enabled":
                out[k] = bool(block.get("enabled", dflt))
            elif k in ("atr_period", "speed_lookback", "anchor_lookback"):
                out[k] = int(_f(block.get(k, dflt), dflt))
            else:
                out[k] = _f(block.get(k, dflt), dflt)
        spec = get_instrument(cfg, symbol) or {}
        inst = ((spec.get("trading_rules") or {}).get("momentum_clutch")) or None
        if isinstance(inst, dict):
            for k in out:
                if k not in inst or inst.get(k) is None:
                    continue
                if k == "enabled":
                    out[k] = bool(inst[k])
                elif k in ("atr_period", "speed_lookback", "anchor_lookback"):
                    out[k] = int(_f(inst[k], out[k]))
                else:
                    out[k] = _f(inst[k], out[k])
                if k in _POINT_KEYS:
                    inst_point_keys.add(k)
    except Exception:  # noqa: BLE001 - fail open to defaults
        pass
    # R26.9.10: scale the gold-point thresholds by the symbol's law ratio,
    # unless the instrument block set them explicitly.
    try:
        ratio = distance_ratio(cfg, symbol)
        if abs(ratio - 1.0) > 1e-9:
            for k in _POINT_KEYS:
                if k not in inst_point_keys:
                    out[k] = _f(out.get(k)) * ratio
    except Exception:  # noqa: BLE001 - fail open to unscaled defaults
        pass
    return out


# ── display wording (phase 3) ───────────────────────────────────────────────

def stop_rule_note(cfg: Dict[str, Any]) -> str:
    """The one sentence every card prints about the stop rule; built from the
    live numbers so a config change rewrites every card automatically."""
    r = stop_rule(cfg)
    return (f"Execution stop set by the operator liquidity rule "
            f"(ignore <{r['min_liquidity_points']:.0f} pts, "
            f"+{r['safety_buffer_points']:.0f} safety, "
            f"cap {r['max_stop_points']:.0f}).")


def post_tp2_note(cfg: Dict[str, Any]) -> str:
    r = post_tp2_rule(cfg)
    window = f"{r['window_hours']:g}h"
    return (f"Post-TP2 same-direction re-entry blocked within "
            f"{r['min_distance_points']:.0f} pts of the exhausted TP2 for "
            f"{window} (absolute, no early release).")


# ── post-TP2 re-entry ───────────────────────────────────────────────────────

def post_tp2_rule(cfg: Dict[str, Any]) -> Dict[str, Any]:
    raw = _block(cfg, "post_tp2") or (cfg or {}).get("post_tp2_reentry") or {}
    out = dict(DEFAULT_POST_TP2)
    if _f(raw.get("min_distance_points"), 0.0) > 0:
        out["min_distance_points"] = _f(raw.get("min_distance_points"))
    if _f(raw.get("window_hours"), 0.0) > 0:
        out["window_hours"] = _f(raw.get("window_hours"))
    out["enabled"] = bool(raw.get("enabled", True))
    return out
