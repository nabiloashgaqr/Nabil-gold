"""Instrument metadata and point conversion helpers.

The project stores PnL/SL/TP distances in broker-style *points*:
- Gold XAU/USD: 1 point = 0.10 USD (10 points = 1.00)
- FX non-JPY: 1 point = 0.00001 (10 points = 1 pip)
- FX JPY pairs: 1 point = 0.001 (10 points = 1 pip)
- WTI oil: 1 point = 0.01 USD
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List


DEFAULT_INSTRUMENTS: Dict[str, Dict[str, Any]] = {
    "XAU/USD": {
        "symbol": "XAU/USD", "name": "Gold", "category": "metal",
        "point_size": 0.10, "price_decimals": 2,
        "min_sl_distance_points": 400, "trailing_distance": 150, "trailing_step": 40,
        "early_breakeven_points": 150, "duplicate_zone_points": 150,
        "trading_rules": {
            "stop": {"enabled": True, "min_liquidity_points": 200,
                     "safety_buffer_points": 70, "max_stop_points": 400},
            "targets": {"min_tp1_rr": 0.8, "tp2_multiple": 2.0,
                        "max_beyond_points": 200},
            "trailing": {"enabled": True, "distance_points": 150,
                         "step_points": 40, "activation_at": "BREAKEVEN",
                         "early_breakeven_points": 150},
            "post_tp2": {"enabled": True, "min_distance_points": 250,
                         "window_hours": 2.5},
        },
        "session_planner": {
            "fallback_zone_half_width_points": 120,
            "standby_min_distance_points": 150,
            "max_primary_zone_width_points": 450,
            "max_standby_zone_width_points": 450,
            "min_zone_width_points": 6.0,
            "min_entry_zone_width_points": 60,
            "min_thesis_objective_points": 30,
        },
        "cross_entry_distance_points": 150,
        "scale_in_trigger_points": 150,
        "auction_flow": {"calibration_required": True},
    },
    "WTI/USD": {
        "symbol": "WTI/USD", "name": "WTI Crude Oil", "category": "oil",
        "point_size": 0.01, "price_decimals": 2,
        "min_sl_distance_points": 200, "trailing_distance": 75, "trailing_step": 20,
        "early_breakeven_points": 75, "duplicate_zone_points": 75,
        "trading_rules": {
            "stop": {"enabled": True, "min_liquidity_points": 100,
                     "safety_buffer_points": 35, "max_stop_points": 200},
            "targets": {"min_tp1_rr": 0.8, "tp2_multiple": 2.0,
                        "max_beyond_points": 100},
            "trailing": {"enabled": True, "distance_points": 75,
                         "step_points": 20, "activation_at": "BREAKEVEN",
                         "early_breakeven_points": 75},
            "post_tp2": {"enabled": True, "min_distance_points": 125,
                         "window_hours": 2.5},
        },
        "session_planner": {
            "fallback_zone_half_width_points": 60,
            "standby_min_distance_points": 75,
            "max_primary_zone_width_points": 225,
            "max_standby_zone_width_points": 225,
            "min_zone_width_points": 3.0,
            "min_entry_zone_width_points": 30,
            "min_thesis_objective_points": 15,
        },
        "cross_entry_distance_points": 75,
        "scale_in_trigger_points": 150,
        "auction_flow": {"calibration_required": False},
    },
    "EUR/USD": {
        "symbol": "EUR/USD", "name": "Euro / US Dollar", "category": "forex",
        "point_size": 0.00001, "price_decimals": 5,
        "min_sl_distance_points": 600, "trailing_distance": 225, "trailing_step": 60,
        "early_breakeven_points": 225, "duplicate_zone_points": 225,
        "distance_ratio": 1.5,
        "trading_rules": {
            "stop": {"enabled": True, "min_liquidity_points": 300,
                     "safety_buffer_points": 105, "max_stop_points": 600},
            "targets": {"min_tp1_rr": 0.8, "tp2_multiple": 2.0,
                        "max_beyond_points": 300},
            "trailing": {"enabled": True, "distance_points": 225,
                         "step_points": 60, "activation_at": "BREAKEVEN",
                         "early_breakeven_points": 225},
            "protection": {"be_lock_points": 60},
            "post_tp2": {"enabled": True, "min_distance_points": 375,
                         "window_hours": 2.5},
        },
        "session_planner": {
            "fallback_zone_half_width_points": 180,
            "standby_min_distance_points": 225,
            "max_primary_zone_width_points": 675,
            "max_standby_zone_width_points": 675,
            "min_zone_width_points": 9.0,
            "min_entry_zone_width_points": 90,
            "min_thesis_objective_points": 45,
        },
        "cross_entry_distance_points": 225,
        "scale_in_trigger_points": 150,
        "auction_flow": {"calibration_required": False},
    },
    "GBP/USD": {
        "symbol": "GBP/USD", "name": "British Pound / US Dollar", "category": "forex",
        "point_size": 0.00001, "price_decimals": 5,
        "min_sl_distance_points": 600, "trailing_distance": 225, "trailing_step": 60,
        "early_breakeven_points": 225, "duplicate_zone_points": 225,
        "distance_ratio": 1.5,
        "trading_rules": {
            "stop": {"enabled": True, "min_liquidity_points": 300,
                     "safety_buffer_points": 105, "max_stop_points": 600},
            "targets": {"min_tp1_rr": 0.8, "tp2_multiple": 2.0,
                        "max_beyond_points": 300},
            "trailing": {"enabled": True, "distance_points": 225,
                         "step_points": 60, "activation_at": "BREAKEVEN",
                         "early_breakeven_points": 225},
            "protection": {"be_lock_points": 60},
            "post_tp2": {"enabled": True, "min_distance_points": 375,
                         "window_hours": 2.5},
        },
        "session_planner": {
            "fallback_zone_half_width_points": 180,
            "standby_min_distance_points": 225,
            "max_primary_zone_width_points": 675,
            "max_standby_zone_width_points": 675,
            "min_zone_width_points": 9.0,
            "min_entry_zone_width_points": 90,
            "min_thesis_objective_points": 45,
        },
        "cross_entry_distance_points": 225,
        "scale_in_trigger_points": 150,
        "auction_flow": {"calibration_required": False},
    },
    "USD/CAD": {
        "symbol": "USD/CAD", "name": "US Dollar / Canadian Dollar", "category": "forex",
        "point_size": 0.00001, "price_decimals": 5,
        "min_sl_distance_points": 600, "trailing_distance": 225, "trailing_step": 60,
        "early_breakeven_points": 225, "duplicate_zone_points": 225,
        "distance_ratio": 1.5,
        "trading_rules": {
            "stop": {"enabled": True, "min_liquidity_points": 300,
                     "safety_buffer_points": 105, "max_stop_points": 600},
            "targets": {"min_tp1_rr": 0.8, "tp2_multiple": 2.0,
                        "max_beyond_points": 300},
            "trailing": {"enabled": True, "distance_points": 225,
                         "step_points": 60, "activation_at": "BREAKEVEN",
                         "early_breakeven_points": 225},
            "protection": {"be_lock_points": 60},
            "post_tp2": {"enabled": True, "min_distance_points": 375,
                         "window_hours": 2.5},
        },
        "session_planner": {
            "fallback_zone_half_width_points": 180,
            "standby_min_distance_points": 225,
            "max_primary_zone_width_points": 675,
            "max_standby_zone_width_points": 675,
            "min_zone_width_points": 9.0,
            "min_entry_zone_width_points": 90,
            "min_thesis_objective_points": 45,
        },
        "cross_entry_distance_points": 225,
        "scale_in_trigger_points": 150,
        "auction_flow": {"calibration_required": False},
    },
    # R33.5 (2026-09-08, operator order «اجعل نسبته 2.0 بدل 1.5»): this
    # pair steps OUT of the FX x1.5 class and runs its own x2.0 law.
    # Every number below is exactly gold x2.0 so the derived
    # distance_ratio (= stop cap / gold cap = 800/400) reports 2.0 and the
    # single-source engine scales every gold-calibrated distance for the
    # pair automatically. The other three FX stay on x1.5, untouched byte
    # for byte.
    "USD/JPY": {
        "symbol": "USD/JPY", "name": "US Dollar / Japanese Yen", "category": "forex",
        "point_size": 0.001, "price_decimals": 3,
        "min_sl_distance_points": 800, "trailing_distance": 300, "trailing_step": 80,
        "early_breakeven_points": 300, "duplicate_zone_points": 300,
        "distance_ratio": 2.0,
        "trading_rules": {
            "stop": {"enabled": True, "min_liquidity_points": 400,
                     "safety_buffer_points": 140, "max_stop_points": 800},
            "targets": {"min_tp1_rr": 0.8, "tp2_multiple": 2.0,
                        "max_beyond_points": 400},
            "trailing": {"enabled": True, "distance_points": 300,
                         "step_points": 80, "activation_at": "BREAKEVEN",
                         "early_breakeven_points": 300},
            "protection": {"be_lock_points": 80},
            "post_tp2": {"enabled": True, "min_distance_points": 500,
                         "window_hours": 2.5},
        },
        "session_planner": {
            "fallback_zone_half_width_points": 240,
            "standby_min_distance_points": 300,
            "max_primary_zone_width_points": 900,
            "max_standby_zone_width_points": 900,
            "min_zone_width_points": 12.0,
            "min_entry_zone_width_points": 120,
            "min_thesis_objective_points": 60,
        },
        "cross_entry_distance_points": 300,
        "scale_in_trigger_points": 150,
        "auction_flow": {"calibration_required": False},
    },
}

ALIASES = {
    "XAUUSD": "XAU/USD",
    "GOLD": "XAU/USD",
    "WTI": "WTI/USD",
    "USOIL": "WTI/USD",
    "OIL": "WTI/USD",
    "OIL/W": "WTI/USD",
    "WTICO_USD": "WTI/USD",
    "EURUSD": "EUR/USD",
    "GBPUSD": "GBP/USD",
    "USDCAD": "USD/CAD",
    "USDJPY": "USD/JPY",
}


def normalize_symbol(symbol: Any) -> str:
    text = str(symbol or "XAU/USD").strip().upper().replace(" ", "")
    # Strip common broker suffixes (.s, .m, .raw, .pro, .ecn, _i, _s, etc.)
    for sfx in (".S", ".M", ".RAW", ".PRO", ".ECN", ".I", "_I", "_S"):
        if text.endswith(sfx):
            text = text[:-len(sfx)]
            break
    if text in ALIASES:
        return ALIASES[text]
    if "/" not in text and len(text) == 6:
        text = f"{text[:3]}/{text[3:]}"
    return text


def instrument_map(config: Dict[str, Any] | None = None) -> Dict[str, Dict[str, Any]]:
    mapping = deepcopy(DEFAULT_INSTRUMENTS)
    for item in (config or {}).get("instruments", []) or []:
        if not isinstance(item, dict):
            continue
        symbol = normalize_symbol(item.get("symbol"))
        base = mapping.get(symbol, {"symbol": symbol})
        base.update(item)
        base["symbol"] = symbol
        mapping[symbol] = base
    return mapping


def get_instrument(config: Dict[str, Any] | None = None, symbol: Any = None) -> Dict[str, Any]:
    symbol = normalize_symbol(symbol or (config or {}).get("symbol") or "XAU/USD")
    mapping = instrument_map(config)
    return deepcopy(mapping.get(symbol, {"symbol": symbol, "point_size": 0.00001, "price_decimals": 5}))


def point_size(symbol: Any = None, config: Dict[str, Any] | None = None) -> float:
    return float(get_instrument(config, symbol).get("point_size", 0.00001) or 0.00001)


def price_decimals(symbol: Any = None, config: Dict[str, Any] | None = None) -> int:
    return int(get_instrument(config, symbol).get("price_decimals", 5) or 5)


def round_price(price: float | None, symbol: Any = None, config: Dict[str, Any] | None = None) -> float:
    if price is None:
        return 0.0
    dec = price_decimals(symbol, config)
    return round(float(price), dec)


def format_price(price: float | None, symbol: Any = None, config: Dict[str, Any] | None = None) -> str:
    if price is None:
        return "0.00"
    dec = price_decimals(symbol, config)
    return f"{float(price):.{dec}f}"


def points_to_price(points: float, symbol: Any = None, config: Dict[str, Any] | None = None) -> float:
    return float(points or 0) * point_size(symbol, config)


def price_to_points(price_delta: float, symbol: Any = None, config: Dict[str, Any] | None = None) -> float:
    ps = point_size(symbol, config)
    return float(price_delta or 0) / ps if ps else 0.0


def price_sanity_range(symbol: Any = None, config: Dict[str, Any] | None = None) -> tuple[float, float]:
    """Return realistic (min_price, max_price) bounds for sanity check."""
    sym = normalize_symbol(symbol or (config or {}).get("symbol") or "XAU/USD")
    if sym.startswith("XAU") or sym == "GOLD":
        return (1500.0, 6000.0)
    if sym.startswith("WTI") or sym in ("USOIL", "OIL", "WTICO_USD"):
        return (20.0, 200.0)
    if sym.endswith("JPY") or "JPY" in sym:
        return (50.0, 300.0)
    # Standard FX pairs (EUR/USD, GBP/USD, USD/CAD, NZD/USD, USD/CHF, etc.)
    return (0.4, 3.5)



def enabled_instruments(config: Dict[str, Any]) -> List[Dict[str, Any]]:
    configured = config.get("symbols") or config.get("enabled_symbols")
    if not configured:
        return [get_instrument(config, config.get("symbol", "XAU/USD"))]
    result: List[Dict[str, Any]] = []
    mapping = instrument_map(config)
    for item in configured:
        if isinstance(item, str):
            symbol = normalize_symbol(item)
            enabled = True
            overrides: Dict[str, Any] = {}
        elif isinstance(item, dict):
            symbol = normalize_symbol(item.get("symbol"))
            enabled = bool(item.get("enabled", True))
            overrides = dict(item)
        else:
            continue
        if not enabled:
            continue
        spec = deepcopy(mapping.get(symbol, {"symbol": symbol}))
        spec.update(overrides)
        spec["symbol"] = symbol
        result.append(spec)
    return result or [get_instrument(config, config.get("symbol", "XAU/USD"))]


def config_for_instrument(base_config: Dict[str, Any], instrument: Dict[str, Any]) -> Dict[str, Any]:
    cfg = deepcopy(base_config)
    symbol = normalize_symbol(instrument.get("symbol"))
    spec = get_instrument(base_config, symbol)
    spec.update(instrument)
    spec["symbol"] = symbol
    cfg["symbol"] = symbol
    cfg["instrument"] = spec

    cfg.setdefault("risk_settings", {})["min_sl_distance_points"] = spec.get(
        "min_sl_distance_points", cfg.get("risk_settings", {}).get("min_sl_distance_points", 400)
    )
    cfg.setdefault("trailing_stop", {})["trailing_distance"] = spec.get(
        "trailing_distance", cfg.get("trailing_stop", {}).get("trailing_distance", 150)
    )
    cfg["trailing_stop"]["trailing_step"] = spec.get(
        "trailing_step", cfg.get("trailing_stop", {}).get("trailing_step", 40)
    )
    cfg["trailing_stop"]["early_breakeven_points"] = spec.get(
        "early_breakeven_points", cfg.get("trailing_stop", {}).get("early_breakeven_points", 200)
    )
    cfg.setdefault("duplicate_signal_filter", {})["price_zone_points"] = spec.get(
        "duplicate_zone_points", cfg.get("duplicate_signal_filter", {}).get("price_zone_points", 50)
    )
    inst_rules = spec.get("trading_rules")
    if isinstance(inst_rules, dict) and inst_rules:
        merged = deepcopy(cfg.get("trading_rules") or {})
        for section, values in inst_rules.items():
            if isinstance(values, dict):
                base = dict(merged.get(section) or {})
                base.update(values)
                merged[section] = base
            else:
                merged[section] = values
        cfg["trading_rules"] = merged
    inst_auction = spec.get("auction_flow")
    if isinstance(inst_auction, dict) and inst_auction:
        base = deepcopy(cfg.get("auction_flow") or {})
        base.update(inst_auction)
        cfg["auction_flow"] = base
    inst_planner = spec.get("session_planner")
    if isinstance(inst_planner, dict) and inst_planner:
        base = deepcopy(cfg.get("session_planner") or {})
        base.update(inst_planner)
        cfg["session_planner"] = base
    if spec.get("cross_entry_distance_points"):
        two = cfg.setdefault("signal_requirements", {}).setdefault("two_agent_entry", {})
        two["cross_entry_distance_points"] = spec["cross_entry_distance_points"]
    if spec.get("scale_in_trigger_points"):
        # R26.9.15 (operator 2026-09-02: "الذهب الأساس"): the stored trigger
        # is the GOLD base (150) for EVERY symbol — the engine's ratio law
        # (_scaled_add_trigger) applies x0.5/x1.5 itself. The specs used to
        # carry PRE-SCALED values (FX 225 / WTI 75) which the engine then
        # scaled AGAIN: live EUR add demanded 337.5 pts (48.6 pips!) instead
        # of the lawful 225, and WTI demanded 37.5 instead of 75.
        fr = cfg.setdefault("order_execution", {}).setdefault("fixed_risk", {})
        fr["scale_in_trigger_points"] = spec["scale_in_trigger_points"]
    return cfg


# -- BUILD31-R13: per-symbol spread caps --------------------------------------
# One global "max_spread_points: 5" was calibrated on GOLD (point = $0.10 ->
# a $0.50 cap) but applied to 5-digit forex where a point is 0.1 pip. A normal
# 0.6-1.5 pip EUR/USD spread is 6-15 points, so the cap vetoed EVERY forex
# entry, all day, every day (SPREAD_GUARD / "Spread too high") while gold and
# oil kept trading. Caps are now per-symbol; the legacy global value stays as
# the fallback for any symbol not listed.
DEFAULT_MAX_SPREAD_POINTS_BY_SYMBOL = {
    "XAU/USD": 5.0,    # $0.50  (unchanged behaviour)
    "WTI/USD": 8.0,    # $0.08  (unchanged default headroom)
    "EUR/USD": 25.0,   # 2.5 pips
    "GBP/USD": 30.0,   # 3.0 pips
    "USD/CAD": 30.0,   # 3.0 pips
    "USD/JPY": 25.0,   # 2.5 pips
}


def max_spread_points_for(symbol: Any = None, config: Dict[str, Any] | None = None) -> float:
    """Effective spread cap (config points) for ONE symbol.

    Order: filters.max_spread_points_by_symbol[symbol]
         -> filters.max_spread_points (legacy global)
         -> DEFAULT_MAX_SPREAD_POINTS_BY_SYMBOL[symbol] -> 5.0
    """
    filters = (config or {}).get("filters", {}) or {}
    by_symbol = filters.get("max_spread_points_by_symbol") or {}
    norm = normalize_symbol(symbol)
    if isinstance(by_symbol, dict) and by_symbol:
        if norm in by_symbol:
            return float(by_symbol[norm])
        for key, value in by_symbol.items():
            if normalize_symbol(key) == norm:
                return float(value)
    legacy = filters.get("max_spread_points")
    if legacy is not None:
        return float(legacy)
    return float(DEFAULT_MAX_SPREAD_POINTS_BY_SYMBOL.get(norm, 5.0))
