# Phase 2 Package — VPS Environment — 2026-08-08

## Contents
- `deploy/trades_demo.sql`: creates `trades_demo` (a full copy of `trades`) +
  `mt5_ticket`/`mt5_account`/`execution_mode` + the `demo_metrics` table. Run it once.
- `deploy/.env.example`: all the variables; copy it to `.env` on the VPS and fill it in.
- `deploy/vps_setup.ps1`: installs Python and the packages (including MetaTrader5), copies `.env`,
  schedules `SS_DemoLoop` (every 5 min) and `SS_DemoWatchdog` (every minute), then runs the smoke test.
- `deploy/PHASE2_VPS_SETUP_EN.md`: a precise English execution sheet for the implementing agent.
- `scripts/demo_smoke_test.py`: checks env vars + MT5 login (rejects a real account) +
  candles + reading `trades_demo` + a 🧪 message to the demo chat; any FAIL stops the process.

## Order of operations
Rent a Windows machine → MT5 demo → `git clone -b demo/mt5` → run `vps_setup.ps1` →
fill in `.env` → run `trades_demo.sql` → SMOKE OK → let the schedule run.

`main` is not touched; no real account is used at this stage at all.
