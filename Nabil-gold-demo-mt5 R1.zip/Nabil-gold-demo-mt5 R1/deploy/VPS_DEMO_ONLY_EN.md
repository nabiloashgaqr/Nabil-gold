# 🖥️ The Server = Demo Only (the demo/mt5 branch runs isolated from everything else)

## Approved decision
- **Paper trading stops permanently** — no paper analysis and no paper cards after the cutover.
- **The server runs the demo only**: analysis every 5 minutes + execution on every tick via MT5.
- **GitHub keeps exactly one thing: the Dashboard** (+ the repository as a code copy).
- The subscription bot: stays on GitHub as-is by default; moving it to the server is optional (two lines in `vps_setup.ps1`).

## Scheduled tasks on the server

| Task | Frequency | Role |
|---|---|---|
| SS_DemoAnalysis | every 5 minutes | full analysis → signals/pendings written to `trades_demo` |
| SS_TickManager | on logon (persistent) | **execution on every tick**: activation, BE, TP1, trailing, close from the broker |
| SS_DemoLoop | on logon (persistent) | audit and reconciliation every 5 minutes + heartbeat |
| SS_DemoWatchdog | every minute | alerts if the demo loop's heartbeat stops |
| SS_MT5Terminal | on logon | keeps the MT5 terminal always running |

**Duplication protection:** the two persistent processes (tick manager + demo loop) are protected by
`utils/single_instance.py` (a pid file): any second instance detects the live one and exits immediately —
never double-managing MT5 orders. Tested in `tests/test_vps_task_guards.py`.

## How does it run in isolation?
- Each task has a `.bat` file under `deploy/tasks/` that sets: `EXECUTION_MODE=mt5_demo` +
  `TRADES_TABLE=trades_demo` + `DATA_SOURCE_PRIMARY=mt5`, then writes its own log under `logs\`.
- A single `.env` carries only the secrets; every scheduled script reads it automatically (`load_dotenv`).
- The data source = **MT5 only**. No TwelveData key is needed at all: without a key, TwelveData is
  never called, and if the MT5 feed drops the cycle stops cleanly instead of using any synthetic
  data (a guard tested in `tests/test_market_data_server_guard.py`).
- Does not depend on GitHub Actions at all — GitHub is for the code and the dashboard only.

## Where do signals arrive? The subscriber channel — same style as paper trading
- The package routes cards to the demo chat **only** if `TELEGRAM_DEMO_CHAT_ID` is
  filled in `.env`. So: **leave it empty** → every signal/update reaches
  `TELEGRAM_CHAT_ID` (the subscriber channel) in exactly the same format as paper trading, with no 🧪 prefix.
- Recording in Supabase happens in the `trades_demo` table (created via `deploy/trades_demo.sql`).
- The dashboard on GitHub reads `trades_demo` and displays it under the "🧪 DEMO" title.

## Startup order
1. Copy the `demo/mt5` branch to `C:\Nabil-gold` and run `deploy\vps_setup.ps1` as administrator.
2. Fill in `.env` + log in to the MT5 demo account manually once (leave the terminal open).
3. Enable Windows auto-login (`netplwiz`) so the persistent tasks come back after any restart.
4. Test: `deploy\tasks\demo_smoke.bat` → should print SMOKE OK.
5. Execute the cutover: `deploy\GITHUB_SHUTDOWN_EN.md`.

## Notes
- Logs: `C:\Nabil-gold\logs\*.log` per task.
- Updating the code: `git pull origin demo/mt5` on the server after every push.
- The Dashboard on GitHub now reads **trades_demo** directly (`TRADES_TABLE` in
  `dashboard.yml`) — the one remaining dashboard will show demo performance exclusively, titled
  "🧪 DEMO", and its Telegram card carries the demo marker.
- After the cutover: any card you receive will be 🧪 DEMO from the server only.
