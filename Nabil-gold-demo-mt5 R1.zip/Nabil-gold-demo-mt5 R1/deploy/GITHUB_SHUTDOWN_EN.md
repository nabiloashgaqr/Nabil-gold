# ✂️ Shutting Down GitHub — the Demo Moves to the Server Permanently
**Execute this only after the server has proven itself stable (checklist below). Before that: don't touch anything.**

## What stops
| Trigger | How to stop it | Why |
|---|---|---|
| Analysis every 5 minutes (paper) | cron-job.org: delete/stop the `analyze.yml` job | Paper trading is stopping — there's no replacement for it |
| Trade updates (paper) | cron-job.org: stop the `update_trades.yml` job | Same reason |
| Hourly macro | cron-job.org: stop the `macro_context.yml` job | Part of paper trading |
| Daily report | cron-job.org: stop the `daily_report.yml` job | Part of paper trading |
| Weekly report | cron-job.org: stop the `weekly_report.yml` job | Part of paper trading |
| **Demo Cycle (important!)** | GitHub → Actions → **Demo Cycle** → ⋯ → Disable | It was running the demo from GitHub; leaving it on = two writers to `trades_demo` alongside your server |

## What stays on GitHub
- ✅ **Dashboard** + its own cron-job.org task — the one dashboard remaining (it will show
  the last historical state of paper trading after it's stopped).
- ✅ CI tests (`tests.yml`) — on push only, runs the tests, not trading.
- ✅ The subscription bot's `Subscription Bot Cron` — stays as-is (unless you enabled its
  optional move to the server in `vps_setup.ps1`, in which case disable it here).
- ✅ The repository itself (the code copy and the `git pull` source for the server).
- Manual tools (backtest/prove…) — dormant buttons; they only run on a manual click. Keep or delete them.

## Cutover steps
1. Disable **Demo Cycle** from the Actions tab first (the riskiest — it directly touches the demo schedule).
2. Stop the five paper-trading cron-job.org tasks listed above.
3. On the server, confirm the tasks are active:
   `schtasks /Query /TN SS_TickManager` and `SS_DemoLoop` (Running after logon)
   and `SS_DemoAnalysis` (Ready).
4. Watch for a full hour:
   - Actions tab: no new runs (other than Dashboard on its schedule).
   - Demo Telegram: 🧪 DEMO cards arriving from the server.
   - `logs\demo_analysis.log` and `logs\tick_manager.log` are updating.

## Rollback plan
- For the demo: re-enable Demo Cycle and stop the server tasks (`schtasks /Change /TN "SS_TickManager" /DISABLE` …).
- If you want to revive paper trading later: re-enable the paper cron-job.org tasks (the code is still on the branch).

## Pre-cutover checklist
- [ ] `deploy\tasks\demo_smoke.bat` prints SMOKE OK
- [ ] One manual demo analysis cycle (`demo_analysis.bat`) delivered its card to the demo channel
- [ ] The tick manager is alive: `logs\tick_manager.log` is moving and managing orders
- [ ] Restart the server once: the terminal + tick manager + demo loop come back on their own (auto-login is enabled)
- [ ] No two manual copies of the tick manager running (the guard evicts duplicates — check the log)
