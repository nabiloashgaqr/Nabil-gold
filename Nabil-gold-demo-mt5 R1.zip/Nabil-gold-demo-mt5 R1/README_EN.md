# Final Upload Package

This package contains **all files modified/added** to the project so far, ready to upload to the repository.

## Notes
- The temporary file `tmp_trades.json` was **excluded**.
- The same folder structure was preserved so you can upload it directly on top of the project.
- The package includes:
  - Execution and analysis code
  - Telegram / Dashboard / API
  - Session planner / pending governance / scenario governance
  - Final evaluation / release readiness
  - Tests
  - Existing SQL / migration files
  - Workflow / runbook / templates
