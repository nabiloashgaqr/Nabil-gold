# Ready to Copy — Quick Start on a Windows VPS

This package = the full project in the state of the demo/mt5 branch (all 08-06/08 phases).
Copy the whole folder to C:\Nabil-gold, then:

1. Install MetaTrader 5 and log in to the demo account once (it auto-starts with Windows).
2. Fill in `.env` from `.env.example` (demo only; the `MT5_*` fields and the demo chat).
3. Run `deploy\trades_demo.sql` once in the Supabase SQL Editor.
4. Click `START_HERE.bat` (as administrator): it installs Python, the packages, and MetaTrader5,
   schedules `SS_DemoLoop` (every 5 min) and `SS_DemoWatchdog` (every minute), and runs the smoke test.
5. Seeing "SMOKE OK" = ready. Cards arrive in the demo chat prefixed with 🧪 DEMO.

No VPS yet? Upload this same package to the demo/mt5 branch on GitHub as-is,
and the Phase 3 shadow keeps working via `demo_cycle.yml` (the daily report compares both ledgers).

No real account is used at this stage. `main` is not touched.
