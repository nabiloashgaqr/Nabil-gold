# Migration Plan: Private Server + MetaTrader 5 — with Supabase, Telegram, and the Dashboard Staying

Plan date: 2026-08-06 · Status: **for understanding and approval — no code touched yet**

## 1) What stays completely unchanged (don't worry)

| Component | Why it stays |
|---|---|
| **Supabase (all tables and history)** | The same `services/database.py` writes the same columns — old and new trades in one connected record |
| **Telegram channel** | The same `services/telegram_bot.py` and the same token — the cards don't change |
| **Channel dashboard (the website)** | `api/dashboard.js` reads straight from Supabase — it has no idea where the engine runs |
| **All the logic** | The agents, the planner, trailing, the tests (1,631 of them) — unchanged |

**Bottom line: we're changing the "eye" (the price source) and the "location" (the host), not the "memory" (the database) or the "mouth" (Telegram).**

## 2) What changes

1. **Host**: GitHub Actions ← your private server (VPS).
2. **Price source**: TwelveData ← MetaTrader 5 (live candles from the terminal).
3. **Scheduler**: cron-job.org ← a local scheduler on the server.
4. **Secrets**: GitHub Secrets ← a `.env` file on the server (same values).

## 3) A technical fact that decides the choice (the fork in the road)

The official `MetaTrader5` Python package only works on **Windows**. Therefore:

- **Option A (recommended)**: a Windows VPS — the MT5 terminal + Python on the same machine. Simpler and more solid.
- **Option B**: Linux + a price bridge (an EA inside MT5 at another broker) — extra complexity with no need for it right now.

## 4) Steps in order (for understanding before execution)

### Phase 0 — Preparation (the current system is not touched)
1. Rent a Windows VPS (2-4 cores / 8GB RAM is enough).
2. Install MT5 and log in with a **demo** account.
3. Install Python 3.11+, then `pip install -r requirements.txt` and `pip install MetaTrader5`.
4. `git clone` the repository + a `.env` file with the same secrets as GitHub.

### Phase 1 — The bridge (the only new code)
5. New file `services/mt5_feed.py`: reads candles via `copy_rates_from` and returns them in **exactly the same shape** `get_gold_data` returns today (the single point of contact in `services/market_data.py`).
6. **Convert MT5 candle time (broker time) to UTC** — very critical: the `trailing_stop_source_time` logic and candle re-aggregation both depend on the timestamps.
7. A key in `config.json`: `data_source: "twelvedata" | "mt5"` — defaults to TwelveData until MT5 proves itself.

### Phase 2 — The shadow (one to two weeks)
8. The server analyzes **without sending Telegram messages and without writing trades** — a local log only.
9. Measure the match: same candles? Same decisions? How many cycles differed? (Our culture: by the numbers, not by impression.)

### Phase 3 — The gradual cutover
10. Move `run_trade_updates` (trade management) first and watch it for a full day.
11. Then move `run_analysis` (the signals).
12. Turn off the cron-job.org jobs one by one; GitHub Actions stays as a manual backup.

### Phase 4 — Live execution on MT5 (a separate decision)
13. Real `order_send` calls — **won't be touched before your explicit approval**; paper trading continues until you decide.

## 5) Files needed for the migration

- **The entire repository as-is**: `scripts/` `services/` `agents/` `config.json` `tests/`.
- **New only**:
  - `services/mt5_feed.py` (the price bridge + UTC conversion)
  - `scripts/run_scheduler.py` or Windows tasks (the scheduler)
  - `.env.example` + a watchdog script that sends a Telegram heartbeat if the engine stops
- **Unchanged**: `services/database.py` · `services/telegram_bot.py` · `api/dashboard.js` · `supabase_schema_unified.sql`.

## 6) Does everything stay on record? — Yes

- The existing history isn't touched (same tables).
- New trades are written by the same code → the dashboard shows old and new on one continuous line.
- During the shadow phase, no duplicate trades are written (writing is deliberately disabled there).
- At cutover: only one source writes at any given moment (either the server or Actions, never both), to prevent duplication.

## 7) Risks accounted for in advance

| Risk | Mitigation |
|---|---|
| MT5 broker time ≠ UTC | explicit conversion + tests on timestamp differences |
| Symbol name XAUUSD vs XAU/USD | a symbol map in `mt5_feed.py` |
| Terminal/session disconnects | watchdog + automatic reconnect + Telegram heartbeat |
| Duplicate writes during cutover | only one source writes (item 12) |
| Holiday/weekend | the same "market closed" behavior that exists today |

## 8) Approximate cost

A Windows VPS ≈ $10-25/month in exchange for full stability and instant control — and an alternative to relying nightly on GitHub's queues.

---
**Awaiting your approval to start Phase 1 (building the bridge) — until then, nothing changes in the live system.**
