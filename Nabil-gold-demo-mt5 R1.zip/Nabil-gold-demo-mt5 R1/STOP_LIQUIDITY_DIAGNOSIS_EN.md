# Diagnosis: Flat 150 Stop and Liquidity That Looks Irrational — 2026-08-06

Status: **diagnosis + opinion — awaiting operator approval to change risk settings**

## The symptom (London BUY plan card)

- Ref entry 4285.01 · INVALIDATION 4270.01 = exactly 150 points
- risk_note: "Execution stop normalized to the configured 150-point minimum"
- LIQUIDITY: L1 4298.30 (0.9R) · L2 4304.07 (1.3R) — numbers that look "compressed"/irrational

- Operator: "I always see the stop as 150. We said: look for liquidity below the buy and place the stop farther than it."

## Where the flaw is

1. The structural calculation **exists and respects the rule**: `_stop_loss` in
   `agents/risk_management_agent.py` builds candidates "farther than the liquidity below entry"
   (sell_side pools + sweep low + OB) and picks the closest logical one.
   For this card: sweep 4280.39 → structural stop ≈ 50 points.
2. Then a floor formula is applied in **both doors** (risk agent ~line 130 and session_planner
   lines 452/809):
   `min_sl_points = max(min_points=150, min(structural × structural_multiplier=3.0, max_points=400))`
3. In tight session maps the structural distance is usually 30-70 points → ×3 = 90-210 →
   **the flat 150 number wins most cycles** → the stop is fixed with no structural meaning,
   and the structural calculation is decoration.

## Why the liquidity looks irrational

R is the ruler for everything. Inflating the stop from ~50 to 150 compresses every multiple:
- L1 = 132.9 points: really 2.6R ← displayed as 0.9R
- L2 = 190.6 points: really 3.5R ← displayed as 1.3R
- The `min_rr_ratio` 1.5 gate and the 0.8R rule govern decisions with an inflated ruler → rejecting/distorting outcomes.

## The opinion (adopted by the developer)

The operator's rule is correct and should govern again:
1. Stop = farther than the nearest liquidity below the buy **with a collective margin** (proposed: 15 points) — not a ×3 multiplier.
2. An absolute minimum for spread/wick noise: **60 points** (instead of 150).
3. The 400 cap stays.

Applied to this card: stop ≈ 4278.9 (61 points) → L1 2.2R · L2 3.1R,
and the loss when the thesis breaks is two-thirds smaller.

## The change needed (after approval)

- `config.json` → `dynamic_sl_floor`: `min_points: 60`, replace
  `structural_multiplier` with `beyond_buffer_points: 15`.
- Adjust the formula in both doors in `agents/risk_management_agent.py` and
  `services/session_planner.py` to:
  `min_sl = clamp(structural + buffer, 60, 400)`
- Regression tests: must fail if a flat floor comes back and kills the structural calc, or if the stop drifts more than the margin away from liquidity.

**Do not execute before the operator's order: "execute" or their alternative numbers for the margin/floor.**

---
*Editorial note (translation pass, current codebase state): this diagnosis was superseded the day after it was written. `agents/risk_management_agent.py` and `utils/trading_rules.py` now implement the operator's liquidity rule directly — `stop_from_liquidity` is `enabled: true` in `config.json` with `min_liquidity_points: 200`, `safety_buffer_points: 70`, `max_stop_points: 400` (not the 60/15 numbers proposed here, but the same underlying fix: the stop is derived from liquidity, not a flat floor). See the "2026-08-07b" comments in `agents/risk_management_agent.py` for the shipped version of this fix.*
