# 🥇 Nabil Gold — Smart Trading Signal System (Paper Trading)

> A multi-agent analytical bot that generates gold (XAU/USD) trading signals in paper-trading mode, built on weighted consensus across 5 analytical agents with multi-layer safety filters and dynamic risk management.

---

## ⚡ Overview

- **Target symbol:** `XAU/USD` (Gold vs. US Dollar)
- **Timeframes:** `5m` · `15m` · `1H` · `4H`
- **Execution type:** Paper Trading (simulated — no real trades are placed)
- **Runtime:** Python 3.12+, scheduled via GitHub Actions
- **Database:** Supabase (PostgreSQL) with a local JSON fallback
- **Notifications:** Telegram Bot (HTML formatting)
- **Data provider:** Twelve Data (Free tier — 800 calls/day)

---

## 🏗️ System Architecture

```
Nabil-gold/
├── agents/              # Analytical agents (5 + Decision + Risk + News + ...)
├── services/            # System services (Telegram, DB, Learning, Backtesting, ...)
├── scripts/             # Entry points for running the system and generating reports
├── dashboard/           # Web dashboard (HTML/CSS/JS)
├── api/                 # Dashboard API (Node.js functions)
├── utils/               # Helper utilities and technical indicators
├── tests/               # Automated test suite (pytest)
├── config.json           # Centralized configuration
└── .github/workflows/   # Scheduled workflows
```

---

## 🤖 Analytical Agents (5 + 1)

| Agent | Role | Weight |
|--------|-------|-------|
| 🔬 **Technical** | Technical indicators (RSI, MACD, EMA, ATR, Bollinger) | 20% |
| 📊 **Classical** | Classical patterns (support/resistance, swing highs/lows, breakouts) | 25% |
| 🧠 **SMC** | Smart Money Concepts (Order Blocks, Liquidity Sweeps, FVG) | 20% |
| 📈 **Price Action** | Pure price action (candles, accumulation, distribution) | 20% |
| 🌍 **Multi-Timeframe** | Timeframe alignment (5m→4H) + entry timing state | 15% |
| ⚖️ **Decision Agent** | Final weighted consensus + safety filters | — |

> **Consensus rule:** requires agreement from ≥3 qualified agents (confidence ≥70%) with net weighted confidence ≥72% after subtracting opposition.

---

## 🛡️ Multi-Layer Safety Filters

- ⏰ **Trading window:** 03:00–22:00 (Asia/Hebron), weekdays only
- 📰 **News filter:** automatic block before/after Tier 1/2 ForexFactory news events
- 📉 **Daily Bias (4H):** blocks trades against the prevailing trend except under strict conditions
- 🚫 **Duplicate filter:** prevents repeat signals in the same price zone, with result-aware cooldown
- ⚠️ **Dynamic risk:** tightens conditions or pauses temporarily after consecutive losses (currently disabled while collecting data)

---

## 📐 Risk & Trade Management

| Item | Value | Description |
|-------|--------|-------|
| SL min distance | 400 pts ($40) | protection against price noise |
| Early Breakeven | +150 pts | automatically moves SL to entry |
| Trailing Stop | 150 pts gap / 40 pts step | trails the stop as profit grows |
| Partial Close @ TP1 | 50% | locks in half the position at the first target |
| Max Open Trades | 3 | original position + up to two scale-ins |
| Scale-In | every 200 pts | 0.5x size for each scale-in |
| Expire | 24 hours | auto-closes pending trades |

*Note: the values above reflect the historical baseline. The active risk logic now uses an operator-directed liquidity-based stop rule (ignore liquidity closer than 200 pts, +70 pt safety buffer, 400 pt cap) and a liquidity-chain target law — see `utils/trading_rules.py`, the single source of truth for these formulas, and `config.json`'s `trading_rules` block for current live values.*

---

## 🔗 Integrations

### 📨 Telegram Bot
- Formatted entry signals (HTML) with entry/SL/TP/RR details
- Trade lifecycle events (TP1/TP2/SL/Trailing/Breakeven/Fill)
- Daily (23:00) and weekly (Saturday 10:00) reports
- Error and critical-condition alerts

### 🗄️ Supabase Database
- Persistent storage of open trade state
- `trades` + `trade_snapshots` + `performance_logs` tables
- Full schema in `supabase_schema_unified.sql`

### 📡 Twelve Data
- Base `5m` candles, locally re-aggregated into `15m/1H/4H`
- Fallback spot quotes when the quota is exhausted

### 🤖 Gemini (optional)
- Independent review of each signal
- Smart news analysis when `GEMINI_API_KEY` is set
- Never used in the final trading decision — advisory/observational only

### 🧪 MetaTrader 5 (demo, this branch)
- `services/mt5_feed.py` / `services/mt5_executor.py` add an optional demo-account execution path on top of the paper-trading core
- Isolated via `EXECUTION_MODE=mt5_demo`, a separate `trades_demo` table, and a separate Telegram demo chat
- Requires a Windows VPS running the MT5 terminal — see `MT5_DEMO_MIGRATION_TECHNICAL_PLAN_EN.md` and `BRANCH_DEMO_MT5_GUIDE_EN.md`

---

## 🚀 Quick Start

### 1. Requirements
```bash
python -m pip install -r requirements.txt
```

### 2. Environment variables
Copy `.env.example` to `.env` and fill in:
```env
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
SUPABASE_URL=...
SUPABASE_KEY=...
TWELVEDATA_API_KEY=...
GEMINI_API_KEY=...        # optional
```

### 3. Running locally
```bash
python main.py                        # one analysis cycle
python scripts/run_analysis.py        # same thing
python scripts/run_trade_updates.py   # update open trades
python scripts/run_daily_report.py    # daily report
python scripts/run_weekly_report.py   # weekly report
```

### 4. Docker
```bash
docker build -t nabil-gold .
docker run --env-file .env nabil-gold
```

---

## 🧪 Tests

```bash
pytest tests/ -q
```

- The suite covers agents, filters, trade management, formatting, and integration paths
- All tests must pass before any production change ships

---

## ⚙️ GitHub Actions Workflows

| Workflow | Schedule | Purpose |
|----------|---------|---------|
| `analyze.yml` | every 5 minutes | market analysis and signal delivery |
| `update_trades.yml` | every 5 minutes | follows open trades (SL/TP/Trailing) |
| `daily_report.yml` | daily at 23:00 | daily report |
| `weekly_report.yml` | Saturday at 10:00 | weekly report |
| `macro_context.yml` | hourly | refreshes macro data |
| `dashboard.yml` | — | generates the dashboard |
| `tests.yml` | on push | runs the test suite |
| `backtest.yml` | manual | historical backtest |
| `telegram_test.yml` | manual | Telegram delivery test |
| `demo_cycle.yml` | manual (external cron) | Phase-3 MT5-demo shadow cycle (paper mode, runs on Linux CI) |
| `manual_operator.yml` | manual | ad-hoc operations (analysis, reports, tuning, release readiness, ...) |

---

## 📁 Key Configuration Files

| File | Purpose |
|-------|-------|
| `config.json` | all centralized settings (weights, risk, schedules, filters) |
| `utils/helpers.py` | single source for shared facts (weights, sessions, formatting) |
| `utils/trading_rules.py` | single source of truth for the stop/target/trailing/post-TP2 formulas |
| `supabase_schema_unified.sql` | full database schema |

---

## 🎯 Strengths

- ✅ No external language model drives the trading decision — the final call comes purely from the analytical agents
- ✅ Multi-layer safety filters reduce weak or reckless signals
- ✅ Smart trade management (Breakeven + Trailing + Partial Close)
- ✅ A learning system that analyzes agent performance and proposes weight recommendations
- ✅ Bilingual support (Arabic/English) across documentation and the dashboard
- ✅ A large automated test suite (1,600+ tests) guarding every release

---

## ⚠️ Disclaimer

> This system operates in **paper-trading mode** only. The signals it sends are for evaluation and testing purposes and do not constitute financial or investment advice. Use it at your own responsibility.

---

**Developer:** Nabil Ashqar
**Location:** Nablus, Palestine 🇵🇸
**Timezone:** Asia/Jerusalem

*(The original Arabic README is preserved at [README_AR_ARCHIVE.md](README_AR_ARCHIVE.md).)*
