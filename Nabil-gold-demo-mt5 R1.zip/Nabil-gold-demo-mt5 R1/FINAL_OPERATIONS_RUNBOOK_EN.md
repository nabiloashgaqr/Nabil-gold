# SmartSignal — Final Operations Runbook

## Purpose
This file lays out the recommended final order for operating the system once the core development work is complete.

## Manual run via GitHub Actions (recommended if you don't want an external cron)
There's a new manual workflow:
- `.github/workflows/manual_operator.yml`

From GitHub:
1. Open the **Actions** tab
2. Choose **Manual SmartSignal Operator**
3. Click **Run workflow**
4. Choose the desired operation from `operation`, such as:
   - `analysis`
   - `update_trades`
   - `daily_report`
   - `weekly_report`
   - `analyst_comparison`
   - `final_evaluation`
   - `tuning_advisor`
   - `release_readiness`
   - `operations_pipeline`
   - `backtest_benchmark`
5. Adjust the optional inputs such as:
   - `timeframe`
   - `outputsize`
   - `window`
   - `step`
   - `horizon`
   - `max_trades`
   - `send_telegram`
6. After the run finishes you'll find artifacts automatically uploaded from the `storage/` folder

> Note: in a manual workflow run you don't need `load_dotenv()` because Secrets are injected directly by GitHub Actions.

## Main paths
### 1) Normal daily operation
- `python scripts/run_analysis.py`
- `python scripts/run_trade_updates.py`
- `python scripts/run_daily_report.py`
- `python scripts/run_weekly_report.py`

### 2) Measurement and evaluation
#### Regular backtest
```bash
python scripts/run_backtest.py --timeframe 15m --outputsize 420 --window 160 --step 12 --horizon 32 --max-trades 60
```

#### Benchmark: current vs baseline
```bash
python scripts/run_backtest.py --benchmark --timeframe 15m --outputsize 420 --window 160 --step 12 --horizon 32 --max-trades 60
```

### 3) Analyst Distillation
#### Importing labels
```bash
python scripts/import_analyst_labels.py path/to/labels.json
```
or:
```bash
python scripts/import_analyst_labels.py path/to/labels.csv
```

#### Running the comparison
```bash
python scripts/run_analyst_comparison.py
```

### 4) Final Evaluation Pass
```bash
python scripts/run_final_evaluation.py --timeframe 15m --outputsize 420 --window 160 --step 12 --horizon 32 --max-trades 60
```

Default output:
- `storage/final_evaluation.json`

### 5) Tuning Advisor
```bash
python scripts/run_tuning_advisor.py --input storage/final_evaluation.json --output storage/tuning_advice.json
```

If `storage/final_evaluation.json` doesn't exist yet (e.g. running from a fresh runner or a separate manual workflow), use:
```bash
python scripts/run_tuning_advisor.py --ensure-final-evaluation --timeframe 15m --outputsize 420 --window 160 --step 12 --horizon 32 --max-trades 60
```

Default output:
- `storage/tuning_advice.json`

### 6) Release Readiness
```bash
python scripts/run_release_readiness.py --timeframe 15m --outputsize 420 --window 160 --step 12 --horizon 32 --max-trades 60
```

Default output:
- `storage/release_readiness.json`

### 7) The full operations bundle (recommended)
```bash
python scripts/run_operations_pipeline.py --timeframe 15m --outputsize 420 --window 160 --step 12 --horizon 32 --max-trades 60
```

Default outputs in:
- `storage/ops_pipeline/final_evaluation.json`
- `storage/ops_pipeline/tuning_advice.json`
- `storage/ops_pipeline/release_readiness.json`

## How to decide after a run?
### If the final verdict is:
- `PROCEED_TO_STRUCTURED_TRIAL`
  - Start a structured forward trial
  - Don't change the config directly unless the proposed adjustments are small and clear

- `APPLY_TUNING_THEN_REEVALUATE`
  - Apply a conservative patch from `tuning_advice.json`
  - Re-run:
    - final evaluation
    - release readiness

- `HOLD_AND_REFINEMENT_REQUIRED`
  - Don't start a structured trial
  - Review:
    - benchmark deltas
    - top missed reasons
    - not-filled ratio
    - overlap quality

## Recommended weekly practical order
1. Import new analyst labels
2. Run `run_analyst_comparison.py`
3. Run `run_backtest.py --benchmark`
4. Run `run_final_evaluation.py`
5. Run `run_tuning_advisor.py`
6. Run `run_release_readiness.py`

Or simply:
```bash
python scripts/run_operations_pipeline.py
```

## Operational notes
- Use the current `config.json` as the single source of truth.
- Don't apply patches to the config automatically, directly in production, without review.
- Analyst overlap without enough labels isn't enough on its own to make a decision.
- The benchmark alone isn't enough either, without understanding overlap and the not-filled ratio.
- The best final read comes from combining:
  - benchmark
  - overlap
  - tuning advice
  - release readiness

## Core reference files
- `services/backtesting.py`
- `services/final_evaluation.py`
- `services/tuning_advisor.py`
- `services/release_readiness.py`
- `services/analyst_distillation.py`
- `scripts/run_backtest.py`
- `scripts/run_final_evaluation.py`
- `scripts/run_tuning_advisor.py`
- `scripts/run_release_readiness.py`
- `scripts/run_operations_pipeline.py`
