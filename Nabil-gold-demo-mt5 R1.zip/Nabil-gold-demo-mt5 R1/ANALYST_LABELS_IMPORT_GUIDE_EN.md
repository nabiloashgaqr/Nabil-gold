# Analyst Labels Import Guide

## Ready-made files
- `analyst_labels_template.json`
- `analyst_labels_template.csv`

## Important fields
- `id`: unique identifier for each label
- `symbol`: e.g. `XAU/USD`
- `timeframe`: e.g. `15m`
- `analyst_name`: the analyst's name
- `bias`: `BUY` or `SELL`
- `setup_type`: e.g. `LIQUIDITY_REVERSAL` or `TREND_CONTINUATION`
- `sweep_side`: `buy_side` or `sell_side`
- `poi_type`: e.g. `order_block` or `fvg`
- `poi_quality_grade`: e.g. `A` or `B`
- `intended_entry`: the entry price the analyst identifies
- `invalidation`: the invalidation condition
- `tp1`, `tp2`: the targets
- `session_label`: e.g. `London / Europe Midday`
- `trade_decision`: usually `TRADE`
- `created_at`: the label's timestamp in ISO format

## Importing locally
### JSON
```bash
python scripts/import_analyst_labels.py analyst_labels_template.json
```

### CSV
```bash
python scripts/import_analyst_labels.py analyst_labels_template.csv
```

## Importing via the manual GitHub workflow
From Actions -> Manual SmartSignal Operator:
- Choose operation: `analyst_comparison`

> Note: the current workflow runs the comparison, not an import from a file uploaded directly on GitHub. If you want to import on GitHub, upload the file to the repository first, or run the script locally/on the server and then push the data to Supabase.

## Verifying after import
Run in Supabase:
```sql
select count(*) from analyst_labels;
```

Then:
```sql
select id, symbol, bias, setup_type, created_at
from analyst_labels
order by created_at desc
limit 20;
```
