# Guide: Creating the demo/mt5 Branch and Uploading Phase-1 Files — Step by Step

## From the GitHub website (without git on your machine)
1. Open the Nabil-gold repository → the button showing the branch name ("main") near the top of the file list.
2. In the search box type: `demo/mt5`, then click "Create branch: demo/mt5 from main".
3. Now, while inside the new branch: click "Add file" → "Upload files".
4. Upload the package files **using the same paths** (folders are created automatically):
   - `services/mt5_feed.py` · `services/mt5_executor.py` · `services/market_data.py` ·
     `services/database.py` · `services/telegram_bot.py`
   - `scripts/run_trade_updates.py` · `scripts/run_demo_loop.py` · `scripts/demo_watchdog.py`
   - `tests/mt5_fake.py` · `tests/test_mt5_phase1.py`
   - `config.json` · `.github/workflows/analyze.yml`
5. Commit message: "demo/mt5: phase 1 feed+executor+tests".
6. Repeat this for any future file, always inside the `demo/mt5` branch and never in `main`.

## If you have git on your machine
```bash
git fetch origin
git checkout -b demo/mt5 origin/main
(copy the files above to the same paths)
git add -A && git commit -m "demo/mt5: phase 1" && git push -u origin demo/mt5
```

## On the VPS (after creating the branch)
1. Windows + MT5 + a demo account + Python 3.11+ and `pip install MetaTrader5 -r requirements.txt`
2. `git clone -b demo/mt5 https://github.com/nabiloashgaqr/Nabil-gold.git`
3. `.env` with the variables: `EXECUTION_MODE=mt5_demo` · `TRADES_TABLE=trades_demo` ·
   `DATA_SOURCE` primary=mt5 (inside `data_source` in the branch's config or via env) ·
   `MT5_PATH`/`MT5_LOGIN`/`MT5_PASSWORD`/`MT5_SERVER` · `TELEGRAM_DEMO_CHAT_ID` ·
   and the rest of the existing secrets.
4. Run the SQL that creates `trades_demo` and `demo_metrics` (in the English technical plan, §4).
5. Task Scheduler: every 5 minutes run `python scripts/run_demo_loop.py` ·
   and every minute run `python scripts/demo_watchdog.py`.

## Verification
`python -m pytest -q` → 1648+ passing · cards arrive at the demo chat prefixed 🧪 DEMO ·
any mismatch → 🧪 DEMO HALT and new orders stop.
