# Comprehensive Development Plan for the Nabil Gold System

## Executive summary
This document lays out a practical roadmap for turning the system from a **Consensus Engine** into a **Setup Engine** capable of catching the same opportunities a strong manual analyst would see, while keeping the system's discipline, measurability, and continuous improvement.

The realistic goal isn't to literally out-perform every analyst, but to build a system that is:
- more accurate than most ordinary analysts
- more consistent and disciplined than manual trading
- capable of catching setups of the sweep → displacement → POI → mitigation kind
- evaluable and improvable with data, not impressions

## Current diagnosis
### What does the system do well today?
- an organized multi-agent architecture
- good risk management and safety filters
- saves trades, run state, and reports
- Telegram, Supabase, Dashboard, and Learning
- prevents fake data in production and offers relative protection from chaos

### Where is the real weakness?
- the system thinks snapshot-by-snapshot more than as a sequential price scenario
- entry is still closer to market-heavy execution than true zone execution
- the SMC edge exists but isn't the decision leader under its natural conditions
- roughly the same decision thresholds are used for nearly every setup regardless of context
- learning exists but isn't context-aware enough yet
- post-entry management is generally good but isn't structure-aware enough

## The new architectural vision
The system's "mind" needs to be reorganized into six layers:
1. Data + Observability
2. Setup Detection
3. Setup State Machine
4. Strategy-specific Decisioning
5. Structure-aware Execution & Trade Management
6. Regime-aware Learning + Analyst Distillation

---

## Phase 0 — Establishing the Baseline
**Suggested duration:** 3–5 days

### Goal
Understand where the system loses, where it lags, and which setups it misses, before changing any logic.

### Why this phase is necessary
Any development without a clear baseline turns into random tweaking whose effect can't be measured.

### Required work
- Add new metrics beyond win rate and PnL:
  - expectancy
  - avg R achieved
  - RR capture %
  - missed setup rate
  - late entry distance
  - entry efficiency
  - MFE / MAE
  - performance by setup/session/regime/lead-agent
- Expand trade storage to include:
  - setup_type
  - setup_id
  - lead_agent
  - entry_profile
  - poi_type
  - sweep_side
  - displacement_score
  - setup_quality
  - miss_reason
- Build breakdowns in the dashboard and reports by setup/session/regime

### Priority files
- `services/database.py`
- `supabase_schema_unified.sql`
- `services/performance_dashboard.py`
- `services/backtesting.py`
- `scripts/run_backtest.py`
- `dashboard/` and `scripts/generate_dashboard.py`

### Required tests
- `tests/test_performance_dashboard.py`
- `tests/test_phase5_data_enrichment.py`
- `tests/test_learning_service.py`

### Success outputs
A clear dashboard that can say, for example:
- Reversal setups misses = 42%
- MARKET entries are worse than zone entries by 0.8R
- best session = London continuation
- worst session = NY reversal without sweep confirmation

---

## Phase 1 — Fixing the Execution Layer
**Duration:** 1–2 weeks

### Goal
Turn execution from market-heavy logic into real zone/pending execution.

### Code-related diagnosis
In `config.json`, `agents/risk_management_agent.py`, and `agents/open_trades_manager.py` there's structure that allows LIMIT/STOP/PENDING, but it isn't properly exploited because the current configuration pushes heavily toward MARKET.

### Required work
1. Re-activate a real execution profile:
   - `entry_style = smart` or `hybrid` or a new profile like `poi_pending`
2. Undo the effect of `pending_support_removed: true`
3. Expand `_smart_entry()` inside `agents/risk_management_agent.py` to clearly define when to use:
   - MARKET
   - LIMIT
   - STOP
4. Define a unified zone object containing:
   - proximal
   - distal
   - fill_rule
   - invalidation anchor
   - source
5. In `scripts/run_analysis.py`:
   - save pending signals
   - replace/cancel old signals for the same setup
6. In `services/telegram_bot.py`:
   - show zone boundaries
   - entry type
   - invalidation
   - target liquidity

### Priority files
- `config.json`
- `agents/risk_management_agent.py`
- `agents/open_trades_manager.py`
- `scripts/run_analysis.py`
- `services/database.py`
- `services/telegram_bot.py`

### Required tests
- `tests/test_limit_fill_logic.py`
- `tests/test_pending_zone_execution.py`
- `tests/test_no_phantom_fill.py`
- `tests/test_pending_replace_cancel.py`

### Success criteria
- improved entry efficiency
- improved planned RR
- reduced entry lag
- fewer trades entering after the original edge is gone

---

## Phase 2 — Building the Setup State Machine
**Duration:** 2–3 weeks

### Goal
Turn the system from a momentary reading into logic that retains the price story over time.

### Core idea
A manual analyst usually sees the following sequence:
- sweep
- displacement
- MSS/CHOCH
- identifying a POI
- waiting for mitigation
- trigger
- invalidation or entry

### What needs to be built?
Add a new component such as:
- `services/setup_memory.py`
or
- `agents/setup_state_agent.py`

### Proposed states
- DETECTED
- SWEEP_CONFIRMED
- DISPLACEMENT_CONFIRMED
- MSS_CONFIRMED
- POI_MARKED
- MITIGATION_PENDING
- ENTRY_ARMED
- ENTRY_TRIGGERED
- INVALIDATED
- EXPIRED

### Developing `agents/smc_agent.py`
It should turn from a signal provider into a setup builder that outputs:
- sweep side
- sweep quality
- equal highs/lows
- session high/low raid
- displacement score
- MSS/CHOCH quality
- order block rank
- FVG rank
- premium/discount score
- mitigation status
- target liquidity map

### Developing `scripts/run_analysis.py`
- update setup state instead of just making an instant decision
- link each setup to a stable identifier
- defer the signal until a valid transition occurs

### Database development
Add tables:
- `setup_candidates`
- `setup_state_events`

### Required tests
- `tests/test_setup_state_machine.py`
- `tests/test_sweep_to_mitigation_flow.py`
- `tests/test_poi_ranking.py`
- `tests/test_invalidated_setup_cleanup.py`

### Success criteria
That the system can say:
> I have a liquidity reversal setup in a MITIGATION_PENDING state
instead of just saying:
> I have 3 agents agreeing right now.

---

## Phase 3 — A Different Decision for Each Setup Type
**Duration:** 2 weeks

### Goal
Stop using the same decision logic for every trade type.

### Current problem
`agents/decision_agent.py` works as an excellent generic weighted consensus, but it doesn't distinguish enough between:
- liquidity reversal
- continuation pullback
- range fade
- breakout continuation

### Structural change
Add strategy profiles such as:
1. `liquidity_reversal`
2. `trend_pullback`
3. `range_fade`

For each profile, define:
- lead agent
- supporting agents
- soft veto / hard veto
- min agents
- min confidence
- allowed execution mode
- management profile
- session preference
- daily bias requirement
- macro/news strictness

### Priority files
- `agents/decision_agent.py`
- `config.json`
- a new proposed file: `services/strategy_profiles.py`

### Logical examples
#### Liquidity Reversal
- SMC + Price Action = core
- MTF = confirm
- Technical/Classical = supportive only

#### Trend Pullback
- MTF + Classical = core
- Price Action = confirm
- SMC = supportive

### Required tests
- `tests/test_strategy_profiles.py`
- `tests/test_reversal_consensus.py`
- `tests/test_continuation_consensus.py`
- `tests/test_soft_veto_logic.py`

### Success criteria
Not killing an excellent SMC setup just because it didn't pass through the same traditional blanket consensus suppression used for everything else.

---

## Phase 4 — Structure-aware Risk Management and Post-Entry Management
**Duration:** 2 weeks

### Goal
Customize the stop, targets, and management by setup type and price structure, not just by generic numbers.

### Current diagnosis
`agents/risk_management_agent.py` and `agents/open_trades_manager.py` are very good as general management, but they need customization by:
- reversal setup
- continuation setup
- range setup

### Required work
#### In `agents/risk_management_agent.py`
- SL behind the sweep extreme / distal edge / invalidation candle in reversal
- SL behind the pullback structure in continuation
- TP map linked to internal/external liquidity, not just ATR
- a risk policy snapshot for every trade

#### In `agents/open_trades_manager.py`
Add management profiles:
- reversal_profile
- continuation_profile
- range_profile

For each profile:
- breakeven trigger
- partial logic
- trail mode
- expiry policy

### An important note about scale-in
It's preferable, for now, to:
- disable it on reversal setups
- or restrict it to continuation only, until the foundation proves itself

### Priority files
- `agents/risk_management_agent.py`
- `agents/open_trades_manager.py`
- `services/database.py`
- `config.json`
- `services/telegram_bot.py`

### Required tests
- `tests/test_structure_aware_sl.py`
- `tests/test_target_liquidity_mapping.py`
- `tests/test_management_profiles.py`
- `tests/test_scalein_continuation_only.py`

### Success criteria
- fewer unnecessary stop-outs
- improved RR capture
- improved actual R achieved
- reduced early exits from good trades

---

## Phase 5 — Real Context-Aware (Regime-aware) Learning
**Duration:** 2–3 weeks

### Goal
Turn `services/learning_service.py` from generic recommendations into learning that distinguishes between contexts.

### Current problem
The current service is useful, but it doesn't precisely answer the question:
> which agent or profile performs best in which setup, session, and regime?

### Required work
1. Build a contextual weight matrix based on:
   - setup type
   - session
   - regime
   - daily bias alignment
   - lead agent
2. Make `DecisionAgent` read the appropriate weight profile instead of always using fixed weights
3. Later, activate dynamic risk contextually, not just globally
4. Show the new learning results in the dashboard and reports

### Example contextual weights
#### If setup = liquidity_reversal
- smc 35%
- price_action 25%
- mtf 20%
- classical 10%
- technical 10%

#### If setup = continuation
- mtf 30%
- classical 25%
- price_action 20%
- smc 15%
- technical 10%

### Priority files
- `services/learning_service.py`
- `agents/decision_agent.py`
- `config.json`
- `services/performance_dashboard.py`

### Required tests
- `tests/test_contextual_weights.py`
- `tests/test_regime_learning_profiles.py`
- `tests/test_dynamic_risk_by_setup.py`

### Success criteria
- reduced drawdown
- improved expectancy
- improved performance within the best contexts
- less incorrect generalization of weights

---

## Phase 6 — Distilling the Analyst's Edge
**Duration:** 3–4 weeks, then ongoing permanently

### Goal
Turn the expertise of your best manual analyst into features, rules, and testable metrics.

### Required work
1. Build a manual or semi-manual dataset named something like:
   - `analyst_labels`
2. Store the following fields for each example:
   - timestamp
   - bias
   - setup_type
   - sweep_side
   - poi_type
   - poi_quality_grade
   - intended_entry
   - invalidation
   - targets
   - trade/no-trade
   - result
3. Build a comparison tool:
   - bot vs analyst on the same day and same chart
4. Build an Analyst Quality Scorer based on:
   - sweep quality
   - displacement strength
   - POI freshness
   - HTF alignment
   - session quality
   - target clarity
   - invalidation clarity

### Proposed files
- `services/analyst_distillation.py`
- `scripts/compare_analyst_vs_bot.py`
- `services/database.py`
- new dashboard sections for the comparison

### Required tests
- `tests/test_analyst_overlap_metrics.py`
- `tests/test_quality_score_alignment.py`

### Success criteria
That the bot becomes able to see what the analyst sees in a growing share of examples, enters near the same zone, and avoids many of the trades the analyst would have avoided.

---

## Phase 7 — Improving Execution Precision (Micro-Precision)
**Duration:** optional, after the previous phases

### Goal
Raise execution precision until the system approaches the human eye's view of the microstructure.

### Required work
- add M1/M3 for execution only
- add session microstructure logic:
  - London open sweep
  - NY open sweep
  - lunch drift filters
  - pre-news fake move
- add a more precise data source or a stronger execution fallback

### Success criteria
reduced execution lag and improved trigger precision inside the zone.

---

## Proposed timeline
### Month 1
- Phase 0
- Phase 1
- start of Phase 2

### Month 2
- finish Phase 2
- Phase 3
- part of Phase 4

### Month 3
- finish Phase 4
- Phase 5
- start of Phase 6

---

## Highest-priority files in the project
### Top priority
- `scripts/run_analysis.py`
- `agents/smc_agent.py`
- `agents/decision_agent.py`
- `agents/risk_management_agent.py`
- `agents/open_trades_manager.py`
- `services/database.py`
- `config.json`

### Second priority
- `services/learning_service.py`
- `services/performance_dashboard.py`
- `services/telegram_bot.py`
- `dashboard/*`

---

## First suggested sprint
1. Add `setup_type`, `lead_agent`, and `setup_quality` to the trade snapshot
2. Re-activate real pending/zone execution
3. Develop the Telegram message to show zone/invalidation/target liquidity
4. Add a `setup_candidates` table
5. Expand `smc_agent.py` to output sweep/displacement/POI structure
6. Build an initial state machine
7. Split out 3 strategy profiles
8. Link thresholds to the profile
9. Add reports by setup/session/regime
10. Measure the difference between MARKET and ZONE entries

---

## Suggested key performance indicators (KPIs)
- Win rate
- Expectancy
- Avg R achieved
- RR capture %
- Entry efficiency
- Late entry distance
- Missed setup rate
- Setup completion rate
- Setup invalidation rate
- Performance by session
- Performance by regime
- Performance by setup family
- Performance by lead agent

---

## What NOT to do right now
- don't add a lot of new indicators
- don't make Gemini the final decision-maker
- don't expand the system to many assets before mastering gold
- don't activate direct auto-learning before a clear baseline exists
- don't complicate scale-in before fixing execution and the setup state machine

---

## Final conclusion
The transformation needed isn't just tuning thresholds — it's changing the system's philosophy from:
**Indicators + Consensus + Filtering**
to:
**a Stateful SMC Setup Engine + Strategy Profiles + Zone Execution + Contextual Learning**

If this roadmap is executed in order, the system will get much closer to the logic of a strong manual analyst, with an important extra edge: discipline, measurability, and the ability to keep improving.
