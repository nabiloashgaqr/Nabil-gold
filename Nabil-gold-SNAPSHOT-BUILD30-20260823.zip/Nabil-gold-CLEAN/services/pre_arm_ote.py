"""BUILD 30 (2026-08-22, operator order): PRE-ARM OTE — live, measurable.

Operator decision 2026-08-22 ("طبق كامل ويكون حي وقابل للقياس لا ظل"):
an open trade's entry was perceived as LATE because the current five
execution paths only admit a trade AFTER the pullback has formed, and the
decision then rides the 5-minute analysis cycle. The operator chose to arm
the order BEFORE the pullback arrives.

What this module does
---------------------
When the SMC structure shows a FRESH confirmed impulse leg, we PROJECT the
Optimal Trade Entry (OTE) retracement of that leg and place a PENDING order
at the projected level while the market is still at the top/bottom of the
impulse. The order then fills on touch — earlier in price and in time than
waiting for the pullback to complete.

Design principles (kept on purpose)
-----------------------------------
* ADDITIVE + SAFE: this is a parallel armer, not a new admission path. It
  reuses the existing PENDING machinery (activation on touch, 24h expiry,
  news block, staleness). If it does not fire, the system behaves 100% as
  before. Every gate is conservative; ANY failure anywhere -> no pre-arm,
  the reactive paths proceed untouched.
* NO NEW AGENT, NO LLM: the impulse/OTE projection is pure local
  candle/ATR math. Zero extra Gemini quota.
* SAME GATES as a live entry: SMC trend must align, news must not block,
  no existing open/pending on the symbol, OTE on the correct side and
  within max pending distance, RR >= min_rr.
* MEASURABLE: every pre-armed trade carries ``armed_at = "pre_arm_ote"``
  and path label ``PREARM_OTE`` so the weekly execution-quality /
  path-performance sections report it separately from the five paths.
* KILL SWITCH: ``pre_arm_ote.enabled`` (default True per the operator's
  "live" order). Set False to revert to today's behaviour with no code
  change.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from utils.indicators import calculate_atr
from utils.instruments import price_to_points, points_to_price, price_decimals

logger = logging.getLogger(__name__)

ARMED_AT = "pre_arm_ote"
PATH_LABEL = "PREARM_OTE"
from services.execution_paths import PATH_PREARM_OTE  # noqa: E402

# Defaults (all overridable under config["pre_arm_ote"]).
DEFAULTS: Dict[str, Any] = {
    "enabled": True,
    "timeframe": "15m",          # impulse leg measured on the primary frame
    "entry_pct": 0.70,           # OTE entry: 70% retracement of the leg
    "zone_low_pct": 0.62,        # OTE zone bounds (confluence window)
    "zone_high_pct": 0.79,
    "min_displacement_atr": 1.2, # impulse must clear >= 1.2 * ATR
    "leg_peak_recent_candles": 3,  # impulse peak must be within the last N closed bars
    "lookback_candles": 15,       # search window for the leg origin
    "stop_buffer_atr": 1.0,       # stop = leg origin +/- 1.0 * ATR
    "min_rr_ratio": 1.5,          # reject if projected RR < min_rr
    "max_pending_distance_points": 0.0,  # 0 = use the shared system cap
    "require_smc_trend": True,    # SMC primary trend must align (hard gate)
}


def _cfg(config: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(DEFAULTS)
    raw = (config or {}).get("pre_arm_ote") or {}
    if isinstance(raw, dict):
        for k in DEFAULTS:
            if k in raw and raw[k] is not None:
                out[k] = raw[k]
    return out


def _f(v: Any, d: float = 0.0) -> float:
    try:
        x = float(v)
        return x if x == x else d  # NaN guard
    except (TypeError, ValueError):
        return d


def _candle_f(c: Dict[str, Any], key: str, d: float = 0.0) -> float:
    return _f(c.get(key), d)


def detect_impulse_leg(candles: List[Dict[str, Any]], atr: float,
                       cfg: Dict[str, Any],
                       direction: str) -> Optional[Dict[str, Any]]:
    """Return the most recent confirmed impulse leg for ``direction``.

    A bullish impulse: a strong UP move whose PEAK is recent (within
    ``leg_peak_recent_candles`` closed bars) and whose origin (trough) is
    within ``lookback_candles``. The leg size must clear
    ``min_displacement_atr * atr``. Returns None when no fresh valid leg
    exists (the common case — the market is mid-pullback or chopping).
    """
    if atr <= 0 or len(candles) < 8:
        return None
    peak_recent = int(cfg.get("leg_peak_recent_candles", 3))
    lookback = int(cfg.get("lookback_candles", 15))
    min_size = float(cfg.get("min_displacement_atr", 1.2)) * atr
    # Only consider CLOSED candles (the last one may be forming).
    closed = candles[:-1] if len(candles) > 2 else candles
    n = len(closed)
    if n < 8:
        return None
    # The peak must sit in the most recent `peak_recent` closed bars.
    peak_start = max(0, n - peak_recent)
    if direction == "BUY":
        peak_idx = peak_start
        for i in range(peak_start, n):
            if _candle_f(closed[i], "high") >= _candle_f(closed[peak_idx], "high"):
                peak_idx = i
        peak = _candle_f(closed[peak_idx], "high")
        origin_start = max(0, peak_idx - lookback)
        trough_idx = peak_idx
        for i in range(origin_start, peak_idx + 1):
            if _candle_f(closed[i], "low") <= _candle_f(closed[trough_idx], "low"):
                trough_idx = i
        trough = _candle_f(closed[trough_idx], "low")
        size = peak - trough
        if size < min_size:
            return None
        return {"direction": "BUY", "leg_origin": trough, "leg_peak": peak,
                "leg_size": size, "peak_idx": peak_idx, "atr": atr}
    # SELL
    peak_idx = peak_start
    for i in range(peak_start, n):
        if _candle_f(closed[i], "low") <= _candle_f(closed[peak_idx], "low"):
            peak_idx = i
    peak = _candle_f(closed[peak_idx], "low")
    origin_start = max(0, peak_idx - lookback)
    trough_idx = peak_idx
    for i in range(origin_start, peak_idx + 1):
        if _candle_f(closed[i], "high") >= _candle_f(closed[trough_idx], "high"):
            trough_idx = i
    trough = _candle_f(closed[trough_idx], "high")
    size = trough - peak
    if size < min_size:
        return None
    return {"direction": "SELL", "leg_origin": trough, "leg_peak": peak,
            "leg_size": size, "peak_idx": peak_idx, "atr": atr}


def project_ote(leg: Dict[str, Any], cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Project the OTE retracement zone/entry/stop for a detected leg."""
    entry_pct = float(cfg.get("entry_pct", 0.70))
    z_low = float(cfg.get("zone_low_pct", 0.62))
    z_high = float(cfg.get("zone_high_pct", 0.79))
    origin = float(leg["leg_origin"])
    peak = float(leg["leg_peak"])
    size = float(leg["leg_size"])
    atr = float(leg["atr"])
    d = leg["direction"]
    if d == "BUY":
        entry = origin + size * entry_pct
        zone_low = origin + size * z_low
        zone_high = origin + size * z_high
        stop = origin - float(cfg.get("stop_buffer_atr", 1.0)) * atr
        target = peak
    else:
        entry = origin - size * entry_pct
        zone_high = origin - size * z_low
        zone_low = origin - size * z_high
        stop = origin + float(cfg.get("stop_buffer_atr", 1.0)) * atr
        target = peak
    return {"entry": entry, "zone_low": min(zone_low, zone_high),
            "zone_high": max(zone_low, zone_high), "stop": stop,
            "target": target, "direction": d}


def _smc_trend(all_results: Dict[str, Any]) -> str:
    smc = (all_results or {}).get("smc") or {}
    trend = str(smc.get("trend") or "").upper()
    if not trend:
        # Fused payload may nest the primary-frame structure.
        for key in ("structure", "market_structure", "primary"):
            sub = smc.get(key)
            if isinstance(sub, dict) and sub.get("trend"):
                return str(sub.get("trend")).upper()
    return trend


def _news_blocks(all_results: Dict[str, Any]) -> bool:
    news = (all_results or {}).get("news") or {}
    if news.get("can_trade") is False:
        return True
    if str(news.get("market_status", "")).upper() in {"DANGER", "HIGH_VOLATILITY"}:
        return True
    return False


def _auction_allows(all_results: Dict[str, Any], direction: str) -> bool:
    """Soft gate: block only when auction flow is CLEARLY against."""
    af = (all_results or {}).get("auction_flow") or {}
    if not isinstance(af, dict) or not af:
        return True  # no data -> do not block
    regime = str(af.get("regime") or af.get("profile") or "").upper()
    bias = str(af.get("bias") or "").upper()
    against = (direction == "BUY" and bias == "BEARISH") or \
              (direction == "SELL" and bias == "BULLISH")
    if against:
        return False
    return True


def try_pre_arm(*, data: Dict[str, Any], all_results: Dict[str, Any],
                config: Dict[str, Any], symbol: str,
                open_trades_snapshot: Optional[List[Dict[str, Any]]] = None,
                database: Any = None, telegram: Any = None,
                current_price: Optional[float] = None,
                demo_execution: bool = False) -> Optional[str]:
    """Attempt to arm a PENDING order at the projected OTE level.

    Returns the armed side ("BUY"/"SELL") on success, else None. NEVER
    raises — any internal problem means "no pre-arm, continue normally".
    """
    try:
        return _try_pre_arm_impl(data=data, all_results=all_results,
                                 config=config, symbol=symbol,
                                 open_trades_snapshot=open_trades_snapshot,
                                 database=database, telegram=telegram,
                                 current_price=current_price,
                                 demo_execution=demo_execution)
    except Exception as exc:  # noqa: BLE001 - pre-arm must never break the cycle
        logger.warning("PRE-ARM OTE skipped (non-fatal): %s", exc)
        return None


def _try_pre_arm_impl(*, data, all_results, config, symbol,
                      open_trades_snapshot, database, telegram,
                      current_price, demo_execution=False) -> Optional[str]:
    cfg = _cfg(config)
    if not bool(cfg.get("enabled", True)):
        return None
    if database is None:
        return None
    tf = str(cfg.get("timeframe", "15m"))
    candles = (((data.get("timeframes", {}) or {}).get(tf) or {}).get("data")
               or data.get("data") or [])
    if len(candles) < 10:
        return None
    atr_list = calculate_atr(candles, 14)
    atr = _f(atr_list[-1], 0.0) if atr_list else 0.0
    if atr <= 0:
        return None
    cp = _f(current_price, 0.0) or _f(data.get("current_price"), 0.0)
    if cp <= 0:
        return None

    # No existing open/pending on this symbol -> never stack a pre-arm.
    for t in (open_trades_snapshot or []):
        if str(t.get("symbol", "")).upper() == str(symbol).upper():
            status = str(t.get("status", "")).upper()
            if status in {"OPEN", "PARTIAL", "TP1_HIT", "PENDING"}:
                return None

    if _news_blocks(all_results):
        return None

    # SMC trend (hard gate when required) decides the candidate direction.
    trend = _smc_trend(all_results)
    candidate = None
    if trend == "BULLISH":
        candidate = "BUY"
    elif trend == "BEARISH":
        candidate = "SELL"
    else:
        return None
    if not _auction_allows(all_results, candidate):
        return None

    leg = detect_impulse_leg(candles, atr, cfg, candidate)
    if not leg:
        return None
    ote = project_ote(leg, cfg)

    # OTE must be on the correct side of price (waiting for the pullback).
    if candidate == "BUY" and ote["entry"] >= cp:
        return None  # pullback already went through/below -> consumed
    if candidate == "SELL" and ote["entry"] <= cp:
        return None
    # Distance cap.
    max_dist = float(cfg.get("max_pending_distance_points", 0.0))
    if max_dist <= 0:
        risk_cfg = (config.get("risk_settings") or {}) if isinstance(config, dict) else {}
        max_dist = _f(risk_cfg.get("max_pending_distance_points"), 0.0)
    if max_dist > 0:
        dist = abs(price_to_points(cp - ote["entry"], symbol=symbol))
        if dist > max_dist:
            return None

    # Risk / RR gate. The first objective is the leg peak (the reclaim);
    # a short leg vs ATR gives a thin reclaim, so the objective is EXTENDED
    # to the minimum RR (leg extension) rather than the arm being rejected.
    risk = abs(ote["entry"] - ote["stop"])
    if risk <= 0:
        return None
    tp2 = ote["target"]
    rr = abs(tp2 - ote["entry"]) / risk
    min_rr = float(cfg.get("min_rr_ratio", 1.5))
    if rr < min_rr:
        tp2 = (ote["entry"] + min_rr * risk) if candidate == "BUY" \
            else (ote["entry"] - min_rr * risk)
        rr = min_rr

    decision = _build_decision(config=config, cfg=cfg, symbol=symbol,
                               direction=candidate, ote=ote, cp=cp, rr=rr,
                               atr=atr, tp2=tp2)
    if not decision:
        return None
    # Persist (PENDING LIMIT) and notify, mirroring the reactive save path.
    trade_id = database.new_trade_id()
    decision["trade_id"] = trade_id
    decision["_telegram_signal_sent"] = False  # rich card after broker accepts
    try:
        database.save_trade(decision)
    except Exception as exc:  # noqa: BLE001
        logger.warning("PRE-ARM OTE save failed for %s %s: %s", direction, symbol, exc)
        return None
    # Demo/mt5 execution: the rich card is sent by the tick manager ONLY
    # after the broker accepts the order (same contract as the reactive
    # path). Paper mode announces immediately, like the reactive save flow.
    if not demo_execution:
        try:
            if telegram is not None and hasattr(telegram, "send_signal"):
                telegram.send_signal(decision)
        except Exception as exc:  # noqa: BLE001 - save succeeded; card best-effort
            logger.warning("PRE-ARM OTE signal delivery failed for %s: %s", symbol, exc)
    logger.info(
        "PRE-ARM OTE armed %s PENDING for %s: entry=%.2f zone=[%.2f-%.2f] "
        "stop=%.2f tp2=%.2f rr=%.2f (current=%.2f) path=%s",
        candidate, symbol, ote["entry"], ote["zone_low"], ote["zone_high"],
        ote["stop"], tp2, rr, cp, PATH_LABEL,
    )
    return candidate


def _build_decision(*, config, cfg, symbol, direction, ote, cp, rr, atr,
                    tp2=None) -> Optional[Dict[str, Any]]:
    decimals = price_decimals(symbol)
    pct = f"{float(cfg.get('entry_pct', 0.70)) * 100:.0f}"
    entry = round(ote["entry"], decimals)
    stop = round(ote["stop"], decimals)
    tp2 = round(float(tp2 if tp2 is not None else ote["target"]), decimals)
    tp1 = round(entry + (tp2 - entry) * 0.5, decimals)
    risk_cfg = (config.get("risk_settings") or {}) if isinstance(config, dict) else {}
    confidence = int(_f(risk_cfg.get("pre_arm_confidence"), 70))
    decision: Dict[str, Any] = {
        "symbol": symbol,
        "decision": direction,
        "confidence": confidence,
        "current_price": round(cp, decimals),
        "armed_at": ARMED_AT,
        "execution_path_id": PATH_PREARM_OTE,
        "execution_path_name": "PRE-ARM OTE — PROJECTED RETRACEMENT (BUILD 30)",
        "execution_path": PATH_LABEL,
        "entry_mode": "pre_arm_ote",
        "trading_mode": config.get("trading_mode", "demo"),
        "reasons": [
            f"PRE-ARM OTE: armed at {pct}% retracement of a "
            f"confirmed impulse leg (path {PATH_LABEL}); fills on touch, "
            f"runs to TP/stop/thesis like any other trade."
        ],
        "signal": {
            "symbol": symbol,
            "type": direction,
            "entry_kind": "LIMIT",
            "order_type": "BUY_LIMIT" if direction == "BUY" else "SELL_LIMIT",
            "entry": {
                "price": entry,
                "low": round(ote["zone_low"], decimals),
                "high": round(ote["zone_high"], decimals),
                "kind": "LIMIT",
            },
            "stop_loss": stop,
            "tp1": tp1,
            "tp2": tp2,
            "rr_ratio": round(float(rr), 2),
        },
    }
    if float(tp2) != round(float(ote["target"]), decimals):
        decision["reasons"].append(
            f"Objective extended to the {pct}% minimum R:R "
            f"(leg peak alone was thin); tp2 is the leg extension."
        )
    return decision
