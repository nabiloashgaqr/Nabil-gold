"""BUILD 19 (2026-08-20): the tick manager must manage each trade with ITS
OWN instrument laws.

Live regression: the first WTI trade (BUY @86.82, SL 84.12) shipped the GOLD
stop band (270 pts = $2.70) because the live loop read trailing/stop/pv from
the base (gold) config for every row. These tests pin the per-symbol fix.
"""
from __future__ import annotations

import json
from copy import deepcopy
from types import SimpleNamespace

import scripts.run_tick_manager as rtm
from utils.helpers import load_config


def _base_cfg():
    cfg = deepcopy(load_config())
    # keep the tick manager constructor quiet in tests
    cfg["auction_flow"] = {"enabled": False,
                           "storage_path": "storage/auction_flow.sqlite3"}
    return cfg


def _tm(cfg):
    db = SimpleNamespace(update_trade=lambda *a, **k: None)
    return rtm.TickManager(cfg, telegram=None, database=db)


# ── per-symbol laws ─────────────────────────────────────────────────────────
def test_laws_for_gold_row_are_gold():
    tm = _tm(_base_cfg())
    laws = tm._per_symbol_laws({"symbol": "XAU/USD"})
    t, s = laws["trailing"], laws["stop"]
    assert (t["distance_points"], t["step_points"], t["early_breakeven_points"]) == (150, 40, 150)
    assert (s["min_liquidity_points"], s["safety_buffer_points"], s["max_stop_points"]) == (200, 70, 400)


def test_laws_for_wti_row_are_oil():
    tm = _tm(_base_cfg())
    laws = tm._per_symbol_laws({"symbol": "WTI/USD"})
    t, s = laws["trailing"], laws["stop"]
    assert (t["distance_points"], t["step_points"], t["early_breakeven_points"]) == (70, 25, 70)
    assert (s["min_liquidity_points"], s["safety_buffer_points"], s["max_stop_points"]) == (60, 21, 120)


def test_laws_are_cached_per_symbol(monkeypatch):
    import utils.instruments as inst
    calls = []

    def _counting(base, instrument):
        calls.append(instrument.get("symbol"))
        return inst.config_for_instrument(base, instrument)

    monkeypatch.setattr(rtm, "config_for_instrument", _counting)
    tm = _tm(_base_cfg())
    tm._per_symbol_laws({"symbol": "WTI/USD"})
    tm._per_symbol_laws({"symbol": "WTI/USD"})
    tm._per_symbol_laws({"symbol": "WTI/USD"})
    assert calls == ["WTI/USD"]  # merged exactly once, then cached


def test_laws_fall_back_to_base_on_error(monkeypatch):
    tm = _tm(_base_cfg())

    def _boom(base, instrument):
        raise RuntimeError("merge failed")

    monkeypatch.setattr(rtm, "config_for_instrument", _boom)
    laws = tm._per_symbol_laws({"symbol": "WTI/USD"})
    assert laws["stop"]["max_stop_points"] == 400  # old base behaviour


# ── the live-regression repair path ─────────────────────────────────────────
class _Pos:
    price_open = 86.82
    sl = 84.12
    time = 0


class _Exec:
    def __init__(self):
        self.applied = []

    def apply_stop(self, tid, sl, tp2, symbol):
        self.applied.append((tid, round(sl, 2), round(tp2, 2), symbol))
        return True


def _wti_row(**overrides):
    row = {
        "id": "TRADE_LIVE_WTI_1",
        "symbol": "WTI/USD",
        "type": "BUY",
        "status": "OPEN",
        "entry_price": 86.82,
        "stop_loss": 84.12,
        "initial_stop_loss": 84.12,
        "tp1": 87.39,
        "tp2": 90.00,
        "mt5_ticket": 489284781,
        "execution_stop_normalized": True,
        "sl_moved_to_entry": False,
        "partial_close": False,
        "signal_snapshot": json.dumps({
            "signal": {"entry": {"price": 86.82}, "stop_loss": 85.72},
        }),
    }
    row.update(overrides)
    return row


def test_normalize_stop_uses_oil_band_for_wti_row():
    tm = _tm(_base_cfg())
    exec = _Exec()
    row = _wti_row()
    corrected = tm._normalize_execution_stop(row, _Pos(), exec, "BUY")
    # actual 270 pts > oil cap 120 -> the oil band clamps it DOWN to the cap
    assert corrected is not None
    assert abs(corrected - 85.62) < 0.01  # 86.82 - 1.20
    assert exec.applied[0][1] == corrected


def test_normalize_stop_keeps_legal_oil_stop():
    tm = _tm(_base_cfg())
    exec = _Exec()
    row = _wti_row(stop_loss=85.72)  # 110 pts - inside the 81..120 band
    corrected = tm._normalize_execution_stop(row, _Pos(), exec, "BUY")
    assert corrected == 85.72  # kept, never re-widened


def test_normalize_stop_gold_row_untouched():
    tm = _tm(_base_cfg())
    exec = _Exec()
    row = {
        "id": "T_G", "symbol": "XAU/USD", "type": "BUY", "status": "OPEN",
        "entry_price": 4520.0, "stop_loss": 4493.0, "initial_stop_loss": 4493.0,
        "execution_stop_normalized": True,
        "signal_snapshot": json.dumps({"signal": {"entry": {"price": 4520.0}, "stop_loss": 4493.0}}),
    }
    corrected = tm._normalize_execution_stop(row, _Pos(), exec, "BUY")
    # 270 pts on gold is legal -> kept
    assert corrected == 4493.0
    assert exec.applied == []


# ── per-symbol pv in the live math ──────────────────────────────────────────
def test_per_symbol_point_value_in_handle_row_math():
    from utils.instruments import point_size
    tm = _tm(_base_cfg())
    pv_wti = point_size("WTI/USD", tm.config)
    pv_gold = point_size("XAU/USD", tm.config)
    assert pv_wti == 0.01
    assert pv_gold == 0.10
    # the live loop now derives pv per row symbol - pin the source call
    import inspect
    src = inspect.getsource(rtm.TickManager._handle_row)
    assert 'point_size(str(row.get("symbol") or "XAU/USD"), self.config)' in src
    assert "pv = 0.10" not in src


# ── the repair script's arithmetic (live geometry) ──────────────────────────
def test_repair_restores_planned_oil_stop():
    from scripts.fix_live_wti_trade import plan_repair
    from utils.helpers import load_config
    from utils.instruments import config_for_instrument
    wti_cfg = config_for_instrument(load_config(), {"symbol": "WTI/USD"})
    row = _wti_row()  # planned stop 85.72 = 110 pts (legal oil band)
    plan = plan_repair(row, wti_cfg)
    assert plan is not None
    assert abs(plan["stop_new"] - 85.72) < 0.01   # restored, not the cap
    assert "restored planned stop" in plan["stop_basis"]
    assert abs(plan["tp1_new"] - 87.70) < 0.01    # 0.8R rung
    assert abs(plan["tp2_new"] - 88.58) < 0.01    # 2x TP1
    assert plan["rr_new"] > plan["rr_old"]


def test_repair_caps_stop_when_no_planned_stop():
    from scripts.fix_live_wti_trade import plan_repair
    from utils.helpers import load_config
    from utils.instruments import config_for_instrument
    wti_cfg = config_for_instrument(load_config(), {"symbol": "WTI/USD"})
    row = _wti_row(signal_snapshot=json.dumps({"signal": {"entry": {"price": 86.82}}}))
    plan = plan_repair(row, wti_cfg)
    assert plan is not None
    assert abs(plan["stop_new"] - 85.62) < 0.01   # 120-pt oil cap
    assert abs(plan["tp1_new"] - 87.78) < 0.01
    assert abs(plan["tp2_new"] - 88.74) < 0.01
    assert abs(plan["rr_new"] - 1.6) < 0.01


def test_repair_recomputes_targets_when_stop_already_legal():
    # after build 19 the tick manager may already have moved the stop to the
    # 120-pt cap (85.62): the repair must then fix TARGETS only
    from scripts.fix_live_wti_trade import plan_repair
    from utils.helpers import load_config
    from utils.instruments import config_for_instrument
    wti_cfg = config_for_instrument(load_config(), {"symbol": "WTI/USD"})
    row = _wti_row(stop_loss=85.62)
    plan = plan_repair(row, wti_cfg)
    assert plan is not None
    assert abs(plan["stop_new"] - 85.62) < 0.01   # kept
    assert abs(plan["tp1_new"] - 87.78) < 0.01
    assert abs(plan["tp2_new"] - 88.74) < 0.01    # was 90.00


def test_repair_noop_when_all_conform():
    from scripts.fix_live_wti_trade import plan_repair
    from utils.helpers import load_config
    from utils.instruments import config_for_instrument
    wti_cfg = config_for_instrument(load_config(), {"symbol": "WTI/USD"})
    row = _wti_row(stop_loss=85.62, tp1=87.78, tp2=88.74)
    assert plan_repair(row, wti_cfg) is None
