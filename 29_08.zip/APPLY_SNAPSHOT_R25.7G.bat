@echo off
setlocal
title APPLY SNAPSHOT R25.7G v2 - FULL SYSTEM
cd /d "%~dp0"
echo Current folder: %CD%
set "ROOT=C:\Nabil-gold"
echo Target folder : %ROOT%
if not exist "Nabil-gold\_manifest.json" goto NOT_EXTRACTED
if not exist "%ROOT%" goto NO_ROOT
echo.
echo NOTE: stop the running services BEFORE this step.
echo.
set RC=
echo [1/6] removing legacy one-shot scripts - best effort...
if exist "%ROOT%\_apply_config_r25_7.py" del /f /q "%ROOT%\_apply_config_r25_7.py" >nul 2>&1
if exist "%ROOT%\_apply_config_r25_7f.py" del /f /q "%ROOT%\_apply_config_r25_7f.py" >nul 2>&1
if exist "%ROOT%\_apply_config_r25_7g.py" del /f /q "%ROOT%\_apply_config_r25_7g.py" >nul 2>&1
if exist "%ROOT%\_apply_config_r25_7g.py" echo   NOTE: _apply_config_r25_7g.py is still LOCKED - the suite now skips it. Delete it later from an ADMIN prompt: del /f /q "%ROOT%\_apply_config_r25_7g.py"
echo [2/6] mirroring the full tree over the target...
robocopy "Nabil-gold" "%ROOT%" /E /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 set RC=1
echo [3/6] verifying sentinel SHA256...
certutil -hashfile "%ROOT%\config.json" SHA256 | findstr /I "e94614188f17c7f169f44951962c5d16fbed78eac6daab2851769a448335963b" >nul
if errorlevel 1 (echo   FAIL config.json & set RC=1) else echo   OK   config.json
certutil -hashfile "%ROOT%\services/weekend_policy.py" SHA256 | findstr /I "0c69e995f70d5cf41e58f0fda695ceee88553d01b0de7152474637876689a24a" >nul
if errorlevel 1 (echo   FAIL services/weekend_policy.py & set RC=1) else echo   OK   services/weekend_policy.py
certutil -hashfile "%ROOT%\services/pre_arm_ote.py" SHA256 | findstr /I "8f6cb7f3c4e2d0ad1c9575b305e433981a737d5df80fdbca29a38b71d3bb7bf5" >nul
if errorlevel 1 (echo   FAIL services/pre_arm_ote.py & set RC=1) else echo   OK   services/pre_arm_ote.py
certutil -hashfile "%ROOT%\services/thesis_consensus.py" SHA256 | findstr /I "063613cbbc06cb7e77a43f87f731bcf00dafbc16a0ef7ac31c1459d305a46190" >nul
if errorlevel 1 (echo   FAIL services/thesis_consensus.py & set RC=1) else echo   OK   services/thesis_consensus.py
certutil -hashfile "%ROOT%\services/mt5_executor.py" SHA256 | findstr /I "1f63642756e58627f5b6ff675ee1cfd8bb574fc31660a42e96db30956fa1b9e0" >nul
if errorlevel 1 (echo   FAIL services/mt5_executor.py & set RC=1) else echo   OK   services/mt5_executor.py
certutil -hashfile "%ROOT%\utils/trading_rules.py" SHA256 | findstr /I "fd28d12426d6b7b432cfe66c290d9f94ea77bc777467148c61ee030a65f5453a" >nul
if errorlevel 1 (echo   FAIL utils/trading_rules.py & set RC=1) else echo   OK   utils/trading_rules.py
certutil -hashfile "%ROOT%\scripts/run_tick_manager.py" SHA256 | findstr /I "d513f97b79408dafbd4bb5e4c002307d2ebb7cc896c6968a72226debbe43154e" >nul
if errorlevel 1 (echo   FAIL scripts/run_tick_manager.py & set RC=1) else echo   OK   scripts/run_tick_manager.py
certutil -hashfile "%ROOT%\tests/test_no_retired_tokens.py" SHA256 | findstr /I "ff8762d73fbce25c344c3ebe7b25f817c4881d7e9d47c404a0b78b25184505fb" >nul
if errorlevel 1 (echo   FAIL tests/test_no_retired_tokens.py & set RC=1) else echo   OK   tests/test_no_retired_tokens.py
echo [4/6] checking the tree is free of one-shot scripts...
if exist "%ROOT%\_apply_config_r25_7g.py" echo   INFO  locked legacy file left in place - suite skips it safely
echo [5/6] running the FULL test suite - about 3 minutes...
python -m pytest "%ROOT%\tests" -q -p no:cacheprovider
if errorlevel 1 set RC=1
echo [6/6] summary...
if defined RC goto FAILED
echo.
echo ==============================================
echo  SUCCESS - full system snapshot R25.7G v2 is
echo  on C:\Nabil-gold. Start Algo Trading BEFORE
echo  the Monday open, then restart the services
echo  as Administrator.
echo ==============================================
pause
exit /b 0

:FAILED
echo.
echo *** FAILED - send me the FULL output of this window.
pause
exit /b 1

:NO_ROOT
echo.
echo *** FAIL: %ROOT% not found. Edit ROOT in this bat
echo *** if your project folder differs.
pause
exit /b 1

:NOT_EXTRACTED
echo.
echo *** Extract the zip first: right-click - Extract All,
