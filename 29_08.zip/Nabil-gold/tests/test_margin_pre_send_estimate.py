"""R25.15 convoy item 5 — the margin guard judges the account AFTER the send.

pre_send_veto used to check only the CURRENT margin; an order whose own
expected margin (risk_usd.expected_margin at margin_planning_leverage) would
push exposure past the cap sailed through. The executor now estimates the
order's margin and passes it in.
"""
from __future__ import annotations

import types

import pytest

from services.margin_guard import pre_send_veto
from services.mt5_executor import Mt5DemoExecutor


def _account(equity=10000.0, margin=3000.0, margin_level=333.0, balance=10000.0):
    return types.SimpleNamespace(equity=equity, margin=margin,
                                 margin_level=margin_level, balance=balance)


def _config(**guard):
    return {"margin_guard": {"enabled": True, **guard}}


def test_without_estimate_current_exposure_only():
    allow, reason = pre_send_veto(_account(), _config(max_exposure_pct=40.0))
    assert allow is True
    assert "30.0%" in reason


def test_expected_margin_pushes_projection_over_cap():
    # current 30% + expected 15% -> 45% > 40% cap
    allow, reason = pre_send_veto(_account(), _config(max_exposure_pct=40.0),
                                  expected_margin_usd=1500.0)
    assert allow is False
    assert "projected exposure 45.0%" in reason
    assert "expected 1500.00" in reason


def test_expected_margin_inside_cap_still_allows():
    allow, _ = pre_send_veto(_account(), _config(max_exposure_pct=40.0),
                             expected_margin_usd=500.0)  # 30% + 5% = 35%
    assert allow is True


def test_negative_estimate_is_ignored():
    allow, _ = pre_send_veto(_account(), _config(max_exposure_pct=35.0),
                             expected_margin_usd=-99.0)  # stays 30%
    assert allow is True


def test_executor_margin_veto_passes_order_estimate():
    """The wiring: _margin_veto derives expected_margin from symbol/lots/px."""
    ex = Mt5DemoExecutor.__new__(Mt5DemoExecutor)
    ex.config = _config(max_exposure_pct=40.0)

    mt5 = types.SimpleNamespace(account_info=lambda: _account())
    # GBP/USD 1.0 lot @1.35504 -> notional $135,504 -> $135.50 @1:1000.
    # 30% + 1.4% stays under the cap: allowed.
    ok = ex._margin_veto(mt5, symbol="GBP/USD", lots=1.0, px=1.35504)
    assert ok is None or "OK" in ok

    # Same order on a 1:100 planning leverage -> $1,355 = 13.6% more:
    # 43.6% > 40% -> veto naming the projection.
    ex.config = _config(max_exposure_pct=40.0)
    ex.config["execution"] = {"margin_planning_leverage": 100}
    veto = ex._margin_veto(mt5, symbol="GBP/USD", lots=1.0, px=1.35504)
    assert veto is not None
    assert "projected exposure" in veto
