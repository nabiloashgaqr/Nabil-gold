"""2026-08-19 upgrade tests: margin guard veto wired into the MT5 executor.

Fault-injection: the executor must REFUSE new openings when account margin
level is below the floor, and must still allow protective closes.

Isolation: the module-level HALT_FILE is monkeypatched to a tmp path per test
so no test can leak a .demo_halt file into the repo or poison other suites.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import services.mt5_executor as m5mod  # noqa: E402
from services.mt5_executor import Mt5DemoExecutor  # noqa: E402
from tests import mt5_fake  # noqa: E402


@pytest.fixture()
def executor_env(monkeypatch, tmp_path):
    state = mt5_fake.FakeState()
    monkeypatch.setitem(sys.modules, "MetaTrader5", mt5_fake.install(state))
    monkeypatch.setattr(m5mod, "HALT_FILE", str(tmp_path / ".demo_halt"))
    return state


def _config(tmp_path, **overrides):
    cfg = {"margin_guard": {"enabled": True, "peak_file": str(tmp_path / "peak.json")}}
    cfg["margin_guard"].update(overrides)
    return cfg


class TestMarginVetoWired:
    def test_new_order_vetoed_on_low_margin(self, executor_env, tmp_path):
        executor_env.margin_level = 150.0
        executor_env.margin = 4000.0
        ex = Mt5DemoExecutor(_config(tmp_path), telegram=None)
        ticket = ex.ensure_ticket("TRADE_MV1", "BUY", "BUY_MARKET", 4300.0, 4290.0, 4320.0, "XAU/USD")
        assert ticket is None
        assert "margin guard veto" in ex.last_error
        assert ex.halted() is True  # halt latch was set

    def test_new_order_passes_with_healthy_account(self, executor_env, tmp_path):
        executor_env.equity, executor_env.margin, executor_env.margin_level = 10000.0, 500.0, 900.0
        ex = Mt5DemoExecutor(_config(tmp_path), telegram=None)
        ticket = ex.ensure_ticket("TRADE_MV2", "BUY", "BUY_MARKET", 4300.0, 4290.0, 4320.0, "XAU/USD")
        assert ticket is not None
        assert ex.halted() is False

    def test_margin_guard_disabled_bypasses(self, executor_env, tmp_path):
        executor_env.margin_level = 150.0
        ex = Mt5DemoExecutor(_config(tmp_path, enabled=False), telegram=None)
        ticket = ex.ensure_ticket("TRADE_MV3", "BUY", "BUY_MARKET", 4300.0, 4290.0, 4320.0, "XAU/USD")
        assert ticket is not None

    def test_no_margin_guard_config_fails_open(self, executor_env, tmp_path, monkeypatch):
        # Guard defaults to enabled; the "fail open" contract is about a broken
        # account_info read, and config defaults must never crash the executor.
        monkeypatch.chdir(tmp_path)  # keep the default peak file out of the repo
        ex = Mt5DemoExecutor({}, telegram=None)
        ticket = ex.ensure_ticket("TRADE_MV4", "BUY", "BUY_MARKET", 4300.0, 4290.0, 4320.0, "XAU/USD")
        assert ticket is not None
        assert ex.halted() is False

    def test_protective_close_never_vetoed(self, executor_env, tmp_path):
        executor_env.margin_level = 150.0
        executor_env.positions.append(mt5_fake._Pos(7, m5mod.magic_for("TRADE_MV5"), 4293.0, 4330.0, volume=0.10))
        ex = Mt5DemoExecutor(_config(tmp_path), telegram=None)
        result = ex.close_position("TRADE_MV5", "XAU/USD")
        assert result is True  # closing is protective and must pass the guard
