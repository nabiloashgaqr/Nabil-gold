"""R25.7-D (2026-08-28, operator order) — supersedes the BUILD 31 R3
k=0.4 era for WTI. The stop is the LIQUIDITY band [230, 330] (noise floor
160 + gold's exact +70 buffer, cap 330 — never fixed), and the whole
management law is GOLD VERBATIM in the symbol's own points:

    stop  = 160 / 70 / 330            -> band [230, 330] by liquidity
    TP1   = 0.8R of the stop (184 pts at the 230-pt floor)
    BE    = stop moves to entry at +150 pts
    trail = 150 / 40 from breakeven
    pool band = 200 pts · post-TP2 = 250 pts / 2.5h (gold, unchanged)

R-based rules (0.8R, 2x, 0.5R, 1.5R), percent thresholds and ATR
multipliers are scale-invariant (unchanged). Gold is UNTOUCHED.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.helpers import load_config
from utils.instruments import config_for_instrument
import utils.trading_rules as tr

def _wti():
    return config_for_instrument(load_config(), {"symbol": "WTI/USD"})


def _gold():
    return config_for_instrument(load_config(), {"symbol": "XAU/USD"})


def test_wti_stop_rule_is_the_r25_7d_liquidity_band():
    ws, gs = tr.stop_rule(_wti()), tr.stop_rule(_gold())
    assert ws["min_liquidity_points"] == 160.0   # noise floor
    assert ws["safety_buffer_points"] == 70.0    # gold's exact addition
    assert ws["max_stop_points"] == 330.0        # band cap
    assert (gs["min_liquidity_points"], gs["safety_buffer_points"],
            gs["max_stop_points"]) == (200.0, 70.0, 400.0)


def test_wti_stop_band_is_230_to_330_points():
    cfg = _wti()
    # No eligible liquidity -> the cap ships directly.
    assert tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00, liquidity_map={}, cfg=cfg,
        symbol="WTI/USD") == 330
    # A 90-pt level is closer than the 160-pt noise floor -> swept noise,
    # the cap ships (the band is liquidity-dependent, never fixed).
    lvl = tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00,
        liquidity_map={"sell_side": [83.10]}, cfg=cfg, symbol="WTI/USD")
    assert lvl == 330
    # A 170-pt level qualifies -> +70 buffer = 240 (just above the floor).
    lvl2 = tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00,
        liquidity_map={"sell_side": [82.30]}, cfg=cfg, symbol="WTI/USD")
    assert abs(lvl2 - 240) < 0.01, f"170-pt level + 70 = 240 pts, got {lvl2}"
    # A 250-pt level -> 320 (inside the band).
    lvl3 = tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00,
        liquidity_map={"sell_side": [84.00 - 2.50, 84.00 - 0.50]},
        cfg=cfg, symbol="WTI/USD")
    assert abs(lvl3 - 320) < 0.01
    # A 300-pt level -> 370 would breach the cap -> the cap ships: 330.
    lvl4 = tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00,
        liquidity_map={"sell_side": [81.00]}, cfg=cfg, symbol="WTI/USD")
    assert abs(lvl4 - 330) < 0.01  # the cap is exact


def test_wti_tp1_is_the_08r_rung_and_184_at_the_floor():
    cfg = _wti()
    ratios = tr.target_ratios(cfg)
    assert ratios["min_tp1_rr"] == 0.8
    assert ratios["tp2_multiple"] == 2.0
    assert ratios["max_beyond_points"] == 200.0   # gold-exact pool band
    # No pools: TP1 = 0.8R. Stop at the 230-pt floor ($2.30) ->
    # TP1 = 0.8 x $2.30 = $1.84 (184 pts), TP2 = 2x (368 pts).
    tp1, tp2, _ = tr.targets_law(
        direction="SELL", entry=85.36, risk_price=2.30, levels=[],
        cfg=cfg, symbol="WTI/USD")
    assert abs(tp1 - 83.52) < 0.011, "TP1 must be the 0.8R rung (184 pts)"
    assert abs(tp2 - 81.68) < 0.011, "TP2 must be 2x TP1 distance"


def test_wti_target_caps_are_gone():
    """No BUILD 18 caps at any scale: a 0.8R rung on the floor stop is
    84.8 pts (216 x0.4) — caps would contradict the law. Gold parity =
    no caps; far pools may win inside the 80-pt (200x0.4) band."""
    cfg = _wti()
    tgt = (cfg.get("trading_rules") or {}).get("targets") or {}
    assert tgt.get("max_tp1_points", 0) == 0
    assert tgt.get("max_tp2_points", 0) == 0
    # A pool within the gold band still wins over the 2x rung:
    # risk 2.30 -> TP2 rung = 85.36 - 3.68 = 81.68; pool at 81.30
    # (38 pts beyond the rung, inside the 200-pt band) wins.
    tp1, tp2, used = tr.targets_law(
        direction="SELL", entry=85.36, risk_price=2.30,
        levels=[81.30], cfg=cfg, symbol="WTI/USD")
    assert used
    assert abs(tp2 - 81.30) < 1e-9  # the pool, not the 3.68 rung


def test_wti_trailing_and_breakeven_are_gold_verbatim():
    cfg = _wti()
    t = tr.trailing_params(cfg)
    assert t["distance_points"] == 150.0
    assert t["step_points"] == 40.0
    assert t["early_breakeven_points"] == 150.0
    assert t["activation_at"] == "BREAKEVEN"
    assert cfg["trailing_stop"]["early_breakeven_points"] == 150
    assert cfg["risk_settings"]["min_sl_distance_points"] == 230


def test_wti_second_entry_family_and_planner_are_gold_times_04():
    """The whole distance family + planner geometry at x0.4 (gold: 150).
    R25.7-D scope note: entry geometry (cross/scale/dup/planner) is NOT
    part of the stop/targets/trailing/laws change and stays x0.4."""
    cfg = _wti()
    gold = _gold()
    assert (cfg["signal_requirements"]["two_agent_entry"]
            ["cross_entry_distance_points"]) == 60
    assert (cfg["order_execution"]["fixed_risk"]
            ["scale_in_trigger_points"]) == 60
    from utils.instruments import DEFAULT_INSTRUMENTS
    assert DEFAULT_INSTRUMENTS["WTI/USD"]["duplicate_zone_points"] == 60
    assert DEFAULT_INSTRUMENTS["XAU/USD"]["duplicate_zone_points"] == 150
    pl_w, pl_g = cfg["session_planner"], gold["session_planner"]
    assert pl_w["standby_min_distance_points"] == 150 * 0.4 == 60
    assert pl_w["max_primary_zone_width_points"] == 450 * 0.4 == 180
    assert pl_w["min_entry_zone_width_points"] == 60 * 0.4 == 24
    assert pl_w["min_thesis_objective_points"] == 30 * 0.4 == 12


def test_wti_post_tp2_is_gold_times_04():
    cfg = _wti()
    p = (cfg.get("trading_rules") or {}).get("post_tp2") or {}
    # R25.7-D scope note: the post-TP2 re-entry guard is not part of the
    # stop/targets/trailing change and keeps the x0.4 distance.
    assert p.get("min_distance_points") == 250 * 0.4 == 100
    assert p.get("window_hours") == 2.5  # time is not scaled


def test_gold_unchanged():
    cfg = _gold()
    s = tr.stop_rule(cfg)
    assert (s["min_liquidity_points"], s["safety_buffer_points"], s["max_stop_points"]) == (200, 70, 400)
    t = tr.trailing_params(cfg)
    assert (t["distance_points"], t["step_points"], t["early_breakeven_points"]) == (150, 40, 150)
