"""BUILD 31 R2 (2026-08-24, operator orders):

1) "تسمية كل مسار" — every card must carry a NAMED path. The VPS showed
   "EXECUTION PATH — UNKNOWN / LEGACY" on a PRE-ARM order because the card
   is sent by the tick manager from the stored snapshot (old process /
   trimmed snapshot lost the structured path fields). Now:
     * armed_at="pre_arm_ote" is an AUTHORITATIVE path marker in
       resolve_execution_path (the header can never degrade to UNKNOWN);
     * _send_execution_signal injects the row's armed_at column;
     * truly unresolvable rows say NOT RECORDED (LEGACY DECISION) —
       an honest reason instead of a mystery.
2) The pre-arm card states explicitly what decided the order: it is an
   ARMING MODE with NO 5-agent vote, and it publishes the gates (SMC
   trend, impulse leg, OTE zone). "0 pts to activation" is dead:
   distance_points is set at arm time and recomputed on display when
   missing.
3) "طابق كل قوانين الذهب بالنفط" — FULL parity: the 0.3-scale remnant
   (duplicate 75 / cross 45 / scale-in 45 / session-planner override) is
   gone; oil runs gold's 150/150/150 family + global planner geometry.
4) The VPS failed BUILD 31 because the config merge (config overrides
   code) had not run before the test suite. Now the law travels with the
   package: deploy/config_merge.json + apply_config_merge.py, applied
   before the tests by install_build31_r2.ps1 / APPLY_PATCH v4. This file
   proves the shipped spec repairs a stale-VPS-style config.
"""
from __future__ import annotations

import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import pytest  # noqa: E402

from services import pre_arm_ote as pa  # noqa: E402
from services.execution_paths import (  # noqa: E402
    PATH_6,
    path_header,
    resolve_execution_path,
)


# ── 1) path naming: armed_at is authoritative ──────────────────────────────

def test_path_resolves_from_armed_at_alone():
    """No structured path fields at all — only the arming column. The
    header must still be the named PRE-ARM path, never UNKNOWN."""
    row = {"id": "T1", "armed_at": "pre_arm_ote",
           "signal_snapshot": {"decision": "SELL"}}
    got = resolve_execution_path(row)
    assert got["id"] == "PATH_6_TWO_AGENT_OTE"
    assert "PATH 6" in got["name"]
    assert "TWO-AGENT CONFIRMED OTE" in got["name"]


def test_path_header_for_stale_snapshot_row():
    """The exact VPS incident shape: tick-manager card payload built from
    a snapshot that lost its path fields while the row column survived."""
    context = {"symbol": "XAU/USD", "type": "SELL", "status": "PENDING",
               "armed_at": "pre_arm_ote",
               "signal_snapshot": {}}
    header = path_header(context, html=False)
    assert "NOT RECORDED" not in header
    assert "UNKNOWN" not in header
    assert "PATH 6" in header
    assert "TWO-AGENT CONFIRMED OTE" in header


def test_unresolvable_path_says_not_recorded():
    """A row with NO provenance at all gets an honest reason, not a
    mystery label."""
    got = resolve_execution_path({"id": "T2"})
    assert got["id"] == "UNKNOWN_EXECUTION_PATH"
    assert "NOT RECORDED" in got["name"]
    assert "UNKNOWN / LEGACY" not in got["name"]


def test_explicit_path_id_still_wins():
    from services.execution_paths import PATH_1
    got = resolve_execution_path({"execution_path_id": PATH_1})
    assert got["id"] == PATH_1


def test_execution_signal_injects_armed_at_from_row():
    """Even when the snapshot has zero provenance, the tick manager copies
    the row's armed_at column into the decision before the card is sent."""
    from scripts.run_tick_manager import TickManager

    sent = []

    class _TG:
        def send_signal(self, decision):
            sent.append(decision)
            return True

    class _DB:
        def update_trade(self, tid, updates):
            return True

    mgr = TickManager(_cfg(), telegram=_TG(), database=_DB())
    row = {
        "id": "TRADE_TEST", "symbol": "XAU/USD", "type": "SELL",
        "status": "PENDING", "telegram_signal_sent": False,
        "armed_at": "pre_arm_ote",
        "signal_snapshot": {
            "symbol": "XAU/USD", "decision": "SELL", "confidence": 70,
            "current_price": 4631.98,
            "signal": {"symbol": "XAU/USD", "type": "SELL",
                       "entry_kind": "SELL_LIMIT",
                       "entry": {"price": 4639.06, "low": 4636.38,
                                 "high": 4641.44, "kind": "LIMIT"},
                       "stop_loss": 4671.25, "tp1": 4614.92,
                       "tp2": 4590.77, "rr_ratio": 1.5},
        },
    }
    mgr._send_execution_signal(row)
    assert len(sent) == 1, "card must be sent for a stored pre-arm row"
    assert sent[0].get("armed_at") == "pre_arm_ote"
    got = resolve_execution_path(sent[0])
    assert got["id"] == PATH_6


# ── 2) pre-arm decision carries distance + the gates that decided ─────────

def _flat_then_impulse_up(points=40.0, n_flat=12):
    candles = []
    base = 4600.0
    for _ in range(n_flat):
        candles.append({"time": "2026-08-20T10:00:00+00:00", "open": base,
                        "high": base + 1, "low": base - 1, "close": base})
    step = points / 3
    for i in range(3):
        o = base + step * i
        c = base + step * (i + 1)
        candles.append({"time": "2026-08-20T10:00:00+00:00", "open": o,
                        "high": c + 1, "low": o - 1, "close": c})
    top = base + points
    candles.append({"time": "2026-08-20T10:00:00+00:00", "open": top,
                    "high": top + 0.5, "low": top - 0.5, "close": top})
    return candles


class _DB:
    def __init__(self):
        self.saved = []

    def new_trade_id(self):
        return "TRADE_PREARM_R2"

    def save_trade(self, decision):
        self.saved.append(decision)
        return decision["trade_id"]


def _cfg():
    from utils.helpers import load_config
    return load_config()


def test_prearm_decision_carries_distance_and_gates():
    # R25.7-G: this test pins the CLASSIC arm (static 70% OTE), so the leg
    # must stay below the news-leg class (>=6x ATR). A 40pt leg on this
    # synthetic ATR measures ~9x = a news leg (entry 50%) by design now.
    candles = _flat_then_impulse_up(points=15.0)
    cp = max(c["high"] for c in candles) - 5.0
    db = _DB()
    side = pa.try_pre_arm(
        data={"timeframes": {"15m": {"data": candles}},
              "current_price": cp},
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": True},
                     "macro_fundamental": {"macro_direction": {
                         "bias": "BULLISH_GOLD", "confidence": 58.0}}},
        config={}, symbol="XAU/USD",
        open_trades_snapshot=[], database=db, telegram=None,
        current_price=cp,
        classic_book={"consensus": {"BUY": {
            "supporters": ["smc", "technical", "classical"],
            "opponents": ["multitimeframe"], "support_count": 3,
            "opposition_count": 1, "edge": 1.0, "confidence": 68.0},
            "SELL": {"supporters": [], "opponents": [],
                     "support_count": 0, "opposition_count": 0,
                     "edge": 0.0, "confidence": 0.0}}})
    assert side == "BUY"
    d = db.saved[0]
    entry = d["signal"]["entry"]
    # distance to activation: real number, never 0 (the VPS card bug)
    assert entry["distance_points"] > 0
    assert abs(entry["distance_points"]
               - abs(entry["price"] - cp) / 0.1) < 1.0  # XAU pt = $0.10
    # PATH 6 stamps + the confirmation
    assert d["execution_path_id"] == PATH_6
    assert d["entry_mode"] == "two_agent_ote"
    assert d["confirm_source"] == "macro"
    assert d["vote_at_arm"]["edge"] == 1.0
    assert d["vote_at_arm"]["net_confidence"] == 68.0
    # the gates that decided — published on the card
    info = d["pre_arm_info"]
    assert info["smc_trend"] == "BULLISH"
    assert info["timeframe"] == "15m"
    assert info["impulse_leg_atr"] is not None and info["impulse_leg_atr"] > 0
    assert info["entry_pct"] == 0.70
    zlo, zhi = info["ote_zone"]
    assert zlo < entry["price"] < zhi


# ── 3) the signal card itself ──────────────────────────────────────────────

def _card_service():
    from services.telegram_bot import TelegramService

    class _Cap(TelegramService):
        def __init__(self):
            super().__init__({"telegram": {}})
            self.captured = []

        def send_message(self, text, urgent=False, chat_id=None):
            self.captured.append(text)
            return True

    return _Cap()


def _incident_decision():
    """The exact VPS incident shape (08:31 UTC SELL LIMIT) as a decision
    dict — including a snapshot-era one WITHOUT distance_points, to prove
    the display-side recompute."""
    return {
        "symbol": "XAU/USD", "decision": "SELL", "confidence": 70,
        "current_price": 4631.98,
        "armed_at": "pre_arm_ote",
        "execution_path_id": PATH_6,
        "entry_mode": "two_agent_ote",
        "confirm_source": "macro",
        "confirm_confidence": 58.0,
        "trade_id": "TRADE_20260824_083111_653484_ca462637",
        "vote_at_arm": {
            "supporters": ["classical", "smc", "technical"],
            "opponents": ["multitimeframe"],
            "edge": 1.0, "net_confidence": 68.0,
            "confirm_source": "macro", "confirm_confidence": 58.0,
            "min_supporters": 2, "min_net_confidence": 65.0,
        },
        "pre_arm_info": {
            "smc_trend": "BEARISH", "timeframe": "15m",
            "impulse_leg_atr": 1.62, "entry_pct": 0.70,
            "ote_zone": [4636.38, 4641.44], "atr": 0.52,
        },
        "reasons": ["PRE-ARM OTE: armed at 70% retracement."],
        "signal": {
            "symbol": "XAU/USD", "type": "SELL", "entry_kind": "SELL_LIMIT",
            "order_type": "SELL_LIMIT",
            "entry": {"price": 4639.06, "low": 4636.38, "high": 4641.44,
                      "kind": "LIMIT", "current_price": 4631.98},
            "stop_loss": 4671.25, "tp1": 4614.92, "tp2": 4590.77,
            "rr_ratio": 1.5,
        },
    }


def test_signal_card_names_the_path_and_the_mode():
    svc = _card_service()
    decision = _incident_decision()
    assert svc.send_signal(decision)
    text = svc.captured[-1]
    # named path on line 1 — PATH 6, never UNKNOWN / NOT RECORDED
    assert "PATH 6 — TWO-AGENT CONFIRMED OTE (PRE-ARM)" in text
    assert "UNKNOWN" not in text and "NOT RECORDED" not in text
    # the arming is declared, the book is published (opponents deducted),
    # the confirmation uses the two-agent paths' own wording, the gates
    # are published
    assert "PATH 6 — OTE ARMED BEFORE THE PULLBACK" in text
    assert "Book: 3" in text
    assert "classical, smc, technical" in text
    assert "multitimeframe" in text
    assert "net weighted 68%" in text
    assert "(opponents deducted)" in text
    assert "Macro confirms SELL (58% confidence ≥ 55%)" in text
    assert "Gates:" in text
    assert "BEARISH" in text
    assert "4636.38" in text and "4641.44" in text  # OTE zone


def test_signal_card_distance_to_activation_is_real():
    svc = _card_service()
    decision = _incident_decision()
    # snapshot era: no distance_points field at all
    del decision["signal"]["entry"]["current_price"]
    assert svc.send_signal(decision)
    text = svc.captured[-1]
    # 4639.06 - 4631.98 = $7.08 = 70.8 pts -> "71 pts to activation"
    assert "71 pts to activation" in text, text[-600:]
    assert "0 pts to activation" not in text


def test_signal_card_reactive_unaffected():
    """A normal reactive card must NOT carry the pre-arm section."""
    svc = _card_service()
    d = {
        "symbol": "XAU/USD", "decision": "BUY", "confidence": 72,
        "current_price": 4600.0, "trade_id": "T_REACTIVE",
        "execution_path_id": "PATH_1_THREE_AGENT_CONSENSUS",
        "signal": {"symbol": "XAU/USD", "type": "BUY",
                   "entry_kind": "MARKET",
                   "entry": {"price": 4600.0, "kind": "MARKET"},
                   "stop_loss": 4585.0, "tp1": 4612.0, "tp2": 4624.0,
                   "rr_ratio": 1.6},
    }
    assert svc.send_signal(d)
    text = svc.captured[-1]
    assert "PATH 1 — THREE-AGENT CONSENSUS" in text
    assert "PRE-ARM MODE" not in text


# ── 4) full WTI parity in the merged config ────────────────────────────────

def test_wti_law_is_04_of_gold_in_effective_config():
    """BUILD 31 R3: the whole distance family is gold x0.4 (60 for oil,
    150 for gold) and the WTI planner override is gold x0.4."""
    from utils.instruments import (DEFAULT_INSTRUMENTS,
                                   config_for_instrument, get_instrument)
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    wti = config_for_instrument(cfg, get_instrument(cfg, "WTI/USD"))
    gold = config_for_instrument(cfg, get_instrument(cfg, "XAU/USD"))
    assert (wti["signal_requirements"]["two_agent_entry"]
            ["cross_entry_distance_points"] == 60
            and gold["signal_requirements"]["two_agent_entry"]
            ["cross_entry_distance_points"] == 150)
    assert (wti["order_execution"]["fixed_risk"]["scale_in_trigger_points"]
            == 60
            and gold["order_execution"]["fixed_risk"]
            ["scale_in_trigger_points"] == 150)
    assert DEFAULT_INSTRUMENTS["WTI/USD"]["duplicate_zone_points"] == 60
    assert DEFAULT_INSTRUMENTS["XAU/USD"]["duplicate_zone_points"] == 150
    pl_w, pl_g = wti["session_planner"], gold["session_planner"]
    assert pl_w["standby_min_distance_points"] == pl_g["standby_min_distance_points"] * 0.4 == 60
    assert pl_w["max_primary_zone_width_points"] == pl_g["max_primary_zone_width_points"] * 0.4 == 180


def test_shipped_config_merge_repairs_a_stale_vps_config():
    """End-to-end: take a STALE-VPS-style config (the exact values that
    failed BUILD 31: 120/70/25/70 + 75/45 + old law block + planner
    override + calibration flag ON), run the SHIPPED spec through the
    SHIPPED tool, and verify the new law lands while VPS-specific state
    (auction calibration, other entries) survives."""
    spec_path = ROOT / "deploy" / "config_merge.json"
    tool_path = ROOT / "deploy" / "apply_config_merge.py"
    assert spec_path.exists() and tool_path.exists()

    stale = {
        "trading_rules": {},
        "instruments": [
            {"symbol": "XAU/USD", "name": "Gold", "point_size": 0.10},
            {"symbol": "WTI/USD", "name": "WTI Crude Oil", "point_size": 0.01,
             "min_sl_distance_points": 120, "trailing_distance": 70,
             "trailing_step": 25, "early_breakeven_points": 70,
             "duplicate_zone_points": 75,
             "cross_entry_distance_points": 45,
             "scale_in_trigger_points": 45,
             "trading_rules": {  # the OLD 0.3-scale law
                 "stop": {"min_liquidity_points": 60,
                          "safety_buffer_points": 21,
                          "max_stop_points": 120},
                 "targets": {"min_tp1_rr": 0.8, "tp2_multiple": 2.0,
                             "max_tp1_points": 150,
                             "max_tp2_points": 350},
             },
             "session_planner": {"standby_min_distance_points": 45,
                                 "max_primary_zone_width_points": 135},
             "auction_flow": {"calibration_required": True},
             "description": "stale vps entry"},
        ],
        # the VPS already carries the BUILD 30 block (customized)
        "pre_arm_ote": {"enabled": True, "entry_pct": 0.7,
                        "vps_custom_tuning": 123},
    }
    tmp = Path(tempfile.mkdtemp(prefix="b31r2_"))
    try:
        cfg_file = tmp / "config.json"
        cfg_file.write_text(json.dumps(stale), encoding="utf-8")
        out = subprocess.run(
            [sys.executable, str(tool_path), "--config", str(cfg_file),
             "--spec", str(spec_path)],
            capture_output=True, text=True, cwd=str(ROOT))
        assert out.returncode == 0, out.stderr

        merged = json.loads(cfg_file.read_text(encoding="utf-8"))
        wti = [i for i in merged["instruments"]
               if i["symbol"] == "WTI/USD"][0]
        # the new law (gold x 0.4), all of it
        assert wti["min_sl_distance_points"] == 160
        assert wti["trailing_distance"] == 60
        assert wti["trailing_step"] == 16
        assert wti["early_breakeven_points"] == 60
        assert wti["duplicate_zone_points"] == 60
        assert wti["cross_entry_distance_points"] == 60
        assert wti["scale_in_trigger_points"] == 60
        assert wti["trading_rules"]["stop"] == {
            "enabled": True, "min_liquidity_points": 80,
            "safety_buffer_points": 28, "max_stop_points": 160}
        assert wti["trading_rules"]["targets"]["min_tp1_rr"] == 0.8
        assert wti["trading_rules"]["targets"]["max_beyond_points"] == 80
        assert "max_tp1_points" not in wti["trading_rules"]["targets"]
        assert wti["trading_rules"]["trailing"] == {
            "enabled": True, "distance_points": 60, "step_points": 16,
            "activation_at": "BREAKEVEN", "early_breakeven_points": 60}
        assert wti["trading_rules"]["post_tp2"] == {
            "enabled": True, "min_distance_points": 100, "window_hours": 2.5}
        # the 0.3-scale planner override is REPLACED by gold x0.4
        assert wti["session_planner"]["standby_min_distance_points"] == 60
        assert wti["session_planner"]["max_primary_zone_width_points"] == 180
        assert wti["session_planner"]["min_entry_zone_width_points"] == 24
        # VPS-specific state SURVIVES
        assert wti["auction_flow"]["calibration_required"] is True
        assert wti["description"] == "stale vps entry"
        xau = [i for i in merged["instruments"]
               if i["symbol"] == "XAU/USD"][0]
        assert xau == {"symbol": "XAU/USD", "name": "Gold",
                       "point_size": 0.10}
        # the PATH 6 vote gate is merged INTO the existing pre_arm_ote
        # block without touching the VPS's own keys
        pa_block = merged["pre_arm_ote"]
        assert pa_block["vote_gate"] == {"enabled": True,
                                         "min_supporters": 2,
                                         "min_net_confidence": 65,
                                         "require_confirmation": True}
        assert pa_block["entry_pct"] == 0.7
        assert pa_block["vps_custom_tuning"] == 123

        # idempotent: second run changes nothing
        before = cfg_file.read_text(encoding="utf-8")
        out2 = subprocess.run(
            [sys.executable, str(tool_path), "--config", str(cfg_file),
             "--spec", str(spec_path)],
            capture_output=True, text=True, cwd=str(ROOT))
        assert out2.returncode == 0
        assert "no changes" in out2.stdout
        assert cfg_file.read_text(encoding="utf-8") == before
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_install_and_merge_tool_ship_in_deploy():
    """The self-healing chain must exist for the VPS: installer + spec +
    tool, and APPLY_PATCH v4 must carry the merge step."""
    for rel in ("deploy/install_build31_r2.ps1",
                "deploy/config_merge.json",
                "deploy/apply_config_merge.py",
                "deploy/APPLY_PATCH.ps1"):
        assert (ROOT / rel).exists(), f"missing {rel}"
    ps1 = (ROOT / "deploy" / "APPLY_PATCH.ps1").read_text(encoding="utf-8")
    assert "config_merge.json" in ps1, "APPLY_PATCH v4 lost the merge step"
    assert "restored: config.json" in ps1, "APPLY_PATCH v4 lost config rollback"
    inst = (ROOT / "deploy" / "install_build31_r2.ps1").read_text(
        encoding="utf-8")
    assert "APPLY_PATCH.ps1" in inst


# ── BUILD 31 R5: a 400 must not lose the card ──────────────────────────────

def test_telegram_http_400_retries_as_plain_text(monkeypatch):
    """VPS incident 2026-08-24 12:31: 'telegram send HTTP 400' dropped a
    PATH 2 card. On a 400 (bad HTML / too long) the card must be redelivered
    ONCE as plain text, and the API description must reach the log."""
    import services.telegram_bot as tb

    svc = tb.TelegramService({"telegram": {"bot_token": "t", "chat_id": "c"}})
    calls = []
    warnings = []

    class _Resp:
        def __init__(self, code, body=""):
            self.status_code = code
            self.text = body

    class _Session:
        def post(self, url, json=None, timeout=None):
            calls.append(dict(json))
            if len(calls) == 1:
                return _Resp(400, '{"ok":false,"description":"can\'t parse entities"}')
            return _Resp(200, "")

    svc.session = _Session()
    monkeypatch.setattr(svc, "_reserve_delivery", lambda key: True)
    monkeypatch.setattr(svc, "_finish_delivery", lambda key, ok: None)
    monkeypatch.setattr(
        tb.logger, "warning",
        lambda msg, *args: warnings.append(msg % args if args else msg))

    ok = svc.send_message("<b>PATH 2 test</b>")
    assert ok is True, "the card must still be delivered"
    assert "parse_mode" in calls[0] and len(calls) == 2
    assert "parse_mode" not in calls[1], "retry must be plain text"
    assert any("400" in w and "parse" in w for w in warnings), warnings


# ── BUILD 31 R7: double-escaped tags are repaired at the send boundary ──

def test_double_escaped_tags_repaired_at_send_boundary():
    """Operator report 2026-08-24 (خلط رموز): a stale producer process
    double-escaped the path header, so the card showed literal '<b>' text.
    The send boundary must repair TAG entities only — single-escaped user
    content ('&lt;200' for a real '<') must stay correct."""
    from services.telegram_bot import TelegramService

    t = TelegramService({"telegram": {"bot_token": "t", "chat_id": "c"}})
    broken = (
        "🛣️ &lt;b&gt;PATH 2 — TWO-AGENT + MACRO&lt;/b&gt;\n"
        "🧭 &lt;b&gt;XAU/USD — PLAN UPDATE&lt;/b&gt;\n"
        "🟢 &lt;b&gt;Bias:&lt;/b&gt; BUY\n"
        "⚠️ Execution stop set by the operator liquidity rule "
        "(ignore &lt;200 pts, +70 safety, cap 400)."
    )
    out = t._polish_message_text(broken, demo=False)
    # the formatting tags are back to real tags
    assert "<b>PATH 2 — TWO-AGENT + MACRO</b>" in out
    assert "<b>XAU/USD — PLAN UPDATE</b>" in out
    assert "<b>Bias:</b> BUY" in out
    assert "&lt;b&gt;" not in out and "&lt;/b&gt;" not in out
    # the single-escaped user '<' is untouched (still correct for Telegram)
    assert "ignore &lt;200 pts" in out


def test_correct_card_is_untouched_by_tag_repair():
    """A correctly built card (raw tags, single-escaped user content)
    passes the boundary byte-identical."""
    from services.telegram_bot import TelegramService

    t = TelegramService({"telegram": {"bot_token": "t", "chat_id": "c"}})
    good = (
        "🛣️ <b>PATH 2 — TWO-AGENT + MACRO</b>\n"
        "🧭 <b>XAU/USD — PLAN UPDATE</b>\n"
        "🟢 <b>Bias:</b> BUY\n"
        "⚠️ (ignore &lt;200 pts, +70 safety, cap 400)."
    )
    assert t._polish_message_text(good, demo=False) == good


# ── BUILD 31 R8: cards must be Telegram-parseable HTML ─────────────────────
# VPS incident 2026-08-24: "can't parse entities: Unsupported start tag
# '65%)'" — the opinion line emitted a raw "<65%" (NOT QUALIFIED (<65%)),
# Telegram 400'd the HTML and the R5 fallback delivered the card as plain
# text (no bold, literal tags visible). Fix: escape at the producers + a
# parse-safety net at the single send boundary.

import re as _re

_TELEGRAM_TAGS = {"b", "i", "u", "a", "pre", "code", "blockquote", "tg-spoiler"}


def _assert_telegram_html_parseable(text: str) -> None:
    """Fail on any '<' Telegram's parser would reject, and on any
    unbalanced tag — i.e. the two 400 classes actually seen in the logs."""
    for m in _re.finditer(r"<", text):
        seg = text[m.start():m.start() + 40]
        mm = _re.match(r"</?([a-zA-Z][a-zA-Z0-9_-]*)", seg)
        assert mm, f"invalid '<' start: {seg!r}"
        assert mm.group(1).lower() in _TELEGRAM_TAGS, \
            f"unsupported tag: {mm.group(0)!r}"
    stack: list = []
    for m in _re.finditer(r"<(/?)([a-zA-Z][a-zA-Z0-9_-]*)", text):
        tag = m.group(2).lower()
        if m.group(1):
            assert stack and stack[-1] == tag, f"unbalanced close </{tag}>"
            stack.pop()
        else:
            stack.append(tag)
    assert not stack, f"unclosed tags: {stack}"


def test_r8_not_qualified_line_is_html_safe():
    from services.telegram_bot import TelegramService

    class _Cap(TelegramService):
        def __init__(self):
            super().__init__({"telegram": {"bot_token": "x", "chat_id": "y"}})
            self.captured = []

        def send_message(self, text, urgent=False, chat_id=None):
            self.captured.append(text)
            return True

    t = _Cap()
    plan = {
        "symbol": "XAU/USD", "status": "READY", "bias": "BUY",
        "session_label": "New York Evening", "session_quality": "HIGH",
        "map_quality_grade": "A+", "map_quality_score": 93.3,
        "authority": "CONFIRMED",
        "agent_book_summary": {"support_count": 2, "opposition_count": 0,
                               "inactive_count": 3,
                               "supporters": ["technical", "classical"],
                               "opponents": []},
        "execution_admission": {"path": "TWO_AGENT_MACRO", "confidence": 71.4},
        "delivery_reason": "first_ready_plan_this_session",
        "primary_execution": {"entry_zone": [4642.53, 4648.53],
                              "entry_price": 4645.53, "stop_loss": 4618.00,
                              "tp1": 4669.48, "tp2": 4700.00},
        "agent_opinions": [
            {"agent": "technical", "direction": "BUY", "confidence": 73,
             "weight": 0.20, "qualified": True,
             "qualification_bar": 65, "reason": "EMA50 above EMA200"},
            {"agent": "multitimeframe", "direction": "BUY", "confidence": 64,
             "weight": 0.15, "qualified": False,
             "qualification_bar": 65, "reason": "PARTIAL alignment 70%"},
            {"agent": "smc", "direction": "BUY", "confidence": 52,
             "weight": 0.20, "qualified": False,
             "qualification_bar": 65, "reason": "continuation step"},
        ],
    }
    t.send_session_plan(plan)
    assert t.captured, "card must be produced"
    text = t.captured[0]
    # the exact string that 400'd the VPS cards must be entity-escaped now
    assert "NOT QUALIFIED (&lt;65%)" in text
    assert "NOT QUALIFIED (<65%)" not in text
    _assert_telegram_html_parseable(text)


def test_r8_boundary_escapes_stray_lt():
    from services.telegram_bot import TelegramService

    t = TelegramService({"telegram": {"bot_token": "t", "chat_id": "c"}})
    # the exact fragment from the VPS 400 description
    out = t._polish_message_text("Multi-Timeframe: BUY (64%) · NOT QUALIFIED (<65%)",
                                 demo=False)
    assert "NOT QUALIFIED (&lt;65%)" in out
    _assert_telegram_html_parseable(out)


def test_r8_boundary_escapes_unsupported_tags_and_orphans():
    from services.telegram_bot import TelegramService

    t = TelegramService({"telegram": {"bot_token": "t", "chat_id": "c"}})
    out = t._polish_message_text(
        "<b>ok</b> · <bot>bad</bot> · </b>orphan</b> <pre>code</pre>",
        demo=False)
    assert "&lt;bot>" in out and "</bot>" not in out
    # exactly the one legitimate </b> survives; both extra ones are escaped
    assert out.count("</b>") == 1
    _assert_telegram_html_parseable(out)


def test_r8_boundary_noop_on_clean_card():
    from services.telegram_bot import TelegramService

    t = TelegramService({"telegram": {"bot_token": "t", "chat_id": "c"}})
    clean = ("🛣️ <b>PATH 2 — TWO-AGENT + MACRO</b>\n"
             "🟢 <b>Bias:</b> BUY\n"
             "⚠️ (ignore &lt;200 pts, +70 safety, cap 400).")
    assert t._polish_message_text(clean, demo=False) == clean
