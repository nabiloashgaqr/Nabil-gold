"""2026-08-19 upgrade tests: MT5 margin/equity circuit breaker."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from services.margin_guard import pre_send_veto  # noqa: E402


class Acct:
    def __init__(self, equity, margin, margin_level, balance=10000.0):
        self.equity = equity
        self.margin = margin
        self.margin_level = margin_level
        self.balance = balance


class TestMarginGuard:
    def test_low_margin_level_veto(self, tmp_path):
        cfg = {"margin_guard": {"peak_file": str(tmp_path / "peak.json")}}
        allow, reason = pre_send_veto(Acct(equity=10000, margin=4000, margin_level=150), cfg)
        assert not allow and "margin level" in reason

    def test_high_exposure_veto(self, tmp_path):
        cfg = {"margin_guard": {"peak_file": str(tmp_path / "peak.json")}}
        allow, _ = pre_send_veto(Acct(equity=10000, margin=6000, margin_level=500), cfg)
        assert not allow

    def test_healthy_pass(self, tmp_path):
        cfg = {"margin_guard": {"peak_file": str(tmp_path / "peak.json")}}
        allow, _ = pre_send_veto(Acct(equity=10000, margin=1000, margin_level=900), cfg)
        assert allow

    def test_equity_drawdown_veto(self, tmp_path):
        peak = tmp_path / "peak.json"
        peak.parent.mkdir(parents=True, exist_ok=True)
        peak.write_text(json.dumps({"peak": 10000.0}))
        cfg = {"margin_guard": {"peak_file": str(peak)}}
        allow, reason = pre_send_veto(Acct(equity=5000, margin=500, margin_level=900), cfg)
        assert not allow and "drawdown" in reason

    def test_zero_account_fails_open(self, tmp_path):
        cfg = {"margin_guard": {"peak_file": str(tmp_path / "peak.json")}}
        allow, _ = pre_send_veto(Acct(equity=0.0, margin=0.0, margin_level=0.0), cfg)
        assert allow  # demo-style zero values must not block the cycle

    def test_peak_is_recorded_and_updated(self, tmp_path):
        peak = tmp_path / "peak.json"
        cfg = {"margin_guard": {"peak_file": str(peak)}}
        pre_send_veto(Acct(equity=8000, margin=500, margin_level=900), cfg)
        assert json.loads(peak.read_text())["peak"] == 8000.0
