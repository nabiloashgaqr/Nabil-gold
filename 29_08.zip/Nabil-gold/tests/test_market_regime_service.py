"""2026-08-19 upgrade tests: D1 market regime service + RANGE gate."""
from __future__ import annotations

import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from services.market_regime import classify_regime, apply_range_gate  # noqa: E402


def _series(n, base=2000.0, trend=0.0, amp=0.0, seed=0):
    import random

    rng = random.Random(seed)
    closes = []
    for i in range(n):
        closes.append(base + trend * i + amp * math.sin(i / 4) + rng.uniform(-0.5, 0.5))
    return closes


class TestClassifyRegime:
    def test_trend_up(self):
        closes = _series(300, trend=1.0, seed=1)
        reg = classify_regime(closes, [c + 5 for c in closes], [c - 5 for c in closes])
        assert reg["regime"] == "TREND_UP"

    def test_trend_down(self):
        closes = _series(300, trend=-1.0, seed=2)
        reg = classify_regime(closes, [c + 5 for c in closes], [c - 5 for c in closes])
        assert reg["regime"] == "TREND_DOWN"

    def test_range(self):
        import random

        rng = random.Random(3)
        closes = []
        price = 2000.0
        for _ in range(300):
            price += rng.uniform(-1.2, 1.2)
            price = 2000.0 + (price - 2000.0) * 0.97  # mean-reverting = range regime
            closes.append(price)
        reg = classify_regime(closes, [c + 4 for c in closes], [c - 4 for c in closes])
        assert reg["regime"] == "RANGE"

    def test_insufficient_data(self):
        reg = classify_regime([2000.0] * 40, [2005.0] * 40, [1995.0] * 40)
        assert reg["regime"] == "INSUFFICIENT_DATA"

    def test_volatility_percentile_bounds(self):
        closes = _series(300, trend=0.4, seed=4)
        reg = classify_regime(closes, [c + 5 for c in closes], [c - 5 for c in closes])
        assert 0.0 <= reg["vol_percentile"] <= 1.0
        assert reg["vol_label"] in {"LOW", "NORMAL", "HIGH"}


class TestRangeGate:
    def _decision(self, path="PATH_2_TWO_AGENT_MACRO", signal="BUY"):
        return {"decision": signal, "confidence": 72, "signal": {"order_type": "BUY_LIMIT"}, "execution_path_id": path}

    def test_two_agent_path_downgraded_in_range(self):
        cfg = {"market_regime": {"strict_range_gate": True}}
        d = apply_range_gate(self._decision("PATH_2_TWO_AGENT_MACRO"), {"regime": "RANGE"}, cfg)
        assert d["decision"] == "WAIT"
        assert d["regime_gate"]["applied"] is True
        assert d["regime_gate"]["original_path"] == "PATH_2_TWO_AGENT_MACRO"

    def test_path1_survives_in_range(self):
        cfg = {"market_regime": {"strict_range_gate": True}}
        d = apply_range_gate(self._decision("PATH_1_THREE_AGENT_CONSENSUS"), {"regime": "RANGE"}, cfg)
        assert d["decision"] == "BUY"

    def test_trend_regime_never_gates(self):
        cfg = {"market_regime": {"strict_range_gate": True}}
        d = apply_range_gate(self._decision("PATH_5_TWO_AGENT_AUCTION"), {"regime": "TREND_UP"}, cfg)
        assert d["decision"] == "BUY"

    def test_gate_disabled_never_gates(self):
        cfg = {"market_regime": {"strict_range_gate": False}}
        d = apply_range_gate(self._decision("PATH_3_TWO_AGENT_GEMINI"), {"regime": "RANGE"}, cfg)
        assert d["decision"] == "BUY"

    def test_wait_decision_untouched(self):
        cfg = {"market_regime": {"strict_range_gate": True}}
        d = apply_range_gate(self._decision("PATH_2_TWO_AGENT_MACRO", signal="WAIT"), {"regime": "RANGE"}, cfg)
        assert d["decision"] == "WAIT"
        assert "regime_gate" not in d
