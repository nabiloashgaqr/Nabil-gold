"""2026-08-19 build 13: operator orders - watch off, oil shadow, cap open,
loss limits removed, hourly status on, PATH 1 on."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from services.dynamic_risk import DynamicRiskManager  # noqa: E402
from services.mt5_executor import Mt5DemoExecutor  # noqa: E402


class TestOrderCapOpen:
    def _env(self, monkeypatch, tmp_path, cap):
        import services.mt5_executor as m5

        from tests import mt5_fake

        state = mt5_fake.FakeState()
        monkeypatch.setitem(sys.modules, "MetaTrader5", mt5_fake.install(state))
        monkeypatch.setattr(m5, "HALT_FILE", str(tmp_path / ".demo_halt"))
        ex = Mt5DemoExecutor({"execution": {"demo": {"max_new_orders_per_day": cap}}}, telegram=None)
        return ex

    def test_zero_cap_means_unlimited(self, monkeypatch, tmp_path):
        ex = self._env(monkeypatch, tmp_path, 0)
        ex._orders_today = 99  # way past any old cap
        ticket = ex.ensure_ticket("TRADE_CAPOPEN", "BUY", "BUY_MARKET", 4300.0, 4290.0, 4320.0, "XAU/USD")
        assert ticket is not None  # placed: cap open
        assert "daily order cap reached" not in ex.last_error

    def test_positive_cap_still_enforced(self, monkeypatch, tmp_path):
        ex = self._env(monkeypatch, tmp_path, 3)
        ex._orders_today = 3
        ticket = ex.ensure_ticket("TRADE_CAPON", "BUY", "BUY_MARKET", 4300.0, 4290.0, 4320.0, "XAU/USD")
        assert ticket is None
        assert ex.last_error == "daily order cap reached"


class TestLossLimitsRemoved:
    class FakeDB:
        def get_consecutive_losses(self):
            return 0

        def get_today_trades(self):
            return [{"symbol": "XAU/USD", "status": "SL_HIT", "final_pnl": -9999.0}]

        def get_recent_trades(self, limit=20):
            return self.get_today_trades()

    def test_points_limit_zero_never_halts(self):
        cfg = {
            "risk_settings": {"account_capital": 10000, "max_daily_loss_percent": 0},
            "dynamic_risk_management": {"daily_loss_limit_points": 0, "halt_after_losses": 3},
        }
        verdict = DynamicRiskManager(cfg).evaluate(self.FakeDB())
        assert verdict["level"] == "NORMAL"
        assert verdict["can_trade"] is True

    def test_consecutive_halt_still_works(self):
        class ThreeLossDB(self.FakeDB):
            def get_consecutive_losses(self):
                return 3

        cfg = {
            "risk_settings": {"account_capital": 10000, "max_daily_loss_percent": 0},
            "dynamic_risk_management": {"daily_loss_limit_points": 0, "halt_after_losses": 3},
        }
        verdict = DynamicRiskManager(cfg).evaluate(ThreeLossDB())
        assert verdict["level"] == "HALT"
        assert verdict["can_trade"] is False

    def test_positive_points_limit_still_works(self):
        cfg = {
            "risk_settings": {"account_capital": 10000, "max_daily_loss_percent": 0},
            "dynamic_risk_management": {"daily_loss_limit_points": 450, "halt_after_losses": 3},
        }
        verdict = DynamicRiskManager(cfg).evaluate(self.FakeDB())
        assert verdict["level"] == "DAILY_HALT"


class TestProductionConfigBuild13:
    def test_all_operator_orders(self):
        prod = json.loads(
            Path(__file__).resolve().parents[1].joinpath("config.json").read_text(encoding="utf-8")
        )
        # watch cards off
        spd = prod.get("session_plan_delivery") or {}
        mo = spd.get("monitoring_only") or {}
        assert mo.get("enabled") is False
        assert mo.get("agent_watch_enabled") is False
        assert (spd.get("armed_map_watch") or {}).get("enabled") is True  # build 14: back ON
        # hourly status back on
        assert (prod.get("notifications") or {}).get("hourly_status") is True
        # WTI live again (build 14)
        wti = [s for s in prod.get("symbols") or [] if s.get("symbol") == "WTI/USD"]
        assert "mode" not in wti[0]
        # cap open
        demo = ((prod.get("execution") or {}).get("demo") or {})
        assert demo.get("max_new_orders_per_day") == 0
        # loss limits removed
        assert (prod.get("dynamic_risk_management") or {}).get("daily_loss_limit_points") == 0
        assert (prod.get("risk_settings") or {}).get("max_daily_loss_percent") == 0
        # PATH 1 back on
        assert ((prod.get("signal_requirements") or {}).get("three_agent_entry") or {}).get("enabled") is True
        # planner floor lowered
        assert (prod.get("session_planner") or {}).get("min_primary_quality_score") == 60
