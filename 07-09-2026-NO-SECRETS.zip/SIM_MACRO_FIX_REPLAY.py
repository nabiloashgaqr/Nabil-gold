# -*- coding: utf-8 -*-
"""SIM_MACRO_FIX_REPLAY.py — هل كان إصلاح تحديث الماكرو (R26.9.16) سيلتقط الصعود؟

Counterfactual replay of ONE day through the REAL gates:

  1. الحقيقة (من الشموع): كل نافذة اندفاع ≥5x ATR على 15m — اللحظات التي
     كان التحديث سيطلق فيها ويعيد سؤال القاضي ببيانات طازجة.
  2. لكل نافذة (بأقرب كتاب وكلاء مسجل في agent_measurements إن وجد):
     تفتح الأبواب الحقيقية تحت ثلاث شهادات ماكرو:
       أ. كما سُجلت يومها (مثلاً BEARISH 66%)   — العالم الذي عشته
       ب. طازجة محايدة (لا ميل ملتزم)           — أثر إعادة السؤال وحدها
       ج. طازجة موالية للصعود 60%               — لو انقلبت شهادة الأسواق
     الأبواب المفحوصة بالكود الحقيقي نفسه:
       • فيتو الماكرو الصلب  (admission_discipline_gates.counter_macro_block)
       • قبول الاتجاه         (thesis_consensus.evaluate_directional_admission)
       • تأكيد الماكرو لـPath 2/6 (pre_arm_ote._macro_confirms)

الحد الصادق للأداة: شهادة ياهو التاريخية لحظة-بلحظة لا تُستعاد — لذلك
تُعرض السيناريوهات الثلاثة وتُسمى الأبواب تحت كل منها؛ ما كانت ستفعله
البيانات الطازجة فعلياً يقع بين (ب) و(ج) غالباً.

Usage:
  python SIM_MACRO_FIX_REPLAY.py XAU/USD
  python SIM_MACRO_FIX_REPLAY.py XAU/USD --dir BUY     # افحص جهة واحدة
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from utils.helpers import load_config                              # noqa: E402
from utils.indicators import calculate_atr                         # noqa: E402
from services.pre_arm_ote import detect_impulse_leg, _macro_confirms  # noqa: E402
from services.admission_discipline_gates import counter_macro_block    # noqa: E402
from services.thesis_consensus import evaluate_directional_admission   # noqa: E402

AGENT_NAMES = ("technical", "multitimeframe", "classical", "smc",
               "price_action", "auction_flow")


def _t(row):
    value = None
    for key in ("time", "ts", "t", "datetime", "date", "timestamp",
                "captured_at", "created_at"):
        if row.get(key):
            value = row[key]; break
    if value is None:
        return None, ""
    if isinstance(value, (int, float)) and value > 1e8:
        seconds = float(value) / 1000.0 if value > 1e12 else float(value)
        try:
            dt = datetime.fromtimestamp(seconds, tz=timezone.utc)
            return dt, dt.strftime("%m-%d %H:%M UTC")
        except (OverflowError, OSError, ValueError):
            return None, str(value)
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt, dt.strftime("%m-%d %H:%M UTC")
    except ValueError:
        return None, str(value)[:16]


def _c(row, *keys):
    for key in keys:
        if key in row and row[key] is not None:
            try:
                return float(row[key])
            except (TypeError, ValueError):
                pass
    return None


def load_candles(symbol: str):
    path = ROOT / "storage" / "shared_market_data.json"
    if not path.exists():
        print("✗ لا يوجد storage/shared_market_data.json — شغّل دورة للرمز ثم نفّذ فوراً")
        sys.exit(1)
    raw = json.loads(path.read_text(encoding="utf-8"))
    meta = raw.get("shared_market_data") or {}
    book_symbol = str(raw.get("symbol") or meta.get("symbol") or "").upper()
    if book_symbol and book_symbol != symbol.upper():
        print("✗ الملف الحالي لرمز آخر: %s — انتظر دورة الرمز ثم نفّذ فوراً" % book_symbol)
        sys.exit(2)
    out = {}
    tfs = raw.get("timeframes") if isinstance(raw.get("timeframes"), dict) else {}
    for tf in ("15m", "5m"):
        node = tfs.get(tf)
        rows = node.get("data") if isinstance(node, dict) else None
        candles, stamps = [], []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            o = _c(row, "open", "o"); h = _c(row, "high", "h")
            l = _c(row, "low", "l"); c = _c(row, "close", "c")
            if None in (h, l) or (o is None and c is None):
                continue
            candles.append({"open": o or c, "high": h, "low": l, "close": c or o})
            stamps.append(_t(row)[1])
        out[tf] = (candles, stamps)
    return out


def load_recorded_books(symbol: str):
    """Best-effort per-cycle agent books from storage/agent_measurements."""
    folder = ROOT / "storage" / "agent_measurements"
    books = []
    if not folder.exists():
        return books
    for path in sorted(folder.glob("agent_system_*.jsonl"))[-2:]:
        try:
            for line in path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(row, dict):
                    continue
                if str(row.get("symbol") or "").upper() != symbol.upper():
                    continue
                dt, _ = _t(row)
                holder = None
                for key in ("agents", "book", "agent_book", "results"):
                    if isinstance(row.get(key), dict):
                        holder = row[key]; break
                if holder is None:
                    holder = row
                details = {}
                for name in AGENT_NAMES:
                    node = holder.get(name)
                    if isinstance(node, dict):
                        details[name] = {
                            "direction": str(node.get("direction")
                                             or node.get("signal") or "WAIT").upper(),
                            "confidence": float(node.get("confidence") or 0.0)}
                macro = holder.get("macro_fundamental") if isinstance(
                    holder.get("macro_fundamental"), dict) else {}
                if details and dt:
                    books.append({"dt": dt, "details": details,
                                  "macro_direction": str(macro.get("direction") or "").upper(),
                                  "macro_conf": float(macro.get("confidence") or 0.0)})
        except OSError:
            continue
    books.sort(key=lambda b: b["dt"])
    return books


def displacement_windows(candles, stamps):
    """Every ≥5x ATR displacement edge on the series (BUY or SELL legs)."""
    windows = []
    armed = False
    for i in range(12, len(candles) + 1):
        atr_series = calculate_atr(candles[:i], 14)
        atr = next((float(x) for x in reversed(atr_series) if x), 0.0)
        if atr <= 0:
            armed = False
            continue
        hit = None
        for cand in ("BUY", "SELL"):
            leg = detect_impulse_leg(list(candles[:i]), atr, {}, cand)
            if leg and float(leg["leg_size"]) / max(atr, 1e-9) >= 5.0:
                hit = (cand, float(leg["leg_size"]) / max(atr, 1e-9))
                break
        if hit and not armed:
            windows.append({"i": i, "stamp": stamps[i - 1], "dir": hit[0],
                            "mult": hit[1]})
            armed = True
        elif not hit:
            armed = False
    return windows


def scenario_doors(side, details, macro_direction, macro_conf, cfg, symbol):
    """Open the three REAL gates under one macro testimony."""
    # inject BOTH shapes: the compact form (what the hard veto reads) and
    # the bias form (what the Path-2/6 confirmer reads: BULLISH_GOLD /
    # BULLISH_EURUSD ...).
    mf = {"direction": macro_direction or "WAIT", "confidence": macro_conf}
    if macro_direction in {"BUY", "SELL"}:
        prefix = "GOLD" if symbol.upper().startswith("XAU") \
            else symbol.upper().replace("/", "")
        mf["macro_direction"] = {"bias": ("BULLISH_" if macro_direction == "BUY"
                                          else "BEARISH_") + prefix,
                                 "confidence": macro_conf}
    all_results = {"symbol": symbol, "macro_fundamental": mf}
    # Path 2 (two agents + macro) reads the macro from the ADMISSION details
    # too — inject the compact form exactly like the live engine does.
    adm_details = dict(details)
    adm_details["symbol"] = symbol
    if macro_direction in {"BUY", "SELL"}:
        adm_details["macro_fundamental"] = {
            "direction": macro_direction, "confidence": macro_conf}
    veto = counter_macro_block(
        {"decision": side, "symbol": symbol, "execution_path_id": "PATH_1"},
        cfg, all_results)
    admission = evaluate_directional_admission(side, adm_details, cfg)
    confirms, source, conf = _macro_confirms(all_results, cfg, symbol, side)
    return {"veto": veto, "admission": admission,
            "confirms": confirms, "conf_source": source, "conf": conf}


def main() -> None:
    symbol = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith("--") \
        else "XAU/USD"
    side_filter = None
    manual_book, manual_macro = None, None   # classical:BUY:72,price_action:BUY:70
    for i, a in enumerate(sys.argv):
        if a == "--dir" and i + 1 < len(sys.argv):
            side_filter = sys.argv[i + 1].upper()
        if a == "--book" and i + 1 < len(sys.argv):
            manual_book = sys.argv[i + 1]
        if a == "--book-macro" and i + 1 < len(sys.argv):
            manual_macro = sys.argv[i + 1]
    cfg = load_config()
    series = load_candles(symbol)
    candles, stamps = series["15m"]
    if len(candles) < 15:
        print("شموع 15m قليلة (%d) — شغّل دورة ثم نفّذ فوراً" % len(candles))
        return
    books = load_recorded_books(symbol)
    if manual_book:
        details_manual = {}
        for part in manual_book.split(","):
            bits = part.strip().split(":")
            if len(bits) == 3 and bits[0] in AGENT_NAMES:
                details_manual[bits[0]] = {"direction": bits[1].upper(),
                                           "confidence": float(bits[2])}
        books = [{"dt": datetime.now(timezone.utc), "details": details_manual,
                  "macro_direction": "", "macro_conf": 0.0,
                  "manual": True}]
        if manual_macro:
            mdir, _, mconf = manual_macro.partition(":")
            books[0]["macro_direction"] = mdir.upper()
            try:
                books[0]["macro_conf"] = float(mconf or 66)
            except ValueError:
                books[0]["macro_conf"] = 66.0
    windows = [w for w in displacement_windows(candles, stamps)
               if side_filter is None or w["dir"] == side_filter]

    print("═" * 70)
    print("فحص إصلاح الماكرو (R26.9.16) — %s | نافذة 15m: %s → %s (%d شمعة)"
          % (symbol, stamps[0] or "?", stamps[-1] or "?", len(candles)))
    print("كتب الوكلاء المسجلة: %d | نوافذ اندفاع ≥5x: %d"
          % (len(books), len(windows)))
    if not windows:
        print("لا نافذة اندفاع داخل النافذة الزمنية للملف — لا شيء كان سيُعاد سؤاله")
        print("═" * 70)
        return
    for w in windows:
        print("─" * 70)
        print("⚡ %.1fx ATR %s عند %s — التحديث كان سيطلق هنا (وكل 10 دقائق بعدها)"
              % (w["mult"], w["dir"], w["stamp"]))
        details, recorded = None, "لا كتاب مسجل قريب"
        best_book = None
        if books:
            # the shared book's stamps are display strings, so per-window
            # wall-clock matching is not possible; use the LAST recorded book
            # of the day and label it honestly.
            best_book = books[-1]
            details = best_book["details"]
            if best_book.get("manual"):
                recorded = ("كتاب ملصق من سجلّك (macro %s %.0f%%)"
                            % (best_book["macro_direction"] or "WAIT",
                               best_book["macro_conf"]))
            elif best_book["macro_direction"]:
                recorded = ("آخر كتاب مسجل لليوم (macro %s %.0f%%)"
                            % (best_book["macro_direction"],
                               best_book["macro_conf"]))
            else:
                recorded = ("لا كتاب مسجل — شهادة الأمس الموثقة في السجل "
                            "(SELL 66%)؛ أدخل --book من سطر BOOK في سجلّك")
        if details is None:
            print("  لا كتاب وكلاء مسجل — أفحص الأبواب بلا كتاب (الفيتو فقط قابل للفحص)")
            details = {}
        scenarios = [
            ("أ) كما سُجلت: %s" % recorded,
             (best_book["macro_direction"] or "WAIT") if books else "SELL",
             best_book["macro_conf"] if books else 66.0),
            ("ب) طازجة محايدة (لا ميل ملتزم)", "WAIT", 0.0),
            ("ج) طازجة موالية %s 60%%" % w["dir"], w["dir"], 60.0),
        ]
        for name, mdir, mconf in scenarios:
            r = scenario_doors(w["dir"], details, mdir, mconf, cfg, symbol)
            adm = r["admission"]
            support = int(adm.get("support_count") or 0)
            path = adm.get("path") or ("مفتوح" if adm.get("allow") else "مغلق")
            veto = "فيتو الماكرو: مشتغل ✗" if r["veto"] else "فيتو الماكرو: منزاح ✓"
            confirm = ("تأكيد Path2/6: ✓ (%s %.0f%%)" % (r["conf_source"], r["conf"])
                       if r["confirms"] else "تأكيد Path2/6: ✗")
            print("  %s" % name)
            print("     %s | قبول الاتجاه: %s (مؤيدون %d، مسار %s)"
                  % (veto, "يفتح ✓" if adm.get("allow") else "لا يفتح", support, path))
            print("     %s" % confirm)
    print("─" * 70)
    print("اقرأ النتيجة: تحت (أ) عاشت يومك؛ تحت (ب) أثر إعادة السؤال وحدها؛")
    print("تحت (ج) لو انقلبت الشهادة الطازجة. الباب الذي يفتح أولاً تحت (ب/ج)")
    print("هو المسار الذي كان سيمسك الحركة قانونياً (سلم/Path2/Path6).")
    print("═" * 70)


if __name__ == "__main__":
    main()
