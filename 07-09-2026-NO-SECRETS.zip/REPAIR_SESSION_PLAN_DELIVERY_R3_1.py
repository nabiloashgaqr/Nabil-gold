# -*- coding: utf-8 -*-
"""Repair session_plan_delivery keys accidentally replaced by R3 merge."""
from __future__ import annotations
import json, shutil
from datetime import datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent; PATH=ROOT/"config.json"
def main():
    c=json.loads(PATH.read_text(encoding="utf-8-sig"))
    d=c.setdefault("session_plan_delivery",{})
    d.update({"enabled":True,"only_when_ready":True,"ready_only_telegram":True})
    d.setdefault("min_change_points",60); d.setdefault("min_update_interval_minutes",25)
    mo=d.setdefault("monitoring_only",{})
    mo.update({"enabled":False,"min_supporting_agents":2,"min_net_confidence":65,
               "max_opposing_agents":1,"require_complete_levels":True,"agent_watch_enabled":False})
    throttle=mo.setdefault("agent_watch_throttle",{})
    defaults={"min_minutes_between_cards":15,"reminder_interval_minutes":60,
              "material_confidence_change":10,"resend_on_supporter_change":True,
              "clear_grace_minutes":20}
    for k,v in defaults.items(): throttle.setdefault(k,v)
    armed=d.setdefault("armed_map_watch",{}); armed["enabled"]=False
    d.setdefault("liquidity_display",{"min_independent_separation_points":100,
                                      "min_independent_separation_rr":0.5})
    d["description"]="Only READY maps are sent to Telegram. WATCH, monitoring-only, agent-watch and armed-map cards are disabled."
    stamp=datetime.now().strftime("%Y%m%d_%H%M%S"); backup=PATH.with_name(f"config.backup_delivery_R3_1_{stamp}.json")
    shutil.copy2(PATH,backup); tmp=PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); tmp.replace(PATH)
    print("OK: session_plan_delivery repaired without replacing unrelated config")
    print(f"BACKUP: {backup.name}")
    print("READY Telegram=true; monitoring/watch/armed-map=false")
if __name__=="__main__": main()
