"""
agents/oil_macro_agent.py — WTI fundamentals (EIA inventories + OPEC + spread).
(2026-08-19 upgrade, phase 2 - new agent)

Fills the oil-fundamentals gap measured in the architecture review: the gold
MacroFundamentalAgent judges gold and configured FX symbols from DXY/yields/Fed ("its verdict is a
GOLD verdict"). This agent is the oil counterpart and is MANDATORY before the
WTI promotion decision (23/08).

Inputs (all free / operator-maintained, all fail-open):
  * EIA weekly petroleum status - storage/oil/eia_weekly.json, appended by the
    operator (or a small helper) after each Wednesday release:
      {"week": "2026-08-14", "crude_change_mb": -3.4,
       "gasoline_change_mb": 1.2, "distillate_change_mb": -0.5,
       "refinery_util_pct": 92.3, "note": ""}
    Seasonal surprise = change - mean(change) for the same ISO week across
    prior years in storage/oil/eia_history.json.
  * OPEC tone - storage/oil/opec_context.json:
      {"tone": "CUT"|"HIKE"|"NEUTRAL", "date": "2026-08-01", "note": ""}
  * Brent-WTI spread (CL=F vs BZ=F via yfinance, cached): widening beyond
    1.5 sigma of its 60-day band = WTI relative weakness.

Scoring (points -> bias/confidence, macro-style):
  crude draw surprise <= -3M  +2.0 | <= -1M +1.0 | build >= +3M -2.0 | >= +1M -1.0
  refinery util >= 92 +0.5 | <= 88 -0.5
  OPEC CUT +2.0 | HIKE -2.0
  spread z > +1.5 -1.0 | z < -1.5 +1.0

Voting policy: NEVER votes (signal="WAIT" always). For a gold run it returns
a neutral card noting the verdict is oil-only — the mirror of macro's gold-only
behaviour.
"""
from __future__ import annotations

import json
import statistics
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .base_agent import BaseAgent
from services.aux_market_data import yf_closes


class OilMacroAgent(BaseAgent):
    name = "oil_macro"

    def __init__(self, config: Dict[str, Any] | None = None, **_kwargs: Any):
        super().__init__(config)
        cfg = self.config.get("oil_macro") or {}
        self.enabled = bool(cfg.get("enabled", True))
        self.eia_path = Path(str(cfg.get("eia_path", "storage/oil/eia_weekly.json")))
        self.history_path = Path(str(cfg.get("eia_history_path", "storage/oil/eia_history.json")))
        self.opec_path = Path(str(cfg.get("opec_path", "storage/oil/opec_context.json")))
        self.spread_lookback = int(cfg.get("spread_lookback_days", 60) or 60)
        self.spread_ttl_hours = float(cfg.get("spread_ttl_hours", 24) or 24)

    # ── local json readers (fail-open) ──────────────────────────────────────
    def _load_json(self, path: Path) -> Any:
        try:
            if path.exists():
                return json.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return None
        return None

    def _seasonal_mean(self, week: str) -> Optional[float]:
        """Mean crude_change for the same ISO week across prior years."""
        hist = self._load_json(self.history_path)
        if not isinstance(hist, list):
            return None
        try:
            iso_week = datetime.fromisoformat(week).isocalendar()[1]
        except ValueError:
            return None
        values = []
        for row in hist:
            if not isinstance(row, dict):
                continue
            rw = row.get("week")
            try:
                if datetime.fromisoformat(str(rw)).isocalendar()[1] == iso_week:
                    v = row.get("crude_change_mb")
                    if isinstance(v, (int, float)):
                        values.append(float(v))
            except (TypeError, ValueError):
                continue
        return float(statistics.mean(values)) if values else None

    def _spread_z(self) -> Optional[float]:
        cl = yf_closes("CL=F", days=max(90, self.spread_lookback + 30),
                       cache_path="storage/aux_cache/CL_F.json", ttl_hours=self.spread_ttl_hours)
        bz = yf_closes("BZ=F", days=max(90, self.spread_lookback + 30),
                       cache_path="storage/aux_cache/BZ_F.json", ttl_hours=self.spread_ttl_hours)
        if not cl or not bz:
            return None
        n = min(len(cl), len(bz))
        if n < 20:
            return None
        spreads = [bz[i] - cl[i] for i in range(-n, 0)]
        recent = spreads[-self.spread_lookback:]
        med = statistics.median(recent)
        std = statistics.pstdev(recent) if len(recent) > 1 else 0.0
        if std <= 0:
            return 0.0
        return (spreads[-1] - med) / std

    def _crack_component(self) -> Tuple[float, List[str]]:
        """Automatic market-structure layer (2026-08-19 build 10, operator
        order: fill the oil macro so it works).

        Gasoline (RB=F) and distillate (HO=F) crack spreads vs WTI (CL=F)
        from yfinance: a widening crack means refining demand/margins
        strength (bullish WTI), narrowing means weakness. Runs WITHOUT the
        operator files, so the agent has a real signal from day one; the
        EIA/OPEC files add the fundamental layer on top. Bounded to +-1.0.
        """
        cfg = self.config.get("oil_macro") or {}
        if not bool(cfg.get("crack_enabled", True)):
            return 0.0, []
        cl = yf_closes("CL=F", days=90, cache_path="storage/aux_cache/CL_F.json", ttl_hours=self.spread_ttl_hours)
        rb = yf_closes("RB=F", days=90, cache_path="storage/aux_cache/RB_F.json", ttl_hours=self.spread_ttl_hours)
        ho = yf_closes("HO=F", days=90, cache_path="storage/aux_cache/HO_F.json", ttl_hours=self.spread_ttl_hours)
        if not cl or not rb or not ho:
            return 0.0, []
        n = min(len(cl), len(rb), len(ho))
        if n < 23:
            return 0.0, []

        def crack_delta(product: List[float], crude: List[float]) -> float:
            spread = [product[i] - crude[i] for i in range(-n, 0)]
            base = max(abs(spread[-23]), 1e-9)
            return (spread[-1] - spread[-23]) / base

        gas_delta = crack_delta(rb, cl)
        dist_delta = crack_delta(ho, cl)
        points = 0.0
        reasons: List[str] = []
        if gas_delta > 0.03:
            points += 0.5
            reasons.append(f"Gasoline crack widening {gas_delta:+.0%} (refining demand strong)")
        elif gas_delta < -0.03:
            points -= 0.5
            reasons.append(f"Gasoline crack narrowing {gas_delta:+.0%} (refining demand weak)")
        if dist_delta > 0.03:
            points += 0.5
            reasons.append(f"Distillate crack widening {dist_delta:+.0%}")
        elif dist_delta < -0.03:
            points -= 0.5
            reasons.append(f"Distillate crack narrowing {dist_delta:+.0%}")
        if points == 0.0:
            reasons.append(f"Crack spreads stable (gas {gas_delta:+.0%}, dist {dist_delta:+.0%})")
        return round(points, 2), reasons

    def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self.enabled:
            return {"agent": self.name, "enabled": False, "signal": "WAIT",
                    "direction": "WAIT", "confidence": 0, "summary": "Oil macro disabled"}

        symbol = str(data.get("symbol") or self.config.get("symbol", "XAU/USD"))
        if "WTI" not in symbol.upper():
            return {
                "agent": self.name, "signal": "WAIT", "direction": "WAIT",
                "confidence": 0, "bias": "NEUTRAL",
                "summary": "Oil macro is the exclusive WTI fundamental voice; this is a non-WTI cycle",
                "reason_codes": ["OIL_ONLY_VERDICT"],
                "missing": [], "source": "eia+opec+spread",
                "timestamp": self.now_iso(),
            }

        score = 0.0
        reasons: List[str] = []
        missing: List[str] = []
        evidence: List[Dict[str, Any]] = []

        eia = self._load_json(self.eia_path)
        if isinstance(eia, dict):
            week = str(eia.get("week") or "")
            change = eia.get("crude_change_mb")
            if week and isinstance(change, (int, float)):
                seasonal = self._seasonal_mean(week)
                surprise = float(change) - (seasonal if seasonal is not None else 0.0)
                evidence.append({"week": week, "crude_change_mb": change,
                                 "seasonal_mean_mb": seasonal, "surprise_mb": round(surprise, 2)})
                if surprise <= -3.0:
                    score += 2.0
                    reasons.append(f"Crude draw surprise {surprise:+.1f}M vs seasonal {seasonal if seasonal is not None else 0:.1f}M (bullish)")
                elif surprise <= -1.0:
                    score += 1.0
                    reasons.append(f"Crude draw {surprise:+.1f}M vs seasonal (mild bullish)")
                elif surprise >= 3.0:
                    score -= 2.0
                    reasons.append(f"Crude build surprise {surprise:+.1f}M vs seasonal (bearish)")
                elif surprise >= 1.0:
                    score -= 1.0
                    reasons.append(f"Crude build {surprise:+.1f}M vs seasonal (mild bearish)")
                else:
                    reasons.append(f"Crude change near seasonal ({surprise:+.1f}M)")
                util = eia.get("refinery_util_pct")
                if isinstance(util, (int, float)):
                    if float(util) >= 92:
                        score += 0.5
                        reasons.append(f"Refinery utilization {util}% strong demand")
                    elif float(util) <= 88:
                        score -= 0.5
                        reasons.append(f"Refinery utilization {util}% weak demand")
            else:
                missing.append("eia")
        else:
            missing.append("eia")

        opec = self._load_json(self.opec_path)
        if isinstance(opec, dict):
            tone = str(opec.get("tone") or "").upper()
            if tone == "CUT":
                score += 2.0
                reasons.append(f"OPEC tone CUT ({opec.get('date', '')})")
            elif tone == "HIKE":
                score -= 2.0
                reasons.append(f"OPEC tone HIKE ({opec.get('date', '')})")
            else:
                reasons.append(f"OPEC tone NEUTRAL ({opec.get('date', '')})")
            evidence.append({"opec": tone, "date": opec.get("date")})
        else:
            missing.append("opec")

        # 2026-08-19 build 10: automatic crack-spread layer (works from day
        # one, no operator files needed).
        crack_points, crack_reasons = self._crack_component()
        if crack_points:
            score += crack_points
            reasons.extend(crack_reasons)
            evidence.append({"crack_spread_points": crack_points})

        z = self._spread_z()
        if z is not None:
            evidence.append({"brent_wti_spread_z": round(z, 2)})
            if z >= 1.5:
                score -= 1.0
                reasons.append(f"Brent-WTI spread widening beyond band (z={z:+.1f}, WTI weakness)")
            elif z <= -1.5:
                score += 1.0
                reasons.append(f"Brent-WTI spread narrowing beyond band (z={z:+.1f}, WTI strength)")
            else:
                reasons.append(f"Brent-WTI spread in band (z={z:+.1f})")
        else:
            missing.append("spread")

        direction = "BUY" if score > 0 else "SELL" if score < 0 else "WAIT"
        side = "BULLISH" if score > 0 else "BEARISH" if score < 0 else "NEUTRAL"
        confidence = min(80, round(40.0 + abs(score) * 8.0)) if direction != "WAIT" else 0

        return {
            "agent": self.name,
            "signal": "WAIT",  # never votes
            "direction": direction,
            "confidence": confidence,
            "bias": f"{side}_OIL",
            "score": round(score, 2),
            "summary": "; ".join(reasons) if reasons else "No oil macro inputs available",
            "reason_codes": [r.split(":")[0][:24] for r in reasons],
            "evidence": evidence,
            "missing": missing,
            "source": "eia_weekly+opec+spread",
            "timestamp": self.now_iso(),
        }
