"""Multi-Instrument Macro / Fundamental Agent.

Provides institutional directional macro context for:
- Gold (XAU/USD)
- WTI Crude Oil (WTI/USD)
- Euro / US Dollar (EUR/USD)
- British Pound / US Dollar (GBP/USD)
- US Dollar / Canadian Dollar (USD/CAD)
- US Dollar / Japanese Yen (USD/JPY)

Respects currency hierarchy (Base vs Quote currency), interest rate differentials,
central bank tones (Fed, ECB, BOE, BOC, BOJ), commodity links (Oil/CAD), and
risk sentiment regimes (Safe-haven JPY/Gold vs Pro-cyclical FX).
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

from agents.base_agent import BaseAgent
from services.symbol_law import is_gold, is_oil
from services.macro_policy import macro_policy
from utils.helpers import load_config, sanitize_prompt_text
from utils.instruments import normalize_symbol


class MacroFundamentalAgent(BaseAgent):
    """Directional macro read across configured asset classes."""

    name = "macro_fundamental"

    def __init__(self, config: Dict[str, Any] | None = None,
                 v1_compat: bool = False,
                 now_fn: Any = None, **_kwargs: Any) -> None:
        # now_fn: replay/testing hook — pins the clock the age-decay reads.
        # Live operation passes nothing and gets the real wall clock.
        super().__init__(config or load_config())
        self.context_path = Path(__file__).resolve().parents[1] / "storage" / "macro_context.json"
        self.symbol = normalize_symbol(self.config.get("symbol") or "XAU/USD")
        # R26.9.13: v2 flip-speed law is the production path; v1_compat keeps
        # the deployed pre-R26.9.13 math available for A/B replay only.
        self.v1_compat = bool(v1_compat)
        self._now_fn = now_fn

    def analyze(self, data: Dict[str, Any] | None = None) -> Dict[str, Any]:
        data = data or {}
        context = self._load_context(data)
        macro_direction = self.macro_direction(context)
        trade_bias = macro_direction.get("trade_bias", "WAIT")
        signal = trade_bias if macro_direction.get("confidence", 0) >= macro_policy(self.config)["entry_confirmation_confidence"] else "WAIT"
        return {
            "agent": self.name,
            "symbol": self.symbol,
            "signal": signal,
            "direction": signal if signal in {"BUY", "SELL"} else "NEUTRAL",
            "confidence": macro_direction.get("confidence", 0),
            "macro_direction": macro_direction,
            "trade_bias": trade_bias,
            "summary": macro_direction.get("summary", "Macro context unavailable"),
            "reason_codes": macro_direction.get("reason_codes", []),
            "evidence": macro_direction.get("evidence", []),
            "invalidations": macro_direction.get("invalidations", []),
            "data_quality": macro_direction.get("data_quality", {}),
            "confidence_breakdown": macro_direction.get("confidence_breakdown", {}),
            "warnings": macro_direction.get("warnings", []),
            "timestamp": self.now_iso(),
        }

    async def analyze_async(self, data: Dict[str, Any] | None = None) -> Dict[str, Any]:
        return self.analyze(data or {})

    def macro_direction(self, context: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """Return directional macro bias for the configured symbol."""
        if getattr(self, "v1_compat", False):
            return self._macro_direction_v1(context)
        return self._macro_direction_v2(context or {})

    # ── R26.9.13 v2: fast, disciplined flip law ──────────────────────────
    #: Researched weights (operator 2026-09-03 «قلب سريع غير متهور»):
    #: gold is driven FIRST by real yields (empirical dominance outside USD),
    #: EUR by the rate differential (2y US-DE is the strongest single driver)
    #: — so the yield leg leads, Fed is deduplicated (it was derived from the
    #: same 10y series and voted twice), the xxx/USD judgement uses the
    #: EUR-EXCLUDED dollar basket + euro crosses, and FX gains an inflation
    #: leg from the TIPS feeds it already fetches. Tables are keyed by
    #: symbol IDENTITY (services/symbol_law.py), never by pair literals.
    V2_W = {
        "gold": {"dxy": 2.0, "yields": 2.4, "fed": 1.2, "infl_hot": 0.8,
                 "infl_cool": 0.7, "growth_weak": 1.3, "growth_strong": -1.0,
                 "risk_off": 1.4, "risk_on": -0.8, "oil_up": 0.5, "oil_down": -0.3},
        "fx_quote": {"dxy_ex": 1.8, "yields": 1.6, "fed": 0.8, "peer": 1.6,
                     "diff": 0.6, "infl_hot": -0.7, "infl_cool": 0.6,
                     "risk_off": -1.2, "risk_on": 1.0},
        "jpy": {"dxy": 2.0, "yields": 2.2, "fed": 0.9, "boj_hawk": -2.2,
                "boj_dove": 2.0, "diff": 0.5, "risk_off": -2.0, "risk_on": 1.2},
        "cad": {"dxy": 2.0, "yields": 1.8, "fed": 0.9, "boc": 1.6,
                "oil_up": -1.8, "oil_down": 1.8, "diff": 0.5, "risk_off": 1.1},
        "oil": {"dxy": 2.0, "growth_strong": 2.2, "growth_weak": -2.2, "geo": 1.8},
    }
    #: peer central-bank voice by BASE currency code (identity, not literals)
    _PEER_BY_BASE = {"EUR": "ecb_tone", "GBP": "boe_tone",
                     "CAD": "boc_tone", "JPY": "boj_tone"}
    #: Dominant legs whose fast/slow disagreement halves their vote.
    _DOMINANT = ("dxy", "dxy_ex", "yields")

    def _now_utc(self):
        """Wall clock for the flip guard — honours the replay pin."""
        from datetime import datetime as _dt, timezone as _tz
        try:
            nv = self._now_fn()
            if isinstance(nv, _dt):
                return nv if nv.tzinfo else nv.replace(tzinfo=_tz.utc)
        except Exception:  # noqa: BLE001
            pass
        return _dt.now(_tz.utc)

    def _flip_guard_load(self) -> Dict[str, Any]:
        """Last committed flip (memory + best-effort sidecar). The sidecar
        bridges the guard across live cycles; historical stamps simply
        expire by age, so a replay can never mis-guard a live call."""
        if hasattr(self, "_flip_guard"):
            return self._flip_guard or {}
        if not bool((self.config.get("macro_stall") or {}).get("flip_guard_persist",
                                                              macro_policy(self.config)["flip_guard_persist"])):
            self._flip_guard = {}
            return self._flip_guard
        out: Dict[str, Any] = {}
        try:
            sidecar = Path(__file__).resolve().parents[1] / "storage" / "macro" / "flip_guard.json"
            if sidecar.exists():
                raw = json.loads(sidecar.read_text(encoding="utf-8")) or {}
                # per-symbol map: gold's guard never speaks for the euro
                entry = raw.get(self.symbol) if isinstance(raw, dict) else None
                if isinstance(entry, dict):
                    out = {"bias": entry.get("bias"), "conf": entry.get("conf"),
                           "at": entry.get("at"), "symbol": self.symbol}
        except Exception:  # noqa: BLE001
            out = {}
        self._flip_guard = out
        return out

    def _flip_guard_save(self, state: Dict[str, Any]) -> None:
        self._flip_guard = state
        if not bool((self.config.get("macro_stall") or {}).get("flip_guard_persist",
                                                              macro_policy(self.config)["flip_guard_persist"])):
            return
        try:
            sidecar = Path(__file__).resolve().parents[1] / "storage" / "macro" / "flip_guard.json"
            sidecar.parent.mkdir(parents=True, exist_ok=True)
            raw = {}
            if sidecar.exists():
                raw = json.loads(sidecar.read_text(encoding="utf-8")) or {}
            if not isinstance(raw, dict):
                raw = {}
            raw[self.symbol] = {"bias": state.get("bias"), "conf": state.get("conf"),
                                "at": state.get("at")}
            tmp = sidecar.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(raw), encoding="utf-8")
            tmp.replace(sidecar)
        except Exception:  # noqa: BLE001 — read-only filesystems never break the verdict
            pass

    def _macro_direction_v2(self, context: Dict[str, Any]) -> Dict[str, Any]:
        if not context:
            return self._neutral("macro: inputs not connected yet", missing=["macro_context"])
        sym_key = self.symbol
        alt_key = self.symbol.replace("/", "")
        sym_context = {}
        if isinstance(context.get(sym_key), dict):
            sym_context = dict(context.get(sym_key))
        elif isinstance(context.get(alt_key), dict):
            sym_context = dict(context.get(alt_key))
        merged = {**context, **sym_context}

        # identity via symbol_law — no pair literals (R25.12 ratchet)
        gold = is_gold(self.symbol)
        oil_sym = is_oil(self.symbol)
        base, _, quote = str(self.symbol).partition("/")
        usd_base = (not gold and not oil_sym and base == "USD")
        # xxx/USD quote pairs (euro-bloc style) — NOT USD-base pairs, whose
        # quote is also "USD" but whose dollar direction is the mirror.
        quote_fx = (not gold and not oil_sym and quote == "USD" and base != "USD")
        jpy_pair = (usd_base and quote == "JPY")   # USD/JPY: USD-base, JPY quote
        cad_pair = (usd_base and quote == "CAD")   # USD/CAD: USD-base, CAD quote
        w = (self.V2_W["gold"] if gold else
             self.V2_W["oil"] if oil_sym else
             self.V2_W["jpy"] if jpy_pair else
             self.V2_W["cad"] if cad_pair else
             self.V2_W["fx_quote"])

        def norm(key_group):
            for k in key_group:
                v = merged.get(k)
                if v and str(v).lower() not in {"unknown", "none", ""}:
                    return str(v).upper()
            return ""

        dxy_all = norm(("dxy_trend", "dollar_trend", "usd_trend"))
        dxy_ex = norm(("dxy_ex_eur_trend",))
        dxy_slow = norm(("dxy_trend_slow",))
        yields = norm(("us10y_trend", "real_yields_trend", "yields_trend"))
        yields_slow = norm(("us10y_trend_slow", "real_yields_trend_slow"))
        fed = norm(("fed_tone", "fed_policy", "rate_expectations"))
        inflation = norm(("inflation_surprise", "cpi_surprise", "pce_surprise"))
        growth = norm(("growth_surprise", "recession_risk", "labor_market"))
        risk = norm(("risk_sentiment", "risk_regime", "geopolitical_risk"))
        oil = norm(("oil_trend", "commodity_inflation"))
        vix = merged.get("vix_level")

        UP = {"UP", "RISING", "STRONG", "BULLISH"}
        DOWN = {"DOWN", "FALLING", "WEAK", "BEARISH"}
        HAWK = {"HAWKISH", "HIGHER_FOR_LONGER", "RATE_HIKES", "TIGHTENING", "HIKE"}
        DOVE = {"DOVISH", "CUTS", "RATE_CUTS", "EASING", "YCC"}
        OFF = {"RISK_OFF", "HIGH", "STRESS", "GEOPOLITICAL", "SAFE_HAVEN"}
        ON = {"RISK_ON", "LOW", "CALM"}

        score = 0.0
        max_abs = 0.0
        drivers, evidence, codes = [], [], []
        breakdown = {k: 0.0 for k in ("dxy", "yields", "central_banks",
                                      "inflation_growth", "risk", "commodity",
                                      "events", "divergence")}

        def _fade(val) -> float:
            """R26.9.14 stall fade: 0..1 (1 = driver fully alive)."""
            try:
                return max(0.0, min(1.0, float(val)))
            except (TypeError, ValueError):
                return 1.0
        dxy_fade = _fade(merged.get("dxy_fade"))
        yields_fade = _fade(merged.get("yields_fade"))

        def halve_if_disagree(leg_key, fast, slow):
            """0.5x when the two eyes disagree on a dominant leg."""
            if leg_key in self._DOMINANT and slow and fast and fast != slow \
                    and "FLAT" not in (fast, slow) and "UNKNOWN" not in (fast, slow):
                return 0.5
            return 1.0

        def add(component, points, label, code, value=None):
            nonlocal score, max_abs
            score += points
            max_abs += abs(points) if points != 0 else 0.3
            breakdown[component] = round(breakdown.get(component, 0.0) + points, 2)
            drivers.append(label)
            codes.append(code)
            evidence.append({"name": component, "value": value if value is not None else label,
                             "bias": "BULLISH" if points > 0 else "BEARISH" if points < 0 else "NEUTRAL"})

        # ── dollar leg ──
        if quote_fx:
            leg = dxy_ex or dxy_all
            f = halve_if_disagree("dxy_ex", leg, dxy_slow)
            if leg in UP:
                add("dxy", -w["dxy_ex"] * f * dxy_fade, f"Stronger USD (ex-EUR basket) pressures {self.symbol}",
                    "MACRO_DXY_BEARISH", leg)
            elif leg in DOWN:
                add("dxy", w["dxy_ex"] * f * dxy_fade, f"Weaker USD (ex-EUR basket) supports {self.symbol}",
                    "MACRO_DXY_BULLISH", leg)
        else:
            f = halve_if_disagree("dxy", dxy_all, dxy_slow)
            if oil_sym:
                if dxy_all in UP:
                    add("dxy", -w["dxy"] * f * dxy_fade, "Stronger USD pressures dollar-denominated oil",
                        "MACRO_DXY_BEARISH_WTI", dxy_all)
                elif dxy_all in DOWN:
                    add("dxy", w["dxy"] * f * dxy_fade, "Weaker USD supports oil", "MACRO_DXY_BULLISH_WTI", dxy_all)
            else:
                sgn = 1 if usd_base else -1
                if dxy_all in UP:
                    add("dxy", sgn * w["dxy"] * f * dxy_fade, f"Stronger USD lifts {self.symbol}" if sgn > 0
                        else f"Stronger USD pressures {self.symbol}",
                        "MACRO_DXY_BEARISH_GOLD" if gold else "MACRO_DXY", dxy_all)
                elif dxy_all in DOWN:
                    add("dxy", -sgn * w["dxy"] * f * dxy_fade, f"Weaker USD pressures {self.symbol}" if sgn > 0
                        else f"Weaker USD supports {self.symbol}",
                        "MACRO_DXY_BULLISH_GOLD" if gold else "MACRO_DXY", dxy_all)

        # ── yields leg (rate differential doctrine) ──
        ysgn = 1 if usd_base else -1
        if not oil_sym:
            f = halve_if_disagree("yields", yields, yields_slow)
            if yields in UP:
                add("yields", ysgn * w["yields"] * f * yields_fade,
                    f"Widening US yield advantage {'lifts' if usd_base else 'pressures'} {self.symbol}",
                    "MACRO_YIELDS", yields)
            elif yields in DOWN:
                add("yields", -ysgn * w["yields"] * f * yields_fade,
                    f"Narrowing US yield advantage {'pressures' if usd_base else 'supports'} {self.symbol}",
                    "MACRO_YIELDS", yields)

        # ── central banks: Fed (deduplicated) + peer + relative differential ──
        peer_field = self._PEER_BY_BASE.get(base if not usd_base else quote)
        peer = norm((peer_field,)) if peer_field else ""
        fsign = 1 if usd_base else -1
        if not oil_sym:
            # R26.9.14: the Fed tone is DERIVED from the same 10y series —
            # it inherits that driver's stall fade (no echo outliving its source).
            if fed in HAWK:
                add("central_banks", fsign * w["fed"] * yields_fade, "Hawkish Fed tone",
                    "MACRO_FED_HAWKISH", fed)
            elif fed in DOVE:
                add("central_banks", -fsign * w["fed"] * yields_fade, "Dovish Fed tone",
                    "MACRO_FED_DOVISH", fed)
        if peer:
            peer_sign = 1 if quote_fx else -1
            if peer in HAWK:
                add("central_banks", peer_sign * w.get("peer", 1.6),
                    f"Hawkish peer central bank ({peer_field})", "MACRO_PEER_HAWKISH", peer)
            elif peer in DOVE:
                add("central_banks", -peer_sign * w.get("peer", 1.6),
                    f"Dovish peer central bank ({peer_field})", "MACRO_PEER_DOVISH", peer)
        # relative differential: both same tone -> the GAP still matters
        if fed and peer and fed == peer and "diff" in w and yields:
            dsign = 1 if yields in UP else -1 if yields in DOWN else 0
            if dsign:
                add("central_banks", w["diff"] * dsign * (1 if usd_base else -1),
                    "Both central banks same tone — rate gap decides",
                    "MACRO_CB_DIFFERENTIAL", yields)

        # ── inflation / growth ──
        if inflation in {"HOT", "ABOVE", "HIGHER", "UPSIDE"}:
            pts = w.get("infl_hot", 0.8)
        elif inflation in {"COOL", "BELOW", "LOWER", "DOWNSIDE"}:
            pts = w.get("infl_cool", 0.7)
        else:
            pts = 0.0
        if pts:
            # gold: hedge demand; FX: USD-positive impulse
            sgn = 1 if gold else -1
            add("inflation_growth", sgn * pts,
                "Hot inflation expectations" if pts > 0 else "Cooling inflation expectations",
                "MACRO_INFLATION", inflation)
        if gold or oil_sym:
            if growth in {"WEAK", "RECESSION", "RISK", "SOFTENING", "COOLING"}:
                add("inflation_growth", w.get("growth_weak", 1.3), "Growth weakness",
                    "MACRO_GROWTH_WEAK", growth)
            elif growth in {"STRONG", "HOT", "RESILIENT"}:
                add("inflation_growth", w.get("growth_strong", -1.0), "Strong growth",
                    "MACRO_GROWTH_STRONG", growth)

        # ── risk ──
        if gold:
            if risk in OFF:
                add("risk", w["risk_off"], "Risk-off / safe-haven supports gold", "MACRO_RISK_OFF", risk)
            elif risk in ON:
                add("risk", w["risk_on"], "Risk-on reduces safe-haven demand", "MACRO_RISK_ON", risk)
        elif jpy_pair:
            if risk in OFF:
                add("risk", w["risk_off"], "Risk-off JPY repatriation pressures the pair", "MACRO_RISK_OFF", risk)
            elif risk in ON:
                add("risk", w["risk_on"], "Risk-on carry appetite supports the pair", "MACRO_RISK_ON", risk)
        elif quote_fx:
            if risk in OFF:
                add("risk", w["risk_off"], "Risk-off safe-haven USD flows", "MACRO_RISK_OFF", risk)
            elif risk in ON:
                add("risk", w["risk_on"], "Risk-on pro-cyclical flows", "MACRO_RISK_ON", risk)
        elif cad_pair:
            if risk in OFF:
                add("risk", w["risk_off"], "Risk-off USD flows support the pair", "MACRO_RISK_OFF", risk)
        elif oil_sym and risk in {"GEOPOLITICAL", "HIGH", "STRESS"}:
            add("risk", w["geo"], "Geopolitical / supply risk supports oil", "MACRO_GEOPOLITICAL", risk)

        # ── VIX ladder ──
        if isinstance(vix, (int, float)):
            if gold:
                if vix >= 30: add("risk", 1.5, f"VIX {vix:.0f} extreme fear", "MACRO_VIX_EXTREME", vix)
                elif vix >= 25: add("risk", 1.0, f"VIX {vix:.0f} elevated", "MACRO_VIX_ELEVATED", vix)
                elif vix <= 13: add("risk", -0.5, f"VIX {vix:.0f} complacency", "MACRO_VIX_COMPLACENCY", vix)
            elif jpy_pair and vix >= 28:
                add("risk", -1.8, f"VIX {vix:.0f} fear triggers JPY repatriation", "MACRO_VIX_HIGH", vix)

        # ── oil ──
        if "oil_up" in w:
            if cad_pair:
                if oil in UP: add("commodity", w["oil_up"], "Higher oil strengthens CAD", "MACRO_OIL", oil)
                elif oil in DOWN: add("commodity", w["oil_down"], "Softer oil weakens CAD", "MACRO_OIL", oil)
            elif gold:
                if oil in UP: add("commodity", w["oil_up"], "Higher oil lifts inflation-hedge demand", "MACRO_OIL", oil)
                elif oil in DOWN: add("commodity", w["oil_down"], "Softer oil reduces hedge demand", "MACRO_OIL", oil)

        # ── R26.9.14 مفتاح التباعد: الرمز يتحرك والمحركان المهيمنان راكدان ──
        # small confirm key (±1.0), never a standalone voice: it only fires
        # when the symbol itself broke away from its 24h extreme while BOTH
        # dominant drivers (dollar basket + yields) sit stalled.
        if bool(merged.get("divergence_key")):
            _dirn = str(merged.get("divergence_direction") or "").lower()
            if _dirn == "up":
                add("divergence", 1.0, "Symbol rallies while both dominant drivers stall",
                    "MACRO_DIVERGENCE_KEY", "up")
            elif _dirn == "down":
                add("divergence", -1.0, "Symbol sells off while both dominant drivers stall",
                    "MACRO_DIVERGENCE_KEY", "down")

        # ── events (R26.9.1 doctrine unchanged) ──
        events_score = 0.0
        for event in self._load_economic_events():
            points = self._economic_event_points(event)
            if points == 0:
                continue
            if abs(events_score + points) > 2.0:
                points = (2.0 - abs(events_score)) * (1 if points > 0 else -1)
                if points == 0:
                    continue
            events_score += points
            add("events", points, self._economic_event_label(event, points),
                "MACRO_EVENT_SURPRISE", event.get("event"))

        raw_confidence = self._confidence(score, max_abs, len(evidence))
        # A narrow evidence set may describe a lean, but cannot confirm or veto.
        if len(evidence) < macro_policy(self.config)["min_evidence_inputs"]:
            raw_confidence = min(raw_confidence, 54)
            codes.append("MACRO_INSUFFICIENT_EVIDENCE")
        # dominant-eye conflict: the honest vote is an abstain — cap below
        # BOTH the confirmation floor (55) and the veto floor (60).
        if bool(merged.get("dominant_disagreement")):
            raw_confidence = min(raw_confidence, 54)

        # age decay: a stale consensus must not hold a hard veto forever
        age_min, decay = self._age_decay(merged.get("generated_at"))
        confidence = int(round(max(0.0, min(90.0, raw_confidence * decay))))

        sym_tag = self.symbol.replace("/", "")
        if score >= 1.5 and confidence >= 45:
            bias = "BULLISH_GOLD" if gold else f"BULLISH_{sym_tag}"
            trade_bias = "BUY"
        elif score <= -1.5 and confidence >= 45:
            bias = "BEARISH_GOLD" if gold else f"BEARISH_{sym_tag}"
            trade_bias = "SELL"
        else:
            bias, trade_bias = "NEUTRAL", "WAIT"
            codes.append("MACRO_NEUTRAL_MIXED")

        # ── R26.9.14 حارس الانقلاب: a committed flip (>=70) is protected
        # for flip_guard_hours (default 4) against an opposite verdict on WEAK evidence;
        # strong evidence (|score| >= 3.5) breaks through immediately.
        _guard_h = float((self.config.get("macro_stall") or {}).get(
            "flip_guard_hours", macro_policy(self.config)["flip_guard_hours"])
                         if isinstance(self.config, dict) else 4.0)
        _g = self._flip_guard_load()
        _g_at = None
        try:
            from datetime import datetime as _dt
            _g_at = _dt.fromisoformat(str(_g.get("at") or "").replace("Z", "+00:00"))
        except (TypeError, ValueError):
            _g_at = None
        _g_age = ((self._now_utc() - _g_at).total_seconds() / 3600.0
                  if _g_at and _g_at.tzinfo else None)
        if (_guard_h > 0 and bias in {"BULLISH_GOLD", f"BULLISH_{sym_tag}",
                                      "BEARISH_GOLD", f"BEARISH_{sym_tag}"}
                and _g.get("bias") and _g.get("bias") != bias
                and float(_g.get("conf") or 0) >= 70
                and (_g_age is None or _g_age <= _guard_h)
                and abs(score) < 3.5):
            bias, trade_bias = "NEUTRAL", "WAIT"
            confidence = min(confidence, 54)
            codes.append("MACRO_FLIP_GUARD")
        if bias not in {"NEUTRAL"} and confidence >= 70:
            self._flip_guard_save({"bias": bias, "conf": confidence,
                                   "at": self._now_utc().isoformat(),
                                   "symbol": self.symbol})

        out = {
            "symbol": self.symbol, "bias": bias, "trade_bias": trade_bias,
            "confidence": confidence, "raw_confidence": raw_confidence,
            "age_minutes": age_min, "decay_factor": decay, "schema": "v2",
            "score": round(score, 2), "drivers": drivers[:8],
            "summary": self._summary(self.symbol, bias, confidence, drivers),
            "reason_codes": self._dedupe(codes)[:12], "evidence": evidence[:10],
            "invalidations": self._invalidations(bias, self.symbol),
            "data_quality": {
                "source": self._source_label(merged),
                "freshness": str(merged.get("freshness") or "OPERATOR_SUPPLIED").upper(),
                "missing_fields": self._missing_fields(merged),
                "inputs": len(evidence),
            },
            "confidence_breakdown": {k: round(v, 2) for k, v in breakdown.items()},
            "flip_armed": bool(merged.get("macro_flip_armed")),
            "warnings": [],
        }
        return out

    def _age_decay(self, generated_at: Any) -> tuple:
        """(age_minutes, decay). Fresh <30m=1.0; 30-60m=0.95; 1-2h=0.90;
        2-4h=0.80; 4-6h=0.60; older=0.50 — nothing, not even a 90% read,
        keeps a hard veto (>=60) past 6h without fresh data. Unreadable
        stamp decays as 2h (honest middle)."""
        from datetime import datetime as _dt, timezone as _tz
        try:
            ts = _dt.fromisoformat(str(generated_at).replace("Z", "+00:00"))
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=_tz.utc)
            _now = _dt.now(_tz.utc)
            try:
                _now = self._now_fn() or _now  # replay pin (tz-aware expected)
            except Exception:  # noqa: BLE001
                pass
            if not isinstance(_now, _dt):
                _now = _dt.now(_tz.utc)
            age = (_now - ts).total_seconds() / 60.0
        except Exception:  # noqa: BLE001
            return 120.0, 0.90
        if age < 0:
            tolerance = macro_policy(self.config)["future_timestamp_tolerance_minutes"]
            if abs(age) > tolerance:
                return round(age, 1), 0.5
            age = 0.0
        decay = (1.0 if age < 30 else 0.95 if age < 60 else
                 0.90 if age < 120 else 0.80 if age < 240 else
                 0.60 if age < 360 else 0.50)
        return round(age, 1), decay

    def _macro_direction_v1(self, context: Dict[str, Any] | None) -> Dict[str, Any]:
        context = context or {}
        if not context:
            return self._neutral(f"{self.symbol} Macro: inputs not connected yet", missing=["macro_context"])

        # Check for symbol-specific nested context (e.g. context["EUR/USD"] or context["EURUSD"])
        sym_key = self.symbol
        alt_key = self.symbol.replace("/", "")
        sym_context = {}
        if isinstance(context.get(sym_key), dict):
            sym_context = dict(context.get(sym_key))
        elif isinstance(context.get(alt_key), dict):
            sym_context = dict(context.get(alt_key))

        merged_context = {**context, **sym_context}

        score = 0.0
        max_abs = 0.0
        drivers: List[str] = []
        evidence: List[Dict[str, Any]] = []
        codes: List[str] = []
        warnings: List[str] = []
        breakdown = {
            "dxy": 0.0,
            "yields": 0.0,
            "central_banks": 0.0,
            "inflation_growth": 0.0,
            "risk": 0.0,
            "commodity": 0.0,
            "events": 0.0,
        }

        def add(component: str, points: float, label: str, code: str, value: Any = None) -> None:
            nonlocal score, max_abs
            score += points
            max_abs += abs(points) if points != 0 else 0.3
            breakdown[component] = round(breakdown.get(component, 0.0) + points, 2)
            drivers.append(label)
            codes.append(code)
            evidence.append({
                "name": component,
                "value": value if value is not None else label,
                "bias": "BULLISH" if points > 0 else "BEARISH" if points < 0 else "NEUTRAL",
            })

        dxy = self._norm(merged_context.get("dxy_trend") or merged_context.get("dollar_trend") or merged_context.get("usd_trend"))
        yields = self._norm(merged_context.get("us10y_trend") or merged_context.get("real_yields_trend") or merged_context.get("yields_trend"))
        fed = self._norm(merged_context.get("fed_tone") or merged_context.get("fed_policy") or merged_context.get("rate_expectations"))
        inflation = self._norm(merged_context.get("inflation_surprise") or merged_context.get("cpi_surprise") or merged_context.get("pce_surprise"))
        growth = self._norm(merged_context.get("growth_surprise") or merged_context.get("recession_risk") or merged_context.get("labor_market"))
        risk = self._norm(merged_context.get("risk_sentiment") or merged_context.get("risk_regime") or merged_context.get("geopolitical_risk"))
        oil = self._norm(merged_context.get("oil_trend") or merged_context.get("commodity_inflation"))
        vix = merged_context.get("vix_level")

        # ── SYMBOL-SPECIFIC MACRO RULES ───────────────────────────────────────
        if self.symbol == "XAU/USD":
            # Gold
            if dxy in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("dxy", -2.2, "Stronger USD pressures gold", "MACRO_DXY_BEARISH_GOLD", dxy)
            elif dxy in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("dxy", 2.2, "Weaker USD supports gold", "MACRO_DXY_BULLISH_GOLD", dxy)

            if yields in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("yields", -2.0, "Rising US yields pressure non-yielding gold", "MACRO_YIELDS_BEARISH_GOLD", yields)
            elif yields in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("yields", 2.0, "Falling US yields support gold", "MACRO_YIELDS_BULLISH_GOLD", yields)

            if fed in {"HAWKISH", "HIGHER_FOR_LONGER", "RATE_HIKES", "TIGHTENING"}:
                add("central_banks", -1.8, "Hawkish Fed tone is bearish for gold", "MACRO_FED_HAWKISH", fed)
            elif fed in {"DOVISH", "CUTS", "RATE_CUTS", "EASING"}:
                add("central_banks", 1.8, "Dovish Fed / cuts expectations support gold", "MACRO_FED_DOVISH", fed)

            if inflation in {"HOT", "ABOVE", "HIGHER", "UPSIDE"}:
                add("inflation_growth", 0.8, "Hot inflation supports hedging demand", "MACRO_INFLATION_HOT", inflation)
            elif inflation in {"COOL", "BELOW", "LOWER", "DOWNSIDE"}:
                add("inflation_growth", 0.7, "Cooling inflation lowers rate expectations", "MACRO_INFLATION_COOLING", inflation)

            if growth in {"WEAK", "RECESSION", "RISK", "SOFTENING", "COOLING"}:
                add("inflation_growth", 1.3, "Growth weakness supports defensive gold demand", "MACRO_GROWTH_WEAK", growth)
            elif growth in {"STRONG", "HOT", "RESILIENT"}:
                add("inflation_growth", -0.9, "Strong growth reduces defensive gold demand", "MACRO_GROWTH_STRONG", growth)

            if risk in {"RISK_OFF", "HIGH", "STRESS", "GEOPOLITICAL", "SAFE_HAVEN"}:
                add("risk", 2.0, "Risk-off / safe-haven supports gold", "MACRO_RISK_OFF_BULLISH_GOLD", risk)
            elif risk in {"RISK_ON", "LOW", "CALM"}:
                add("risk", -0.9, "Risk-on sentiment reduces safe-haven demand", "MACRO_RISK_ON_BEARISH_GOLD", risk)

            if oil in {"UP", "RISING", "STRONG"}:
                add("commodity", 0.5, "Higher oil lifts inflation-hedge demand", "MACRO_OIL_UP_SUPPORTS_GOLD", oil)
            elif oil in {"DOWN", "FALLING", "WEAK"}:
                add("commodity", -0.3, "Softer oil reduces inflation-hedge demand", "MACRO_OIL_DOWN_SOFT_GOLD", oil)

            if isinstance(vix, (int, float)):
                if vix >= 30: add("risk", 1.5, f"VIX at {vix:.0f} — extreme fear supports gold", "MACRO_VIX_EXTREME_FEAR", vix)
                elif vix >= 25: add("risk", 1.0, f"VIX at {vix:.0f} — elevated fear supports gold", "MACRO_VIX_ELEVATED", vix)
                elif vix <= 13: add("risk", -0.5, f"VIX at {vix:.0f} — complacency", "MACRO_VIX_COMPLACENCY", vix)

        elif self.symbol in {"EUR/USD", "GBP/USD"}:
            # European Majors (USD is quote currency)
            peer = "EUR" if "EUR" in self.symbol else "GBP"
            cb_peer = "ECB" if "EUR" in self.symbol else "BOE"
            cb_peer_tone = self._norm(merged_context.get(f"{cb_peer.lower()}_tone") or merged_context.get(f"{cb_peer.lower()}_policy"))

            if dxy in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("dxy", -2.2, f"Stronger USD pressures {self.symbol}", f"MACRO_DXY_BEARISH_{peer}", dxy)
            elif dxy in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("dxy", 2.2, f"Weaker USD supports {self.symbol}", f"MACRO_DXY_BULLISH_{peer}", dxy)

            if yields in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("yields", -2.0, f"Widening US yield advantage pressures {peer}", f"MACRO_YIELDS_BEARISH_{peer}", yields)
            elif yields in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("yields", 2.0, f"Narrowing US yield advantage supports {peer}", f"MACRO_YIELDS_BULLISH_{peer}", yields)

            if fed in {"HAWKISH", "HIGHER_FOR_LONGER", "RATE_HIKES"}:
                add("central_banks", -1.8, f"Hawkish Fed pressures {self.symbol}", "MACRO_FED_HAWKISH", fed)
            elif fed in {"DOVISH", "CUTS", "RATE_CUTS", "EASING"}:
                add("central_banks", 1.8, f"Dovish Fed supports {self.symbol}", "MACRO_FED_DOVISH", fed)

            if cb_peer_tone in {"HAWKISH", "TIGHTENING", "RATE_HIKES"}:
                add("central_banks", 1.8, f"Hawkish {cb_peer} lifts {peer}", f"MACRO_{cb_peer}_HAWKISH", cb_peer_tone)
            elif cb_peer_tone in {"DOVISH", "EASING", "RATE_CUTS"}:
                add("central_banks", -1.8, f"Dovish {cb_peer} weakens {peer}", f"MACRO_{cb_peer}_DOVISH", cb_peer_tone)

            if risk in {"RISK_OFF", "HIGH", "STRESS"}:
                add("risk", -1.4, f"Risk-off safe-haven USD flows pressure {self.symbol}", f"MACRO_RISK_OFF_BEARISH_{peer}", risk)
            elif risk in {"RISK_ON", "LOW", "CALM"}:
                add("risk", 1.2, f"Risk-on sentiment supports pro-cyclical {peer}", f"MACRO_RISK_ON_BULLISH_{peer}", risk)

        elif self.symbol == "USD/CAD":
            # USD/CAD (USD is base currency, CAD is petrodollar)
            boc = self._norm(merged_context.get("boc_tone") or merged_context.get("boc_policy"))
            if dxy in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("dxy", 2.2, "Stronger USD lifts USD/CAD", "MACRO_DXY_BULLISH_USDCAD", dxy)
            elif dxy in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("dxy", -2.2, "Weaker USD pressures USD/CAD", "MACRO_DXY_BEARISH_USDCAD", dxy)

            if yields in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("yields", 2.0, "Rising US yields support USD/CAD", "MACRO_YIELDS_BULLISH_USDCAD", yields)
            elif yields in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("yields", -2.0, "Falling US yields pressure USD/CAD", "MACRO_YIELDS_BEARISH_USDCAD", yields)

            if fed in {"HAWKISH", "HIGHER_FOR_LONGER"}:
                add("central_banks", 1.8, "Hawkish Fed supports USD/CAD", "MACRO_FED_HAWKISH", fed)
            elif fed in {"DOVISH", "CUTS"}:
                add("central_banks", -1.8, "Dovish Fed pressures USD/CAD", "MACRO_FED_DOVISH", fed)

            if boc in {"HAWKISH", "TIGHTENING"}:
                add("central_banks", -1.8, "Hawkish BOC strengthens CAD (pressures USD/CAD)", "MACRO_BOC_HAWKISH", boc)
            elif boc in {"DOVISH", "EASING"}:
                add("central_banks", 1.8, "Dovish BOC weakens CAD (lifts USD/CAD)", "MACRO_BOC_DOVISH", boc)

            # Crude Oil Petrodollar Link: Oil UP -> CAD UP -> USD/CAD DOWN
            if oil in {"UP", "RISING", "STRONG"}:
                add("commodity", -2.0, "Higher oil strengthens petrodollar CAD (pressures USD/CAD)", "MACRO_OIL_UP_CAD_STRONG", oil)
            elif oil in {"DOWN", "FALLING", "WEAK"}:
                add("commodity", 2.0, "Softer oil weakens CAD (supports USD/CAD)", "MACRO_OIL_DOWN_CAD_WEAK", oil)

            if risk in {"RISK_OFF", "HIGH", "STRESS"}:
                add("risk", 1.3, "Risk-off safe-haven USD flows support USD/CAD", "MACRO_RISK_OFF_BULLISH_USDCAD", risk)

        elif self.symbol == "USD/JPY":
            # USD/JPY (USD is base currency, JPY is safe haven)
            boj = self._norm(merged_context.get("boj_tone") or merged_context.get("boj_policy"))
            if dxy in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("dxy", 2.2, "Stronger USD lifts USD/JPY", "MACRO_DXY_BULLISH_USDJPY", dxy)
            elif dxy in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("dxy", -2.2, "Weaker USD pressures USD/JPY", "MACRO_DXY_BEARISH_USDJPY", dxy)

            # US-Japan Yield Spread is the primary driver
            if yields in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("yields", 2.5, "Widening US-Japan yield differential lifts USD/JPY carry", "MACRO_YIELDS_BULLISH_USDJPY", yields)
            elif yields in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("yields", -2.5, "Narrowing US-Japan yield differential pressures USD/JPY", "MACRO_YIELDS_BEARISH_USDJPY", yields)

            if fed in {"HAWKISH", "HIGHER_FOR_LONGER"}:
                add("central_banks", 1.8, "Hawkish Fed widens policy gap with BOJ (supports USD/JPY)", "MACRO_FED_HAWKISH", fed)
            elif fed in {"DOVISH", "CUTS"}:
                add("central_banks", -1.8, "Dovish Fed narrows policy gap (pressures USD/JPY)", "MACRO_FED_DOVISH", fed)

            if boj in {"HAWKISH", "HIKE", "RATE_HIKES", "TIGHTENING"}:
                add("central_banks", -2.5, "Hawkish BOJ / rate hike strengthens JPY (pressures USD/JPY)", "MACRO_BOJ_HAWKISH", boj)
            elif boj in {"DOVISH", "YCC", "EASING"}:
                add("central_banks", 2.0, "Dovish BOJ keeps JPY weak (supports USD/JPY)", "MACRO_BOJ_DOVISH", boj)

            # JPY Safe Haven: Risk-Off -> JPY Inflows -> USD/JPY DOWN
            if risk in {"RISK_OFF", "HIGH", "STRESS", "GEOPOLITICAL"}:
                add("risk", -2.2, "Risk-off safe-haven flows into JPY pressure USD/JPY", "MACRO_RISK_OFF_BEARISH_USDJPY", risk)
            elif risk in {"RISK_ON", "LOW", "CALM"}:
                add("risk", 1.5, "Risk-on carry appetite supports USD/JPY", "MACRO_RISK_ON_BULLISH_USDJPY", risk)

            if isinstance(vix, (int, float)):
                if vix >= 28: add("risk", -1.8, f"VIX at {vix:.0f} — fear triggers JPY repatriation (pressures USD/JPY)", "MACRO_VIX_HIGH_JPY_STRENGTH", vix)

        elif self.symbol == "WTI/USD":
            # WTI Crude Oil
            if dxy in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("dxy", -2.0, "Stronger USD pressures dollar-denominated oil", "MACRO_DXY_BEARISH_WTI", dxy)
            elif dxy in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("dxy", 2.0, "Weaker USD supports oil", "MACRO_DXY_BULLISH_WTI", dxy)

            if growth in {"STRONG", "HOT", "RESILIENT"}:
                add("inflation_growth", 2.2, "Strong global growth supports oil demand", "MACRO_GROWTH_BULLISH_WTI", growth)
            elif growth in {"WEAK", "RECESSION", "RISK"}:
                add("inflation_growth", -2.2, "Growth slowdown weakens oil demand", "MACRO_GROWTH_BEARISH_WTI", growth)

            if risk in {"GEOPOLITICAL", "HIGH", "STRESS"}:
                add("risk", 1.8, "Geopolitical tensions / supply risk support oil", "MACRO_GEOPOLITICAL_BULLISH_WTI", risk)

        # Economic releases
        events_score = 0.0
        for event in self._load_economic_events():
            points = self._economic_event_points(event)
            if points == 0: continue
            if abs(events_score + points) > 2.0:
                points = (2.0 - abs(events_score)) * (1 if points > 0 else -1)
                if points == 0: continue
            events_score += points
            add("events", points, self._economic_event_label(event, points), "MACRO_EVENT_SURPRISE", event.get("event"))

        confidence = self._confidence(score, max_abs, len(evidence))
        sym_tag = self.symbol.replace("/", "")
        if score >= 1.5 and confidence >= 45:
            bias = f"BULLISH_{sym_tag}" if self.symbol != "XAU/USD" else "BULLISH_GOLD"
            trade_bias = "BUY"
        elif score <= -1.5 and confidence >= 45:
            bias = f"BEARISH_{sym_tag}" if self.symbol != "XAU/USD" else "BEARISH_GOLD"
            trade_bias = "SELL"
        else:
            bias = "NEUTRAL"
            trade_bias = "WAIT"
            codes.append("MACRO_NEUTRAL_MIXED")

        summary = self._summary(self.symbol, bias, confidence, drivers)
        data_quality = {
            "source": self._source_label(merged_context),
            "freshness": str(merged_context.get("freshness") or merged_context.get("data_quality") or "OPERATOR_SUPPLIED").upper(),
            "missing_fields": self._missing_fields(merged_context),
            "inputs": len(evidence),
        }
        return {
            "symbol": self.symbol,
            "bias": bias,
            "trade_bias": trade_bias,
            "confidence": confidence,
            "score": round(score, 2),
            "drivers": drivers[:8],
            "summary": summary,
            "reason_codes": self._dedupe(codes)[:12],
            "evidence": evidence[:10],
            "invalidations": self._invalidations(bias, self.symbol),
            "data_quality": data_quality,
            "confidence_breakdown": {k: round(v, 2) for k, v in breakdown.items()},
            "warnings": warnings[:4],
        }

    def _load_economic_events(self) -> List[Dict[str, Any]]:
        cfg = self.config.get("macro_economic_events") or {}
        if not bool(cfg.get("enabled", False)):
            return []
        try:
            path = Path(str(cfg.get("path", "storage/macro/economic_events.json")))
            if not path.exists():
                return []
            raw = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                return []
            max_age_days = float(cfg.get("max_age_days", 7) or 7)
            cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
            events = []
            for row in raw:
                if not isinstance(row, dict): continue
                try:
                    when = datetime.fromisoformat(str(row.get("date") or "").replace("Z", "+00:00"))
                    if when.tzinfo is None: when = when.replace(tzinfo=timezone.utc)
                except (TypeError, ValueError): continue
                if when < cutoff: continue
                events.append(row)
            return events
        except Exception:
            return []

    def _usd_event_exposure(self) -> float | None:
        """R26.9.1: the signed answer to the ONE question that governs
        economic-event surprises — "does dollar strength LIFT or PRESS this
        symbol?"

        +1.0  USD-base pairs (dollar strength lifts them)
        -1.0  xxx/USD quote pairs (dollar strength presses them)
        -0.75 oil (pressed through the demand channel, at a dampened scale)
        None  gold (its own literal doctrine, see _economic_event_points)
              or an unreadable symbol (scores no event points — safe).
        Identity via services/symbol_law.py — no hand-written symbols."""
        sym = str(self.symbol or "").upper()
        if is_gold(sym):
            return None
        if is_oil(sym):
            return -0.75
        if "/" not in sym:
            return None
        base, _, quote = sym.partition("/")
        base, quote = base.strip(), quote.strip()
        if quote == "USD" and base not in ("", "USD"):
            return -1.0
        if base == "USD" and quote not in ("", "USD"):
            return 1.0
        return None

    def _economic_event_points(self, event: Dict[str, Any]) -> float:
        """R26.9.1 (2026-09-01): the surprise map rebuilt around the single
        explicit question above. The old multiplier produced inverted
        reads — a cold CPI scored BEARISH on EUR/USD and BULLISH on
        USD/JPY, a strong NFP scored BULLISH on EUR/USD, and a hawkish
        FOMC scored BULLISH oil (+1.8) against this agent's own DXY branch.
        Now: a USD-positive impulse (hot CPI / strong jobs / hawkish Fed)
        presses xxx/USD pairs, lifts USD/xxx pairs, and presses oil at the
        dampened 0.75 demand scale; oil NFP follows the agent's own growth
        doctrine (+0.6 strong labor / -0.8 weak). GOLD is not dollar-
        mapped: its event doctrine (inflation hedge vs policy hopes) keeps
        every literal historical value — not one number moved."""
        try:
            forecast = float(event.get("forecast"))
            actual = float(event.get("actual"))
        except (TypeError, ValueError):
            return 0.0
        surprise = actual - forecast
        name = str(event.get("event") or "").upper()
        norm = "".join(ch for ch in name if ch.isalnum())

        # ── GOLD: its own literal doctrine, byte-for-byte unchanged ──
        if is_gold(self.symbol):
            if any(k in norm for k in ("CPI", "PCE", "PPI", "INFLATION")):
                return 0.8 if surprise > 0 else 0.7 if surprise < 0 else 0.0
            if any(k in norm for k in ("NFP", "NONFARM", "PAYROLL", "UNEMPLOYMENT", "JOBS")):
                return -0.9 if surprise > 0 else 1.3 if surprise < 0 else 0.0
            if any(k in norm for k in ("FOMC", "FED", "RATE", "INTEREST")):
                return -1.8 if surprise > 0 else 1.8 if surprise < 0 else 0.0
            return 0.0

        usd = self._usd_event_exposure()
        if usd is None:  # an unreadable symbol never scores events
            return 0.0

        if any(k in norm for k in ("CPI", "PCE", "PPI", "INFLATION")):
            # USD impulse: hot inflation +0.8 / cooling -0.7
            impulse = 0.8 if surprise > 0 else -0.7 if surprise < 0 else 0.0
            return impulse * usd
        if any(k in norm for k in ("NFP", "NONFARM", "PAYROLL", "UNEMPLOYMENT", "JOBS")):
            # OIL follows the agent's growth doctrine, not the dollar map:
            # strong labor = fuel demand (+0.6), weak labor = -0.8.
            if is_oil(self.symbol):
                return 0.6 if surprise > 0 else -0.8 if surprise < 0 else 0.0
            impulse = 1.2 if surprise > 0 else -1.2 if surprise < 0 else 0.0
            return impulse * usd
        if any(k in norm for k in ("FOMC", "FED", "RATE", "INTEREST")):
            # Hawkish surprise +1.8 / dovish -1.8 as the USD impulse
            impulse = 1.8 if surprise > 0 else -1.8 if surprise < 0 else 0.0
            return impulse * usd
        return 0.0

    def _economic_event_label(self, event: Dict[str, Any], points: float) -> str:
        name = str(event.get("event") or "EVENT")
        direction = "supportive" if points > 0 else "pressure"
        return f"{name}: actual {event.get('actual')} vs forecast {event.get('forecast')} ({self.symbol} {direction})"

    def _load_context(self, data: Dict[str, Any]) -> Dict[str, Any]:
        for source in (data.get("macro_context"), self.config.get("macro_context")):
            if isinstance(source, dict) and source:
                return dict(source)
        env_context = os.environ.get("MACRO_CONTEXT_JSON")
        if env_context:
            try:
                parsed = json.loads(env_context)
                if isinstance(parsed, dict): return parsed
            except json.JSONDecodeError as exc:
                self.logger.warning("Invalid MACRO_CONTEXT_JSON: %s", exc)
        if self.context_path.exists():
            try:
                with self.context_path.open("r", encoding="utf-8") as file:
                    parsed = json.load(file)
                if isinstance(parsed, dict): return parsed
            except json.JSONDecodeError as exc:
                self.logger.warning("Invalid macro context file: %s", exc)
        return {}

    def _neutral(self, summary: str, missing: List[str] | None = None) -> Dict[str, Any]:
        return {
            "symbol": self.symbol,
            "bias": "NEUTRAL",
            "trade_bias": "WAIT",
            "confidence": 0,
            "score": 0.0,
            "drivers": [],
            "summary": summary,
            "reason_codes": ["MACRO_DATA_UNAVAILABLE"],
            "evidence": [],
            "invalidations": [],
            "data_quality": {"source": "none", "freshness": "UNKNOWN", "missing_fields": missing or ["macro_context"], "inputs": 0},
            "confidence_breakdown": {"dxy": 0, "yields": 0, "central_banks": 0, "inflation_growth": 0, "risk": 0, "commodity": 0},
            "warnings": [summary],
        }

    @staticmethod
    def _norm(value: Any) -> str:
        return str(value or "").strip().upper().replace(" ", "_").replace("-", "_")

    @staticmethod
    def _dedupe(items: List[str]) -> List[str]:
        seen: List[str] = []
        for item in items:
            if item and item not in seen:
                seen.append(item)
        return seen

    @staticmethod
    def _confidence(score: float, max_abs: float, inputs: int) -> int:
        if inputs <= 0: return 0
        if max_abs <= 0: return int(round(max(0.0, min(30.0, 10 + inputs * 4))))
        conviction = min(abs(score) / max_abs, 1.0)
        breadth = min(inputs / 5.0, 1.0)
        return int(round(max(0.0, min(90.0, 35 + conviction * 35 + breadth * 20))))

    @staticmethod
    def _invalidations(bias: str, symbol: str) -> List[str]:
        if "BULLISH" in bias:
            return [f"USD / Yield trend reverses against {symbol}", "Macro risk regime shifts abruptly"]
        if "BEARISH" in bias:
            return [f"USD / Yield trend reverses in favor of {symbol}", "Macro risk regime shifts abruptly"]
        return ["Wait for clearer macro alignment"]

    @staticmethod
    def _missing_fields(context: Dict[str, Any]) -> List[str]:
        groups = {
            "dxy_trend": ("dxy_trend", "dollar_trend", "usd_trend"),
            "yields_trend": ("us10y_trend", "real_yields_trend", "yields_trend"),
            "fed_tone": ("fed_tone", "fed_policy", "rate_expectations"),
            "risk_sentiment": ("risk_sentiment", "risk_regime", "geopolitical_risk"),
            "oil_trend": ("oil_trend", "commodity_inflation"),
            "inflation_surprise": ("inflation_surprise", "cpi_surprise", "pce_surprise"),
        }
        missing = []
        for label, keys in groups.items():
            val = None
            for k in keys:
                v = context.get(k)
                if v and str(v).lower() not in {"unknown", "none", ""}:
                    val = v
                    break
            if not val:
                missing.append(label)
        return missing

    @staticmethod
    def _source_label(context: Dict[str, Any]) -> str:
        source = context.get("source") or context.get("provider") or "operator_macro_context"
        return sanitize_prompt_text(str(source), max_len=80)

    @staticmethod
    def _summary(symbol: str, bias: str, confidence: int, drivers: List[str]) -> str:
        if not drivers:
            return f"{symbol} Macro: context unavailable"
        lead = "; ".join(drivers[:3])
        if len(drivers) > 3:
            lead += f"; +{len(drivers) - 3} more"
        bias_label = bias.replace("_", " ").title()
        if bias == "NEUTRAL" and confidence > 0:
            return f"{symbol} Macro: Neutral ({confidence}%) — {lead}"
        return f"{symbol} Macro: {bias_label} ({confidence}%) — {lead}"
