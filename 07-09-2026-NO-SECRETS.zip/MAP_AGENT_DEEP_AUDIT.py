"""Read-only live audit of map construction, agent opinions, weights and gates."""
from __future__ import annotations

import asyncio
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env", override=False)
except Exception:
    pass
os.environ["DATA_SOURCE_PRIMARY"] = "mt5"
os.environ["EXECUTION_MODE"] = "mt5_demo"
os.environ["TRADES_TABLE"] = "trades_demo"

from agents.classical_agent import ClassicalAgent
from agents.daily_bias_agent import DailyBiasAgent
from agents.decision_agent import DecisionAgent
from agents.macro_fundamental_agent import MacroFundamentalAgent
from agents.multitimeframe_agent import MultiTimeframeAgent
from agents.news_risk_agent import NewsRiskAgent
from agents.price_action_agent import PriceActionAgent
from agents.smc_agent import SMCAgent
from agents.technical_agent import TechnicalAgent
from agents.trading_session_agent import TradingSessionAgent
from scripts.run_analysis import run_agent
from services.database import DatabaseService
from services.market_data import MarketDataService
from services.market_snapshot import build_market_snapshot
from services.session_planner import SessionPlannerService
from utils.helpers import get_agent_weights, load_config
from utils.instruments import config_for_instrument


def direction_of(result):
    return str((result or {}).get("direction") or (result or {}).get("signal") or "WAIT").upper()


def confidence_of(result):
    try:
        return float((result or {}).get("confidence") or 0)
    except Exception:
        return 0.0


async def main():
    base = load_config()
    config = config_for_instrument(base, {"symbol": "XAU/USD"})
    db = DatabaseService(config)
    market = MarketDataService(config)
    data = market.get_gold_data()
    if not data:
        raise RuntimeError("No MT5 market data returned")
    data["verified_snapshot"] = build_market_snapshot(data, config)
    persisted_macro = db.get_macro_context()
    macro_input = {**data, "macro_context": persisted_macro} if persisted_macro else data
    macro = run_agent("macro_fundamental", MacroFundamentalAgent(config), macro_input)
    news_cfg = {**config, "macro_context": persisted_macro} if persisted_macro else config
    news = NewsRiskAgent(news_cfg).check()
    results = {
        "technical": run_agent("technical", TechnicalAgent(config), data),
        "classical": run_agent("classical", ClassicalAgent(config), data),
        "smc": run_agent("smc", SMCAgent(config), data),
        "price_action": run_agent("price_action", PriceActionAgent(config), data),
        "multitimeframe": run_agent("multitimeframe", MultiTimeframeAgent(config), data),
        "macro_fundamental": macro,
        "daily_bias": run_agent("daily_bias", DailyBiasAgent(config), data),
        "news": news,
        "session": TradingSessionAgent(config).check(),
        "current_price": data.get("current_price"),
        "symbol": "XAU/USD",
        "verified_snapshot": data.get("verified_snapshot"),
    }
    plan = SessionPlannerService(config).build_plan(results, persist=False)
    results["session_plan"] = plan
    try:
        decision = await DecisionAgent(config).decide_async(results)
    except Exception as exc:
        decision = {"decision": "ERROR", "error": repr(exc)}

    weights = get_agent_weights(config)
    sig = config.get("signal_requirements") or {}
    planner_cfg = config.get("session_planner") or {}
    signal_bar = float(sig.get("agent_min_confidence", 67) or 67)
    planner_bar = float(planner_cfg.get("agent_alignment_min_confidence", 68) or 68)
    opinions = []
    for name in ("technical", "classical", "smc", "price_action", "multitimeframe"):
        result = results.get(name) or {}
        d = direction_of(result)
        c = confidence_of(result)
        opinions.append({
            "agent": name,
            "weight": float(weights.get(name, 0)),
            "direction": d,
            "confidence": c,
            "weighted_confidence": round(float(weights.get(name, 0)) * c, 3),
            "qualifies_signal_bar": c >= signal_bar and d in {"BUY", "SELL"},
            "qualifies_planner_bar": c >= planner_bar and d in {"BUY", "SELL"},
            "summary": result.get("summary"),
            "signals": (result.get("signals") or [])[:4],
        })

    candidates = list(((results.get("smc") or {}).get("setup_candidates") or []))[:8]
    candidate_view = []
    for c in candidates:
        candidate_view.append({k: c.get(k) for k in (
            "id", "direction", "setup_type", "setup_state", "entry_price",
            "quality_score", "trigger_score", "thesis_dominance_score",
            "return_probability_score", "target_liquidity", "stop_loss",
        )})

    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "market": {
            "price": data.get("current_price"), "source": data.get("source"),
            "integrity": data.get("source_integrity"),
        },
        "canonical_weights": weights,
        "weight_sum": round(sum(float(v) for v in weights.values()), 6),
        "thresholds": {
            "signal_agent_min_confidence": signal_bar,
            "planner_agent_alignment_min_confidence": planner_bar,
            "signal_min_agents": sig.get("min_agents_agree"),
            "signal_min_consensus": sig.get("min_consensus_confidence"),
            "planner_min_supporting_agents_ready": planner_cfg.get("min_supporting_agents_for_ready"),
            "planner_final_execution_min_agents": sig.get("min_agents_agree"),
            "planner_min_dominance": planner_cfg.get("min_primary_dominance"),
            "planner_min_return_probability": planner_cfg.get("min_return_probability"),
            "planner_min_quality": planner_cfg.get("min_primary_quality_score"),
        },
        "configuration_mismatches": [
            "Planner qualifies agents at 68 while final signal/execution gate qualifies them at 67.",
            "Planner can publish READY with 2 supporters, but final execution normally needs 3 or 2 plus macro/Gemini.",
            "only_when_ready=true hides WATCH/NOT_READY maps from Telegram.",
        ],
        "agent_opinions": opinions,
        "macro": macro,
        "daily_bias": results.get("daily_bias"),
        "news": news,
        "decision": decision,
        "session_plan": plan,
        "smc_candidates": candidate_view,
    }
    outdir = ROOT / "diagnostics"
    outdir.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    path = outdir / f"map_agent_deep_audit_{stamp}.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")

    print("REPORT:", path)
    print("PRICE:", report["market"]["price"], "SOURCE:", report["market"]["source"])
    print("WEIGHTS:", weights, "SUM=", report["weight_sum"])
    print("AGENTS:")
    for x in opinions:
        print(f"  {x['agent']:<16} {x['direction']:<4} {x['confidence']:>5.1f}% "
              f"w={x['weight']:.2f} signal67={x['qualifies_signal_bar']} planner68={x['qualifies_planner_bar']}")
    print("DECISION:", decision.get("decision"), decision.get("confidence"), decision.get("rejection_reason"))
    print("PLAN:", plan.get("plan_status"), "ready=", plan.get("plan_ready"),
          "bias=", plan.get("session_bias"), "reason=", plan.get("plan_reason"))
    print("PRIMARY:", json.dumps(plan.get("primary_poi") or {}, ensure_ascii=False, default=str)[:1500])


if __name__ == "__main__":
    asyncio.run(main())
