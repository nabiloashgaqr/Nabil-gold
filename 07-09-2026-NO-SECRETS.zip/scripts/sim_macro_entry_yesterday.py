#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SIM_MACRO_ENTRY_YESTERDAY — R26.9.14 (operator order 2026-09-03
«طبق مع سكربت يفحص ويقيس هل كنا سندخلها البارحة»).

Rebuilds yesterday (or any day) hour by hour with THREE macro judges:

  v1       = deployed pre-R26.9.13 law
  v2-pure  = R26.9.13 two-eye law (no stall law)
  v2-full  = R26.9.13 + R26.9.14 (third 8h eye + driver-stall fade +
             divergence key + flip guard)

…and answers, per judge: would it have CONFIRMED a BUY (bias BULLISH and
confidence >= confirm bar, default 55)? At which hour and which price?

If a decision_audit.json is available (--audit), every audit row of that
day for the symbol is printed alongside — so a technical book that WAS
refused can be matched with the macro verdict it would have received:
entry = technical book existed + macro confirms at that hour.

Pure Python + yfinance, read-only for the repo (writes one JSON report).
Prices are the FEED's prices (e.g. GC=F for gold); --spot-offset prints a
spot ESTIMATE alongside (feed − offset), clearly labelled as estimate.

Usage:
    python scripts/sim_macro_entry_yesterday.py --symbol XAU/USD
    python scripts/sim_macro_entry_yesterday.py --symbol XAU/USD \
        --day 2026-09-02 --audit storage/decision_audit.json --spot-offset 40
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def _fetch(symbol: str, days: int):
    import yfinance as yf
    frame = yf.Ticker(symbol).history(period=f"{days + 6}d", interval="1h",
                                      auto_adjust=False)
    pts = []
    if frame is not None and len(frame):
        for ts, row in zip(frame.index, frame.itertuples()):
            dt = ts.to_pydatetime()
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            close = float(getattr(row, "Close", 0.0) or 0.0)
            if close > 0:
                pts.append((dt.astimezone(timezone.utc), close))
    return sorted(pts)


def main() -> int:
    ap = argparse.ArgumentParser(description="هل كنا سندخلها البارحة؟ A/B/C judge")
    ap.add_argument("--symbol", default="XAU/USD")
    ap.add_argument("--day", default=None, help="YYYY-MM-DD (default: yesterday UTC)")
    ap.add_argument("--confirm-bar", type=float, default=55.0)
    ap.add_argument("--audit", default=str(ROOT / "storage" / "decision_audit.json"))
    ap.add_argument("--spot-offset", type=float, default=0.0,
                    help="feed price minus this = spot ESTIMATE (e.g. 40 for GC=F)")
    ap.add_argument("--out", default=str(ROOT / "storage" / "macro" / "entry_check_last.json"))
    args = ap.parse_args()

    symbol = args.symbol.upper()
    now = datetime.now(timezone.utc)
    day = args.day or (now - timedelta(days=1)).strftime("%Y-%m-%d")
    day_start = datetime.fromisoformat(f"{day}T00:00:00+00:00")

    from services.macro_data_provider import MacroDataProvider
    from services.macro_context_core import build_context as core_build
    from agents.macro_fundamental_agent import MacroFundamentalAgent
    from scripts.sim_macro_flip_replay import _slice

    price_alias = {"XAU/USD": "GC=F", "WTI/USD": "CL=F"}.get(symbol)
    if price_alias is None:
        base, quote = symbol.split("/", 1)
        price_alias = f"{base}{quote}=X"
    series = {}
    for cand in list(dict.fromkeys([*MacroDataProvider.YFINANCE_SYMBOLS, price_alias,
                                    "DX-Y.NYB"])):
        try:
            pts = _fetch(cand, 8)
            if pts:
                series[cand] = pts
        except Exception as exc:  # noqa: BLE001
            print(f"  [warn] {cand}: {exc}", file=sys.stderr)
    if price_alias not in series:
        print("no price series — abort")
        return 3
    series["symbol_price"] = series[price_alias]

    # three judges; replay keeps the flip guard IN MEMORY only (never touches
    # the live sidecar), and the day replay starts clean.
    judges = {}
    for name, v1, stall in (("v1", True, False), ("v2-pure", False, False),
                            ("v2-full", False, True)):
        ag = MacroFundamentalAgent({"symbol": symbol}, v1_compat=v1)
        ag._flip_guard = {}
        ag._flip_guard_save = lambda state, _ag=ag: setattr(_ag, "_flip_guard", state)
        judges[name] = (ag, stall)

    stamps = sorted(dt for dt, _ in series[price_alias]
                    if day_start <= dt < day_start + timedelta(days=1))
    if len(stamps) < 6:
        print(f"only {len(stamps)} bars for {day} — abort")
        return 4

    rows = []
    for t in stamps:
        lo = t - timedelta(days=5)
        sm = {k: v for k, v in ((s, _slice(p, lo, t)) for s, p in series.items()) if v}
        price = sm[price_alias][-1][1]
        row = {"t": t.isoformat(), "price": round(price, 5)}
        for name, (ag, stall) in judges.items():
            ag._now_fn = (lambda tt: (lambda: tt))(t)
            try:
                ctx = core_build(sm, as_of=t, v1_compat=(name == "v1"),
                                 stall_enabled=stall)
                out = ag.macro_direction(ctx)
                row[name] = {"bias": out["bias"], "conf": out["confidence"],
                             "armed": bool(out.get("flip_armed"))}
            except Exception as exc:  # noqa: BLE001
                row[name] = {"bias": "ERROR", "conf": 0, "armed": False, "err": str(exc)}
        rows.append(row)

    def _fmt_price(p):
        est = f" (سبوت≈{p - args.spot_offset:.0f}$)" if args.spot_offset else ""
        return f"{p:.5g}{est}"

    # first BUY confirmation per judge
    confirms = {}
    for name in judges:
        first = next((r for r in rows
                      if r[name]["bias"].startswith("BULLISH")
                      and r[name]["conf"] >= args.confirm_bar), None)
        confirms[name] = first

    # optional: cross-check with the server's decision audit
    audit_rows = []
    audit_path = Path(args.audit)
    if audit_path.exists():
        try:
            for a in json.loads(audit_path.read_text(encoding="utf-8")) or []:
                if not isinstance(a, dict):
                    continue
                if str(a.get("symbol", "")).upper() != symbol:
                    continue
                ts = str(a.get("created_at") or "")
                if not ts.startswith(day):
                    continue
                audit_rows.append(a)
        except Exception as exc:  # noqa: BLE001
            print(f"  [warn] audit unreadable: {exc}", file=sys.stderr)

    print(f"\nهل كنا سندخلها؟  {symbol}  يوم {day}  (شريطة التأكيد ≥{args.confirm_bar:.0f}%)")
    print("─" * 100)
    print(f"{'الساعة':<7}{'السعر':<22}", end="")
    for name in judges:
        print(f"{name:<20}", end="")
    print()
    for r in rows:
        cells = []
        for name in judges:
            j = r[name]
            mark = ""
            if j["bias"].startswith("BULLISH") and j["conf"] >= args.confirm_bar:
                mark = " <<تأكيد شراء"
            cells.append(f"{j['bias'].split('_')[0][:7]:<9}{j['conf']:>3}%{mark:<12}")
        print(f"{r['t'][11:16]:<7}{_fmt_price(r['price']):<22}", end="")
        for c in cells:
            print(f"{c:<20}", end="")
        print()

    print("─" * 100)
    verdict = {"symbol": symbol, "day": day, "confirm_bar": args.confirm_bar,
               "rows": rows, "first_buy_confirm": {}, "audit_rows": len(audit_rows)}
    for name, first in confirms.items():
        if first:
            print(f"  {name:<8}: أول تأكيد شراء {first['t'][11:16]} على "
                  f"{_fmt_price(first['price'])} بثقة {first[name]['conf']}%")
            verdict["first_buy_confirm"][name] = {"t": first["t"],
                                                  "price": first["price"],
                                                  "conf": first[name]["conf"]}
        else:
            print(f"  {name:<8}: لم يؤكد شراءً طوال اليوم")
            verdict["first_buy_confirm"][name] = None

    if audit_rows:
        print(f"\n  سجل القرارات لهذا الرمز في ذلك اليوم: {len(audit_rows)} صف — "
              "الأعمدة أعلاه هي حكم الماكرو الذي كانت ستحصل عليه كل صفحة")
        for a in audit_rows[:12]:
            print(f"    {str(a.get('created_at'))[11:16]}  {a.get('outcome'):<8} "
                  f"{a.get('stage')}: {str(a.get('reason'))[:70]}")

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(verdict, indent=2, ensure_ascii=False),
                        encoding="utf-8")
    print(f"\n  التقرير: {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
