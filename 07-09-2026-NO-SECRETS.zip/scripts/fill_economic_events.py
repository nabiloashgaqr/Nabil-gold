"""
scripts/fill_economic_events.py — build & maintain the macro economic-events
file (2026-08-19 build 11, operator order).

The macro agent's surprise layer reads storage/macro/economic_events.json:
{event, forecast, actual, date}. The ForexFactory weekly XML gives REAL
forecast/previous but NOT the released actual, so this tool:

  --sync   fetch the FF calendar (live), build/update entries for the
           TIER-1 gold events (CPI/PCE/PPI, NFP/payrolls/unemployment,
           FOMC/rate/Powell) with real forecast+previous and actual=null,
           preserving any actual the operator already typed.
           -> the macro stays honest: no actual, no surprise, no score.
  --add    quick manual fill right after a release:
             --add --event "CPI YoY" --forecast 3.1 --actual 3.3 --date 2026-08-12
           -> actual is written into the entry (created if missing).

Agent contract (macro_fundamental_agent._economic_event_points):
  CPI/PCE/PPI hot +0.8 / cool +0.7 · NFP strong -0.9 / weak +1.3 ·
  FOMC hike -1.8 / cut +1.8 · cap +-2.0 total.

Usage:
  python scripts/fill_economic_events.py --sync
  python scripts/fill_economic_events.py --add --event "CPI YoY" --forecast 3.1 --actual 3.3 --date 2026-08-12
  python scripts/fill_economic_events.py --show
"""
from __future__ import annotations

import argparse
import json
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

FF_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.xml"

TIER1_KEYWORDS = {
    "CPI": "CPI", "PCE": "PCE", "PPI": "PPI",
    "NFP": "NFP", "NON-FARM": "NFP", "NONFARM": "NFP",
    "PAYROLL": "NFP", "UNEMPLOYMENT": "NFP",
    "FOMC": "FOMC", "RATE DECISION": "FOMC", "FED FUNDS": "FOMC",
    "POWELL": "FOMC",
}


def classify_kind(title: str) -> Optional[str]:
    up = str(title or "").upper()
    for keyword, kind in TIER1_KEYWORDS.items():
        if keyword in up:
            return kind
    return None


def parse_ff_events(xml_text: str, max_age_days: float = 7.0,
                    now: datetime | None = None) -> List[Dict[str, Any]]:
    """Parse the FF calendar XML into macro events (pure, testable).

    Only USD (and ALL) TIER-1 gold events with a forecast, within
    max_age_days around now. actual is always None here - the FF free feed
    does not carry released values.
    """
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return []
    # ``now`` is injectable so pinned calendar fixtures do not become stale as
    # wall-clock time advances. Production callers retain the live UTC clock.
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    out: List[Dict[str, Any]] = []
    for ev in root.findall(".//event"):
        country = (ev.findtext("country") or "").strip().upper()
        if country not in {"USD", "ALL"}:
            continue
        title = (ev.findtext("title") or "").strip()
        kind = classify_kind(title)
        if not kind:
            continue
        forecast_raw = (ev.findtext("forecast") or "").strip()
        if not forecast_raw:
            continue  # no forecast -> no measurable surprise
        date_str = (ev.findtext("date") or "").strip()
        time_str = (ev.findtext("time") or "").strip()
        dt = None
        for fmt in ("%m-%d-%Y %I:%M%p", "%m-%d-%Y"):
            try:
                if time_str and time_str.lower() not in ("all day", "tentative", ""):
                    dt = datetime.strptime(f"{date_str} {time_str}", fmt).replace(tzinfo=timezone.utc)
                else:
                    dt = datetime.strptime(date_str, "%m-%d-%Y").replace(tzinfo=timezone.utc)
                break
            except (ValueError, TypeError):
                continue
        if dt is None:
            continue
        if abs((dt - now).total_seconds()) > max_age_days * 86400:
            continue
        out.append({
            "event": title,
            "kind": kind,
            "forecast": forecast_raw,
            "previous": (ev.findtext("previous") or "").strip(),
            "actual": None,
            "date": dt.strftime("%Y-%m-%d"),
            "source": "forexfactory",
        })
    return out


def merge_events(existing: List[Dict[str, Any]], fetched: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Upsert fetched entries into the file, preserving operator-filled actuals.

    Key = (event, date). A fetched forecast refreshes the row; an existing
    actual is NEVER overwritten."""
    merged: Dict[tuple, Dict[str, Any]] = {}
    for row in existing:
        if not isinstance(row, dict) or not row.get("event"):
            continue
        key = (str(row["event"]), str(row.get("date") or ""))
        merged[key] = dict(row)
    for row in fetched:
        key = (str(row["event"]), str(row.get("date") or ""))
        if key in merged:
            old_actual = merged[key].get("actual")
            merged[key].update(row)
            if old_actual is not None:
                merged[key]["actual"] = old_actual  # never overwrite a real value
        else:
            merged[key] = dict(row)
    return sorted(merged.values(), key=lambda r: str(r.get("date") or ""))


def load_file(root: Path) -> List[Dict[str, Any]]:
    path = root / "storage" / "macro" / "economic_events.json"
    if not path.exists():
        return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return raw if isinstance(raw, list) else []
    except Exception:  # noqa: BLE001
        return []


def save_file(root: Path, rows: List[Dict[str, Any]]) -> Path:
    path = root / "storage" / "macro" / "economic_events.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def main() -> int:
    parser = argparse.ArgumentParser(description="Fill macro economic events (FF forecast + manual actual)")
    parser.add_argument("--sync", action="store_true", help="fetch FF calendar and refresh forecast/previous")
    parser.add_argument("--add", action="store_true", help="manual entry after a release")
    parser.add_argument("--event", type=str, default="")
    parser.add_argument("--forecast", type=str, default="")
    parser.add_argument("--actual", type=str, default="")
    parser.add_argument("--date", type=str, default="")
    parser.add_argument("--show", action="store_true", help="print the current file")
    parser.add_argument("--root", type=str, default=str(ROOT))
    args = parser.parse_args()
    root = Path(args.root)

    if args.show:
        rows = load_file(root)
        print(json.dumps(rows, ensure_ascii=False, indent=2) if rows else "[]")
        return 0

    if args.sync:
        import requests

        print("Fetching ForexFactory calendar ...")
        try:
            resp = requests.get(FF_URL, timeout=15, headers={"User-Agent": "Gold-AI-Signals/1.0"})
            resp.raise_for_status()
            fetched = parse_ff_events(resp.text)
        except Exception as exc:  # noqa: BLE001
            print(f"FF fetch failed: {exc}")
            return 1
        if not fetched:
            print("No TIER-1 gold events with a forecast in this week's calendar.")
            return 0
        merged = merge_events(load_file(root), fetched)
        path = save_file(root, merged)
        print(f"synced {len(fetched)} events -> {path}")
        for row in fetched:
            print(f"  {row['date']} [{row['kind']}] {row['event']} "
                  f"forecast={row['forecast']} previous={row['previous']} actual=None (fill with --add)")
        print("After each release fill the actual:")
        print('  python scripts\\fill_economic_events.py --add --event "<title>" --forecast <f> --actual <a> --date <YYYY-MM-DD>')
        return 0

    if args.add:
        if not args.event or not args.forecast or not args.actual or not args.date:
            print("--add needs --event --forecast --actual --date")
            return 1
        rows = load_file(root)
        key = (args.event, args.date)
        replaced = False
        for row in rows:
            if (str(row.get("event")), str(row.get("date"))) == key:
                row["actual"] = args.actual
                row["forecast"] = args.forecast
                replaced = True
                break
        if not replaced:
            rows.append({
                "event": args.event,
                "forecast": args.forecast,
                "actual": args.actual,
                "date": args.date,
                "source": "operator",
            })
        path = save_file(root, rows)
        print(f"actual filled: {args.event} {args.date} forecast={args.forecast} actual={args.actual}")
        print(f"written: {path}")
        return 0

    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
