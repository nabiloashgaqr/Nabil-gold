"""Phase-1 bootstrap for the isolated Shadow Market Architect.

It performs a safety audit and initializes only the dedicated local SQLite
ledger. Market analysis starts in later approved phases.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shadow_market_architect.safety import audit_package
from shadow_market_architect.store import DEFAULT_PATH, ShadowStore


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--initialize-only", action="store_true")
    parser.add_argument("--capture-once", action="store_true",
                        help="Capture configured read-only evidence once and exit")
    parser.add_argument("--classify-once", action="store_true",
                        help="Capture evidence and classify all horizons once")
    parser.add_argument("--scenarios-once", action="store_true",
                        help="Capture, classify, and publish dual-sided shadow scenarios once")
    parser.add_argument("--entries-once", action="store_true",
                        help="Capture through virtual entry planning once")
    parser.add_argument("--positions-once", action="store_true",
                        help="Capture through virtual position bootstrap/management once")
    parser.add_argument("--gaps-once", action="store_true", help="Run family-aware gap comparison once")
    parser.add_argument("--report-once", action="store_true", help="Calculate stored shadow metrics and write a Markdown report")
    parser.add_argument("--calibrate-once", action="store_true", help="Write the final guarded calibration report")
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    cfg = config.get("shadow_market_architect", {}) or {}
    audit_package()
    store = ShadowStore(cfg.get("storage_path") or DEFAULT_PATH)
    store.initialize()
    print(f"Shadow Market Architect safety boundary: OK")
    print(f"Isolated ledger initialized: {store.path}")
    if args.initialize_only:
        return 0
    if not cfg.get("enabled", False):
        print("Shadow runner is disabled in config (safe default).")
        return 0
    if args.report_once:
        from shadow_market_architect.reporting import ShadowMetrics,ShadowReporter
        metrics=ShadowMetrics(cfg.get("reporting",{}) or {}).calculate(store.virtual_positions())
        for metric in metrics: store.upsert_daily_metric(metric)
        reporter=ShadowReporter();report=reporter.build(metrics,store.gap_comparisons())
        output=Path(cfg.get("reporting",{}).get("output_path","storage/shadow_market_report.md"))
        if not output.is_absolute(): output=ROOT/output
        output.parent.mkdir(parents=True,exist_ok=True);output.write_text(reporter.markdown(report),encoding="utf-8")
        print(f"Shadow metric groups: {len(metrics)}")
        print(f"Shadow report written: {output}")
        return 0
    if args.calibrate_once:
        from shadow_market_architect.reporting import ShadowReporter
        from shadow_market_architect.calibration import ShadowCalibrator,FinalReport
        metrics=store.daily_metrics();gaps=store.gap_comparisons();measurement=ShadowReporter().build([],gaps)
        measurement["summary"]["closed_families"]=sum(int(x.get("family_count",0)) for x in metrics)
        run=ShadowCalibrator(cfg.get("calibration",{}) or {}).calibrate(metrics,gaps);store.append_calibration_run(run)
        output=Path(cfg.get("calibration",{}).get("final_report_path","storage/shadow_final_calibration_report.md"))
        if not output.is_absolute(): output=ROOT/output
        output.parent.mkdir(parents=True,exist_ok=True);output.write_text(FinalReport().markdown(run,measurement),encoding="utf-8")
        print(f"Calibration recommendations: {len(run.recommendations)}")
        print(f"Final report written: {output}")
        return 0
    if args.capture_once or args.classify_once or args.scenarios_once or args.entries_once or args.positions_once or args.gaps_once:
        from shadow_market_architect.evidence import EvidenceAdapter
        from shadow_market_architect.regime import MarketStateEngine
        from shadow_market_architect.scenarios import DualSidedScenarioFactory
        from shadow_market_architect.entries import EntryArchitect, VirtualBroker, VirtualOrderStatus
        from shadow_market_architect.positions import VirtualPositionManager
        from shadow_market_architect.gaps import GapIntelligence
        adapter = EvidenceAdapter(cfg.get("evidence", {}) or {}, root=ROOT)
        engine = MarketStateEngine(cfg.get("market_state", {}) or {})
        factory = DualSidedScenarioFactory(cfg.get("scenario_factory", {}) or {})
        architect = EntryArchitect(cfg.get("entry_architect", {}) or {}, config)
        broker = VirtualBroker(config, cfg.get("entry_architect", {}) or {})
        manager = VirtualPositionManager(config, cfg.get("position_manager", {}) or {})
        gap_engine = GapIntelligence(cfg.get("gap_intelligence", {}) or {})
        originals=[]
        symbols = cfg.get("symbols") or [config.get("symbol") or "XAU/USD"]
        for symbol in symbols:
            snapshot = adapter.capture(str(symbol))
            store.append_evidence(snapshot)
            context=snapshot.original_context or {}
            raw_originals=context.get("trades") or context.get("closed_trades") or context.get("decisions") or []
            if isinstance(raw_originals,list): originals.extend(x for x in raw_originals if isinstance(x,dict))
            print(f"Evidence captured: {snapshot.symbol} warnings={len(snapshot.warnings)}")
            if args.classify_once or args.scenarios_once or args.entries_once or args.positions_once or args.gaps_once:
                states = engine.classify(snapshot.symbol, snapshot.market, snapshot.known_at)
                for state in states:
                    store.append_market_state(state)
                    print(f"  {state.horizon.value}: {state.state.value} "
                          f"{state.direction} strength={state.strength:.1f}")
                if args.scenarios_once or args.entries_once or args.positions_once or args.gaps_once:
                    scenarios = factory.build(snapshot, states)
                    for scenario in scenarios:
                        store.append_snapshot(scenario)
                    print(f"  dual-sided scenarios: {len(scenarios)}")
                    if args.entries_once or args.positions_once or args.gaps_once:
                        orders=0; positions=0; deduplicated=0
                        market=snapshot.market or {}
                        bid=float(market.get("bid") or market.get("current_price") or 0)
                        ask=float(market.get("ask") or market.get("current_price") or 0)

                        # Runtime hydration: old positions and pending orders
                        # remain the same objects across snapshot cycles.
                        open_positions=store.active_virtual_positions(snapshot.symbol)
                        for position in open_positions:
                            manager.on_tick(position,bid=bid,ask=ask,known_at=snapshot.known_at)
                            store.upsert_virtual_position(position); positions+=1
                        open_positions=[p for p in open_positions if p.status.value == "OPEN"]

                        def order_key(order):
                            entry=(round(float(order.entry_price),10)
                                   if order.entry_price is not None else None)
                            return (order.symbol,order.side,order.method,entry)

                        active_orders=store.active_virtual_orders(snapshot.symbol)
                        active_keys=set(); canonical_orders=[]
                        for order in active_orders:
                            key=order_key(order)
                            if key in active_keys:
                                # Clean up duplicates written by pre-runtime
                                # snapshot cycles; keep the oldest identity.
                                order.status=VirtualOrderStatus.CANCELLED
                                order.payload["runtime_reason"]="DUPLICATE_ACTIVE_ORDER"
                                store.upsert_virtual_order(order,updated_at=snapshot.known_at)
                                deduplicated+=1
                                continue
                            active_keys.add(key);canonical_orders.append(order)
                        for order in canonical_orders:
                            side_open=any(p.side==order.side for p in open_positions)
                            # A crossed pending remains pending while that side
                            # already has its one permitted live position.
                            if (not side_open and order.entry_price is not None
                                    and order.stop_loss is not None
                                    and broker.on_tick(order,bid=bid,ask=ask,
                                                       known_at=snapshot.known_at)):
                                position=manager.open_from_order(order,open_positions)
                                manager.on_tick(position,bid=bid,ask=ask,
                                                known_at=snapshot.known_at)
                                store.upsert_virtual_position(position)
                                if position.status.value == "OPEN":
                                    open_positions.append(position)
                                positions+=1
                            store.upsert_virtual_order(order,updated_at=snapshot.known_at)

                        for scenario in scenarios:
                            plan=architect.plan(scenario); store.append_entry_plan(plan)
                            order=architect.virtual_order(plan)
                            key=order_key(order)
                            if key in active_keys:
                                deduplicated+=1
                                continue
                            active_keys.add(key);orders+=1
                            side_open=any(p.side==order.side for p in open_positions)
                            if ((args.positions_once or args.gaps_once) and not side_open
                                    and order.entry_price is not None
                                    and order.stop_loss is not None
                                    and broker.on_tick(order,bid=bid,ask=ask,
                                                       known_at=scenario.known_at)):
                                position=manager.open_from_order(order,open_positions)
                                manager.on_tick(position,bid=bid,ask=ask,
                                                known_at=scenario.known_at)
                                store.upsert_virtual_position(position)
                                if position.status.value == "OPEN":
                                    open_positions.append(position)
                                positions+=1
                            store.upsert_virtual_order(order,updated_at=scenario.known_at)
                        print(f"  virtual entry plans/new orders: {orders} (deduplicated={deduplicated})")
                        if args.positions_once or args.gaps_once: print(f"  virtual positions managed: {positions}")
        if args.gaps_once:
            gaps=gap_engine.compare(originals,store.virtual_positions())
            for gap in gaps: store.append_gap_comparison(gap)
            print(f"Gap comparisons recorded: {len(gaps)}")
        return 0
    print("Phase 9 supports guarded calibration recommendations and the final gap-closure report.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
