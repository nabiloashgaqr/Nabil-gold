"""Safely merge Shadow Market Architect phase-1 settings into config.json."""
from __future__ import annotations

import argparse
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

SECTION = {
    "enabled": False,
    "phase": 1,
    "mode": "SHADOW_ONLY",
    "storage_path": "storage/shadow_market_architect.sqlite3",
    "allow_live_buy_per_symbol": 1,
    "allow_live_sell_per_symbol": 1,
    "allow_pending_both_directions": True,
    "telegram_enabled": False,
    "production_writes_allowed": False,
    "broker_execution_allowed": False,
    "description": "Isolated removable shadow research layer. Phase 1 initializes contracts and a dedicated local SQLite ledger only; it cannot trade or update production tables.",
    "description_direction_capacity": "Research target: at most one virtual LIVE BUY and one virtual LIVE SELL per symbol at the same time; multiple virtual pending scenarios in both directions remain measurable.",
}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("config", nargs="?", default="config.json")
    args = ap.parse_args()
    path = Path(args.config).resolve()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = path.with_name(f"{path.name}.bak.shadow-phase1.{stamp}")
    shutil.copy2(path, backup)
    data = json.loads(path.read_text(encoding="utf-8"))
    existing = data.get("shadow_market_architect")
    merged = dict(existing) if isinstance(existing, dict) else {}
    for key, value in SECTION.items():
        merged.setdefault(key, value)
    # Safety flags are not operator-tunable in phase 1.
    merged["phase"] = 1
    merged["mode"] = "SHADOW_ONLY"
    merged["production_writes_allowed"] = False
    merged["broker_execution_allowed"] = False
    merged["telegram_enabled"] = False
    data["shadow_market_architect"] = merged
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with tmp.open("r+", encoding="utf-8") as fh:
        os.fsync(fh.fileno())
    os.replace(tmp, path)
    print(f"Updated: {path}")
    print(f"Backup:  {backup}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
