#!/usr/bin/env python3
"""Set the Zone-Touch conversion R:R floor to 1.0 without replacing config.

Creates a timestamped backup and changes only the Zone-Touch conversion gate.
The fixed 80-point total XAU watch zone and all other risk laws are preserved.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

DESCRIPTION = (
    "Zone-Touch conversion floor is 1.0R. The path remains constrained by "
    "the fixed instrument-scaled watch zone (XAU 80 points total) and the "
    "configured target-progress guard; this setting does not alter SL or TP geometry."
)


def apply(path: Path) -> Path:
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    zone = data.setdefault("order_execution", {}).setdefault("zone_touch_activation", {})
    zone["min_remaining_rr"] = 1.0
    zone["description_min_remaining_rr"] = DESCRIPTION

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = path.with_name(f"{path.name}.bak.zone_rr_1_0.{stamp}")
    shutil.copy2(path, backup)
    temp = path.with_name(f".{path.name}.zone_rr_1_0.tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)
    return backup


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("config", nargs="?", default="config.json")
    args = parser.parse_args()
    path = Path(args.config).resolve()
    backup = apply(path)
    print(f"Updated: {path}")
    print(f"Backup:  {backup}")
    print("Zone-Touch min_remaining_rr: 1.0")


if __name__ == "__main__":
    main()
