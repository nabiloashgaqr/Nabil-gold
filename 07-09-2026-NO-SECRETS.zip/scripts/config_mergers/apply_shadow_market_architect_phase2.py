"""Merge cumulative Shadow Market Architect settings through phase 2."""
from __future__ import annotations
import argparse, json, os, shutil
from datetime import datetime, timezone
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument("config", nargs="?", default="config.json")
    path = Path(ap.parse_args().config).resolve()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = path.with_name(f"{path.name}.bak.shadow-phase2.{stamp}")
    shutil.copy2(path, backup)
    data = json.loads(path.read_text(encoding="utf-8"))
    existing = data.get("shadow_market_architect")
    s = dict(existing) if isinstance(existing, dict) else {}
    defaults = {
        "enabled": False, "phase": 2, "mode": "SHADOW_ONLY",
        "storage_path": "storage/shadow_market_architect.sqlite3",
        "allow_live_buy_per_symbol": 1, "allow_live_sell_per_symbol": 1,
        "allow_pending_both_directions": True, "telegram_enabled": False,
        "production_writes_allowed": False, "broker_execution_allowed": False,
        "symbols": ["XAU/USD", "WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"],
        "evidence": {
            "shared_market_data_path": "storage/shared_market_data.json",
            "agent_book_pattern": "storage/agent_books/{symbol}.json",
            "original_context_pattern": None,
            "auction_seconds_limit": 300,
            "auction_flow_paths": {
                "XAU/USD": "storage/auction_flow.sqlite3",
                "WTI/USD": "storage/auction_flow_wtiusd.sqlite3",
                "EUR/USD": "storage/auction_flow_eurusd.sqlite3",
                "GBP/USD": "storage/auction_flow_gbpusd.sqlite3",
                "USD/CAD": "storage/auction_flow_usdcad.sqlite3",
                "USD/JPY": "storage/auction_flow_usdjpy.sqlite3"
            },
            "description": "Read-only adapter consumes existing atomic market/agent artifacts and Auction Flow SQLite opened with mode=ro; unavailable evidence is recorded, never invented."
        },
        "description": "Isolated removable shadow research layer. Phase 2 adds read-only evidence capture; it cannot trade or update production tables.",
        "description_direction_capacity": "Research target: one virtual LIVE BUY and one virtual LIVE SELL per symbol, with multiple measurable pending scenarios in both directions."
    }
    for k,v in defaults.items(): s.setdefault(k,v)
    s["phase"] = 2; s["mode"] = "SHADOW_ONLY"
    s["production_writes_allowed"] = False; s["broker_execution_allowed"] = False; s["telegram_enabled"] = False
    # Phase-2 evidence defaults are merged without deleting operator additions.
    ev = dict(defaults["evidence"]); ev.update(s.get("evidence") or {})
    paths = dict(defaults["evidence"]["auction_flow_paths"]); paths.update(ev.get("auction_flow_paths") or {})
    ev["auction_flow_paths"] = paths; s["evidence"] = ev
    data["shadow_market_architect"] = s
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    with tmp.open("r+", encoding="utf-8") as fh: os.fsync(fh.fileno())
    os.replace(tmp,path)
    print(f"Updated: {path}"); print(f"Backup:  {backup}")
    return 0
if __name__ == "__main__": raise SystemExit(main())
