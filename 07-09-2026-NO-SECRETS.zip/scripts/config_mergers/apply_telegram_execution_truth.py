#!/usr/bin/env python3
"""Patch only the stale protection description while preserving live config.

Creates a timestamped backup next to config.json before the atomic write.
Runtime values are not changed: XAU=40, WTI=20, FX=60 already implement
Gold ×1, Oil ×0.5, Forex ×1.5.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

DESCRIPTION = (
    "Gold base. Every instrument explicitly owns its scaled value: "
    "XAU ×1, WTI ×0.5, FX ×1.5."
)


def apply(path: Path) -> Path:
    data = json.loads(path.read_text(encoding="utf-8"))
    protection = data.setdefault("trading_rules", {}).setdefault("protection", {})
    protection["description"] = DESCRIPTION

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = path.with_name(f"{path.name}.bak.telegram_truth.{stamp}")
    shutil.copy2(path, backup)
    temp = path.with_name(f".{path.name}.telegram_truth.tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)
    return backup


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("config", nargs="?", default="config.json")
    args = parser.parse_args()
    path = Path(args.config).resolve()
    backup = apply(path)
    print(f"Updated: {path}")
    print(f"Backup:  {backup}")


if __name__ == "__main__":
    main()
