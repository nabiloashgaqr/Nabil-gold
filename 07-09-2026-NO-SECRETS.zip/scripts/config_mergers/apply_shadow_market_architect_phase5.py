"""Merge cumulative Shadow Market Architect settings through phase 5."""
from __future__ import annotations
import argparse,json,os,shutil
from datetime import datetime,timezone
from pathlib import Path
SYMBOLS=["XAU/USD","WTI/USD","EUR/USD","GBP/USD","USD/CAD","USD/JPY"]
AUCTION={"XAU/USD":"storage/auction_flow.sqlite3","WTI/USD":"storage/auction_flow_wtiusd.sqlite3","EUR/USD":"storage/auction_flow_eurusd.sqlite3","GBP/USD":"storage/auction_flow_gbpusd.sqlite3","USD/CAD":"storage/auction_flow_usdcad.sqlite3","USD/JPY":"storage/auction_flow_usdjpy.sqlite3"}
def merge(dst,src):
 out=dict(src); out.update(dst if isinstance(dst,dict) else {})
 for k,v in src.items():
  if isinstance(v,dict): out[k]=merge((dst or {}).get(k,{}),v)
 return out
def main()->int:
 ap=argparse.ArgumentParser();ap.add_argument("config",nargs="?",default="config.json");p=Path(ap.parse_args().config).resolve();stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ");bak=p.with_name(f"{p.name}.bak.shadow-phase5.{stamp}");shutil.copy2(p,bak);data=json.loads(p.read_text(encoding="utf-8"))
 defaults={"enabled":False,"phase":5,"mode":"SHADOW_ONLY","storage_path":"storage/shadow_market_architect.sqlite3","allow_live_buy_per_symbol":1,"allow_live_sell_per_symbol":1,"allow_pending_both_directions":True,"telegram_enabled":False,"production_writes_allowed":False,"broker_execution_allowed":False,"symbols":SYMBOLS,"evidence":{"shared_market_data_path":"storage/shared_market_data.json","agent_book_pattern":"storage/agent_books/{symbol}.json","original_context_pattern":None,"auction_seconds_limit":300,"auction_flow_paths":AUCTION},"market_state":{"min_closed_bars":20,"lookback_bars":24,"drop_live_bar":True,"shock_tr_multiple":3.0,"compression_atr_ratio":0.68,"expansion_atr_ratio":1.45},"scenario_factory":{"version":"phase5","approaching_zone_widths":1.0,"publish_both_directions":True,"horizons":["SCALP","INTRADAY","STRUCTURAL"],"description":"Always publishes one BUY and one SELL hypothesis per horizon. Location alone never becomes READY; phase-5 entry triggers are mandatory."},"entry_architect":{"gold_risk_points":300,"gold_min_risk_points":270,"gold_max_risk_points":400,"tp1_rr":1.0,"tp2_rr":2.0,"tp3_rr":3.0,"market_slippage_points":0,"description":"Broker-inert entry planner. Gold is the numeric base; canonical distance_ratio resolves WTI x0.5 and FX x1.5. LIMIT uses executable bid/ask rules and market simulations record spread/slippage."},"description":"Isolated shadow layer through phase 5: evidence, states, dual-sided hypotheses, and virtual entry plans/orders; no broker execution or production writes."}
 s=merge(data.get("shadow_market_architect",{}),defaults);s.update({"phase":5,"mode":"SHADOW_ONLY","production_writes_allowed":False,"broker_execution_allowed":False,"telegram_enabled":False});data["shadow_market_architect"]=s;tmp=p.with_suffix(p.suffix+".tmp");tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");
 with tmp.open("r+",encoding="utf-8") as f:os.fsync(f.fileno())
 os.replace(tmp,p);print(f"Updated: {p}");print(f"Backup:  {bak}");return 0
if __name__=="__main__":raise SystemExit(main())
