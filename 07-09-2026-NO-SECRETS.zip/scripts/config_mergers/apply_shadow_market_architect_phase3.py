"""Merge cumulative Shadow Market Architect settings through phase 3."""
from __future__ import annotations
import argparse, json, os, shutil
from datetime import datetime, timezone
from pathlib import Path

SYMBOLS=["XAU/USD","WTI/USD","EUR/USD","GBP/USD","USD/CAD","USD/JPY"]
AUCTION={"XAU/USD":"storage/auction_flow.sqlite3","WTI/USD":"storage/auction_flow_wtiusd.sqlite3","EUR/USD":"storage/auction_flow_eurusd.sqlite3","GBP/USD":"storage/auction_flow_gbpusd.sqlite3","USD/CAD":"storage/auction_flow_usdcad.sqlite3","USD/JPY":"storage/auction_flow_usdjpy.sqlite3"}

def main()->int:
 ap=argparse.ArgumentParser(); ap.add_argument("config",nargs="?",default="config.json"); path=Path(ap.parse_args().config).resolve()
 stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"); backup=path.with_name(f"{path.name}.bak.shadow-phase3.{stamp}"); shutil.copy2(path,backup)
 data=json.loads(path.read_text(encoding="utf-8")); old=data.get("shadow_market_architect"); s=dict(old) if isinstance(old,dict) else {}
 defaults={"enabled":False,"phase":3,"mode":"SHADOW_ONLY","storage_path":"storage/shadow_market_architect.sqlite3","allow_live_buy_per_symbol":1,"allow_live_sell_per_symbol":1,"allow_pending_both_directions":True,"telegram_enabled":False,"production_writes_allowed":False,"broker_execution_allowed":False,"symbols":SYMBOLS,"evidence":{"shared_market_data_path":"storage/shared_market_data.json","agent_book_pattern":"storage/agent_books/{symbol}.json","original_context_pattern":None,"auction_seconds_limit":300,"auction_flow_paths":AUCTION,"description":"Read-only existing evidence; unavailable inputs are recorded and never invented."},"market_state":{"min_closed_bars":20,"lookback_bars":24,"drop_live_bar":True,"shock_tr_multiple":3.0,"compression_atr_ratio":0.68,"expansion_atr_ratio":1.45,"description":"Transparent price-only state engine classifies SCALP, INTRADAY and STRUCTURAL independently; the live forming bar is excluded."},"description":"Isolated shadow layer through phase 3: read-only evidence plus deterministic multi-horizon market-state classification; no trading or production writes."}
 for k,v in defaults.items(): s.setdefault(k,v)
 ev=dict(defaults["evidence"]); ev.update(s.get("evidence") or {}); paths=dict(AUCTION); paths.update(ev.get("auction_flow_paths") or {}); ev["auction_flow_paths"]=paths; s["evidence"]=ev
 ms=dict(defaults["market_state"]); ms.update(s.get("market_state") or {}); s["market_state"]=ms
 s.update({"phase":3,"mode":"SHADOW_ONLY","production_writes_allowed":False,"broker_execution_allowed":False,"telegram_enabled":False}); data["shadow_market_architect"]=s
 tmp=path.with_suffix(path.suffix+".tmp"); tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");
 with tmp.open("r+",encoding="utf-8") as fh: os.fsync(fh.fileno())
 os.replace(tmp,path); print(f"Updated: {path}"); print(f"Backup:  {backup}"); return 0
if __name__=="__main__": raise SystemExit(main())
