"""Merge the tick-native 80-point zone-touch law without replacing config.json."""
from __future__ import annotations
import argparse, json, shutil
from datetime import datetime, timezone
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("config", nargs="?", default="config.json")
    args = ap.parse_args()
    path = Path(args.config).resolve()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = path.with_name(f"{path.name}.bak.zone-touch.{stamp}")
    shutil.copy2(path, backup)
    data = json.loads(path.read_text(encoding="utf-8"))
    z = data.setdefault("order_execution", {}).setdefault("zone_touch_activation", {})
    z.update({
        "enabled": True, "grace_minutes": 0, "zone_width_points": 80,
        "tick_managed_only": True, "news_bypass": True,
        "require_exit_in_favour": True, "preserve_planned_risk": True,
        "description_grace_minutes": "No waiting: MT5 Tick Manager watches every tick and converts on the first favourable exit after a real zone touch.",
        "description_zone_width_points": "Gold base zone width is 80 points total. The canonical instrument distance ratio resolves WTI to 40 points and FX to 120 points.",
        "description_zone_width_scaling": "Single-source scaling: XAU x1.0, WTI x0.5, FX x1.5; each resolved width is split equally around the planned LIMIT entry.",
        "description_tick_managed_only": "MT5 Tick Manager is the sole conversion authority: cancel the broker pending order, confirm cancellation, then send one MARKET order.",
        "description_news_bypass": "Zone-touch conversion may execute during news; all other entry paths keep their normal news gate.",
    })
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)
    print(f"Updated: {path}")
    print(f"Backup:  {backup}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
