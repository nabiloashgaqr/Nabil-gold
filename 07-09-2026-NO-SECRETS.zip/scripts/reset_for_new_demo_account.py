#!/usr/bin/env python3
"""Archive the old account and initialise a clean local dashboard/trade book.

Dry-run by default. This never deletes history: it copies the selected storage
files into an immutable timestamped archive before atomically resetting only
operational/display stores. Learning history and path-performance stores remain
in place, and the archived trade book stays available for forensic review.

Stop Analysis, Tick Manager, and Dashboard API before applying. Broker positions
and Supabase rows are never modified by this script.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
STORAGE = ROOT / "storage"
ARCHIVE_ROOT = STORAGE / "account_archives"
CONFIRM = "ARCHIVE_OLD_ACCOUNT_AND_START_CLEAN"

# Copied for review. Only RESET_CONTENT entries are changed afterwards.
ARCHIVE_FILES = (
    "trades.json", "trades_demo.json", "demo_trades.json",
    "decision_audit.json", "daily_report.json", "session_plans.json",
    "setup_candidates.json", "setup_state_events.json", "live_snapshot.json",
    "hourly_status_last.json",
)
RESET_CONTENT = {
    "trades.json": [], "trades_demo.json": [], "demo_trades.json": [],
    "decision_audit.json": [], "daily_report.json": {},
    "session_plans.json": [], "setup_candidates.json": [],
    "setup_state_events.json": [],
}
TRANSIENT_FILES = ("live_snapshot.json", "hourly_status_last.json")
ACTIVE = {"OPEN", "PARTIAL", "TP1_HIT", "PENDING"}


def _read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return default


def _atomic_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(value, fh, ensure_ascii=False, indent=2)
            fh.write("\n"); fh.flush(); os.fsync(fh.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def plan(root: Path = ROOT) -> dict:
    storage = root / "storage"
    trades = _read_json(storage / "trades.json", [])
    rows = trades if isinstance(trades, list) else []
    active = [r for r in rows if isinstance(r, dict) and str(r.get("status") or "").upper() in ACTIVE]
    files = [name for name in ARCHIVE_FILES if (storage / name).is_file()]
    return {"trade_rows": len(rows), "active_rows": len(active), "files": files}


def transition(root: Path = ROOT, *, archive_active: bool = False,
               regenerate_dashboard: bool = True) -> Path:
    info = plan(root)
    if info["active_rows"] and not archive_active:
        raise RuntimeError(
            f"{info['active_rows']} active/pending local rows found. Confirm broker closure first, "
            "then rerun with --archive-active. This flag archives rows; it does not close MT5 orders."
        )
    storage = root / "storage"
    archive_root = storage / "account_archives"
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    archive = archive_root / f"account_{stamp}"
    archive.mkdir(parents=True, exist_ok=False)

    manifest = {"created_at": datetime.now(timezone.utc).isoformat(),
                "purpose": "old account forensic and learning archive",
                "trade_rows": info["trade_rows"], "active_rows_archived": info["active_rows"],
                "files": {}}
    for name in info["files"]:
        src, dst = storage / name, archive / name
        shutil.copy2(src, dst)
        manifest["files"][name] = {"sha256": _sha256(dst), "bytes": dst.stat().st_size}
    _atomic_json(archive / "MANIFEST.json", manifest)

    # Backup verification is a hard barrier before any reset.
    for name, meta in manifest["files"].items():
        if _sha256(archive / name) != meta["sha256"]:
            raise RuntimeError(f"archive verification failed for {name}")

    for name, empty in RESET_CONTENT.items():
        _atomic_json(storage / name, empty)
    for name in TRANSIENT_FILES:
        path = storage / name
        if path.exists():
            path.unlink()
    for path in (root / ".demo_halt", root / "tick_heartbeat.json"):
        if path.is_file():
            path.unlink()
    _atomic_json(storage / "account_transition.json", {
        "started_at": datetime.now(timezone.utc).isoformat(),
        "archive": str(archive.relative_to(root)),
        "old_trade_rows": info["trade_rows"],
        "note": "Local dashboard/account epoch reset; broker and Supabase unchanged",
    })

    if regenerate_dashboard:
        env = dict(os.environ, SEND_TELEGRAM="false")
        subprocess.run([sys.executable, str(root / "scripts" / "generate_dashboard.py")],
                       cwd=root, env=env, check=False)
    return archive


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--apply", action="store_true", help="perform archive and reset")
    p.add_argument("--confirm", default="", help=f"required token: {CONFIRM}")
    p.add_argument("--archive-active", action="store_true",
                   help="archive local active rows after broker positions were closed")
    p.add_argument("--no-dashboard-regenerate", action="store_true")
    args = p.parse_args(argv)
    info = plan()
    print(json.dumps(info, indent=2))
    if not args.apply:
        print("DRY RUN ONLY. Stop services, close/cancel broker orders, then use --apply.")
        return 0
    if args.confirm != CONFIRM:
        print(f"REFUSED: pass --confirm {CONFIRM}", file=sys.stderr)
        return 2
    archive = transition(archive_active=args.archive_active,
                         regenerate_dashboard=not args.no_dashboard_regenerate)
    print(f"DONE. Old account archived at: {archive}")
    print("Dashboard/local operational stores are clean. Learning/path-performance stores were preserved.")
    print("IMPORTANT: broker positions and Supabase were not changed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
