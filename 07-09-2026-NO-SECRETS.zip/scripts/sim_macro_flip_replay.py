#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SIM_MACRO_FLIP_REPLAY — R26.9.13 (operator order 2026-09-03
«طبق اصلاح الماكرو مع سكربت لقياس تاثير الاصلاح وهل كان سيدخل البارحة
واليوم شراء») — point-in-time A/B replay of the macro judge:

    v1 = deployed pre-R26.9.13 law   (5d net eye, fixed 0.15% threshold,
         loudest-pair DXY, no age decay, curve guard dead)
    v2 = R26.9.13 flip-speed law     (24h fast eye + 5d slow eye, relative
         threshold, weighted DXY basket, dedup Fed, disagreement cap 54,
         age decay, veto bar 60)

For EVERY hourly stamp t in the window it rebuilds BOTH contexts from ONLY
the data visible at t (no look-ahead: series are sliced at t before the
core sees them), runs BOTH agents on top, and prints the verdict table plus
the three numbers the operator asked for:

  1) هل كان يدخل شراء البارحة واليوم؟  — first hour each mode would
     CONFIRM a BUY (bias BUY and confidence >= 55, the confirmation bar)
  2) flip latency  — hours from the move's real start to the flip
  3) flip-flops    — verdict sign changes over the window (discipline)

Pure Python + yfinance (same feed the provider already uses on the Windows
server). Read-only: touches the network and writes one JSON report next to
this file. Fail-soft: a missing series degrades that leg, never crashes.

Usage:
    python scripts/sim_macro_flip_replay.py                 # gold, last ~6d
    python scripts/sim_macro_flip_replay.py --symbol EUR/USD
    python scripts/sim_macro_flip_replay.py --days 8 --json-only
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# ── series map (same Yahoo symbols the provider fetches) ──────────────────
FEED = {
    "XAU/USD": {"price": "GC=F", "dxy": "DX-Y.NYB", "tnx": "^TNX", "vix": "^VIX",
                "tip": "TIP", "spy": "SPY"},
    "EUR/USD": {"price": "EURUSD=X", "dxy": "DX-Y.NYB", "tnx": "^TNX", "vix": "^VIX",
                "tip": "TIP", "spy": "SPY", "eurgbp": "EURGBP=X", "eurjpy": "EURJPY=X"},
    "GBP/USD": {"price": "GBPUSD=X", "dxy": "DX-Y.NYB", "tnx": "^TNX", "vix": "^VIX",
                "tip": "TIP", "spy": "SPY", "eurgbp": "EURGBP=X", "eurjpy": "EURJPY=X"},
    "USD/JPY": {"price": "USDJPY=X", "dxy": "DX-Y.NYB", "tnx": "^TNX", "vix": "^VIX",
                "tip": "TIP", "spy": "SPY"},
    "USD/CAD": {"price": "USDCAD=X", "dxy": "DX-Y.NYB", "tnx": "^TNX", "vix": "^VIX",
                "tip": "TIP", "spy": "SPY"},
    "WTI/USD": {"price": "CL=F", "dxy": "DX-Y.NYB", "tnx": "^TNX", "vix": "^VIX",
                "tip": "TIP", "spy": "SPY"},
}
YF_ALIASES = {"GC=F": ["GC=F"], "CL=F": ["CL=F"], "DX-Y.NYB": ["DX-Y.NYB"],
              "^TNX": ["^TNX"], "^VIX": ["^VIX"], "TIP": ["TIP"], "SPY": ["SPY"],
              "EURUSD=X": ["EURUSD=X"], "GBPUSD=X": ["GBPUSD=X"],
              "USDJPY=X": ["USDJPY=X"], "USDCAD=X": ["USDCAD=X"],
              "EURGBP=X": ["EURGBP=X"], "EURJPY=X": ["EURJPY=X"]}


def _fetch(symbol: str, days: int):
    """[(dt_utc, close)] hourly (falls back to whatever granularity Yahoo
    gives — the core only needs points, not bars)."""
    import yfinance as yf
    frame = yf.Ticker(symbol).history(period=f"{days + 4}d", interval="1h",
                                      auto_adjust=False)
    pts = []
    if frame is not None and len(frame):
        for ts, row in zip(frame.index, frame.itertuples()):
            dt = ts.to_pydatetime()
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            close = float(getattr(row, "Close", 0.0) or 0.0)
            if close > 0:
                pts.append((dt.astimezone(timezone.utc), close))
    return sorted(pts)


def _slice(pts, lo, hi):
    return [(dt, c) for dt, c in pts if lo < dt <= hi]


def main() -> int:
    ap = argparse.ArgumentParser(description="A/B replay v1 vs v2 macro judge")
    ap.add_argument("--symbol", default="XAU/USD")
    ap.add_argument("--days", type=float, default=6.0,
                    help="replay window in days ending at the last bar")
    ap.add_argument("--confirm-bar", type=float, default=55.0)
    ap.add_argument("--json-only", action="store_true")
    ap.add_argument("--out", default=str(ROOT / "storage" / "macro" / "flip_replay_last.json"))
    args = ap.parse_args()

    symbol = args.symbol.upper()
    feed = FEED.get(symbol)
    if not feed:
        print(f"unsupported symbol {symbol}; known: {', '.join(FEED)}")
        return 2

    series = {}
    for name, yfsym in feed.items():
        for cand in YF_ALIASES.get(yfsym, [yfsym]):
            try:
                pts = _fetch(cand, int(args.days))
                if pts:
                    series[name] = pts
                    break
            except Exception as exc:  # noqa: BLE001 — degrade, never crash
                print(f"  [warn] {cand}: {exc}", file=sys.stderr)
    if "price" not in series or len(series["price"]) < 24:
        print("no usable price series — abort (network/feed down?)")
        return 3
    last = series["price"][-1][0]
    start = last - timedelta(days=args.days)
    if not args.json_only:
        print(f"\nSIM_MACRO_FLIP_REPLAY  {symbol}  window {start:%m-%d %H:%M} → "
              f"{last:%m-%d %H:%M} UTC   ({len(series['price'])} hourly bars)")

    # import the two laws AFTER sys.path is set (pure modules, no IO).
    # Series keys mirror the PRODUCTION feed exactly (provider's own symbol
    # list) so the DXY basket / crosses legs see what the judge sees live.
    from services.macro_data_provider import MacroDataProvider
    YFINANCE_SYMBOLS = list(MacroDataProvider.YFINANCE_SYMBOLS)
    from services.macro_context_core import build_context as core_build
    from agents.macro_fundamental_agent import MacroFundamentalAgent

    _PRICE_KEY = {"XAU/USD": "XAUUSD=X", "EUR/USD": "EURUSD=X", "GBP/USD": "GBPUSD=X",
                  "USD/JPY": "USDJPY=X", "USD/CAD": "USDCAD=X",
                  "WTI/USD": "CL=F"}[symbol]
    for cand in list(dict.fromkeys([*YFINANCE_SYMBOLS, _PRICE_KEY, "DX-Y.NYB",
                                    "GC=F"])):
        if cand not in series and cand not in series.values():
            try:
                pts = _fetch(cand, int(args.days))
                if pts:
                    series[cand] = pts
            except Exception as exc:  # noqa: BLE001 — degrade, never crash
                print(f"  [warn] {cand}: {exc}", file=sys.stderr)

    # the traded symbol's own series for the R26.9.14 divergence key
    if "price" in series:
        series["symbol_price"] = series["price"]

    agent_v1 = MacroFundamentalAgent({"symbol": symbol}, v1_compat=True)
    agent_v2 = MacroFundamentalAgent({"symbol": symbol}, v1_compat=False)

    def ctx_at(t, v1):
        lo = t - timedelta(days=5)
        series_map = {sym: _slice(pts, lo, t) for sym, pts in series.items()}
        series_map = {k: v for k, v in series_map.items() if v}
        if not series_map:
            return {}
        try:
            return core_build(series_map, as_of=t, v1_compat=v1)
        except Exception:  # noqa: BLE001
            return {}

    def verdict(agent, ctx):
        try:
            out = agent.macro_direction(ctx)
            return str(out.get("bias") or "NEUTRAL"), int(out.get("confidence") or 0)
        except Exception:  # noqa: BLE001
            return "ERROR", 0

    # hourly stamps over the window (anchored on real bars)
    stamps = [dt for dt, _ in series["price"] if dt > start]
    rows = []
    for t in stamps:
        price = next((c for dt, c in reversed(series["price"]) if dt <= t), None)
        # pin each agent's clock to the stamp: live contexts are fresh by
        # construction (age ~0), and punishing a historical stamp with the
        # REAL wall clock would understate v2 confidence by up to 30%.
        agent_v1._now_fn = (lambda tt: (lambda: tt))(t)
        agent_v2._now_fn = (lambda tt: (lambda: tt))(t)
        b1, c1 = verdict(agent_v1, ctx_at(t, True))
        b2, c2 = verdict(agent_v2, ctx_at(t, False))
        rows.append({"t": t.isoformat(), "price": round(price, 5) if price else None,
                     "v1_bias": b1, "v1_conf": c1, "v2_bias": b2, "v2_conf": c2})

    # ── analysis ─────────────────────────────────────────────────────────
    def day_rows(day0):
        return [r for r in rows if r["t"][:10] == day0]

    def first_confirm(mode, rs):
        pre = "v1_" if mode == "v1" else "v2_"
        for r in rs:
            if r[pre + "bias"].startswith("BULLISH") and r[pre + "conf"] >= args.confirm_bar:
                return r
        return None

    def first_buy_any(mode, rs):
        pre = "v1_" if mode == "v1" else "v2_"
        for r in rs:
            if r[pre + "bias"].startswith("BULLISH"):
                return r
        return None

    def flips(mode, rs):
        pre = "v1_" if mode == "v1" else "v2_"
        n = 0
        for a, b in zip(rs, rs[1:]):
            sa = 1 if a[pre + "bias"].startswith("BULLISH") else (-1 if a[pre + "bias"].startswith("BEARISH") else 0)
            sb = 1 if b[pre + "bias"].startswith("BULLISH") else (-1 if b[pre + "bias"].startswith("BEARISH") else 0)
            if sa and sb and sa != sb:
                n += 1
        return n

    def asleep_hours(mode, rs):
        """hours spent BEARISH/NEUTRAL while price above the day's first
        bar close — the 'slept through the rally' metric."""
        pre = "v1_" if mode == "v1" else "v2_"
        if not rs:
            return 0
        base = rs[0]["price"]
        return sum(1 for r in rs
                   if base and r["price"] and r["price"] > base
                   and not r[pre + "bias"].startswith("BULLISH"))

    days = sorted({r["t"][:10] for r in rows})
    report = {"symbol": symbol, "window": [rows[0]["t"], rows[-1]["t"]],
              "confirm_bar": args.confirm_bar, "rows": rows, "days": {}}
    for day0 in days:
        rs = day_rows(day0)
        if len(rs) < 3:
            continue
        up_move = max(r["price"] or 0 for r in rs) > (rs[0]["price"] or 0)
        e1, e2 = first_buy_any("v1", rs), first_buy_any("v2", rs)
        report["days"][day0] = {
            "bars": len(rs),
            "up_day": bool(up_move),
            "first_bar_price": rs[0]["price"], "last_bar_price": rs[-1]["price"],
            "v1_first_bullish": e1["t"] if e1 else None,
            "v2_first_bullish": e2["t"] if e2 else None,
            "v1_confirms_buy": (lambda f: f["t"] if f else None)(first_confirm("v1", rs)),
            "v2_confirms_buy": (lambda f: f["t"] if f else None)(first_confirm("v2", rs)),
            "flip_latency_hours_v1": (lambda: None)(),
            "flip_latency_hours_v2": (lambda: None)(),
            "flips_v1": flips("v1", rs), "flips_v2": flips("v2", rs),
            "asleep_in_rally_v1": asleep_hours("v1", rs),
            "asleep_in_rally_v2": asleep_hours("v2", rs),
        }
        # flip latency: hours from the first bar that broke above the day's
        # opening range (move start) to the first BULLISH verdict
        move_start = None
        for r in rs:
            if r["price"] and rs[0]["price"] and r["price"] > rs[0]["price"] * 1.001:
                move_start = datetime.fromisoformat(r["t"])
                break
        for mode, first in (("v1", e1), ("v2", e2)):
            if move_start and first:
                dtf = datetime.fromisoformat(first["t"])
                report["days"][day0][f"flip_latency_hours_{mode}"] = round(
                    (dtf - move_start).total_seconds() / 3600.0, 2)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    if not args.json_only:
        cur = ""
        for r in rows:
            if r["t"][:10] != cur:
                cur = r["t"][:10]
                print(f"\n── {cur} " + "─" * 46)
            print(f"  {r['t'][11:16]}  price {r['price'] or 0:>10.5f}   "
                  f"v1 {r['v1_bias']:<14}{r['v1_conf']:>3}%   "
                  f"v2 {r['v2_bias']:<14}{r['v2_conf']:>3}%")
        print("\n" + "─" * 62)
        for day0, d in report["days"].items():
            print(f"  {day0}: up_day={d['up_day']}  "
                  f"v1 bull@{str(d['v1_first_bullish'])[11:16] or '—'} "
                  f"(lat {d['flip_latency_hours_v1']}h, asleep {d['asleep_in_rally_v1']}h, "
                  f"flips {d['flips_v1']})  "
                  f"v2 bull@{str(d['v2_first_bullish'])[11:16] or '—'} "
                  f"(lat {d['flip_latency_hours_v2']}h, asleep {d['asleep_in_rally_v2']}h, "
                  f"flips {d['flips_v2']})  BUY-confirmed@{str(d['v2_confirms_buy'])[11:16] or '—'}")
        print(f"\n  JSON report → {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
