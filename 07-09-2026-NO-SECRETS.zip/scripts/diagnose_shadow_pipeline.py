"""Explain exactly why Shadow Market Architect did not open positions."""
from __future__ import annotations
import argparse,json,sqlite3,sys
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--config',default='config.json');a=ap.parse_args();cp=Path(a.config);cp=cp if cp.is_absolute() else ROOT/cp
 cfg=json.loads(cp.read_text(encoding='utf-8'));s=cfg.get('shadow_market_architect') or {};db=Path(s.get('storage_path') or 'storage/shadow_market_architect.sqlite3');db=db if db.is_absolute() else ROOT/db
 if not db.exists():print('FAIL database missing:',db);return 2
 uri=f"file:{db.resolve().as_posix()}?mode=ro"
 with sqlite3.connect(uri,uri=True) as c:
  c.row_factory=sqlite3.Row
  print('DATABASE:',db);print('ENABLED:',s.get('enabled'))
  print('\nLATEST EVIDENCE WARNINGS')
  rows=c.execute('''select e.symbol,e.known_at,e.warnings_json from shadow_evidence_snapshots e join
   (select symbol,max(rowid) rid from shadow_evidence_snapshots group by symbol) x on e.rowid=x.rid order by e.symbol''').fetchall()
  for r in rows:
   warnings=json.loads(r['warnings_json'] or '[]');print(f"{r['symbol']}: {warnings or ['none']}")
  print('\nLATEST ENTRY DECISIONS')
  rows=c.execute('''select p.symbol,p.side,p.method,p.decision,p.plan_json from shadow_entry_plans p join
   (select symbol,side,max(rowid) rid from shadow_entry_plans group by symbol,side) x on p.rowid=x.rid order by p.symbol,p.side''').fetchall()
  totals=Counter()
  for r in rows:
   d=json.loads(r['plan_json']);reason=d.get('reason');totals[(r['method'],r['decision'],reason)]+=1
   print(f"{r['symbol']} {r['side']}: {r['method']} / {r['decision']} | {reason} | entry={d.get('entry_price')}")
  print('\nALL PLAN SUMMARY')
  allrows=c.execute('select method,decision,plan_json from shadow_entry_plans').fetchall();summary=Counter()
  for r in allrows:
   d=json.loads(r['plan_json']);summary[(r['method'],r['decision'],d.get('reason'))]+=1
  for (method,decision,reason),n in summary.most_common():print(f"{n:4}  {method}/{decision}: {reason}")
  print('\nORDER STATUS SUMMARY')
  for r in c.execute('select status,order_type,count(*) n from shadow_virtual_orders group by status,order_type order by n desc'):print(f"{r['n']:4}  {r['status']} {r['order_type']}")
  executable=c.execute("select count(*) from shadow_virtual_orders where status='FILLED'").fetchone()[0]
  if not executable:print('\nROOT CAUSE: no virtual order reached FILLED. Inspect PASS reasons and evidence warnings above.')
 return 0
if __name__=='__main__':raise SystemExit(main())
