"""Diagnose, safely enable, and run one Shadow Market Architect cycle.

Examples (PowerShell):
  python scripts/check_and_start_shadow.py
  python scripts/check_and_start_shadow.py --enable --run-once
"""
from __future__ import annotations
import argparse,json,shutil,sqlite3,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
TABLES=("shadow_evidence_snapshots","shadow_market_state_snapshots","shadow_scenario_snapshots","shadow_entry_plans","shadow_virtual_orders","shadow_virtual_trades","shadow_gap_comparisons","shadow_daily_metrics")
def load(path):return json.loads(path.read_text(encoding="utf-8"))
def resolve(root,value):
 p=Path(value);return p if p.is_absolute() else root/p
def counts(db):
 if not db.exists():return {}
 uri=f"file:{db.resolve().as_posix()}?mode=ro"
 out={}
 with sqlite3.connect(uri,uri=True,timeout=3) as c:
  names={r[0] for r in c.execute("select name from sqlite_master where type='table'")}
  for t in TABLES:out[t]=c.execute(f"select count(*) from {t}").fetchone()[0] if t in names else None
  if "shadow_virtual_trades" in names:
   out["OPEN_BUY"]=c.execute("select count(*) from shadow_virtual_trades where status='OPEN' and side='BUY'").fetchone()[0]
   out["OPEN_SELL"]=c.execute("select count(*) from shadow_virtual_trades where status='OPEN' and side='SELL'").fetchone()[0]
   out["CLOSED"]=c.execute("select count(*) from shadow_virtual_trades where status='CLOSED'").fetchone()[0]
 return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument("--config",default="config.json");ap.add_argument("--enable",action="store_true");ap.add_argument("--run-once",action="store_true");a=ap.parse_args();path=resolve(ROOT,a.config)
 if not path.exists():print(f"FAIL config missing: {path}");return 2
 cfg=load(path);s=cfg.get("shadow_market_architect") or {}
 if not s:print("FAIL shadow_market_architect block missing; run phase-9 merger first");return 2
 if a.enable and not s.get("enabled"):
  stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ");bak=path.with_name(path.name+f".bak.shadow-enable.{stamp}");shutil.copy2(path,bak);s["enabled"]=True;cfg["shadow_market_architect"]=s;tmp=path.with_suffix(path.suffix+".tmp");tmp.write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");tmp.replace(path);print(f"ENABLED; backup: {bak}")
 db=resolve(ROOT,s.get("storage_path") or "storage/shadow_market_architect.sqlite3")
 print(f"config: {path}");print(f"enabled: {bool(s.get('enabled'))}");print(f"mode: {s.get('mode')}");print(f"broker execution: {s.get('broker_execution_allowed')}");print(f"production writes: {s.get('production_writes_allowed')}");print(f"database: {db}")
 if a.run_once:
  if not load(path).get("shadow_market_architect",{}).get("enabled"):print("FAIL disabled; use --enable --run-once");return 2
  cmd=[sys.executable,str(ROOT/'scripts/run_shadow_market_architect.py'),'--config',str(path),'--positions-once'];print("RUN:"," ".join(cmd));r=subprocess.run(cmd,cwd=ROOT);print("cycle exit:",r.returncode)
  if r.returncode:return r.returncode
 c=counts(db);print("\nLEDGER COUNTS")
 for k,v in c.items():print(f"{k}: {v}")
 if not c:print("FAIL shadow database does not exist yet");return 1
 if (c.get("shadow_evidence_snapshots") or 0)==0:print("FAIL no evidence captured")
 elif (c.get("shadow_scenario_snapshots") or 0)==0:print("FAIL no scenarios generated")
 elif (c.get("shadow_virtual_trades") or 0)==0:print("WARNING pipeline reaches scenarios/orders but has opened no virtual positions")
 elif (c.get("CLOSED") or 0)==0:print("WARNING positions exist but none are closed; daily comparison will remain incomplete")
 else:print("OK closed shadow outcomes are available for daily comparison")
 print("\nIMPORTANT: --run-once is a snapshot cycle, not a persistent tick runtime.")
 return 0
if __name__=="__main__":raise SystemExit(main())
