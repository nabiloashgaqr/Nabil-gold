"""Manual live-vs-shadow daily comparison (read-only live source).

Usage:
  python scripts/compare_live_vs_shadow.py
  python scripts/compare_live_vs_shadow.py --date 2026-09-06
  python scripts/compare_live_vs_shadow.py --date 2026-09-06 --send-telegram
"""
from __future__ import annotations
import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))

from services.database import DatabaseService
from services.telegram_bot import TelegramService
from shadow_market_architect.daily_integration import build_daily_shadow_comparison
from utils.helpers import load_config

OPEN={"OPEN","TP1_HIT","PARTIAL","PENDING"}

def closed_for_date(rows,date_text):
 out=[]
 for t in rows:
  status=str(t.get("status") or "").upper();closed=str(t.get("closed_at") or t.get("close_time") or "")
  created=str(t.get("created_at") or t.get("entry_time") or t.get("opened_at") or "")
  resolved=status not in OPEN and status!="CANCELLED"
  if status!="CANCELLED" and (closed.startswith(date_text) or (resolved and not closed and created.startswith(date_text))):out.append(t)
 return out

def main()->int:
 ap=argparse.ArgumentParser(description="Compare closed live trades with closed shadow families")
 ap.add_argument("--date",help="YYYY-MM-DD; defaults to today in configured schedule timezone")
 ap.add_argument("--send-telegram",action="store_true",help="Send the compact summary to the configured Telegram chat")
 ap.add_argument("--json",action="store_true",help="Also print a machine-readable summary")
 args=ap.parse_args();config=load_config();tz=str((config.get("schedule") or {}).get("timezone") or (config.get("trading_hours") or {}).get("timezone") or "Asia/Hebron")
 day=args.date or datetime.now(ZoneInfo(tz)).date().isoformat();datetime.strptime(day,"%Y-%m-%d")
 db=DatabaseService(config);rows=db.get_trades_for_date(day,tz);live=closed_for_date(rows,day)
 lines,path=build_daily_shadow_comparison(config,live,day,ROOT)
 if not lines:
  print("Shadow daily comparison is disabled. Run the phase-9 config merger or set shadow_market_architect.daily_comparison.enabled=true.");return 2
 print("\n".join(lines));print(f"Live source: {'Supabase/'+db.trades_table if db.use_supabase else db.local_path}");print(f"Detailed report: {path}")
 if args.json:print(json.dumps({"date":day,"live_closed":len(live),"summary_lines":lines,"report":str(path)},ensure_ascii=False,indent=2))
 if args.send_telegram:
  ok=TelegramService(config).send_message("\n".join(lines));print("Telegram: SENT" if ok else "Telegram: FAILED");return 0 if ok else 3
 return 0
if __name__=="__main__":raise SystemExit(main())
