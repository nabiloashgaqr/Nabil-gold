#!/usr/bin/env python3
"""Safely merge the final FX x1.5 law into an existing config.json.

Preserves unrelated server settings, creates a timestamped backup when a
change is needed, validates the result, and is idempotent.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

FX = {"EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"}
FX_STOP = {
    "enabled": True,
    "min_liquidity_points": 300,
    "safety_buffer_points": 105,
    "max_stop_points": 600,
}
FX_VALUES = {
    "distance_ratio": 1.5,
    "min_sl_distance_points": 600,
    "trailing_distance": 225,
    "trailing_step": 60,
    "early_breakeven_points": 225,
}


def _set(obj: dict[str, Any], key: str, value: Any, changes: list[str], label: str) -> None:
    if obj.get(key) != value:
        obj[key] = value
        changes.append(label)


def merge(config: dict[str, Any]) -> list[str]:
    changes: list[str] = []
    found: set[str] = set()
    for inst in config.get("instruments") or []:
        if not isinstance(inst, dict) or inst.get("symbol") not in FX:
            continue
        symbol = str(inst["symbol"])
        found.add(symbol)
        for key, value in FX_VALUES.items():
            _set(inst, key, value, changes, f"{symbol}.{key}")
        rules = inst.setdefault("trading_rules", {})
        stop = rules.setdefault("stop", {})
        for key, value in FX_STOP.items():
            _set(stop, key, value, changes, f"{symbol}.trading_rules.stop.{key}")
        targets = rules.setdefault("targets", {})
        _set(targets, "max_beyond_points", 300, changes,
             f"{symbol}.trading_rules.targets.max_beyond_points")
        trailing = rules.setdefault("trailing", {})
        for key, value in {"enabled": True, "distance_points": 225,
                           "step_points": 60, "early_breakeven_points": 225}.items():
            _set(trailing, key, value, changes, f"{symbol}.trading_rules.trailing.{key}")
        _set(rules.setdefault("protection", {}), "be_lock_points", 60, changes,
             f"{symbol}.trading_rules.protection.be_lock_points")
        _set(rules.setdefault("post_tp2", {}), "min_distance_points", 375, changes,
             f"{symbol}.trading_rules.post_tp2.min_distance_points")
        _set(inst.setdefault("auction_flow", {}), "calibration_required", True,
             changes, f"{symbol}.auction_flow.calibration_required")

    missing = FX - found
    if missing:
        raise ValueError(f"missing FX instrument blocks: {sorted(missing)}")

    tr = config.setdefault("trading_rules", {})
    stop_root = tr.setdefault("stop", {})
    _set(stop_root, "description",
         "Canonical stop law: XAU/USD 200/70/400 gives a 270-400 point band; "
         "WTI/USD is Gold x0.5 (100/35/200, band 135-200); FX is Gold x1.5 "
         "(300/105/600, band 405-600). Instrument blocks own their overrides.",
         changes, "trading_rules.stop.description")
    _set(tr, "description_distance_ratio",
         "Distance scaling law: XAU/USD x1.0, WTI/USD x0.5, FX x1.5. "
         "Runtime derives the ratio from each instrument stop cap.",
         changes, "trading_rules.description_distance_ratio")

    planner = config.setdefault("session_planner", {})
    _set(planner, "description_zone_width_vs_sl_floor",
         "Zone width and stop geometry use the instrument law: XAU/USD x1.0, "
         "WTI/USD x0.5, FX x1.5. No global Gold-only stop assumption.",
         changes, "session_planner.description_zone_width_vs_sl_floor")
    _set(planner, "description_standby_min_distance_150",
         "Gold-base standby distance is 150 points: XAU/USD 150, WTI/USD 75, FX 225.",
         changes, "session_planner.description_standby_min_distance_150")

    gates = config.setdefault("discipline_gates", {})
    bands = gates.setdefault("stop_band_by_symbol", {})
    for symbol in sorted(FX):
        if bands.get(symbol) != {"min_points": 405.0, "max_points": 600.0}:
            bands[symbol] = {"min_points": 405.0, "max_points": 600.0}
            changes.append(f"discipline_gates.stop_band_by_symbol.{symbol}")
    _set(gates, "description_stop_band",
         "Diagnostic/enforcement stop bands mirror the canonical instrument law: "
         "XAU/USD 270-400, WTI/USD 135-200, FX 405-600 points.",
         changes, "discipline_gates.description_stop_band")
    return changes


def validate(config: dict[str, Any]) -> None:
    rows = {str(i.get("symbol")): i for i in config.get("instruments") or []
            if isinstance(i, dict)}
    for symbol in FX:
        inst = rows[symbol]
        stop = ((inst.get("trading_rules") or {}).get("stop") or {})
        assert stop == FX_STOP, (symbol, stop)
        assert float(inst.get("distance_ratio")) == 1.5
        assert int(inst.get("min_sl_distance_points")) == 600
        assert int(inst.get("trailing_distance")) == 225
        assert int(inst.get("early_breakeven_points")) == 225
        band = ((config.get("discipline_gates") or {}).get("stop_band_by_symbol") or {})[symbol]
        assert float(band["min_points"]) == 405.0
        assert float(band["max_points"]) == 600.0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path,
                        default=Path(__file__).resolve().parent / "config.json")
    args = parser.parse_args(argv)
    path: Path = args.config.resolve()
    if not path.exists():
        parser.error(f"config not found: {path}")
    config = json.loads(path.read_text(encoding="utf-8-sig"))
    changes = merge(config)
    validate(config)
    if not changes:
        print("NO CHANGES: final FX x1.5 law is already unified")
        return 0
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup = path.with_name(f"{path.stem}.backup_before_R4_14_{stamp}{path.suffix}")
    shutil.copy2(path, backup)
    tmp = path.with_suffix(path.suffix + ".r4_14.tmp")
    tmp.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    json.loads(tmp.read_text(encoding="utf-8"))
    os.replace(tmp, path)
    print(f"BACKUP: {backup}")
    print(f"UPDATED: {path}")
    print(f"CHANGES: {len(changes)}")
    print("FINAL LAW: XAU x1.0 | WTI x0.5 | FX x1.5; FX stop band 405-600")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
