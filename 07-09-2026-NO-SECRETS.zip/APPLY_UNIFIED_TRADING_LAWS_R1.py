#!/usr/bin/env python3
"""RETIRED compatibility entry point.

The former R1 merger carried the cancelled FX ratio. It now delegates to
the final R4.14 x1.5 merger and can no longer restore the retired law.
"""
from APPLY_FINAL_FX_1_5_UNIFICATION_R4_14 import main


if __name__ == "__main__":
    print("NOTICE: legacy R1 law merger is retired; applying final FX x1.5.")
    raise SystemExit(main())
