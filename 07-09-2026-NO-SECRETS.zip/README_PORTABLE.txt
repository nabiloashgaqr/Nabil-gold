NABIL-GOLD PORTABLE BUNDLE
==========================
Contents: full code (R26.7, shadow mode removed) + your config.json +
.env (if present) + small runtime state (trade book, memory, path stats).
Excluded (regenerate automatically): auction-flow tick DBs (*.sqlite3),
caches, logs, diagnostics, archives/PDFs.

INSTALL ON A NEW MACHINE (Windows)
----------------------------------
1. Copy this whole folder to  C:\Nabil-gold
2. Install Python 3.11+ (tick "Add to PATH").
3. Open PowerShell in C:\Nabil-gold and run:
       powershell -NoProfile -ExecutionPolicy Bypass -File .\INSTALL_ON_NEW_SERVER.ps1
   (this installs requirements and runs the test suite.)
4. Review config.json (telegram token, chat_id, data keys, capital).
   If you have no .env, copy .env.template to .env and fill secrets.
5. Start the bots (scheduler / RESTART_ALL_SERVICES.ps1 as usual).

NOTES
-----
- config.json and .env CONTAIN SECRETS (telegram token, API keys).
  Do NOT upload this zip to any public place.
- Auction-flow tick history is intentionally excluded; the tick manager
  rebuilds the *.sqlite3 stores from live ticks automatically.
- PATH 6 (OTE) is LIVE in this build (it places real pending LIMITs).