#!/usr/bin/env python3
"""RETIRED compatibility entry point.

The former R26.9.3 merger wrote the cancelled FX ratio law. It is deliberately
redirected to the final R4.14 x1.5 merger so an old operator command cannot
restore the cancelled production values.
"""
from APPLY_FINAL_FX_1_5_UNIFICATION_R4_14 import main


if __name__ == "__main__":
    print("NOTICE: R26.9.3 is retired; applying the final FX x1.5 law instead.")
    raise SystemExit(main())
