# R4.18 Phase 5 — Documentation clarifications

## Volatility targeting switches

These are independent controls, not contradictory aliases:

- `volatility_agent.apply_risk_multiplier` belongs to the non-voting volatility agent and is emitted with its recommendation.
- `risk_settings.vol_targeting.enabled` is the switch actually read by `RiskManagementAgent` when multiplying position risk by `suggested_risk_multiplier`.

The current production configuration has both enabled intentionally. This phase does not change either value.

## News `risk_score = 8`

Eight is a deliberate non-zero SAFE baseline representing residual calendar/session uncertainty. It is not a detected event and not a probability percentage. Rules can only raise it. The established bands remain SAFE below 50, MEDIUM from 50 through 74, and HIGH from 75.

## ATR stop audit label

The old label `atr_1_5x` was only a stale name: execution already used `risk_settings.atr_multiplier_sl` (default 2.0). The audit label is now generated as `atr_<configured multiplier>x`; no stop formula changed.

## `arr_rsi_trend` enum note

No active occurrence of `arr_rsi_trend` exists in the reviewed runtime tree. The reported enum gap therefore remains an unproven maintenance observation, not a behavioural fix.

## Seven skipped tests

The complete suite currently reports seven intentional skips:

1. `test_analyst_labels_are_scoreable.py`: deployment contains no operator analyst-label dataset.
2. `test_dashboard_numbers_agree.py` (two cases): optional web API is absent from this checkout.
3. `test_dashboards_read_the_same_trades.py`: optional web API is absent from this checkout.
4. `test_protection_wired_to_tp1.py` (two pinned-card cases): retired fixture has a 150-point TP1 that cannot satisfy the later 270-point minimum stop/readiness law; equivalent live wiring remains covered by passing unit tests.
5. `test_revival_readiness_rejudged.py`: the same retired pinned-card geometry is intentionally excluded and covered by current readiness tests.

These skips do not conceal failures introduced by phases 1–5.

## Pre-Arm OTE

No Pre-Arm OTE code or configuration was changed in this phase.
