# Run once from an elevated PowerShell in C:\Nabil-gold.
# Converts existing non-GUI production tasks to hidden SYSTEM background jobs.
# Existing actions and triggers are preserved. MT5 remains interactive by design.
$ErrorActionPreference = 'Stop'

$BackgroundTasks = @(
    'Nabil Gold Dashboard',
    'SS_DemoAnalysis',
    'SS_DemoLoop',
    'SS_DemoWatchdog',
    'SS_TickManager',
    'SS_MacroContext',
    'SS_EIAFill',
    'SS_DailyReport',
    'SS_WeeklyReport',
    'SS_Dashboard',
    'SS_SubscriptionBot',
    'SS_AutoMaintenance'
)

$SystemPrincipal = New-ScheduledTaskPrincipal `
    -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest

foreach ($Name in $BackgroundTasks) {
    $Task = Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue
    if ($null -eq $Task) {
        Write-Warning "Missing task (not created): $Name"
        continue
    }
    # Rebuild only Settings; Actions and Triggers remain exactly as installed.
    $Settings = New-ScheduledTaskSettingsSet `
        -Hidden `
        -StartWhenAvailable `
        -RestartCount 999 `
        -RestartInterval (New-TimeSpan -Minutes 1) `
        -ExecutionTimeLimit ([TimeSpan]::Zero) `
        -MultipleInstances IgnoreNew
    Set-ScheduledTask -TaskName $Name -Principal $SystemPrincipal -Settings $Settings | Out-Null
    Enable-ScheduledTask -TaskName $Name | Out-Null
    Write-Host "BACKGROUND OK: $Name" -ForegroundColor Green
}

# MT5 cannot run as SYSTEM: it needs the logged-on Administrator desktop and profile.
$Mt5 = Get-ScheduledTask -TaskName 'SS_MT5Terminal' -ErrorAction SilentlyContinue
if ($null -ne $Mt5) {
    Enable-ScheduledTask -TaskName 'SS_MT5Terminal' | Out-Null
    Write-Host 'INTERACTIVE OK: SS_MT5Terminal kept unchanged' -ForegroundColor Cyan
} else {
    Write-Warning 'Missing task: SS_MT5Terminal'
}

# Start only persistent workers. Periodic jobs retain and follow their schedules.
foreach ($Name in @('Nabil Gold Dashboard','SS_DemoLoop','SS_TickManager')) {
    $Task = Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue
    if ($null -ne $Task -and $Task.State -ne 'Running') {
        Start-ScheduledTask -TaskName $Name
    }
}

Start-Sleep -Seconds 5
Write-Host "`nPERSISTENT TASKS:" -ForegroundColor Yellow
Get-ScheduledTask -TaskName 'Nabil Gold Dashboard','SS_DemoLoop','SS_TickManager','SS_MT5Terminal' |
    Select-Object TaskName,State

Write-Host "`nRun verification:" -ForegroundColor Yellow
Write-Host 'python scripts\system_healthcheck.py'
