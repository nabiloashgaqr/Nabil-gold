"""Shared pytest fixtures.

NewsRiskAgent transparently pulls a free ForexFactory calendar over the network
as a fallback news source. That makes any test touching NewsRiskAgent flaky and
non-deterministic: when a real high-impact event (e.g. an FOMC speech) happens
to be near "now", tests expecting SAFE/CAUTION suddenly see DANGER.

The autouse fixture below stubs that network call to return no events by
default, so news tests exercise only their own seeded data. Tests that want to
verify the ForexFactory path explicitly still override it with their own
``monkeypatch.setattr(...)`` inside the test, which takes precedence.
"""

from __future__ import annotations

import os
import sys
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import os
import sys

# Ensure project root is always in sys.path on all platforms (Windows/Linux)

import asyncio
import inspect

import pytest

#: Environment variables that ``scripts/run_analysis.py`` (and friends) load
#: from the operator's real ``.env`` via ``load_dotenv()`` at import time.
#: Leaking them into the test process makes results depend on IMPORT ORDER:
#: e.g. ``tests/test_services.py`` builds a TelegramService with
#: ``bot_token=None`` and expects ``False``, but a real TELEGRAM_BOT_TOKEN in
#: the environment silently wins; likewise EXECUTION_MODE=mt5_demo re-routes
#: the delivery path in ``test_signal_delivery``. Tests that genuinely need
#: one of these set it explicitly with ``monkeypatch.setenv`` which runs after
#: this fixture and therefore takes precedence.
_DOTENV_LEAK_VARS = (
    "TELEGRAM_BOT_TOKEN",
    "TELEGRAM_CHAT_ID",
    "TELEGRAM_DEMO_CHAT_ID",
    "EXECUTION_MODE",
    "GEMINI_API_KEY",
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "TWELVEDATA_API_KEY",
    "SUPABASE_URL",
    "SUPABASE_KEY",
)


@pytest.fixture(autouse=True)
def _isolate_dotenv_environment(monkeypatch):
    """Strip operator ``.env`` values so tests are deterministic and offline."""
    for name in _DOTENV_LEAK_VARS:
        monkeypatch.delenv(name, raising=False)


@pytest.fixture(autouse=True)
def _isolate_session_state(monkeypatch):
    """R25.12: hermetic session state for EVERY test.

    - argv starts clean and is restored afterwards: an in-process CLI
      (argparse) can never parse a foreign/leaked --root again (the R25.9
      VPS failure class, closed structurally).
    - the Gemini review service's class-level latches are reset before
      each test, so persistence tests are order-independent.
    """
    monkeypatch.setattr(sys, "argv", ["pytest"])
    try:
        import services.llm_review as _llm
        _llm.GeminiReviewService.reset_quota_state()
    except Exception:  # noqa: BLE001 - the module may not be importable yet
        pass
    yield
    try:
        import services.llm_review as _llm2
        _llm2.GeminiReviewService.reset_quota_state()
    except Exception:  # noqa: BLE001
        pass


@pytest.fixture(autouse=True)
def _isolate_mt5_halt_file(monkeypatch, tmp_path):
    """A real VPS .demo_halt must not disable fake-terminal unit tests."""
    try:
        import services.mt5_executor as executor
        monkeypatch.setattr(executor, "HALT_FILE", str(tmp_path / ".demo_halt"))
    except Exception:  # noqa: BLE001
        pass


@pytest.fixture(autouse=True)
def _mark_pytest_running(monkeypatch):
    """R25.6: declare pytest in the environment.

    The production decision-audit writer refuses the code-tree audit file
    while this flag is set (belt over the store-root fix), so the suite can
    never contaminate the operator's court record again.
    """
    monkeypatch.setenv("PYTEST_RUNNING", "1")


@pytest.fixture(autouse=True)
def _stub_forexfactory_feed(monkeypatch):
    """Disable the live ForexFactory network fetch for all tests by default."""
    try:
        import services.news_feed_forexfactory as ff
    except Exception:  # noqa: BLE001 - module may not import in some envs
        return
    monkeypatch.setattr(ff, "fetch_forexfactory_events", lambda *a, **k: [], raising=False)


def pytest_pyfunc_call(pyfuncitem):
    """Run ``async def`` tests even when pytest-asyncio is not installed.

    The project declares ``pytest-asyncio`` as a test dependency and uses
    ``@pytest.mark.asyncio``/``async def`` tests.  Some lightweight CI or review
    environments install only pytest itself, which otherwise fails with
    "async def functions are not natively supported" before the application code
    is exercised.  This minimal hook keeps the suite runnable in those
    environments while remaining compatible with pytest-asyncio: if the real
    plugin is present it can still provide its richer fixture support.
    """
    test_func = pyfuncitem.obj
    if not inspect.iscoroutinefunction(test_func):
        return None
    fixture_names = pyfuncitem._fixtureinfo.argnames
    kwargs = {name: pyfuncitem.funcargs[name] for name in fixture_names}
    asyncio.run(test_func(**kwargs))
    return True