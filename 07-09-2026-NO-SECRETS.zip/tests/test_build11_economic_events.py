"""2026-08-19 build 11: economic-events filler + macro surprise layer ON."""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import scripts.fill_economic_events as fe  # noqa: E402
from agents.macro_fundamental_agent import MacroFundamentalAgent  # noqa: E402

FF_XML = """<?xml version="1.0" encoding="UTF-8"?>
<weeklyevents>
  <event>
    <title>CPI m/m</title><country>USD</country>
    <date>08-12-2026</date><time>8:30am</time>
    <impact>High</impact><forecast>0.3%</forecast><previous>0.2%</previous>
  </event>
  <event>
    <title>Non-Farm Employment Change</title><country>USD</country>
    <date>08-07-2026</date><time>8:30am</time>
    <impact>High</impact><forecast>185K</forecast><previous>147K</previous>
  </event>
  <event>
    <title>FOMC Statement</title><country>USD</country>
    <date>08-05-2026</date><time>2:00pm</time>
    <impact>High</impact><forecast>0.00%</forecast><previous>4.50%</previous>
  </event>
  <event>
    <title>German ZEW Economic Sentiment</title><country>EUR</country>
    <date>08-11-2026</date><time>9:00am</time>
    <impact>Medium</impact><forecast>15.0</forecast><previous>12.0</previous>
  </event>
  <event>
    <title>Unemployment Claims</title><country>USD</country>
    <date>08-14-2026</date><time>8:30am</time>
    <impact>Medium</impact><forecast>240K</forecast><previous>233K</previous>
  </event>
</weeklyevents>
"""

# Pin the fixture's observation date. Without this, its August 2026 FOMC row
# crossed max_age_days as the real clock advanced and made the suite flaky.
FIXTURE_NOW = datetime(2026, 8, 15, tzinfo=timezone.utc)


class TestParseFFEvents:
    def test_tier1_usd_only_with_forecast(self):
        events = fe.parse_ff_events(FF_XML, max_age_days=30, now=FIXTURE_NOW)
        kinds = sorted({e["kind"] for e in events})
        assert kinds == ["CPI", "FOMC", "NFP", "NFP"] or kinds == ["CPI", "FOMC", "NFP"]
        # EUR event excluded
        assert not any("ZEW" in e["event"] for e in events)
        # every entry has actual=None (FF feed has no actuals)
        assert all(e["actual"] is None for e in events)
        cpi = next(e for e in events if e["kind"] == "CPI")
        assert cpi["forecast"] == "0.3%"

    def test_stale_outside_window_excluded(self):
        events = fe.parse_ff_events(FF_XML, max_age_days=0.001, now=FIXTURE_NOW)  # ~86 seconds
        assert events == []

    def test_bad_xml_returns_empty(self):
        assert fe.parse_ff_events("not xml", max_age_days=30) == []


class TestMergeEvents:
    def test_upsert_preserves_actual(self):
        existing = [{"event": "CPI m/m", "date": "2026-08-12",
                     "forecast": "0.3%", "actual": "0.5%", "source": "operator"}]
        fetched = fe.parse_ff_events(FF_XML, max_age_days=30, now=FIXTURE_NOW)
        merged = fe.merge_events(existing, fetched)
        cpi = next(e for e in merged if e["event"] == "CPI m/m")
        assert cpi["actual"] == "0.5%"  # operator actual survives the sync
        assert cpi["source"] == "forexfactory"

    def test_new_entries_appended(self):
        merged = fe.merge_events([], fe.parse_ff_events(FF_XML, max_age_days=30, now=FIXTURE_NOW))
        assert len(merged) >= 3

    def test_non_dict_rows_dropped(self):
        merged = fe.merge_events([{"junk": 1}, None], [])
        assert merged == []


class TestFileIO:
    def test_load_save_roundtrip(self, tmp_path):
        fe.save_file(tmp_path, [{"event": "CPI m/m", "date": "2026-08-12",
                                 "forecast": "0.3%", "actual": "0.5%"}])
        rows = fe.load_file(tmp_path)
        assert rows[0]["actual"] == "0.5%"

    def test_missing_file_returns_empty(self, tmp_path):
        assert fe.load_file(tmp_path) == []


class TestMacroSurpriseLayer:
    def _agent(self, tmp_path, events):
        path = tmp_path / "events.json"
        path.write_text(json.dumps(events), encoding="utf-8")
        return MacroFundamentalAgent({
            "macro_economic_events": {"enabled": True, "path": str(path), "max_age_days": 7},
        })

    def test_hot_cpi_and_weak_nfp_break_neutrality(self, tmp_path):
        from datetime import datetime, timedelta, timezone

        now = datetime.now(timezone.utc)
        events = [
            {"event": "CPI m/m", "forecast": 0.3, "actual": 0.6,
             "date": (now - timedelta(days=1)).strftime("%Y-%m-%d")},
            {"event": "Non-Farm Employment Change", "forecast": 185, "actual": 120,
             "date": (now - timedelta(days=2)).strftime("%Y-%m-%d")},
        ]
        agent = self._agent(tmp_path, events)
        d = agent.macro_direction({"dxy_trend": "flat"})
        assert d["confidence_breakdown"]["events"] == 2.0  # capped
        assert d["bias"] == "BULLISH_GOLD"
        assert any("CPI" in r for r in d["drivers"])

    def test_no_actual_no_score(self, tmp_path):
        from datetime import datetime, timedelta, timezone

        now = datetime.now(timezone.utc)
        events = [{"event": "CPI m/m", "forecast": 0.3, "actual": None,
                   "date": (now - timedelta(days=1)).strftime("%Y-%m-%d")}]
        agent = self._agent(tmp_path, events)
        d = agent.macro_direction({"dxy_trend": "flat"})
        assert d["confidence_breakdown"]["events"] == 0.0

    def test_production_config_enabled(self):
        cfg_path = Path(__file__).resolve().parents[1] / "config.json"
        prod = json.loads(cfg_path.read_text(encoding="utf-8"))
        assert (prod.get("macro_economic_events") or {}).get("enabled") is True
