# =====================================================================
#  R26.7 - Remove the shadow-mode keys from config.json AND delete all
#          legacy shadow files/tests.
#  Run from inside C:\Nabil-gold:
#     powershell -NoProfile -ExecutionPolicy Bypass -File .\R26_7_REMOVE_SHADOW.ps1
#
#  Safe: backs up config.json, validates JSON after editing (auto-rollback
#  on failure), and only deletes files in the explicit list below.
#  ASCII-only on purpose so Windows PowerShell 5.1 parses it regardless
#  of system code page.
# =====================================================================
$ErrorActionPreference = "Stop"
$root = "C:\Nabil-gold"
if (-not (Test-Path $root)) { throw "Project folder not found: $root" }
Set-Location $root

function Section($t) { Write-Host ""; Write-Host "=== $t ===" -ForegroundColor Cyan }

# ---------------------------------------------------------------------
# 1) config.json: drop "shadow": true  and  "measure_levels": [ ... ]
#    from the pre_arm_ote block (leaves "enabled": true intact).
# ---------------------------------------------------------------------
Section "1) Editing config.json"
$cfg = Join-Path $root "config.json"
if (-not (Test-Path $cfg)) { throw "config.json not found in $root" }

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$bak   = Join-Path $root ("config.backup_before_shadow_removal_" + $stamp + ".json")
Copy-Item $cfg $bak -Force
Write-Host ("Backup created: " + $bak) -ForegroundColor Green

$text = [System.IO.File]::ReadAllText($cfg, [System.Text.Encoding]::UTF8)
$orig = $text

# Remove the line:  "shadow": true,
$text = [System.Text.RegularExpressions.Regex]::Replace(
    $text, '(?m)^\s*"shadow"\s*:\s*true\s*,?\s*\r?\n', '')

# Remove the line:  "measure_levels": [ ... ],
$text = [System.Text.RegularExpressions.Regex]::Replace(
    $text, '(?m)^\s*"measure_levels"\s*:\s*\[[^\]]*\]\s*,?\s*\r?\n', '')

# Clean up a trailing comma that could be left before a closing brace.
$text = [System.Text.RegularExpressions.Regex]::Replace(
    $text, ',\s*(\r?\n\s*})', '$1')

# Validate JSON before saving.
try {
    $null = $text | ConvertFrom-Json
} catch {
    Write-Host "JSON validation failed after edit - restoring backup." -ForegroundColor Red
    Copy-Item $bak $cfg -Force
    throw ("Invalid JSON: " + $_.Exception.Message)
}

if ($text -ne $orig) {
    [System.IO.File]::WriteAllText($cfg, $text, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host "Removed 'shadow' and 'measure_levels' from config.json." -ForegroundColor Green
} else {
    Write-Host "Keys not found (maybe already removed) - no change." -ForegroundColor Yellow
}

if ($text -match '"shadow"') {
    Write-Host "WARNING: a 'shadow' key still exists in config.json - check manually." -ForegroundColor Yellow
} else {
    Write-Host "Confirmed: no 'shadow' key remains in config.json." -ForegroundColor Green
}

# ---------------------------------------------------------------------
# 2) Delete legacy shadow service / scripts / tests / data
# ---------------------------------------------------------------------
Section "2) Deleting legacy shadow files and tests"
$shadowPaths = @(
    "services\shadow_mode.py",
    "scripts\shadow_report.py",
    "scripts\review_shadow_trades.py",
    "scripts\run_demo_cycle.py",
    "scripts\demo_compare_report.py",
    "scripts\verify_r10_fixes.py",
    "APPLY_R11_PATCH.py",
    "APPLY_R13_EVIDENCE_SHADOW.ps1",
    "tests\test_shadow_mode_wti.py",
    "tests\test_build31r6_path6_shadow.py",
    "tests\test_demo_compare.py",
    "tests\test_inspect_running_modes.py",
    "storage\r25_scalp_shadow.jsonl",
    "pre_arm_ote_shadow_arms.jsonl",
    "storage\shadow"
)

foreach ($rel in $shadowPaths) {
    $p = Join-Path $root $rel
    if (Test-Path $p) {
        try {
            Remove-Item $p -Recurse -Force -ErrorAction Stop
            Write-Host ("  deleted: " + $rel) -ForegroundColor Green
        } catch {
            Write-Host ("  could not delete " + $rel + " : " + $_.Exception.Message) -ForegroundColor Yellow
        }
    } else {
        Write-Host ("  not present (skip): " + $rel) -ForegroundColor DarkGray
    }
}

Write-Host ""
Write-Host "Done. Next steps:" -ForegroundColor Cyan
Write-Host "  - Copy the R26.7 code files over the old ones (services / agents / scripts / utils / tests)."
Write-Host "  - Restart the analysis bot and the tick manager."
Write-Host "  - Optional: run   python -m pytest -q   to verify the suite."
