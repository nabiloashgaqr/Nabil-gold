#!/usr/bin/env python3
"""Merge the FX x1.5 law into config.json, preserving all unrelated settings."""
from __future__ import annotations
import json, os, shutil, sys
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FX={"EUR/USD","GBP/USD","USD/CAD","USD/JPY"}
VALUES={
 "distance_ratio":1.5,"min_sl_distance_points":600,"trailing_distance":225,
 "trailing_step":60,"early_breakeven_points":225,
}

def main()->int:
 p=ROOT/'config.json'
 if not p.exists(): print('ERROR: config.json missing',file=sys.stderr); return 2
 c=json.loads(p.read_text(encoding='utf-8-sig')); changed=[]
 for inst in c.get('instruments') or []:
  if not isinstance(inst,dict) or inst.get('symbol') not in FX: continue
  inst.update(VALUES)
  tr=inst.setdefault('trading_rules',{})
  tr.setdefault('stop',{}).update({"enabled":True,"min_liquidity_points":300,"safety_buffer_points":105,"max_stop_points":600})
  tr.setdefault('targets',{}).update({"max_beyond_points":300})
  tr.setdefault('trailing',{}).update({"enabled":True,"distance_points":225,"step_points":60,"early_breakeven_points":225})
  tr.setdefault('protection',{}).update({"be_lock_points":60})
  tr.setdefault('post_tp2',{}).update({"min_distance_points":375})
  sp=inst.setdefault('session_planner',{})
  sp.update({"fallback_zone_half_width_points":180,"standby_min_distance_points":225,
             "max_primary_zone_width_points":675,"max_standby_zone_width_points":675,
             "min_zone_width_points":9.0,"min_entry_zone_width_points":90,
             "min_thesis_objective_points":45})
  changed.append(inst['symbol'])
 if set(changed)!=FX:
  print('ERROR: missing FX instrument blocks: '+str(sorted(FX-set(changed))),file=sys.stderr); return 2
 # descriptions only; no broad numeric replacement.
 for obj in [c.get('session_planner') or {}, c.get('trading_rules') or {}]:
  for k,v in list(obj.items()):
   if isinstance(v,str) and ('×1.8' in v or 'x1.8' in v): obj[k]=v.replace('×1.8','×1.5').replace('x1.8','x1.5')
 stamp=datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
 backup=p.with_name(f'config.backup_fx_1_5_{stamp}.json'); shutil.copy2(p,backup)
 tmp=p.with_suffix('.json.fx15.tmp'); tmp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 json.loads(tmp.read_text(encoding='utf-8')); os.replace(tmp,p)
 print('BACKUP:',backup); print('FX LAW: XAU x1.0 | WTI x0.5 | FX x1.5')
 print('FX stop=405..600 pts; trail=225/60; early-BE=225; BE lock=60; post-TP2=375')
 print('LOT SIZING: unchanged and automatic from actual entry-to-stop risk distance')
 return 0
if __name__=='__main__': raise SystemExit(main())
