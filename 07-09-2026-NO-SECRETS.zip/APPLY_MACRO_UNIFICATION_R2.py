# -*- coding: utf-8 -*-
"""Safely merge the unified macro policy into config.json (idempotent)."""
from __future__ import annotations
import json, shutil
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PATH = ROOT / "config.json"

def main():
    if not PATH.exists():
        raise SystemExit(f"ERROR: missing {PATH}")
    cfg = json.loads(PATH.read_text(encoding="utf-8-sig"))
    cfg["macro_policy"] = {
        "entry_confirmation_confidence": 55,
        "entry_veto_confidence": 60,
        "exit_veto_confidence": 60,
        "min_evidence_inputs": 3,
        "future_timestamp_tolerance_minutes": 5,
        "flip_guard_persist": True,
        "flip_guard_hours": 4,
        "description": "Single source for macro confirmation, veto and data-quality thresholds.",
    }
    two = cfg.setdefault("signal_requirements", {}).setdefault("two_agent_entry", {})
    two.setdefault("macro_confirmation", {})["min_confidence"] = 55
    two["macro_veto"] = {
        "min_confidence": 60,
        "description": "Compatibility alias; canonical value is macro_policy.entry_veto_confidence.",
    }
    cfg.setdefault("discipline_gates", {})["macro_block_conf"] = 60
    cfg["macro_stall"] = {"flip_guard_persist": True, "flip_guard_hours": 4.0}
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = PATH.with_name(f"config.backup_macro_R2_{stamp}.json")
    shutil.copy2(PATH, backup)
    tmp = PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(PATH)
    print("OK: unified macro policy merged")
    print(f"BACKUP: {backup.name}")
    print("confirmation=55, entry-veto=60, exit-veto=60, min-evidence=3, flip-guard=4h/persistent")

if __name__ == "__main__":
    main()
