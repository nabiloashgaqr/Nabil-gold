# -*- coding: utf-8 -*-
"""R26 admission-discipline gates (2026-08-31).

Pure, unit-testable, config-driven, fail-OPEN checks that sit at the single
point a directional signal becomes real (``validate_signal_before_send`` in
run_analysis already returns the violation list every route is rejected on).

They are deliberately NOT strategy opinions and they never invent numbers:

  1. counter_macro_block      — refuse a direction the macro fundamental
     agent opposes at >= ``macro_block_conf`` while the confirming witnesses
     are unable to overrule (auction tape dead/refused for that symbol AND
     SMC not a qualified supporter). This is the live loss pattern: a trend
     "consensus" BUY on yen while the tape was FOREIGN_FEED_REFUSED / dead,
     and a WTI BUY vs a SELL 74% macro with SMC WAIT.

  2. trend_family_only_block   — refuse a non-auction "consensus" when every
     qualified supporter is a single trend family and the auction tape is
     dead/refused (a family of look-alike votes must not substitute for the
     dead tape on forex/oil).

  3. stop_distance_band        — the configured per-symbol stop distance
     [min,max] in points must hold (the documented law is gold [270,400],
     forex+oil [230,330]; a WTI 116-pt stop shipped anyway).

  4. rr_floor                  — tp2 must clear ``risk_settings.min_rr_ratio``
     (a 1.48R yen trade shipped under a 1.5 floor).

  5. thesis_exit_loss_cap      — (enforced by the manager, surfaced here as a
     read of config) the maximum USD a thesis-exit may surrender before it
     must close like a stop; pure helper only.

Every gate reads config under a single ``discipline_gates`` block; absent or
``enabled: false`` it returns no violation (fail-open). No gate touches PATH 9
admission logic, weights, or the regime switcher; the auction remains a
confirmer (never a voter) elsewhere.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from utils.instruments import (
    normalize_symbol, price_to_points, get_instrument,
)


# ── config ──────────────────────────────────────────────────────────────────

DEFAULTS: Dict[str, Any] = {
    "enabled": True,
    "macro_block_conf": 55.0,
    # trend families (look-alike votes); any supporter outside this set means
    # the "consensus" is genuinely multi-family and the gate does not fire.
    "trend_family_keys": ["technical", "mtf", "classical", "price_action"],
    # The stop-distance band and the hard R:R floor are NOT enforced here by
    # default: the stop is set by the liquidity planning law (a scalp or a
    # resting-ladder stop may legitimately be tighter) and the final validator
    # already enforces R:R with the scalp's OWN floors. Flipping these to true
    # turns them into hard admission vetoes on top of that (operator opt-in).
    "enforce_stop_band": False,
    "enforce_rr_floor": False,
    "stop_band_default": {"min_points": 230.0, "max_points": 400.0},
    "stop_band_by_symbol": {},
    "thesis_exit_loss_cap_usd": 100.0,
}

TREND_FAMILY_ALIASES = {
    "technical": "technical", "tech": "technical",
    "mtf": "mtf", "multitimeframe": "mtf", "multi_timeframe": "mtf", "multitf": "mtf",
    "classical": "classical", "classic": "classical",
    "price_action": "price_action", "pa": "price_action",
    "priceaction": "price_action",
}


def gate_config(config: Dict[str, Any] | None) -> Dict[str, Any]:
    """Merge the ``discipline_gates`` block over the fail-open defaults."""
    cfg = dict(DEFAULTS)
    block = ((config or {}).get("discipline_gates") or {})
    if isinstance(block, dict):
        for k, v in block.items():
            if v is not None:
                cfg[k] = v
    return cfg


def _f(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


# ── decision readers (defensive; all fail-open to neutral) ──────────────────

def _side(decision: Dict[str, Any]) -> str:
    return str(decision.get("decision") or (decision.get("signal") or {}).get("type")
               or "").upper()


# R26.9: macro routing lives in ONE place (services/macro_voice.py) so the
# hard veto, the exit-mirror veto and the post-decision auditor can never
# read different fundamental voices for the same symbol.
from services.macro_policy import macro_policy
from services.macro_voice import macro_voice as _macro_voice


def _macro(decision, all_results=None, config=None):
    # Legacy shape kept for internal callers: {bias, conf}; bias is BUY/SELL/'".
    v = _macro_voice(decision, all_results, config)
    return {"bias": v.get("side") or "", "conf": float(v.get("conf") or 0.0)}


def _auction_state(decision: Dict[str, Any], all_results: Dict[str, Any] | None = None) -> str:
    """Classify the auction tape for this decision's symbol.

    Returns one of: "ok" (qualified/available), "dead" (not qualified /
    refused / no weight / foreign feed), "unknown".
    """
    # explicit stamped state on the decision wins
    for key in ("auction_state", "flow_state", "auction_status"):
        v = str(decision.get(key) or "").upper()
        if v:
            if any(tok in v for tok in ("REFUSED", "STALE", "DEAD", "INVALID",
                                        "NO_TAPE", "CALIBRATION", "WAIT", "WEIGHT_0")):
                return "dead"
            if any(tok in v for tok in ("OK", "LIVE", "CONFIRM", "RESPONSIVE", "QUALIFIED")):
                return "ok"
    af = decision.get("auction_flow") if isinstance(decision.get("auction_flow"), dict) else {}
    if af:
        if af.get("foreign_feed_refused") or af.get("refused") or af.get("dead"):
            return "dead"
        w = _f(af.get("weight", af.get("weight_pct", 1.0)), -1.0)
        if w == 0.0:
            return "dead"
    # look at the agent result if supplied
    if isinstance(all_results, dict):
        agent = None
        for k in ("auction_flow", "auction", "flow"):
            if isinstance(all_results.get(k), dict):
                agent = all_results[k]
                break
        if isinstance(agent, dict):
            state = str(agent.get("state") or agent.get("status") or "").upper()
            if any(tok in state for tok in ("REFUSED", "STALE", "DEAD", "INVALID", "WAIT", "NO_TAPE")):
                return "dead"
            w = _f(agent.get("weight", agent.get("weight_pct", 1.0)), -1.0)
            if w == 0.0:
                return "dead"
            d = str(agent.get("direction") or "").upper()
            if d in {"BUY", "SELL"}:
                return "ok"
    return "unknown"


def _smc_qualified(decision: Dict[str, Any],
                   all_results: Dict[str, Any] | None = None,
                   min_conf: float = 65.0) -> bool:
    """True only when SMC/structure is a QUALIFIED supporter of the thesis.

    SMC is the confirming family (not a voter); a SMC WAIT cannot overrule a
    dead tape or strong macro opposition.
    """
    side = _side(decision)
    # stamped supporters may carry agent directions
    support = decision.get("support_agents") or decision.get("supporters") or []
    if isinstance(support, list):
        for s in support:
            key = str(s).lower()
            if "smc" in key or "structure" in key:
                return True  # already counted as a supporter by admission
    # inspect the smc agent result directly
    src = all_results if isinstance(all_results, dict) else {}
    smc = None
    for k in ("smc", "structure", "smart_money", "market_structure"):
        if isinstance(src.get(k), dict):
            smc = src[k]
            break
    if isinstance(smc, dict):
        d = str(smc.get("direction") or smc.get("bias") or "").upper()
        c = _f(smc.get("confidence"))
        if d == side and c >= min_conf:
            return True
    # some paths store smc inside market_context / decision
    md = decision.get("smc") if isinstance(decision.get("smc"), dict) else {}
    if md:
        d = str(md.get("direction") or md.get("bias") or "").upper()
        c = _f(md.get("confidence"))
        if d == side and c >= min_conf:
            return True
    return False


def _supporter_families(decision: Dict[str, Any],
                        all_results: Dict[str, Any] | None = None) -> List[str]:
    """Normalised family keys for every qualified directional supporter."""
    fams: List[str] = []
    raw = decision.get("support_agents") or decision.get("supporters") or []
    if not isinstance(raw, list):
        raw = []
    for item in raw:
        key = ""
        if isinstance(item, str):
            key = item
        elif isinstance(item, dict):
            key = str(item.get("key") or item.get("agent") or item.get("id") or "")
        norm = TREND_FAMILY_ALIASES.get(str(key).lower().replace("-", "_")) \
            or TREND_FAMILY_ALIASES.get(str(key).lower().replace(" ", "_"))
        if norm:
            fams.append(norm)
        elif str(key):
            fams.append(str(key).lower())
    # also derive from per-agent results if provided
    if isinstance(all_results, dict):
        for k, v in all_results.items():
            if not isinstance(v, dict):
                continue
            d = str(v.get("direction") or "").upper()
            if d in {"BUY", "SELL"} and d == _side(decision) \
               and _f(v.get("confidence")) >= 65.0:
                nk = TREND_FAMILY_ALIASES.get(str(k).lower())
                fams.append(nk or str(k).lower())
    # dedupe preserve order
    seen, out = set(), []
    for f in fams:
        if f not in seen:
            seen.add(f)
            out.append(f)
    return out


# ── gates ───────────────────────────────────────────────────────────────────

def counter_macro_block(decision: Dict[str, Any], config: Dict[str, Any],
                        all_results: Dict[str, Any] | None = None) -> Optional[str]:
    """R26.2 (operator order 2026-08-31): HARD macro veto before any execution.

    The macro fundamental agent is the fundamental-regime voice. If it commits
    to a direction at/above ``macro_block_conf`` (operator set it to 55%), NO
    path may place a trade the other way - not Path 1 consensus, not the SMC
    map, not a reversal. There is deliberately no tape/SMC overrule: a live
    tape or qualified SMC against a confident macro is exactly the counter-
    trend trap the gold BUY fell into (macro SELL 74%, order BUY). The trade
    is refused; the macro verdict is never a voter in the other direction.
    """
    g = gate_config(config)
    if not g.get("enabled", True):
        return None
    side = _side(decision)
    if side not in {"BUY", "SELL"}:
        return None
    # Operator order (2026-08-31): the macro veto is HARD on every path EXCEPT
    # Path 9 liquidity-sweep reversal and the R25-2 scalp. Those two exist to
    # take the turn against the prior regime (Path 9 already requires an
    # auction-flow witness + SMC confirmation; the scalp is a separate small
    # fade outside the day-map thesis). Everything else may not trade against
    # a confident macro verdict.
    path = str(decision.get("execution_path_id")
               or (decision.get("signal") or {}).get("execution_path_id")
               or "").upper()
    if "PATH_9" in path or "SCALP" in path:
        return None
    macro = _macro(decision, all_results, config)
    floor = macro_policy(config)["entry_veto_confidence"]
    if not macro["bias"] or macro["bias"] == side or macro["conf"] < floor:
        return None
    return (f"HARD MACRO VETO: order is {side} but macro reads {macro['bias']} "
            f"at {macro['conf']:.0f}% (>= {floor:.0f}% floor); no path trades against a "
            f"confident macro-regime verdict")


def _trend_direction(all_results: Dict[str, Any] | None) -> str:
    """Higher-timeframe trend side from the MTF agent (BUY/SELL/'').

    Fail-open to neutral: only a confident qualified MTF read counts.
    """
    if not isinstance(all_results, dict):
        return ""
    mtf = all_results.get("multitimeframe") or all_results.get("mtf") or {}
    if isinstance(mtf, dict):
        d = str(mtf.get("direction") or mtf.get("alignment") or "").upper()
        if d in {"BUY", "SELL"} and _f(mtf.get("confidence")) >= 65.0:
            return d
        # FULL/PARTIAL alignment with a bias side
        if str(mtf.get("direction") or "").upper() in {"BUY", "SELL"}:
            return str(mtf.get("direction")).upper()
    return ""


def setup_direction_contradiction_block(decision: Dict[str, Any], config: Dict[str, Any],
                                        all_results: Dict[str, Any] | None = None) -> Optional[str]:
    """R26.2 (2026-08-31): refuse a label/direction self-contradiction.

    Live defect: in a confirmed DOWN move the SMC book labelled the setup
    CONTINUATION_BREAKDOWN (a bearish continuation = SELL with the down trend)
    yet the order was BUY (a counter-trend pullback mistaken for a reversal).
    A CONTINUATION_BREAKDOWN entry must agree with the higher-timeframe trend;
    a counter-trend fill under that label is rejected. Reversal setups
    (LIQUIDITY_REVERSAL / FAILED_RECLAIM) are intentionally NOT gated here -
    they are designed to trade the turn and must clear their own confirmations
    (macro veto, SMC, auction) instead.
    """
    g = gate_config(config)
    if not g.get("enabled", True):
        return None
    side = _side(decision)
    if side not in {"BUY", "SELL"}:
        return None
    setup = str(decision.get("setup_type")
                or (decision.get("planner_execution_gate") or {}).get("setup_type")
                or (decision.get("signal") or {}).get("setup_type") or "").upper()
    if "CONTINUATION_BREAKDOWN" not in setup:
        return None
    trend = _trend_direction(all_results)
    if not trend:
        return None  # no confirmed higher-timeframe side -> neutral, don't guess
    if trend != side:
        return (f"setup/direction contradiction: {setup} is a "
                f"{'BEARISH' if trend == 'SELL' else 'BULLISH'}-trend continuation "
                f"(trend={trend}) but the order is {side}; a counter-trend fill "
                f"must be a LIQUIDITY_REVERSAL with its own confirmations")
    return None


def trend_family_only_block(decision: Dict[str, Any], config: Dict[str, Any],
                            all_results: Dict[str, Any] | None = None) -> Optional[str]:
    g = gate_config(config)
    if not g.get("enabled", True):
        return None
    side = _side(decision)
    if side not in {"BUY", "SELL"}:
        return None
    path = str(decision.get("execution_path_id") or "").upper()
    # Path 9/4/5 have their own tape mandate; this guards consensus paths.
    if not ("THREE_AGENT" in path or path == "" or "CONSENSUS" in path):
        return None
    tape = _auction_state(decision, all_results)
    if tape != "dead":
        return None  # only fire when the tape cannot witness at all
    fams = _supporter_families(decision, all_results)
    if len(fams) < 2:
        return None  # not a claimed multi-agent consensus
    trend = set(str(x).lower() for x in (g.get("trend_family_keys") or []))
    if all(f in trend for f in fams):
        return (f"all {len(fams)} supporters are one trend family {fams} while the "
                f"auction tape is dead; trend votes cannot substitute for the tape")
    return None


def path23_two_family_block(decision: Dict[str, Any], config: Dict[str, Any],
                            all_results: Dict[str, Any] | None = None) -> Optional[str]:
    """Final invariant: Paths 2/3 require core supporters from two families.

    Gemini/macro/auction are external confirmers, never the missing second
    core family. This repeats the consensus-stage rule at the final execution
    choke point so stale/stamped decisions cannot bypass it.
    """
    path = str(decision.get("execution_path_id")
               or (decision.get("signal") or {}).get("execution_path_id")
               or "").upper()
    if "PATH_2" not in path and "PATH_3" not in path and \
       "TWO_AGENT_MACRO" not in path and "TWO_AGENT_GEMINI" not in path:
        return None
    fd = ((config.get("signal_requirements") or {}).get("family_diversity") or {})
    if not bool(fd.get("path23_require_two_families", True)):
        return None
    side = _side(decision)
    family_map = {
        "technical": "trend", "mtf": "trend", "multitimeframe": "trend",
        "classical": "trend", "smc": "structure", "price_action": "structure",
    }
    supporters: set[str] = set()
    votes = decision.get("votes") or {}
    if isinstance(votes, dict):
        for item in votes.get(side, []) or []:
            if isinstance(item, dict):
                key = str(item.get("agent") or item.get("key") or "").lower()
                if key in family_map:
                    supporters.add(key)
    if isinstance(all_results, dict):
        for key, value in all_results.items():
            norm = str(key).lower()
            if norm not in family_map or not isinstance(value, dict):
                continue
            direction = str(value.get("direction") or value.get("signal") or "").upper()
            if direction == side and _f(value.get("confidence")) >= 65.0:
                supporters.add(norm)
    families = {family_map[k] for k in supporters}
    if len(supporters) < 2 or len(families) < 2:
        return (f"Path 2/3 two-family invariant failed: core supporters="
                f"{sorted(supporters)} families={sorted(families)}; macro/Gemini/auction "
                "confirmation cannot replace the second core family")
    return None


def stop_distance_band(decision: Dict[str, Any], config: Dict[str, Any]) -> Optional[str]:
    g = gate_config(config)
    if not g.get("enabled", True) or not g.get("enforce_stop_band", False):
        return None  # opt-in only; stop is set by the liquidity planning law
    side = _side(decision)
    if side not in {"BUY", "SELL"}:
        return None
    symbol = normalize_symbol(decision.get("symbol") or (config or {}).get("symbol") or "")
    sig = decision.get("signal") if isinstance(decision.get("signal"), dict) else {}
    entry = _f((sig.get("entry") or {}).get("price") if isinstance(sig.get("entry"), dict) else None) \
        or _f(decision.get("current_price"))
    stop = _f(sig.get("stop_loss"))
    if entry <= 0 or stop <= 0:
        return None  # geometry validator handles missing prices
    pts = abs(price_to_points(entry - stop, symbol=symbol))
    band = (g.get("stop_band_by_symbol") or {}).get(symbol) or g.get("stop_band_default") or {}
    lo = _f(band.get("min_points"))
    hi = _f(band.get("max_points"))
    if lo > 0 and pts < lo - 0.5:
        return f"stop {pts:.0f} pts is tighter than the {lo:.0f}-pt minimum for {symbol}"
    if hi > 0 and pts > hi + 0.5:
        return f"stop {pts:.0f} pts exceeds the {hi:.0f}-pt maximum for {symbol}"
    return None


def rr_floor_block(decision: Dict[str, Any], config: Dict[str, Any]) -> Optional[str]:
    """Reuse the same min-rr the validator uses; nothing parallel.

    Opt-in only (``enforce_rr_floor``): the final validator already applies
    risk_settings.min_rr_ratio with the scalp's OWN floors, so this veto is
    only for an operator who wants the discipline module to refuse too."""
    g = gate_config(config)
    if not g.get("enabled", True) or not g.get("enforce_rr_floor", False):
        return None
    side = _side(decision)
    if side not in {"BUY", "SELL"}:
        return None
    risk_cfg = (config or {}).get("risk_settings") or {}
    min_rr = _f(risk_cfg.get("min_rr_ratio"), 0.0)
    if min_rr <= 0:
        return None
    sig = decision.get("signal") if isinstance(decision.get("signal"), dict) else {}
    symbol = normalize_symbol(decision.get("symbol") or (config or {}).get("symbol") or "")
    entry = _f((sig.get("entry") or {}).get("price") if isinstance(sig.get("entry"), dict) else None) \
        or _f(decision.get("current_price"))
    stop = _f(sig.get("stop_loss"))
    tp2 = _f(sig.get("tp2"))
    if entry <= 0 or stop <= 0 or tp2 <= 0:
        return None
    risk_pts = abs(price_to_points(entry - stop, symbol=symbol))
    if risk_pts <= 0:
        return None
    rr = abs(price_to_points(tp2 - entry, symbol=symbol)) / risk_pts
    if rr < min_rr - 1e-9:
        return f"tp2 reward {rr:.2f}R is below the {min_rr:.2f}R minimum"
    return None


def thesis_exit_loss_cap(config: Dict[str, Any]) -> float:
    """The USD cap a thesis-exit is allowed to realise before it must close."""
    return _f(gate_config(config).get("thesis_exit_loss_cap_usd"), 100.0)


def discipline_violations(decision: Dict[str, Any], config: Dict[str, Any],
                          all_results: Dict[str, Any] | None = None) -> List[str]:
    """All discipline-gate violations; fail-open (returns [] on any error)."""
    out: List[str] = []
    try:
        for fn in (counter_macro_block, setup_direction_contradiction_block,
                   trend_family_only_block, path23_two_family_block,
                   stop_distance_band, rr_floor_block):
            try:
                v = fn(decision, config, all_results) if fn in (
                    counter_macro_block, setup_direction_contradiction_block,
                    trend_family_only_block, path23_two_family_block) else fn(decision, config)
                if v:
                    out.append(str(v))
            except Exception:  # noqa: BLE001 - a gate must never block on a bug
                continue
    except Exception:  # noqa: BLE001
        return []
    return out
