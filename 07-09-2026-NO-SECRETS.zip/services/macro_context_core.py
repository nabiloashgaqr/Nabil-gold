"""R26.9.13 — pure macro-context core (v2 flip-speed law + v1 A/B replay).

Split out of services.macro_data_provider on operator order 2026-09-03
(«قلب سريع غير متهور يكتشف الانقلاب مبكراً ولا يظل نائماً يوم كامل»).

Why a PURE core: the replay tool (SIM_MACRO_FLIP_REPLAY) must rebuild the
context AS OF any past instant from the same fetched series — point-in-time
correct, no re-fetch per step — so the measurement grades the REAL code.

v2 law (vs the v1 deployed behaviour, kept byte-compatible under
``v1_compat=True`` for A/B):

* TWO EYES: every trend gets a FAST window (24h) and the legacy SLOW window
  (5d). The published ``*_trend`` label is the fast eye (early flip
  detection); the slow label ships alongside as ``*_trend_slow``.
* RELATIVE threshold: a series is "flat" only within ITS OWN noise —
  thr = clamp(6% of the 5d range, 0.10%, 1.00%) instead of one fixed
  0.15% for gold, oil and FX alike.
* DXY basket properly WEIGHTED (v1 averaged, then let the single loudest
  pair override), and a EUR-EXCLUDED variant (``dxy_ex_eur_trend``) so the
  EUR/USD judgement is not 57% a mirror of the pair itself.
* ECB tone from EURO CROSSES (EURGBP, EURJPY — euro strength vs non-USD)
  instead of EURUSD itself; BOE from EURGBP inverted; BOC/BOJ keep their
  USD-pair proxies (medium/slow window — policy is not a 24h noise read).
* Provenance: ``trend_detail`` carries fast/slow pct, threshold, range and
  age per field; ``dominant_disagreement`` flags fast/slow conflict on the
  dominant legs (DXY / US10Y) so the agent can abstain honestly.

No network, no IO, no globals — everything comes in as arguments.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Sequence, Tuple

# DXY-style weights for the free FX basket (EUR/JPY/GBP/CAD/AUD — the SEK &
# CHF legs of the true index are not on the free feed; renormalised to 1.0).
_BASKET_WEIGHTS = {
    "EURUSD=X": 0.637,
    "USDJPY=X": 0.1505,
    "GBPUSD=X": 0.1316,
    "USDCAD=X": 0.1007,
    "AUDUSD=X": 0.1018,
}
# 1.0 - EUR weight (renormalised): the dollar seen WITHOUT the euro.
_BASKET_EX_EUR_TOTAL = round(1.0 - _BASKET_WEIGHTS["EURUSD=X"], 4)

FAST_WINDOW_HOURS = 24.0
RANGE_SHARE = 0.06          # thr = 6% of the series' own 5d range
THR_FLOOR, THR_CAP = 0.10, 1.00
V1_FIXED_THR = 0.15         # deployed v1 threshold (A/B fidelity)
STALE_HOURS = 48.0
# ── R26.9.14 (operator 2026-09-03 «محور أ + قانون ركود الدافع + مفتاح التباعد»)
ULTRA_WINDOW_HOURS = 8.0     # third eye: 8h net leads the 24h eye by hours
STALL_GRACE_HOURS = 2.0      # a stalled extreme keeps full voice this long
STALL_FADE_SPAN_HOURS = 12.0 # then its vote fades toward the floor across 12h
STALL_FADE_FLOOR = 0.35      # a stalled driver is DIMMED, never silenced


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _label(pct: float, thr: float, up: str, down: str, flat: str = "flat") -> str:
    if pct >= thr:
        return up
    if pct <= -thr:
        return down
    return flat


def series_stats(points: Sequence[Tuple[datetime, float]], as_of: Optional[datetime] = None,
                 v1: bool = False) -> Optional[Dict[str, Any]]:
    """Per-series fast/slow trend statistics.

    ``points`` = [(tz-aware datetime, close)] ascending. Returns None when the
    series cannot support a read (fail-open, never fabricates).
    """
    pts = [(t, float(c)) for t, c in points if c is not None]
    pts = [(t, c) for t, c in pts if t.tzinfo is not None] or [
        (t.replace(tzinfo=timezone.utc), c) for t, c in pts]
    if len(pts) < 2:
        return None
    as_of = as_of or pts[-1][0]
    pts = [(t, c) for t, c in pts if t <= as_of]
    if len(pts) < 2:
        return None
    first = pts[0][1]
    last = pts[-1][1]
    if not first:
        return None
    slow_pct = (last - first) / first * 100.0

    fast_cut = as_of - timedelta(hours=FAST_WINDOW_HOURS)
    fast_pts = [(t, c) for t, c in pts if t >= fast_cut]
    if len(fast_pts) >= 3 and fast_pts[0][1]:
        fast_pct = (fast_pts[-1][1] - fast_pts[0][1]) / fast_pts[0][1] * 100.0
    else:
        fast_pct = slow_pct  # too little intraday history — fall back to slow

    hi = max(c for _, c in pts)
    lo = min(c for _, c in pts)
    range_pct = (hi - lo) / first * 100.0 if first else 0.0
    thr = V1_FIXED_THR if v1 else _clamp(RANGE_SHARE * range_pct, THR_FLOOR, THR_CAP)
    age_hours = max(0.0, (as_of - pts[-1][0]).total_seconds() / 3600.0)

    # R26.9.14: third eye + extreme ages (the stall law's raw material)
    ultra_cut = as_of - timedelta(hours=ULTRA_WINDOW_HOURS)
    ultra_pts = [(t, c) for t, c in pts if t >= ultra_cut]
    ultra_pct = ((ultra_pts[-1][1] - ultra_pts[0][1]) / ultra_pts[0][1] * 100.0
                 if len(ultra_pts) >= 2 and ultra_pts[0][1] else fast_pct)
    day_pts = [(t, c) for t, c in pts if t >= as_of - timedelta(hours=24)]
    peak_age = trough_age = off_trough = off_peak = None
    stall_peak_age = stall_trough_age = None
    if day_pts:
        _hi = max(c for _, c in day_pts)
        _lo = min(c for _, c in day_pts)
        _last = day_pts[-1][1]
        peak_age = round((as_of - max(day_pts, key=lambda x: x[1])[0]).total_seconds() / 3600.0, 1)
        trough_age = round((as_of - min(day_pts, key=lambda x: x[1])[0]).total_seconds() / 3600.0, 1)
        if _lo:
            off_trough = round((_last - _lo) / _lo * 100.0, 4)
        if _hi:
            off_peak = round((_hi - _last) / _hi * 100.0, 4)
        # R26.9.14: a retest of yesterday's extreme is NOT a new extreme.
        # The effective stall age runs from the last GENUINE extension —
        # breaking beyond the previous day's extreme by >= 0.25 x thr.
        # compare against everything older than the grace window — a tick
        # above YESTERDAY'S high (which sits inside today's 24h window) is
        # a retest, not an extension.
        _prev = [(t, c) for t, c in pts
                 if as_of - timedelta(hours=48) <= t < as_of - timedelta(hours=STALL_GRACE_HOURS)]
        _m = 0.25 * thr / 100.0
        _dmax_t = max(day_pts, key=lambda x: x[1])[0]
        _dmin_t = min(day_pts, key=lambda x: x[1])[0]
        stall_peak_age = peak_age
        stall_trough_age = trough_age
        if _prev:
            _ph = max(c for _, c in _prev)
            _pl = min(c for _, c in _prev)
            _pht = max(_prev, key=lambda x: x[1])[0]
            _plt = min(_prev, key=lambda x: x[1])[0]
            if _hi <= _ph * (1.0 + _m):
                stall_peak_age = round((as_of - _pht).total_seconds() / 3600.0, 1)
            if _lo >= _pl * (1.0 - _m):
                stall_trough_age = round((as_of - _plt).total_seconds() / 3600.0, 1)
    return {
        "first": first, "last": last,
        "slow_pct": round(slow_pct, 4), "fast_pct": round(fast_pct, 4),
        "ultra_pct": round(ultra_pct, 4),
        "range_pct": round(range_pct, 4), "thr": round(thr, 4),
        "age_hours": round(age_hours, 1),
        "peak_age_24h": peak_age, "trough_age_24h": trough_age,
        "stall_peak_age_24h": stall_peak_age, "stall_trough_age_24h": stall_trough_age,
        "off_trough_24h_pct": off_trough, "off_peak_24h_pct": off_peak,
        "stale": age_hours > STALE_HOURS,
    }


def _basket(scores: Dict[str, Dict[str, Any]], key: str, exclude_eur: bool = False) -> Optional[float]:
    """Weighted mean of the USD-basket fast/slow scores."""
    num = den = 0.0
    for sym, w in _BASKET_WEIGHTS.items():
        if exclude_eur and sym == "EURUSD=X":
            continue
        st = scores.get(sym)
        if not st:
            continue
        inverse = sym in {"EURUSD=X", "GBPUSD=X", "AUDUSD=X"}
        val = -st[key] if inverse else st[key]
        num += w * val
        den += w
    if den <= 0:
        return None
    return num / den


def _tone_from_pct(move: Optional[float], thr_pct: float,
                   strong_is_hawkish: bool) -> Optional[str]:
    if move is None or abs(move) < thr_pct:
        return None
    strong = move > 0
    if not strong_is_hawkish:
        strong = not strong
    return "HAWKISH" if strong else "DOVISH"


def build_context(series_map: Dict[str, List[Tuple[datetime, float]]],
                  as_of: Optional[datetime] = None,
                  v1_compat: bool = False,
                  operator_tones: Optional[Dict[str, str]] = None,
                  cb28: Optional[Dict[str, float]] = None,
                  stall_enabled: bool = True) -> Dict[str, Any]:
    """Build the macro agent context from pure series.

    v1_compat=True reproduces the deployed pre-R26.9.13 behaviour (fixed
    0.15% threshold, slow-only labels, unweighted DXY with loudest-pair
    override, USD-pair CB proxies over a 28d window via ``cb28``).
    """
    v1 = v1_compat
    stats: Dict[str, Dict[str, Any]] = {}
    for sym, pts in (series_map or {}).items():
        st = series_stats(pts, as_of=as_of, v1=v1)
        if st is not None:
            stats[sym] = st
    if not stats:
        return {"source": "yfinance_macro_proxy", "provider": "none",
                "generated_at": (as_of or datetime.now(timezone.utc)).isoformat(),
                "freshness": "UNKNOWN", "schema": "v1" if v1 else "v2",
                "missing_fields": ["dxy_trend", "us10y_trend", "fed_tone"]}

    if as_of is None:
        as_of = datetime.now(timezone.utc)
    gen_at = as_of.isoformat().replace("+00:00", "Z")

    def pct(sym: str, key: str) -> Optional[float]:
        st = stats.get(sym)
        return None if not st else st[key]

    def label(sym: str, up: str, down: str, key: str = "fast_pct") -> str:
        st = stats.get(sym)
        if not st:
            return "unknown"
        return _label(st[key], st["thr"], up, down)

    # ── DXY ──
    dxy_fast = _basket(stats, "fast_pct")
    dxy_slow = _basket(stats, "slow_pct")
    dxy_thr = max([stats[s]["thr"] for s in _BASKET_WEIGHTS if s in stats] or [V1_FIXED_THR])
    dxy_trend = dxy_slow_trend = "unknown"
    if dxy_fast is not None and dxy_slow is not None:
        if v1:
            # deployed rule: plain mean over the 5d window; a flat mean with
            # one loud pair lets THAT pair speak for the dollar.
            val = dxy_slow
            if abs(val) < V1_FIXED_THR:
                loud = None
                for sym, w in _BASKET_WEIGHTS.items():
                    st = stats.get(sym)
                    if not st:
                        continue
                    inverse = sym in {"EURUSD=X", "GBPUSD=X", "AUDUSD=X"}
                    sc = -st["slow_pct"] if inverse else st["slow_pct"]
                    if loud is None or abs(sc) > abs(loud):
                        loud = sc
                if loud is not None and abs(loud) >= V1_FIXED_THR:
                    val = loud
            dxy_trend = dxy_slow_trend = _label(val, V1_FIXED_THR, "rising", "falling")
        else:
            dxy_trend = _label(dxy_fast, dxy_thr, "rising", "falling")
            dxy_slow_trend = _label(dxy_slow, dxy_thr, "rising", "falling")
    dxy_ex = _basket(stats, "fast_pct", exclude_eur=True)
    dxy_ex_slow = _basket(stats, "slow_pct", exclude_eur=True)
    dxy_ex_trend = (_label(dxy_ex, dxy_thr, "rising", "falling")
                    if dxy_ex is not None else "unknown")
    dxy_ex_slow_trend = (_label(dxy_ex_slow, dxy_thr, "rising", "falling")
                         if dxy_ex_slow is not None else "unknown")

    # ── yields / oil / vix / dxy-direct ──
    def field_trend(sym: str, up: str, down: str) -> Tuple[str, str]:
        return label(sym, up, down, "fast_pct"), label(sym, up, down, "slow_pct")

    us10y_fast, us10y_slow = field_trend("^TNX", "rising", "falling")
    realy_fast, realy_slow = field_trend("^FVX", "rising", "falling")
    oil_fast, oil_slow = field_trend("CL=F", "rising", "falling")
    dxyd_fast, dxyd_slow = field_trend("DX-Y.NYB", "rising", "falling")
    us10y_trend = us10y_slow if v1 else us10y_fast
    real_yields_trend = realy_slow if v1 else realy_fast
    oil_trend = oil_slow if v1 else oil_fast
    dxy_direct_trend = dxyd_slow if v1 else dxyd_fast
    if v1 and dxy_direct_trend not in {"flat", "unknown"} and dxy_trend == "flat":
        dxy_trend = dxy_slow_trend = dxy_direct_trend  # deployed override

    # ── R26.9.14 محور أ: العين الثالثة 8س تحلّ التسمية الهامشية ──
    # A fast (24h) label that only JUST crossed its threshold while the 8h
    # eye already says the opposite is noise, not a course — degrade it to
    # flat. Symmetric in both directions; v1 untouched.
    def _ultra_resolve(fast_lab: str, fast_val, thr: float, ultra_lab: str) -> str:
        if fast_lab not in {"rising", "falling"} or ultra_lab not in {"rising", "falling"}:
            return fast_lab
        if ultra_lab == fast_lab:
            return fast_lab
        if fast_val is not None and abs(fast_val) < 2.0 * thr:
            return "flat"
        return fast_lab

    # ── R26.9.14: ركود الدافع + مفتاح التباعد ──
    # v2 only, config-gated. A driver whose 5d course says "rising" but whose
    # 24h peak has gone stale (the last 8h stopped making highs) is PUSHING
    # NOTHING — its vote fades with the extreme's age instead of blocking the
    # flip for a full day. The divergence key lights when the traded symbol
    # itself moves while BOTH dominant drivers sit stalled.
    us10y_fast_resolved = None
    dxy_fade = yields_fade = 1.0
    dxy_stall_age = yields_stall_age = None
    dxy_ultra_trend = us10y_ultra_trend = "unknown"
    divergence_key = False
    divergence_direction = "none"
    flip_armed = False
    sym_mom, sym_mom_pct = "unknown", None
    if not v1 and stall_enabled:
        def _driver_stall(slow_trend: str, st: Optional[Dict[str, Any]]):
            """(extreme_age, fade). The driver's voice is the AGE of its own
            24h extreme: still making highs/troughs -> age ~0 -> full voice;
            the older the un-extended extreme, the fainter the vote, reaching
            the STALL_FADE_FLOOR after grace+span hours (a stalled driver
            is dimmed, never silenced). ANY genuine extension restores it
            fully and instantly. (The first draft gated on the 8h net sign
            and flapped on every micro-bounce — age is the stable law.)"""
            if not st or slow_trend not in {"rising", "falling"}:
                return None, 1.0
            age = (st.get("stall_peak_age_24h") if slow_trend == "rising"
                   else st.get("stall_trough_age_24h"))
            if age is None:
                age = st["peak_age_24h"] if slow_trend == "rising" else st["trough_age_24h"]
            if age is None or age <= STALL_GRACE_HOURS:
                return age, 1.0
            return age, round(max(STALL_FADE_FLOOR, 1.0 - (age - STALL_GRACE_HOURS)
                                  / STALL_FADE_SPAN_HOURS), 3)

        # dollar basket: weighted mean of the member fades
        _fsum = _wsum = 0.0
        _ages = []
        for _sym, _wgt in _BASKET_WEIGHTS.items():
            _st = stats.get(_sym)
            if not _st:
                continue
            _dirn = "rising" if _st["slow_pct"] > 0 else "falling"
            _ag, _fd = _driver_stall(_dirn, _st)
            _fsum += _wgt * _fd
            _wsum += _wgt
            if _ag is not None:
                _ages.append(_ag)
        if _wsum:
            dxy_fade = round(_fsum / _wsum, 3)
        if _ages:
            dxy_stall_age = round(sum(_ages) / len(_ages), 1)
        _bask_ultra = _basket(stats, "ultra_pct")
        if _bask_ultra is not None:
            dxy_ultra_trend = _label(_bask_ultra, dxy_thr, "rising", "falling")

        _tst = stats.get("^TNX")
        yields_stall_age, yields_fade = _driver_stall(us10y_slow, _tst)
        if _tst:
            us10y_ultra_trend = _label(_tst["ultra_pct"], _tst["thr"], "rising", "falling")

        # resolve marginal fast labels against the third eye
        dxy_trend = _ultra_resolve(dxy_trend, dxy_fast, dxy_thr, dxy_ultra_trend)
        us10y_fast_resolved = _ultra_resolve(us10y_fast,
                                            _tst["fast_pct"] if _tst else None,
                                            _tst["thr"] if _tst else V1_FIXED_THR,
                                            us10y_ultra_trend)

        # arming: the 8h eye contradicts the 5d course on a dominant driver,
        # or the divergence key is lit — the flip is being born NOW.
        _ultra_conflict = ((dxy_ultra_trend not in {"unknown", "flat"}
                            and dxy_ultra_trend != dxy_slow_trend
                            and dxy_slow_trend not in {"unknown", "flat"})
                           or (us10y_ultra_trend not in {"unknown", "flat"}
                               and us10y_ultra_trend != us10y_slow
                               and us10y_slow not in {"unknown", "flat"}))

        _sym_st = stats.get("symbol_price")
        if _sym_st:
            if (_sym_st["off_trough_24h_pct"] is not None
                    and _sym_st["off_trough_24h_pct"] >= _sym_st["thr"]):
                sym_mom, sym_mom_pct = "up", _sym_st["off_trough_24h_pct"]
            elif (_sym_st["off_peak_24h_pct"] is not None
                    and _sym_st["off_peak_24h_pct"] >= _sym_st["thr"]):
                sym_mom, sym_mom_pct = "down", -_sym_st["off_peak_24h_pct"]
            if sym_mom in {"up", "down"} and dxy_fade < 1.0 and yields_fade < 1.0:
                divergence_key = True
                divergence_direction = sym_mom
        flip_armed = _ultra_conflict or divergence_key

    vix_st = stats.get("^VIX")
    vix_level = round(vix_st["last"], 2) if vix_st else None

    # ── yield curve spread (10Y - 13W) ──
    irx = stats.get("^IRX")
    tnx_val = stats.get("^TNX")
    spread = round(tnx_val["last"] - irx["last"], 3) if (tnx_val and irx) else None

    # ── fed tone (v1: slow eye; v2: fast eye — the flip must be early) ──
    def _fed_from(trend: str) -> str:
        if trend == "rising":
            return "neutral" if (spread_for_fed is not None and spread_for_fed < 0) else "hawkish"
        if trend == "falling":
            return "neutral" if (spread_for_fed is not None and spread_for_fed > 1.0) else "dovish"
        if trend == "flat":
            return "neutral"
        return "unknown"
    # v1 fidelity: deployed yield_curve_spread was never populated (it read
    # the us10y_trend LABEL where a float was expected), so the deployed
    # fed_tone never consulted the curve. Replicate verbatim under v1.
    spread_for_fed = None if v1 else spread
    fed_tone = _fed_from(us10y_slow if v1 else us10y_fast)
    if fed_tone == "unknown":
        fed_tone = _fed_from(realy_slow if v1 else realy_fast)
    # R26.9.14: the third eye degraded a marginal 24h yields label -> the
    # published trend and the Fed tone follow the resolved label.
    if not v1 and stall_enabled and us10y_fast_resolved is not None \
            and us10y_fast_resolved != us10y_fast:
        us10y_trend = us10y_fast_resolved
        fed_tone = _fed_from(us10y_fast_resolved)

    # ── risk sentiment (VIX ladder dominates, else SPY) ──
    risk_sentiment = "neutral"
    if vix_level is not None:
        if vix_level >= 25:
            risk_sentiment = "risk_off"
        elif vix_level <= 14:
            risk_sentiment = "risk_on"
    if risk_sentiment == "neutral":
        spy = stats.get("SPY")
        if spy:
            key = "slow_pct" if v1 else "fast_pct"
            thr = V1_FIXED_THR if v1 else spy["thr"]
            risk_sentiment = _label(spy[key], thr, "risk_on", "risk_off", "neutral")

    # ── inflation surprise (TIP primary, STIP tiebreak) ──
    tips, stip = stats.get("TIP"), stats.get("STIP")

    def _infl(st: Optional[Dict[str, Any]], key: str, thr: float) -> Optional[str]:
        if not st:
            return None
        return _label(st[key], thr, "hot", "cool", "neutral")

    if v1:
        inflation_surprise = "unknown"
        first_ = _infl(tips, "slow_pct", V1_FIXED_THR)
        if first_ in {"hot", "cool"}:
            inflation_surprise = first_
        elif tips is not None:
            second_ = _infl(stip, "slow_pct", V1_FIXED_THR)
            inflation_surprise = second_ if second_ in {"hot", "cool"} else "neutral"
        elif stip is not None:
            inflation_surprise = _infl(stip, "slow_pct", V1_FIXED_THR) or "neutral"
    else:
        inflation_surprise = "unknown"
        first_ = _infl(tips, "fast_pct", tips["thr"] if tips else V1_FIXED_THR)
        if first_ in {"hot", "cool"}:
            inflation_surprise = first_
        elif tips is not None:
            second_ = _infl(stip, "fast_pct", stip["thr"] if stip else V1_FIXED_THR)
            inflation_surprise = second_ if second_ in {"hot", "cool"} else "neutral"
        elif stip is not None:
            inflation_surprise = _infl(stip, "fast_pct", stip["thr"] if stip else V1_FIXED_THR) or "neutral"

    # ── peer central-bank tones ──
    operator_tones = operator_tones or {}
    tones: Dict[str, str] = {}
    tone_source = "fx_proxy"
    cb_thr = 1.5  # % over the policy (medium) window — same as deployed

    def _set_from_operator(field: str) -> bool:
        tok = str(operator_tones.get(field) or "").strip().upper()
        if tok in {"HAWKISH", "TIGHTENING", "RATE_HIKES", "HIKE"}:
            tones[field] = "HAWKISH"
            return True
        if tok in {"DOVISH", "EASING", "RATE_CUTS", "CUTS", "YCC"}:
            tones[field] = "DOVISH"
            return True
        return False

    # ECB — v2: euro vs NON-dollar crosses (breaks the EURUSD circularity);
    # v1: the EURUSD 28d window via cb28 (deployed proxy).
    if not _set_from_operator("ecb_tone"):
        if v1:
            mv = (cb28 or {}).get("EURUSD=X")
            t = _tone_from_pct(mv, cb_thr, strong_is_hawkish=True)
            if t:
                tones["ecb_tone"] = t
        else:
            gbp = pct("EURGBP=X", "slow_pct")
            jpy = pct("EURJPY=X", "slow_pct")
            thr_g = stats.get("EURGBP=X", {}).get("thr", cb_thr)
            thr_j = stats.get("EURJPY=X", {}).get("thr", cb_thr)
            t1 = _tone_from_pct(gbp, thr_g, True)
            t2 = _tone_from_pct(jpy, thr_j, True)
            if t1 and t1 == t2:
                tones["ecb_tone"] = t1  # euro firm vs BOTH -> hawkish ECB
    # BOE — v2: EURGBP inverted (euro up vs pound = pound soft = dovish BOE).
    if not _set_from_operator("boe_tone"):
        if v1:
            mv = (cb28 or {}).get("GBPUSD=X")
            t = _tone_from_pct(mv, cb_thr, True)
            if t:
                tones["boe_tone"] = t
        else:
            mv = pct("EURGBP=X", "slow_pct")
            thr_g = stats.get("EURGBP=X", {}).get("thr", cb_thr)
            t = _tone_from_pct(mv, thr_g, strong_is_hawkish=False)
            if t:
                tones["boe_tone"] = t
    # BOC — CAD soft -> dovish BOC (USDCAD rising = CAD weaker).
    if not _set_from_operator("boc_tone"):
        src = (cb28 or {}).get("USDCAD=X") if v1 else pct("USDCAD=X", "slow_pct")
        thr_b = V1_FIXED_THR * 10 if v1 else stats.get("USDCAD=X", {}).get("thr", cb_thr)
        t = _tone_from_pct(src, cb_thr if v1 else thr_b, strong_is_hawkish=False)
        if t:
            tones["boc_tone"] = t
    # BOJ — JPY weak (USDJPY rising) -> dovish BOJ.
    if not _set_from_operator("boj_tone"):
        src = (cb28 or {}).get("USDJPY=X") if v1 else pct("USDJPY=X", "slow_pct")
        thr_j = V1_FIXED_THR * 10 if v1 else stats.get("USDJPY=X", {}).get("thr", cb_thr)
        t = _tone_from_pct(src, cb_thr if v1 else thr_j, strong_is_hawkish=False)
        if t:
            tones["boj_tone"] = t
    if any(operator_tones.get(f) for f in ("ecb_tone", "boe_tone", "boc_tone", "boj_tone")):
        tone_source = "operator"

    stale_syms = [s for s, st in stats.items() if st["stale"]]
    missing = [f for f, v in (("dxy_trend", dxy_trend == "unknown"),
                              ("us10y_trend", us10y_trend == "unknown"),
                              ("real_yields_trend", real_yields_trend == "unknown"),
                              ("fed_tone", fed_tone == "unknown"),
                              ("oil_trend", oil_trend == "unknown"),
                              ("inflation_surprise", inflation_surprise == "unknown")) if v]

    ctx: Dict[str, Any] = {
        "source": "yfinance_macro_proxy",
        "provider": "yfinance",
        "generated_at": gen_at,
        "freshness": "OK" if not stale_syms else "STALE",
        "update_frequency": "hourly",
        "schema": "v1" if v1 else "v2",
        "dxy_trend": dxy_trend,
        "usd_trend": dxy_trend,
        "risk_sentiment": risk_sentiment,
        "us10y_trend": us10y_trend,
        "real_yields_trend": real_yields_trend,
        "fed_tone": fed_tone,
        "inflation_surprise": inflation_surprise,
        "ecb_tone": tones.get("ecb_tone", "unknown"),
        "boe_tone": tones.get("boe_tone", "unknown"),
        "boc_tone": tones.get("boc_tone", "unknown"),
        "boj_tone": tones.get("boj_tone", "unknown"),
        "cb_tone_source": tone_source,
        "oil_trend": oil_trend,
        "vix_level": vix_level,
        "yield_curve_spread": spread,
        "dxy_direct_trend": dxy_direct_trend,
        "missing_fields": missing,
    }
    ctx["data_quality"] = {
        "source": "yfinance",
        "freshness": ctx["freshness"],
        "stale_symbols": len(stale_syms),
        "fx_symbols": len([s_ for s_ in stats if s_.endswith("=X")]),
        "macro_symbols": len(stats),
        "missing_fields": missing,
        "optional_cb_tones_missing": [f_ for f_ in ("ecb_tone", "boe_tone", "boc_tone", "boj_tone")
                                      if tones.get(f_) in (None, "", "unknown")],
    }
    if not v1:
        ctx.update({
            "dxy_trend_slow": dxy_slow_trend,
            "dxy_ex_eur_trend": dxy_ex_trend,
            "dxy_ex_eur_trend_slow": dxy_ex_slow_trend,
            "us10y_trend_slow": us10y_slow,
            "real_yields_trend_slow": realy_slow,
            "oil_trend_slow": oil_slow,
            "dominant_disagreement": (dxy_trend != dxy_slow_trend
                                      and "flat" not in (dxy_trend, dxy_slow_trend)
                                      ) or (us10y_fast != us10y_slow
                                            and "flat" not in (us10y_fast, us10y_slow)),
            "windows": {"fast_hours": FAST_WINDOW_HOURS, "slow": "5d",
                        "threshold": f"{RANGE_SHARE:.0%} of 5d range, clamped [{THR_FLOOR},{THR_CAP}]"},
            "dxy_trend_ultra": dxy_ultra_trend,
            "us10y_trend_ultra": us10y_ultra_trend,
            "dxy_stall_age_hours": dxy_stall_age,
            "yields_stall_age_hours": yields_stall_age,
            "dxy_fade": dxy_fade,
            "yields_fade": yields_fade,
            "symbol_momentum": sym_mom,
            "symbol_momentum_pct": sym_mom_pct,
            "divergence_key": divergence_key,
            "divergence_direction": divergence_direction,
            "macro_flip_armed": flip_armed,
            "stall_law": {"ultra_hours": ULTRA_WINDOW_HOURS,
                          "grace_hours": STALL_GRACE_HOURS,
                          "fade_span_hours": STALL_FADE_SPAN_HOURS,
                          "enabled": True},
            "trend_detail": {s: {"fast_pct": st["fast_pct"], "slow_pct": st["slow_pct"],
                                 "thr": st["thr"], "range_pct": st["range_pct"],
                                 "age_hours": st["age_hours"]}
                             for s, st in stats.items()},
        })
    return ctx
