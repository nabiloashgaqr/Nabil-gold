# -*- coding: utf-8 -*-
"""R26.9 (2026-09-01): the SINGLE source for "which fundamental macro voice
may judge (veto) a trade for THIS symbol, and which way does it lean?".

History / why this exists
-------------------------
The hard macro veto (R26.2) and the mirrored thesis-exit veto (R26.4) both
used to read ONE key — ``macro_fundamental`` — which is the dollar/gold
macro-regime voice. Crude has its OWN fundamentals agent (``oil_macro``: EIA
inventories + OPEC tone + Brent-WTI spread) that Path-2 confirmation already
routes to, but the veto ignored it. On a dollar-strong tape the gold macro
said BEARISH_WTIUSD while oil fundamentals said BULLISH_OIL, so the veto
killed every correct oil BUY, mirror-closed correct oil longs, and refused
to close wrong oil shorts. The same reader logic was then duplicated
(independently) in the post-decision auditor, so the two could silently
disagree.

This module is the one routing decision every consumer must share:

    voice = macro_voice(decision, all_results, config)
    -> {"side": "BUY"|"SELL"|"", "conf": float, "source": "oil_macro"|
        "macro_fundamental"|"", "symbol": str}

Rules (pure, config-driven, fail-open, no symbol literals):
  * oil          -> the oil-fundamental agent's committed verdict; neutral
                    (no veto) when it has none.
  * gold + the configured ``macro_confirmation.symbols`` list -> the
                    macro_fundamental agent (per-symbol verdict).
  * any other known symbol -> neutral / no veto (mirrors the Path-2
                    confirmation routing, which only judges listed symbols).

Nothing here invents numbers or votes; it only routes + normalises.
"""
from __future__ import annotations

from typing import Any, Dict

from utils.instruments import normalize_symbol
from services.symbol_law import category_of, is_gold, is_oil, macro_symbols


def _f(v: Any) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def normalise_bias(raw: Any) -> str:
    """Map any bias token (BULLISH/BEARISH/BULLISH_GOLD/BULLISH_EURUSD/
    BULLISH_OIL/...) to BUY/SELL/''. Test whole words / prefixes so a
    partial substring can never be mistaken; only one ever matches."""
    b = str(raw or "").upper()
    if b == "SELL" or "BEARISH" in b or b.startswith("BEAR"):
        return "SELL"
    if b == "BUY" or "BULLISH" in b or b.startswith("BULL"):
        return "BUY"
    return ""


def decision_symbol(decision: Any = None,
                    all_results: Any = None,
                    config: Any = None) -> str:
    """Best-effort normalised symbol for the decision under evaluation."""
    for src in (decision or {}, all_results or {}):
        if isinstance(src, dict):
            sym = src.get("symbol")
            if sym:
                try:
                    return normalize_symbol(sym)
                except Exception:  # noqa: BLE001
                    return str(sym).upper()
    if isinstance(config, dict):
        sym = config.get("symbol")
        if sym:
            try:
                return normalize_symbol(sym)
            except Exception:  # noqa: BLE001
                return str(sym).upper()
    return ""


def _oil_voice(decision: Any, all_results: Any) -> Dict[str, Any]:
    """The oil-fundamental verdict. It NEVER votes (signal WAIT), so the lean
    rides in ``bias``/``direction``, never in ``signal``. Fail-open neutral
    when it has no committed verdict."""
    sources = []
    if isinstance(all_results, dict):
        sources.append(all_results.get("oil_macro"))
    if isinstance(decision, dict):
        nc = decision.get("news_context")
        if isinstance(nc, dict) and isinstance(nc.get("oil_macro"), dict):
            sources.append(nc["oil_macro"])
        mc = decision.get("market_context")
        if isinstance(mc, dict):
            if mc.get("oil_macro_bias"):
                sources.append({"bias": mc.get("oil_macro_bias"),
                                "confidence": mc.get("oil_macro_confidence", 0)})
        ad = decision.get("agent_details")
        if isinstance(ad, dict) and isinstance(ad.get("oil_macro"), dict):
            sources.append(ad["oil_macro"])
    for a in sources:
        if not isinstance(a, dict):
            continue
        side = normalise_bias(a.get("bias") or a.get("direction"))
        conf = _f(a.get("confidence"))
        if side and conf > 0:
            return {"side": side, "conf": conf, "source": "oil_macro"}
    return {"side": "", "conf": 0.0, "source": ""}


def _macro_fundamental_voice(decision: Any, all_results: Any) -> Dict[str, Any]:
    """Read the freshest committed macro verdict, never a fixed stale priority."""
    from datetime import datetime, timezone
    candidates = []

    def add(raw: Any, source_rank: int = 0) -> None:
        if not isinstance(raw, dict):
            return
        inner = raw.get("macro_direction") if isinstance(raw.get("macro_direction"), dict) else raw
        side = normalise_bias(inner.get("bias") or inner.get("direction")
                              or inner.get("signal") or inner.get("trade_bias"))
        if not side:
            return
        stamp = inner.get("timestamp") or inner.get("generated_at") or raw.get("timestamp") or raw.get("generated_at")
        epoch = 0.0
        try:
            dt = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            epoch = dt.timestamp()
        except Exception:
            pass
        candidates.append((epoch, source_rank, side, _f(inner.get("confidence"))))

    # Current-cycle results win ties/no-timestamp; timestamp wins otherwise.
    if isinstance(all_results, dict):
        for key in ("macro_fundamental", "macro", "macro_fundamental_agent"):
            add(all_results.get(key), 3)
    if isinstance(decision, dict):
        mc = decision.get("market_context")
        if isinstance(mc, dict):
            add(mc.get("macro_direction"), 2)
        nc = decision.get("news_context")
        if isinstance(nc, dict):
            add(nc.get("macro"), 1)
    if not candidates:
        return {"side": "", "conf": 0.0, "source": ""}
    _, _, side, conf = max(candidates, key=lambda item: (item[0], item[1]))
    return {"side": side, "conf": conf, "source": "macro_fundamental"}

def macro_voice(decision: Any = None,
                all_results: Any = None,
                config: Any = None) -> Dict[str, Any]:
    """The routed fundamental macro verdict that may judge THIS symbol.

    Returns ``{"side": BUY|SELL|"", "conf": float, "source": str,
    "symbol": str}``. ``side == ""`` means no fundamental veto applies
    (fail-open / symbol not judged / no committed verdict)."""
    symbol = decision_symbol(decision, all_results, config)
    try:
        if symbol and is_oil(symbol):
            v = _oil_voice(decision, all_results)
            v["symbol"] = symbol
            return v
    except Exception:  # noqa: BLE001 - routing must never block a trade
        pass
    # Only gold + the configured macro list are judged by macro_fundamental;
    # any other symbol fails open so a foreign regime can never veto it.
    if symbol and not _judged_by_macro_fundamental(symbol, config):
        return {"side": "", "conf": 0.0, "source": "", "symbol": symbol}
    v = _macro_fundamental_voice(decision, all_results)
    v["symbol"] = symbol
    return v


def _judged_by_macro_fundamental(symbol: str, config: Any) -> bool:
    """Whether the macro_fundamental verdict may judge this symbol.

    Primary: the configured ``macro_confirmation.symbols`` list (gold always).
    Fallback when the list is unavailable (a thin test/ad-hoc config with no
    signal_requirements): judge metal + forex (the instruments the
    macro_fundamental agent has per-symbol branches for) but never oil here -
    crude is routed to its own oil voice above, so this fallback must not let a
    dollar/gold regime veto crude either."""
    try:
        listed = {normalize_symbol(x) for x in macro_symbols(config)}
    except Exception:  # noqa: BLE001
        listed = set()
    if listed:
        return symbol in listed
    # no config list available -> category fallback (no symbol literals)
    try:
        return is_gold(symbol) or category_of(symbol) == "forex"
    except Exception:  # noqa: BLE001
        return is_gold(symbol)
