"""Atomic per-symbol, read-only evidence artifact for Shadow Market Architect."""
from __future__ import annotations
import json,os,tempfile
from datetime import datetime,timezone
from pathlib import Path
from typing import Any,Mapping
ROOT=Path(__file__).resolve().parents[1]
def publish_shadow_agent_book(symbol:str,results:Mapping[str,Any],config:Mapping[str,Any]|None=None)->Path|None:
 cfg=((config or {}).get('shadow_market_architect') or {}).get('evidence') or {}
 # Never share this path with services.agent_book_store: that activation-gate
 # store intentionally writes a compact direction/confidence-only payload and
 # would erase the POI/zone structures required by the shadow architect.
 pattern=str(cfg.get('shadow_agent_book_pattern') or 'storage/shadow_agent_books/{symbol}.json');compact=''.join(ch for ch in str(symbol).upper() if ch.isalnum())
 if not compact:return None
 path=Path(pattern.format(symbol=compact,normalized=symbol));path=path if path.is_absolute() else ROOT/path;path.parent.mkdir(parents=True,exist_ok=True)
 payload={'symbol':symbol,'generated_at':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),'agents':dict(results)};temp=''
 try:
  with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=path.parent,prefix=f'.{path.name}.',suffix='.tmp',delete=False) as f:
   temp=f.name;json.dump(payload,f,ensure_ascii=False,separators=(',',':'),default=str);f.flush();os.fsync(f.fileno())
  os.replace(temp,path);temp='';return path
 finally:
  if temp and os.path.exists(temp):
   try:os.unlink(temp)
   except OSError:pass
