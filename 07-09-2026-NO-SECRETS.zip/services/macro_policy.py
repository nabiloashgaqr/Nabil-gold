# -*- coding: utf-8 -*-
"""Single source of truth for macro confirmation/veto quality thresholds."""
from __future__ import annotations
from typing import Any, Dict


def _f(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def macro_policy(config: Dict[str, Any] | None = None) -> Dict[str, Any]:
    cfg = config or {}
    explicit = cfg.get("macro_policy") or {}
    two = ((cfg.get("signal_requirements") or {}).get("two_agent_entry") or {})
    confirmation = two.get("macro_confirmation") or {}
    veto = two.get("macro_veto") or {}
    gates = cfg.get("discipline_gates") or {}
    return {
        "entry_confirmation_confidence": _f(
            explicit.get("entry_confirmation_confidence"),
            _f(confirmation.get("min_confidence"), 55.0)),
        "entry_veto_confidence": _f(
            explicit.get("entry_veto_confidence"),
            _f(veto.get("min_confidence"), _f(gates.get("macro_block_conf"), 60.0))),
        "exit_veto_confidence": _f(
            explicit.get("exit_veto_confidence"),
            _f(veto.get("min_confidence"), 60.0)),
        "min_evidence_inputs": int(_f(explicit.get("min_evidence_inputs"), 3)),
        "future_timestamp_tolerance_minutes": _f(
            explicit.get("future_timestamp_tolerance_minutes"), 5.0),
        "flip_guard_persist": bool(explicit.get("flip_guard_persist", False)),
        "flip_guard_hours": _f(explicit.get("flip_guard_hours"), 4.0),
    }
