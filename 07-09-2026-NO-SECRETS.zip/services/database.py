"""Database service using Supabase with local JSON fallback.

GitHub Actions runners are stateless, so production persistence should use
Supabase. The local fallback lets tests and manual dry-runs work without
credentials, but it will not persist between separate GitHub Actions runs.
"""

from __future__ import annotations

import logging
import os
import re
import uuid
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo
from pathlib import Path
from typing import Any, Dict, List, Optional

try:  # Supabase is optional during local tests.
    from supabase import Client, create_client
except Exception:  # pragma: no cover - dependency may be absent in local Python
    Client = Any  # type: ignore[misc,assignment]
    create_client = None  # type: ignore[assignment]

from utils.helpers import (
    load_config, load_trades, load_trades_checked, mutate_trades, save_trades,
)
from utils.instruments import price_decimals, price_to_points
from utils.sessions import session_label_from_utc, SESSION_ORDER
from services import performance_stats
from services.path_performance import PathPerformanceTracker


def _iso_ts(value: Any) -> Any:
    """Normalize epoch seconds (int or digit-string) to ISO-8601 UTC.

    Supabase timestamptz columns reject raw epoch strings (SQLSTATE 22008
    'date/time field value out of range' — live incident 2026-08-10: SMC
    candidates carry candle-epoch created_at). ISO strings pass through.
    """
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)) or (isinstance(value, str) and value.strip().isdigit()):
        try:
            return datetime.fromtimestamp(int(value), tz=timezone.utc).replace(
                microsecond=0).isoformat()
        except Exception:  # noqa: BLE001
            return None
    return value


class DatabaseService:
    """Persist and retrieve trades from Supabase or local JSON fallback."""

    def __init__(self, config: Dict[str, Any] | None = None) -> None:
        self.config = config or load_config()
        self.logger = logging.getLogger(self.__class__.__name__)
        # demo/mt5 branch: demo executions write to trades_demo via env.
        self.trades_table = os.environ.get("TRADES_TABLE") or "trades"
        db_config = self.config.get("database", {})
        self.url = os.environ.get("SUPABASE_URL") or db_config.get("url")
        self.key = os.environ.get("SUPABASE_KEY") or db_config.get("key")
        if isinstance(self.url, str) and self.url.startswith("ENV:"):
            self.url = os.environ.get(self.url.replace("ENV:", "", 1))
        if isinstance(self.key, str) and self.key.startswith("ENV:"):
            self.key = os.environ.get(self.key.replace("ENV:", "", 1))
        fallback = db_config.get("local_fallback_file", "storage/trades.json")
        root = Path(__file__).resolve().parents[1]
        self.local_path = root / fallback
        self.setup_candidates_path = root / "storage" / "setup_candidates.json"
        self.setup_state_events_path = root / "storage" / "setup_state_events.json"
        self.session_plans_path = root / "storage" / "session_plans.json"
        self.analyst_labels_path = root / "storage" / "analyst_labels.json"
        self.analyst_comparisons_path = root / "storage" / "analyst_comparisons.json"
        # R25.6 (2026-08-28, court-record contamination): the audit file
        # follows the SAME store root as the trades fallback. It used to be
        # hardwired to the code tree, so a test DatabaseService pointed at a
        # tmp dir still wrote the PRODUCTION storage/decision_audit.json
        # (the "unit-test veto" rows in the 14-day report). The production
        # layout is unchanged: storage/trades.json -> storage/decision_audit.json.
        self.decision_audit_path = self.local_path.parent / "decision_audit.json"
        self.path_performance = PathPerformanceTracker(
            root / "storage" / "path_performance" / "trades.json"
        )
        self.client: Client | None = None
        self.use_supabase = False

        if self.url and self.key and create_client is not None:
            try:
                self.client = create_client(str(self.url), str(self.key))
                self.use_supabase = True
                self.logger.info("Database connected: Supabase")
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Supabase init failed in production: {exc}") from exc
                self.logger.warning("Supabase init failed, using local fallback: %s", exc)
        else:
            if self._strict_supabase():
                raise RuntimeError("Supabase credentials missing in production GitHub Actions")
            self.logger.warning("Supabase credentials missing, using local fallback JSON")

    def _strict_supabase(self) -> bool:
        """Require Supabase only for production workflows or explicit requests.

        GitHub Actions sets GITHUB_ACTIONS=true for every workflow, including the
        Tests workflow. Unit tests must still be allowed to use the local JSON
        fallback. Production jobs set REQUIRE_SUPABASE=true explicitly in their
        workflow env, so they continue to fail fast if Supabase is unavailable.
        """
        explicit = str(os.environ.get("REQUIRE_SUPABASE", "")).strip().lower()
        if explicit in {"1", "true", "yes", "y"}:
            return True
        if explicit in {"0", "false", "no", "n"}:
            return False
        if os.environ.get("PYTEST_CURRENT_TEST"):
            return False
        if os.environ.get("GITHUB_ACTIONS") != "true":
            return False
        return bool(self.config.get("github_actions", {}).get("require_supabase", False))

    @staticmethod
    def _resolve_execution_path_id(decision: Dict[str, Any], signal: Dict[str, Any]) -> Optional[str]:
        """R25.9: resolve execution path provenance from every place it can hide.

        Live mt5_demo MARKET rows were saved with a null execution_path_id even
        though the admission carried it inside ``execution_path`` or the signal
        snapshot, so per-path P&L reports lost those trades. Read top-level
        first, then the nested path object, then the signal snapshot.
        """
        top = decision.get("execution_path_id")
        if top:
            return top
        ep = decision.get("execution_path")
        if isinstance(ep, dict):
            if ep.get("id"):
                return ep.get("id")
            if ep.get("path_id"):
                return ep.get("path_id")
        if ep and isinstance(ep, str):
            return ep
        if decision.get("entry_path"):
            return decision.get("entry_path")
        if isinstance(signal, dict):
            if signal.get("execution_path_id"):
                return signal.get("execution_path_id")
            p9 = signal.get("path9")
            if isinstance(p9, dict) and p9.get("execution_path_id"):
                return p9.get("execution_path_id")
        # R26.5 (2026-09-01): a scale-in / add leg (2026-08-31 gold 19:56 MARKET
        # row saved null) reaches save_trade via the scale-in branch, which never
        # ran the run_analysis provenance stamp. A real, entered trade must never
        # be recorded with no path. Stamp it for what it is.
        if decision.get("scale_in_size_ratio") or decision.get("scale_in_trigger") \
                or decision.get("parent_trade_id") or (signal or {}).get("scale_in_size_ratio") \
                or (isinstance(signal, dict) and signal.get("scale_in")):
            return "SCALE_IN_ADD"
        return None

    @staticmethod
    def new_trade_id() -> str:
        """Generate a canonical trade id.

        Exposed so callers (e.g. run_analysis) can mint the *real* id BEFORE the
        Telegram message is sent, instead of showing a temporary 'PENDING_...'
        placeholder and only assigning the real id at save time.
        """
        return f"TRADE_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')}_{uuid.uuid4().hex[:8]}"

    def save_trade(self, decision: Dict[str, Any]) -> str:
        """Save a new trade from a decision dictionary."""
        # Reuse a pre-assigned id (set by the caller before sending Telegram) so
        # the id shown in the signal message matches the stored trade exactly.
        trade_id = (
            decision.get("trade_id")
            or (decision.get("signal", {}) or {}).get("trade_id")
            or self.new_trade_id()
        )
        if str(trade_id).startswith("PENDING_") or not str(trade_id).startswith("TRADE_"):
            trade_id = self.new_trade_id()
        signal = decision.get("signal", {})
        entry = signal.get("entry", {})
        symbol = str(decision.get("symbol") or signal.get("symbol") or self.config.get("symbol", "XAU/USD"))
        decimals = price_decimals(symbol)
        entry_price = float(entry.get("price") or ((float(entry.get("low", 0)) + float(entry.get("high", 0))) / 2) or 0)
        now_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        stop_loss = round(float(signal.get("stop_loss", 0)), decimals)

        # ── Market vs pending (LIMIT/STOP) order ────────────────────────────
        # A smart entry may place the order AWAY from the current price
        # (a LIMIT pullback or STOP breakout). Such an order is NOT filled yet:
        # it must wait until price actually touches entry_price. Storing it as
        # OPEN immediately created phantom fills/profits (e.g. a SELL LIMIT at
        # 4101 while price was 4068 and never traded up to 4101). So we persist
        # it as PENDING and let the trade manager activate it on touch.
        order_kind = str(signal.get("entry_kind") or entry.get("kind") or "MARKET").upper()
        current_price = float(decision.get("current_price", entry_price) or entry_price)
        # A directional kind is what every planner path actually emits
        # (BUY_LIMIT / SELL_LIMIT), not the bare token LIMIT.  The old exact
        # membership check therefore stored a genuine LIMIT as OPEN.  The tick
        # manager's OPEN/no-ticket recovery is intentionally MARKET-only, so
        # it immediately filled the supposedly pending card at market (live
        # GBP/USD PATH 5, 2026-09-04, ticket 627800859).
        #
        # Order semantics, not an arbitrary 0.01 absolute-price gap, decide
        # lifecycle.  0.01 is 1,000 points on 5-digit FX and classified nearly
        # every lawful FX LIMIT as OPEN.  Even a LIMIT already at touch remains
        # PENDING until MT5 accepts/fills that LIMIT and reconciliation records
        # the broker's actual event.
        is_pending_order = order_kind.endswith("LIMIT") or order_kind.endswith("STOP")
        initial_status = "PENDING" if is_pending_order else "OPEN"
        trade_data = {
            "id": trade_id,
            "type": decision.get("decision", signal.get("type")),
            "symbol": symbol,
            "entry_price": round(entry_price, decimals),
            "entry_time": now_iso,
            "stop_loss": stop_loss,
            "initial_stop_loss": stop_loss,
            "tp1": round(float(signal.get("tp1", 0)), decimals),
            "tp2": round(float(signal.get("tp2", 0)), decimals),
            "confidence": int(decision.get("confidence", 0)),
            "trading_mode": ("mt5_demo" if os.environ.get("EXECUTION_MODE") == "mt5_demo"
                             else decision.get("trading_mode", "demo")),
            "paper_trading": (False if os.environ.get("EXECUTION_MODE") == "mt5_demo"
                              else bool(decision.get("paper_trading", False))),
            "paper_balance_start": decision.get("paper_config", {}).get("starting_balance"),
            "paper_lot_size": decision.get("paper_config", {}).get("default_lot_size"),
            "status": initial_status,
            "order_kind": order_kind,
            "order_type": signal.get("order_type") or entry.get("order_type"),
            "current_price": round(current_price, decimals),
            "current_pnl": 0,
            "current_pnl_points": 0,
            "sl_moved_to_entry": False,
            "partial_close": False,
            # Rechecked against the broker's actual fill before any signal card.
            "execution_stop_normalized": False,
            "execution_stop_points": None,
            "opposite_exit_required": bool(decision.get("opposite_exit_required", False)),
            "opposite_trade_ids": list(decision.get("opposite_trade_ids") or []),
            "opposite_pending_cancelled_ids": list(decision.get("opposite_pending_cancelled_ids") or []),
            "opposite_exit_completed": False,
            # In mt5_demo, analysis persists the execution intent first and the
            # tick manager sends the rich signal card only AFTER MT5 accepts the
            # order. Paper mode keeps its historical send-before-save flow.
            "telegram_signal_sent": bool(decision.get("_telegram_signal_sent", True)),
            "telegram_signal_sent_at": decision.get("_telegram_signal_sent_at"),
            "pending_cycles": 0,  # hybrid mode: how many cycles a PENDING order has survived
            # BUILD 30: arming mode provenance (None = reactive, the
            # historical behaviour; "pre_arm_ote" = armed at the projected
            # OTE before the pullback arrived). Reports measure the two
            # modes separately.
            "armed_at": decision.get("armed_at"),
            "updates_sent": [],
            "result": None,
            "created_at": now_iso,
            "closed_at": None,
            "close_time": None,
            "close_price": None,
            "final_pnl": None,
            "reasons": decision.get("reasons", []),
            "signal_snapshot": decision,
            "last_updated": now_iso,
        }

        # Backwards-compatible: set 'side' alongside 'type' for clearer naming
        trade_data["side"] = trade_data.get("type")
        trade_data.update(self._entry_enrichment(decision, signal, symbol, entry_price, stop_loss))

        # BUILD31-R13: persist entry-time EVIDENCE (vwap/atr/dealing range) at
        # the TOP LEVEL of the row. Before this, the forensic audit had to dig
        # into signal_snapshot paths the engine often never populated, so the
        # VWAP-band and 80/20-range guards ran on UNKNOWN for every trade
        # (measured on the live book: 5/5 trades missing evidence).
        trade_data.update(self._entry_evidence(decision, symbol))

        # BUILD31-R13: record which R10/R11 guards WOULD have
        # blocked this entry - log-only, never blocks the save. The audit
        # report and this field share one implementation
        # (services/guard_replay.py), so they cannot drift apart.
        try:
            from services.guard_replay import would_block_for, load_json_rows
            book = load_json_rows(self.local_path) if self.local_path else []
            trade_data["would_block"] = would_block_for(trade_data, book)
        except Exception as guard_exc:  # noqa: BLE001
            trade_data["would_block"] = None
            self.logger.debug("would_block guard eval skipped: %s", guard_exc)

        if self.use_supabase and self.client:
            try:
                self._insert_trade_supabase(trade_data)
                try:
                    if not os.environ.get("PYTEST_CURRENT_TEST"):
                        self.path_performance.record_trade(trade_data)
                except Exception as measure_exc:  # noqa: BLE001
                    self.logger.warning("Path-performance mirror failed without affecting trade save: %s", measure_exc)
                return trade_id
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Failed to save trade in Supabase in production: {exc}") from exc
                self.logger.error("Failed to save trade in Supabase, falling back local: %s", exc)

        mutate_trades(lambda trades: trades.append(trade_data), self.local_path)
        try:
            if not os.environ.get("PYTEST_CURRENT_TEST"):
                self.path_performance.record_trade(trade_data)
        except Exception as measure_exc:  # noqa: BLE001
            self.logger.warning("Path-performance mirror failed without affecting trade save: %s", measure_exc)
        return trade_id

    def save_setup_candidate(self, candidate: Dict[str, Any]) -> str:
        """Persist or refresh a structured setup candidate.

        Sprint 1 scope: this stores the best currently-known setup context so
        later phases can evolve it into a full setup lifecycle/state machine.
        Supabase uses upsert by id; local fallback uses a JSON file.
        """
        candidate_id = str(candidate.get("id") or f"SETUP_{uuid.uuid4().hex[:16]}")
        now_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        zone = candidate.get("poi_zone") or candidate.get("zone") or {}
        setup_quality_value = candidate.get("setup_quality")
        setup_quality_grade = setup_quality_value.get("grade") if isinstance(setup_quality_value, dict) else setup_quality_value
        setup_quality_score = setup_quality_value.get("score", candidate.get("quality_score", 0)) if isinstance(setup_quality_value, dict) else candidate.get("quality_score", 0)
        payload = {
            "id": candidate_id,
            "state_key": str(candidate.get("state_key") or candidate_id),
            "symbol": str(candidate.get("symbol") or self.config.get("symbol", "XAU/USD")),
            "timeframe": str(candidate.get("timeframe") or self.config.get("entry_timeframe") or "15m"),
            "direction": str(candidate.get("direction") or "WAIT").upper(),
            "setup_type": candidate.get("setup_type") or "UNKNOWN",
            "setup_state": candidate.get("setup_state") or "DETECTED",
            "lead_agent": candidate.get("lead_agent") or "smc",
            "setup_quality": setup_quality_grade,
            "quality_score": float(setup_quality_score or 0),
            "poi_type": candidate.get("poi_type"),
            "poi_low": candidate.get("poi_low") if candidate.get("poi_low") is not None else zone.get("bottom"),
            "poi_high": candidate.get("poi_high") if candidate.get("poi_high") is not None else zone.get("top"),
            "entry_price": candidate.get("entry_price"),
            "stop_loss": candidate.get("stop_loss"),
            "target_price": candidate.get("target_price") or candidate.get("target_liquidity"),
            "sweep_side": candidate.get("sweep_side"),
            "displacement_score": candidate.get("displacement_score"),
            "confidence": candidate.get("confidence"),
            "details": candidate.get("details") or {},
            "source": candidate.get("source") or "smc",
            "is_active": bool(candidate.get("is_active", True)),
            "first_seen_at": _iso_ts(candidate.get("first_seen_at") or candidate.get("created_at")) or now_iso,
            "last_seen_at": _iso_ts(candidate.get("last_seen_at")) or now_iso,
            "last_transition_at": _iso_ts(candidate.get("last_transition_at")) or now_iso,
            "transition_count": int(candidate.get("transition_count", 0) or 0),
            "missing_cycles": int(candidate.get("missing_cycles", 0) or 0),
            "last_trade_id": candidate.get("last_trade_id"),
            "updated_at": now_iso,
        }
        if self.use_supabase and self.client:
            try:
                self.client.table("setup_candidates").upsert(payload).execute()
                return candidate_id
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Failed to save setup candidate in production: {exc}") from exc
                self.logger.error("Failed to upsert setup candidate in Supabase, falling back local: %s", exc)
        candidates = load_trades(self.setup_candidates_path)
        replaced = False
        for index, existing in enumerate(candidates):
            same_id = str(existing.get("id")) == candidate_id
            same_state_key = bool(payload.get("state_key")) and str(existing.get("state_key") or "") == str(payload.get("state_key"))
            if same_id or same_state_key:
                merged = dict(existing)
                merged.update(payload)
                merged["id"] = existing.get("id") or payload["id"]
                merged["first_seen_at"] = existing.get("first_seen_at") or payload["first_seen_at"]
                candidates[index] = merged
                replaced = True
                break
        if not replaced:
            candidates.append(payload)
        save_trades(candidates, self.setup_candidates_path)
        return candidate_id

    def get_recent_setup_candidates(self, limit: int = 20, symbol: str | None = None) -> List[Dict[str, Any]]:
        if self.use_supabase and self.client:
            try:
                query = self.client.table("setup_candidates").select("*").order("last_seen_at", desc=True).limit(limit)
                if symbol:
                    query = query.eq("symbol", symbol)
                response = query.execute()
                return list(response.data or [])
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Failed to fetch setup candidates in production: {exc}") from exc
                self.logger.error("Failed to fetch setup candidates from Supabase: %s", exc)
        rows = load_trades(self.setup_candidates_path)
        if symbol:
            rows = [row for row in rows if str(row.get("symbol", "")).upper() == str(symbol).upper()]
        return sorted(rows, key=lambda row: str(row.get("last_seen_at") or row.get("updated_at") or ""), reverse=True)[:limit]

    def get_active_setup_candidates(self, symbol: str | None = None) -> List[Dict[str, Any]]:
        terminal = {"ENTRY_TRIGGERED", "INVALIDATED", "EXPIRED"}
        if self.use_supabase and self.client:
            try:
                query = self.client.table("setup_candidates").select("*").eq("is_active", True)
                if symbol:
                    query = query.eq("symbol", symbol)
                response = query.execute()
                rows = list(response.data or [])
                return [row for row in rows if str(row.get("setup_state") or "").upper() not in terminal]
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Failed to fetch active setup candidates in production: {exc}") from exc
                self.logger.error("Failed to fetch active setup candidates from Supabase: %s", exc)
        rows = load_trades(self.setup_candidates_path)
        if symbol:
            rows = [row for row in rows if str(row.get("symbol", "")).upper() == str(symbol).upper()]
        return [row for row in rows if bool(row.get("is_active", True)) and str(row.get("setup_state") or "").upper() not in terminal]

    def save_setup_state_event(self, event: Dict[str, Any]) -> str:
        event_id = str(event.get("id") or f"SETUP_EVENT_{uuid.uuid4().hex[:16]}")
        now_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        payload = {
            "id": event_id,
            "setup_id": str(event.get("setup_id") or ""),
            "state_key": str(event.get("state_key") or ""),
            "symbol": str(event.get("symbol") or self.config.get("symbol", "XAU/USD")),
            "from_state": event.get("from_state"),
            "to_state": event.get("to_state"),
            "reason": event.get("reason") or "state_transition",
            "price": event.get("price"),
            "payload": event.get("payload") or {},
            "created_at": _iso_ts(event.get("created_at")) or now_iso,
            "updated_at": now_iso,
        }
        path = self.setup_state_events_path
        if self.use_supabase and self.client:
            try:
                self.client.table("setup_state_events").insert(payload).execute()
                return event_id
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Failed to save setup state event in production: {exc}") from exc
                self.logger.error("Failed to insert setup state event in Supabase, falling back local: %s", exc)
        rows = load_trades(path)
        rows.append(payload)
        save_trades(rows, path)
        return event_id

    def save_analyst_label(self, label: Dict[str, Any]) -> str:
        """Persist a discretionary analyst label for later bot-vs-analyst comparison."""
        label_id = str(label.get("id") or f"ANALYST_{uuid.uuid4().hex[:16]}")
        now_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        payload = {
            "id": label_id,
            "symbol": str(label.get("symbol") or self.config.get("symbol", "XAU/USD")),
            "timeframe": str(label.get("timeframe") or self.config.get("entry_timeframe") or "15m"),
            "analyst_name": str(label.get("analyst_name") or "manual"),
            "bias": str(label.get("bias") or label.get("direction") or "WAIT").upper(),
            "setup_type": label.get("setup_type") or "UNKNOWN",
            "sweep_side": label.get("sweep_side"),
            "poi_type": label.get("poi_type"),
            "poi_quality_grade": label.get("poi_quality_grade") or label.get("quality_grade"),
            "intended_entry": label.get("intended_entry"),
            "invalidation": label.get("invalidation"),
            "tp1": label.get("tp1"),
            "tp2": label.get("tp2"),
            "session_label": label.get("session_label") or label.get("session"),
            "trade_decision": str(label.get("trade_decision") or "TRADE").upper(),
            "notes": label.get("notes") or "",
            "source": label.get("source") or "manual_label",
            "created_at": label.get("created_at") or now_iso,
            "updated_at": now_iso,
        }
        if self.use_supabase and self.client:
            try:
                self.client.table("analyst_labels").upsert(payload).execute()
                return label_id
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Failed to save analyst label in production: {exc}") from exc
                self.logger.error("Failed to upsert analyst label in Supabase, falling back local: %s", exc)
        rows = load_trades(self.analyst_labels_path)
        replaced = False
        for index, existing in enumerate(rows):
            if str(existing.get("id")) == label_id:
                merged = dict(existing)
                merged.update(payload)
                merged["created_at"] = existing.get("created_at") or payload["created_at"]
                rows[index] = merged
                replaced = True
                break
        if not replaced:
            rows.append(payload)
        save_trades(rows, self.analyst_labels_path)
        return label_id

    def get_analyst_labels(self, limit: int = 50, symbol: str | None = None) -> List[Dict[str, Any]]:
        if self.use_supabase and self.client:
            try:
                query = self.client.table("analyst_labels").select("*").order("created_at", desc=True).limit(limit)
                if symbol:
                    query = query.eq("symbol", symbol)
                response = query.execute()
                return list(response.data or [])
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Failed to fetch analyst labels in production: {exc}") from exc
                self.logger.error("Failed to fetch analyst labels from Supabase: %s", exc)
        rows = load_trades(self.analyst_labels_path)
        if symbol:
            rows = [row for row in rows if str(row.get("symbol", "")).upper() == str(symbol).upper()]
        return sorted(rows, key=lambda row: str(row.get("created_at") or row.get("updated_at") or ""), reverse=True)[:limit]

    def save_analyst_comparison(self, comparison: Dict[str, Any]) -> str:
        comparison_id = str(comparison.get("id") or f"COMPARE_{uuid.uuid4().hex[:16]}")
        now_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        payload = {
            "id": comparison_id,
            "analyst_label_id": comparison.get("analyst_label_id"),
            "setup_candidate_id": comparison.get("setup_candidate_id"),
            "symbol": str(comparison.get("symbol") or self.config.get("symbol", "XAU/USD")),
            "match_score": comparison.get("match_score"),
            "classification": comparison.get("classification") or "UNREVIEWED",
            "summary": comparison.get("summary") or "",
            "payload": comparison.get("payload") or {},
            "created_at": comparison.get("created_at") or now_iso,
            "updated_at": now_iso,
        }
        if self.use_supabase and self.client:
            try:
                self.client.table("analyst_comparisons").upsert(payload).execute()
                return comparison_id
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Failed to save analyst comparison in production: {exc}") from exc
                self.logger.error("Failed to upsert analyst comparison in Supabase, falling back local: %s", exc)
        rows = load_trades(self.analyst_comparisons_path)
        replaced = False
        for index, existing in enumerate(rows):
            if str(existing.get("id")) == comparison_id:
                merged = dict(existing)
                merged.update(payload)
                rows[index] = merged
                replaced = True
                break
        if not replaced:
            rows.append(payload)
        save_trades(rows, self.analyst_comparisons_path)
        return comparison_id

    def save_session_plan(self, plan: Dict[str, Any], analysis_context: Dict[str, Any] | None = None) -> str:
        """Persist a day-map / session-plan snapshot for production auditability.

        Unlike trades, plans must be visible even when NO trade was opened.
        Each save writes a snapshot row so the dashboard/API can show what the
        system believed the day map was at that analysis cycle.
        """
        if not isinstance(plan, dict):
            return ""
        analysis_context = analysis_context or {}
        now_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        symbol = str(plan.get("symbol") or analysis_context.get("symbol") or self.config.get("symbol", "XAU/USD"))
        snapshot_id = str(
            plan.get("snapshot_id")
            or analysis_context.get("snapshot_id")
            or f"SESSION_PLAN_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')}_{uuid.uuid4().hex[:8]}"
        )
        payload = {
            "id": snapshot_id,
            "plan_id": plan.get("plan_id"),
            "scenario_id": plan.get("scenario_id"),
            "symbol": symbol,
            "session_label": plan.get("session_label"),
            "session_quality": plan.get("session_quality"),
            "session_bias": plan.get("session_bias"),
            "scenario_type": plan.get("scenario_type"),
            "planner_source": plan.get("planner_source"),
            "authority_state": plan.get("authority_state"),
            "authority_direction": plan.get("authority_direction"),
            "plan_ready": bool(plan.get("plan_ready", False)),
            "plan_status": plan.get("plan_status"),
            "plan_reason": plan.get("plan_reason"),
            "planner_confidence": plan.get("planner_confidence"),
            "planner_grade": plan.get("planner_grade"),
            "poi_classification": plan.get("poi_classification"),
            "extreme_poi": bool(plan.get("extreme_poi", False)),
            "primary_entry_price": plan.get("primary_entry_price"),
            "standby_entry_price": plan.get("standby_entry_price"),
            "invalidation_level": plan.get("invalidation_level"),
            "target_liquidity": plan.get("target_liquidity"),
            "market_zone_context": plan.get("market_zone_context"),
            "structure_trend": plan.get("structure_trend"),
            "structure_quality": plan.get("structure_quality"),
            "execution_preference": plan.get("execution_preference"),
            "expected_path": plan.get("expected_path"),
            "current_price": analysis_context.get("current_price"),
            "market_data_source": analysis_context.get("market_data_source"),
            "analysis_run_at": analysis_context.get("analysis_run_at") or now_iso,
            "plan_created_at": plan.get("plan_created_at") or now_iso,
            "plan_expires_at": plan.get("plan_expires_at"),
            "payload": plan,
            "telegram_sent_at": None,
            "telegram_delivery_note": None,
            "created_at": now_iso,
            "updated_at": now_iso,
        }
        if self.use_supabase and self.client:
            try:
                self.client.table("session_plans").insert(payload).execute()
                return snapshot_id
            except Exception as exc:  # noqa: BLE001
                self.logger.error("Failed to insert session plan snapshot in Supabase, falling back local: %s", exc)
        rows = load_trades(self.session_plans_path)
        rows.append(payload)
        rows = sorted(
            rows,
            key=lambda row: str(row.get("analysis_run_at") or row.get("updated_at") or row.get("created_at") or ""),
            reverse=True,
        )[:500]
        save_trades(rows, self.session_plans_path)
        return snapshot_id

    def save_decision_audit(self, entry: Dict[str, Any]) -> str:
        """Record why a cycle ended where it did.

        Until now a blocked signal existed only as a log line in a workflow
        run that scrolls away. Answering "how many signals did the cross-path
        filter stop this week, and were they right to stop?" meant reading
        Actions output by hand, so nobody asked.

        Rows are written for refusals as well as deliveries, because the
        refusals are the interesting half: a filter that blocks everything and
        a filter that blocks nothing both look healthy in a trade table.
        """
        if not isinstance(entry, dict) or not entry:
            return ""
        # R25.6 belt: a pytest run must never touch the production audit
        # even if a fixture builds a DatabaseService without redirecting
        # the store. Production runs never set this flag.
        if (os.environ.get("PYTEST_RUNNING") == "1"
                and self.decision_audit_path == Path(__file__).resolve().parents[1] / "storage" / "decision_audit.json"):
            self.logger.warning(
                "PYTEST_RUNNING=1: refusing to write the production decision_audit")
            return ""
        now_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        audit_id = str(
            entry.get("id")
            or f"AUDIT_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')}_{uuid.uuid4().hex[:8]}"
        )
        payload = {
            "id": audit_id,
            "symbol": entry.get("symbol"),
            "stage": entry.get("stage"),
            "outcome": entry.get("outcome"),
            "side": entry.get("side"),
            "reason": entry.get("reason"),
            "entry_price": entry.get("entry_price"),
            "stop_loss": entry.get("stop_loss"),
            "tp1": entry.get("tp1"),
            "tp2": entry.get("tp2"),
            "tp1_rr": entry.get("tp1_rr"),
            "tp2_rr": entry.get("tp2_rr"),
            "confidence": entry.get("confidence"),
            "support_count": entry.get("support_count"),
            "oppose_count": entry.get("oppose_count"),
            "entry_mode": entry.get("entry_mode"),
            "trade_id": entry.get("trade_id"),
            "created_at": now_iso,
        }
        if self.use_supabase and self.client:
            try:
                self.client.table("decision_audit").insert(payload).execute()
                return audit_id
            except Exception as exc:  # noqa: BLE001
                self.logger.warning(
                    "Failed to insert decision audit in Supabase, falling back local: %s", exc
                )
        rows = load_trades(self.decision_audit_path)
        rows.append(payload)
        # R18: 2000 held ~28h once every WAIT cycle writes a row (6 symbols x
        # 5-min cycles). 6000 keeps ~3.5 days of refusal history for the funnel.
        rows = sorted(rows, key=lambda row: str(row.get("created_at") or ""), reverse=True)[:6000]
        save_trades(rows, self.decision_audit_path)
        return audit_id

    def get_recent_decision_audits(
        self,
        *,
        limit: int = 500,
        symbol: str | None = None,
        since: str | None = None,
    ) -> List[Dict[str, Any]]:
        """Read back the decision trail for reporting."""
        if self.use_supabase and self.client:
            try:
                query = self.client.table("decision_audit").select("*").order("created_at", desc=True).limit(limit)
                if symbol:
                    query = query.eq("symbol", str(symbol))
                if since:
                    query = query.gte("created_at", str(since))
                return list(query.execute().data or [])
            except Exception as exc:  # noqa: BLE001
                self.logger.error("Failed to fetch decision audits from Supabase: %s", exc)
        rows = load_trades(self.decision_audit_path)
        if symbol:
            rows = [row for row in rows if str(row.get("symbol") or "") == str(symbol)]
        if since:
            rows = [row for row in rows if str(row.get("created_at") or "") >= str(since)]
        rows.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
        return rows[:limit]

    def get_recent_session_plans(
        self,
        *,
        limit: int = 20,
        symbol: str | None = None,
        plan_ready_only: bool = False,
        sent_only: bool = False,
    ) -> List[Dict[str, Any]]:
        if self.use_supabase and self.client:
            try:
                query = self.client.table("session_plans").select("*").order("analysis_run_at", desc=True).limit(limit)
                if symbol:
                    query = query.eq("symbol", str(symbol))
                if plan_ready_only:
                    query = query.eq("plan_ready", True)
                response = query.execute()
                rows = list(response.data or [])
                if sent_only:
                    rows = [row for row in rows if row.get("telegram_sent_at")]
                return rows
            except Exception as exc:  # noqa: BLE001
                self.logger.error("Failed to fetch session plans from Supabase: %s", exc)
        rows = load_trades(self.session_plans_path)
        if symbol:
            rows = [row for row in rows if str(row.get("symbol") or "") == str(symbol)]
        if plan_ready_only:
            rows = [row for row in rows if bool(row.get("plan_ready", False))]
        if sent_only:
            rows = [row for row in rows if row.get("telegram_sent_at")]
        rows.sort(key=lambda row: str(row.get("analysis_run_at") or row.get("updated_at") or row.get("created_at") or ""), reverse=True)
        return rows[:limit]

    def get_latest_session_plan(self, symbol: str | None = None, *, plan_ready_only: bool = False) -> Dict[str, Any] | None:
        rows = self.get_recent_session_plans(limit=1, symbol=symbol, plan_ready_only=plan_ready_only)
        return rows[0] if rows else None

    def get_latest_sent_session_plan(self, symbol: str | None = None, *, plan_ready_only: bool = False) -> Dict[str, Any] | None:
        rows = self.get_recent_session_plans(limit=1, symbol=symbol, plan_ready_only=plan_ready_only, sent_only=True)
        return rows[0] if rows else None

    def mark_session_plan_telegram_sent(self, snapshot_id: str, note: str | None = None) -> None:
        if not snapshot_id:
            return
        now_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        updates = {
            "telegram_sent_at": now_iso,
            "telegram_delivery_note": str(note or "session_plan_telegram"),
            "updated_at": now_iso,
        }
        if self.use_supabase and self.client:
            try:
                self.client.table("session_plans").update(updates).eq("id", snapshot_id).execute()
                return
            except Exception as exc:  # noqa: BLE001
                self.logger.error("Failed to mark session plan Telegram delivery in Supabase: %s", exc)
        rows = load_trades(self.session_plans_path)
        changed = False
        for row in rows:
            if str(row.get("id")) == str(snapshot_id):
                row.update(updates)
                changed = True
                break
        if changed:
            save_trades(rows, self.session_plans_path)

    def merge_session_plan_payload(self, snapshot_id: str, payload_patch: Dict[str, Any], scalar_updates: Dict[str, Any] | None = None) -> None:
        if not snapshot_id or not isinstance(payload_patch, dict) or not payload_patch:
            return
        scalar_updates = dict(scalar_updates or {})
        now_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        scalar_updates.setdefault("updated_at", now_iso)
        if self.use_supabase and self.client:
            try:
                response = self.client.table("session_plans").select("payload").eq("id", snapshot_id).limit(1).execute()
                rows = list(response.data or [])
                current_payload = dict((rows[0] or {}).get("payload") or {}) if rows else {}
                merged_payload = self._deep_merge_dict(current_payload, payload_patch)
                updates = {"payload": merged_payload, **scalar_updates}
                self.client.table("session_plans").update(updates).eq("id", snapshot_id).execute()
                return
            except Exception as exc:  # noqa: BLE001
                self.logger.error("Failed to merge session plan payload in Supabase: %s", exc)
        rows = load_trades(self.session_plans_path)
        changed = False
        for row in rows:
            if str(row.get("id")) == str(snapshot_id):
                current_payload = dict(row.get("payload") or {}) if isinstance(row.get("payload"), dict) else {}
                row["payload"] = self._deep_merge_dict(current_payload, payload_patch)
                row.update(scalar_updates)
                changed = True
                break
        if changed:
            save_trades(rows, self.session_plans_path)

    @staticmethod
    def _deep_merge_dict(base: Dict[str, Any], patch: Dict[str, Any]) -> Dict[str, Any]:
        merged = dict(base or {})
        for key, value in (patch or {}).items():
            if isinstance(value, dict) and isinstance(merged.get(key), dict):
                merged[key] = DatabaseService._deep_merge_dict(dict(merged.get(key) or {}), value)
            else:
                merged[key] = value
        return merged

    @staticmethod
    def _build_regime_composite(tech_regime: dict) -> str:
        """Build a composite regime label from volatility_regime + market_phase.

        Examples: 'NORMAL TRENDING', 'HIGH RANGING', 'SQUEEZE', etc.
        Returns 'UNKNOWN' if neither dimension is available.
        """
        vol = str(tech_regime.get("volatility_regime") or "").strip().upper()
        phase = str(tech_regime.get("market_phase") or "").strip().upper()
        if phase == "SQUEEZE":
            return "SQUEEZE"
        if vol and phase:
            return f"{vol} {phase}"
        if vol:
            return vol
        if phase:
            return phase
        return "LEGACY"

    def _entry_enrichment(
        self,
        decision: Dict[str, Any],
        signal: Dict[str, Any],
        symbol: str,
        entry_price: float,
        stop_loss: float,
    ) -> Dict[str, Any]:
        """Best-effort Phase 5 metadata persisted with each trade.

        Older Supabase schemas may not have all columns; insert retry logic drops
        unknown columns while keeping this data in signal_snapshot. When columns
        exist, reports can query directly without parsing JSON snapshots.
        """
        now = datetime.now(timezone.utc)
        try:
            local = now.astimezone(ZoneInfo(str(self.config.get("schedule", {}).get("timezone") or self.config.get("trading_hours", {}).get("timezone") or "Asia/Hebron")))
        except Exception:  # noqa: BLE001
            local = now
        side = str(decision.get("decision") or signal.get("type") or "").upper()
        tp2 = signal.get("tp2")
        try:
            planned_risk_points = abs(price_to_points(float(entry_price) - float(stop_loss), symbol=symbol))
        except Exception:  # noqa: BLE001
            planned_risk_points = 0.0
        try:
            planned_tp2_points = abs(price_to_points(float(tp2) - float(entry_price), symbol=symbol)) if tp2 is not None else 0.0
        except Exception:  # noqa: BLE001
            planned_tp2_points = 0.0
        planned_rr = float(signal.get("rr_ratio") or signal.get("tp2_rr") or 0) or (planned_tp2_points / planned_risk_points if planned_risk_points else 0.0)
        session_info = decision.get("session_info") or {}
        news_context = decision.get("news_context") or {}
        market_context = decision.get("market_context") or {}
        news_rule = news_context.get("rule_based", {}) if isinstance(news_context, dict) else {}
        tech_regime = market_context.get("technical_regime", {}) if isinstance(market_context, dict) else {}
        if not isinstance(tech_regime, dict):
            tech_regime = {}
        # Session label: prefer the already-classified name from
        # TradingSessionAgent (which now uses classify_session), fall back to
        # computing from the current UTC timestamp so we never store a raw
        # config name like "Main Trading Session".
        stored_session = (
            session_info.get("current_session")
            or session_info.get("session")
            or session_info.get("session_name")
        )
        session_label = (
            stored_session if stored_session in SESSION_ORDER
            else session_label_from_utc(now)
        )
        setup_context = decision.get("setup_context") or {}
        if not isinstance(setup_context, dict):
            setup_context = {}
        quality = decision.get("quality") or {}
        return {
            "planned_risk_points": round(planned_risk_points, 1),
            "planned_tp2_points": round(planned_tp2_points, 1),
            "planned_rr": round(planned_rr, 2),
            # Route provenance at the TOP LEVEL of the trade row. The ladder
            # decision carries entry_mode="session_plan_ladder_market" and a
            # stamped execution_path, but save_trade only kept them inside
            # signal_snapshot — so TRADE_20260817_110616 (the first unified-65
            # gold trade) answered `null` for entry_mode/execution_path to any
            # surface-level query or report. Reports must not need to parse
            # the snapshot JSON to learn which path opened a trade.
            "entry_mode": decision.get("entry_mode"),
            "entry_path": decision.get("entry_path"),
            # R25.9 (2026-08-31): mt5_demo MARKET rows arrived with a null
            # execution_path_id (4 live trades, 3 of them losses) so path P&L
            # attribution and per-path reports lost them. Resolve provenance
            # from nested snapshots before falling back to None.
            "execution_path_id": self._resolve_execution_path_id(decision, signal),
            "execution_path_name": decision.get("execution_path_name")
                or ((decision.get("execution_path") or {}).get("name")
                    if isinstance(decision.get("execution_path"), dict) else None),
            "confirm_source": decision.get("confirm_source"),
            "warnings": [str(w) for w in (decision.get("warnings") or []) if str(w).strip()],
            "session_label": session_label,
            "session_quality": session_info.get("session_quality") or session_info.get("quality"),
            "entry_day_of_week": local.strftime("%A"),
            "entry_hour_local": int(local.hour),
            "news_status_at_entry": news_rule.get("market_status") or news_rule.get("status"),
            "news_risk_at_entry": news_rule.get("risk_level") or news_rule.get("risk"),
            "volatility_regime": tech_regime.get("volatility_regime"),
            "market_phase": tech_regime.get("market_phase"),
            "regime_composite": self._build_regime_composite(tech_regime),
            "trend_strength": tech_regime.get("trend_strength"),
            "daily_bias_at_entry": (decision.get("daily_bias") or {}).get("bias") if isinstance(decision.get("daily_bias"), dict) else None,
            "primary_entry_driver": (decision.get("entry_attribution") or {}).get("primary_entry_driver") if isinstance(decision.get("entry_attribution"), dict) else None,
            "entry_failure_mode": (decision.get("entry_attribution") or {}).get("failure_mode") if isinstance(decision.get("entry_attribution"), dict) else None,
            "macro_bias_at_entry": ((decision.get("market_context") or {}).get("macro_direction") or {}).get("bias") if isinstance((decision.get("market_context") or {}).get("macro_direction"), dict) else None,
            "setup_id": decision.get("setup_id") or setup_context.get("id"),
            "setup_type": decision.get("setup_type") or setup_context.get("setup_type"),
            "setup_state": decision.get("setup_state") or setup_context.get("setup_state"),
            "lead_agent": decision.get("lead_agent") or setup_context.get("lead_agent") or (decision.get("entry_attribution") or {}).get("primary_entry_driver"),
            "setup_quality": decision.get("setup_quality") or setup_context.get("quality_grade") or quality.get("grade"),
            "poi_type": setup_context.get("poi_type"),
            "sweep_side": setup_context.get("sweep_side"),
            "displacement_score": setup_context.get("displacement_score"),
        }

    def _entry_evidence(self, decision: Dict[str, Any], symbol: str) -> Dict[str, Any]:
        """Row-level guard evidence for the R13 audit loop.

        Deep-searches the decision blob for session VWAP, ATR and the dealing
        range so the guard replay never has to answer UNKNOWN when the engine
        did produce the numbers somewhere. All fields may stay None when the
        engine genuinely had nothing - absence is reported, never invented.
        """
        try:
            from services.guard_replay import _deep_find_first, _dig

            def _num(value):
                try:
                    return float(value)
                except (TypeError, ValueError):
                    return None

            decimals = price_decimals(symbol)
            snap = decision.get("signal_snapshot") if isinstance(decision.get("signal_snapshot"), dict) else decision
            # Structured paths first (same paths the audit replays); deep
            # search only for keys specific enough to avoid grabbing candle
            # highs/lows or entry levels by mistake.
            vwap = _dig(snap, ("auction_flow", "session_vwap"),
                        ("agents", "auction_flow", "session_vwap"))
            if vwap is None:
                vwap = _deep_find_first(snap, "session_vwap")
            atr = _dig(snap, ("technical", "atr"), ("volatility", "atr"))
            if atr is None:
                atr = _deep_find_first(snap, "atr")
            dealing = (_dig(snap, ("smc", "dealing_range"))
                       or _deep_find_first(snap, "dealing_range") or {})
            if not isinstance(dealing, dict):
                dealing = {}
            rh, rl = _num(dealing.get("high")), _num(dealing.get("low"))
            out = {
                "entry_vwap": round(vwap, decimals) if _num(vwap) is not None else None,
                "entry_atr": round(atr, decimals) if _num(atr) is not None else None,
                "range_high": round(rh, decimals) if rh is not None else None,
                "range_low": round(rl, decimals) if rl is not None else None,
            }
            return out
        except Exception:  # noqa: BLE001 - evidence must never break a save
            return {"entry_vwap": None, "entry_atr": None,
                    "range_high": None, "range_low": None}

    # Statuses the trade manager must still evaluate each cycle. PENDING is
    # included so a not-yet-filled LIMIT/STOP order can be activated on touch
    # (or expired/cancelled) — it is NOT a live position until it fills.
    ACTIVE_STATUSES = ["OPEN", "PARTIAL", "TP1_HIT", "PENDING"]

    def get_open_trades(self) -> List[Dict[str, Any]]:
        """Get trades the manager should process: live (OPEN/PARTIAL/TP1_HIT)
        plus not-yet-filled PENDING limit/stop orders."""
        if self.use_supabase and self.client:
            try:
                response = self.client.table(self.trades_table).select("*").in_("status", self.ACTIVE_STATUSES).execute()
                return list(response.data or [])
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Failed to fetch open trades from Supabase in production: {exc}") from exc
                self.logger.error("Failed to fetch open trades from Supabase: %s", exc)
        # Execution path uses the strict read: corrupt/contended storage must
        # fail closed, never masquerade as an empty book and cancel broker orders.
        return [trade for trade in load_trades_checked(self.local_path)
                if trade.get("status") in set(self.ACTIVE_STATUSES)]

    def save_macro_context(self, context: Dict[str, Any]) -> bool:
        """Persist latest hourly macro context in Supabase when schema exists.

        The analysis workflow can read this snapshot without spending Twelve
        Data quota every 5 minutes. Missing table/columns are treated as a safe
        no-op because local storage remains available for manual runs.
        """
        if not (self.use_supabase and self.client):
            return False
        payload = {
            "id": "latest",
            "context": context,
            "source": context.get("source"),
            "generated_at": context.get("generated_at"),
            "updated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        }
        try:
            self.client.table("macro_context").upsert(payload).execute()
            return True
        except Exception as exc:  # noqa: BLE001
            self.logger.warning("Could not save macro_context snapshot: %s", exc)
            return False

    def get_macro_context(self) -> Dict[str, Any]:
        """Load latest persisted macro context from Supabase or local file."""
        if self.use_supabase and self.client:
            try:
                response = self.client.table("macro_context").select("context").eq("id", "latest").limit(1).execute()
                rows = list(response.data or [])
                if rows and isinstance(rows[0].get("context"), dict):
                    return dict(rows[0]["context"])
            except Exception as exc:  # noqa: BLE001
                self.logger.warning("Could not read macro_context snapshot: %s", exc)
        local = Path(__file__).resolve().parents[1] / "storage" / "macro_context.json"
        if local.exists():
            try:
                import json
                data = json.loads(local.read_text(encoding="utf-8"))
                return data if isinstance(data, dict) else {}
            except Exception as exc:  # noqa: BLE001
                self.logger.warning("Could not read local macro_context.json: %s", exc)
        return {}


    async def execute_query(self, query: str, params: List[Any] | None = None) -> List[Dict[str, Any]]:
        """Small compatibility layer for older services that used raw SQL.

        Supabase's Python PostgREST client does not execute arbitrary SQL directly.
        This method supports the common read/write patterns used by this project and
        falls back safely instead of crashing scheduled GitHub Actions.
        """
        params = params or []
        q = " ".join(str(query).strip().lower().split())

        # Local fallback / generic reads from trades.
        if "from trades" in q:
            trades = load_trades(self.local_path)
            if self.use_supabase and self.client:
                try:
                    response = self.client.table(self.trades_table).select("*").execute()
                    trades = list(response.data or [])
                except Exception as exc:  # noqa: BLE001
                    self.logger.error("execute_query trades fallback after Supabase error: %s", exc)
            if "where" in q and "status" in q:
                if "open" in q or "tp1_hit" in q or "partial" in q:
                    trades = [t for t in trades if str(t.get("status", "")).upper() in {"OPEN", "PARTIAL", "TP1_HIT"}]
                elif "closed_at is not null" in q or "status not in" in q:
                    trades = [t for t in trades if str(t.get("status", "")).upper() not in {"OPEN", "PARTIAL", "TP1_HIT", "PENDING"}]
            return trades

        # agent_weights read/update compatibility.
        if "from agent_weights" in q:
            if self.use_supabase and self.client:
                try:
                    response = self.client.table("agent_weights").select("*").execute()
                    return list(response.data or [])
                except Exception as exc:  # noqa: BLE001
                    self.logger.error("Failed to read agent_weights: %s", exc)
            return []

        if "insert into agent_weights" in q or "update agent_weights" in q:
            if self.use_supabase and self.client and len(params) >= 2:
                try:
                    agent_name = str(params[0])
                    weight = float(params[1])
                    self.client.table("agent_weights").upsert({"agent_name": agent_name, "weight": weight}).execute()
                except Exception as exc:  # noqa: BLE001
                    self.logger.error("Failed to upsert agent_weights: %s", exc)
            return []

        self.logger.warning("Unsupported execute_query call ignored safely: %s", str(query)[:160])
        return []

    def update_trade(self, trade_id: str, updates: Dict[str, Any]) -> None:
        """Update a trade by id."""
        if self.use_supabase and self.client:
            try:
                self._update_trade_supabase(trade_id, updates)
                try:
                    if not os.environ.get("PYTEST_CURRENT_TEST"):
                        self.path_performance.record_update(trade_id, updates)
                except Exception as measure_exc:  # noqa: BLE001
                    self.logger.warning("Path-performance mirror update failed without affecting trade: %s", measure_exc)
                return
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Failed to update Supabase trade {trade_id} in production: {exc}") from exc
                self.logger.error("Failed to update Supabase trade %s: %s", trade_id, exc)

        def _update_local(trades: List[Dict[str, Any]]) -> None:
            for trade in trades:
                if str(trade.get("id")) == trade_id:
                    trade.update(updates)
                    # Keep type/side in sync for backward compatibility.
                    if "type" in updates and "side" not in updates:
                        trade["side"] = updates.get("type")
                    if "side" in updates and "type" not in updates:
                        trade["type"] = updates.get("side")
                    break

        mutate_trades(_update_local, self.local_path)
        try:
            if not os.environ.get("PYTEST_CURRENT_TEST"):
                self.path_performance.record_update(trade_id, updates)
        except Exception as measure_exc:  # noqa: BLE001
            self.logger.warning("Path-performance mirror update failed without affecting trade: %s", measure_exc)
        # R25.9 (2026-08-31): reflection memory was never written - record_burn
        # existed but had no caller, so storage/reflection_memory.json never
        # appeared and the cooldown veto had no memory to learn from. Record a
        # burn when a trade closes at a loss (SL or thesis exit in the red) at
        # its entry POI, so the agent stops walking straight back into the same
        # trap. Fail-open: reflection must never block trade lifecycle.
        self._maybe_record_reflection_burn(trade_id, updates)

    def _maybe_record_reflection_burn(self, trade_id: str, updates: Dict[str, Any]) -> None:
        """Record a reflection 'burn' when a trade closes at a loss.

        Uses the stop-hunt cooldown the reflection agent already implements;
        pure best-effort and disabled under tests / when the agent is off.
        """
        if os.environ.get("PYTEST_CURRENT_TEST"):
            return
        try:
            new_status = str(updates.get("status", "")).upper()
            closed_events = {"SL_HIT", "TRAILING_SL_HIT", "THESIS_EXIT", "BE_HIT",
                             "TP2_HIT", "MANUAL_CLOSE", "CLOSED"}
            if new_status not in closed_events:
                return
            pnl = None
            for key in ("final_pnl", "realized_usd", "current_pnl", "pnl_points"):
                v = updates.get(key)
                if v is not None:
                    try:
                        pnl = float(v)
                        break
                    except (TypeError, ValueError):
                        continue
            if pnl is None or pnl >= 0:
                return  # only log real losses into the burn memory
            trades = load_trades(self.local_path)
            row = next((t for t in trades if str(t.get("id")) == trade_id), None)
            if not row:
                return
            symbol = str(row.get("symbol") or (self.config or {}).get("symbol") or "")
            if not symbol:
                return
            direction = str(row.get("type") or row.get("side") or "").upper()
            level = float(row.get("entry_price") or 0.0)
            if level <= 0 or direction not in {"BUY", "SELL"}:
                return
            cfg = self.config if isinstance(getattr(self, "config", None), dict) else load_config()
            rblock = (cfg or {}).get("reflection_agent") or {}
            if not bool(rblock.get("enabled", True)):
                return
            from services.reflection_agent import ReflectionAgent
            agent = ReflectionAgent(cfg)
            agent.record_burn(
                symbol=symbol, level=level, direction=direction,
                burn_type=("stop_hit" if new_status in {"SL_HIT", "TRAILING_SL_HIT"}
                           else "thesis_exit_loss"),
                trade_id=trade_id,
                extra={"pnl": pnl, "status": new_status,
                       "path": row.get("execution_path_id")},
            )
        except Exception as exc:  # noqa: BLE001 - fail-open
            try:
                self.logger.warning("Reflection burn record failed (fail-open): %s", exc)
            except Exception:  # noqa: BLE001
                pass

    def cancel_pending_orders(
        self,
        reason: str = "Replaced by a newer signal",
        *,
        symbol: str | None = None,
        direction: str | None = None,
    ) -> int:
        """Cancel not-yet-filled PENDING orders.

        Optional filters let the signal pipeline replace only stale pending
        orders for the same symbol/direction instead of cancelling every pending
        order globally.
        """
        now_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        cancelled = 0
        norm_symbol = str(symbol or "").upper() if symbol else None
        norm_direction = str(direction or "").upper() if direction else None

        def _matches(trade: Dict[str, Any]) -> bool:
            if str(trade.get("status", "")).upper() != "PENDING":
                return False
            if norm_symbol and str(trade.get("symbol") or "").upper() != norm_symbol:
                return False
            trade_dir = str(trade.get("type") or trade.get("side") or "").upper()
            if norm_direction and trade_dir != norm_direction:
                return False
            return True

        if self.use_supabase and self.client:
            try:
                query = self.client.table(self.trades_table).select("id,symbol,type,side,status").eq("status", "PENDING")
                if norm_symbol:
                    query = query.eq("symbol", norm_symbol)
                if norm_direction:
                    query = query.eq("type", norm_direction)
                resp = query.execute()
                rows = [r for r in (resp.data or []) if _matches(r)]
                for row in rows:
                    tid = row.get("id")
                    if not tid:
                        continue
                    self.update_trade(str(tid), {
                        "status": "CANCELLED", "result": "CANCELLED",
                        "closed_at": now_iso, "close_time": now_iso,
                        "reasons": [reason], "last_updated": now_iso,
                    })
                    cancelled += 1
                return cancelled
            except Exception as exc:  # noqa: BLE001
                if self._strict_supabase():
                    raise RuntimeError(f"Failed to cancel pending orders in production: {exc}") from exc
                self.logger.error("Failed to cancel pending orders from Supabase: %s", exc)

        def _cancel_local(trades: List[Dict[str, Any]]) -> int:
            count = 0
            for trade in trades:
                if _matches(trade):
                    trade.update({
                        "status": "CANCELLED", "result": "CANCELLED",
                        "closed_at": now_iso, "close_time": now_iso,
                        "reasons": [reason], "last_updated": now_iso,
                    })
                    count += 1
            return count

        return mutate_trades(_cancel_local, self.local_path)

    def _missing_column_name(self, exc: Exception) -> str | None:
        """Extract the missing column name from a Supabase/PostgREST error.

        Handles both error styles:
          * PostgREST schema-cache: PGRST204 -> "Could not find the 'X' column
            of 'trades' in the schema cache"
          * Postgres: 42703 -> "column \"X\" does not exist"
        Returns the column name (e.g. 'exit_warning') or None.
        """
        text = str(exc)
        # PGRST204 style: ... the 'X' column ...
        m = re.search(r"the '([^']+)' column", text)
        if m:
            return m.group(1)
        # 42703 style: column "X" does not exist
        m = re.search(r'column "([^"]+)" does not exist', text)
        if m:
            return m.group(1)
        # Fallback single-quoted Postgres style: column 'X' does not exist
        m = re.search(r"column '([^']+)' does not exist", text)
        if m:
            return m.group(1)
        return None

    def _missing_column(self, exc: Exception, column: str) -> bool:
        """Return True for Supabase/PostgREST missing-column errors."""
        text = str(exc).lower()
        if "42703" in text and column.lower() in text and "does not exist" in text:
            return True
        # PGRST204 schema-cache style.
        if "pgrst204" in text or "schema cache" in text:
            return column.lower() in text
        return False

    def _trade_time_text(self, trade: Dict[str, Any]) -> str:
        """Best available timestamp across current and legacy trade schemas."""
        for key in ("created_at", "entry_time", "opened_at", "updated_at", "last_updated", "closed_at"):
            value = trade.get(key)
            if value:
                return str(value)
        return ""

    def get_today_signals_count(self) -> int:
        """Return number of trades created today UTC."""
        return len(self.get_today_trades())

    def _date_window_utc(self, report_date: str, timezone_name: str = "UTC") -> tuple[str, str]:
        """Return UTC ISO [start, end) boundaries for a local report date."""
        day = date.fromisoformat(str(report_date))
        tz = timezone.utc
        if ZoneInfo is not None:
            try:
                tz = ZoneInfo(timezone_name or "UTC")
            except Exception:  # noqa: BLE001
                tz = timezone.utc
        start_local = datetime.combine(day, time.min, tzinfo=tz)
        end_local = start_local + timedelta(days=1)
        start_utc = start_local.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        end_utc = end_local.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        return start_utc, end_utc

    def get_trades_for_date(self, report_date: str | None = None, timezone_name: str = "UTC") -> List[Dict[str, Any]]:
        """Return trades for a specific local report date.

        Includes trades CREATED on that date OR trades CLOSED on that date.
        This ensures a trade opened yesterday but closed today appears in today's
        realized performance stats.
        """
        report_date = report_date or date.today().isoformat()
        start_utc, end_utc = self._date_window_utc(report_date, timezone_name)
        if self.use_supabase and self.client:
            try:
                # Query trades created OR closed within the window.
                # Using an 'or' filter in Supabase: (created_at >= start AND created_at < end) OR (closed_at >= start AND closed_at < end)
                filter_str = f"and(created_at.gte.{start_utc},created_at.lt.{end_utc}),and(closed_at.gte.{start_utc},closed_at.lt.{end_utc})"
                response = (
                    self.client.table(self.trades_table)
                    .select("*")
                    .or_(filter_str)
                    .execute()
                )
                return list(response.data or [])
            except Exception as exc:  # noqa: BLE001
                self.logger.error("Failed to fetch trades for %s from Supabase: %s", report_date, exc)

        # Local/debug fallback: check created_at or closed_at prefix
        return [
            trade for trade in load_trades(self.local_path)
            if self._trade_time_text(trade).startswith(str(report_date)) or
               str(trade.get("closed_at") or "").startswith(str(report_date))
        ]

    def get_today_trades(self) -> List[Dict[str, Any]]:
        """Return trades for today UTC/local-default, supporting legacy schemas."""
        return self.get_trades_for_date(date.today().isoformat(), "UTC")

    def get_open_trades_count(self) -> int:
        """Return open trades count."""
        return len(self.get_open_trades())

    def get_recent_trades(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Return recent trades ordered newest first, supporting legacy schemas."""
        if self.use_supabase and self.client:
            try:
                response = self.client.table(self.trades_table).select("*").order("created_at", desc=True).limit(limit).execute()
                return list(response.data or [])
            except Exception as exc:  # noqa: BLE001
                if self._missing_column(exc, "created_at"):
                    try:
                        response = self.client.table(self.trades_table).select("*").order("updated_at", desc=True).limit(limit).execute()
                        return list(response.data or [])
                    except Exception as fallback_exc:  # noqa: BLE001
                        if self._strict_supabase():
                            raise RuntimeError(f"Failed to fetch recent trades using legacy updated_at fallback: {fallback_exc}") from fallback_exc
                        self.logger.error("Failed legacy recent trades fallback from Supabase: %s", fallback_exc)
                elif self._strict_supabase():
                    raise RuntimeError(f"Failed to fetch recent trades from Supabase in production: {exc}") from exc
                else:
                    self.logger.error("Failed to fetch recent trades from Supabase: %s", exc)
        trades = load_trades(self.local_path)
        return sorted(trades, key=self._trade_time_text, reverse=True)[:limit]

    def get_recent_closed_trades(self, limit: int = 150) -> List[Dict[str, Any]]:
        """Recent FINISHED trades, newest close first.

        ``get_recent_trades`` answers "what was written recently" and returns
        whatever is newest by ``created_at`` -- pending orders, cancelled
        orders and open positions included. Anything that wants a performance
        record has to filter that list afterwards, and by then the window has
        already been spent on rows that have no outcome.

        That is why the two dashboards disagreed. The Telegram card pulled 80
        rows and filtered down to 52 closed trades; the web API asked the
        database for closed rows directly and got 85. Same maths, different
        sample, so the totals could never line up.

        Filtering in the query keeps the whole window on rows that can
        actually have a result, and mirrors what
        ``services/dashboard_local_api.py`` already does -- same status list, same
        ordering -- so both surfaces read the same trades.
        """
        statuses = sorted(performance_stats.CLOSED_STATUSES)
        if self.use_supabase and self.client:
            for order_column in ("closed_at", "close_time", "created_at"):
                try:
                    response = (
                        self.client.table(self.trades_table).select("*")
                        .in_("status", statuses)
                        .order(order_column, desc=True)
                        .limit(limit)
                        .execute()
                    )
                    return list(response.data or [])
                except Exception as exc:  # noqa: BLE001
                    if self._missing_column(exc, order_column):
                        continue
                    self.logger.warning(
                        "Could not fetch recent closed trades ordered by %s: %s",
                        order_column, exc,
                    )
                    break

        rows = [
            row for row in load_trades(self.local_path)
            if str(row.get("status") or "").upper() in performance_stats.CLOSED_STATUSES
        ]
        return sorted(
            rows,
            key=lambda r: str(r.get("closed_at") or r.get("close_time")
                              or self._trade_time_text(r) or ""),
            reverse=True,
        )[:limit]

    def get_trades_closed_since(
        self, since_iso: str, *, symbol: str | None = None, limit: int = 200
    ) -> List[Dict[str, Any]]:
        """Trades that CLOSED at or after ``since_iso``, newest close first.

        ``get_recent_trades`` orders by created_at, which answers a different
        question: "what was written recently". A trade opened hours ago and
        closed a minute ago is old by that measure and drops out of the list
        as soon as enough newer rows exist.

        The post-TP2 re-entry rule cares about when a target was TAKEN, so it
        needs this ordering instead. On 2026-08-03 the rule allowed a SELL
        152 points above a TP2 hit thirty minutes earlier, purely because the
        closed trade was no longer inside the created_at window.

        Falls back to a filtered read of recent history when the column is
        missing, so an older schema degrades rather than raising.
        """
        if self.use_supabase and self.client:
            for column in ("closed_at", "close_time"):
                try:
                    query = (
                        self.client.table(self.trades_table).select("*")
                        .gte(column, since_iso)
                        .order(column, desc=True)
                        .limit(limit)
                    )
                    if symbol:
                        query = query.eq("symbol", symbol)
                    response = query.execute()
                    return list(response.data or [])
                except Exception as exc:  # noqa: BLE001
                    if self._missing_column(exc, column):
                        continue
                    self.logger.warning(
                        "Could not read trades closed since %s by %s: %s",
                        since_iso, column, exc,
                    )
                    break

        rows = load_trades(self.local_path)
        result: List[Dict[str, Any]] = []
        for row in rows:
            if symbol and str(row.get("symbol") or "") != symbol:
                continue
            closed = str(row.get("closed_at") or row.get("close_time") or "")
            if closed and closed >= since_iso:
                result.append(row)
        return sorted(
            result,
            key=lambda r: str(r.get("closed_at") or r.get("close_time") or ""),
            reverse=True,
        )[:limit]

    def get_consecutive_losses(self, limit: int = 20) -> int:
        """Return consecutive losing closed trades, ignoring open trades."""
        losses = 0
        for trade in self.get_recent_trades(limit=limit):
            status = str(trade.get("status", "")).upper()
            if status in {"OPEN", "TP1_HIT"}:
                continue
            pnl = self._trade_pnl(trade)
            # SL_HIT is not automatically a loss: a trailing/breakeven stop can
            # close profitably (SL+) or at breakeven. Use PnL sign when present.
            is_loss = pnl < 0
            is_win_or_break = status in {"TP2_HIT", "BE_HIT", "THESIS_EXIT", "MANUAL_CLOSE", "EXPIRED"} or pnl >= 0
            if is_loss:
                losses += 1
                continue
            if is_win_or_break:
                break
        return losses

    # ── Partial alert tracker (Supabase with local file fallback) ──


    # How many unknown columns we are willing to strip one-by-one before giving
    # up and using the minimal legacy payload.
    _MAX_COLUMN_RETRIES = 12

    def _drop_missing_columns_and_retry(self, op, payload: Dict[str, Any]):
        """Run ``op(payload)``; if it fails on an unknown column, drop ONLY that
        column and retry, instead of collapsing to a tiny legacy payload.

        This preserves critical fields (stop_loss, result, sl_moved_to_entry,
        close_time, ...) that the old legacy fallback silently discarded — which
        is why trailing-stop / breakeven updates never persisted on older
        Supabase schemas. Only the genuinely missing columns are removed.
        """
        current = dict(payload)
        dropped: List[str] = []
        last_exc: Exception | None = None
        for _ in range(self._MAX_COLUMN_RETRIES):
            try:
                return op(current), dropped
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                col = self._missing_column_name(exc)
                if not col or col not in current:
                    break
                current.pop(col, None)
                dropped.append(col)
                if not current:
                    break
        # Could not resolve by dropping columns; surface for caller fallback.
        raise last_exc if last_exc else RuntimeError("Supabase operation failed")

    def _insert_trade_supabase(self, trade_data: Dict[str, Any]) -> None:
        """Insert full trade row.

        If the live schema is missing some newer columns, drop ONLY those and
        retry, so we still store as much as the schema supports. Fall back to the
        minimal legacy payload only as a last resort.
        """
        assert self.client is not None
        try:
            self.client.table(self.trades_table).insert(trade_data).execute()
            return
        except Exception as exc:  # noqa: BLE001
            try:
                _, dropped = self._drop_missing_columns_and_retry(
                    lambda p: self.client.table(self.trades_table).insert(p).execute(), trade_data
                )
                if dropped:
                    self.logger.warning(
                        "Trade insert succeeded after dropping unknown column(s): %s. "
                        "Add them to your Supabase 'trades' table (see supabase_schema.sql).",
                        ", ".join(dropped),
                    )
                return
            except Exception:  # noqa: BLE001
                legacy = self._legacy_payload(trade_data)
                if legacy == trade_data:
                    raise
                self.logger.warning("Full trade insert failed, trying legacy schema: %s", exc)
                self.client.table(self.trades_table).insert(legacy).execute()

    def _update_trade_supabase(self, trade_id: str, updates: Dict[str, Any]) -> None:
        """Update full trade row.

        Drop only unknown columns and retry (preserving stop_loss/result/etc.),
        falling back to the minimal legacy column set only if that still fails.
        """
        assert self.client is not None
        try:
            self.client.table(self.trades_table).update(updates).eq("id", trade_id).execute()
            return
        except Exception as exc:  # noqa: BLE001
            try:
                _, dropped = self._drop_missing_columns_and_retry(
                    lambda p: self.client.table(self.trades_table).update(p).eq("id", trade_id).execute(), updates
                )
                if dropped:
                    self.logger.warning(
                        "Trade %s update succeeded after dropping unknown column(s): %s. "
                        "Add them to your Supabase 'trades' table (see supabase_schema.sql).",
                        trade_id, ", ".join(dropped),
                    )
                return
            except Exception:  # noqa: BLE001
                legacy = self._legacy_payload(updates)
                if not legacy or legacy == updates:
                    raise
                self.logger.warning("Full trade update failed, trying legacy schema: %s", exc)
                self.client.table(self.trades_table).update(legacy).eq("id", trade_id).execute()

    def _legacy_payload(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Keep only columns from the initial Supabase schema for compatibility."""
        legacy_fields = {
            "id",
            "signal_id",
            "type",
            "side",
            "entry_price",
            "entry_time",
            "stop_loss",
            "initial_stop_loss",
            "tp1",
            "tp2",
            "confidence",
            "status",
            "order_kind",
            "order_type",
            "pending_cycles",
            "activation_reason",
            "market_data_source",
            "current_price",
            "current_pnl",
            "current_pnl_points",
            # Critical management fields — must survive even the last-resort
            # fallback, otherwise breakeven/trailing-stop changes never persist.
            "sl_moved_to_entry",
            "partial_close",
            "updates_sent",
            "result",
            "closed_at",
            "close_time",
            "close_price",
            "final_pnl",
            "final_pnl_points",
            "planned_risk_points",
            "planned_tp2_points",
            "planned_rr",
            "session_label",
            "session_quality",
            "entry_day_of_week",
            "entry_hour_local",
            "news_status_at_entry",
            "news_risk_at_entry",
            "volatility_regime",
            "market_phase",
            "regime_composite",
            "trend_strength",
            "daily_bias_at_entry",
            "setup_id",
            "setup_type",
            "setup_state",
            "lead_agent",
            "setup_quality",
            "poi_type",
            "sweep_side",
            "displacement_score",
            "reasons",
            "signal_snapshot",
            "last_updated",
            # Price tracking columns — must persist so dashboard/SQL queries
            # can report actual candle extremes and all-time PnL excursions.
            "last_candle_low",
            "last_candle_high",
            "recent_30m_high",
            "recent_30m_low",
            "max_favorable_excursion",
            "max_adverse_excursion",
        }
        return {key: value for key, value in data.items() if key in legacy_fields}

    def _trade_pnl(self, trade: Dict[str, Any]) -> float:
        """Extract final/current pnl safely."""
        for key in ("final_pnl", "current_pnl", "current_pnl_points"):
            value = trade.get(key)
            if value is not None:
                try:
                    return float(value)
                except (TypeError, ValueError):
                    continue
        return 0.0


