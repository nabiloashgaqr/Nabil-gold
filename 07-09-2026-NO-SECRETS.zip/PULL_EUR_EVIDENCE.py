"""PULL_EUR_EVIDENCE.py — one-shot evidence pull for the EUR/USD stop audit.

Run from the repo root (same place you put SIM_MACRO_FIX_REPLAY.py):

    python PULL_EUR_EVIDENCE.py

It never sends anything, never writes to the database — READ ONLY.
Prints a console summary AND writes the full report to:
    EUR_EVIDENCE_REPORT.txt   (paste this file back)
"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)

PREFIXES = [
    "TRADE_20260828_170231",
    "TRADE_20260831_073215",
    "TRADE_20260902_000226",
]
SINCE = "2026-08-28T00:00:00"
REPORT_PATH = ROOT / "EUR_EVIDENCE_REPORT.txt"

_report_lines: list = []


def say(text: str = "") -> None:
    print(text)
    _report_lines.append(text)


def section(title: str) -> None:
    say("")
    say("=" * 78)
    say(title)
    say("=" * 78)


def clip(value, limit: int = 400):
    """Shorten long values so the report stays paste-friendly."""
    if isinstance(value, str) and len(value) > limit:
        return value[:limit] + f"...[+{len(value) - limit} chars]"
    if isinstance(value, dict):
        return {str(k): clip(v, limit) for k, v in value.items()}
    if isinstance(value, list):
        return [clip(v, limit) for v in value]
    return value


def load_local_list(path: Path):
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception as exc:
        return f"READ ERROR: {exc}"


def file_stamp(path: Path) -> str:
    try:
        mt = datetime.fromtimestamp(path.stat().st_mtime, timezone.utc)
        return f"{path}  (size {path.stat().st_size} B, modified {mt.isoformat()[:19]}Z)"
    except Exception:
        return f"{path}  (missing)"


# ─────────────────────────────────────────────────────────────────────────────
say("EUR/USD STOP AUDIT — EVIDENCE PULL")
say(f"generated: {datetime.now(timezone.utc).isoformat()[:19]}Z   (read-only)")
say(f"repo root : {ROOT}")

# ── 1) MODE / ENV ────────────────────────────────────────────────────────────
section("1) EXECUTION MODE & DATABASE TARGET")
say(f"EXECUTION_MODE env      : {os.environ.get('EXECUTION_MODE', '<unset>')}")
say(f"TRADES_TABLE env        : {os.environ.get('TRADES_TABLE', '<unset> -> trades')}")
say(f"SUPABASE_URL set        : {'yes' if os.environ.get('SUPABASE_URL') else 'no'}")
say(f"SUPABASE_KEY set        : {'yes' if os.environ.get('SUPABASE_KEY') else 'no'}")

db = None
try:
    try:
        from dotenv import load_dotenv
        load_dotenv()
        say(".env loaded             : yes")
    except Exception:
        say(".env loaded             : no (no python-dotenv or no .env)")
    from services.database import DatabaseService
    db = DatabaseService()
    say(f"DatabaseService backend : {'SUPABASE' if db.use_supabase else 'LOCAL JSON FALLBACK'}")
    say(f"trades table in use     : {db.trades_table}")
except Exception as exc:
    say(f"DatabaseService init FAILED: {exc}")
    say("-> continuing with local files only")

# ── 2) MANAGEMENT AUDIT TRAIL (decision_audit) ──────────────────────────────
section("2) MANAGEMENT AUDIT TRAIL (stage=management rows for the 3 trades)")
audit_rows = []
if db is not None:
    try:
        audit_rows = db.get_recent_decision_audits(
            limit=3000, symbol="EUR/USD", since=SINCE)
        say(f"reader returned {len(audit_rows)} EUR/USD audit rows since {SINCE}")
    except Exception as exc:
        say(f"reader FAILED: {exc}")

matched = [r for r in audit_rows
           if isinstance(r, dict)
           and any(str(r.get("trade_id") or "").startswith(p) for p in PREFIXES)]
if not matched:
    say("NO audit rows reference the 3 trade ids directly.")
    say("Any management-stage EUR/USD rows in the window (first 60, newest first):")
    mgmt = [r for r in audit_rows if str(r.get("stage") or "") == "management"][:60]
    for r in mgmt:
        say(f"  {str(r.get('created_at'))[:19]}  {str(r.get('outcome')):<22} "
            f"{clip(str(r.get('reason') or ''), 90)}")
else:
    matched.sort(key=lambda r: str(r.get("created_at") or ""))
    say(f"{len(matched)} rows for the 3 trades, chronological:")
    counts = {}
    for r in matched:
        outcome = str(r.get("outcome"))
        counts[outcome] = counts.get(outcome, 0) + 1
        say(f"  {str(r.get('created_at'))[:19]}  {outcome:<22} "
            f"{clip(str(r.get('reason') or ''), 90)}")
    say("")
    say("outcome counts: " + json.dumps(counts))

# local fallback audit file (is it the live sink or stale?)
section("2b) LOCAL decision_audit.json STATE")
laudit = ROOT / "storage" / "decision_audit.json"
say(file_stamp(laudit))
rows = load_local_list(laudit)
if isinstance(rows, list):
    say(f"local rows: {len(rows)}")
    if rows:
        ts = [str(r.get("created_at") or "") for r in rows if isinstance(r, dict)]
        say(f"newest local row : {max(ts)[:19] if ts else '?'}")
        say(f"oldest local row : {min(ts)[:19] if ts else '?'}")
        loc_match = [r for r in rows if isinstance(r, dict)
                     and any(str(r.get("trade_id") or "").startswith(p) for p in PREFIXES)]
        say(f"local rows for the 3 trades: {len(loc_match)}")
        for r in sorted(loc_match, key=lambda x: str(x.get("created_at") or "")):
            say(f"  {str(r.get('created_at'))[:19]}  {str(r.get('outcome')):<22} "
                f"{clip(str(r.get('reason') or ''), 90)}")
elif isinstance(rows, str):
    say(rows)

# ── 3) FULL TRADE ROWS (both sinks + diff) ─────────────────────────────────
section("3) FULL TRADE ROWS — Supabase vs local JSON (key-field DIFF)")

def fetch_supabase_rows():
    if db is None or not getattr(db, "use_supabase", False):
        return None
    try:
        res = (db.client.table(db.trades_table).select("*")
               .eq("symbol", "EUR/USD")
               .order("entry_time", desc=False)
               .limit(500).execute())
        return [r for r in (res.data or [])
                if any(str(r.get("id") or "").startswith(p) for p in PREFIXES)]
    except Exception as exc:
        return f"SUPABASE READ FAILED: {exc}"

def fetch_local_rows():
    rows = load_local_list(ROOT / "storage" / "trades.json")
    if not isinstance(rows, list):
        return None
    return [r for r in rows
            if isinstance(r, dict)
            and any(str(r.get("id") or "").startswith(p) for p in PREFIXES)]

sb_rows = fetch_supabase_rows()
lc_rows = fetch_local_rows()

def dump_row(source: str, row) -> None:
    say("")
    say(f"--- {source}: {row.get('id')} ---")
    for key in sorted(row.keys()):
        say(f"  {key:<28}: {json.dumps(clip(row.get(key)), ensure_ascii=False)}")

if isinstance(sb_rows, str):
    say(sb_rows)
elif sb_rows is None:
    say("supabase: not in use (or db unavailable)")
else:
    say(f"supabase rows found: {len(sb_rows)}")
    for row in sb_rows:
        dump_row("SUPABASE", row)

if lc_rows is None:
    say("local trades.json: missing or unreadable")
else:
    say(f"local rows found: {len(lc_rows)}")
    for row in lc_rows:
        dump_row("LOCAL", row)

# key-field diff between the two sinks for the same trade
if isinstance(sb_rows, list) and isinstance(lc_rows, list):
    say("")
    say("KEY-FIELD DIFF (supabase vs local) — divergence names the failed sink:")
    lc_by_prefix = {str(r.get("id") or "")[:19]: r for r in lc_rows}
    any_diff = False
    for sb in sb_rows:
        prefix = str(sb.get("id") or "")[:19]
        lc = lc_by_prefix.get(prefix)
        if not lc:
            continue
        for field in ("status", "stop_loss", "sl_moved_to_entry", "updates_sent",
                      "current_pnl", "mt5_ticket", "closed_at", "final_pnl",
                      "trailing_stop_source_time", "requested_exit",
                      "requested_exit_reason"):
            if sb.get(field) != lc.get(field):
                any_diff = True
                say(f"  {prefix}: {field}: supabase={sb.get(field)!r}  "
                    f"local={lc.get(field)!r}")
    if not any_diff:
        say("  (no differences on key fields)")

# ── 4) COMPANION PROCESS STATE ──────────────────────────────────────────────
section("4) COMPANION STATE (heartbeats / halt / macro marker)")
for name in ("heartbeat.json", "tick_heartbeat.json", ".demo_halt",
             "storage/macro/refresh_marker.json"):
    p = ROOT / name
    if not p.exists():
        say(f"{name:<34}: missing")
        continue
    try:
        say(f"{name:<34}: {clip(p.read_text(encoding='utf-8')[:300])}")
    except Exception as exc:
        say(f"{name:<34}: exists, read error {exc}")

say("")
say(f"report written to: {REPORT_PATH.name}")
try:
    REPORT_PATH.write_text("\n".join(_report_lines), encoding="utf-8")
except Exception as exc:
    print(f"FAILED to write report file: {exc}")
say("DONE. Paste EUR_EVIDENCE_REPORT.txt back.")
