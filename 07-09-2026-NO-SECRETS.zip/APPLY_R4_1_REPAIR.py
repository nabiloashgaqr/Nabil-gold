#!/usr/bin/env python3
"""R4.1 one-time repair: normalize closed trade rows after services are stopped.

Run from the project root:
    python APPLY_R4_1_REPAIR.py

The script preserves config.json, creates a timestamped backup of the local
trade ledger, and makes every closed_at row terminal. It is idempotent.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LIVE = {"OPEN", "PENDING", "PARTIAL", "TP1_HIT"}
NON_TERMINAL_RESULTS = LIVE | {"", "NONE", "NULL"}


def main() -> int:
    os.chdir(ROOT)
    config_path = ROOT / "config.json"
    if not config_path.exists():
        print("ERROR: run this script from a deployment containing config.json", file=sys.stderr)
        return 2
    config = json.loads(config_path.read_text(encoding="utf-8"))
    relative = (config.get("database") or {}).get("local_fallback_file", "storage/trades.json")
    ledger = (ROOT / relative).resolve()
    if not ledger.exists():
        print(f"ERROR: trade ledger not found: {ledger}", file=sys.stderr)
        return 2
    rows = json.loads(ledger.read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        print(f"ERROR: expected a JSON array in {ledger}", file=sys.stderr)
        return 2

    changes: list[tuple[str, str, str]] = []
    for row in rows:
        if not isinstance(row, dict) or not row.get("closed_at"):
            continue
        old = str(row.get("status") or "").upper()
        if old not in LIVE:
            continue
        result = str(row.get("result") or "").upper()
        terminal = "CLOSED" if result in NON_TERMINAL_RESULTS else result
        row["status"] = terminal
        row["result"] = terminal
        changes.append((str(row.get("id") or "<missing-id>"), old, terminal))

    if not changes:
        print("R4.1 REPAIR: no zombie rows found; no file changed")
        return 0

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup = ledger.with_name(f"{ledger.stem}.backup_R4_1_{stamp}{ledger.suffix}")
    shutil.copy2(ledger, backup)
    temp = ledger.with_suffix(ledger.suffix + ".R4_1.tmp")
    temp.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    # Verify the complete replacement before publishing it atomically.
    verified = json.loads(temp.read_text(encoding="utf-8"))
    assert isinstance(verified, list) and len(verified) == len(rows)
    os.replace(temp, ledger)

    print(f"BACKUP: {backup}")
    for trade_id, old, terminal in changes:
        print(f"REPAIRED: {trade_id} {old} -> {terminal}")
    print(f"R4.1 REPAIR: repaired={len(changes)} remaining_zombies=0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
