# INSTALL_ON_NEW_SERVER.ps1 - run once on the new machine inside C:\Nabil-gold
$ErrorActionPreference = "Stop"
Set-Location "C:\Nabil-gold"
Write-Host "=== Python version ===" -ForegroundColor Cyan
python --version
Write-Host "=== Installing requirements ===" -ForegroundColor Cyan
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
Write-Host "=== Quick checks ===" -ForegroundColor Cyan
python -c "import json; json.load(open('config.json', encoding='utf-8')); print('config.json OK')"
Write-Host "=== Running test suite ===" -ForegroundColor Cyan
python -m pytest -q
Write-Host "Done. Review config.json secrets, then start the bots." -ForegroundColor Green