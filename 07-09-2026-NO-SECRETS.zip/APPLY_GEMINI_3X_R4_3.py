#!/usr/bin/env python3
"""Safely enforce the Gemini 3.x model chain without replacing config.json."""
from __future__ import annotations
import json, os, shutil, sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PRIMARY = "gemini-3.1-flash-lite"
FALLBACKS = ["gemini-3.5-flash-lite", "gemini-3.6-flash", "gemini-3.5-flash"]
ALLOWED = {PRIMARY, *FALLBACKS}


def backup(path: Path, stamp: str) -> None:
    if path.exists():
        shutil.copy2(path, path.with_name(f"{path.name}.backup_gemini3x_{stamp}"))


def atomic_json(path: Path, value) -> None:
    tmp = path.with_suffix(path.suffix + ".gemini3x.tmp")
    tmp.parent.mkdir(parents=True, exist_ok=True)
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    json.loads(tmp.read_text(encoding="utf-8"))
    os.replace(tmp, path)


def main() -> int:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    cfg_path = ROOT / "config.json"
    if not cfg_path.exists():
        print("ERROR: config.json missing", file=sys.stderr); return 2
    cfg = json.loads(cfg_path.read_text(encoding="utf-8-sig"))
    backup(cfg_path, stamp)
    llm = cfg.setdefault("llm_review", {})
    llm["model"] = PRIMARY
    llm["fallback_models"] = FALLBACKS
    llm["description_fallback_models"] = (
        "Gemini 3.x only: 3.1 Flash-Lite primary; 3.5 Flash-Lite, 3.6 Flash, "
        "and 3.5 Flash fallbacks. Gemini 2.5 is retired. Quota failover is per-model."
    )
    atomic_json(cfg_path, cfg)

    # GEMINI_MODEL overrides config; remove only retired 2.5 overrides.
    env_path = ROOT / ".env"
    if env_path.exists():
        lines = env_path.read_text(encoding="utf-8-sig").splitlines()
        changed = False; out = []
        for line in lines:
            if line.strip().startswith("GEMINI_MODEL="):
                value = line.split("=", 1)[1].strip().strip('"\'')
                if ("gemini-" + "2.5") in value.lower() or value not in ALLOWED:
                    out.append(f"GEMINI_MODEL={PRIMARY}"); changed = True; continue
            out.append(line)
        if changed:
            backup(env_path, stamp)
            env_path.write_text("\n".join(out) + "\n", encoding="utf-8")

    # Purge stale retired/unconfigured models but preserve today's valid 3.x quotas.
    state_path = ROOT / str(llm.get("quota_state_path") or "storage/llm/gemini_quota_state.json")
    if state_path.exists():
        state = json.loads(state_path.read_text(encoding="utf-8-sig"))
        backup(state_path, stamp)
        for key in ("exhausted_models", "unavailable_models"):
            state[key] = [m for m in (state.get(key) or []) if m in ALLOWED]
        if state.get("resolved_model") not in ALLOWED:
            state["resolved_model"] = ""
        # A rotated key must not inherit the previous credential's 401 latch.
        state["auth_rejected"] = False
        state["auth_rejected_reason"] = ""
        state["version"] = 2
        atomic_json(state_path, state)

    print(f"PRIMARY: {PRIMARY}")
    print("FALLBACKS: " + " -> ".join(FALLBACKS))
    print("RETIRED: all previous-generation 2.5 models")
    print("CONFIG: merged safely; backups created; valid 3.x quota state preserved")
    return 0

if __name__ == "__main__": raise SystemExit(main())
