# -*- coding: utf-8 -*-
"""Read-only audit for live map/agent evidence files. No secrets are printed."""
from __future__ import annotations
import glob, json, re, sqlite3
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILES = [
    "storage/session_plans.json", "storage/trades.json",
    "storage/decision_audit.json", "logs/demo_analysis.log",
]
PATTERNS = ["storage/pre_arm*.json", "storage/auction_flow*.sqlite3"]

def age_hours(path: Path) -> float:
    return (datetime.now(timezone.utc).timestamp() - path.stat().st_mtime) / 3600

def audit_json(path: Path):
    obj = json.loads(path.read_text(encoding="utf-8-sig"))
    rows = obj if isinstance(obj, list) else obj.get("rows", obj.get("items", [])) if isinstance(obj, dict) else []
    print(f"  JSON valid; type={type(obj).__name__}; rows={len(rows) if isinstance(rows,list) else 'n/a'}")
    if isinstance(rows, list) and rows:
        statuses = {}
        for row in rows:
            if isinstance(row, dict):
                key = str(row.get("plan_status") or row.get("status") or row.get("state") or "UNKNOWN")
                statuses[key] = statuses.get(key, 0) + 1
        print(f"  statuses={statuses}")

def audit_jsonl(path: Path):
    good = bad = 0
    with path.open(encoding="utf-8-sig", errors="replace") as fh:
        for line in fh:
            if not line.strip(): continue
            try: json.loads(line); good += 1
            except Exception: bad += 1
    print(f"  JSONL valid_rows={good}; invalid_rows={bad}")

def audit_sqlite(path: Path):
    con = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
    integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
    tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    counts = {}
    for table in tables:
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", table):
            try: counts[table] = con.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
            except Exception: counts[table] = "unreadable"
    con.close()
    print(f"  SQLite integrity={integrity}; tables={counts}")

def audit_log(path: Path):
    text = path.read_text(encoding="utf-8", errors="replace")[-2_000_000:]
    terms = ("ERROR", "Traceback", "planner", "WATCH", "READY", "Path 4", "Path 5", "macro veto")
    counts = {term: text.lower().count(term.lower()) for term in terms}
    print(f"  recent-log counters={counts}")

def main():
    paths = [ROOT / x for x in FILES]
    for pattern in PATTERNS:
        paths.extend(Path(x) for x in glob.glob(str(ROOT / pattern)))
    seen = set(); missing = 0; failed = 0
    for path in paths:
        path = path.resolve()
        if path in seen: continue
        seen.add(path)
        rel = path.relative_to(ROOT) if path.is_relative_to(ROOT) else path
        if not path.exists():
            print(f"MISSING {rel}"); missing += 1; continue
        print(f"OK {rel} size={path.stat().st_size} age_hours={age_hours(path):.2f}")
        try:
            if path.suffix == ".sqlite3": audit_sqlite(path)
            elif path.suffix == ".jsonl": audit_jsonl(path)
            elif path.suffix == ".json": audit_json(path)
            elif path.suffix == ".log": audit_log(path)
        except Exception as exc:
            failed += 1; print(f"  INVALID: {type(exc).__name__}: {exc}")
    print(f"SUMMARY checked={len(seen)} missing={missing} invalid={failed}")
    raise SystemExit(1 if failed else 0)

if __name__ == "__main__": main()
