import os, json

# 1. إصلاح tests/conftest.py وترتيب __future__
tc_file = os.path.join("tests", "conftest.py")
if os.path.exists(tc_file):
    txt = open(tc_file, "r", encoding="utf-8").read()
    lines = [l for l in txt.splitlines() if not l.startswith("import os, sys") and not l.startswith("_ROOT =") and not l.startswith("if _ROOT not in sys.path:") and not l.startswith("    sys.path.insert(0, _ROOT)")]
    new_txt = "\n".join(lines)
    if "from __future__ import annotations" in new_txt:
        new_txt = new_txt.replace(
            "from __future__ import annotations",
            "from __future__ import annotations\n\nimport os\nimport sys\n_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))\nif _ROOT not in sys.path:\n    sys.path.insert(0, _ROOT)"
        )
    open(tc_file, "w", encoding="utf-8").write(new_txt)
    print("✅ Fixed tests/conftest.py __future__ order.")

# 2. تحديث config.json للأزواج الأربعة
cfg_file = "config.json"
if os.path.exists(cfg_file):
    with open(cfg_file, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    for inst in cfg.get("instruments", []):
        if inst.get("category") == "forex":
            inst.setdefault("auction_flow", {})["calibration_required"] = False
    with open(cfg_file, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    print("✅ Updated config.json: Forex auction calibration set to linear fallback.")

print("\n🎉 Setup complete!")
