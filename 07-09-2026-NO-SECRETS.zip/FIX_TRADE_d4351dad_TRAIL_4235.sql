-- ============================================================
-- إصلاح يدوي (Operator override): TRADE_20260806_142059_102220_d4351dad
-- التاريخ: 2026-08-06 — بعد انقطاع GitHub Actions (15:36-17:45 UTC)
-- ============================================================
-- لماذا نصلح يدوياً: أثناء الانقطاع لم يعمل محرك التحديثات، والنوافذ الحية
-- (آخر 6 شموع M5 = 30 دقيقة) لم ترَ قاع الهبوط بعد عودة التشغيل، فلم يُسجَّل
-- ضرب TP1 ولم يعمل التريلنج. هذا SQL يعيد كتابة النتيجة كما كان المحرك
-- سيكتبها حرفياً (نفس الحقول ونفس القيم المستخرجة من قواعده).
--
-- ── الحسابات (نقطة = 0.10$) ─────────────────────────────────
-- الدخول SELL 4265.03 · SL الأصلي 4288.70 · TP1 4231.37 · TP2 4200.00
-- التريلنج حسب بطاقة الصفقة: فجوة 120 نقطة (12.00$) / خطوة 30
--
-- النزول: 4265.03 - 4223.83 (قاع الشارت M5) = 41.20$ = 412.0 نقطة
--   · TP1 مضروب وزيادة: القاع أخفض من 4231.37 بـ 75.4 نقطة
--   · TP2 لم يضرب: القاع أعلى منه بـ 238.3 نقطة
--
-- التريلنج ستوب: بعد حجز النصف عند TP1 ينتقل الوقف للدخول ثم يرتد من القاع:
--   4223.83 + 12.00 = 4235.83   (≈ 4235 عند المشغّل)
-- الارتداد: أول شمعة M5 بعد القاع بلغ عاليها 4235.83 أغلقت النصف الثاني عندها.
--
-- ── النتيجة النهائية ────────────────────────────────────────
-- نصف 1: +336.6 نقطة @ 4231.37  -> realized = 336.6 * 0.5 = 168.3
-- نصف 2: +292.0 نقطة @ 4235.83  (final_pnl_points)
-- المجموع الموزون ≈ +314.3 نقطة · نتيجة WIN
-- ============================================================

-- ── 0) أكمل الأعمدة الناقصة أولاً (آمن: IF NOT EXISTS، قابل للتكرار) ──
ALTER TABLE trades ADD COLUMN IF NOT EXISTS closed_fraction     DECIMAL(18, 6) DEFAULT 0;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS realized_pnl_points DECIMAL(18, 6) DEFAULT 0;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS scale_out_price     DECIMAL(18, 6);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS partial_close       BOOLEAN DEFAULT FALSE;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS updates_sent        JSONB DEFAULT '[]'::jsonb;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS management_phase    VARCHAR(40);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS trailing_distance_points DECIMAL(18, 6);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS trailing_step_points     DECIMAL(18, 6);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS max_favorable_excursion  DECIMAL(18, 6) DEFAULT 0;

-- ── 1) إصلاح الصفقة ─────────────────────────────────────────
UPDATE trades SET
  -- الإغلاق كما يسمّيه المحرك: إغلاق بالوقف المُترَيل = SL_HIT + WIN
  status                = 'SL_HIT',
  result                = 'WIN',
  close_price           = 4235.83,
  final_pnl             = 292.0,
  final_pnl_points      = 292.0,
  -- أول شمعة M5 بعد القاع بلغ عاليها 4235.83 (راجع الشارت وعدّل إن لزم)
  closed_at             = '2026-08-06T16:25:00+00:00',
  close_time            = '2026-08-06T16:25:00+00:00',
  -- حجز النصف عند TP1 (نفس أرقام _book_tp1_partial في المحرك)
  partial_close         = TRUE,
  closed_fraction       = 0.5,
  realized_pnl_points   = 168.3,
  scale_out_price       = 4231.37,
  -- الوقف المُترَيل وإدارة الصفقة
  stop_loss             = 4235.83,
  sl_moved_to_entry     = TRUE,
  management_phase      = 'POST_TP1_TRAILING',
  trailing_distance_points = 120,
  trailing_step_points     = 30,
  max_favorable_excursion  = 412.0,
  exit_warning          = NULL,
  updates_sent          = COALESCE(updates_sent, '[]'::jsonb)
                          || '["TP1_HIT","TRAILING_SL_HIT"]'::jsonb,
  last_updated          = NOW()
WHERE id = 'TRADE_20260806_142059_102220_d4351dad';

-- ── 2) تحقق: يجب أن يعيد سطراً واحداً SL_HIT / WIN / 4235.83 ──
SELECT id, status, result, close_price, final_pnl_points,
       realized_pnl_points, closed_fraction, scale_out_price,
       stop_loss, max_favorable_excursion, closed_at
FROM trades
WHERE id = 'TRADE_20260806_142059_102220_d4351dad';
