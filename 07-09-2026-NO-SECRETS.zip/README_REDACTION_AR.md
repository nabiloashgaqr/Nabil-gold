# 🔐 نسخة نظيفة — بدون أسرار (2026-09-07)

هذه نسخة من مشروع Nabil-gold **تمت إزالة كل كلمات المرور والمفاتيح السرية منها** قبل النشر/المشاركة.

## ✅ ما تمت إزالته واستبداله

| المفتاح | القيمة القديمة | القيمة الجديدة |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | توكن حقيقي 🔴 | `YOUR_BOT_TOKEN_FROM_BOTFATHER` |
| `SUBSCRIPTION_BOT_TOKEN` | توكن حقيقي 🔴 | `YOUR_BOT_TOKEN_FROM_BOTFATHER` |
| `GEMINI_API_KEY` | مفتاح Gemini حقيقي 🔴 | `YOUR_GEMINI_API_KEY` |
| `EIA_API_KEY` | مفتاح حقيقي 🔴 | `YOUR_API_KEY` |
| `MT5_PASSWORD` | كلمة مرور MT5 🔴 | `YOUR_MT5_PASSWORD` |
| `MT5_LOGIN` / `MT5_SERVER` | قيم حقيقية | `YOUR_MT5_LOGIN` / `YOUR_MT5_SERVER` |
| `SUPABASE_URL` / `SUPABASE_KEY` | قيم حقيقية | `https://YOUR-PROJECT.supabase.co` / `YOUR_SUPABASE_ANON_KEY` |

> 🔴 القيم الأصلية **أصبحت مكشوفة علناً على GitHub** (المستودع صار عاماً) —
> **يجب إبطالها فوراً** (Revoke) من: BotFather، Google AI Studio، لوحة Supabase، ووسيط MT5،
> ثم وضع القيم الجديدة في `.env` المحلي فقط.

## 📝 ملاحظات

- بقيت `ADMIN_IDS` و `ADMIN_CONTACT` كما هي (هي معرّفات/تواصل عامة وليست كلمات مرور) — استبدلها إن رغبت.
- ملفات `config*.json` تستخدم مراجع بيئية `ENV:KEY` أصلاً — لم تتغير.
- بصمات SHA-256 في `_manifest.json` و `SHA256SUMS.txt` هي مجرد بصمات ملفات (ليست أسراراً).
- بعد استخراج النسخة: انسخ `.env.template` إلى `.env` واملأ قيمك الحقيقية،
  ثم شغّل `INSTALL_EVERYTHING.bat` (على ويندوز) أو `pip install -r requirements.txt`.

**(هذا الملف جزء من النسخة النظيفة ولا يحتوي أي أسرار).**
