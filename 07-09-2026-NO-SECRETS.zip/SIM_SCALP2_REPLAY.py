# -*- coding: utf-8 -*-
"""SIM_SCALP2_REPLAY.py — إعادة تشغيل سكالب نوع ٢ على بيانات سيرفرك الحقيقية.

MEASUREMENT LAB ONLY (operator 2026-09-02: "احذف النوع الثاني نهائي" —
scalp type 2 is REMOVED from production). This tool exists to MEASURE, on
the server's own candles, what a displacement-continuation scalp WOULD have
done — including the shallower-zone experiment (50% -> 38%) whose benefit
is proven here BEFORE any production decision.

Reads storage/shared_market_data.json — the per-cycle MT5 book (R22: the
file carries a plain-text "symbol"; the last analysis cycle owns it) — and
runs a SELF-CONTAINED copy of the evaluator on the 5-MINUTE series (the
stop still derives from the general law via utils.trading_rules).

Modes:
  python SIM_SCALP2_REPLAY.py                     # اللحظة الأخيرة
  python SIM_SCALP2_REPLAY.py XAU/USD             # رمز محدد
  python SIM_SCALP2_REPLAY.py XAU/USD --timeline  # إعادة زمنية شمعة-بشمعة:
                                                  # أول تسليح + السعر حينها،
                                                  # امتلاء الـLIMIT، وأول حدث
                                                  # بعده (ستوب/TP1)

If the book belongs to a DIFFERENT symbol (the file is rewritten by every
cycle, six symbols round-robin), the tool REFUSES and says whose data it
holds — wait one cycle (or run an analysis for the symbol) and retry fast.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from utils.indicators import calculate_atr                      # noqa: E402
from utils.trading_rules import clamp_stop_price                # noqa: E402
from services.pre_arm_ote import detect_impulse_leg             # noqa: E402

ENTRY_PCT = 0.50   # --entry-pct overrides (the shallower-zone experiment)


def evaluate_continuation_lab(*, symbol, candles, atr, current_price,
                              config=None):
    """Self-contained measurement copy of the (production-removed) scalp
    type-2 evaluator; entry/zone come from ENTRY_PCT (zone = entry -8/+5
    percentage points, mirroring the 42-55 zone around 50)."""
    threshold, tp1_rr, tp2_rr = 5.0, 1.5, 2.5
    verdict = {"allow": False, "direction": None, "reasons": []}
    if atr <= 0 or len(candles) < 8 or current_price <= 0:
        verdict["reasons"].append("insufficient_data"); return verdict
    leg = None; direction = ""; mult = 0.0
    for cand in ("BUY", "SELL"):
        candidate = detect_impulse_leg(list(candles), atr, {}, cand)
        if not candidate:
            continue
        m = float(candidate["leg_size"]) / max(float(atr), 1e-9)
        if m >= threshold:
            leg, direction, mult = candidate, cand, m
            break
    if leg is None:
        verdict["reasons"].append("no_fresh_displacement >= %.1fx" % threshold)
        return verdict
    origin = float(leg["leg_origin"]); size = float(leg["leg_size"])
    sign = 1.0 if direction == "BUY" else -1.0
    entry = origin + sign * size * ENTRY_PCT
    z_low_pct = ENTRY_PCT - 0.08
    z_high_pct = ENTRY_PCT + 0.05
    zone_low = origin + sign * size * z_low_pct
    zone_high = origin + sign * size * z_high_pct
    peak = float(leg["leg_peak"])
    retr = ((peak - current_price) if direction == "BUY"
            else (current_price - peak)) / max(size, 1e-9)
    if retr >= ENTRY_PCT:
        verdict["reasons"].append("first_bounce_already_filled_or_gone")
        return verdict
    if retr > z_high_pct:
        verdict["reasons"].append("first_bounce_already_spent_beyond_zone")
        return verdict
    stop = clamp_stop_price(direction=direction, entry=entry, stop=origin,
                            cfg=config or {}, symbol=symbol)
    risk = abs(entry - stop)
    if risk <= 0:
        verdict["reasons"].append("zero_lawful_risk"); return verdict
    verdict.update({
        "allow": True, "direction": direction,
        "entry": round(entry, 5), "stop": round(stop, 5),
        "tp1": round(entry + sign * risk * tp1_rr, 5),
        "tp2": round(entry + sign * risk * tp2_rr, 5),
        "displacement_multiple": round(mult, 2),
        "zone_low": round(zone_low, 5), "zone_high": round(zone_high, 5),
    })
    return verdict


def _t(row):
    """Readable stamp: ISO passthrough, or epoch sec/ms -> UTC time."""
    for key in ("time", "t", "datetime", "date", "timestamp"):
        value = row.get(key)
        if not value:
            continue
        if isinstance(value, (int, float)) and value > 1e8:      # epoch
            seconds = float(value) / 1000.0 if value > 1e12 else float(value)
            try:
                return datetime.fromtimestamp(seconds, tz=timezone.utc).strftime("%m-%d %H:%M UTC")
            except (OverflowError, OSError, ValueError):
                return str(value)
        return str(value)[:16]
    return ""


def _c(row, *keys):
    for key in keys:
        if key in row and row[key] is not None:
            try:
                return float(row[key])
            except (TypeError, ValueError):
                pass
    return None


def load(symbol: str):
    book_path = ROOT / "storage" / "shared_market_data.json"
    if not book_path.exists():
        print("لا يوجد ملف بيانات:", book_path)
        sys.exit(1)
    raw = json.loads(book_path.read_text(encoding="utf-8"))
    meta = raw.get("shared_market_data") or {}
    book_symbol = str(raw.get("symbol") or meta.get("symbol") or "").upper()
    if book_symbol and book_symbol != symbol.upper():
        print("✗ الملف الحالي لرمز آخر: %s (الملف يُستبدل كل دورة تحليل — الأزواج"
              " تتناوب). شغّل دورة/انتظر دورة الرمز المطلوب ثم نفّذ الأداة فوراً."
              % book_symbol)
        sys.exit(2)
    if not book_symbol:
        print("⚠ الملف بلا ختم رمز (نسخة قديمة) — النتائج استرشادية.")
    # direct key access first — no heuristics when the schema is clean
    tfs = raw.get("timeframes") if isinstance(raw.get("timeframes"), dict) else {}
    series, label = [], "5m"
    for tf in ("5m", "15m"):
        node = tfs.get(tf)
        if isinstance(node, dict) and isinstance(node.get("data"), list):
            series, label = node["data"], tf
            break
    candles, stamps = [], []
    for row in series:
        if not isinstance(row, dict):
            continue
        o = _c(row, "open", "o"); h = _c(row, "high", "h")
        l = _c(row, "low", "l"); c = _c(row, "close", "c")
        if None in (h, l) or (o is None and c is None):
            continue
        candles.append({"open": o or c, "high": h, "low": l, "close": c or o})
        stamps.append(_t(row))
    return candles, stamps, label


def verdict_at(candles, symbol):
    atr_series = calculate_atr(candles, 14)
    atr = next((float(x) for x in reversed(atr_series) if x), 0.0)
    return evaluate_continuation_lab(
        symbol=symbol, candles=candles, atr=atr,
        current_price=candles[-1]["close"], config=None), atr




def _scan(candles, stamps, symbol, first_only=False):
    """State machine over the series: every False->True verdict edge is an
    arming event. After a fill it simulates the R25-3 time contract (60 min
    on M5 = 12 candles; progress >= 50%% toward TP1 survives) and then the
    raw stop/TP1 race, before scanning resumes."""
    events = []
    n = 0
    i = 12
    armed = False
    while i <= len(candles):
        v, atr = verdict_at(candles[:i], symbol)
        if v.get("allow") and not armed:
            armed = True
            n += 1
            ev = {"n": n, "arm_i": i, "verdict": v, "atr": atr,
                  "fill_j": None, "contract": None, "contract_j": None,
                  "outcome": None}
            side, limit = v["direction"], v["entry"]
            stop, tp1 = v["stop"], v["tp1"]
            fill = None
            for j in range(i, len(candles)):
                if side == "BUY" and candles[j]["low"] <= limit:
                    fill = j; break
                if side == "SELL" and candles[j]["high"] >= limit:
                    fill = j; break
            if fill is not None:
                ev["fill_j"] = fill
                # first raw event (stop/TP1) after the fill, if any
                first_k, first_what = None, None
                for k in range(fill + 1, len(candles)):
                    hit_stop = candles[k]["low"] <= stop if side == "BUY" \
                        else candles[k]["high"] >= stop
                    hit_tp1 = candles[k]["high"] >= tp1 if side == "BUY" \
                        else candles[k]["low"] <= tp1
                    if hit_stop or hit_tp1:
                        first_k = k
                        first_what = "الستوب" if hit_stop else "TP1"
                        break
                cj = min(fill + 12, len(candles) - 1)   # R25-3: 60 min on M5
                if first_k is not None and first_k <= cj:
                    # the event INSIDE the first hour settles it before the
                    # time check ever fires (the real exit is this hit)
                    ev["contract_j"] = first_k
                    ev["contract"] = ("حُسم داخل الساعة الأولى: %s وصل %s — قبل فحص الوقت"
                                      % (first_what, stamps[first_k] or ""))
                    ev["outcome"] = None
                else:
                    best = None
                    for k in range(fill + 1, cj + 1):
                        fav = (candles[k]["high"] - limit) if side == "BUY" \
                            else (limit - candles[k]["low"])
                        best = max(best or 0.0, fav)
                    need = 0.5 * abs(tp1 - limit)
                    ev["contract_j"] = cj
                    ev["contract"] = ("تجاوز فحص الوقت — تقدم %.1f ≥ %.1f (50%% نحو TP1)"
                                      % (best or 0.0, need)) if (best or 0.0) >= need else \
                                     ("خروج وقت R25-3 — تقدم %.1f < %.1f خلال 60 دقيقة"
                                      % (best or 0.0, need))
                    ev["outcome"] = ("الخام بعد الساعة الأولى: %s أولاً %s"
                                     % (first_what, stamps[first_k] or "")) if first_k \
                                    else "الخام: لا ستوب/TP1 داخل النافذة بعدها"
                i = fill + 13          # resume after the contract horizon
            else:
                i += 1                  # unfilled: keep watching (limit follows)
            events.append(ev)
            if first_only:
                return events
            continue
        if not v.get("allow"):
            armed = False
        i += 1
    return events

def main() -> None:
    symbol = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith("--") \
        else "XAU/USD"
    global ENTRY_PCT
    timeline = ("--timeline" in sys.argv) or ("--all" in sys.argv)
    for _i, _a in enumerate(sys.argv):
        if _a == "--entry-pct" and _i + 1 < len(sys.argv):
            try:
                ENTRY_PCT = min(max(float(sys.argv[_i + 1]), 0.10), 0.90)
            except ValueError:
                pass
    candles, stamps, label = load(symbol)
    if len(candles) < 12:
        print("شموع قليلة جداً (%d) على %s — شغّل دورة تحليل ثم أعد المحاولة"
              % (len(candles), label))
        return
    print("═" * 66)
    print("مختبر قياس النوع-٢ [محذوف من الإنتاج] — دخول عند %.0f%% من الساق"
          % (ENTRY_PCT * 100))
    print("سكالب نوع ٢ (%s) — سلسلة %s: %d شمعة | من %s إلى %s"
          % (symbol, label, len(candles), stamps[0] or "?", stamps[-1] or "?"))
    print("  أول إغلاق %.2f → آخر إغلاق %.2f" % (candles[0]["close"], candles[-1]["close"]))

    if not timeline:
        v, atr = verdict_at(candles, symbol)
        print("  السعر الآن %.2f | ATR14(%s) %.2f" % (candles[-1]["close"], label, atr))
        if v.get("allow"):
            print("  ⚡ يُسلّح: %s | اندفاع %.1fx | LIMIT %.2f (منطقة %.2f-%.2f)"
                  % (v["direction"], v["displacement_multiple"], v["entry"],
                     v["zone_low"], v["zone_high"]))
            print("  ستوب %.2f | TP1 %.2f | TP2 %.2f" % (v["stop"], v["tp1"], v["tp2"]))
        else:
            print("  لا تسليح:", ", ".join(str(r) for r in v.get("reasons", [])))
        print("═" * 66)
        return

    scan_all = "--all" in sys.argv
    events = _scan(candles, stamps, symbol, first_only=not scan_all)
    if not events:
        print("  لم يسلّح في أي لحظة داخل نافذة الملف (لا ساق ≥5x ATR طازجة)")
        print("═" * 66)
        return
    for ev in events:
        i, v, atr = ev["arm_i"], ev["verdict"], ev["atr"]
        side, limit = v["direction"], v["entry"]
        z_lo, z_hi = sorted((v["zone_low"], v["zone_high"]))
        print("  ⚡ تسليح #%d عند الشمعة #%d %s — %s"
              % (ev["n"], i, stamps[i - 1] or "", side))
        print("     السعر لحظة التسليح: %.2f | اندفاع %.1fx ATR (ATR %.2f)"
              % (candles[i - 1]["close"], v["displacement_multiple"], atr))
        print("     LIMIT %.2f (منطقة %.2f-%.2f) | ستوب %.2f | TP1 %.2f | TP2 %.2f"
              % (limit, z_lo, z_hi, v["stop"], v["tp1"], v["tp2"]))
        if ev["fill_j"] is None:
            print("     ○ لم يمتلىء داخل نافذة المتابعة")
            continue
        print("     ✓ امتلأ %s بسعر %.2f — عقد 60 دقيقة يبدأ"
              % (stamps[ev["fill_j"]] or "", limit))
        if ev["contract"] is not None:
            print("     ⏱ حكم عقد الوقت (%s): %s" %
                  (stamps[ev["contract_j"]] or "", ev["contract"]))
        if ev["outcome"]:
            print("     %s" % ev["outcome"])
    print("═" * 66)


if __name__ == "__main__":
    main()
