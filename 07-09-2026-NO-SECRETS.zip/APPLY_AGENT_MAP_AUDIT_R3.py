# -*- coding: utf-8 -*-
"""Merge reviewed agent/map settings into config.json; preserves unrelated keys."""
from __future__ import annotations
import json, shutil
from datetime import datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent; PATH=ROOT/"config.json"
def main():
    c=json.loads(PATH.read_text(encoding="utf-8-sig"))
    sig=c.setdefault("signal_requirements",{})
    p4=sig.setdefault("path4_smc_map_auction",{}); p4["min_auction_confidence"]=65
    p4["description"]="PATH 4 — SMC CONDITIONAL MAP + AUCTION FLOW. Execution admission thresholds: map quality >=60, return probability >=55, dominance >=70, trigger score >=70, trigger_ready=true, structure >=MODERATE, same-direction Auction Flow >=65, zero qualified opposite Core agents. LIMIT_ONLY_AT_SMC_POI."
    p5=sig.setdefault("path5_two_agent_auction",{}); p5.update({"min_consensus_confidence":65,"min_auction_confidence":65})
    p5["description"]="PATH 5 — TWO-AGENT + AUCTION FLOW. Execution admission thresholds: >=2 qualified Core agents, net confidence >=65, Auction Flow >=65, family-diversity rules; checked after Macro/Gemini fail."
    sp=c.setdefault("session_planner",{}); sp["min_primary_quality_score"]=65
    sp["description_threshold_layers"]="map_display/readiness thresholds describe construction/display; execution admission thresholds independently authorize orders."
    sp["description_zone_width_vs_sl_floor"]="Instrument law: XAU x1.0, WTI x0.5, FX x1.5; no global Gold-only stop assumption."
    sp["description_standby_min_distance_150"]="Gold-base 150 points scaled by law: XAU 150, WTI 75, FX 225."
    sp["description_min_primary_quality_65"]="Planner primary map quality floor is 65; execution still requires shared admission, risk, news, stop and target gates."
    sp.pop("description_min_primary_quality_60",None)
    delivery=c.setdefault("session_plan_delivery",{})
    delivery["ready_only_telegram"]=True
    delivery["only_when_ready"]=True
    delivery["description"]="Only READY maps are sent to Telegram; WATCH maps remain stored for dashboard/audit."
    # Preserve every nested delivery control; explicitly keep all watch cards off.
    delivery.setdefault("monitoring_only",{})["enabled"]=False
    delivery.setdefault("monitoring_only",{})["agent_watch_enabled"]=False
    delivery.setdefault("armed_map_watch",{})["enabled"]=False
    stamp=datetime.now().strftime("%Y%m%d_%H%M%S"); backup=PATH.with_name(f"config.backup_agent_map_R3_{stamp}.json")
    shutil.copy2(PATH,backup); tmp=PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); tmp.replace(PATH)
    print("OK: agent/map settings merged"); print(f"BACKUP: {backup.name}")
    print("Path4 auction=65; Path5 net/auction=65/65; planner quality=65; Telegram=READY only; Pre-Arm untouched")
if __name__=="__main__": main()
