@echo off
REM Daily EIA petroleum status fill (15:10 UTC = 18:10 Hebron).
REM The data is WEEKLY (published Wednesday ~14:30 UTC) but a daily run
REM self-heals a missed/partial fill the very next day - 1 tiny request.
cd /d "%~dp0..\.."
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist logs mkdir logs
python scripts\fill_oil_macro.py >> logs\eia_fill.log 2>&1
