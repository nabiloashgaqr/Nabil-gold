﻿param(
    [string]$Edge = '',
    [int]$HorizonBars = 0,
    [double]$BarrierAtr = 0
)

$ErrorActionPreference = 'Continue'
$root = 'C:\Nabil-gold'
Set-Location $root
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
Write-Output '=============================================='
Write-Output 'BUILD OIL AUCTION CALIBRATION (MT5 history)'
Write-Output '=============================================='
$argList = @('--days','180','--tick-days','60')
if ($Edge -ne '') { $argList += @('--edge', $Edge) }
if ($HorizonBars -gt 0) { $argList += @('--horizon-bars', $HorizonBars) }
if ($BarrierAtr -gt 0) { $argList += @('--barrier-atr', $BarrierAtr) }
& python scripts\build_oil_auction_calibration.py @argList
if ($LASTEXITCODE -eq 2) {
    Write-Output ''
    Write-Output '[WEAK CURVE] both the default and the value_only retry stayed weak -'
    Write-Output '            the flag stays OFF and weak curves were moved aside;'
    Write-Output '            the linear fallback keeps Paths 4/5 alive.'
    Write-Output '            Retry after more live history accumulates.'
} elseif ($LASTEXITCODE -ne 0) {
    Write-Output ''
    Write-Output '[FAIL] calibration build failed - reverting WTI calibration_required to false'
    & python scripts\build_oil_auction_calibration.py --revert
    Write-Output ('REVERT EXIT=' + $LASTEXITCODE)
} else {
    Write-Output ''
    Write-Output '[OK] WTI auction calibration built, verified by the agent,'
    Write-Output '     and the production flag is locked to required=true.'
}
Write-Output ('EXIT=' + $LASTEXITCODE)
