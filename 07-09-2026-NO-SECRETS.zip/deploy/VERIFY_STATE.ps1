﻿$ErrorActionPreference = 'Continue'
$root = 'C:\Nabil-gold'
Write-Output '=============================================='
Write-Output 'VERIFY-STATE 2026-08-19  (read-only checks)'
Write-Output '=============================================='

# ---- 1) FILE HASHES vs expected build-15 bytes ----
Write-Output ''
Write-Output '--- 1) FILE HASHES (MATCH = expected build-15 bytes) ---'
$exp = @{
 'services\shared_market_data.py' = '2a98d4d895e93686b5278be18591feb4e1934d0dab42c84e1a6e0d0464efa9c6'
 'utils\helpers.py' = '5a70d8cb17551fc4589b6435e48f2aef5e57ff2f9cd53a5a2172b4aab5f45709'
 'agents\technical_agent.py' = 'cb063055c1b6dcc3b3921786149de744dc631ef97a76b7f31ae011656583b8b4'
 'agents\multitimeframe_agent.py' = '446aea16a6cc0aacfa34dfe04bbc296692ac6caaea0e29bad2204ee4758ac339'
 'agents\price_action_agent.py' = '45dc46938f969e8e164849522d8418fe1cbc3199cc615b164f6b3f5699580133'
 'agents\classical_agent.py' = 'bba5dcd0b15a64a62cf6899a854696577013b2e66258733868e35b77c5edbd8b'
 'services\thesis_consensus.py' = 'c19f2f8a9707c02c225d59300c2b383b5990aaef3a8875393afa150ab87e50c6'
 'services\auction_evidence.py' = 'f6096693f5e5216e1fa7bc25c4c254c4d29e6e6823db1379414ab5f6abe596c3'
 'scripts\run_analysis.py' = 'b0ba0d61514e10c41592c05d97fb02b4768adb74e697cc3c1fb9c4334a732a23'
 'agents\risk_management_agent.py' = '7eb4c477ada775fd003b29580198051c91d8263bdc135fed500ffc63755ca153'
 'config.json' = '6c23e1a72873ef1b5c896ab3caaff5a02120289ce383fbc896575af2853116ff'
}
$b15ok = $true
foreach ($k in $exp.Keys) {
  $p = Join-Path $root $k
  if (-not (Test-Path $p)) { Write-Output ('MISSING   ' + $k); $b15ok = $false; continue }
  $h = (Get-FileHash -Path $p -Algorithm SHA256).Hash.ToLower()
  if ($h -eq $exp[$k]) { Write-Output ('MATCH     ' + $k) }
  else { Write-Output ('DIFF      ' + $k + '  got=' + $h); $b15ok = $false }
}
$ra = (Get-FileHash -Path (Join-Path $root 'scripts\run_analysis.py') -Algorithm SHA256).Hash.ToLower()
$rm = (Get-FileHash -Path (Join-Path $root 'agents\risk_management_agent.py') -Algorithm SHA256).Hash.ToLower()
$cf = (Get-FileHash -Path (Join-Path $root 'config.json') -Algorithm SHA256).Hash.ToLower()
if ($ra -eq 'b0ba0d61514e10c41592c05d97fb02b4768adb74e697cc3c1fb9c4334a732a23' -and
    $rm -eq '7eb4c477ada775fd003b29580198051c91d8263bdc135fed500ffc63755ca153' -and
    $cf -eq '6c23e1a72873ef1b5c896ab3caaff5a02120289ce383fbc896575af2853116ff') {
  Write-Output 'BUILD15 => APPLIED (per-symbol cap files all match)'
} else {
  Write-Output 'BUILD15 => NOT APPLIED or drifted (see DIFF lines above)'
}

# ---- 2) LIVE CONFIG VALUES ----
Write-Output ''
Write-Output '--- 2) LIVE CONFIG VALUES ---'
try {
  $cfg = Get-Content -Raw -Path (Join-Path $root 'config.json') | ConvertFrom-Json
  Write-Output ('execution.demo.max_new_orders_per_day    = ' + $cfg.execution.demo.max_new_orders_per_day)
  Write-Output ('risk_settings.max_open_trades            = ' + $cfg.risk_settings.max_open_trades)
  Write-Output ('risk_settings.max_open_trades_per_symbol = ' + $cfg.risk_settings.max_open_trades_per_symbol)
  Write-Output ('dynamic_risk_management.halt_after_losses= ' + $cfg.dynamic_risk_management.halt_after_losses)
  Write-Output ('session_planner.min_primary_quality_score= ' + $cfg.session_planner.min_primary_quality_score)
} catch { Write-Output ('CONFIG PARSE FAILED: ' + $_.Exception.Message) }

# ---- 3) TICK LOG (are the 884 refusals old or live?) ----
Write-Output ''
Write-Output '--- 3) TICK LOG (refusals: old or live?) ---'
$log = Join-Path $root 'logs\tick_manager.log'
if (Test-Path $log) {
  $fi = Get-Item $log
  $age = [Math]::Round(((Get-Date) - $fi.LastWriteTime).TotalMinutes, 1)
  Write-Output ('log size=' + $fi.Length + ' bytes   last write ' + $age + ' min ago')
  $lines = Get-Content -Path $log
  $total = $lines.Count
  $all = 0
  foreach ($ln in $lines) { if ($ln -match 'Demo order refused') { $all++ } }
  Write-Output ('total lines=' + $total + '   refusal lines in WHOLE file=' + $all)
  $lastIdx = -1
  for ($i = $total - 1; $i -ge 0; $i--) {
    if ($lines[$i] -match 'Demo order refused') { $lastIdx = $i; break }
  }
  if ($lastIdx -lt 0) { Write-Output 'no refusal lines found' }
  else { Write-Output ('last refusal at line ' + ($lastIdx + 1) + ' of ' + $total + '  (lines after it: ' + ($total - $lastIdx - 1) + ')') }
  Write-Output '--- last 6 log lines ---'
  $last6 = $lines | Select-Object -Last 6
  foreach ($ln in $last6) { Write-Output ('  | ' + $ln) }
  Write-Output ''
  if (($lastIdx -ge 0) -and ($total - $lastIdx - 1 -le 2)) { Write-Output 'VERDICT: REFUSALS ARE LIVE (log still ends with cap refusals)' }
  elseif ($lastIdx -lt 0) { Write-Output 'VERDICT: no refusals at all' }
  else { Write-Output 'VERDICT: refusals are HISTORICAL (normal lines after them)' }
} else { Write-Output 'tick_manager.log not found' }

# ---- 4) PYTHON PROCESSES (start time tells if tasks restarted after patches) ----
Write-Output ''
Write-Output '--- 4) PYTHON PROCESSES ---'
try {
  $procs = Get-CimInstance Win32_Process -Filter "Name='python.exe'"
  foreach ($p in $procs) {
    $cl = [string]$p.CommandLine
    if ($cl.Length -gt 130) { $cl = $cl.Substring(0, 130) }
    Write-Output ('PID=' + $p.ProcessId + '  START=' + $p.CreationDate + '  CMD=' + $cl)
  }
  if (@($procs).Count -eq 0) { Write-Output 'no python.exe process running' }
} catch { Write-Output ('process query failed: ' + $_.Exception.Message) }

Write-Output ''
Write-Output '===== VERIFY-STATE DONE ====='
