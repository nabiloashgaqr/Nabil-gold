$ErrorActionPreference = 'Continue'
$root = 'C:\Nabil-gold'
Write-Output '=============================================='
Write-Output 'OIL PATH AUDIT  (read-only - prints diagnostics only)'
Write-Output '=============================================='
Set-Location $root
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
& python scripts\oil_path_audit.py --root $root
Write-Output ('EXIT=' + $LASTEXITCODE)
