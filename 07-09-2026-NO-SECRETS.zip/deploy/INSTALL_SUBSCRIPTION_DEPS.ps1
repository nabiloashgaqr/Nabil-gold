﻿$ErrorActionPreference = 'Continue'
Write-Output '=============================================='
Write-Output 'INSTALL SUBSCRIPTION BOT DEPENDENCIES (BUILD 16)'
Write-Output '=============================================='
$root = 'C:\Nabil-gold'
Set-Location $root
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'

Write-Output '==> 1) pip install subscription_bot\requirements.txt'
python -m pip install -r subscription_bot\requirements.txt
if ($LASTEXITCODE -ne 0) {
    Write-Output '[WARN] full requirements failed - installing the minimal cron set instead'
    python -m pip install "python-telegram-bot==21.7" python-dotenv pytz
}

Write-Output '==> 2) smoke import test'
python -c "import telegram; print('telegram import OK', telegram.__version__)"
if ($LASTEXITCODE -ne 0) { Write-Output '[FAIL] telegram still not importable'; exit 1 }

Write-Output '==> 3) run one maintenance cycle (uses local JSON fallback, no Supabase)'
python subscription_bot\cron_maintenance.py
Write-Output ('    maintenance exit=' + $LASTEXITCODE)

Write-Output ''
Write-Output '==> DONE. Next scheduled run: every 4 hours (SS_SubscriptionBot).'
