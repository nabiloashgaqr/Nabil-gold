# ==============================================================================
# NABIL-GOLD: APPLY SOLUTIONS 1 & 2 (DISABLE MARKET PROMOTION & DEEP POI PREFERENCE)
# ==============================================================================
$baseDir = "C:\Nabil-gold"
Set-Location $baseDir

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = "$baseDir\deploy\backups\patch_$timestamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   تطبيق الحل 1 (إلغاء ملاحقة الماركت) والحل 2 (مناطق الطلب العميقة)   " -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Cyan

# 1. النسخ الاحتياطي
Write-Host "`n[1] أخذ نسخة احتياطية إلى: $backupDir" -ForegroundColor Green
Copy-Item "$baseDir\config.json" -Destination $backupDir -Force
Copy-Item "$baseDir\services\adaptive_execution.py" -Destination $backupDir -Force
Copy-Item "$baseDir\agents\smc_agent.py" -Destination $backupDir -Force

# 2. تطبيق التعديلات البرمجية والإعدادات
Write-Host "`n[2] تطبيق التعديلات البرمجية..." -ForegroundColor Green
python -c @"
import json, os

# A) Update config.json
cfg_path = r'$baseDir\config.json'
with open(cfg_path, 'r', encoding='utf-8') as f:
    cfg = json.load(f)

# 1. Adaptive Execution: Disable market promotion
if 'adaptive_execution' not in cfg:
    cfg['adaptive_execution'] = {}
cfg['adaptive_execution']['allow_market_promotion'] = False
cfg['adaptive_execution']['promote_to_market_min_move_points'] = 999999

# Order execution: Tighten market threshold to 15 points ($1.5 on Gold)
if 'order_execution' not in cfg:
    cfg['order_execution'] = {}
cfg['order_execution']['market_threshold_points'] = 15

# 2. SMC Engine: Deep POI / Extreme OB Preference
if 'smc_engine' not in cfg:
    cfg['smc_engine'] = {}
if 'poi_preference' not in cfg['smc_engine']:
    cfg['smc_engine']['poi_preference'] = {}

cfg['smc_engine']['poi_preference']['deep_zone_bonus'] = 16
cfg['smc_engine']['poi_preference']['proximity_bonus_cap'] = 4

with open(cfg_path, 'w', encoding='utf-8') as f:
    json.dump(cfg, f, indent=2, ensure_ascii=False)
print('Config updated successfully!')

# B) Update services/adaptive_execution.py
ae_path = r'$baseDir\services\adaptive_execution.py'
with open(ae_path, 'r', encoding='utf-8') as f:
    ae_code = f.read()

if 'self.allow_market_promotion' not in ae_code:
    old_init = 'or (self.config.get(\"risk_settings\", {}) or {}).get(\"min_rr_ratio\", 1.5)\n        )'
    new_init = old_init + '\n        self.allow_market_promotion = bool(cfg.get(\"allow_market_promotion\", True))'
    if old_init in ae_code:
        ae_code = ae_code.replace(old_init, new_init)

    old_rev = 'rules[\"promote_to_market_min_move_points\"] <= move_points <= rules[\"promote_to_market_max_move_points\"]'
    new_rev = 'rules.get(\"allow_market_promotion\", True) and rules[\"promote_to_market_min_move_points\"] <= move_points <= rules[\"promote_to_market_max_move_points\"]'
    if old_rev in ae_code:
        ae_code = ae_code.replace(old_rev, new_rev)

    old_eff = 'rules: Dict[str, float | str] = {\n            \"keep_pending_max_move_points\": self.keep_pending_max_move_points,'
    new_eff = 'rules: Dict[str, Any] = {\n            \"allow_market_promotion\": self.allow_market_promotion,\n            \"keep_pending_max_move_points\": self.keep_pending_max_move_points,'
    if old_eff in ae_code:
        ae_code = ae_code.replace(old_eff, new_eff)

    with open(ae_path, 'w', encoding='utf-8') as f:
        f.write(ae_code)
    print('adaptive_execution.py updated successfully!')

# C) Update agents/smc_agent.py
smc_path = r'$baseDir\agents\smc_agent.py'
with open(smc_path, 'r', encoding='utf-8') as f:
    smc_code = f.read()

if 'deep_discount_preferred' not in smc_code:
    old_call = '[self._rank_poi_candidate(candidate, direction, current_price, atr, market_structure, sweep) for candidate in candidates]'
    new_call = '[self._rank_poi_candidate(candidate, direction, current_price, atr, market_structure, sweep, dealing_range=dealing_range) for candidate in candidates]'
    if old_call in smc_code:
        smc_code = smc_code.replace(old_call, new_call)

    old_sig = 'def _rank_poi_candidate(\n        self,\n        candidate: Dict[str, Any],\n        direction: str,\n        current_price: float,\n        atr: float,\n        market_structure: Dict[str, Any],\n        sweep: Dict[str, Any],\n    ) -> Dict[str, Any]:'
    new_sig = 'def _rank_poi_candidate(\n        self,\n        candidate: Dict[str, Any],\n        direction: str,\n        current_price: float,\n        atr: float,\n        market_structure: Dict[str, Any],\n        sweep: Dict[str, Any],\n        dealing_range: Dict[str, float] | None = None,\n    ) -> Dict[str, Any]:'
    if old_sig in smc_code:
        smc_code = smc_code.replace(old_sig, new_sig)

    old_trend = 'trend = str(market_structure.get(\"trend\") or \"\")'
    new_trend = '''# Deep POI / Extreme Structure Bonus
        dr = dealing_range or {}
        dr_h = self._f(dr.get(\"high\"))
        dr_l = self._f(dr.get(\"low\"))
        if top > 0 and bottom > 0 and dr_h > 0 and dr_l > 0 and dr_h > dr_l:
            span = dr_h - dr_l
            mid = (top + bottom) / 2.0
            pos = (mid - dr_l) / span
            deep_bonus = float(pref.get(\"deep_zone_bonus\", 16) or 16)
            if direction == \"BUY\" and pos <= float(pref.get(\"buy_deep_discount_pct\", 0.40) or 0.40):
                score += deep_bonus
                reasons.append(\"deep_discount_preferred\")
            elif direction == \"SELL\" and pos >= float(pref.get(\"sell_deep_premium_pct\", 0.60) or 0.60):
                score += deep_bonus
                reasons.append(\"deep_premium_preferred\")

        trend = str(market_structure.get(\"trend\") or \"\")'''
    if old_trend in smc_code:
        smc_code = smc_code.replace(old_trend, new_trend, 1)

    with open(smc_path, 'w', encoding='utf-8') as f:
        f.write(smc_code)
    print('smc_agent.py updated successfully!')
"@

# 3. تشغيل اختبار التحقق
Write-Host "`n[3] تشغيل اختبارات التحقق من صحة النظام..." -ForegroundColor Green
pytest tests/test_adaptive_execution.py tests/test_smc_poi_trigger.py -q

# 4. إعادة تشغيل العمليات في الذاكرة لتطبيق الكود الجديد
Write-Host "`n[4] إعادة تشغيل المهام لتحديث العمليات في الذاكرة..." -ForegroundColor Green
schtasks /Run /TN "SS_DemoAnalysis"
schtasks /Run /TN "SS_DemoLoop"

Write-Host "`n============================================================" -ForegroundColor Cyan
Write-Host "     تم تطبيق الحل 1 والحل 2 واختبارهما بنجاح على النظام!    " -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Cyan
