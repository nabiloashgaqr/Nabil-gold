﻿param()
$ErrorActionPreference = 'Continue'
$root = 'C:\Nabil-gold'
Write-Output '=============================================='
Write-Output 'SETUP EIA WEEKLY FILL (optional automation)'
Write-Output '=============================================='
# 1) write the .bat wrapper (APPLY_PATCH blocks .bat payloads, so the
#    installer writes it itself - ASCII, CRLF)
$batDir = Join-Path $root 'deploy\tasks'
$bat = Join-Path $batDir 'eia_fill.bat'
New-Item -ItemType Directory -Path $batDir -Force | Out-Null
$lines = @(
  '@echo off',
  'REM Weekly EIA petroleum status fill (Wednesday ~15:10 UTC = 18:10 Hebron).',
  'cd /d "%~dp0..\.."',
  'set PYTHONUTF8=1',
  'set PYTHONIOENCODING=utf-8',
  'if not exist logs mkdir logs',
  'python scripts\fill_oil_macro.py >> logs\eia_fill.log 2>&1'
)
Set-Content -Path $bat -Value ($lines -join "`r`n") -Encoding Ascii
Write-Output ('wrote ' + $bat)
# 2) weekly task: Wednesday 15:10 UTC - EIA publishes the weekly petroleum
#    status Wed ~14:30 UTC, so 15:10 catches the fresh numbers.
& schtasks /Create /TN 'SS_EIAWeekly' /SC WEEKLY /D WED /ST 15:10 /TR 'cmd /c C:\Nabil-gold\deploy\tasks\eia_fill.bat' /F
# 3) verify
& schtasks /Query /TN 'SS_EIAWeekly' /FO LIST /V | Select-String -Pattern 'TaskName|Status|Schedule Type|Next Run Time'
Write-Output '=============================================='
Write-Output 'DONE'
