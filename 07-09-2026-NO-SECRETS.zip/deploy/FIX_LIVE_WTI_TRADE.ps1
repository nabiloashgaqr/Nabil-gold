﻿param(
    [switch]$Apply
)

$ErrorActionPreference = 'Continue'
$root = 'C:\Nabil-gold'
Set-Location $root
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
if ($Apply) {
    Write-Output 'FIX LIVE WTI TRADE - APPLY MODE (writes trades.json + moves broker SL/TP)'
    & python scripts\fix_live_wti_trade.py --root $root --apply
} else {
    Write-Output 'FIX LIVE WTI TRADE - DRY RUN (prints the plan, writes nothing)'
    Write-Output 'Re-run with -Apply to execute.'
    & python scripts\fix_live_wti_trade.py --root $root
}
Write-Output ('EXIT=' + $LASTEXITCODE)
