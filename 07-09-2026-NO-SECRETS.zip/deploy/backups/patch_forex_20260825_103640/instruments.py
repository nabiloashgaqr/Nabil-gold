"""Instrument metadata and point conversion helpers.

The project stores PnL/SL/TP distances in broker-style *points*:
- Gold XAU/USD: 1 point = 0.10 USD (10 points = 1.00)
- FX non-JPY: 1 point = 0.00001 (10 points = 1 pip)
- FX JPY pairs: 1 point = 0.001 (10 points = 1 pip)
- WTI oil: 1 point = 0.01 USD
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List


DEFAULT_INSTRUMENTS: Dict[str, Dict[str, Any]] = {
    "XAU/USD": {
        "symbol": "XAU/USD", "name": "Gold", "category": "metal",
        "point_size": 0.10, "price_decimals": 2,
        "min_sl_distance_points": 400, "trailing_distance": 150, "trailing_step": 40,
        # duplicate_zone 200 -> 150 (operator 2026-08-18): the second-entry
        # distance family (cross_entry / scale_in_trigger / duplicate zone)
        # moved to 150 together. Qualification gates are untouched.
        "early_breakeven_points": 200, "duplicate_zone_points": 150,
    },
    "WTI/USD": {
        "symbol": "WTI/USD", "name": "WTI Crude Oil", "category": "oil",
        "point_size": 0.01, "price_decimals": 2,
        # BUILD 31 R3 (2026-08-24, operator order): oil carries the SAME
        # LAW as gold at a FIXED SCALE FACTOR k = 0.4 — every absolute
        # gold number x 0.4, computed once (see the table in
        # DELIVERY_BUILD31_R3). R-based rules (0.8R TP1, 2x TP2, 0.5R BE
        # floor, 1.5R pre-arm), percent thresholds and ATR multipliers are
        # scale-invariant and stay as-is.
        #   stop = 200x0.4 / 70x0.4 / 400x0.4 = 80/28/160 -> band [108,160]
        #   TP1  = 0.8R (84.8 pts at the 108-pt floor)
        #   breakeven move = 150x0.4 = 60 pts
        #   trailing = 150x0.4 / 40x0.4 = 60 / 16
        "min_sl_distance_points": 160, "trailing_distance": 60, "trailing_step": 16,
        # second-entry distance family: 150 x 0.4 = 60 each (gold: 150).
        "early_breakeven_points": 60, "duplicate_zone_points": 60,
        # The gold trading law at x0.4: stop 80/28/160 (band [108,160]),
        # TP1 0.8R / 2x TP2 with the 80-pt (200x0.4) pool band and NO caps,
        # trailing 60/16 with the 60-pt breakeven move, 100-pt (250x0.4)
        # post-TP2 gate.
        "trading_rules": {
            "stop": {"enabled": True, "min_liquidity_points": 80,
                     "safety_buffer_points": 28, "max_stop_points": 160},
            "targets": {"min_tp1_rr": 0.8, "tp2_multiple": 2.0,
                        "max_beyond_points": 80},
            "trailing": {"enabled": True, "distance_points": 60,
                         "step_points": 16, "activation_at": "BREAKEVEN",
                         "early_breakeven_points": 60},
            "post_tp2": {"enabled": True, "min_distance_points": 100,
                         "window_hours": 2.5},
        },
        # Planner geometry at x0.4 of the gold global values
        # (120/150/450/450/6/60/30 -> 48/60/180/180/2.4/24/12).
        "session_planner": {
            "fallback_zone_half_width_points": 48,
            "standby_min_distance_points": 60,
            "max_primary_zone_width_points": 180,
            "max_standby_zone_width_points": 180,
            "min_zone_width_points": 2.4,
            "min_entry_zone_width_points": 24,
            "min_thesis_objective_points": 12,
        },
        # cross-path / scale-in distances: 150 x 0.4 = 60 (gold: 150).
        "cross_entry_distance_points": 60,
        "scale_in_trigger_points": 60,
        # BUILD 20 (2026-08-20, operator order): the WTI auction curve is now
        # BUILT from MT5 history by scripts/build_oil_auction_calibration.py
        # and production config.json carries calibration_required=true so the
        # agent DEMANDS the curve like gold. This DEFAULT stays false so a
        # bare config without a curve keeps the explicit linear fallback
        # (and the gold curve stays barred by the calibration symbol guard).
        "auction_flow": {"calibration_required": False},
    },
}

ALIASES = {
    "XAUUSD": "XAU/USD",
    "GOLD": "XAU/USD",
    "WTI": "WTI/USD",
    "USOIL": "WTI/USD",
    "OIL": "WTI/USD",
    "OIL/W": "WTI/USD",
    "WTICO_USD": "WTI/USD",
}


def normalize_symbol(symbol: Any) -> str:
    text = str(symbol or "XAU/USD").strip().upper().replace(" ", "")
    if text in ALIASES:
        return ALIASES[text]
    if "/" not in text and len(text) == 6:
        text = f"{text[:3]}/{text[3:]}"
    return text


def instrument_map(config: Dict[str, Any] | None = None) -> Dict[str, Dict[str, Any]]:
    mapping = deepcopy(DEFAULT_INSTRUMENTS)
    for item in (config or {}).get("instruments", []) or []:
        if not isinstance(item, dict):
            continue
        symbol = normalize_symbol(item.get("symbol"))
        base = mapping.get(symbol, {"symbol": symbol})
        base.update(item)
        base["symbol"] = symbol
        mapping[symbol] = base
    return mapping


def get_instrument(config: Dict[str, Any] | None = None, symbol: Any = None) -> Dict[str, Any]:
    symbol = normalize_symbol(symbol or (config or {}).get("symbol") or "XAU/USD")
    mapping = instrument_map(config)
    return deepcopy(mapping.get(symbol, {"symbol": symbol, "point_size": 0.00001, "price_decimals": 5}))


def point_size(symbol: Any = None, config: Dict[str, Any] | None = None) -> float:
    return float(get_instrument(config, symbol).get("point_size", 0.00001) or 0.00001)


def price_decimals(symbol: Any = None, config: Dict[str, Any] | None = None) -> int:
    return int(get_instrument(config, symbol).get("price_decimals", 5) or 5)


def points_to_price(points: float, symbol: Any = None, config: Dict[str, Any] | None = None) -> float:
    return float(points or 0) * point_size(symbol, config)


def price_to_points(price_delta: float, symbol: Any = None, config: Dict[str, Any] | None = None) -> float:
    ps = point_size(symbol, config)
    return float(price_delta or 0) / ps if ps else 0.0


def enabled_instruments(config: Dict[str, Any]) -> List[Dict[str, Any]]:
    configured = config.get("symbols") or config.get("enabled_symbols")
    if not configured:
        return [get_instrument(config, config.get("symbol", "XAU/USD"))]
    result: List[Dict[str, Any]] = []
    mapping = instrument_map(config)
    for item in configured:
        if isinstance(item, str):
            symbol = normalize_symbol(item)
            enabled = True
            overrides: Dict[str, Any] = {}
        elif isinstance(item, dict):
            symbol = normalize_symbol(item.get("symbol"))
            enabled = bool(item.get("enabled", True))
            overrides = dict(item)
        else:
            continue
        if not enabled:
            continue
        spec = deepcopy(mapping.get(symbol, {"symbol": symbol}))
        spec.update(overrides)
        spec["symbol"] = symbol
        result.append(spec)
    return result or [get_instrument(config, config.get("symbol", "XAU/USD"))]


def config_for_instrument(base_config: Dict[str, Any], instrument: Dict[str, Any]) -> Dict[str, Any]:
    cfg = deepcopy(base_config)
    symbol = normalize_symbol(instrument.get("symbol"))
    spec = get_instrument(base_config, symbol)
    spec.update(instrument)
    spec["symbol"] = symbol
    cfg["symbol"] = symbol
    cfg["instrument"] = spec

    cfg.setdefault("risk_settings", {})["min_sl_distance_points"] = spec.get(
        "min_sl_distance_points", cfg.get("risk_settings", {}).get("min_sl_distance_points", 400)
    )
    cfg.setdefault("trailing_stop", {})["trailing_distance"] = spec.get(
        "trailing_distance", cfg.get("trailing_stop", {}).get("trailing_distance", 150)
    )
    cfg["trailing_stop"]["trailing_step"] = spec.get(
        "trailing_step", cfg.get("trailing_stop", {}).get("trailing_step", 40)
    )
    cfg["trailing_stop"]["early_breakeven_points"] = spec.get(
        "early_breakeven_points", cfg.get("trailing_stop", {}).get("early_breakeven_points", 200)
    )
    cfg.setdefault("duplicate_signal_filter", {})["price_zone_points"] = spec.get(
        "duplicate_zone_points", cfg.get("duplicate_signal_filter", {}).get("price_zone_points", 50)
    )
    # Per-instrument trading_rules override the global (gold-scale) block so
    # the one canonical law set is always expressed in THIS instrument's
    # points (operator 2026-08-16, WTI shadow onboarding).
    inst_rules = spec.get("trading_rules")
    if isinstance(inst_rules, dict) and inst_rules:
        merged = deepcopy(cfg.get("trading_rules") or {})
        for section, values in inst_rules.items():
            if isinstance(values, dict):
                base = dict(merged.get(section) or {})
                base.update(values)
                merged[section] = base
            else:
                merged[section] = values
        cfg["trading_rules"] = merged
    # Same for the per-instrument auction_flow overrides.
    inst_auction = spec.get("auction_flow")
    if isinstance(inst_auction, dict) and inst_auction:
        base = deepcopy(cfg.get("auction_flow") or {})
        base.update(inst_auction)
        cfg["auction_flow"] = base
    # Same for planner point-geometry and the cross-entry spacing.
    inst_planner = spec.get("session_planner")
    if isinstance(inst_planner, dict) and inst_planner:
        base = deepcopy(cfg.get("session_planner") or {})
        base.update(inst_planner)
        cfg["session_planner"] = base
    if spec.get("cross_entry_distance_points"):
        two = cfg.setdefault("signal_requirements", {}).setdefault("two_agent_entry", {})
        two["cross_entry_distance_points"] = spec["cross_entry_distance_points"]
    # Scale-in trigger is expressed in POINTS and the global block is
    # gold-scale: 150 gold points = $15 (0.34% of price) but 150 oil points
    # = $1.50 (a 1.8% move at $84) — first live log line for WTI read
    # "need >=150 pts below entry" (2026-08-18 11:41), an impossible bar
    # that would have starved the shadow book of adds. Same fix pattern as
    # cross_entry above.
    if spec.get("scale_in_trigger_points"):
        fr = cfg.setdefault("order_execution", {}).setdefault("fixed_risk", {})
        fr["scale_in_trigger_points"] = spec["scale_in_trigger_points"]
    return cfg
