﻿$ErrorActionPreference = 'Continue'
Write-Output '=============================================='
Write-Output 'UPDATE-SCHEDULES 2026-08-20  (BUILD 16)'
Write-Output '=============================================='

# Operator order 2026-08-20:
#   Daily report  + dashboard  -> 23:50 Hebron  = 20:50 UTC
#   Weekly report              -> Friday 23:55 Hebron = Friday 20:55 UTC
#   SS_MarketStatus deleted    -> the 5-min cycle status is the one true hourly status

$results = @()

function Apply-Change($label, $command) {
    Write-Output ('--- ' + $label)
    $out = cmd /c $command 2>&1
    $out | ForEach-Object { Write-Output ('    ' + $_) }
    $results += [PSCustomObject]@{ Label = $label; Out = ($out -join ' | ') }
}

Apply-Change 'Daily report -> 20:50 UTC (23:50 Hebron)' 'schtasks /Change /TN "SS_DailyReport" /ST 20:50'
Apply-Change 'Dashboard     -> 20:50 UTC (23:50 Hebron)' 'schtasks /Change /TN "SS_Dashboard" /ST 20:50'
Apply-Change 'Weekly report -> Friday 20:55 UTC (Fri 23:55 Hebron)' 'schtasks /Change /TN "SS_WeeklyReport" /D FRI /ST 20:55'
Apply-Change 'Delete legacy SS_MarketStatus (duplicate hourly sender)' 'schtasks /Delete /TN "SS_MarketStatus" /F'
Apply-Change 'Subscription bot -> VPS task every 4 hours (replaces GitHub cron)' 'schtasks /Create /TN "SS_SubscriptionBot" /SC HOURLY /MO 4 /TR "cmd /c C:\Nabil-gold\deploy\tasks\subscription_bot.bat" /F'

Write-Output ''
Write-Output '--- VERIFY (next run time) ---'
foreach ($tn in @('SS_DailyReport','SS_Dashboard','SS_WeeklyReport','SS_DemoAnalysis','SS_TickManager','SS_SubscriptionBot')) {
    $q = cmd /c ('schtasks /Query /TN "' + $tn + '" /FO LIST /V') 2>&1 | Out-String
    $nxt = ''
    if ($q -match 'Next Run Time:\s+([^\r\n]+)') { $nxt = $Matches[1].Trim() }
    $mode = ''
    if ($q -match 'Schedule Type:\s+([^\r\n]+)') { $mode = $Matches[1].Trim() }
    $state = ''
    if ($q -match 'Status:\s+([^\r\n]+)') { $state = $Matches[1].Trim() }
    if ($q -match 'ERROR') { Write-Output ('    ' + $tn + ' : NOT FOUND') }
    else { Write-Output ('    ' + $tn + ' : ' + $state + ' | ' + $mode + ' | next: ' + $nxt) }
}

Write-Output ''
Write-Output '--- RESTART RUNTIME TASKS (load BUILD 16 code) ---'
foreach ($tn in @('SS_DemoLoop','SS_TickManager')) {
    $end = cmd /c ('schtasks /End /TN "' + $tn + '"') 2>&1 | Out-String
    Start-Sleep -Seconds 3
    $run = cmd /c ('schtasks /Run /TN "' + $tn + '"') 2>&1 | Out-String
    Write-Output ('    ' + $tn + ' : end=' + ($end -join ' ').Trim() + ' | run=' + ($run -join ' ').Trim())
}

Write-Output ''
Write-Output '===== UPDATE-SCHEDULES DONE ====='
