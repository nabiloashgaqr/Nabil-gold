﻿param()
$ErrorActionPreference = 'Continue'
$root = 'C:\Nabil-gold'
Write-Output '=============================================='
Write-Output 'SETUP EIA DAILY FILL (operator order 2026-08-20)'
Write-Output '=============================================='
# 1) write the .bat wrapper (APPLY_PATCH blocks .bat payloads, so the
#    installer writes it itself - ASCII, CRLF)
$batDir = Join-Path $root 'deploy\tasks'
$bat = Join-Path $batDir 'eia_fill.bat'
New-Item -ItemType Directory -Path $batDir -Force | Out-Null
$lines = @(
  '@echo off',
  'REM Daily EIA petroleum status fill (15:10 UTC = 18:10 Hebron).',
  'REM The data is WEEKLY (published Wednesday ~14:30 UTC) but a daily run',
  'REM self-heals a missed/partial fill the very next day - 1 tiny request.',
  'cd /d "%~dp0..\.."',
  'set PYTHONUTF8=1',
  'set PYTHONIOENCODING=utf-8',
  'if not exist logs mkdir logs',
  'python scripts\fill_oil_macro.py >> logs\eia_fill.log 2>&1'
)
Set-Content -Path $bat -Value ($lines -join "`r`n") -Encoding Ascii
Write-Output ('wrote ' + $bat)
# 2) daily task (replaces the weekly one if it exists)
& schtasks /Delete /TN 'SS_EIAWeekly' /F 2>&1 | Out-Null
& schtasks /Create /TN 'SS_EIAFill' /SC DAILY /ST 15:10 /TR 'cmd /c C:\Nabil-gold\deploy\tasks\eia_fill.bat' /F
# 3) verify
& schtasks /Query /TN 'SS_EIAFill' /FO LIST /V | Select-String -Pattern 'TaskName|Status|Schedule Type|Next Run Time'
Write-Output '=============================================='
Write-Output 'DONE'
