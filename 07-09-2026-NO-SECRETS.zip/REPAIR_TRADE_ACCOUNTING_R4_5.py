#!/usr/bin/env python3
"""Repair sign-inconsistent terminal result labels; preserves ledger backup."""
from __future__ import annotations
import json, os, shutil, sys
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent
LIVE={"OPEN","PENDING","PARTIAL","TP1_HIT"}

def main()->int:
    cfg=json.loads((ROOT/'config.json').read_text(encoding='utf-8-sig'))
    ledger=ROOT/str((cfg.get('database') or {}).get('local_fallback_file','storage/trades.json'))
    rows=json.loads(ledger.read_text(encoding='utf-8-sig'))
    changed=[]
    for r in rows:
        if not isinstance(r,dict): continue
        pnl=r.get('final_pnl')
        if pnl is None: pnl=r.get('final_pnl_points')
        if pnl is None: continue
        try: pnl=float(pnl)
        except (TypeError,ValueError): continue
        expected='WIN' if pnl>1e-9 else ('LOSS' if pnl < -1e-9 else 'BREAKEVEN')
        result=str(r.get('result') or '').upper()
        status=str(r.get('status') or '').upper()
        updates={}
        if result in {'WIN','LOSS','BREAKEVEN'} and result != expected:
            updates['result']=expected
        # WIN/LOSS are outcomes, not exit mechanisms. Repair rows previously
        # converted from TP1_HIT zombies using the stale result as status.
        if status in {'WIN','LOSS','BREAKEVEN'} and r.get('closed_at'):
            entry=float(r.get('entry_price') or 0); stop=float(r.get('stop_loss') or 0)
            side=str(r.get('type') or r.get('side') or '').upper()
            protected=(side=='BUY' and stop>=entry) or (side=='SELL' and stop<=entry)
            updates['status']='TRAILING_SL_HIT' if protected and pnl>0 else 'CLOSED'
        if updates:
            changed.append((str(r.get('id')),status,result,updates.copy()))
            r.update(updates)
    if not changed:
        print('R4.5 ACCOUNTING: no sign inconsistencies found'); return 0
    stamp=datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
    backup=ledger.with_name(f'{ledger.stem}.backup_R4_5_{stamp}{ledger.suffix}')
    shutil.copy2(ledger,backup)
    tmp=ledger.with_suffix(ledger.suffix+'.R4_5.tmp')
    tmp.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    json.loads(tmp.read_text(encoding='utf-8'))
    os.replace(tmp,ledger)
    print(f'BACKUP: {backup}')
    for tid,status,result,updates in changed: print(f'REPAIRED: {tid} status={status} result={result} -> {updates}')
    print(f'R4.5 ACCOUNTING: repaired={len(changed)}')
    return 0
if __name__=='__main__': raise SystemExit(main())
