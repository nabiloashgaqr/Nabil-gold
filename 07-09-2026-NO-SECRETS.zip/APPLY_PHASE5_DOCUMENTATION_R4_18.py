#!/usr/bin/env python3
"""Merge R4.18 documentation clarifications into config.json safely.

No trading value or switch is changed. Only two description fields are updated.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import tempfile

RISK_DESCRIPTION = (
    "Volatility sizing consumer. When risk_settings.vol_targeting.enabled=true, "
    "RiskManagementAgent applies VolatilityAgent.suggested_risk_multiplier to "
    "position risk (EXTREME 0.5, HIGH 0.75, otherwise 1.0). This switch is "
    "independent of volatility_agent.apply_risk_multiplier; current production "
    "configuration intentionally enables both."
)
AGENT_DESCRIPTION = (
    "Non-voting volatility agent using VIX/GVZ for gold, VIX/OVX for oil, and "
    "D1 ATR percentile. It emits regime and suggested_risk_multiplier. "
    "volatility_agent.apply_risk_multiplier describes the agent-side application "
    "flag; actual RiskManagementAgent consumption is controlled independently by "
    "risk_settings.vol_targeting.enabled."
)


def merge(cfg: dict) -> list[str]:
    changes = []
    targets = [
        (cfg.setdefault("risk_settings", {}).setdefault("vol_targeting", {}),
         "description", RISK_DESCRIPTION, "risk_settings.vol_targeting.description"),
        (cfg.setdefault("volatility_agent", {}), "description", AGENT_DESCRIPTION,
         "volatility_agent.description"),
    ]
    for block, key, value, label in targets:
        if block.get(key) != value:
            block[key] = value
            changes.append(label)
    return changes


def validate(cfg: dict) -> None:
    assert cfg["risk_settings"]["vol_targeting"]["description"] == RISK_DESCRIPTION
    assert cfg["volatility_agent"]["description"] == AGENT_DESCRIPTION


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args(argv)
    path = Path(args.config).resolve()
    cfg = json.loads(path.read_text(encoding="utf-8-sig"))
    before = json.dumps(cfg, sort_keys=True, ensure_ascii=False)
    changes = merge(cfg)
    validate(cfg)
    if not changes:
        print("R4.18 documentation already applied; no backup or write needed.")
        return 0
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup = path.with_name(f"{path.stem}.backup_before_R4_18_{stamp}{path.suffix}")
    shutil.copy2(path, backup)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(cfg, fh, ensure_ascii=False, indent=2)
            fh.write("\n")
            fh.flush(); os.fsync(fh.fileno())
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name): os.unlink(temp_name)
    after = json.loads(path.read_text(encoding="utf-8"))
    validate(after)
    assert json.dumps(after, sort_keys=True, ensure_ascii=False) != before
    print(f"Applied {len(changes)} documentation changes. Backup: {backup}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
