"""Phase-5 entry architecture and broker-inert virtual order simulation."""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, Mapping, Optional
from uuid import uuid4

from utils.instruments import point_size, round_price
from utils.trading_rules import distance_ratio

from .models import ScenarioSnapshot, ScenarioStatus, utc_now


class EntryMethod(str, Enum):
    LIMIT = "LIMIT"
    ZONE_EXIT_MARKET = "ZONE_EXIT_MARKET"
    BREAKOUT_RETEST_MARKET = "BREAKOUT_RETEST_MARKET"
    SWEEP_RECLAIM_MARKET = "SWEEP_RECLAIM_MARKET"
    FIRST_PULLBACK_LIMIT = "FIRST_PULLBACK_LIMIT"
    PENDING_TRIGGER = "PENDING_TRIGGER"
    PASS = "PASS"


class VirtualOrderStatus(str, Enum):
    PENDING = "PENDING"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"
    PASSED = "PASSED"


@dataclass(frozen=True)
class EntryPlan:
    scenario_id: str
    family_id: str
    symbol: str
    side: str
    method: EntryMethod
    decision: str
    known_at: str
    entry_price: Optional[float]
    stop_loss: Optional[float]
    tp1: Optional[float]
    tp2: Optional[float]
    tp3: Optional[float]
    risk_points: float
    remaining_rr: float
    reason: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    plan_id: str = field(default_factory=lambda: uuid4().hex)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self); d["method"] = self.method.value; return d


@dataclass
class VirtualOrder:
    plan_id: str
    scenario_id: str
    family_id: str
    symbol: str
    side: str
    method: str
    status: VirtualOrderStatus
    created_at: str
    entry_price: Optional[float]
    stop_loss: Optional[float]
    tp1: Optional[float]
    tp2: Optional[float]
    tp3: Optional[float]
    order_id: str = field(default_factory=lambda: uuid4().hex)
    filled_at: Optional[str] = None
    fill_price: Optional[float] = None
    spread_points: Optional[float] = None
    slippage_points: float = 0.0
    payload: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self); d["status"] = self.status.value; return d


def _has_all(evidence: Mapping[str, Any], names: tuple[str, ...]) -> bool:
    events = evidence.get("events") or evidence.get("trigger_events") or {}
    return isinstance(events, Mapping) and all(bool(events.get(name)) for name in names)


def _dt(value: str) -> datetime:
    dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


class EntryArchitect:
    LIMIT_PLAYBOOKS = {
        "TREND_PULLBACK", "MATURE_TREND_PULLBACK", "RANGE_EDGE_ROTATION",
        "FIRST_PULLBACK_AFTER_EXPANSION", "CONTINUATION_POI",
    }
    BREAKOUT_PLAYBOOKS = {"BREAKOUT_RETEST", "POST_SHOCK_CONTINUATION"}
    REVERSAL_PLAYBOOKS = {
        "EXTREME_FAILED_AUCTION", "FAILED_AUCTION_REVERSAL",
        "EXTREME_REVERSAL", "POST_SHOCK_FAILED_AUCTION",
    }

    def __init__(self, config: Mapping[str, Any], root_config: Mapping[str, Any]):
        self.config = dict(config or {})
        self.root_config = dict(root_config or {})

    def _geometry(self, scenario: ScenarioSnapshot, entry: float) -> tuple[float,float,float,float,float]:
        ratio = float(distance_ratio(self.root_config, scenario.symbol))
        pv = float(point_size(scenario.symbol, self.root_config))
        base_risk = float(self.config.get("gold_risk_points", 300))
        floor = float(self.config.get("gold_min_risk_points", 270))
        cap = float(self.config.get("gold_max_risk_points", 400))
        risk_pts = max(floor, min(cap, base_risk)) * ratio
        risk = risk_pts * pv
        buy = scenario.side.value == "BUY"
        structural = scenario.invalidation
        stop = entry-risk if buy else entry+risk
        if structural and ((buy and structural < entry) or (not buy and structural > entry)):
            structural_pts = abs(entry-structural)/pv
            if structural_pts <= cap*ratio:
                stop = structural; risk_pts = structural_pts; risk = abs(entry-stop)
        direction = 1 if buy else -1
        rr1 = float(self.config.get("tp1_rr", 1.0)); rr2 = float(self.config.get("tp2_rr", 2.0)); rr3 = float(self.config.get("tp3_rr", 3.0))
        vals = [stop, entry+direction*risk*rr1, entry+direction*risk*rr2, entry+direction*risk*rr3]
        return tuple(round_price(x, scenario.symbol, self.root_config) for x in vals)+(risk_pts,)

    def plan(self, scenario: ScenarioSnapshot) -> EntryPlan:
        side = scenario.side.value; evidence = scenario.evidence or {}
        family = scenario.family_id or scenario.scenario_id
        entry = scenario.preferred_entry
        method, decision, reason = EntryMethod.PASS, "PASS", "no executable entry"
        if scenario.playbook.startswith("NO_TRADE"):
            reason = "playbook explicitly requires no trade"
        elif entry is None or scenario.entry_low is None or scenario.entry_high is None:
            reason = "no pre-published entry zone"
        elif scenario.playbook in self.LIMIT_PLAYBOOKS:
            method, decision, reason = EntryMethod.LIMIT, "PLACE_VIRTUAL", "pre-published POI limit"
        elif scenario.playbook in self.BREAKOUT_PLAYBOOKS:
            if _has_all(evidence, ("break_acceptance","retest","failed_reclaim")):
                method, decision, reason = EntryMethod.BREAKOUT_RETEST_MARKET, "PLACE_VIRTUAL", "breakout-retest trigger complete"
            else:
                method, decision, reason = EntryMethod.PENDING_TRIGGER, "WATCH_TRIGGER", "breakout-retest trigger incomplete"
        elif scenario.playbook in self.REVERSAL_PLAYBOOKS:
            if _has_all(evidence, ("sweep_or_failed_auction","reclaim","micro_structure_shift")):
                method, decision, reason = EntryMethod.SWEEP_RECLAIM_MARKET, "PLACE_VIRTUAL", "failed-auction reversal trigger complete"
            else:
                method, decision, reason = EntryMethod.PENDING_TRIGGER, "WATCH_TRIGGER", "reversal trigger incomplete"
        if method in {EntryMethod.PASS, EntryMethod.PENDING_TRIGGER} or entry is None:
            return EntryPlan(scenario.scenario_id,family,scenario.symbol,side,method,decision,
                             scenario.known_at,entry,None,None,None,None,0,0,reason,
                             {"playbook":scenario.playbook,"horizon":scenario.horizon.value})
        sl,tp1,tp2,tp3,risk_pts = self._geometry(scenario,float(entry))
        return EntryPlan(scenario.scenario_id,family,scenario.symbol,side,method,decision,
                         scenario.known_at,round_price(float(entry),scenario.symbol,self.root_config),
                         sl,tp1,tp2,tp3,round(risk_pts,1),2.0,reason,
                         {"playbook":scenario.playbook,"horizon":scenario.horizon.value,
                          "distance_ratio":float(distance_ratio(self.root_config,scenario.symbol))})

    def virtual_order(self, plan: EntryPlan) -> VirtualOrder:
        status = VirtualOrderStatus.PASSED if plan.method == EntryMethod.PASS else VirtualOrderStatus.PENDING
        return VirtualOrder(plan.plan_id,plan.scenario_id,plan.family_id,plan.symbol,plan.side,
                            plan.method.value,status,plan.known_at,plan.entry_price,plan.stop_loss,
                            plan.tp1,plan.tp2,plan.tp3,payload={"decision":plan.decision,"reason":plan.reason,**plan.metadata})


class VirtualBroker:
    """Pure simulation. It has deliberately no production broker dependency."""
    MARKET_METHODS = {EntryMethod.ZONE_EXIT_MARKET.value,EntryMethod.BREAKOUT_RETEST_MARKET.value,EntryMethod.SWEEP_RECLAIM_MARKET.value}
    def __init__(self, root_config: Mapping[str,Any], config: Mapping[str,Any]|None=None):
        self.root_config=dict(root_config or {}); self.config=dict(config or {})

    def on_tick(self, order: VirtualOrder, *, bid: float, ask: float, known_at: str) -> bool:
        if order.status != VirtualOrderStatus.PENDING or _dt(known_at) < _dt(order.created_at):
            return False
        if bid<=0 or ask<=0 or ask<bid:
            return False
        pv=float(point_size(order.symbol,self.root_config)); side=order.side
        fill=None
        if order.method in self.MARKET_METHODS:
            fill=ask if side=="BUY" else bid
        elif order.method in {EntryMethod.LIMIT.value,EntryMethod.FIRST_PULLBACK_LIMIT.value} and order.entry_price:
            if side=="BUY" and ask<=order.entry_price: fill=min(ask,order.entry_price)
            if side=="SELL" and bid>=order.entry_price: fill=max(bid,order.entry_price)
        if fill is None:
            return False
        slip=float(self.config.get("market_slippage_points",0)) if order.method in self.MARKET_METHODS else 0.0
        fill += slip*pv if side=="BUY" else -slip*pv
        if order.method in self.MARKET_METHODS and order.entry_price:
            # Preserve the planned geometry at the executable market fill;
            # never book targets/stops around a fictitious reference quote.
            delta=fill-order.entry_price
            if order.stop_loss is not None: order.stop_loss=round_price(order.stop_loss+delta,order.symbol,self.root_config)
            if order.tp1 is not None: order.tp1=round_price(order.tp1+delta,order.symbol,self.root_config)
            if order.tp2 is not None: order.tp2=round_price(order.tp2+delta,order.symbol,self.root_config)
            if order.tp3 is not None: order.tp3=round_price(order.tp3+delta,order.symbol,self.root_config)
        order.status=VirtualOrderStatus.FILLED; order.filled_at=known_at
        order.fill_price=round_price(fill,order.symbol,self.root_config)
        order.spread_points=round((ask-bid)/pv,1) if pv>0 else None
        order.slippage_points=slip
        return True
