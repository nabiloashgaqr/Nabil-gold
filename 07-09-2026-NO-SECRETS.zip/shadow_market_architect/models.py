"""Phase-1 domain contracts for the isolated shadow research ledger."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, Optional
from uuid import uuid4


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class Horizon(str, Enum):
    SCALP = "SCALP"
    INTRADAY = "INTRADAY"
    STRUCTURAL = "STRUCTURAL"


class MarketState(str, Enum):
    TREND_CONTINUATION = "TREND_CONTINUATION"
    RANGE_ROTATION = "RANGE_ROTATION"
    COMPRESSION = "COMPRESSION"
    EXPANSION = "EXPANSION"
    EXHAUSTION = "EXHAUSTION"
    TRANSITION = "TRANSITION"
    SHOCK_NEWS = "SHOCK_NEWS"
    UNCERTAIN = "UNCERTAIN"


class ScenarioSide(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class ScenarioStatus(str, Enum):
    DISCOVERED = "DISCOVERED"
    WATCH = "WATCH"
    APPROACHING = "APPROACHING"
    INSIDE_POI = "INSIDE_POI"
    ARMED = "ARMED"
    READY = "READY"
    INVALIDATED = "INVALIDATED"
    EXPIRED = "EXPIRED"


@dataclass(frozen=True)
class ShadowEvent:
    event_type: str
    symbol: str
    known_at: str
    payload: Dict[str, Any] = field(default_factory=dict)
    scenario_id: Optional[str] = None
    event_id: str = field(default_factory=lambda: uuid4().hex)
    recorded_at: str = field(default_factory=utc_now)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ScenarioSnapshot:
    """Immutable ex-ante snapshot; later outcomes never rewrite this record."""
    symbol: str
    side: ScenarioSide
    horizon: Horizon
    playbook: str
    status: ScenarioStatus
    known_at: str
    evidence: Dict[str, Any]
    config_version: str
    scenario_id: str = field(default_factory=lambda: uuid4().hex)
    family_id: Optional[str] = None
    entry_low: Optional[float] = None
    entry_high: Optional[float] = None
    preferred_entry: Optional[float] = None
    invalidation: Optional[float] = None
    tp1: Optional[float] = None
    tp2: Optional[float] = None
    tp3: Optional[float] = None
    expiry_at: Optional[str] = None
    recorded_at: str = field(default_factory=utc_now)

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["side"] = self.side.value
        data["horizon"] = self.horizon.value
        data["status"] = self.status.value
        return data
