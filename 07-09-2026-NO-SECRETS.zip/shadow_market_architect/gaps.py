"""Phase-7 gap intelligence between original decisions and shadow outcomes."""
from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, Iterable, Mapping, Optional

from .entries import _dt
from .models import utc_now


class GapType(str, Enum):
    MISSED_OPPORTUNITY = "MISSED_OPPORTUNITY"
    AVOIDED_LOSS = "AVOIDED_LOSS"
    ORIGINAL_ONLY = "ORIGINAL_ONLY"
    DIRECTION_DISAGREEMENT = "DIRECTION_DISAGREEMENT"
    ENTRY_TIMING = "ENTRY_TIMING"
    EXIT_MANAGEMENT = "EXIT_MANAGEMENT"
    OUTCOME_DIVERGENCE = "OUTCOME_DIVERGENCE"


@dataclass(frozen=True)
class GapComparison:
    symbol: str
    gap_type: GapType
    compared_at: str
    details: Dict[str, Any]
    original_trade_id: Optional[str] = None
    scenario_id: Optional[str] = None
    family_id: Optional[str] = None
    comparison_id: str = ""

    def __post_init__(self) -> None:
        if not self.comparison_id:
            raw="|".join((self.original_trade_id or "-",self.scenario_id or "-",self.family_id or "-",self.gap_type.value))
            object.__setattr__(self,"comparison_id",hashlib.sha256(raw.encode()).hexdigest()[:32])

    def to_dict(self) -> Dict[str, Any]:
        d=asdict(self);d["gap_type"]=self.gap_type.value;return d


class GapIntelligence:
    """Family-aware observational comparison; it never changes either system."""
    def __init__(self, config: Mapping[str, Any] | None = None):
        self.config=dict(config or {})
        self.window_seconds=float(self.config.get("match_window_seconds",14400))
        self.entry_tolerance_points=float(self.config.get("entry_tolerance_points",40))
        self.exit_tolerance_r=float(self.config.get("exit_tolerance_r",0.25))

    @staticmethod
    def _f(x:Any,default:float=0.0)->float:
        try:return float(x)
        except (TypeError,ValueError):return default

    @staticmethod
    def _value(x:Any,key:str,default:Any=None)->Any:
        if isinstance(x,Mapping):return x.get(key,default)
        return getattr(x,key,default)

    def _time(self,x:Any)->Optional[str]:
        return self._value(x,"opened_at") or self._value(x,"known_at") or self._value(x,"created_at")

    def _closed_shadow(self, shadows:Iterable[Any])->list[Any]:
        return [s for s in shadows if str(getattr(self._value(s,"status"),"value",self._value(s,"status"))).upper()=="CLOSED"]

    def compare(self, originals:Iterable[Any], shadows:Iterable[Any], *, compared_at:Optional[str]=None)->list[GapComparison]:
        now=compared_at or utc_now(); originals=list(originals); shadows=self._closed_shadow(shadows)
        # One representative per scenario family prevents multi-horizon inflation.
        by_family:Dict[tuple[str,str],Any]={}
        for s in shadows:
            key=(str(self._value(s,"symbol")),str(self._value(s,"family_id") or self._value(s,"scenario_id")))
            old=by_family.get(key)
            if old is None or self._f(self._value(s,"realized_r"))>self._f(self._value(old,"realized_r")):by_family[key]=s
        shadows=list(by_family.values());matched:set[int]=set();out:list[GapComparison]=[]
        for o in originals:
            sym=str(self._value(o,"symbol") or "");ot=self._time(o); candidates=[]
            for i,s in enumerate(shadows):
                if i in matched or str(self._value(s,"symbol"))!=sym:continue
                st=self._time(s)
                if not ot or not st or abs((_dt(st)-_dt(ot)).total_seconds())<=self.window_seconds:candidates.append((i,s))
            if not candidates:
                out.append(self._make(GapType.ORIGINAL_ONLY,o,None,now,{"reason":"no closed shadow family in match window"}));continue
            i,s=min(candidates,key=lambda z:abs((_dt(self._time(z[1]))-_dt(ot)).total_seconds()) if ot and self._time(z[1]) else 0);matched.add(i)
            oside=str(self._value(o,"side") or self._value(o,"direction") or "").upper();sside=str(self._value(s,"side") or "").upper()
            opnl=self._f(self._value(o,"pnl_r",self._value(o,"realized_r")));spnl=self._f(self._value(s,"realized_r"))
            if oside and sside and oside!=sside:out.append(self._make(GapType.DIRECTION_DISAGREEMENT,o,s,now,{"original_side":oside,"shadow_side":sside,"original_r":opnl,"shadow_r":spnl}))
            if opnl<0<=spnl:out.append(self._make(GapType.AVOIDED_LOSS,o,s,now,{"original_r":opnl,"shadow_r":spnl,"delta_r":spnl-opnl}))
            elif abs(spnl-opnl)>=self.exit_tolerance_r:out.append(self._make(GapType.OUTCOME_DIVERGENCE,o,s,now,{"original_r":opnl,"shadow_r":spnl,"delta_r":spnl-opnl}))
            oe=self._value(o,"entry_price");se=self._value(s,"entry_price");point=self._f(self._value(o,"point_size"),0)
            if oe is not None and se is not None and point>0:
                delta=abs(self._f(oe)-self._f(se))/point
                if delta>=self.entry_tolerance_points:out.append(self._make(GapType.ENTRY_TIMING,o,s,now,{"entry_gap_points":delta}))
            ox=self._value(o,"exit_reason");sx=self._value(s,"exit_reason")
            if ox and sx and str(ox)!=str(sx):out.append(self._make(GapType.EXIT_MANAGEMENT,o,s,now,{"original_exit":ox,"shadow_exit":sx,"delta_r":spnl-opnl}))
        for i,s in enumerate(shadows):
            if i not in matched and self._f(self._value(s,"realized_r"))>0:
                out.append(self._make(GapType.MISSED_OPPORTUNITY,None,s,now,{"shadow_r":self._f(self._value(s,"realized_r")),"reason":"profitable shadow family had no original trade"}))
        return out

    def _make(self,kind:GapType,o:Any,s:Any,now:str,details:Dict[str,Any])->GapComparison:
        return GapComparison(str(self._value(s,"symbol") if s is not None else self._value(o,"symbol")),kind,now,details,
            str(self._value(o,"trade_id") or self._value(o,"id")) if o is not None else None,
            str(self._value(s,"scenario_id")) if s is not None else None,
            str(self._value(s,"family_id")) if s is not None else None)
