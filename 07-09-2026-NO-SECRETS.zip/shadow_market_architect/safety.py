"""Fail-closed static boundary checks for the removable shadow package."""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Iterable, List

FORBIDDEN_IMPORT_PREFIXES = (
    "MetaTrader5",
    "services.mt5_executor",
    "telegram",
    "database",
)
FORBIDDEN_CALL_ATTRIBUTES = {
    "order_send", "ensure_ticket", "cancel_order", "apply_stop",
    "close_position", "partial_close", "update_trade",
}
FORBIDDEN_TEXT = {
    "TRADE_ACTION_DEAL", "TRADE_ACTION_PENDING", "Mt5DemoExecutor",
}


def python_files(root: str | Path) -> Iterable[Path]:
    return Path(root).rglob("*.py")


def audit_file(path: str | Path) -> List[str]:
    path = Path(path)
    text = path.read_text(encoding="utf-8")
    issues: List[str] = []
    for token in FORBIDDEN_TEXT:
        if token in text:
            issues.append(f"forbidden token {token}")
    tree = ast.parse(text, filename=str(path))
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.startswith(FORBIDDEN_IMPORT_PREFIXES):
                    issues.append(f"forbidden import {alias.name}")
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            if module.startswith(FORBIDDEN_IMPORT_PREFIXES):
                issues.append(f"forbidden import {module}")
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr in FORBIDDEN_CALL_ATTRIBUTES:
                issues.append(f"forbidden call .{node.func.attr}()")
    return sorted(set(issues))


def audit_package(root: str | Path | None = None) -> None:
    root = Path(root) if root else Path(__file__).resolve().parent
    findings = []
    for path in python_files(root):
        if path.resolve() == Path(__file__).resolve():
            continue  # the policy file necessarily names forbidden tokens
        for issue in audit_file(path):
            findings.append(f"{path}: {issue}")
    if findings:
        raise RuntimeError("Shadow safety boundary violated:\n" + "\n".join(findings))
