"""Phase-8 family-aware measurement and human-readable shadow reporting."""
from __future__ import annotations

from collections import Counter,defaultdict
from dataclasses import asdict,dataclass
from datetime import datetime,timezone
from typing import Any,Dict,Iterable,Mapping,Optional

from .models import utc_now


def _v(x:Any,key:str,default:Any=None)->Any:
    return x.get(key,default) if isinstance(x,Mapping) else getattr(x,key,default)
def _f(x:Any,default:float=0.0)->float:
    try:return float(x)
    except (TypeError,ValueError):return default
def _date(x:Any)->str:
    raw=str(_v(x,"closed_at") or _v(x,"opened_at") or "")
    return raw[:10] if len(raw)>=10 else "UNKNOWN"

@dataclass(frozen=True)
class MetricRollup:
    metric_date:str;symbol:str;horizon:str;playbook:str
    family_count:int;win_count:int;loss_count:int;breakeven_count:int
    win_rate:float;total_r:float;expectancy_r:float;profit_factor:Optional[float]
    average_win_r:float;average_loss_r:float;partial_close_rate:float
    sample_quality:str;calculated_at:str
    def to_dict(self)->Dict[str,Any]:return asdict(self)

class ShadowMetrics:
    """Scores only closed positions and only once per scenario family."""
    def __init__(self,config:Mapping[str,Any]|None=None):
        self.config=dict(config or {});self.min_sample=int(self.config.get("min_sample_size",30))
    def calculate(self,positions:Iterable[Any],*,calculated_at:Optional[str]=None)->list[MetricRollup]:
        now=calculated_at or utc_now();best:Dict[tuple[str,str],Any]={}
        for p in positions:
            status=getattr(_v(p,"status"),"value",_v(p,"status"))
            if str(status).upper()!="CLOSED" or not _v(p,"closed_at"):continue
            family=str(_v(p,"family_id") or _v(p,"scenario_id"));key=(_date(p),family)
            old=best.get(key)
            if old is None or str(_v(p,"closed_at"))<str(_v(old,"closed_at")):best[key]=p
        groups=defaultdict(list)
        for p in best.values():
            groups[(_date(p),str(_v(p,"symbol")),str(_v(p,"horizon") or "UNKNOWN"),str(_v(p,"playbook") or "UNKNOWN"))].append(p)
        out=[]
        for key,rows in sorted(groups.items()):
            rs=[_f(_v(x,"realized_r",_v(x,"pnl_r"))) for x in rows];wins=[x for x in rs if x>0];losses=[x for x in rs if x<0];n=len(rs)
            gross_win=sum(wins);gross_loss=abs(sum(losses));pf=(round(gross_win/gross_loss,4) if gross_loss else None)
            partial=sum(1 for x in rows if _f(_v(x,"closed_fraction"))>0 and any(str(e.get("event","")).endswith("PARTIAL") for e in (_v(x,"events",[]) or [])))
            out.append(MetricRollup(*key,n,len(wins),len(losses),n-len(wins)-len(losses),round(len(wins)/n,4),round(sum(rs),6),round(sum(rs)/n,6),pf,round(sum(wins)/len(wins),6) if wins else 0.0,round(sum(losses)/len(losses),6) if losses else 0.0,round(partial/n,4),"ADEQUATE" if n>=self.min_sample else "LOW_SAMPLE",now))
        return out

class ShadowReporter:
    def build(self,metrics:Iterable[MetricRollup],gaps:Iterable[Any],*,generated_at:Optional[str]=None)->Dict[str,Any]:
        metrics=list(metrics);counts=Counter(str(getattr(_v(g,"gap_type"),"value",_v(g,"gap_type"))) for g in gaps)
        return {"generated_at":generated_at or utc_now(),"scope":"SHADOW_ONLY","family_deduplicated":True,"metric_groups":[m.to_dict() for m in metrics],"gap_counts":dict(sorted(counts.items())),"summary":{"closed_families":sum(m.family_count for m in metrics),"total_r":round(sum(m.total_r for m in metrics),6),"low_sample_groups":sum(m.sample_quality=="LOW_SAMPLE" for m in metrics)},"warnings":["Observational shadow results are not evidence of live profitability.","LOW_SAMPLE groups must not be used for calibration decisions."]}
    def markdown(self,report:Mapping[str,Any])->str:
        s=report["summary"];lines=["# Shadow Market Architect — Measurement Report","",f"Generated: {report['generated_at']}","",f"Closed scenario families: **{s['closed_families']}**  ",f"Aggregate R: **{s['total_r']:.3f}**  ",f"Low-sample groups: **{s['low_sample_groups']}**","","## Performance by date / symbol / horizon / playbook","","| Date | Symbol | Horizon | Playbook | Families | Win rate | Expectancy R | Total R | PF | Quality |","|---|---|---|---|---:|---:|---:|---:|---:|---|"]
        for m in report["metric_groups"]:lines.append(f"| {m['metric_date']} | {m['symbol']} | {m['horizon']} | {m['playbook']} | {m['family_count']} | {m['win_rate']:.1%} | {m['expectancy_r']:.3f} | {m['total_r']:.3f} | {m['profit_factor'] if m['profit_factor'] is not None else '∞'} | {m['sample_quality']} |")
        lines += ["","## Gap counts",""]+[f"- {k}: {v}" for k,v in report["gap_counts"].items()]
        lines += ["","## Warnings",""]+[f"- {x}" for x in report["warnings"]]
        return "\n".join(lines)+"\n"
