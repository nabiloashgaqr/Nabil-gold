"""Read-only Shadow Market Architect research package.

This package has no broker execution capability. It writes only to its own
local SQLite ledger and can be removed without changing production trading.
"""
from .models import Horizon, MarketState, ScenarioSide, ScenarioStatus
from .store import ShadowStore

__all__ = ["Horizon", "MarketState", "ScenarioSide", "ScenarioStatus", "ShadowStore"]
