"""Phase-6 broker-inert virtual position management and exit accounting."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, Iterable, Mapping, Optional
from uuid import uuid4

from utils.instruments import point_size, round_price
from utils.trading_rules import distance_ratio, trailing_params

from .entries import VirtualOrder, VirtualOrderStatus, _dt


class VirtualPositionStatus(str, Enum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"


@dataclass
class VirtualPosition:
    order_id: str
    scenario_id: str
    family_id: str
    symbol: str
    side: str
    opened_at: str
    entry_price: float
    initial_stop_loss: float
    stop_loss: float
    tp1: float
    tp2: float
    tp3: float
    status: VirtualPositionStatus = VirtualPositionStatus.OPEN
    remaining_fraction: float = 1.0
    closed_fraction: float = 0.0
    realized_points: float = 0.0
    realized_r: float = 0.0
    tp1_done: bool = False
    tp2_done: bool = False
    tp3_done: bool = False
    protected: bool = False
    best_price: Optional[float] = None
    closed_at: Optional[str] = None
    close_price: Optional[float] = None
    exit_reason: Optional[str] = None
    result: Optional[str] = None
    position_id: str = field(default_factory=lambda: uuid4().hex)
    events: list[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d=asdict(self); d["status"]=self.status.value; return d


class VirtualPositionManager:
    """Tick-driven simulation only; no production execution dependency."""
    def __init__(self, root_config: Mapping[str, Any], config: Mapping[str, Any] | None = None):
        self.root_config=dict(root_config or {}); self.config=dict(config or {})

    def open_from_order(self, order: VirtualOrder, existing: Iterable[VirtualPosition] = ()) -> VirtualPosition:
        if order.status != VirtualOrderStatus.FILLED or not order.filled_at or order.fill_price is None:
            raise ValueError("only a filled virtual order can open a virtual position")
        if None in (order.stop_loss, order.tp1, order.tp2, order.tp3):
            raise ValueError("filled order is missing exit geometry")
        for p in existing:
            if p.status == VirtualPositionStatus.OPEN and p.symbol == order.symbol and p.side == order.side:
                raise ValueError("one live virtual position per symbol and side")
        return VirtualPosition(order.order_id,order.scenario_id,order.family_id,order.symbol,order.side,
            order.filled_at,float(order.fill_price),float(order.stop_loss),float(order.stop_loss),
            float(order.tp1),float(order.tp2),float(order.tp3),best_price=float(order.fill_price))

    def _points(self, p: VirtualPosition, price: float) -> float:
        sign=1.0 if p.side=="BUY" else -1.0
        return sign*(price-p.entry_price)/float(point_size(p.symbol,self.root_config))

    def _event(self,p:VirtualPosition,kind:str,known_at:str,**details:Any)->None:
        p.events.append({"event":kind,"known_at":known_at,**details})

    def _book(self,p:VirtualPosition,price:float,fraction:float,reason:str,known_at:str)->None:
        fraction=min(max(float(fraction),0.0),p.remaining_fraction)
        if fraction<=0:return
        pts=self._points(p,price); risk=abs(p.entry_price-p.initial_stop_loss)/float(point_size(p.symbol,self.root_config))
        p.realized_points += pts*fraction
        p.realized_r += (pts/risk)*fraction if risk>0 else 0.0
        p.remaining_fraction=round(p.remaining_fraction-fraction,10)
        p.closed_fraction=round(p.closed_fraction+fraction,10)
        self._event(p,reason,known_at,price=round_price(price,p.symbol,self.root_config),fraction=fraction,pnl_points=round(pts*fraction,4))

    def _close(self,p:VirtualPosition,price:float,reason:str,known_at:str)->None:
        self._book(p,price,p.remaining_fraction,reason,known_at)
        p.status=VirtualPositionStatus.CLOSED; p.closed_at=known_at
        p.close_price=round_price(price,p.symbol,self.root_config);p.exit_reason=reason
        p.realized_points=round(p.realized_points,4);p.realized_r=round(p.realized_r,6)
        p.result="WIN" if p.realized_points>0 else ("LOSS" if p.realized_points<0 else "BREAKEVEN")

    def on_tick(self,p:VirtualPosition,*,bid:float,ask:float,known_at:str)->list[str]:
        if p.status != VirtualPositionStatus.OPEN or p.closed_at is not None:return []
        if _dt(known_at)<_dt(p.opened_at) or bid<=0 or ask<=0 or ask<bid:return []
        before=len(p.events); executable=bid if p.side=="BUY" else ask
        # Existing protection is tested before this tick can ratchet it.
        stop_hit=executable<=p.stop_loss if p.side=="BUY" else executable>=p.stop_loss
        if stop_hit:
            self._close(p,executable,"STOP_LOSS",known_at)
            return [e["event"] for e in p.events[before:]]
        favorable=lambda level: executable>=level if p.side=="BUY" else executable<=level
        fractions=self.config.get("scale_out_fractions",{}) or {}
        f1=float(fractions.get("tp1",0.5));f2=float(fractions.get("tp2",0.25))
        if not p.tp1_done and favorable(p.tp1):
            self._book(p,p.tp1,min(f1,p.remaining_fraction),"TP1_PARTIAL",known_at);p.tp1_done=True
        if not p.tp2_done and favorable(p.tp2):
            self._book(p,p.tp2,min(f2,p.remaining_fraction),"TP2_PARTIAL",known_at);p.tp2_done=True
        if not p.tp3_done and favorable(p.tp3):
            p.tp3_done=True;self._close(p,p.tp3,"TP3_FINAL",known_at)
            return [e["event"] for e in p.events[before:]]
        pv=float(point_size(p.symbol,self.root_config));ratio=float(distance_ratio(self.root_config,p.symbol))
        if p.tp1_done:
            lock=float(self.config.get("gold_be_lock_points",40))*ratio
            be=p.entry_price+(lock*pv if p.side=="BUY" else -lock*pv)
            better=be>p.stop_loss if p.side=="BUY" else be<p.stop_loss
            if better:
                p.stop_loss=round_price(be,p.symbol,self.root_config);p.protected=True
                self._event(p,"STOP_TO_PROFIT",known_at,stop_loss=p.stop_loss,locked_points=lock)
        p.best_price=(max(float(p.best_price),executable) if p.side=="BUY" else min(float(p.best_price),executable))
        trail=trailing_params(self.root_config,symbol=p.symbol)
        if p.protected and bool(trail.get("enabled")):
            gap=float(trail["distance_points"])*pv;step=float(trail["step_points"])*pv
            candidate=p.best_price-gap if p.side=="BUY" else p.best_price+gap
            improves=(candidate-p.stop_loss)>=step if p.side=="BUY" else (p.stop_loss-candidate)>=step
            if improves:
                p.stop_loss=round_price(candidate,p.symbol,self.root_config)
                self._event(p,"TRAILING_STOP_MOVED",known_at,stop_loss=p.stop_loss)
        return [e["event"] for e in p.events[before:]]
