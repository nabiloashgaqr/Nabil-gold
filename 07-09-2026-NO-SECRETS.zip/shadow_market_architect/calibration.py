"""Phase-9 conservative calibration recommendations and final gap-closure report.

This module never mutates live or shadow trading parameters. It emits bounded,
auditable research recommendations only after minimum evidence requirements pass.
"""
from __future__ import annotations

import hashlib
from collections import Counter,defaultdict
from dataclasses import asdict,dataclass,field
from enum import Enum
from typing import Any,Dict,Iterable,Mapping,Optional

from .models import utc_now

class CalibrationAction(str,Enum):
    INSUFFICIENT_DATA="INSUFFICIENT_DATA"
    KEEP="KEEP"
    REVIEW="REVIEW"

@dataclass(frozen=True)
class CalibrationRecommendation:
    symbol:str;horizon:str;playbook:str;action:CalibrationAction
    family_count:int;trading_days:int;expectancy_r:float;win_rate:float
    reasons:list[str];bounded_changes:Dict[str,Any]=field(default_factory=dict)
    def to_dict(self)->Dict[str,Any]:
        d=asdict(self);d["action"]=self.action.value;return d

@dataclass(frozen=True)
class CalibrationRun:
    run_id:str;generated_at:str;recommendations:list[CalibrationRecommendation]
    gap_priorities:list[Dict[str,Any]];ready_groups:int;insufficient_groups:int
    safeguards:list[str]
    def to_dict(self)->Dict[str,Any]:
        d=asdict(self);d["recommendations"]=[x.to_dict() for x in self.recommendations];return d

class ShadowCalibrator:
    def __init__(self,config:Mapping[str,Any]|None=None):
        self.config=dict(config or {});self.min_families=int(self.config.get("min_families",30));self.min_days=int(self.config.get("min_trading_days",10));self.negative=float(self.config.get("review_below_expectancy_r",-0.10));self.max_adjust=float(self.config.get("max_adjustment_percent",10))
    def calibrate(self,metrics:Iterable[Any],gaps:Iterable[Any],*,generated_at:Optional[str]=None)->CalibrationRun:
        generated_at=generated_at or utc_now();groups=defaultdict(list)
        for m in metrics:
            get=lambda k,d=None:m.get(k,d) if isinstance(m,Mapping) else getattr(m,k,d)
            groups[(str(get("symbol")),str(get("horizon")),str(get("playbook")))].append(m)
        recs=[]
        for key,rows in sorted(groups.items()):
            def val(x,k,d=0):
                try:return float(x.get(k,d) if isinstance(x,Mapping) else getattr(x,k,d))
                except (TypeError,ValueError):return float(d)
            n=sum(int(val(x,"family_count")) for x in rows);days=len({str(x.get("metric_date") if isinstance(x,Mapping) else x.metric_date) for x in rows});total=sum(val(x,"total_r") for x in rows);wins=sum(int(val(x,"win_count")) for x in rows);exp=total/n if n else 0;wr=wins/n if n else 0
            reasons=[];changes={}
            if n<self.min_families or days<self.min_days:
                action=CalibrationAction.INSUFFICIENT_DATA;reasons.append(f"requires at least {self.min_families} closed families across {self.min_days} trading days")
            elif exp<self.negative:
                action=CalibrationAction.REVIEW;reasons.append("out-of-sample shadow expectancy is below the review floor");changes={"status":"RESEARCH_REVIEW_ONLY","maximum_single_parameter_adjustment_percent":self.max_adjust,"automatic_deployment":False}
            else:
                action=CalibrationAction.KEEP;reasons.append("minimum evidence passed without breaching the negative-expectancy floor")
            recs.append(CalibrationRecommendation(*key,action,n,days,round(exp,6),round(wr,4),reasons,changes))
        counts=Counter()
        for g in gaps:
            x=g.get("gap_type") if isinstance(g,Mapping) else getattr(g,"gap_type","");counts[str(getattr(x,"value",x))]+=1
        priorities=[{"gap_type":k,"count":v,"priority":"HIGH" if v>=max(3,sum(counts.values())*.25) else "MONITOR"} for k,v in counts.most_common()]
        digest=hashlib.sha256((generated_at+repr([(r.symbol,r.horizon,r.playbook,r.action.value,r.family_count) for r in recs])).encode()).hexdigest()[:32]
        ready=sum(r.action!=CalibrationAction.INSUFFICIENT_DATA for r in recs)
        return CalibrationRun(digest,generated_at,recs,priorities,ready,len(recs)-ready,["No recommendation is applied automatically.","Production configuration and broker execution remain outside the shadow boundary.","Family deduplication and minimum sample/day gates are mandatory.","Review recommendations permit only bounded one-parameter-at-a-time research changes.","A fresh forward shadow sample is required after every accepted research change."])

class FinalReport:
    def markdown(self,run:CalibrationRun,measurement:Mapping[str,Any])->str:
        lines=["# Shadow Market Architect — Final Gap-Closure & Calibration Report","",f"Run ID: `{run.run_id}`  ",f"Generated: {run.generated_at}","", "## Executive status","",f"- Closed scenario families measured: {measurement.get('summary',{}).get('closed_families',0)}",f"- Calibration-ready groups: {run.ready_groups}",f"- Insufficient-data groups: {run.insufficient_groups}","- Deployment mode: **SHADOW ONLY — NO AUTOMATIC CHANGES**","","## Calibration recommendations","","| Symbol | Horizon | Playbook | Families | Days | Expectancy R | Win rate | Action |","|---|---|---|---:|---:|---:|---:|---|"]
        for r in run.recommendations:lines.append(f"| {r.symbol} | {r.horizon} | {r.playbook} | {r.family_count} | {r.trading_days} | {r.expectancy_r:.3f} | {r.win_rate:.1%} | {r.action.value} |")
        lines += ["","## Gap-closure priorities",""]+[f"- {x['gap_type']}: {x['count']} ({x['priority']})" for x in run.gap_priorities]
        lines += ["","## Mandatory safeguards",""]+[f"- {x}" for x in run.safeguards]
        lines += ["","## Interpretation", "", "This report closes the implementation gap, not the statistical evidence gap. Groups marked INSUFFICIENT_DATA must continue collecting forward shadow observations before any calibration decision."]
        return "\n".join(lines)+"\n"
