"""Phase-3 transparent multi-horizon market-state classifier.

The engine is deterministic, price-only and shadow-only. It classifies each
symbol independently from bars already captured by EvidenceAdapter. It never
calls a broker, an agent, or a production database.
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field
from statistics import median
from typing import Any, Dict, Iterable, List, Mapping, Sequence
from uuid import uuid4

from .models import Horizon, MarketState, utc_now


TF_ALIASES = {
    "M1": ("M1", "1M", "1m", "m1", "1min"),
    "M5": ("M5", "5M", "5m", "m5", "5min"),
    "M15": ("M15", "15M", "15m", "m15", "15min"),
    "H1": ("H1", "1H", "1h", "h1", "60m"),
    "H4": ("H4", "4H", "4h", "h4", "240m"),
}
HORIZON_TFS = {
    Horizon.SCALP: ("M1", "M5"),
    Horizon.INTRADAY: ("M5", "M15", "H1"),
    Horizon.STRUCTURAL: ("H1", "H4"),
}


def _f(value: Any) -> float:
    try:
        x = float(value)
        return x if math.isfinite(x) else 0.0
    except (TypeError, ValueError):
        return 0.0


def _bars_from(value: Any) -> List[Dict[str, float]]:
    if isinstance(value, dict):
        value = value.get("data") or value.get("candles") or value.get("bars") or []
    if not isinstance(value, list):
        return []
    out = []
    for row in value:
        if not isinstance(row, dict):
            continue
        o, h, low, c = (_f(row.get(k)) for k in ("open", "high", "low", "close"))
        if min(o, h, low, c) <= 0 or h < low:
            continue
        out.append({"open": o, "high": h, "low": low, "close": c,
                    "time": row.get("time") or row.get("timestamp")})
    return out


def extract_timeframes(market: Mapping[str, Any]) -> Dict[str, List[Dict[str, float]]]:
    """Normalize common shared-snapshot shapes without mutating the source."""
    candidates = []
    for obj in (market, market.get("shared_market_data") or {}):
        if isinstance(obj, Mapping):
            candidates.append(obj.get("timeframes") or {})
    result: Dict[str, List[Dict[str, float]]] = {}
    for canonical, aliases in TF_ALIASES.items():
        for source in candidates:
            if not isinstance(source, Mapping):
                continue
            for key in aliases:
                if key in source:
                    bars = _bars_from(source[key])
                    if len(bars) > len(result.get(canonical, [])):
                        result[canonical] = bars
    return result


def _ema(values: Sequence[float], period: int) -> float:
    if not values:
        return 0.0
    alpha = 2.0 / (period + 1.0)
    value = values[0]
    for item in values[1:]:
        value = alpha * item + (1 - alpha) * value
    return value


def _metrics(bars: Sequence[Mapping[str, Any]], lookback: int = 24) -> Dict[str, float]:
    window = list(bars[-max(8, lookback):])
    closes = [_f(x.get("close")) for x in window]
    highs = [_f(x.get("high")) for x in window]
    lows = [_f(x.get("low")) for x in window]
    trs = [max(h-l, abs(h-closes[i-1]), abs(l-closes[i-1]))
           for i, (h, l) in enumerate(zip(highs, lows)) if i > 0]
    path = sum(abs(closes[i]-closes[i-1]) for i in range(1, len(closes)))
    net = closes[-1]-closes[0]
    efficiency = abs(net)/path if path > 0 else 0.0
    half = max(3, len(trs)//2)
    old_atr = sum(trs[:-half])/max(1, len(trs[:-half])) if trs[:-half] else median(trs or [0])
    recent_atr = sum(trs[-half:])/max(1, len(trs[-half:])) if trs else 0.0
    atr_ratio = recent_atr/old_atr if old_atr > 0 else 1.0
    fast = _ema(closes, min(5, len(closes)))
    slow = _ema(closes, min(13, len(closes)))
    slope_n = min(5, len(closes)-1)
    recent_net = closes[-1]-closes[-1-slope_n] if slope_n > 0 else 0.0
    recent_path = sum(abs(closes[i]-closes[i-1]) for i in range(len(closes)-slope_n, len(closes)))
    recent_eff = abs(recent_net)/recent_path if recent_path > 0 else 0.0
    latest_tr = trs[-1] if trs else 0.0
    baseline_tr = median(trs[:-1] or trs or [0.0])
    return {
        "bars": float(len(window)), "net": net, "efficiency": efficiency,
        "recent_efficiency": recent_eff, "atr": recent_atr,
        "atr_ratio": atr_ratio, "latest_tr_ratio": latest_tr/baseline_tr if baseline_tr > 0 else 1.0,
        "ema_fast": fast, "ema_slow": slow,
        "ema_spread_atr": (fast-slow)/recent_atr if recent_atr > 0 else 0.0,
        "recent_net_atr": recent_net/recent_atr if recent_atr > 0 else 0.0,
    }


@dataclass(frozen=True)
class MarketStateSnapshot:
    symbol: str
    horizon: Horizon
    state: MarketState
    direction: str
    strength: float
    known_at: str
    source_timeframe: str | None
    features: Dict[str, Any]
    reasons: List[str] = field(default_factory=list)
    state_id: str = field(default_factory=lambda: uuid4().hex)
    recorded_at: str = field(default_factory=utc_now)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self); d["horizon"] = self.horizon.value; d["state"] = self.state.value
        return d


class MarketStateEngine:
    def __init__(self, config: Mapping[str, Any] | None = None):
        self.config = dict(config or {})
        self.min_bars = int(self.config.get("min_closed_bars", 20))
        self.lookback = int(self.config.get("lookback_bars", 24))
        self.drop_live = bool(self.config.get("drop_live_bar", True))

    def _classify(self, metrics: Mapping[str, float]) -> tuple[MarketState, str, float, List[str]]:
        eff = metrics["efficiency"]; recent = metrics["recent_efficiency"]
        atr_ratio = metrics["atr_ratio"]; shock = metrics["latest_tr_ratio"]
        spread = metrics["ema_spread_atr"]; recent_net = metrics["recent_net_atr"]
        direction = "BUY" if spread > 0.12 and recent_net > 0 else "SELL" if spread < -0.12 and recent_net < 0 else "NEUTRAL"
        reasons = [f"efficiency={eff:.2f}", f"recent_efficiency={recent:.2f}",
                   f"atr_ratio={atr_ratio:.2f}", f"latest_tr_ratio={shock:.2f}",
                   f"ema_spread_atr={spread:.2f}"]
        if shock >= float(self.config.get("shock_tr_multiple", 3.0)):
            return MarketState.SHOCK_NEWS, direction, min(100.0, 55+10*(shock-3)), reasons
        if atr_ratio <= float(self.config.get("compression_atr_ratio", 0.68)):
            return MarketState.COMPRESSION, direction, min(100.0, 60+40*(0.68-atr_ratio)), reasons
        if atr_ratio >= float(self.config.get("expansion_atr_ratio", 1.45)) and recent >= 0.42:
            return MarketState.EXPANSION, direction, min(100.0, 55+35*recent), reasons
        if eff >= 0.42 and direction != "NEUTRAL":
            if recent < 0.24 and eff-recent >= 0.25:
                return MarketState.EXHAUSTION, direction, min(100.0, 55+50*(eff-recent)), reasons
            return MarketState.TREND_CONTINUATION, direction, min(100.0, 50+55*eff), reasons
        if eff <= 0.24 and recent <= 0.35:
            return MarketState.RANGE_ROTATION, "NEUTRAL", min(100.0, 60+40*(0.24-eff)), reasons
        slow_sign = 1 if spread > 0 else -1 if spread < 0 else 0
        fast_sign = 1 if recent_net > 0 else -1 if recent_net < 0 else 0
        if slow_sign and fast_sign and slow_sign != fast_sign:
            return MarketState.TRANSITION, "NEUTRAL", 65.0, reasons
        return MarketState.UNCERTAIN, direction, 45.0, reasons

    def classify(self, symbol: str, market: Mapping[str, Any], known_at: str) -> List[MarketStateSnapshot]:
        frames = extract_timeframes(market)
        output = []
        for horizon, preferences in HORIZON_TFS.items():
            tf = next((name for name in preferences if len(frames.get(name, [])) >= self.min_bars + int(self.drop_live)), None)
            if tf is None:
                output.append(MarketStateSnapshot(symbol, horizon, MarketState.UNCERTAIN,
                    "NEUTRAL", 0.0, known_at, None,
                    {"available_timeframes": sorted(frames)}, ["insufficient closed bars"]))
                continue
            bars = frames[tf][:-1] if self.drop_live else frames[tf]
            metrics = _metrics(bars, self.lookback)
            state, direction, strength, reasons = self._classify(metrics)
            output.append(MarketStateSnapshot(symbol, horizon, state, direction,
                                               round(strength, 1), known_at, tf,
                                               dict(metrics), reasons))
        return output
