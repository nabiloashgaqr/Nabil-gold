"""Read-only live-ledger comparison for the consolidated daily Telegram report."""
from __future__ import annotations
from pathlib import Path
from typing import Any,Dict,Iterable,Mapping

from utils.instruments import point_size
from .gaps import GapIntelligence
from .reporting import ShadowMetrics,ShadowReporter
from .store import ShadowStore,DEFAULT_PATH


def _live_row(row:Mapping[str,Any],root_config:Mapping[str,Any])->Dict[str,Any]:
    symbol=str(row.get("symbol") or "XAU/USD");side=str(row.get("side") or row.get("type") or row.get("trade_type") or "").upper()
    pv=point_size(symbol,dict(root_config));entry=float(row.get("entry_price") or 0);initial=float(row.get("initial_stop_loss") or row.get("stop_loss") or 0)
    risk_points=abs(entry-initial)/pv if entry and initial and pv else 0
    pnl_points=float(row.get("final_pnl_points",row.get("pnl_points",row.get("final_pnl",0))) or 0)
    raw_r=row.get("pnl_r",row.get("final_pnl_r"));pnl_r=float(raw_r) if raw_r not in (None,"") else (pnl_points/risk_points if risk_points else 0.0)
    return {"trade_id":str(row.get("id") or row.get("trade_id") or ""),"symbol":symbol,"side":side,
        "opened_at":row.get("opened_at") or row.get("entry_time") or row.get("created_at"),
        "closed_at":row.get("closed_at") or row.get("close_time"),"entry_price":row.get("entry_price"),
        "point_size":pv,"pnl_r":pnl_r,"exit_reason":row.get("exit_reason") or row.get("status")}


def build_daily_shadow_comparison(config:Mapping[str,Any],live_closed:Iterable[Mapping[str,Any]],report_date:str,root:Path)->tuple[list[str],Path|None]:
    """Compare today's live closes with today's closed shadow families.

    DatabaseService remains the sole live source. This function receives rows
    already read by the daily report and writes only to the isolated shadow DB.
    """
    cfg=dict((config.get("shadow_market_architect") or {}));daily=dict(cfg.get("daily_comparison") or {})
    if not bool(daily.get("enabled",False)):return [],None
    store=ShadowStore(cfg.get("storage_path") or DEFAULT_PATH);store.initialize()
    shadows=[p for p in store.virtual_positions() if str(p.get("closed_at") or "").startswith(report_date)]
    live=[_live_row(x,config) for x in live_closed]
    gaps=GapIntelligence(cfg.get("gap_intelligence") or {}).compare(live,shadows)
    for gap in gaps:store.append_gap_comparison(gap)
    metrics=ShadowMetrics(cfg.get("reporting") or {}).calculate(shadows)
    for metric in metrics:store.upsert_daily_metric(metric)
    report=ShadowReporter().build(metrics,gaps)
    output_dir=Path(daily.get("report_directory","storage/shadow_daily_reports"));output_dir=output_dir if output_dir.is_absolute() else root/output_dir
    output_dir.mkdir(parents=True,exist_ok=True);path=output_dir/f"shadow_comparison_{report_date}.md";path.write_text(ShadowReporter().markdown(report),encoding="utf-8")
    summary=report["summary"];counts=report["gap_counts"]
    lines=["🌑 <b>Live vs Shadow</b>",f"• Live closed: {len(live)} | Shadow families: {summary['closed_families']}",f"• Shadow total: {summary['total_r']:+.2f}R | Low-sample groups: {summary['low_sample_groups']}"]
    if counts:
        labels={"MISSED_OPPORTUNITY":"missed","AVOIDED_LOSS":"avoided loss","DIRECTION_DISAGREEMENT":"direction","ENTRY_TIMING":"entry","EXIT_MANAGEMENT":"exit","OUTCOME_DIVERGENCE":"outcome","ORIGINAL_ONLY":"live only"}
        lines.append("• Gaps: "+" · ".join(f"{labels.get(k,k)} {v}" for k,v in sorted(counts.items())))
    else:lines.append("• Gaps: none recorded today")
    lines.append(f"• Detailed report: {path.name}")
    return lines,path
