PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS shadow_metadata (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS shadow_scenario_snapshots (
    snapshot_id INTEGER PRIMARY KEY AUTOINCREMENT,
    scenario_id TEXT NOT NULL,
    family_id TEXT,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL CHECK(side IN ('BUY','SELL')),
    horizon TEXT NOT NULL CHECK(horizon IN ('SCALP','INTRADAY','STRUCTURAL')),
    playbook TEXT NOT NULL,
    status TEXT NOT NULL,
    known_at TEXT NOT NULL,
    recorded_at TEXT NOT NULL,
    config_version TEXT NOT NULL,
    entry_low REAL,
    entry_high REAL,
    preferred_entry REAL,
    invalidation REAL,
    tp1 REAL,
    tp2 REAL,
    tp3 REAL,
    expiry_at TEXT,
    evidence_json TEXT NOT NULL,
    UNIQUE(scenario_id, known_at, status)
);

CREATE TABLE IF NOT EXISTS shadow_events (
    event_id TEXT PRIMARY KEY,
    scenario_id TEXT,
    event_type TEXT NOT NULL,
    symbol TEXT NOT NULL,
    known_at TEXT NOT NULL,
    recorded_at TEXT NOT NULL,
    payload_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS shadow_virtual_orders (
    order_id TEXT PRIMARY KEY,
    scenario_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL CHECK(side IN ('BUY','SELL')),
    order_type TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    payload_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS shadow_virtual_trades (
    trade_id TEXT PRIMARY KEY,
    scenario_id TEXT NOT NULL,
    family_id TEXT NOT NULL,
    order_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL CHECK(side IN ('BUY','SELL')),
    status TEXT NOT NULL CHECK(status IN ('OPEN','CLOSED')),
    opened_at TEXT NOT NULL,
    closed_at TEXT,
    entry_price REAL,
    close_price REAL,
    pnl_points REAL,
    pnl_r REAL,
    payload_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS shadow_daily_metrics (
    metric_date TEXT NOT NULL,
    symbol TEXT NOT NULL,
    horizon TEXT NOT NULL,
    playbook TEXT NOT NULL,
    metrics_json TEXT NOT NULL,
    calculated_at TEXT NOT NULL,
    PRIMARY KEY(metric_date, symbol, horizon, playbook)
);

CREATE TABLE IF NOT EXISTS shadow_gap_comparisons (
    comparison_id TEXT PRIMARY KEY,
    original_trade_id TEXT,
    scenario_id TEXT,
    family_id TEXT,
    symbol TEXT NOT NULL,
    gap_type TEXT NOT NULL,
    compared_at TEXT NOT NULL,
    details_json TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS ix_shadow_scenarios_symbol_time
ON shadow_scenario_snapshots(symbol, known_at);
CREATE INDEX IF NOT EXISTS ix_shadow_events_scenario_time
ON shadow_events(scenario_id, known_at);

CREATE TABLE IF NOT EXISTS shadow_evidence_snapshots (
    evidence_id TEXT PRIMARY KEY,
    symbol TEXT NOT NULL,
    known_at TEXT NOT NULL,
    recorded_at TEXT NOT NULL,
    source_times_json TEXT NOT NULL,
    market_json TEXT NOT NULL,
    agents_json TEXT NOT NULL,
    auction_json TEXT NOT NULL,
    original_context_json TEXT NOT NULL,
    warnings_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_shadow_evidence_symbol_time
ON shadow_evidence_snapshots(symbol, known_at);

CREATE TABLE IF NOT EXISTS shadow_market_state_snapshots (
    state_id TEXT PRIMARY KEY,
    symbol TEXT NOT NULL,
    horizon TEXT NOT NULL,
    state TEXT NOT NULL,
    direction TEXT NOT NULL,
    strength REAL NOT NULL,
    known_at TEXT NOT NULL,
    recorded_at TEXT NOT NULL,
    source_timeframe TEXT,
    features_json TEXT NOT NULL,
    reasons_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_shadow_market_state_symbol_time
ON shadow_market_state_snapshots(symbol, horizon, known_at);

CREATE TABLE IF NOT EXISTS shadow_entry_plans (
    plan_id TEXT PRIMARY KEY,
    scenario_id TEXT NOT NULL,
    family_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    method TEXT NOT NULL,
    decision TEXT NOT NULL,
    known_at TEXT NOT NULL,
    plan_json TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_shadow_live_trade_side
ON shadow_virtual_trades(symbol, side) WHERE status='OPEN';

CREATE TABLE IF NOT EXISTS shadow_calibration_runs (
    run_id TEXT PRIMARY KEY,
    generated_at TEXT NOT NULL,
    payload_json TEXT NOT NULL
);
