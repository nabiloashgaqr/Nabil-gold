# تسليم Nabil Gold — Snapshot R4.9

**تاريخ البناء:** 2026-09-03 UTC  
**نوع الحزمة:** سناب شوت إنتاجي كامل ونظيف، وليس Patch.

## أهم القوانين النهائية

- XAU/USD = الأساس ×1.0.
- WTI/USD = الذهب ×0.5.
- FX = الذهب ×1.5.
- Forex stop band: 405–600 points.
- Forex trailing: distance 225 / step 60 points.
- Forex early BE: 225 points.
- Forex protected-profit lock: 60 points.
- حجم اللوت ديناميكي تلقائياً من مبلغ المخاطرة ومسافة الدخول إلى الستوب الفعلية؛ لا يوجد لوت ثابت.
- Path 4 Auction Flow = 65.
- Path 5 net/auction = 65/65.
- Planner min_primary_quality_score = 65.
- Telegram ينشر الخرائط الجاهزة للتنفيذ فقط، وبعد execution admission وfinal validation.
- WATCH / monitoring / agent-watch / armed-map delivery معطلة.
- Pre-Arm OTE لم يتم تغييره.

## إصلاحات إدارة الصفقات

- دقة Trailing حسب الرمز: FX خمس منازل، JPY ثلاث، والذهب/النفط حسب تعريف الرمز.
- منع رجوع الستوب للخلف على BUY وSELL.
- Trailing الذي يعبر الدخول يلتزم بحد ربح BE الرسمي، ولا يترك حماية رمزية بنقطة واحدة.
- ترقية الصفقات الحية القديمة من حماية رمزية إلى protected-profit lock بعد تأكيد MT5.
- الإغلاق الجزئي عند TP1 لا يُسجل إلا بعد تنفيذ MT5، مع closed_fraction وrealized_pnl_points وtp1_partial_price.
- تصحيح Zombie rows: لا حالة حية مع closed_at.
- تصنيف النتيجة يعتمد على إشارة الربح بصورة متناظرة.
- منع flood لسجل refused backward stop مع إبقاء الحارس فعالاً.

## ملفات الأسرار والبيانات الحية

الحزمة لا تحتوي `.env` أو مفاتيح API أو سجلات/دفتر صفقات السيرفر الحي. احتفظ بملف `.env` الحالي و`storage/trades.json` الحالي عند التحديث فوق سيرفر قائم. يوجد `.env.template` فقط.

## تثبيت جديد

1. فك الحزمة إلى `C:\Nabil-gold`.
2. أنشئ `.env` من `.env.template` وأدخل المفاتيح محلياً.
3. ثبّت dependencies حسب ملفات المشروع.
4. طبّق إعداد مهام Windows بواسطة `SET_BACKGROUND_TASKS_R4_2.ps1` بعد إنشاء المهام الأصلية.

## تحديث سيرفر قائم

1. أوقف مهام Analysis / DemoLoop / TickManager.
2. خذ نسخة احتياطية من المجلد وخصوصاً `.env` و`storage`.
3. انسخ ملفات السناب شوت فوق الكود، لكن لا تستبدل `.env` ولا بيانات `storage` الحية.
4. إذا لم يُطبق قانون FX ×1.5 بعد، شغّل:
   `python APPLY_FX_RATIO_1_5_R4_7.py`
5. شغّل المهام مجدداً.
6. تحقق بواسطة:
   `python scripts\system_healthcheck.py`

## تحقق سريع

```powershell
python -c "import json; from utils.instruments import config_for_instrument; from utils.trading_rules import trailing_params,stop_rule,protection_params; c=json.load(open('config.json',encoding='utf-8-sig')); [print(s,trailing_params(config_for_instrument(c,{'symbol':s})),stop_rule(config_for_instrument(c,{'symbol':s})),protection_params(config_for_instrument(c,{'symbol':s}),s)) for s in ('EUR/USD','GBP/USD','USD/CAD','USD/JPY')]"
python scripts\system_healthcheck.py
```

القيم المتوقعة للفوركس: trailing 225/60، early BE 225، stop 300+105 وحتى 600، وBE lock 60.
