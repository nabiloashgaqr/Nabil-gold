# -*- coding: utf-8 -*-
"""
APPLY_R25_9_HARDENING.py — تطبيق إصلاحات ما بعد التشخيص (2026-08-31).

يضع الملفات المعدّلة في أماكنها الصحيحة داخل C:\\Nabil-gold بعد أخذ نسخة
احتياطية من كل ملف سيُستبدل. لا يمسّ الإعدادات ولا أي مفتاح تبديل.

الإصلاحات (كلها ميكانيكية/دفاعية، لا تغيّر استراتيجية القبول):
  1) services/auction_flow_store.py
       بوابة سعر عند الكتابة: أي تيك سعره خارج النطاق المعقول للرمز يُرفض
       (يمنع هبوط تيك رمز آخر في متجر مزاد رمز مختلف — حادثة FOREIGN_FEED).
  2) scripts/run_tick_manager.py
       يمرّر النطاق السعري لكل متجر (ذهب + المتاجر الفرعية الخمسة).
  3) services/database.py
       - ضمان حفظ execution_path_id دائمًا (fallback من اللقطات المتداخلة).
       - ربط ذاكرة التأمل: عند إغلاق صفقة بخسارة يُسجَّل "حرق" في
         reflection_memory فيتعلّم الفيتو الزمني فعلًا (كانت الدالة موجودة
         بلا مُستدعٍ).
  4) tests/test_r25_9_diagnostics_fixes.py  (اختبارات جديدة).
  5) DIAGNOSE_ALL.py  (الفاحص v2 — قراءة فقط).

التشغيل:
    python APPLY_R25_9_HARDENING.py            # معاينة جافة (لا يكتب)
    python APPLY_R25_9_HARDENING.py --apply     # التطبيق الفعلي مع نسخ احتياطي

بعد التطبيق:
    python -m pytest tests/test_r25_9_diagnostics_fixes.py -q
ثم أعد تشغيل خدمة المُجمِّع (run_tick_manager) ليُبنى المتجر بالبوابة الجديدة.
"""
from __future__ import annotations

import argparse
import shutil
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent

NEW_FILES = [
    "tests/test_r25_9_diagnostics_fixes.py",
    "DIAGNOSE_ALL.py",
]

EDITED_FILES = [
    "services/auction_flow_store.py",
    "scripts/run_tick_manager.py",
    "services/database.py",
]

ALL_FILES = NEW_FILES + EDITED_FILES


def main() -> int:
    parser = argparse.ArgumentParser(description="R25.9 hardening applier")
    parser.add_argument("--apply", action="store_true",
                        help="apply for real (default = dry-run)")
    args = parser.parse_args()

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = ROOT / "backup" / f"r25_9_{stamp}"
    src_pkg = ROOT  # files sit next to this applier (the zip extracts over root)

    print("=" * 70)
    print("R25.9 — تطبيق إصلاحات ما بعد التشخيص")
    print("=" * 70)
    print(f"الجذر: {ROOT}")
    print(f"الوضع: {'تطبيق فعلي' if args.apply else 'معاينة جافة (لم يُكتب أي شيء)'}")
    print()

    missing = []
    copied = 0
    for rel in ALL_FILES:
        src = src_pkg / rel
        dst = ROOT / rel
        if not src.exists():
            missing.append(rel)
            print(f"  [MISSING] {rel} — الملف غير موجود في الحزمة")
            continue
        existed = dst.exists()
        action = "جديد" if not existed else "استبدال"
        if args.apply:
            dst.parent.mkdir(parents=True, exist_ok=True)
            same_file = src.resolve() == dst.resolve()
            if not same_file:
                if existed:
                    backup_dir.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dst, backup_dir / Path(rel).name)
                shutil.copy2(src, dst)
            copied += 1
        print(f"  [{action:6s}] {rel}" + ("  (في مكانه بالفعل)" if args.apply and src.resolve() == dst.resolve() else ""))

    print()
    if missing:
        print(f"⚠️  {len(missing)} ملف ناقص في الحزمة: {missing}")
    if args.apply:
        print(f"✅ تم نسخ {copied} ملف. النسخ الاحتياطي: {backup_dir}")
        print("   الخطوات التالية:")
        print("   1) python -m pytest tests/test_r25_9_diagnostics_fixes.py -q")
        print("   2) أعد تشغيل خدمة المُجمِّع (run_tick_manager).")
    else:
        print("هذه معاينة جافة. للتطبيق الفعلي شغّل:  python APPLY_R25_9_HARDENING.py --apply")
    return 1 if missing else 0


if __name__ == "__main__":
    sys.exit(main())
