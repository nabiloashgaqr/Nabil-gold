"""Mitigation-aware SMC POI return probability v2."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from agents.smc_agent import SMCAgent


ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def _candles(start: float, step: float, count: int = 30) -> list[dict]:
    out = []
    for index in range(count):
        price = start + step * index
        out.append({
            "open": price - .2, "high": price + 3.0, "low": price - 3.0,
            "close": price, "volume": 100,
        })
    return out


def _manual_case(poi: dict | None = None, candles: list[dict] | None = None) -> dict:
    agent = SMCAgent(CONFIG)
    base = poi or {
        "zone": {"top": 4404.71, "bottom": 4397.68},
        "mitigation_status": "FRESH",
        "strength": "strong",
        "displacement_score": 24.5,
    }
    intermediate = {"zone": {"top": 4385.0, "bottom": 4380.0}}
    return agent._return_probability_assessment(
        poi=base,
        direction="SELL",
        current_price=4369.385,
        atr=6.0,
        market_structure={"trend": "BEARISH", "structure_quality": "STRONG"},
        liquidity={"session_liquidity": {"label": "London / Europe Midday"}},
        all_candidates=[base, intermediate],
        candles=candles or _candles(4395.0, .3),
    )


def test_operator_manual_case_no_longer_collapses_to_seven_percent() -> None:
    result = _manual_case()
    assert result["model"] == "mitigation_revisit_v2"
    assert result["distance_atr"] == pytest.approx(5.3017, abs=.001)
    assert result["score"] >= 60.0
    assert result["score"] > 42.0
    assert result["components"]["distance_reachability"] > 0.0


def test_weights_match_operator_approved_formula_and_sum_to_one() -> None:
    result = _manual_case()
    assert result["weights"] == {
        "distance_reachability": .35,
        "displacement_retracement": .20,
        "poi_freshness_quality": .15,
        "session_volatility": .10,
        "value_return_context": .10,
        "intermediate_path": .10,
    }
    assert sum(result["weights"].values()) == pytest.approx(1.0)
    recomputed = sum(
        result["components"][name] * weight
        for name, weight in result["weights"].items()
    )
    assert result["score"] == pytest.approx(recomputed, abs=.11)


def test_fresh_strong_displacement_scores_above_mitigated_weak_poi() -> None:
    strong = _manual_case()
    weak_poi = {
        "zone": {"top": 4404.71, "bottom": 4397.68},
        "mitigation_status": "MITIGATED",
        "strength": "weak",
        "displacement_score": 2.0,
    }
    weak = _manual_case(weak_poi)
    assert strong["score"] > weak["score"] + 20.0


def test_value_reference_alignment_rewards_mean_reversion_path() -> None:
    aligned = _manual_case(candles=_candles(4395.0, .3))
    # Value below current price is opposite a SELL POI above current.
    misaligned = _manual_case(candles=_candles(4340.0, -.1))
    assert aligned["value_path_aligned"] is True
    assert misaligned["value_path_aligned"] is False
    assert aligned["components"]["value_return_context"] > misaligned["components"]["value_return_context"]
    assert aligned["score"] > misaligned["score"]


def test_score_wrapper_persists_transparent_breakdown_on_poi() -> None:
    agent = SMCAgent(CONFIG)
    poi = {
        "zone": {"top": 4404.71, "bottom": 4397.68},
        "mitigation_status": "FRESH", "strength": "strong",
        "displacement_score": 24.5,
    }
    score = agent._return_probability_score(
        poi=poi, direction="SELL", current_price=4369.385, atr=6.0,
        market_structure={"structure_quality": "STRONG"},
        liquidity={"session_liquidity": {"label": "London / Europe Midday"}},
        all_candidates=[poi], candles=_candles(4395.0, .3),
    )
    assert score == poi["return_probability_breakdown"]["score"]
    assert poi["return_probability_breakdown"]["components"]
