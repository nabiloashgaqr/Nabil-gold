"""Two-agent watch maps are visible but can never authorize execution."""
from __future__ import annotations

from copy import deepcopy

from scripts.run_analysis import (
    _decorate_session_plan_for_delivery,
    _monitoring_map_delivery_gate,
    _planner_execution_gate,
)
from services.telegram_bot import TelegramService


CONFIG = {
    "shared_market_data": {"enabled": True},
    "agent_weights": {
        "technical": .20, "multitimeframe": .15, "classical": .25,
        "smc": .20, "price_action": .20,
    },
    "signal_requirements": {
        "agent_min_confidence": 67,
        "min_agents_agree": 3,
        "min_consensus_confidence": 72,
        "two_agent_entry": {
            "enabled": True,
            "min_agents_agree": 2,
            "min_consensus_confidence": 72,
            "macro_confirmation": {"enabled": True, "min_confidence": 55},
            "gemini_confirmation": {"enabled": True, "min_confidence": 70},
        },
    },
    "session_planner": {"max_opposing_agents_for_ready": 1},
    "session_plan_delivery": {
        "enabled": True,
        "only_when_ready": True,
        "monitoring_only": {
            "enabled": True,
            "min_supporting_agents": 2,
            "min_net_confidence": 72,
            "max_opposing_agents": 1,
            "require_complete_levels": True,
        },
    },
}


def _plan() -> dict:
    return {
        "symbol": "XAU/USD",
        "plan_ready": True,
        "plan_status": "READY",
        "plan_reason": "session plan ready",
        "session_bias": "SELL",
        "authority_direction": "SELL",
        "authority_state": "WEAK",
        "session_label": "London",
        "session_quality": "HIGH",
        "scenario_type": "ORDER_BLOCK_PULLBACK",
        "planner_confidence": 84.0,
        "planner_grade": "A",
        "primary_entry_zone": {"low": 4397.68, "high": 4404.71},
        "primary_entry_price": 4401.19,
        "invalidation_level": 4406.81,
        "target_liquidity": 4340.0,
        "primary_execution": {
            "stop_loss": 4406.81,
            "tp1": 4368.07,
            "tp2": 4340.0,
        },
        "primary_poi": {
            "entry_price": 4401.19,
            "stop_loss": 4406.81,
            "target_liquidity": 4340.0,
            "details": {
                "liquidity": {
                    "buy_side": [4410.0, 4425.0],
                    "sell_side": [4368.07, 4340.0, 4335.79],
                }
            },
        },
        "execution_admission": {
            "allow": False,
            "path": None,
            "supporters": ["multitimeframe", "price_action"],
            "opponents": [],
            "support_count": 2,
            "opposition_count": 0,
            "confidence": 73.3,
            "reason": "SELL admission failed: support=2, opposition=0, net=73.3%",
        },
        "agent_book_summary": {
            "supporters": ["multitimeframe", "price_action"],
            "opponents": [],
            "inactive_or_unqualified": ["technical", "classical", "smc"],
            "support_count": 2,
            "opposition_count": 0,
            "inactive_count": 3,
            "matches_execution_admission": True,
        },
        "agent_min_confidence": 67,
        "shared_market_data": {"snapshot_id": "MT5BOOK::watch"},
        "delivery_context": {
            "message_kind": "WATCH_MAP",
            "delivery_reason": "two_agent_monitoring_map",
            "monitoring_only": True,
        },
        "monitoring_only": True,
        "agent_opinions": [
            {"key": "technical", "label": "Technical", "direction": "WAIT", "confidence": 55.2, "weight": .20, "qualified": False, "qualification_bar": 67},
            {"key": "classical", "label": "Classical", "direction": "SELL", "confidence": 60.1, "weight": .25, "qualified": False, "qualification_bar": 67},
            {
                "key": "smc", "label": "SMC", "direction": "WAIT",
                "confidence": 29.8, "weight": .20, "qualified": False,
                "qualification_bar": 67,
                "conditional_map_counted_as_vote": False,
                "conditional_map": {
                    "direction": "SELL",
                    "setup_type": "ORDER_BLOCK_PULLBACK",
                    "setup_state": "POI_MARKED",
                    "entry_timing": "WAIT_PULLBACK",
                    "trigger_state": "AWAY_FROM_POI",
                    "zone": {"low": 4397.68, "high": 4404.71},
                    "entry_price": 4401.19,
                    "stop_loss": 4406.81,
                    "target": 4340.0,
                    "quality": 53.0,
                    "return_probability": 24.6,
                },
            },
            {"key": "price_action", "label": "Price Action", "direction": "SELL", "confidence": 73.5, "weight": .20, "qualified": True, "qualification_bar": 67},
            {"key": "multitimeframe", "label": "Multi-Timeframe", "direction": "SELL", "confidence": 73.1, "weight": .15, "qualified": True, "qualification_bar": 67},
        ],
    }


def test_two_agent_complete_map_is_admitted_for_monitoring_only() -> None:
    plan = _plan()
    before = deepcopy(plan)
    gate = _monitoring_map_delivery_gate(plan, CONFIG)
    assert gate["allow"] is True
    assert gate["mode"] == "MONITORING_ONLY"
    assert gate["support_count"] == 2
    assert plan == before  # display gate never mutates the executable plan


def test_monitoring_gate_refuses_one_agent_low_net_or_missing_levels() -> None:
    one = _plan()
    one["execution_admission"]["support_count"] = 1
    assert _monitoring_map_delivery_gate(one, CONFIG)["allow"] is False

    low = _plan()
    low["execution_admission"]["confidence"] = 71.9
    assert _monitoring_map_delivery_gate(low, CONFIG)["allow"] is False

    incomplete = _plan()
    incomplete["primary_entry_zone"] = {}
    assert _monitoring_map_delivery_gate(incomplete, CONFIG)["allow"] is False


def test_two_agent_watch_map_still_fails_the_real_order_gate() -> None:
    decision = {
        "decision": "SELL",
        "agent_details": {
            "multitimeframe": {"direction": "SELL", "confidence": 73.1},
            "price_action": {"direction": "SELL", "confidence": 73.5},
            "technical": {"direction": "WAIT", "confidence": 55.2},
            "classical": {"direction": "WAIT", "confidence": 60.1},
            "smc": {"direction": "WAIT", "confidence": 29.8},
        },
        "session_plan": {"plan_ready": True, "session_bias": "SELL"},
    }
    gate = _planner_execution_gate(decision, CONFIG)
    assert gate["allow"] is False
    assert gate["kind"] == "SHARED_ADMISSION_BLOCKED"
    assert gate["support_count"] == 2


def test_monitoring_card_contains_zone_stop_targets_liquidity_and_conditional_smc(monkeypatch) -> None:
    captured = {}
    service = TelegramService({"telegram": {}})

    def capture(text: str, urgent: bool = False, **_kwargs):
        captured["text"] = text
        captured["urgent"] = urgent
        return True

    monkeypatch.setattr(service, "send_message", capture)
    assert service.send_session_plan(_plan()) is True
    text = captured["text"]
    assert captured["urgent"] is False
    assert "WATCH MAP — MONITORING ONLY" in text
    assert "NOT EXECUTION-ADMITTED" in text
    assert "No Market, Pending or revived-plan order" in text
    assert "4397.68" in text and "4404.71" in text
    assert "4406.81" in text  # stop
    assert "4368.07" in text and "4340.00" in text  # targets
    assert "LIQUIDITY" in text and "L1" in text and "L2" in text
    assert "Conditional SELL map" in text
    assert "not counted as a vote" in text
    assert "WAIT_PULLBACK" in text
    assert "quality 53.0" in text and "return 24.6" in text
    assert "Shared agent admission passed" not in text
    assert "This card cannot create an order" in text


def test_decorator_carries_smc_conditional_map_without_changing_vote() -> None:
    plan = _plan()
    plan.pop("agent_opinions")
    plan.pop("execution_admission")
    plan.pop("agent_book_summary")
    decision = {
        "agent_details": {
            "technical": {"direction": "WAIT", "confidence": 55.2},
            "classical": {"direction": "WAIT", "confidence": 60.1},
            "smc": {"direction": "WAIT", "confidence": 29.8},
            "price_action": {"direction": "SELL", "confidence": 73.5},
            "multitimeframe": {"direction": "SELL", "confidence": 73.1},
        },
        "weights": CONFIG["agent_weights"],
    }
    all_results = {
        "shared_market_data": {"snapshot_id": "MT5BOOK::watch"},
        "smc": {
            "setup_structure": {
                "direction": "SELL",
                "setup_type": "ORDER_BLOCK_PULLBACK",
                "setup_state": "POI_MARKED",
                "entry_timing": "WAIT_PULLBACK",
                "trigger_state": "AWAY_FROM_POI",
                "poi_zone": {"bottom": 4397.68, "top": 4404.71},
                "entry_price": 4401.19,
                "stop_loss": 4406.81,
                "target_liquidity": 4340.0,
                "quality_score": 53.0,
                "return_probability_score": 24.6,
            }
        },
    }
    decorated = _decorate_session_plan_for_delivery(plan, decision, all_results, {}, CONFIG)
    smc = next(op for op in decorated["agent_opinions"] if op["key"] == "smc")
    assert smc["direction"] == "WAIT"
    assert smc["qualified"] is False
    assert smc["conditional_map"]["direction"] == "SELL"
    assert smc["conditional_map_counted_as_vote"] is False
