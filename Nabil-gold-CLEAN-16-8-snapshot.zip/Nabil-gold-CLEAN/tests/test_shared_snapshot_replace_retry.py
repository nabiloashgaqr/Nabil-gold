"""Windows-safe atomic snapshot swap (operator incident 2026-08-14).

The demo loop crashed with ``[WinError 5] Access is denied`` renaming the
temp snapshot onto ``storage/shared_market_data.json``: on Windows,
``os.replace`` fails while ANY other process (tick manager, dashboard,
check_agents_now) holds the destination open for reading. Readers hold it
for milliseconds, so ``publish_shared_market_data`` now retries the swap
briefly (10 tries, 50..500 ms backoff) before surfacing the error.
"""
from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from services.shared_market_data import publish_shared_market_data


def _market_data():
    candles = [
        {"time": i * 900, "open": 1.0, "high": 2.0, "low": 0.5, "close": 1.5}
        for i in range(30)
    ]
    return {
        "symbol": "XAU/USD",
        "source": "mt5",
        "current_price": 4400.0,
        "timeframes": {tf: {"data": list(candles), "source": "mt5"} for tf in ("5m", "15m", "1H", "4H")},
    }


def _config(tmp_path):
    return {"shared_market_data": {"enabled": True, "storage_path": str(tmp_path / "shared.json")}}


def test_transient_permission_error_is_retried_and_succeeds(tmp_path):
    real_replace = os.replace
    calls = {"n": 0}

    def flaky_replace(src, dst):
        calls["n"] += 1
        if calls["n"] <= 3:  # first three attempts hit the Windows reader lock
            raise PermissionError(5, "Access is denied", str(dst))
        return real_replace(src, dst)

    with patch("services.shared_market_data.os.replace", side_effect=flaky_replace), \
         patch("services.shared_market_data.time.sleep"):
        result = publish_shared_market_data(_market_data(), _config(tmp_path))

    assert calls["n"] == 4
    assert (tmp_path / "shared.json").exists()
    assert result["shared_market_data"]["snapshot_id"].startswith("MT5BOOK::")


def test_first_ever_write_failure_still_raises(tmp_path):
    """No previous snapshot on disk -> the error must surface."""
    with patch("services.shared_market_data.os.replace",
               side_effect=PermissionError(5, "Access is denied", "shared.json")), \
         patch("services.shared_market_data.time.sleep"):
        with pytest.raises(PermissionError):
            publish_shared_market_data(_market_data(), _config(tmp_path))


def test_persistent_lock_with_previous_snapshot_degrades_gracefully(tmp_path):
    """A held lock must not kill the analysis cycle when a valid previous
    snapshot exists: the cycle keeps its in-memory book, readers keep the
    previous file, and the meta records stored=False with the error."""
    cfg = _config(tmp_path)
    publish_shared_market_data(_market_data(), cfg)  # seed a valid snapshot
    with patch("services.shared_market_data.os.replace",
               side_effect=PermissionError(5, "Access is denied", "shared.json")), \
         patch("services.shared_market_data.time.sleep"):
        result = publish_shared_market_data(_market_data(), cfg)
    meta = result["shared_market_data"]
    assert meta["stored"] is False
    assert "PermissionError" in meta["store_error"]
    assert meta["snapshot_id"].startswith("MT5BOOK::")
    assert (tmp_path / "shared.json").exists()  # previous snapshot intact


def test_normal_publish_swaps_once_and_leaves_no_temp_files(tmp_path):
    publish_shared_market_data(_market_data(), _config(tmp_path))
    leftovers = [p for p in tmp_path.iterdir() if p.suffix == ".tmp"]
    assert leftovers == []
    assert (tmp_path / "shared.json").exists()
