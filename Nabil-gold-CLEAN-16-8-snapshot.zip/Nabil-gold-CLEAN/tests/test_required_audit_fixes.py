"""Required fixes from the independent five-agent audit."""
from __future__ import annotations

import json
import time

import pytest

from agents.decision_agent import DecisionAgent
from services.agent_confidence_audit import _fusion_expected
from services.auction_flow_store import AuctionFlowStore
from services.timeframe_fusion import fuse_timeframe_results


class _Learning:
    def get_agent_recommendation(self, _name):
        return "INCREASE_CONFIDENCE"


def test_mt5_feed_requests_closed_bars_and_keeps_live_tick_price(monkeypatch) -> None:
    import types
    import sys
    from services import mt5_feed

    now = int(time.time())
    calls = []
    rates = [
        {"time": now - (220 - i) * 300, "open": 4289.0, "high": 4291.0,
         "low": 4288.0, "close": 4290.0}
        for i in range(220)
    ]
    fake = types.SimpleNamespace(
        TIMEFRAME_M5=5, TIMEFRAME_M15=15, TIMEFRAME_H1=60, TIMEFRAME_H4=240,
        terminal_info=lambda: object(),
        copy_rates_from_pos=lambda symbol, tf, start, count: calls.append((start, count)) or rates,
        symbol_info_tick=lambda symbol: types.SimpleNamespace(bid=4300.0, ask=4300.2),
        time=lambda: int(time.time()),
    )
    monkeypatch.setitem(sys.modules, "MetaTrader5", fake)
    mt5_feed._offset_cache.clear()
    payload = mt5_feed.get_candles("XAU/USD", "5m", 220)
    assert calls == [(1, 220)]
    assert payload["data"][-1]["close"] == 4290.0
    assert payload["current_price"] == pytest.approx(4300.1)
    assert payload["source_integrity"]["uses_closed_candles"] is True
    assert payload["source_integrity"]["forming_bar_excluded"] is True


def test_learning_recommendation_cannot_silently_change_live_book() -> None:
    cfg = {
        "agent_weights": {"technical": .2, "multitimeframe": .15, "classical": .25,
                          "smc": .2, "price_action": .2},
        "signal_requirements": {"agent_min_confidence": 67},
        "learning": {"auto_adjust_confidence": False},
    }
    agent = DecisionAgent(cfg, learning_service=_Learning())
    assert agent.get_adjusted_confidence("smc", 70.0) == 70.0
    votes = agent._collect_votes({"smc": {"signal": "BUY", "confidence": 70}})
    assert votes["BUY"][0]["confidence"] == 70.0
    assert votes["BUY"][0]["adjusted_confidence"] == 70.0
    assert votes["BUY"][0]["learning_adjusted"] is False


def test_learning_adjustment_requires_explicit_operator_opt_in() -> None:
    cfg = {
        "agent_weights": {"technical": .2, "multitimeframe": .15, "classical": .25,
                          "smc": .2, "price_action": .2},
        "signal_requirements": {"agent_min_confidence": 67},
        "learning": {"auto_adjust_confidence": True},
    }
    agent = DecisionAgent(cfg, learning_service=_Learning())
    assert agent.get_adjusted_confidence("smc", 70.0) == pytest.approx(77.0)


def test_activity_ratio_compares_same_unit_sixty_second_windows(tmp_path) -> None:
    store = AuctionFlowStore(tmp_path / "activity.sqlite3")
    now = int(time.time())
    ticks = []
    # 31 equal 60-second windows, 10 unique ticks per window.
    for minute in range(31):
        start = now - 31 * 60 + minute * 60 + 1
        for index in range(10):
            mid = 4300.0 + minute * 0.01 + index * 0.0001
            ticks.append({
                "time_msc": (start + index * 5) * 1000,
                "bid": mid - 0.10, "ask": mid + 0.10,
                "last": 0.0, "flags": minute * 100 + index,
            })
    assert store.bulk_record_ticks(ticks) == 310
    state = store.flow_state(session_timezone="UTC", now=now)
    assert state["activity_windows"] >= 28
    assert state["activity_ticks_60s"] == pytest.approx(10, abs=2)
    assert state["activity_baseline_ticks_60s"] == pytest.approx(10, abs=2)
    assert state["activity_ratio"] == pytest.approx(1.0, abs=0.2)


def test_broker_shifted_tick_buckets_use_offset_query_reference(tmp_path) -> None:
    store = AuctionFlowStore(tmp_path / "broker_offset.sqlite3")
    now = int(time.time())
    offset = 3 * 3600
    ticks = []
    for minute in range(31):
        start = now + offset - 31 * 60 + minute * 60 + 1
        for index in range(10):
            mid = 4300.0 + minute * 0.01 + index * 0.0001
            ticks.append({
                "time_msc": (start + index * 5) * 1000,
                "bid": mid - .10, "ask": mid + .10,
                "last": 0.0, "flags": minute * 100 + index,
            })
    assert store.bulk_record_ticks(ticks) == 310
    state = store.flow_state(session_timezone="Asia/Hebron", now=now)
    assert state["broker_offset_seconds"] == offset
    assert state["query_reference_time"] == pytest.approx(now + offset, abs=1)
    assert state["activity_ratio"] == pytest.approx(1.0, abs=0.2)
    assert state["activity_ticks_60s"] == pytest.approx(10, abs=2)


def _conflict_reads(sell: float, buy: float) -> dict:
    return {
        "5m": {"direction": "WAIT", "confidence": 32},
        "15m": {"direction": "SELL", "confidence": sell},
        "1H": {"direction": "BUY", "confidence": buy},
        "4H": {"direction": "WAIT", "confidence": 28},
    }


def test_near_cancelled_frames_are_wait_not_sell_point_four() -> None:
    result = fuse_timeframe_results("classical", _conflict_reads(71, 70))
    assert result["signal"] == "WAIT"
    assert result["direction"] == "NEUTRAL"
    assert result["timeframe_fusion"]["conflict_wait"] is True
    assert result["confidence"] == pytest.approx(49.6, abs=0.1)
    expected = _fusion_expected(result)
    assert expected["direction"] == "WAIT"
    assert expected["confidence"] == pytest.approx(result["confidence"], abs=0.11)


def test_material_residual_direction_survives_conflict_guard() -> None:
    result = fuse_timeframe_results("classical", _conflict_reads(80, 60))
    assert result["signal"] == "SELL"
    assert result["timeframe_fusion"]["coherence"] > 0.10
    assert result["timeframe_fusion"]["conflict_wait"] is False


def test_shipped_config_pins_one_raw_book_and_closed_candles() -> None:
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    cfg = json.loads((root / "config.json").read_text(encoding="utf-8"))
    assert cfg["learning"]["auto_adjust_confidence"] is False
    source = (root / "services" / "mt5_feed.py").read_text(encoding="utf-8")
    assert "copy_rates_from_pos(mt5_symbol, tf_const, 1, count)" in source
