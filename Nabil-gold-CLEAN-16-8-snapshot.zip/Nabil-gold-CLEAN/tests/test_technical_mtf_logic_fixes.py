"""Technical + Multi-Timeframe logic fixes (operator 2026-08-14).

Four measured defects, each pinned here so it cannot silently return:

1. Technical's confidence map (score*16+45 cap 92) published the weakest
   possible directional signal at 85% and saturated by score 3.0 -- a 7-point
   band that inflated every vote past the 67% bar with no gradation.
   New map: min(45 + score*9, 90) -> threshold signal ~67-70%, graded to 90.

2. MTF's strength bonus summed over ALL frames including OPPOSING ones:
   a STRONG 4H against the trade added +6 to the trade's own confidence
   (measured live: 43 vs 37). Opposing frames now subtract their strength.

3. Technical was the only core agent still reading a single timeframe while
   config::all_agents_timeframes declares all four for every agent. It now
   fuses native 5m/15m/1H/4H through the shared fuse_timeframe_results.

4. The "ADX proxy" was one unsmoothed DX snapshot (jumpy, understated
   moderate trends: 33 vs a real 45). It is now true Wilder-smoothed ADX.
"""
from __future__ import annotations

import random

from agents.multitimeframe_agent import MultiTimeframeAgent
from agents.technical_agent import TechnicalAgent
from utils.helpers import load_config

CONFIG = load_config()


def _candles(n=250, trend=0.5, seed=1):
    rng = random.Random(seed)
    out, price = [], 4300.0
    for i in range(n):
        drift = trend + rng.gauss(0, 2.0)
        o, c = price, price + drift
        out.append({
            "time": i * 900, "open": o,
            "high": max(o, c) + 1.0, "low": min(o, c) - 1.0, "close": c,
        })
        price = c
    return out


# ── 1. graded confidence ────────────────────────────────────────────────────

def test_threshold_signal_is_barely_qualified_not_wildly_confident():
    agent = TechnicalAgent(CONFIG)
    tech = {"classic_score": 2.5, "classic_signal": "BUY", "rsi": 50, "market_regime": {}}
    conf = agent._calculate_classic_confidence(tech)
    assert 67 <= conf <= 72, f"threshold signal should barely qualify, got {conf}"


def test_confidence_grows_with_score_instead_of_saturating():
    agent = TechnicalAgent(CONFIG)
    confs = []
    for score in (2.5, 3.0, 3.5, 4.0, 5.0):
        tech = {"classic_score": score, "classic_signal": "BUY", "rsi": 50, "market_regime": {}}
        confs.append(agent._calculate_classic_confidence(tech))
    assert confs == sorted(confs), "confidence must be monotonic in score"
    assert confs[-1] - confs[0] >= 15, f"needs a real spread, got {confs}"
    assert confs[-1] <= 90


def test_wait_confidence_still_capped_low():
    agent = TechnicalAgent(CONFIG)
    tech = {"classic_score": 2.4, "classic_signal": "WAIT", "rsi": 50, "market_regime": {}}
    assert agent._calculate_classic_confidence(tech) <= 55


# ── 2. MTF opposing strength ────────────────────────────────────────────────

def test_stronger_opponent_never_raises_trade_confidence():
    agent = MultiTimeframeAgent(CONFIG)
    supporting = {
        "1H": {"bias": "BUY", "strength": "MODERATE"},
        "15m": {"bias": "BUY", "strength": "STRONG"},
        "5m": {"bias": "BUY", "strength": "MODERATE"},
    }
    strong_opp = {"4H": {"bias": "SELL", "strength": "STRONG"}, **supporting}
    weak_opp = {"4H": {"bias": "SELL", "strength": "WEAK"}, **supporting}
    c_strong = agent._confidence(strong_opp, "BUY", 45, [], counter_trend=True, setup_type="REVERSAL_ATTEMPT")
    c_weak = agent._confidence(weak_opp, "BUY", 45, [], counter_trend=True, setup_type="REVERSAL_ATTEMPT")
    assert c_strong <= c_weak, (
        f"a STRONG opponent must not add confidence: strong={c_strong} weak={c_weak}"
    )


def test_supporting_strength_still_earns_its_bonus():
    agent = MultiTimeframeAgent(CONFIG)
    strong_support = {
        "4H": {"bias": "BUY", "strength": "STRONG"},
        "1H": {"bias": "BUY", "strength": "STRONG"},
        "15m": {"bias": "BUY", "strength": "STRONG"},
        "5m": {"bias": "BUY", "strength": "STRONG"},
    }
    weak_support = {tf: {"bias": "BUY", "strength": "WEAK"} for tf in strong_support}
    c_strong = agent._confidence(strong_support, "BUY", 80, [], setup_type="TREND_CONTINUATION")
    c_weak = agent._confidence(weak_support, "BUY", 80, [], setup_type="TREND_CONTINUATION")
    assert c_strong > c_weak


# ── 3. Technical reads all four native frames ───────────────────────────────

def test_technical_fuses_all_four_native_timeframes():
    agent = TechnicalAgent(CONFIG)
    data = {
        "source": "mt5",
        "current_price": 4400.0,
        "timeframes": {
            tf: {"data": _candles(seed=i, trend=0.6)}
            for i, tf in enumerate(("5m", "15m", "1H", "4H"))
        },
    }
    result = agent.analyze(data)
    assert result["agent"] == "technical"
    frames = set((result.get("timeframe_analysis") or {}).keys())
    assert frames == {"5m", "15m", "1H", "4H"}
    fusion = result.get("timeframe_fusion") or {}
    assert fusion.get("method") == "equal_native_timeframes_one_vote"


def test_technical_single_frame_compatibility_path_still_works():
    agent = TechnicalAgent(CONFIG)
    result = agent.analyze({"data": _candles(seed=9), "current_price": 4400.0})
    assert result["agent"] == "technical"
    assert result["signal"] in {"BUY", "SELL", "WAIT"}
    assert 0 <= result["confidence"] <= 100


# ── 4. true Wilder ADX ──────────────────────────────────────────────────────

def _wilder_reference(cs, period=14):
    import math  # noqa: F401

    plus_dm, minus_dm, trs = [], [], []
    for i in range(1, len(cs)):
        h, l = cs[i]["high"], cs[i]["low"]
        hp, lp, cp = cs[i - 1]["high"], cs[i - 1]["low"], cs[i - 1]["close"]
        up, dn = h - hp, lp - l
        plus_dm.append(up if up > dn and up > 0 else 0.0)
        minus_dm.append(dn if dn > up and dn > 0 else 0.0)
        trs.append(max(h - l, abs(h - cp), abs(l - cp)))
    st, sp, sm = sum(trs[:period]), sum(plus_dm[:period]), sum(minus_dm[:period])
    dxs = []
    for i in range(period, len(trs)):
        st = st - st / period + trs[i]
        sp = sp - sp / period + plus_dm[i]
        sm = sm - sm / period + minus_dm[i]
        pdi, mdi = 100 * sp / max(st, 1e-9), 100 * sm / max(st, 1e-9)
        dxs.append(abs(pdi - mdi) / max(pdi + mdi, 1e-9) * 100)
    adx = sum(dxs[:period]) / period
    for dx in dxs[period:]:
        adx = (adx * (period - 1) + dx) / period
    return adx


def test_adx_matches_the_wilder_reference():
    agent = TechnicalAgent(CONFIG)
    cs = _candles(300, trend=0.8, seed=42)
    ours, _ = agent._calculate_adx_proxy(cs)
    assert abs(ours - _wilder_reference(cs)) < 0.01


def test_adx_direction_labels_are_sane():
    agent = TechnicalAgent(CONFIG)
    up = _candles(300, trend=2.0, seed=7)
    down = _candles(300, trend=-2.0, seed=8)
    _, up_label = agent._calculate_adx_proxy(up)
    _, down_label = agent._calculate_adx_proxy(down)
    assert up_label == "BULLISH"
    assert down_label == "BEARISH"
