"""PATH 5 — TWO-AGENT + AUCTION FLOW (operator 2026-08-14).

Two qualified core agents plus a same-direction standalone Auction Flow read
at >=72% admit the direction.  Auction Flow never votes: it is the third
external confirmer alongside Macro (Path 2) and Gemini (Path 3).  Qualified
opposition is allowed but deducted with the standard penalty; the net
confidence must still clear the 72% floor.
"""
from __future__ import annotations

from services.execution_paths import (
    PATH_5,
    PATH_DEFINITIONS,
    path_id_from_admission,
    resolve_execution_path,
)
from services.thesis_consensus import evaluate_directional_admission


def _config(**path5_overrides):
    path5 = {
        "enabled": True,
        "min_agents_agree": 2,
        "min_consensus_confidence": 72,
        "agent_min_confidence": 67,
        "min_auction_confidence": 72,
    }
    path5.update(path5_overrides)
    return {
        "agent_weights": {
            "classical": 0.25,
            "technical": 0.20,
            "smc": 0.20,
            "price_action": 0.20,
            "multitimeframe": 0.15,
        },
        "signal_requirements": {
            "min_agents_agree": 3,
            "min_consensus_confidence": 72,
            "agent_min_confidence": 67,
            "two_agent_entry": {
                "enabled": True,
                "min_agents_agree": 2,
                "min_consensus_confidence": 72,
                # Macro and Gemini stay silent in these tests so that only
                # the auction confirmation can admit the two-agent book.
                "macro_confirmation": {"enabled": True, "min_confidence": 55},
                "gemini_confirmation": {"enabled": True, "min_confidence": 70},
            },
            "path5_two_agent_auction": path5,
        },
    }


def _two_supporters(side="BUY", conf=85):
    return {
        "technical": {"signal": side, "confidence": conf},
        "classical": {"signal": side, "confidence": conf},
        "smc": {"signal": "WAIT", "confidence": 40},
        "price_action": {"signal": "WAIT", "confidence": 30},
        "multitimeframe": {"signal": "WAIT", "confidence": 35},
    }


def test_path5_admits_two_agents_plus_auction():
    details = _two_supporters("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 80}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is True
    assert admission["path"] == "TWO_AGENT_AUCTION"
    assert admission["confirm_source"] == "auction"
    assert admission["confirm_confidence"] == 80
    assert admission["support_count"] == 2


def test_path5_is_a_registered_execution_path():
    assert PATH_5 in PATH_DEFINITIONS
    assert PATH_DEFINITIONS[PATH_5]["number"] == 5
    assert path_id_from_admission("TWO_AGENT_AUCTION") == PATH_5
    resolved = resolve_execution_path({"execution_path_id": PATH_5})
    assert resolved["id"] == PATH_5
    resolved_from_mode = resolve_execution_path(
        {"entry_mode": "two_agent_auction", "confirm_source": "auction"}
    )
    assert resolved_from_mode["id"] == PATH_5


def test_path5_refused_when_auction_confidence_below_floor():
    details = _two_supporters("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 71.9}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is False


def test_path5_refused_when_auction_points_the_other_way():
    details = _two_supporters("BUY")
    details["auction_flow"] = {"signal": "SELL", "confidence": 90}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is False


def test_path5_refused_when_auction_is_wait():
    details = _two_supporters("SELL")
    details["auction_flow"] = {"signal": "WAIT", "confidence": 90}
    admission = evaluate_directional_admission("SELL", details, _config())
    assert admission["allow"] is False


def test_path5_disabled_by_config():
    details = _two_supporters("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 90}
    admission = evaluate_directional_admission("BUY", details, _config(enabled=False))
    assert admission["allow"] is False


def test_path5_refused_with_only_one_qualified_supporter():
    details = {
        "technical": {"signal": "BUY", "confidence": 90},
        "classical": {"signal": "WAIT", "confidence": 30},
        "smc": {"signal": "WAIT", "confidence": 30},
        "price_action": {"signal": "WAIT", "confidence": 30},
        "multitimeframe": {"signal": "BUY", "confidence": 60},  # below the 67 bar
        "auction_flow": {"signal": "BUY", "confidence": 90},
    }
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is False


def test_path5_opposition_is_deducted_not_fatal():
    """A qualified opponent lowers net confidence but does not veto Path 5."""
    details = {
        "technical": {"signal": "BUY", "confidence": 95},
        "classical": {"signal": "BUY", "confidence": 95},
        "smc": {"signal": "WAIT", "confidence": 30},
        "price_action": {"signal": "SELL", "confidence": 68},  # qualified opposition
        "multitimeframe": {"signal": "WAIT", "confidence": 30},
        "auction_flow": {"signal": "BUY", "confidence": 85},
    }
    admission = evaluate_directional_admission("BUY", details, _config())
    # Support 95%*0.45 vs opposition 68%*0.20 → net stays above the floor.
    assert admission["allow"] is True
    assert admission["path"] == "TWO_AGENT_AUCTION"
    assert admission["opposition_count"] == 1


def test_path5_opposition_can_sink_the_net_confidence():
    """Enough qualified opposition pushes net confidence under 72 → refused."""
    details = {
        "technical": {"signal": "BUY", "confidence": 74},
        "multitimeframe": {"signal": "BUY", "confidence": 74},
        "classical": {"signal": "SELL", "confidence": 90},
        "smc": {"signal": "SELL", "confidence": 90},
        "price_action": {"signal": "WAIT", "confidence": 30},
        "auction_flow": {"signal": "BUY", "confidence": 90},
    }
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is False


def test_path5_yields_to_macro_when_macro_confirms():
    """Macro (Path 2) is checked first; auction only confirms when it fails."""
    details = _two_supporters("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 90}
    details["macro_fundamental"] = {"direction": "BUY", "confidence": 60}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is True
    assert admission["path"] == "TWO_AGENT_MACRO"


def test_path5_never_promotes_auction_into_the_vote_book():
    details = _two_supporters("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 90}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert "auction_flow" not in admission["supporters"]
    assert "auction_flow" not in admission["opponents"]
