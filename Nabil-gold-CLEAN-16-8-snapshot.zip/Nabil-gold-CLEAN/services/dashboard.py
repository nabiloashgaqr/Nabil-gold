"""HTML dashboard generator for Gold AI Signals.

Creates a self-contained HTML dashboard from recent trades.
No external assets/CDNs are used so the artifact can be opened offline.
"""

from __future__ import annotations

import html
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from services import performance_stats


OPEN_STATUSES = {"OPEN", "PARTIAL", "TP1_HIT"}
WIN_STATUSES = {"TP2_HIT"}
LOSS_STATUSES = set()


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _status_badge(status: str) -> str:
    status = str(status or "UNKNOWN").upper()
    if status in {"OPEN", "PARTIAL", "TP1_HIT"}:
        cls = "open"
    elif status in WIN_STATUSES:
        cls = "win"
    elif status == "SL_HIT":
        # SL_HIT can be SL+, breakeven, or a loss; the row PnL color carries
        # the financial outcome, so keep the status badge neutral.
        cls = "neutral"
    elif status in LOSS_STATUSES:
        cls = "loss"
    else:
        cls = "neutral"
    return f'<span class="badge {cls}">{html.escape(status)}</span>'


def _trade_type_badge(trade_type: str) -> str:
    trade_type = str(trade_type or "").upper()
    cls = "buy" if trade_type == "BUY" else "sell" if trade_type == "SELL" else "neutral"
    return f'<span class="badge {cls}">{html.escape(trade_type or "N/A")}</span>'


def _pnl(trade: Dict[str, Any]) -> float:
    for key in ("final_pnl", "current_pnl", "current_pnl_points", "pnl"):
        if trade.get(key) is not None:
            return _f(trade.get(key))
    return 0.0


def _trade_type(trade: Dict[str, Any]) -> str:
    return str(trade.get("type") or trade.get("trade_type") or "").upper()


def summarize_trades(trades: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Performance summary. Delegates to the one shared definition.

    This used to be a second implementation of the maths the web dashboard
    already had, and the two disagreed in front of the operator: the card
    reported 80 trades with 34 wins and 9 losses -- 37 rows in neither
    column, because PENDING and CANCELLED orders were being counted as
    "trades" while having no outcome to be counted in. Net and profit factor
    mixed realised profit with floating PnL for the same reason.

    ``services.performance_stats`` now owns the definition. The legacy key
    names are preserved so existing callers and the HTML renderer keep
    working, and ``total`` deliberately means CLOSED trades now, matching the
    number the wins and losses are drawn from.
    """
    summary = performance_stats.summarize(trades)
    return {
        # `total` is the set the outcomes are computed over, so W + L + BE
        # always reconciles against it.
        "total": summary["closed"],
        "open": summary["open"],
        "pending": summary["pending"],
        "closed": summary["closed"],
        "wins": summary["wins"],
        "losses": summary["losses"],
        "breakeven": summary["breakeven"],
        "win_rate": summary["win_rate"],
        "net_points": summary["net_points"],
        "profit_factor": summary["profit_factor"] if summary["profit_factor"] is not None else 99.9,
        "open_floating_points": summary["open_floating_points"],
        "buy_count": summary["buy_count"],
        "sell_count": summary["sell_count"],
        "buy_net": summary["buy_net"],
        "sell_net": summary["sell_net"],
        "avg_confidence": summary["avg_confidence"],
    }


def _render_cards(summary: Dict[str, Any]) -> str:
    pf = summary["profit_factor"]
    pf_display = "∞" if pf >= 99 or (pf in (0, 99.9) and summary.get("losses", 0) == 0 and summary.get("wins", 0) > 0) else pf
    cards = [
        ("Total Trades", summary["total"], "📊"),
        ("Open", summary["open"], "🟡"),
        ("Win Rate", f"{summary['win_rate']}%", "✅"),
        ("Net Points", f"{summary['net_points']:+}", "💰"),
        ("Profit Factor", pf_display, "⚖️"),
        ("Avg Confidence", f"{summary['avg_confidence']}%", "🎯"),
    ]
    return "\n".join(
        f"""
        <div class="card">
          <div class="card-icon">{icon}</div>
          <div class="card-title">{html.escape(str(title))}</div>
          <div class="card-value">{html.escape(str(value))}</div>
        </div>
        """
        for title, value, icon in cards
    )


def _render_trades_table(trades: List[Dict[str, Any]]) -> str:
    rows = []
    for trade in trades[:80]:
        status = str(trade.get("status", "UNKNOWN"))
        pnl = _pnl(trade)
        pnl_cls = "pos" if pnl > 0 else "neg" if pnl < 0 else "flat"
        rows.append(
            "<tr>"
            f"<td><code>{html.escape(str(trade.get('id', '')))}</code></td>"
            f"<td>{_trade_type_badge(_trade_type(trade))}</td>"
            f"<td>{_status_badge(status)}</td>"
            f"<td>{html.escape(str(trade.get('entry_price', '')))}</td>"
            f"<td>{html.escape(str(trade.get('current_price', '')))}</td>"
            f"<td>{html.escape(str(trade.get('stop_loss', '')))}</td>"
            f"<td>{html.escape(str(trade.get('tp1', '')))}</td>"
            f"<td>{html.escape(str(trade.get('tp2', '')))}</td>"
            f"<td class='{pnl_cls}'>{pnl:+.2f}</td>"
            f"<td>{html.escape(str(trade.get('confidence', '')))}%</td>"
            f"<td>{html.escape(str(trade.get('trading_mode', 'mt5_demo')))}</td>"
            f"<td>{html.escape(str(trade.get('created_at', ''))[:19])}</td>"
            "</tr>"
        )
    if not rows:
        rows.append("<tr><td colspan='12' class='empty'>No trades found</td></tr>")
    return "\n".join(rows)


def merge_trade_rows(*lists: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Merge trade rows from several tables into ONE continuous history.

    Operator directive (2026-08-09): the dashboard must read as a single
    unbroken record — paper history + live execution — as if no migration
    ever happened. Dedup by trade id (ids are unique per row; a row can
    never exist in two tables). Pure + unit-tested.
    """
    seen: Dict[str, Dict[str, Any]] = {}
    order: List[str] = []
    for rows in lists:
        for row in rows or []:
            key = str(row.get("id") or id(row))
            if key not in seen:
                seen[key] = row
                order.append(key)
    return [seen[k] for k in order]


def render_dashboard(trades: List[Dict[str, Any]]) -> str:
    summary = summarize_trades(trades)
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    cards = _render_cards(summary)
    rows = _render_trades_table(sorted(trades, key=lambda t: str(t.get("created_at", "")), reverse=True))
    # One continuous record (operator directive 2026-08-09): no paper/demo
    # split markers anywhere — the history reads as a single system.
    h1 = "🏆 Gold AI Signals Dashboard"
    mode_label = "XAU/USD"
    title = "Gold AI Signals Dashboard"
    return f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title)}</title>
<style>
  :root {{ --bg:#0f172a; --panel:#111827; --card:#1f2937; --text:#f8fafc; --muted:#94a3b8; --gold:#facc15; --green:#22c55e; --red:#ef4444; --blue:#38bdf8; }}
  * {{ box-sizing: border-box; }}
  body {{ margin:0; font-family: Arial, Tahoma, sans-serif; background:linear-gradient(135deg,#020617,#111827); color:var(--text); }}
  .wrap {{ max-width:1200px; margin:auto; padding:24px; }}
  .hero {{ padding:24px; background:rgba(250,204,21,.08); border:1px solid rgba(250,204,21,.25); border-radius:18px; margin-bottom:20px; }}
  h1 {{ margin:0 0 8px; color:var(--gold); }}
  .muted {{ color:var(--muted); }}
  .grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:14px; margin:20px 0; }}
  .card {{ background:rgba(31,41,55,.9); border:1px solid rgba(148,163,184,.18); border-radius:16px; padding:18px; }}
  .card-icon {{ font-size:24px; }} .card-title {{ color:var(--muted); font-size:13px; margin-top:6px; }} .card-value {{ font-size:28px; font-weight:bold; margin-top:8px; }}
  .panel {{ background:rgba(17,24,39,.92); border:1px solid rgba(148,163,184,.18); border-radius:18px; padding:18px; margin-top:20px; overflow:hidden; }}
  .table-wrap {{ overflow:auto; }}
  table {{ width:100%; border-collapse:collapse; min-width:980px; }}
  th, td {{ border-bottom:1px solid rgba(148,163,184,.15); padding:10px; text-align:right; white-space:nowrap; }}
  th {{ color:var(--gold); font-size:13px; background:rgba(250,204,21,.05); }}
  code {{ direction:ltr; unicode-bidi:bidi-override; color:#c4b5fd; }}
  .badge {{ display:inline-block; padding:4px 8px; border-radius:999px; font-size:12px; font-weight:bold; }}
  .buy,.win {{ background:rgba(34,197,94,.16); color:#86efac; }} .sell,.loss {{ background:rgba(239,68,68,.16); color:#fca5a5; }} .open {{ background:rgba(56,189,248,.16); color:#7dd3fc; }} .neutral {{ background:rgba(148,163,184,.16); color:#cbd5e1; }}
  .pos {{ color:#86efac; font-weight:bold; }} .neg {{ color:#fca5a5; font-weight:bold; }} .flat {{ color:#cbd5e1; }}
  .review {{ background:rgba(31,41,55,.72); border:1px solid rgba(148,163,184,.15); border-radius:14px; padding:14px; margin:10px 0; }}
  .review-head {{ color:#fca5a5; font-weight:bold; }} .review-cause {{ margin:8px 0; color:#e2e8f0; }}
  .empty,.empty-box {{ color:var(--muted); text-align:center; padding:20px; }}
</style>
</head>
<body>
  <div class="wrap">
    <div class="hero">
      <h1>{h1}</h1>
      <div class="muted">Generated at {html.escape(generated)} · {mode_label}</div>
    </div>
    <div class="grid">{cards}</div>
    <div class="panel">
      <h2>📊 Latest Trades</h2>
      <div class="table-wrap"><table>
        <thead><tr><th>ID</th><th>Type</th><th>Status</th><th>Entry</th><th>Current</th><th>SL</th><th>TP1</th><th>TP2</th><th>PnL</th><th>Conf</th><th>Mode</th><th>Created</th></tr></thead>
        <tbody>{rows}</tbody>
      </table></div>
    </div>
  </div>
</body>
</html>"""


def save_dashboard(html_text: str, path: str | Path = "storage/dashboard.html") -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(html_text, encoding="utf-8")
    return target


def format_dashboard_telegram(summary: Dict[str, Any]) -> str:
    pf = summary.get("profit_factor", 0)
    if pf >= 99 or pf == 0 and summary.get("losses", 0) == 0 and summary.get("wins", 0) > 0:
        pf_display = "∞"
    else:
        pf_display = pf
    net = summary.get("net_points", 0)
    wins = summary.get("wins", 0)
    losses = summary.get("losses", 0)
    buy_net = summary.get("buy_net", 0)
    sell_net = summary.get("sell_net", 0)
    buy_count = summary.get("buy_count", 0)
    sell_count = summary.get("sell_count", 0)
    avg_conf = summary.get("avg_confidence", 0)
    lines = [
        "📊 <b>Dashboard Updated</b>",
        "━━━━━━━━━━━━━━━━━━━━",
        # The label says CLOSED because that is what every figure below is
        # computed over. The old card said "Trades: 80" while W + L was 43,
        # because it counted pending and cancelled orders that have no
        # outcome. Naming the scope is what stops that being misread.
        f"Closed: {summary.get('total', 0)} | Open: {summary.get('open', 0)}"
        + (f" | Pending: {summary.get('pending', 0)}" if summary.get("pending") else ""),
        f"📈 Win Rate: {summary.get('win_rate', 0)}% · W: {wins} / L: {losses}"
        + (f" / BE: {summary.get('breakeven')}" if summary.get("breakeven") else ""),
        f"💰 Net: {net:+} pts · PF: {pf_display}",
    ]
    # Floating PnL is reported on its own line, never folded into Net.
    floating = summary.get("open_floating_points") or 0
    if summary.get("open") and floating:
        lines.append(f"⏳ Open floating: {floating:+} pts (not in Net)")
    if buy_count or sell_count:
        lines.append(f"🟢 BUY: {buy_count} trades · {buy_net:+} pts")
        lines.append(f"🔴 SELL: {sell_count} trades · {sell_net:+} pts")
    if avg_conf:
        lines.append(f"🎯 Avg Confidence: {avg_conf}%")
    lines.append("━━━━━━━━━━━━━━━━━━━━")
    return "\n".join(lines)
