"""Non-trading measurement capture for one-variable-at-a-time review.

The recorder writes diagnostic JSONL only. It never changes an agent result,
admission, map, order, stop, target or trade state.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Mapping
from zoneinfo import ZoneInfo

from services.thesis_consensus import evaluate_directional_admission

ROOT = Path(__file__).resolve().parents[1]
CORE = ("technical", "multitimeframe", "classical", "smc", "price_action", "auction_flow")
FUSION = ("classical", "smc", "price_action")


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _direction(result: Mapping[str, Any] | None) -> str:
    value = str((result or {}).get("signal") or (result or {}).get("direction") or "WAIT").upper()
    return "WAIT" if value in {"NEUTRAL", "HOLD", "NONE", ""} else value


def _path(config: Mapping[str, Any], now: datetime) -> Path:
    cfg = config.get("agent_measurement") or {}
    base = Path(str(cfg.get("storage_dir") or "storage/agent_measurements"))
    if not base.is_absolute():
        base = ROOT / base
    tz_name = str((config.get("schedule") or {}).get("timezone") or "Asia/Hebron")
    local_date = now.astimezone(ZoneInfo(tz_name)).date().isoformat()
    return base / f"agent_system_{local_date}.jsonl"


def _fusion_row(result: Mapping[str, Any]) -> Dict[str, Any]:
    fusion = result.get("timeframe_fusion") or {}
    average = _f(fusion.get("average_directional_confidence"))
    coherence = _f(fusion.get("coherence"))
    return {
        "direction": _direction(result),
        "confidence": _f(result.get("confidence")),
        "directional_count": int(fusion.get("directional_count", 0) or 0),
        "coverage": _f(fusion.get("directional_coverage")),
        "coherence": coherence,
        "participation": _f(fusion.get("participation_factor")),
        "pre_participation_confidence": round(average * coherence, 4),
        "conflict_wait": bool(fusion.get("conflict_wait")),
    }


def record_agent_measurement(
    all_results: Mapping[str, Any],
    decision: Mapping[str, Any] | None,
    config: Mapping[str, Any],
) -> Path | None:
    cfg = config.get("agent_measurement") or {}
    if not bool(cfg.get("enabled", False)):
        return None
    now = datetime.now(timezone.utc)
    shared = all_results.get("shared_market_data") or {}
    snapshot_id = str(shared.get("snapshot_id") or "")
    if not snapshot_id:
        return None
    min_conf = _f((config.get("signal_requirements") or {}).get("agent_min_confidence"), 67.0)
    agents: Dict[str, Any] = {}
    for name in CORE:
        result = all_results.get(name) or {}
        side = _direction(result)
        confidence = _f(result.get("confidence"))
        agents[name] = {
            "direction": side,
            "raw_direction": result.get("raw_direction"),
            "confidence": confidence,
            "qualified": side in {"BUY", "SELL"} and confidence >= min_conf,
            "raw_edge": result.get("raw_edge"),
            "coherence": result.get("coherence"),
        }
    auction = all_results.get("auction_flow") or {}
    smc = all_results.get("smc") or {}
    smc_frames = {}
    for timeframe, read in (smc.get("timeframe_analysis") or {}).items():
        score = _f(read.get("directional_score"))
        smc_frames[timeframe] = {
            "score": score,
            "distance_to_buy_threshold": round(4.0 - score, 4),
            "distance_to_sell_threshold": round(score + 4.0, 4),
            "direction": _direction(read),
            "confidence": _f(read.get("confidence")),
        }
    setup = smc.get("setup_structure") or {}
    row = {
        "generated_at": now.isoformat(),
        "snapshot_id": snapshot_id,
        "current_price": _f(all_results.get("current_price")),
        "shared_timeframes": shared.get("timeframes"),
        "agents": agents,
        "fusion": {name: _fusion_row(all_results.get(name) or {}) for name in FUSION},
        "smc_measurement": {
            "frames": smc_frames,
            "setup_candidates": len(smc.get("setup_candidates") or []),
            "setup_direction": setup.get("direction"),
            "setup_type": setup.get("setup_type"),
            "setup_state": setup.get("setup_state"),
            "quality": setup.get("quality_score"),
            "dominance": setup.get("thesis_dominance_score"),
            "return_probability": setup.get("return_probability_score"),
            "return_probability_model": setup.get("return_probability_model"),
            "return_probability_breakdown": setup.get("return_probability_breakdown"),
            "trigger_score": setup.get("trigger_score"),
        },
        "auction_measurement": {
            "state": auction.get("state"),
            "family_scores": auction.get("family_scores"),
            "acceptance_metrics": auction.get("acceptance_metrics"),
            "raw_flow_pressure": auction.get("raw_flow_pressure"),
            "activity_ratio": auction.get("activity_ratio"),
            "activity_ticks_60s": auction.get("activity_ticks_60s"),
            "activity_baseline_ticks_60s": auction.get("activity_baseline_ticks_60s"),
            "broker_offset_seconds": auction.get("broker_offset_seconds"),
            "final_edge": auction.get("raw_edge"),
            "confidence": auction.get("confidence"),
        },
        "admission": {
            "BUY": evaluate_directional_admission("BUY", dict(all_results), dict(config)),
            "SELL": evaluate_directional_admission("SELL", dict(all_results), dict(config)),
        },
        "map": {
            "ready": bool((all_results.get("session_plan") or {}).get("plan_ready")),
            "status": (all_results.get("session_plan") or {}).get("plan_status"),
            "side": (all_results.get("session_plan") or {}).get("session_bias"),
        },
        "decision": str((decision or {}).get("decision") or "WAIT"),
        "non_trading_measurement": True,
    }
    path = _path(config, now)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Single scheduled analysis owner writes this file. Last-line dedup avoids
    # repeated manual diagnostics for the same frozen snapshot.
    if path.exists():
        try:
            last = path.read_text(encoding="utf-8").splitlines()[-1]
            if str((json.loads(last) or {}).get("snapshot_id") or "") == snapshot_id:
                return path
        except Exception:
            pass
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    return path
