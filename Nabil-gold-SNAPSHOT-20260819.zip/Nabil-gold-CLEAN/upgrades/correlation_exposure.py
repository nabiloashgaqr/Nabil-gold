"""
upgrades/correlation_exposure.py — Cross-asset correlation & portfolio exposure manager.

Problem (the largest quant gap in the system):
  There is NO portfolio-level correlation control between XAU/USD and WTI/USD.
  Both instruments share risk-on/risk-off days; two "independent" 1% risks can
  silently become a 2% correlated loss day. Before WTI promotion (23/08 decision)
  this must exist. The existing scripts/agent_correlation_report.py measures
  correlation between AGENT VOTES, not between asset P&L.

Solution: a small, evidence-based manager:
  1. Rolling Pearson correlation on daily log returns (gold vs oil) — lookback configurable.
  2. Portfolio heat: correlation-weighted aggregate exposure = sqrt(w'Σw) style.
  3. Veto: opposite-direction positions on positively-correlated assets in
     risk-off regimes (safe-haven flow) are blocked above a configurable
     correlation threshold.
  4. Everything is advisory until `enforce` is enabled per-instrument (mirrors
     the WTI shadow promotion pattern already used in the repo).

Integration (mirrors existing patterns in scripts/run_analysis.py):
  from upgrades.correlation_exposure import CorrelationExposureManager
  corr = CorrelationExposureManager(config)
  verdict = corr.review(new_decision, open_trades)
  if verdict["action"] == "VETO":
      all_results["correlation_guard"] = verdict   # consumed by risk filters
      decision stays WAIT; telegram card carries the reason.

Tests: see upgrades/test_upgrades.py::TestCorrelationExposure
"""
from __future__ import annotations

import math
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List

import numpy as np


def _daily_log_returns(closes: List[float]) -> np.ndarray:
    c = np.asarray(closes, dtype=float)
    if len(c) < 3 or np.any(c <= 0):
        return np.array([])
    return np.diff(np.log(c))


class CorrelationExposureManager:
    def __init__(self, config: Dict[str, Any]):
        self.symbols = [str(i.get("symbol", "XAU/USD")) for i in config.get("instruments", [])]
        sec = config.get("correlation_guard", {}) or {}
        self.lookback_days = int(sec.get("lookback_days", 60))
        self.veto_correlation = float(sec.get("veto_correlation", 0.55))
        self.max_heat = float(sec.get("max_heat", 1.5))          # sqrt(w'Σw) cap
        self.enforce = bool(sec.get("enforce", False))           # False = advisory
        self.data_path = Path(
            sec.get("daily_closes_path", "storage/correlation/daily_closes.json")
        )

    # ---- data ----------------------------------------------------------------
    def _load_closes(self) -> Dict[str, List[float]]:
        if not self.data_path.exists():
            return {}
        import json

        return json.loads(self.data_path.read_text(encoding="utf-8"))

    def update_closes(self, symbol: str, today: str, close: float) -> None:
        """Called once per day by run_daily_report (append-only, dedup by date)."""
        data = self._load_closes()
        rows = data.setdefault(symbol, {})
        rows[today] = float(close)
        self.data_path.parent.mkdir(parents=True, exist_ok=True)
        self.data_path.write_text(
            __import__("json").dumps(data, indent=1), encoding="utf-8"
        )

    # ---- metrics -------------------------------------------------------------
    def correlation(self, a: str, b: str) -> float:
        data = self._load_closes()
        sa = [v for k, v in sorted(data.get(a, {}).items())][-self.lookback_days :]
        sb = [v for k, v in sorted(data.get(b, {}).items())][-self.lookback_days :]
        n = min(len(sa), len(sb))
        if n < 10:
            return 0.0  # not enough evidence — fail open (advisory mode)
        ra, rb = _daily_log_returns(sa[-n:]), _daily_log_returns(sb[-n:])
        ra, rb = ra[: n - 1], rb[: n - 1]
        if ra.std() == 0 or rb.std() == 0:
            return 0.0
        return float(np.corrcoef(ra, rb)[0, 1])

    def portfolio_heat(self, risk_per_trade: float = 0.01) -> Dict[str, Any]:
        """Correlation-weighted aggregate exposure sqrt(w'Σw) with equal risk weights."""
        data = self._load_closes()
        syms = [s for s in self.symbols if len(data.get(s, {})) >= 10]
        if len(syms) < 2:
            return {"heat": 1.0, "pairs": {}, "missing_data": True}
        closes = {
            s: [v for k, v in sorted(data[s].items())][-self.lookback_days :] for s in syms
        }
        n = min(len(v) for v in closes.values())
        rets = np.array([_daily_log_returns(closes[s][-n:])[: n - 1] for s in syms])
        corr_mat = np.corrcoef(rets)
        w = np.full(len(syms), 1.0 / len(syms))
        heat = float(math.sqrt(max(w @ corr_mat @ w, 1e-9)) / math.sqrt(max(w @ w, 1e-9)))
        pairs = {
            f"{syms[i]}<->{syms[j]}": float(corr_mat[i, j])
            for i in range(len(syms))
            for j in range(i + 1, len(syms))
        }
        return {"heat": heat, "pairs": pairs, "corr_matrix": corr_mat.tolist()}

    # ---- gate ------------------------------------------------------------------
    def review(self, decision: Dict[str, Any], open_trades: List[Dict[str, Any]]) -> Dict[str, Any]:
        if len(self.symbols) < 2:
            return {"action": "PASS", "reason": "single instrument"}
        target = str(decision.get("symbol") or self.symbols[0])
        others = [s for s in self.symbols if s != target]
        worst_corr = max((abs(self.correlation(target, o)), o) for o in others)

        opposing = []
        for t in open_trades:
            ts = str(t.get("symbol") or "")
            if ts in others and str(t.get("signal") or t.get("side") or "").upper() != str(
                decision.get("signal") or ""
            ).upper():
                opposing.append(t)

        heat = self.portfolio_heat().get("heat", 1.0)
        verdict = {
            "action": "PASS",
            "correlation": round(worst_corr[0], 3),
            "worst_pair": f"{target}<->{worst_corr[1]}",
            "portfolio_heat": round(heat, 3),
            "opposing_open_trades": len(opposing),
            "enforced": self.enforce,
        }
        if opposing and worst_corr[0] >= self.veto_correlation:
            verdict["action"] = "VETO" if self.enforce else "ADVISORY_VETO"
            verdict["reason"] = (
                f"Opposite {target} position against {len(opposing)} open trade(s) on "
                f"correlated asset (ρ={worst_corr[0]:.2f} ≥ {self.veto_correlation})"
            )
        elif heat > self.max_heat:
            verdict["action"] = "VETO" if self.enforce else "ADVISORY_VETO"
            verdict["reason"] = f"Portfolio heat {heat:.2f} exceeds cap {self.max_heat}"
        return verdict
