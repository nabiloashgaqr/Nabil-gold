"""
scripts/fill_oil_macro.py — auto-fill the oil macro operator files from the
free EIA API (2026-08-19 build 10, operator order: "fill the oil macro so it
works").

Requires a FREE API key from https://www.eia.gov/opendata/ (register, then
set EIA_API_KEY in .env or oil_macro.eia_api_key in config.json).

Fetches the weekly petroleum status (crude/gasoline/distillate stocks and
refinery utilization), writes storage/oil/eia_weekly.json and appends the
seasonal history to storage/oil/eia_history.json. Without a key the script
exits with a clear message - the agent still works via the automatic
crack-spread layer.

Usage:
  python scripts/fill_oil_macro.py            # fill now
  python scripts/fill_oil_macro.py --check    # dry-run: print, do not write
  python scripts/fill_oil_macro.py --root D:\\Nabil-gold
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

SERIES = {
    "crude": "PET.WCRSTUS1.W",
    "gasoline": "PET.WGTSTUS1.W",
    "distillate": "PET.WDISTUS1.W",
    "utilization": "PET.WPULEUS3.W",
}


def fetch_eia_weekly(api_key: str, timeout: int = 25) -> Dict[str, Any]:
    """Fetch the latest weekly petroleum status values. Returns
    {week, crude_change_mb, gasoline_change_mb, distillate_change_mb,
    refinery_util_pct}. Raises on API/network failure."""
    import requests

    params: List[Tuple[str, str]] = [
        ("frequency", "weekly"),
        ("data[0]", "value"),
        ("sort[0][column]", "period"),
        ("sort[0][direction]", "desc"),
        ("length", "3"),
        ("api_key", api_key),
    ]
    for series_id in SERIES.values():
        params.append(("facets[series][]", series_id))
    resp = requests.get(
        "https://api.eia.gov/v2/petroleum/stoc/wstk/data/",
        params=params, timeout=timeout,
    )
    resp.raise_for_status()
    payload = resp.json()
    series_data: Dict[str, List[List]] = {}
    for entry in (payload.get("response") or {}).get("data") or []:
        sid = entry.get("series")
        data = entry.get("data") or []
        if sid in SERIES.values():
            series_data[sid] = data

    def _change(series_id: str) -> Optional[float]:
        data = series_data.get(series_id) or []
        if len(data) < 2:
            return None
        v0 = float(data[0][1])
        v1 = float(data[1][1])
        return round((v0 - v1) / 1000.0, 1)  # thousand barrels -> mb

    crude = _change(SERIES["crude"])
    gasoline = _change(SERIES["gasoline"])
    distillate = _change(SERIES["distillate"])
    util_data = series_data.get(SERIES["utilization"]) or []
    util = float(util_data[0][1]) if util_data else None
    week = str((series_data.get(SERIES["crude"]) or [[None]])[0][0])
    if crude is None:
        raise ValueError("EIA response missing crude stocks series")
    return {
        "week": week,
        "crude_change_mb": crude,
        "gasoline_change_mb": gasoline,
        "distillate_change_mb": distillate,
        "refinery_util_pct": util,
        "source": "eia_api_auto",
    }


def apply_eia_payload(payload: Dict[str, Any], root: Path) -> Tuple[Path, Path]:
    """Write eia_weekly.json + append the seasonal history row. Returns paths."""
    eia_path = root / "storage" / "oil" / "eia_weekly.json"
    hist_path = root / "storage" / "oil" / "eia_history.json"
    eia_path.parent.mkdir(parents=True, exist_ok=True)
    eia_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    history: List[Dict[str, Any]] = []
    if hist_path.exists():
        try:
            history = json.loads(hist_path.read_text(encoding="utf-8"))
            if not isinstance(history, list):
                history = []
        except Exception:  # noqa: BLE001
            history = []
    week = str(payload.get("week") or "")
    if not any(isinstance(h, dict) and h.get("week") == week for h in history):
        history.append({"week": week, "crude_change_mb": payload.get("crude_change_mb")})
    hist_path.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")
    return eia_path, hist_path


def main() -> int:
    parser = argparse.ArgumentParser(description="Auto-fill oil macro from the free EIA API")
    parser.add_argument("--check", action="store_true", help="dry-run: print, do not write")
    parser.add_argument("--root", type=str, default=str(ROOT))
    args = parser.parse_args()
    root = Path(args.root)

    import os

    from utils.helpers import load_config

    config = load_config()
    oil_cfg = config.get("oil_macro") or {}
    api_key = str(
        oil_cfg.get("eia_api_key") or os.environ.get("EIA_API_KEY") or ""
    ).strip()
    if not api_key:
        print("NO EIA API KEY configured.")
        print("Get a FREE key at https://www.eia.gov/opendata/ then either:")
        print("  - set EIA_API_KEY in the .env file, or")
        print('  - set "oil_macro": {"eia_api_key": "..."} in config.json')
        print("")
        print("Until then the oil macro still works via the automatic")
        print("crack-spread layer (RB=F/HO=F vs CL=F) - no files needed.")
        return 1

    try:
        payload = fetch_eia_weekly(api_key)
    except Exception as exc:  # noqa: BLE001
        print(f"EIA fetch failed: {exc}")
        return 1

    print(f"week             : {payload['week']}")
    print(f"crude_change_mb  : {payload['crude_change_mb']}")
    print(f"gasoline_change  : {payload['gasoline_change_mb']}")
    print(f"distillate_change: {payload['distillate_change_mb']}")
    print(f"refinery_util    : {payload['refinery_util_pct']}")
    if args.check:
        print("DRY RUN - nothing written")
        return 0
    eia_path, hist_path = apply_eia_payload(payload, root)
    print(f"written: {eia_path}")
    print(f"history appended: {hist_path}")
    print("The oil macro now reads this file (plus the crack layer).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
