"""سكريبت تحديث الصفقات المفتوحة.

يعمل كل 5 دقائق عبر GitHub Actions. يجلب السعر الحالي، يمرر الصفقات المفتوحة
إلى OpenTradesManager، ثم يتم تحديث Supabase وإرسال تحديثات Telegram.
أحداث نقل الستوب / trailing / TP / SL تُرسل فوراً عند تشغيل هذا السكريبت ولا
تنتظر رسالة الـ heartbeat/الساعة.
✏️ يتحقق من ساعات التداول ويخرج إذا كان خارج الجلسات إلا إذا كان التحديث خارج
الساعات مفعلاً في config.
"""

from __future__ import annotations

# --- VPS: load .env if present (real env vars ALWAYS win over .env) ---
try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv()  # override=False: task-wrapper vars take precedence
except Exception:
    pass

import logging
import os
import sys
from datetime import datetime, timezone

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.news_risk_agent import NewsRiskAgent
from agents.open_trades_manager import OpenTradesManager
from agents.trading_session_agent import TradingSessionAgent
from services.database import DatabaseService
from services.market_data import MarketDataService
from services.telegram_bot import TelegramService
from utils.helpers import calculate_pips, load_config, setup_logging
from utils.instruments import config_for_instrument, normalize_symbol

setup_logging()
logger = logging.getLogger(__name__)


def _payload_supports_signal_generation(payload) -> bool:
    if not payload:
        return False
    if isinstance(payload, dict) and payload.get("supports_signal_generation") is not None:
        return bool(payload.get("supports_signal_generation"))
    return str((payload or {}).get("source") or "") == "twelvedata"


def _payload_supports_pending_activation(payload) -> bool:
    if not payload:
        return False
    if isinstance(payload, dict) and payload.get("supports_pending_activation") is not None:
        return bool(payload.get("supports_pending_activation"))
    return str((payload or {}).get("source") or "") == "twelvedata"


def _short_id(trade_id: str) -> str:
    """Compact, readable trade id: keep the date + last hex chunk.

    TRADE_20260623_120035_726925_7cf3f415 -> #7cf3f415
    Falls back to the last 8 chars if the format differs.
    """
    s = str(trade_id or "")
    if not s:
        return "#?"
    parts = s.split("_")
    last = parts[-1]
    if len(parts) > 1 and len(last) >= 4:
        return f"#{last}"
    # Single chunk (or too-short tail): use the last 8 characters.
    return f"#{s[-8:]}"


def _build_status_message(open_trades, evaluations, current_price: float) -> str:
    """Build a SHORT hourly status with live trades separated from pending orders."""
    import html as _html

    now_txt = datetime.now(timezone.utc).strftime("%H:%M UTC")
    if not open_trades:
        return (
            "🔄 <b>Trade Update</b> · " + now_txt + "\n"
            f"Price {current_price:.2f}\n"
            "📭 No open trades."
        )

    by_id = {str(ev.get("trade_id")): ev for ev in (evaluations or [])}
    live_statuses = {"OPEN", "PARTIAL", "TP1_HIT"}
    pending_statuses = {"PENDING"}
    live_trades = [t for t in open_trades if str(t.get("status") or "OPEN").upper() in live_statuses]
    pending_trades = [t for t in open_trades if str(t.get("status") or "").upper() in pending_statuses]

    headline_parts = []
    if live_trades:
        headline_parts.append(f"{len(live_trades)} open")
    if pending_trades:
        headline_parts.append(f"{len(pending_trades)} pending")
    lines = [
        f"🔄 <b>Trade Update</b> · {now_txt}",
        f"Price {current_price:.2f} · {' / '.join(headline_parts) if headline_parts else '0 active'}",
        "───────────────",
    ]

    net_points = 0.0
    for t in live_trades[:20]:
        tid = str(t.get("id", ""))
        ev = by_id.get(tid, {})
        direction = str(t.get("type") or t.get("side") or "BUY").upper()
        pnl = float(ev.get("pnl_points", 0) or 0)
        net_points += pnl
        usd = pnl / 10.0
        sign = "🟢" if pnl > 0 else "🔴" if pnl < 0 else "➖"
        prog = ev.get("progress_to_tp1")
        prog_txt = ""
        if prog is not None:
            try:
                prog_txt = f" · {float(prog) * 100:.0f}%➜TP1"
            except (TypeError, ValueError):
                prog_txt = ""
        status = str(ev.get("new_status") or t.get("status") or "OPEN")
        status_txt = "" if status == "OPEN" else f" [{_html.escape(status)}]"
        lines.append(
            f"{sign} {direction:<4} <code>{_short_id(tid)}</code>  "
            f"{pnl:+.0f} pts ({usd:+.1f}$){prog_txt}{status_txt}"
        )
    if len(live_trades) > 20:
        lines.append(f"… and {len(live_trades) - 20} more")
    if live_trades:
        net_usd = net_points / 10.0
        net_emoji = "🟢" if net_points > 0 else "🔴" if net_points < 0 else "➖"
        lines.append("───────────────")
        lines.append(f"{net_emoji} <b>Net:</b> {net_points:+.0f} pts ({net_usd:+.1f}$)")

    if pending_trades:
        if live_trades:
            lines.append("───────────────")
        lines.append(f"⏳ <b>Pending Orders ({len(pending_trades)})</b>")
        for t in pending_trades[:20]:
            tid = str(t.get("id", ""))
            ev = by_id.get(tid, {})
            direction = str(t.get("type") or t.get("side") or "BUY").upper()
            entry = float(t.get("entry_price") or 0)
            order_type = str(t.get("order_type") or t.get("order_kind") or "PENDING").upper()
            pts_to_fill = ev.get("pending_distance_points")
            if pts_to_fill is None:
                pts_to_fill = abs(calculate_pips(current_price, entry, trade_type=direction, symbol=str(t.get("symbol") or "XAU/USD")))
            hours_open = ev.get("hours_open")
            if hours_open is None:
                try:
                    opened = datetime.fromisoformat(str(t.get("entry_time") or t.get("created_at") or "").replace("Z", "+00:00"))
                    if opened.tzinfo is None:
                        opened = opened.replace(tzinfo=timezone.utc)
                    hours_open = max(0.0, (datetime.now(timezone.utc) - opened.astimezone(timezone.utc)).total_seconds() / 3600.0)
                except Exception:
                    hours_open = None
            age_txt = f"waiting {float(hours_open):.1f}h" if hours_open is not None else "waiting"
            lines.append(f"🟡 {direction:<4} <code>{_short_id(tid)}</code>  @ {entry:.2f} [{_html.escape(order_type)}] · {float(pts_to_fill):.0f} pts to fill · {age_txt}")
        if len(pending_trades) > 20:
            lines.append(f"… and {len(pending_trades) - 20} more")
    return "\n".join(lines)




def _cap_refusal(last_error: str) -> bool:
    """2026-08-19: True when the executor refused because the daily order cap
    is reached. The retry loop must NOT leave these rows OPEN forever."""
    if not last_error:
        return False
    s = str(last_error).lower()
    return ("daily order cap" in s) or ("order cap reached" in s) or ("daily cap" in s)


def _is_market_entry(row: dict) -> bool:
    order = str(row.get("order_type") or row.get("order_kind") or "").upper()
    return bool(order) and "MARKET" in order


def _cancel_cap_phantom(database, tid: str, telegram) -> None:
    """Mark a market entry that the daily cap refused as CANCELLED.

    A market signal that could not be placed in its cycle is stale by the
    next cycle; retrying it would silently trade a different price. LIMIT
    rows are price-anchored and keep retrying (the cap resets at midnight).
    """
    try:
        database.update_trade(tid, {
            "status": "CANCELLED",
            "result": "CANCELLED",
            "exit_warning": "daily order cap reached - market signal expired (never placed)",
        })
        if telegram:
            try:
                telegram.send_error_alert(
                    f"Daily cap: market entry {tid} cancelled (never placed)"
                )
            except Exception:  # noqa: BLE001
                pass
    except Exception:  # noqa: BLE001
        logger.warning("cap-phantom cancel failed for %s", tid)


def _sync_demo_execution(config, symbol_config, symbol, symbol_trades,
                         symbol_evals, database, telegram) -> None:
    """demo/mt5 branch (phase 1): transmit unified-law levels to MT5 demo.

    Paper mode (default) returns immediately; the executor only TRANSMITS
    levels already decided by the management engine and the unified loader.
    """
    mode = str(os.environ.get("EXECUTION_MODE")
               or (config.get("execution") or {}).get("execution_mode") or "paper")
    if mode != "mt5_demo":
        return
    try:
        from services.mt5_executor import Mt5DemoExecutor
        executor = Mt5DemoExecutor(symbol_config, telegram=telegram)
        if not executor.alive() or executor.halted():
            return
        rows_by_id = {str(t.get("id")): t for t in symbol_trades}
        for ev in symbol_evals or []:
            tid = str(ev.get("trade_id") or "")
            row = rows_by_id.get(tid) or {}
            side = str(row.get("type") or row.get("side") or "")
            events = set(ev.get("events") or [])
            updates = ev.get("updates") or {}
            ticket = row.get("mt5_ticket")
            if not ticket and ev.get("new_status") in {"OPEN", "PENDING"}:
                ticket = executor.ensure_ticket(
                    tid, side, str(row.get("order_type") or "MARKET"),
                    float(row.get("entry_price") or 0),
                    float(updates.get("stop_loss") or row.get("stop_loss") or 0),
                    float(row.get("tp2") or row.get("tp1") or 0), symbol)
                if ticket and hasattr(database, "update_trade"):
                    try:
                        database.update_trade(tid, {"mt5_ticket": ticket})
                    except Exception:  # noqa: BLE001
                        pass
                elif ticket is None and _cap_refusal(executor.last_error) and _is_market_entry(row):
                    # 2026-08-19: the daily cap blocked a MARKET entry. It is
                    # stale by the next cycle - close it instead of leaving a
                    # phantom OPEN row that can never be placed today.
                    _cancel_cap_phantom(database, tid, telegram)
                    continue
            if not ticket:
                continue
            if "TP1_HIT" in events:
                executor.partial_close_at_tp1(tid, 0.5, symbol)
            new_sl = updates.get("stop_loss")
            if new_sl:
                executor.apply_stop(tid, float(new_sl),
                                    float(row.get("tp2") or 0), symbol)
        open_rows = [t for t in (database.get_open_trades() or [])
                     if normalize_symbol(str(t.get("symbol") or "")) == normalize_symbol(symbol)]
        mism = executor.reconcile(open_rows)
        if mism:
            logger.error("Demo reconciliation mismatches: %s", mism)
    except Exception as exc:  # noqa: BLE001 - demo must never kill paper
        logger.warning("Demo sync skipped: %s", exc)


def main() -> None:
    """تحديث الصفقات المفتوحة."""
    # Weekend hard gate (operator directive 2026-08-09): Sat/Sun = no updates.
    from utils.helpers import is_weekend_hebron
    if is_weekend_hebron():
        logger.info("Weekend (Sat/Sun Hebron) — trade updates skipped by operator directive.")
        return
    logger.info("Starting trade updates: %s", datetime.now(timezone.utc).isoformat())
    config = load_config()

    # ── فحص ساعات التداول ──
    session = TradingSessionAgent(config).check()
    logger.info(
        "🔍 Session: %s | Quality: %s | Allowed: %s",
        session.get("current_session") or "خارج Session",
        session.get("session_quality", "N/A"),
        session.get("trading_allowed"),
    )

    update_outside_hours = bool(config.get("trade_management", {}).get("update_outside_trading_hours", False))
    force_update = os.environ.get("FORCE_TRADE_UPDATE", "false").lower() in {"1", "true", "yes"}
    if not session.get("trading_allowed") and not update_outside_hours and not force_update:
        logger.info(
            "🚫 Outside trade update hours (%s) - No update. Reason: %s",
            session.get("current_session") or "غير محدد",
            session.get("reason", ""),
        )
        return  # ══ لا تحديث خارج الجلسات إلا عند FORCE_TRADE_UPDATE ══
    if not session.get("trading_allowed") and (update_outside_hours or force_update):
        logger.info(
            "ℹ️ Outside normal update hours, but continuing due to update_outside_trading_hours or FORCE_TRADE_UPDATE"
        )

    try:
        telegram = TelegramService(config)
        database = DatabaseService(config)

        # Critical quota/cost optimization: do not fetch market data, initialize
        # trade management, or consume Twelve Data calls when there is no active
        # trade/pending order to manage. This still starts a tiny GitHub workflow
        # when triggered externally, but the workflow pre-check should normally
        # skip the heavy steps before Python dependencies are installed.
        open_trades = database.get_open_trades()
        logger.info("Active/pending trades count: %s", len(open_trades))
        # Shadow books are managed by THIS cycle (the tick manager never sees
        # them), so an empty LIVE book alone must not end the run while a
        # shadow instrument still has open/pending rows to manage.
        try:
            from services.shadow_mode import shadow_open_trades as _shadow_open
            _shadow_pending = _shadow_open(config)
        except Exception:  # noqa: BLE001
            _shadow_pending = {}
        if not open_trades and not _shadow_pending:
            logger.info("لا توجد صفقات مفتوحة أو أوامر معلقة — skipping تحديث الصفقات بدون Telegram وبدون جلب سعر.")
            return
        if not open_trades and _shadow_pending:
            logger.info("Live book empty; continuing for shadow book(s): %s",
                        {k: len(v) for k, v in _shadow_pending.items()})

        # In the consolidated end-of-day digest, suppress this script's own
        # Telegram messages (trade events + confirmation). DB updates still run;
        # the daily report aggregates everything into one message. We achieve
        # this by passing telegram=None to the manager so it sends nothing.
        eod_quiet = os.environ.get("EOD_QUIET", "").lower() in {"1", "true", "yes"}
        telegram_for_events = None if eod_quiet else telegram

        # Group active trades by symbol and fetch each market price separately.
        # This is mandatory now that the bot supports Gold, FX pairs, and WTI.
        grouped: dict[str, list] = {}
        for trade in open_trades:
            symbol = normalize_symbol(trade.get("symbol") or config.get("symbol", "XAU/USD"))
            grouped.setdefault(symbol, []).append(trade)

        if (os.environ.get("EXECUTION_MODE") == "mt5_demo"
                and os.environ.get("TICK_MANAGER", "true").lower() in {"1", "true", "yes"}):
            logger.info("Tick manager owns MT5 execution; the 5m cycle keeps "
                        "bookkeeping/reporting only.")
            grouped = {}
        evaluations = []
        current_price = 0.0
        for symbol, symbol_trades in grouped.items():
            symbol_config = config_for_instrument(config, {"symbol": symbol})
            market_data = MarketDataService(symbol_config)
            manager = OpenTradesManager(symbol_config)

            # Use the SAME base timeframe as analysis (5m) to benefit from
            # the 60-second cache. We intentionally fetch MORE than 6 candles
            # here because the trade manager now computes a rolling "recent 30m"
            # range from the last 6 x 5m candles. Requesting only 5 candles was
            # insufficient and could miss one candle from the intended window.
            base_tf = symbol_config.get("data_source", {}).get("base_timeframe", "5m")
            price_payload = market_data.get_ohlcv(base_tf, outputsize=12)
            allow_synthetic = bool(symbol_config.get("data_source", {}).get("allow_synthetic_in_production", False))
            if os.environ.get("GITHUB_ACTIONS") == "true" and not _payload_supports_signal_generation(price_payload) and price_payload.get("source") == "synthetic_demo" and not allow_synthetic:
                # For trade management only, try a live XAU/USD spot quote before
                # giving up. This does not provide historical candles for
                # analysis, but it is safer than stopping SL/TP management and
                # safer than using GC=F futures as a proxy.
                quote_payload = market_data.get_spot_quote_payload()
                if quote_payload:
                    logger.warning("Using Swissquote spot quote fallback for %s trade updates", symbol)
                    price_payload = quote_payload
                else:
                    logger.error("Trade updates stopped for %s: all real data sources failed", symbol)
                    telegram.send_error_alert(
                        "Trade updates stopped: all real data sources failed "
                        "(Twelve Data quota/key and Swissquote spot quote unavailable)"
                    )
                    continue
            symbol_price = price_payload.get("current_price")
            if not symbol_price:
                logger.error("Failed to fetch price for symbol %s", symbol)
                continue
            current_price = float(symbol_price)
            # Check news hard-block for pending-order activation logic.
            try:
                news_cfg = {**symbol_config, "macro_context": database.get_macro_context()} if hasattr(database, 'get_macro_context') else symbol_config
                news_result = NewsRiskAgent(news_cfg).check()
            except Exception:
                news_result = {}
            news_blocked = bool(news_result.get("can_trade") is False or str(news_result.get("market_status", "")).upper() in {"DANGER", "HIGH_VOLATILITY"})
            # ── Global price sanity: reject obviously corrupt ticks ──
            # XAU/USD realistic range: 2500-5500. WTI: 30-150.
            # Anything outside this is a data provider glitch.
            _sane_min = 2500.0 if symbol.startswith("XAU") else 30.0
            _sane_max = 5500.0 if symbol.startswith("XAU") else 150.0
            if current_price < _sane_min or current_price > _sane_max:
                logger.error(
                    "PRICE SANITY FAILED (global): %s current_price=%.2f outside range [%.0f-%.0f]. Skipping trade updates this cycle.",
                    symbol, current_price, _sane_min, _sane_max,
                )
                if not eod_quiet:
                    telegram.send_error_alert(
                        f"Trade updates skipped for {symbol}: corrupted price {current_price:.2f} "
                        f"(expected {_sane_min:.0f}-{_sane_max:.0f}). Data provider glitch."
                    )
                continue
            latest_candle = (price_payload.get("data") or [{}])[-1] or {}
            recent_candles = (price_payload.get("data") or [])[-6:]
            try:
                candle_high = float(latest_candle.get("high") or current_price)
                candle_low = float(latest_candle.get("low") or current_price)
            except (TypeError, ValueError):
                candle_high = current_price
                candle_low = current_price
            # The candle's own timestamp travels with its extremes: the manager
            # refuses fills/stop-outs from a bar older than the freshness
            # window, and never lets a bar that predates an order fill it.
            candle_time = str(latest_candle.get("time") or "") or None
            if not _payload_supports_pending_activation(price_payload) and any(str(t.get("status") or "").upper() == "PENDING" for t in symbol_trades):
                integrity = price_payload.get("source_integrity") or {}
                logger.warning(
                    "Pending touch detection degraded for %s: source=%s type=%s grade=%s. Pending orders will wait for a real candle source before activation.",
                    symbol,
                    integrity.get("source") or price_payload.get("source"),
                    integrity.get("source_type") or "unknown",
                    integrity.get("reliability_grade") or "UNKNOWN",
                )
            # Activation book gate (operator 2026-08-18): hand the manager
            # the freshest agent book so a pending that price touches is
            # checked against the CURRENT vote, not the one from placement
            # time. A missing/stale book passes None and the gate fails open.
            _activation_book = None
            try:
                from services.agent_book_store import load_agent_book
                _activation_book = load_agent_book(symbol)
            except Exception as _book_exc:  # noqa: BLE001
                logger.warning("Agent book load failed for %s (gate fails open): %s", symbol, _book_exc)
            _before_eval = len(evaluations)
            evaluations.extend(manager.update_trades(
                open_trades=symbol_trades,
                current_price=current_price,
                candle_high=candle_high,
                candle_low=candle_low,
                recent_candles=recent_candles,
                database=database,
                telegram=telegram_for_events,
                now=datetime.now(timezone.utc),
                news_blocked=news_blocked,
                news_context=news_result,
                market_data_source=str(price_payload.get("source") or ""),
                candle_time=candle_time,
                agent_details=_activation_book,
            ))
            _sync_demo_execution(
                config, symbol_config, symbol, symbol_trades,
                evaluations[_before_eval:], database, telegram_for_events)
        # ── Shadow instruments (operator 2026-08-16) ────────────────────────
        # Shadow books live outside the live trade book, so the tick manager
        # never manages them. This 5-minute cycle applies the SAME
        # OpenTradesManager laws (pending touch, TP1 partial, trailing,
        # breakeven, thesis exit) to every shadow trade using real MT5
        # candles, and reports through the shadow-branded Telegram. A broken
        # shadow instrument must never break gold: everything is wrapped.
        try:
            from services.shadow_mode import (
                shadow_database as _shadow_db_factory,
                shadow_instruments as _shadow_instruments,
                shadow_telegram as _shadow_tg_factory,
            )
            for _inst in _shadow_instruments(config):
                _sym = normalize_symbol(_inst.get("symbol"))
                _sym_cfg = config_for_instrument(config, _inst)
                _sdb = _shadow_db_factory(_sym_cfg)
                _srows = _sdb.get_open_trades() or []
                if not _srows:
                    continue
                _stg = None if eod_quiet else _shadow_tg_factory(_sym_cfg)
                _smd = MarketDataService(_sym_cfg)
                _sbase_tf = _sym_cfg.get("data_source", {}).get("base_timeframe", "5m")
                _spayload = _smd.get_ohlcv(_sbase_tf, outputsize=12)
                _sprice = float(_spayload.get("current_price") or 0)
                if _sprice <= 0:
                    logger.warning("Shadow %s: no price this cycle; skipped", _sym)
                    continue
                _slast = (_spayload.get("data") or [{}])[-1] or {}
                try:
                    _shigh = float(_slast.get("high") or _sprice)
                    _slow = float(_slast.get("low") or _sprice)
                except (TypeError, ValueError):
                    _shigh = _slow = _sprice
                _sevals = OpenTradesManager(_sym_cfg).update_trades(
                    open_trades=_srows,
                    current_price=_sprice,
                    candle_high=_shigh,
                    candle_low=_slow,
                    recent_candles=(_spayload.get("data") or [])[-6:],
                    database=_sdb,
                    telegram=_stg,
                    now=datetime.now(timezone.utc),
                    news_blocked=False,
                    news_context={},
                    market_data_source=str(_spayload.get("source") or ""),
                    candle_time=str(_slast.get("time") or "") or None,
                )
                for _ev in _sevals or []:
                    if _ev.get("events"):
                        logger.info(
                            "SHADOW %s update %s: %s | %s -> %s | PnL=%s",
                            _sym, _ev.get("trade_id"),
                            ",".join(_ev.get("events", [])),
                            _ev.get("old_status"), _ev.get("new_status"),
                            _ev.get("pnl_points"),
                        )
        except Exception:  # noqa: BLE001 - shadow must never break the live cycle
            logger.exception("Shadow instrument update block failed (live flow unaffected)")

        total_events = 0
        for evaluation in evaluations:
            if evaluation.get("events"):
                total_events += len(evaluation.get("events", []))
                logger.info(
                    "Trade update %s: %s | %s -> %s | PnL=%s",
                    evaluation.get("trade_id"),
                    ",".join(evaluation.get("events", [])),
                    evaluation.get("old_status"),
                    evaluation.get("new_status"),
                    evaluation.get("pnl_points"),
                )

        # ── Hourly heartbeat / status message ───────────────────────────────
        # CRITICAL FIX: We deliberately suppress the "Trades Update" heartbeat
        # when there are **zero open trades** on scheduled runs.
        #
        # Reason: It was sending useless "📭 No open trades." messages that
        # collided in time with the much more useful "Market Status" from
        # the analysis script (which already explains WAIT + reasons + Daily Bias).
        #
        # New rule:
        # - Always send on manual runs (workflow_dispatch)
        # - On scheduled runs: ONLY send if there is at least 1 open trade
        manual = os.environ.get("GITHUB_EVENT_NAME") == "workflow_dispatch" or force_update
        notif = config.get("notifications", {}) or {}
        heartbeat = bool(notif.get("heartbeat_on_trade_update", True))
        notify_updates = bool(notif.get("notify_on_trade_update", False))

        heartbeat_interval = int(notif.get("heartbeat_interval_minutes", 60) or 60)
        if manual:
            heartbeat_due = True
        elif heartbeat_interval <= 30:
            heartbeat_due = True
        else:
            heartbeat_due = datetime.now(timezone.utc).minute < 30

        has_open_trades = len(open_trades) > 0

        # Only send the optional "Trades Update" heartbeat when explicitly
        # enabled. It must NOT be forced by a manual run: the production rule is
        # "message only on real change" (SL moved / trailing moved / TP / SL / BE
        # / order fill). Those event messages are already sent above by
        # OpenTradesManager. With heartbeat_on_trade_update=false and
        # notify_on_trade_update=false, no Telegram message is sent when there is
        # no trade-state change.
        should_send = (
            (notify_updates or (heartbeat and has_open_trades))
            and heartbeat_due
            and total_events == 0
            and not eod_quiet
        )

        if should_send:
            telegram.send_message(
                _build_status_message(open_trades, evaluations, float(current_price))
            )

        logger.info("Trade update completed (events=%s, open=%s)", total_events, len(open_trades))
    except Exception as exc:  # noqa: BLE001
        logger.exception("Update error: %s", exc)


if __name__ == "__main__":
    main()
