"""2026-08-19 build 10: crack-spread oil layer + EIA auto-fill + measurement ON."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import agents.oil_macro_agent as oma  # noqa: E402
import scripts.fill_oil_macro as fm  # noqa: E402


def _series(start: float, step: float, n: int = 60) -> list:
    return [start + step * i for i in range(n)]


class TestCrackComponent:
    def _agent(self):
        return oma.OilMacroAgent({"oil_macro": {"enabled": True, "crack_enabled": True}})

    def test_widening_cracks_bullish(self, monkeypatch):
        mapping = {
            "CL=F": _series(70.0, 0.02),       # crude roughly flat
            "RB=F": _series(95.0, 0.25),       # gasoline rising fast -> crack widens
            "HO=F": _series(90.0, 0.20),       # distillate rising -> crack widens
        }
        monkeypatch.setattr(oma, "yf_closes", lambda sym, *a, **k: mapping.get(sym))
        points, reasons = self._agent()._crack_component()
        assert points == 1.0
        assert any("Gasoline crack widening" in r for r in reasons)
        assert any("Distillate crack widening" in r for r in reasons)

    def test_narrowing_cracks_bearish(self, monkeypatch):
        mapping = {
            "CL=F": _series(70.0, 0.30),       # crude rising
            "RB=F": _series(95.0, 0.05),       # products lagging -> crack narrows
            "HO=F": _series(90.0, 0.03),
        }
        monkeypatch.setattr(oma, "yf_closes", lambda sym, *a, **k: mapping.get(sym))
        points, _ = self._agent()._crack_component()
        assert points == -1.0

    def test_disabled_returns_zero(self, monkeypatch):
        agent = oma.OilMacroAgent({"oil_macro": {"enabled": True, "crack_enabled": False}})
        monkeypatch.setattr(oma, "yf_closes", lambda *a, **k: _series(70.0, 0.1))
        points, reasons = agent._crack_component()
        assert points == 0.0 and reasons == []

    def test_missing_data_fails_open(self, monkeypatch):
        monkeypatch.setattr(oma, "yf_closes", lambda *a, **k: None)
        points, reasons = self._agent()._crack_component()
        assert points == 0.0 and reasons == []

    def test_crack_feeds_analyze_score(self, monkeypatch, tmp_path):
        cfg = {"oil_macro": {"enabled": True, "crack_enabled": True,
                             "eia_path": str(tmp_path / "eia.json"),
                             "eia_history_path": str(tmp_path / "hist.json"),
                             "opec_path": str(tmp_path / "opec.json")}}
        mapping = {"CL=F": _series(70.0, 0.02), "RB=F": _series(95.0, 0.25),
                   "HO=F": _series(90.0, 0.20), "BZ=F": _series(75.0, 0.02)}
        monkeypatch.setattr(oma, "yf_closes", lambda sym, *a, **k: mapping.get(sym))
        r = oma.OilMacroAgent(cfg).analyze({"symbol": "WTI/USD"})
        # no EIA/OPEC files: crack is the only component -> direction BUY
        assert r["direction"] == "BUY"
        assert r["confidence"] > 0
        assert r["signal"] == "WAIT"  # never votes


class TestFillOilMacro:
    class FakeResp:
        def __init__(self, payload):
            self._payload = payload

        def raise_for_status(self):
            pass

        def json(self):
            return self._payload

    def _response(self):
        return {
            "response": {"data": [
                {"series": "PET.WCRSTUS1.W", "data": [["2026-08-14", 426000], ["2026-08-07", 430000]]},
                {"series": "PET.WGTSTUS1.W", "data": [["2026-08-14", 221000], ["2026-08-07", 219000]]},
                {"series": "PET.WDISTUS1.W", "data": [["2026-08-14", 120000], ["2026-08-07", 120500]]},
                {"series": "PET.WPULEUS3.W", "data": [["2026-08-14", 92.3], ["2026-08-07", 91.0]]},
            ]}
        }

    def test_fetch_math(self, monkeypatch):
        import requests
        monkeypatch.setattr(requests, "get", lambda *a, **k: self.FakeResp(self._response()))
        payload = fm.fetch_eia_weekly("TESTKEY")
        assert payload["week"] == "2026-08-14"
        assert payload["crude_change_mb"] == -4.0      # (426000-430000)/1000
        assert payload["gasoline_change_mb"] == 2.0
        assert payload["distillate_change_mb"] == -0.5
        assert payload["refinery_util_pct"] == 92.3

    def test_apply_writes_and_dedupes_history(self, tmp_path):
        payload = {"week": "2026-08-14", "crude_change_mb": -4.0,
                   "gasoline_change_mb": 2.0, "distillate_change_mb": -0.5,
                   "refinery_util_pct": 92.3, "source": "eia_api_auto"}
        eia_path, hist_path = fm.apply_eia_payload(payload, tmp_path)
        assert json.loads(eia_path.read_text(encoding="utf-8"))["crude_change_mb"] == -4.0
        hist = json.loads(hist_path.read_text(encoding="utf-8"))
        assert len(hist) == 1
        # second apply with same week: no duplicate
        fm.apply_eia_payload(payload, tmp_path)
        hist2 = json.loads(hist_path.read_text(encoding="utf-8"))
        assert len(hist2) == 1

    def test_api_error_raises(self, monkeypatch):
        def boom(*a, **k):
            raise ConnectionError("down")

        import requests
        monkeypatch.setattr(requests, "get", boom)
        import pytest

        with pytest.raises(ConnectionError):
            fm.fetch_eia_weekly("TESTKEY")


class TestConfigBuild10:
    def test_measurement_restarted_and_crack_on(self):
        cfg_path = Path(__file__).resolve().parents[1] / "config.json"
        prod = json.loads(cfg_path.read_text(encoding="utf-8"))
        assert (prod.get("agent_measurement") or {}).get("enabled") is True
        om = prod.get("oil_macro") or {}
        assert om.get("crack_enabled") is True
        assert om.get("eia_api_key_env") == "EIA_API_KEY"
