"""Shadow-mode WTI onboarding (operator 2026-08-16).

The promises pinned here:

1. WTI/USD is enabled as a SHADOW instrument with broker symbol WTI.s and
   runs the same pipeline as gold (agents, admission paths, planner, risk).
2. A shadow cycle can NEVER reach execution: demo_execution is forced off,
   the ShadowDatabase writes only under storage/shadow/, and Supabase stays
   disabled even when credentials exist.
3. The live gold book and the shadow book are physically separate files.
4. Every shadow Telegram message carries the SHADOW banner and is never
   urgent.
5. The canonical trading laws are expressed in OIL points for WTI (stop law
   60/21/120, trailing 70/25, BE 70, post-TP2 75) while gold keeps
   200/70/400 and 150/40/150 — same ratios, right scale.
6. The tick manager's execution feed reads only the LIVE book, so shadow
   rows can never be placed on MT5.
"""
from __future__ import annotations

import json

from services.shadow_mode import (
    ShadowDatabase,
    ShadowTelegram,
    is_shadow_config,
    shadow_instruments,
    shadow_paths,
)
from utils.helpers import load_config
from utils.instruments import config_for_instrument, enabled_instruments, normalize_symbol
from utils.trading_rules import stop_rule

CONFIG = load_config()


def _wti_config():
    for inst in enabled_instruments(CONFIG):
        if normalize_symbol(inst.get("symbol")) == "WTI/USD":
            return config_for_instrument(CONFIG, inst)
    raise AssertionError("WTI/USD not enabled in config")


def _gold_config():
    for inst in enabled_instruments(CONFIG):
        if normalize_symbol(inst.get("symbol")) == "XAU/USD":
            return config_for_instrument(CONFIG, inst)
    raise AssertionError("XAU/USD not enabled in config")


# ── 1. enrolment ────────────────────────────────────────────────────────────

def test_wti_promoted_to_live_with_broker_symbol():
    # 2026-08-19 (build 9, operator order): WTI promoted from shadow to LIVE
    # mt5_demo. The broker symbol mapping stays.
    insts = {normalize_symbol(i.get("symbol")): i for i in enabled_instruments(CONFIG)}
    assert "WTI/USD" in insts
    assert "mode" not in insts["WTI/USD"]  # promotion = remove the mode key
    assert "mode" not in insts["XAU/USD"]
    sm = ((CONFIG.get("execution") or {}).get("demo") or {}).get("symbol_map") or {}
    assert sm.get("WTI/USD") == "WTI.s"
    assert sm.get("XAU/USD") == "XAUUSD.s"
    assert [i["symbol"] for i in shadow_instruments(CONFIG)] == []


def test_shadow_flag_travels_through_config_for_instrument():
    # 2026-08-19: production instruments are live now; the shadow helper is
    # proven with a synthetic per-instrument config carrying mode=shadow.
    assert is_shadow_config(_wti_config()) is False
    assert is_shadow_config(_gold_config()) is False
    synthetic = dict(_wti_config())
    synthetic["instrument"] = dict(synthetic.get("instrument") or {})
    synthetic["instrument"]["mode"] = "shadow"
    assert is_shadow_config(synthetic) is True


# ── 2 + 3. isolation ────────────────────────────────────────────────────────

def test_shadow_database_writes_only_under_the_shadow_tree(tmp_path, monkeypatch):
    monkeypatch.setenv("NABIL_SHADOW_DIR", str(tmp_path))
    cfg = _wti_config()
    db = ShadowDatabase(cfg)
    assert db.use_supabase is False and db.client is None
    assert str(tmp_path) in str(db.local_path)
    assert str(tmp_path) in str(db.session_plans_path)
    assert str(tmp_path) in str(db.decision_audit_path)

    trade_id = db.save_trade({
        "decision": "BUY", "symbol": "WTI/USD", "confidence": 70,
        "current_price": 81.60,
        "signal": {"type": "BUY", "entry": {"price": 81.60}, "stop_loss": 80.40,
                   "tp1": 82.20, "tp2": 83.00, "entry_kind": "MARKET"},
    })
    assert trade_id
    rows = json.loads(db.local_path.read_text(encoding="utf-8"))
    assert len(rows) == 1 and rows[0]["symbol"] == "WTI/USD"
    # The LIVE book path was never touched by this write.
    from services.database import DatabaseService
    live = DatabaseService(cfg)
    assert str(live.local_path) != str(db.local_path)


def test_shadow_database_ignores_supabase_credentials(monkeypatch, tmp_path):
    monkeypatch.setenv("NABIL_SHADOW_DIR", str(tmp_path))
    monkeypatch.setenv("SUPABASE_URL", "https://example.supabase.co")
    monkeypatch.setenv("SUPABASE_KEY", "fake-key-for-test")
    db = ShadowDatabase(_wti_config())
    assert db.use_supabase is False
    assert db.client is None


# ── 4. telegram branding ────────────────────────────────────────────────────

def test_shadow_telegram_brands_and_never_pages(monkeypatch):
    tg = ShadowTelegram(_wti_config())
    captured = {}

    def _fake_parent_send(self, text, urgent=False, chat_id=None):
        captured["text"] = text
        captured["urgent"] = urgent
        return True

    from services.telegram_bot import TelegramService
    monkeypatch.setattr(TelegramService, "send_message", _fake_parent_send)
    assert tg.send_message("BUY signal body", urgent=True) is True
    assert "SHADOW WTI/USD" in captured["text"]
    assert captured["text"].splitlines()[0].startswith("\U0001F9EA")
    assert captured["urgent"] is False  # shadow never pages


# ── 5. instrument-scale laws ────────────────────────────────────────────────

def test_wti_trading_laws_are_oil_scale_and_gold_is_untouched():
    wti = _wti_config()
    gold = _gold_config()
    ws = stop_rule(wti)
    gs = stop_rule(gold)
    assert (ws["min_liquidity_points"], ws["safety_buffer_points"], ws["max_stop_points"]) == (60, 21, 120)
    assert (gs["min_liquidity_points"], gs["safety_buffer_points"], gs["max_stop_points"]) == (200, 70, 400)
    wt = (wti.get("trading_rules") or {}).get("trailing") or {}
    gt = (gold.get("trading_rules") or {}).get("trailing") or {}
    assert (wt.get("distance_points"), wt.get("step_points"), wt.get("early_breakeven_points")) == (70, 25, 70)
    assert (gt.get("distance_points"), gt.get("step_points"), gt.get("early_breakeven_points")) == (150, 40, 150)
    # Same law shape, scaled: ratios match the 120/400 floor ratio (0.3).
    assert abs(ws["max_stop_points"] / gs["max_stop_points"] - 0.3) < 1e-9


def test_wti_risk_floor_and_trailing_derive_from_instrument_spec():
    wti = _wti_config()
    assert wti["risk_settings"]["min_sl_distance_points"] == 120
    assert wti["trailing_stop"]["trailing_distance"] == 70
    assert wti["trailing_stop"]["trailing_step"] == 25


# ── 2 (execution ban) + 6. pipeline wiring ──────────────────────────────────

def test_run_analysis_forces_demo_execution_off_for_shadow():
    import io

    src = io.open("scripts/run_analysis.py", encoding="utf-8").read()
    assert 'shadow = is_shadow_config(config)' in src
    assert 'and not shadow' in src.split('demo_execution =')[1].split('\n')[0]
    assert 'shadow_telegram(config) if shadow else TelegramService(config)' in src
    assert 'shadow_database(config) if shadow else DatabaseService(config)' in src


def test_trade_updates_manage_shadow_books_and_gate_is_shadow_aware():
    import io

    src = io.open("scripts/run_trade_updates.py", encoding="utf-8").read()
    assert "shadow_open_trades" in src           # empty-live-book early exit fixed
    assert "_shadow_instruments(config)" in src  # shadow management loop exists
    assert "shadow must never break the live cycle" in src


def test_tick_manager_never_executes_shadow_trades():
    """The tick manager MAY collect ticks for shadow symbols (2026-08-17:
    each shadow instrument owns a suffixed auction store fed from the same
    loop) but its EXECUTION path must stay wired to the live book only —
    the shadow collectors never touch trade placement."""
    import io

    src = io.open("scripts/run_tick_manager.py", encoding="utf-8").read()
    # Collectors exist...
    assert "_collect_shadow_ticks" in src
    # ...but no execution/order call sites reference shadow anything.
    exec_markers = ("place", "order_send", "close_position", "modify")
    for chunk in src.split("def "):
        if chunk.startswith("_collect_shadow_ticks"):
            assert not any(m in chunk for m in exec_markers), (
                "shadow tick collector must never place/modify orders")
    # ShadowDatabase is never imported here: trades stay live-book only.
    assert "ShadowDatabase" not in src and "shadow_database" not in src


def test_shadow_paths_are_per_symbol_and_isolated(tmp_path):
    a = shadow_paths("WTI/USD", tmp_path)
    b = shadow_paths("XAU/USD", tmp_path)
    assert a["trades"] != b["trades"]
    assert "wtiusd" in str(a["trades"])


# ── 7. the $4-stop regression (first live shadow signal, 2026-08-17) ────────

def test_stop_law_uses_instrument_scale_not_legacy_gold_block():
    """TRADE_20260817_014655: BUY WTI @81.97 shipped stop 77.97 ($4.00, 400
    gold-points) because both stop doors passed the legacy
    risk_settings.stop_from_liquidity block (200/70/400) verbatim, overriding
    the per-instrument canonical rule. Both doors now read stop_rule(cfg)."""
    import utils.trading_rules as tr

    wti = _wti_config()
    # No eligible liquidity -> the law ships the cap directly: 120 oil points.
    pts = tr.stop_from_liquidity_points(
        direction="BUY", entry=81.97, liquidity_map={}, cfg=wti, symbol="WTI/USD")
    assert pts == 120, f"oil cap must be 120 points ($1.20), got {pts}"
    tp1, tp2, _ = tr.targets_law(
        direction="BUY", entry=81.97, risk_price=1.20, levels=[],
        cfg=wti, symbol="WTI/USD")
    assert abs(tp1 - 82.93) < 0.02   # 0.8R of $1.20
    assert abs(tp2 - 83.89) < 0.02   # 2x TP1 distance
    # Gold unchanged.
    gold = _gold_config()
    gpts = tr.stop_from_liquidity_points(
        direction="BUY", entry=4375.0, liquidity_map={}, cfg=gold, symbol="XAU/USD")
    assert gpts == 400


def test_both_stop_doors_read_the_canonical_rule():
    import io

    risk_src = io.open("agents/risk_management_agent.py", encoding="utf-8").read()
    planner_src = io.open("scripts/run_analysis.py", encoding="utf-8").read()
    assert "rule_cfg = _tr.stop_rule(self.config)" in risk_src
    assert "rule_cfg = _tr.stop_rule(config)" in planner_src
    # The hardcoded gold label is gone; the method name now carries the
    # instrument's actual numbers.
    assert 'sl_method = "liquidity_rule_200_70_400"' not in risk_src


# ── 8. auction integrity for shadow instruments (2026-08-17) ────────────────

def test_auction_agent_is_fully_isolated_per_symbol():
    """Operator caught auction_flow reading 0.0% and asked why. Root issues
    fixed: (a) a data-outage WAIT published confidence 0 (display floor is
    now 50); (b) the WTI agent read GOLD's tick store and calibration —
    cross-scale nonsense. Each symbol now owns its store and calibration,
    a foreign-symbol calibration is refused, and oil runs uncalibrated on
    the explicit linear fallback until its own curve is built."""
    from agents.auction_flow_agent import AuctionFlowAgent

    gold = AuctionFlowAgent(_gold_config())
    wti = AuctionFlowAgent(_wti_config())
    # (b) isolation
    assert str(gold.store.path) != str(wti.store.path)
    assert "wtiusd" in str(wti.store.path)
    assert gold.calibration_path != wti.calibration_path
    # gold curve must not leak into the oil agent
    assert wti.calibration is None
    # oil may run uncalibrated (linear fallback); gold still demands its curve
    assert wti.calibration_required is False
    assert gold.calibration_required is True
    # (a) display floor
    waiter = wti._wait("LIVE_TICK_FEED_STALE", "stale")
    assert waiter["confidence"] == 50
    assert waiter["signal"] == "WAIT"
    assert waiter["data_quality"]["valid"] is False
