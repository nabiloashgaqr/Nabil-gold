"""2026-08-19 phase-2 tests: oil macro agent (EIA + OPEC + spread)."""
from __future__ import annotations

import datetime
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import agents.oil_macro_agent as oma  # noqa: E402


def _cfg(tmp_path, **overrides):
    cfg = {
        "oil_macro": {
            "enabled": True,
            "eia_path": str(tmp_path / "eia_weekly.json"),
            "eia_history_path": str(tmp_path / "eia_history.json"),
            "opec_path": str(tmp_path / "opec_context.json"),
        },
    }
    cfg["oil_macro"].update(overrides)
    return cfg


def _write(path, payload):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(payload), encoding="utf-8")


def _same_iso_week_dates(week: str, years=(2025, 2024)):
    iso = datetime.date.fromisoformat(week).isocalendar()[1]
    out = []
    for year in years:
        d = datetime.date(year, 1, 1)
        for i in range(365):
            dd = d + datetime.timedelta(days=i)
            if dd.isocalendar()[1] == iso:
                out.append(dd.isoformat())
                break
    return out


class TestOilMacroAgent:
    def test_gold_run_is_neutral(self, tmp_path, monkeypatch):
        agent = oma.OilMacroAgent(_cfg(tmp_path))
        r = agent.analyze({"symbol": "XAU/USD"})
        assert r["direction"] == "WAIT"
        assert r["confidence"] == 0
        assert "OIL_ONLY" in str(r["reason_codes"])

    def test_draw_and_opec_cut_bullish(self, tmp_path, monkeypatch):
        cfg = _cfg(tmp_path)
        _write(cfg["oil_macro"]["eia_path"], {
            "week": "2026-08-14", "crude_change_mb": -4.5,
            "gasoline_change_mb": 1.0, "distillate_change_mb": -0.5,
            "refinery_util_pct": 93.0,
        })
        _write(cfg["oil_macro"]["opec_path"], {"tone": "CUT", "date": "2026-08-01"})
        monkeypatch.setattr(oma.OilMacroAgent, "_spread_z", lambda self: 0.0)
        monkeypatch.setattr(oma.OilMacroAgent, "_crack_component", lambda self: (0.0, []))
        r = oma.OilMacroAgent(cfg).analyze({"symbol": "WTI/USD"})
        assert r["direction"] == "BUY"
        assert r["bias"] == "BULLISH_OIL"
        # surprise -4.5 (+2.0) + refinery 93 (+0.5) + OPEC CUT (+2.0) = 4.5 -> 40+36=76
        assert r["confidence"] == 76
        assert r["signal"] == "WAIT"  # never votes

    def test_build_and_opec_hike_bearish(self, tmp_path, monkeypatch):
        cfg = _cfg(tmp_path)
        _write(cfg["oil_macro"]["eia_path"], {
            "week": "2026-08-14", "crude_change_mb": 4.5, "refinery_util_pct": 87.0,
        })
        _write(cfg["oil_macro"]["opec_path"], {"tone": "HIKE", "date": "2026-08-01"})
        monkeypatch.setattr(oma.OilMacroAgent, "_spread_z", lambda self: 0.0)
        monkeypatch.setattr(oma.OilMacroAgent, "_crack_component", lambda self: (0.0, []))
        r = oma.OilMacroAgent(cfg).analyze({"symbol": "WTI/USD"})
        assert r["direction"] == "SELL"
        assert r["bias"] == "BEARISH_OIL"

    def test_seasonal_surprise(self, tmp_path, monkeypatch):
        cfg = _cfg(tmp_path)
        hist_dates = _same_iso_week_dates("2026-08-14")
        assert len(hist_dates) == 2
        _write(cfg["oil_macro"]["eia_history_path"], [
            {"week": hist_dates[0], "crude_change_mb": 2.0},
            {"week": hist_dates[1], "crude_change_mb": 2.5},
        ])
        _write(cfg["oil_macro"]["eia_path"], {"week": "2026-08-14", "crude_change_mb": -1.0})
        _write(cfg["oil_macro"]["opec_path"], {"tone": "NEUTRAL", "date": "2026-08-01"})
        monkeypatch.setattr(oma.OilMacroAgent, "_spread_z", lambda self: 0.0)
        monkeypatch.setattr(oma.OilMacroAgent, "_crack_component", lambda self: (0.0, []))
        r = oma.OilMacroAgent(cfg).analyze({"symbol": "WTI/USD"})
        # surprise = -1.0 - 2.25 = -3.25 -> +2.0 -> BUY despite the "mild" headline number
        assert r["direction"] == "BUY"
        assert r["evidence"][0]["surprise_mb"] == -3.25

    def test_spread_widening_bearish(self, tmp_path, monkeypatch):
        cfg = _cfg(tmp_path)
        _write(cfg["oil_macro"]["eia_path"], {"week": "2026-08-14", "crude_change_mb": 0.0})
        _write(cfg["oil_macro"]["opec_path"], {"tone": "NEUTRAL", "date": "2026-08-01"})
        monkeypatch.setattr(oma.OilMacroAgent, "_spread_z", lambda self: 2.0)
        r = oma.OilMacroAgent(cfg).analyze({"symbol": "WTI/USD"})
        assert r["direction"] == "SELL"
        assert r["score"] == -1.0

    def test_fail_open_no_files(self, tmp_path, monkeypatch):
        monkeypatch.setattr(oma.OilMacroAgent, "_spread_z", lambda self: None)
        monkeypatch.setattr(oma.OilMacroAgent, "_crack_component", lambda self: (0.0, []))
        r = oma.OilMacroAgent(_cfg(tmp_path)).analyze({"symbol": "WTI/USD"})
        assert r["direction"] == "WAIT"
        assert r["confidence"] == 0
        assert set(r["missing"]) == {"eia", "opec", "spread"}
