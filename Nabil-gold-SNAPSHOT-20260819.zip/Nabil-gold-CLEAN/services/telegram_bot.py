"""Telegram service for signal and update messages."""

from __future__ import annotations

import hashlib
import html
import logging
import os
import re
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import requests

logger = logging.getLogger("telegram_bot")


def send_email_alert(config: Dict[str, Any], message: str) -> bool:
    """Second alert channel: email fallback for critical errors (item 14).

    Config section (DISABLED by default — fill and enable to activate):
      "alert_email": {
        "enabled": false,
        "smtp_host": "smtp.example.com",
        "smtp_port": 587,
        "username": "",
        "password": "",
        "from_addr": "",
        "to_addr": "",
        "subject": "SmartSignal Error Alert"
      }
    Returns True only when an email was actually sent. Never raises.
    """
    cfg = config.get("alert_email") or {}
    if not bool(cfg.get("enabled")):
        return False
    try:
        import smtplib
        from email.mime.text import MIMEText

        host = str(cfg.get("smtp_host") or "")
        to_addr = str(cfg.get("to_addr") or "")
        from_addr = str(cfg.get("from_addr") or "") or str(cfg.get("username") or "")
        if not host or not to_addr or not from_addr:
            return False
        port = int(cfg.get("smtp_port", 587) or 587)
        subject = str(cfg.get("subject", "SmartSignal Error Alert"))
        msg = MIMEText(str(message)[:2000], "plain", "utf-8")
        msg["Subject"] = subject
        msg["From"] = from_addr
        msg["To"] = to_addr
        with smtplib.SMTP(host, port, timeout=15) as server:
            server.ehlo()
            server.starttls()
            username = str(cfg.get("username") or "")
            password = str(cfg.get("password") or "")
            if username:
                server.login(username, password)
            server.sendmail(from_addr, [to_addr], msg.as_string())
        return True
    except Exception:  # noqa: BLE001 — a broken fallback must never break the bot
        logger.warning("Email alert fallback failed (silent)")
        return False

from services.liquidity_display import liquidity_display_zones
from services.execution_paths import path_header, resolve_execution_path
from utils import trading_rules as _tr
from utils.helpers import format_price, load_config


class TelegramService:
    API_BASE = "https://api.telegram.org/bot{token}/{method}"

    EVENT_LABELS = {
        "ORDER_FILLED": "Pending Order Activated",
        "NEAR_TP1": "Near TP1",
        "NEWS_HOLD": "Pending Order Paused by News",
        "PENDING_CANCELLED": "Pending Order Cancelled",
        "TP1_HIT": "Take Profit 1 Hit",
        "TP2_HIT": "Take Profit 2 Hit",
        "SL_HIT": "Stop Loss Hit",
        "TRAILING_SL_HIT": "Trailing Stop Hit",
        "BE_HIT": "Breakeven Hit",
        "MOVE_SL_TO_BE": "SL Moved to Breakeven",
        "TRAILING_SL_UPDATED": "Trailing Stop Updated",
        "THESIS_SCALE_OUT": "Thesis Risk Scale-Out",
        "LONG_RUNNING": "Long-running Trade",
        "EXIT_WARNING": "Exit / Risk Warning",
        "EXPIRED": "Trade Expired",
        "THESIS_EXIT": "Thesis Exit",
        "MANUAL_CLOSE": "Manual Close",
    }
    EVENT_PRIORITY = [
        "TP2_HIT", "TRAILING_SL_HIT", "SL_HIT", "BE_HIT", "TP1_HIT",
        "THESIS_SCALE_OUT", "MOVE_SL_TO_BE", "TRAILING_SL_UPDATED", "ORDER_FILLED", "NEWS_HOLD", "PENDING_CANCELLED", "EXIT_WARNING",
        "LONG_RUNNING", "NEAR_TP1", "EXPIRED", "THESIS_EXIT", "MANUAL_CLOSE",
    ]

    def __init__(self, config: Dict[str, Any] | None = None) -> None:
        self.config = config or load_config()
        c = self.config.get("telegram", {})
        self.bot_token = os.environ.get("TELEGRAM_BOT_TOKEN") or c.get("bot_token")
        self.chat_id = os.environ.get("TELEGRAM_CHAT_ID") or c.get("chat_id")
        self.session = requests.Session()
        self._recent_messages: Dict[str, float] = {}
        self._dedup_path = Path(__file__).resolve().parents[1] / "storage" / "telegram_delivery_dedup.sqlite3"
        dedup_cfg = (self.config.get("telegram_delivery") or {}) if isinstance(self.config, dict) else {}
        self._dedup_seconds = float(dedup_cfg.get("dedup_seconds", 180) or 180)
        self._pending_dedup_seconds = float(dedup_cfg.get("pending_dedup_seconds", 30) or 30)

    @staticmethod
    def _polish_message_text(text: Any, *, demo: bool) -> str:
        """One final truth/polish boundary for every Telegram producer."""
        value = str(text or "").replace("\r\n", "\n").replace("\r", "\n")
        # Operator 2026-08-11: the retired paper label must never reach users.
        value = re.sub(r"(?i)\bpaper[\s-]*trading\b", "demo execution", value)
        value = re.sub(r"(?i)\bpaper[\s-]*traded\b", "evaluated on demo", value)
        value = re.sub(r"(?i)\bpaper_trading\b", "demo", value)
        value = re.sub(r"(?i)\bpaper\b", "demo", value)
        value = re.sub(r"ورقي(?:ة)?", "ديمو", value)
        # Canonicalize all historic tick-manager prefixes to one clean marker.
        value = re.sub(r"^\s*🧪\s*DEMO\s*(?:[·:—-]\s*)?", "", value,
                       count=1, flags=re.IGNORECASE)
        if demo:
            value = "🧪 DEMO · " + value.lstrip()

        # Collapse accidental adjacent duplicates while preserving intentional
        # section separators used between different card blocks.
        out: List[str] = []
        for raw in value.split("\n"):
            line = raw.rstrip()
            if line and out and line == out[-1]:
                continue
            if not line and out and out[-1] == "":
                continue
            out.append(line)
        return "\n".join(out).strip()

    def _delivery_key(self, chat_id: Any, text: str) -> str:
        return hashlib.sha256(f"{chat_id}\0{text}".encode("utf-8")).hexdigest()

    def _reserve_delivery(self, key: str) -> bool:
        now = time.time()
        if os.environ.get("PYTEST_CURRENT_TEST") or os.environ.get("PYTEST_RUNNING") == "true":
            last = self._recent_messages.get(key, 0.0)
            if now - last < self._dedup_seconds:
                return False
            self._recent_messages[key] = now
            return True

        try:
            self._dedup_path.parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(self._dedup_path, timeout=8.0) as conn:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute(
                    "CREATE TABLE IF NOT EXISTS deliveries "
                    "(key TEXT PRIMARY KEY, ts REAL NOT NULL, state TEXT NOT NULL)"
                )
                conn.execute("BEGIN IMMEDIATE")
                conn.execute("DELETE FROM deliveries WHERE ts < ?", (now - max(self._dedup_seconds, 3600),))
                row = conn.execute(
                    "SELECT ts, state FROM deliveries WHERE key = ?", (key,)
                ).fetchone()
                if row:
                    age = now - float(row[0] or 0)
                    ttl = self._pending_dedup_seconds if row[1] == "pending" else self._dedup_seconds
                    if age < ttl:
                        conn.rollback()
                        return False
                conn.execute(
                    "INSERT INTO deliveries(key, ts, state) VALUES(?, ?, 'pending') "
                    "ON CONFLICT(key) DO UPDATE SET ts=excluded.ts, state='pending'",
                    (key, now),
                )
                conn.commit()
                return True
        except Exception as exc:  # noqa: BLE001
            # Never lose a real message merely because dedup storage is damaged.
            logger.warning("telegram dedup reserve failed open: %s", exc)
            return True

    def _finish_delivery(self, key: str, success: bool) -> None:
        if os.environ.get("PYTEST_CURRENT_TEST") or os.environ.get("PYTEST_RUNNING") == "true":
            if not success:
                self._recent_messages.pop(key, None)
            return
        now = time.time()
        try:
            with sqlite3.connect(self._dedup_path, timeout=8.0) as conn:
                if success:
                    conn.execute(
                        "UPDATE deliveries SET ts = ?, state = 'delivered' WHERE key = ?",
                        (now, key),
                    )
                else:
                    conn.execute("DELETE FROM deliveries WHERE key = ?", (key,))
                conn.commit()
        except Exception as exc:  # noqa: BLE001
            logger.warning("telegram dedup finish failed: %s", exc)

    def send_message(self, text: str, urgent: bool = False, chat_id: str | None = None) -> bool:
        demo = os.environ.get("EXECUTION_MODE") == "mt5_demo"
        demo_chat = os.environ.get("TELEGRAM_DEMO_CHAT_ID")
        if demo and not chat_id and demo_chat:
            chat_id = demo_chat
        target_chat = chat_id or self.chat_id
        text = self._polish_message_text(text, demo=demo)
        if not self.bot_token or not target_chat:
            return False

        key = self._delivery_key(target_chat, text)
        if not self._reserve_delivery(key):
            logger.info("telegram duplicate suppressed: %.80s", text)
            # Treat exact duplicate as already delivered so callers never create
            # a second trade/error merely because the card was suppressed.
            return True

        url = self.API_BASE.format(token=self.bot_token, method="sendMessage")
        payload = {
            "chat_id": target_chat,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }
        try:
            resp = self.session.post(url, json=payload, timeout=20)
            ok = resp.status_code == 200
        except Exception:
            self._finish_delivery(key, False)
            logger.error("telegram send crashed for: %.60s", text)
            return False
        self._finish_delivery(key, ok)
        if not ok:
            logger.error("telegram send HTTP %s for: %.60s",
                         resp.status_code, text)
        else:
            logger.info("telegram delivered: %.60s", text)
        return ok

    @staticmethod
    def _money(value: Any, symbol: str = "XAU/USD") -> str:
        return format_price(value, symbol)

    @staticmethod
    def _clean_text(value: Any) -> str:
        text = html.escape(str(value or ""))
        return " ".join(text.split())

    @staticmethod
    def _friendly_signal_text(value: Any) -> str:
        text = str(value or "")
        text = text.replace(
            "Buy-side liquidity sweep detected (STRONG) - bearish after sweep",
            "Sweep above recent highs detected (STRONG) - bearish reversal context",
        )
        text = text.replace(
            "Sell-side liquidity sweep detected (STRONG) - bullish after sweep",
            "Sweep below recent lows detected (STRONG) - bullish reversal context",
        )
        return html.escape(text)

    @staticmethod
    def _numbers(text: Any) -> List[float]:
        return [float(x) for x in re.findall(r"\d+(?:\.\d+)?", str(text or ""))]

    def _should_show_invalidation(self, invalidation: Any, stop_loss: Any) -> bool:
        text = str(invalidation or "").strip()
        if not text:
            return False
        nums = self._numbers(text)
        try:
            sl = float(stop_loss)
        except (TypeError, ValueError):
            sl = None
        # Hide invalidation only when it is just the SL price repeated.
        if sl is not None and nums and any(abs(n - sl) < 0.02 for n in nums):
            structural_words = {"structure", "block", "break", "close", "sweep"}
            lower = text.lower()
            if not any(word in lower for word in structural_words - {"close"}):
                return False
        return True

    def _votes_lines(self, decision: Dict[str, Any]) -> List[str]:
        agent_details = decision.get("agent_details") or {}
        if not agent_details:
            return []
        lines = ["🗳️ <b>AGENT VOTES</b>"]
        shared = decision.get("shared_market_data") or {}
        if isinstance(shared, dict) and shared.get("snapshot_id"):
            lines.append(
                f"📚 One shared stored MT5 snapshot · "
                f"{html.escape(str(shared.get('snapshot_id')))}"
            )
        # Fixed color contract: BUY green, SELL red, WAIT white.
        marker = {"BUY": "🟢", "SELL": "🔴", "WAIT": "⚪"}
        # Render order: core 5 agents first, then any extras
        core_order = ["technical", "multitimeframe", "classical", "smc", "price_action", "auction_flow", "macro_fundamental"]
        ordered_keys = [k for k in core_order if k in agent_details]
        for key in agent_details:
            if key not in ordered_keys:
                ordered_keys.append(key)
        # Only votes at or above agent_min_confidence count toward admission.
        # Rendering a 67% vote identically to an 84% one made the message show
        # four green agents while the header said "3 qualified agents".
        sig_cfg = (self.config.get("signal_requirements") or {}) if isinstance(self.config, dict) else {}
        try:
            min_agent_conf = float(sig_cfg.get("agent_min_confidence", 67) or 67)
        except (TypeError, ValueError):
            min_agent_conf = 67.0
        side = str(decision.get("decision") or (decision.get("signal") or {}).get("type") or "").upper()

        for key in ordered_keys:
            detail = agent_details.get(key)
            if not isinstance(detail, dict):
                continue
            label = str(detail.get("label") or key).strip()
            direction = str(detail.get("direction") or "WAIT").upper()
            if direction in {"NEUTRAL", "HOLD", "NO_TRADE", ""}:
                direction = "WAIT"
            confidence = detail.get("confidence")
            try:
                conf_value = float(confidence)
            except (TypeError, ValueError):
                conf_value = None
            emoji = marker.get(direction, "⚪")
            conf_text = f" {confidence}%" if confidence is not None else ""

            note = ""
            if key == "macro_fundamental":
                # Macro states a view on gold, not on this trade. Its percentage
                # is confidence in its own direction, which may be the opposite
                # of the signal being published.
                if side in {"BUY", "SELL"} and direction in {"BUY", "SELL"} and direction != side:
                    note = f" — {direction} (opposes this {side})"
                elif direction in {"BUY", "SELL"}:
                    note = f" — {direction} (supports)"
            elif conf_value is not None and direction in {"BUY", "SELL"}:
                if conf_value >= min_agent_conf:
                    note = " — QUALIFIED" if direction == side else " — QUALIFIED, opposes"
                else:
                    note = f" — NOT QUALIFIED (<{min_agent_conf:.0f}%)"
            elif direction == "WAIT":
                note = " — WAIT"

            icon = "🌊 " if key == "auction_flow" else ""
            decision_weights = decision.get("weights") or {}
            if key != "macro_fundamental" and isinstance(decision_weights, dict) and key in decision_weights:
                note = f" · weight {float(decision_weights.get(key) or 0) * 100:.0f}%" + note
            lines.append(f"{emoji} {icon}<b>{html.escape(label)}</b>{html.escape(conf_text)}{html.escape(note)}")
            if key == "auction_flow" and detail.get("state"):
                lines.append(
                    f"  • {html.escape(str(detail.get('state')).replace('_', ' ').title())} · "
                    f"Edge {float(detail.get('raw_edge') or 0):+.3f}"
                )
            signals = detail.get("signals") or []
            if not signals:
                # Some agents (multitimeframe) emit only a summary, which left
                # them looking unexplained next to fully-reasoned peers.
                summary = str(detail.get("summary") or "").strip()
                if summary:
                    signals = [summary]
            for sig in signals[:2]:
                text = self._friendly_signal_text(sig)
                if len(text) > 160:
                    text = text[:157].rstrip() + "..."
                lines.append(f"  • {text}")
        return lines

    def _session_plan_signal_strength_line(self, decision: Dict[str, Any]) -> str | None:
        plan = decision.get("session_plan") or {}
        if not isinstance(plan, dict) or not plan:
            return None
        confidence = plan.get("planner_confidence")
        authority = str(plan.get("authority_state") or "UNKNOWN").upper()
        grade = str(plan.get("planner_grade") or "--")
        session_bias = str(plan.get("session_bias") or decision.get("decision") or "WAIT").upper()
        execution = str(plan.get("execution_preference") or "planner-led").replace("_", " ").title()
        conf_text = f" {float(confidence):.1f}%" if confidence not in {None, ""} else ""
        line = f"🧭 Planner-led day map — {session_bias} {grade}{conf_text} · authority {authority} · {execution}"
        # Surface how much conviction the day archetype carries, since it now
        # decides whether an add leg is permitted at all.
        conviction = plan.get("archetype_conviction") or {}
        if isinstance(conviction, dict) and conviction.get("level"):
            level = str(conviction.get("level"))
            archetype = str(conviction.get("archetype") or "").replace("_", " ").title()
            score = conviction.get("score")
            bits = [f"conviction {level}"]
            if archetype:
                bits.append(archetype + (f" {score:.0f}%" if isinstance(score, (int, float)) and score else ""))
            if conviction.get("family_aligned") is False:
                bits.append("setup contradicts archetype")
            if not conviction.get("allow_add_leg", True):
                bits.append("main leg only")
            line += "\n🎯 " + html.escape(" · ".join(bits))
        return line

    def _signal_strength_line(self, decision: Dict[str, Any]) -> str | None:
        classic = decision.get("classic") or {}
        two_agent = classic.get("two_agent")
        signal = str(decision.get("decision") or "").upper()
        selected = ((classic.get("consensus") or {}).get("selected") or {}) if isinstance(classic, dict) else {}
        total_core = 5
        # For Path 2 (dual-agent) entries, two_agent is the authoritative
        # source for support/opposition counts.  The classic consensus
        # "selected" is None in that case (the 3-agent consensus was WAIT), so
        # we must read BOTH counts from two_agent — not fall back to
        # sell_count/buy_count which only give support and leave opposition at 0.
        if isinstance(two_agent, dict) and two_agent:
            support = int(two_agent.get("support_count", 0) or 0)
            opposition = int(two_agent.get("opposition_count", 0) or 0)
        else:
            support = int(selected.get("support_count") or classic.get("buy_count" if signal == "BUY" else "sell_count", 0) or 0)
            opposition = int(selected.get("opposition_count") or 0)
        if support <= 0:
            return None
        if support >= 4 and opposition == 0:
            label = "Excellent"
        elif support >= 3:
            label = "Strong"
        elif support >= 2 and opposition == 0:
            label = "Good (dual-agent)"
        elif opposition == 0:
            label = "Good"
        else:
            label = "Cautious"
        opp_text = "no opposition" if opposition == 0 else f"{opposition} opposing"
        return f"💪 Strength: {label} — {support}/{total_core} qualified agents, {opp_text}"

    def _macro_block(self, decision: Dict[str, Any]) -> List[str]:
        """Rich macro block for signal messages — July 2026 macro-aware upgrade."""
        attr = decision.get("entry_attribution") or {}
        market_context = decision.get("market_context") or {}
        news_context = decision.get("news_context") or {}
        macro_agent = news_context.get("macro", {}) if isinstance(news_context, dict) else {}
        # try full agent result too
        if not macro_agent:
            macro_agent = market_context if isinstance(market_context, dict) else {}
        macro = {}
        macro_full = {}
        for candidate in (
            attr.get("macro_direction") if isinstance(attr, dict) else None,
            market_context.get("macro_direction") if isinstance(market_context, dict) else None,
            (macro_agent.get("macro_direction") if isinstance(macro_agent, dict) else None),
        ):
            if isinstance(candidate, dict) and candidate:
                macro = candidate
                break
        # try to get full agent for drivers/breakdown
        for full_candidate in (
            news_context.get("macro") if isinstance(news_context, dict) else None,
            decision.get("macro_agent"),
            market_context,
        ):
            if isinstance(full_candidate, dict) and full_candidate.get("macro_direction"):
                macro_full = full_candidate
                break
        if not macro or (str(macro.get("bias", "NEUTRAL")).upper() == "NEUTRAL" and not macro.get("confidence") and not macro.get("drivers")):
            # Check if data was collected but just flat/neutral
            data_quality = macro.get("data_quality", {}) if isinstance(macro, dict) else {}
            if data_quality.get("inputs", 0) > 0 or (isinstance(macro, dict) and macro.get("drivers")):
                drivers = macro.get("drivers", [])
                driver_text = "; ".join(drivers[:2]) if drivers else "all indicators flat"
                return [f"• Macro: Neutral — {html.escape(driver_text)}"]
            return ["• Macro: Collecting hourly data"]
        bias = str(macro.get("bias") or "NEUTRAL").replace("_", " ").title()
        conf = macro.get("confidence")
        score = macro.get("score")
        drivers = macro.get("drivers") or []
        breakdown = macro.get("confidence_breakdown") or {}
        invalidations = macro.get("invalidations") or []
        lines = [f"• Macro: {html.escape(bias)}" + (f" ({conf}%)" if conf not in {None, ""} else "") + (f" · score {score}" if score not in {None, ""} else "")]
        if drivers:
            lines.append(f"  ↳ {html.escape('; '.join(drivers[:2]))}")
        if breakdown:
            # show top 2 components
            top = sorted(breakdown.items(), key=lambda kv: abs(float(kv[1] or 0)), reverse=True)[:2]
            bd_txt = ", ".join(f"{k}:{v:+.1f}" for k, v in top)
            lines.append(f"  ↳ {html.escape(bd_txt)}")
        if invalidations:
            lines.append(f"  ⚠ Invalidation: {html.escape(str(invalidations[0])[:90])}")
        return lines

    def _macro_line(self, decision: Dict[str, Any]) -> str:
        # backward compat: first line of block
        block = self._macro_block(decision)
        return block[0] if block else "• Macro: Collecting hourly data"

    def _execution_leg_label(self, setup: Dict[str, Any] | None, plan: Dict[str, Any] | None, *, direction: str = "") -> str | None:
        setup = setup if isinstance(setup, dict) else {}
        plan = plan if isinstance(plan, dict) else {}
        direct = str(setup.get("execution_leg_label") or "").strip()
        if direct:
            return direct
        manual_plan = (plan.get("manual_plan") or {}) if isinstance(plan, dict) else {}
        role = str(setup.get("pending_plan_role") or setup.get("selection_role") or "").upper()
        direction = str(direction or plan.get("session_bias") or "").upper()
        side_word = "BUY" if direction == "BUY" else "SELL" if direction == "SELL" else "TRADE"
        main_label = str(manual_plan.get("main_area_label") or f"MAIN {side_word} AREA")
        add_label = str(manual_plan.get("add_area_label") or f"ADD {side_word} AREA")
        mapping = {
            "PRIMARY": main_label,
            "STANDBY": add_label,
            "STARTER": f"STARTER inside {main_label}",
            "ADD_ON": f"ADD-ON from {add_label}",
        }
        return mapping.get(role) if role else None

    def _trade_execution_leg_label(self, trade: Dict[str, Any]) -> str | None:
        snap = trade.get("signal_snapshot") or {}
        if isinstance(snap, str):
            try:
                import json as _json
                snap = _json.loads(snap)
            except Exception:
                snap = {}
        if not isinstance(snap, dict):
            snap = {}
        setup = snap.get("setup_context") or {}
        plan = snap.get("session_plan") or {}
        return self._execution_leg_label(setup, plan, direction=str(trade.get("type") or trade.get("side") or ""))

    def _planned_rr_line(self, signal: Dict[str, Any], rr: Any) -> str | None:
        """Render RR per target instead of a single TP2-only figure.

        Breakeven protection moves the stop to entry well before TP2, so an
        exit at or near TP1 is the more likely outcome. Publishing only the
        TP2 ratio overstates the expected return of every signal.
        """
        entry = signal.get("entry", {}) or {}
        try:
            entry_price = float(entry.get("price") or 0)
            stop_loss = float(signal.get("stop_loss") or 0)
            tp1 = float(signal.get("tp1") or 0)
            tp2 = float(signal.get("tp2") or 0)
        except (TypeError, ValueError):
            entry_price = stop_loss = tp1 = tp2 = 0.0
        risk = abs(entry_price - stop_loss)
        if risk > 0 and tp1 > 0 and tp2 > 0:
            rr1 = abs(tp1 - entry_price) / risk
            rr2 = abs(tp2 - entry_price) / risk
            return f"• <b>Planned RR:</b> {rr1:.2f}R (TP1) / {rr2:.2f}R (TP2)"
        if rr:
            return f"• <b>Planned RR:</b> {html.escape(str(rr))}R (TP2)"
        return None

    def _management_lines(self, decision: Dict[str, Any], signal: Dict[str, Any]) -> List[str]:
        """Describe protection/trailing using the profile the engine will apply.

        These were previously hardcoded to 150/40/150, which is the
        default_profile. In practice every real setup type maps to a different
        profile (reversal 120/30/100, continuation 170/45/170, range
        110/25/90), so the published numbers were wrong for every signal.
        """
        # Phase 3: even the last-resort defaults come from the single source.
        _trail0 = _tr.trailing_params(self.config if isinstance(self.config, dict) else {})
        trailing = float(_trail0["distance_points"])
        step = float(_trail0["step_points"])
        breakeven = float(_trail0["early_breakeven_points"])
        try:
            from agents.open_trades_manager import OpenTradesManager
            from utils.helpers import load_config

            # Always resolve against production trade_management settings. A
            # caller may construct this service with a partial config (tests,
            # ad-hoc scripts); the numbers we publish must still describe what
            # the live engine will do, not a fallback that exists nowhere.
            mgmt_config = self.config
            if not (isinstance(self.config, dict) and self.config.get("trade_management")):
                try:
                    mgmt_config = load_config()
                except Exception:  # noqa: BLE001
                    mgmt_config = self.config

            setup_context = decision.get("setup_context") or {}
            # Pass only what selects a profile. Forwarding the whole risk /
            # signal payload would let per-trade overrides leak in and change
            # the advertised numbers away from the profile itself.
            risk = decision.get("risk") or {}
            probe_risk = (
                {"management_profile": risk.get("management_profile")}
                if isinstance(risk, dict) and risk.get("management_profile")
                else {}
            )
            probe = {
                "signal_snapshot": {
                    "setup_context": setup_context,
                    "setup_type": decision.get("setup_type") or setup_context.get("setup_type"),
                    "risk": probe_risk,
                }
            }
            params = OpenTradesManager(mgmt_config)._management_params(
                probe, symbol=str(decision.get("symbol") or mgmt_config.get("symbol", "XAU/USD"))
            )
            trailing = float(params.get("trailing_distance_points", trailing) or trailing)
            step = float(params.get("trailing_step_points", step) or step)
            breakeven = float(params.get("early_breakeven_points", breakeven) or breakeven)
        except Exception:  # noqa: BLE001 - never block a signal on formatting
            pass
        # Describe the protection that will actually run. The engine has two
        # wirings and the line must name the one in force:
        #   * auto_move_sl_to_entry_after_tp1: the TP1 touch moves the stop to
        #     entry whatever TP1's value, gated only by min_breakeven_rr of
        #     travel. Stating the old "+N pts" promise alone is what refused
        #     sound maps at the gate on 2026-08-04 (TP1 140.5 pts vs +150).
        #   * legacy distance trigger only: SL -> entry after +N pts.
        mgmt = (mgmt_config.get("trade_management") or {}) if isinstance(mgmt_config, dict) else {}
        auto_be_at_tp1 = bool(mgmt.get("auto_move_sl_to_entry_after_tp1", True))
        min_be_rr = float(mgmt.get("min_breakeven_rr") or 0)
        tp1_pts = 0.0
        tp1_rr = 0.0
        try:
            from utils.instruments import price_to_points
            symbol = str(decision.get("symbol") or "XAU/USD")
            entry_price = float((signal.get("entry") or {}).get("price")
                                or decision.get("current_price") or 0)
            stop_price = float(signal.get("stop_loss") or 0)
            tp1_price = float(signal.get("tp1") or 0)
            if entry_price > 0 and tp1_price > 0:
                tp1_pts = abs(price_to_points(tp1_price - entry_price, symbol=symbol))
                risk_pts = abs(price_to_points(entry_price - stop_price, symbol=symbol)) if stop_price > 0 else 0.0
                tp1_rr = (tp1_pts / risk_pts) if risk_pts > 0 else 0.0
        except Exception:  # noqa: BLE001 - never block a signal on formatting
            pass

        if auto_be_at_tp1 and tp1_pts > 0 and (min_be_rr <= 0 or tp1_rr >= min_be_rr):
            # The wired promise: reaching TP1 arms the breakeven stop.
            protection = f"• <b>Protection:</b> SL → entry at TP1 ({tp1_pts:.0f} pts away, half books there)"
            if breakeven > 0 and tp1_pts > breakeven:
                protection += f" · may arm earlier at +{breakeven:.0f} pts"
        else:
            protection = f"• <b>Protection:</b> SL → entry after +{breakeven:.0f} pts"
            if tp1_pts > 0:
                if breakeven > 0 and breakeven < tp1_pts:
                    protection += " (before TP1)"
                else:
                    suffix = f"TP1 is {tp1_pts:.0f} pts away — partial close first"
                    if auto_be_at_tp1 and min_be_rr > 0 and tp1_rr < min_be_rr:
                        suffix += "; breakeven at TP1 deferred (below the R-guard)"
                    protection += f" ({suffix})"
        if min_be_rr > 0:
            protection += f" · needs ≥{min_be_rr:.2f}R travelled"
        return [
            protection,
            f"• <b>Management:</b> Trail gap {trailing:.0f} pts / step {step:.0f} pts · check 5m",
        ]

    def _setup_lines(self, decision: Dict[str, Any], signal: Dict[str, Any]) -> List[str]:
        setup = decision.get("setup_context") or {}
        if not isinstance(setup, dict):
            setup = {}
        lines: List[str] = []
        setup_type = setup.get("setup_type")
        setup_state = setup.get("setup_state")
        lead_agent = setup.get("lead_agent")
        quality = setup.get("quality_grade") or decision.get("setup_quality")
        selection_role = setup.get("selection_role")
        leg_label = self._execution_leg_label(setup, decision.get("session_plan") or {}, direction=str(decision.get("decision") or signal.get("type") or ""))
        if setup_type or setup_state or lead_agent:
            compact = []
            if setup_type:
                compact.append(str(setup_type).replace("_", " ").title())
            if leg_label:
                compact.append(f"leg {leg_label}")
            if selection_role:
                compact.append(f"role {selection_role}")
            if setup_state:
                compact.append(f"state {setup_state}")
            if lead_agent:
                compact.append(f"lead {lead_agent}")
            if quality:
                # Say WHICH quality this is.
                #
                # The header already prints "Quality: A 89.7" -- the decision
                # agent's grade for the whole signal (confidence, reward,
                # session, news). This one is SMCAgent's grade for the POI
                # alone. They measure different things and can legitimately
                # disagree, but printed as two bare letters on one card they
                # read as a contradiction: 2026-08-03 trade bdde9a5f showed
                # "Quality: A 89.7" beside "quality D" and neither was wrong.
                #
                # Naming the source costs one word and removes the confusion.
                compact.append(f"POI quality {quality}")
            lines.append(f"• <b>Setup:</b> {html.escape(' · '.join(compact))}")
        if leg_label:
            lines.append(f"• <b>Execution leg:</b> {html.escape(leg_label)}")
        zone = signal.get("entry", {}) or {}
        low = zone.get("low")
        high = zone.get("high")
        if low is not None and high is not None:
            try:
                low_f = float(low)
                high_f = float(high)
                if abs(high_f - low_f) > 0.01:
                    lines.append(f"• <b>Entry zone:</b> {self._money(low_f, str(decision.get('symbol') or 'XAU/USD'))} → {self._money(high_f, str(decision.get('symbol') or 'XAU/USD'))}")
            except (TypeError, ValueError):
                pass
        poi_type = setup.get("poi_type")
        sweep_side = setup.get("sweep_side")
        displacement = setup.get("displacement_score")
        target_liquidity = setup.get("target_liquidity")
        if poi_type or sweep_side or displacement not in {None, ""}:
            extra = []
            if poi_type:
                extra.append(f"POI {str(poi_type).replace('_', ' ').title()}")
            if sweep_side:
                extra.append(f"sweep {sweep_side}")
            if displacement not in {None, ""}:
                extra.append(f"disp {displacement}")
            lines.append(f"• <b>SMC context:</b> {html.escape(' · '.join(str(x) for x in extra))}")
        rp = setup.get("return_probability_score")
        td = setup.get("thesis_dominance_score")
        revisit = setup.get("expected_revisit_window")
        if rp not in {None, ""} or td not in {None, ""} or revisit:
            metric_bits = []
            if rp not in {None, ""}:
                metric_bits.append(f"reach {rp}")
            if td not in {None, ""}:
                metric_bits.append(f"dominance {td}")
            if revisit:
                metric_bits.append(f"revisit {revisit}")
            lines.append(f"• <b>POI selection:</b> {html.escape(' · '.join(str(x) for x in metric_bits))}")
        if target_liquidity not in {None, ""}:
            lines.append(f"• <b>Target liquidity:</b> {self._money(target_liquidity, str(decision.get('symbol') or 'XAU/USD'))}")
        governor = decision.get("pending_governor") or {}
        if isinstance(governor, dict) and str(governor.get("action") or "") in {"REPLACE_PENDING", "CANCEL_PENDING_ALLOW_NEW"}:
            old_id = str(governor.get("old_trade_id") or "")
            short = old_id.split("_")[-1] if "_" in old_id else (old_id[-8:] if len(old_id) >= 8 else old_id)
            old_ctx = governor.get("old_context") or {}
            new_ctx = governor.get("new_context") or {}
            lines.append(
                f"• <b>Pending governance:</b> {html.escape(str(governor.get('action')).replace('_', ' ').title())} "
                f"<code>#{html.escape(short)}</code>"
            )
            lines.append(
                f"• <b>Dominance:</b> old {old_ctx.get('thesis_dominance_score', '--')} → new {new_ctx.get('thesis_dominance_score', '--')}"
            )
        adaptive = decision.get("adaptive_execution") or {}
        if isinstance(adaptive, dict) and adaptive.get("action"):
            lines.append(
                f"• <b>Execution switch:</b> {html.escape(str(adaptive.get('action')).replace('_', ' ').title())}"
            )
            if adaptive.get("reason"):
                lines.append(f"• <b>Execution reason:</b> {self._clean_text(adaptive.get('reason'))}")
        golden = decision.get("golden_dual_entry") or {}
        if isinstance(golden, dict) and golden.get("action") == "GOLDEN_DUAL_ENTRY":
            lv = golden.get("levels") or {}
            lines.append(
                "• <b>Golden dual entry:</b> market at 0.618 close-confirm "
                f"({lv.get('l618')}) + pending kept at >= 0.70 fibo "
                f"({lv.get('l70')}) — two-entry exception; exits via stops/thesis"
            )
        invalidation = (decision.get("ai") or {}).get("invalidation") or setup.get("invalidation") or setup.get("entry_reason")
        if self._should_show_invalidation(invalidation, signal.get("stop_loss")):
            label = "Invalidation" if (decision.get("ai") or {}).get("invalidation") else "Structural trigger"
            lines.append(f"• <b>{label}:</b> {self._clean_text(invalidation)}")
        return lines[:7]

    def _attribution_lines(self, decision: Dict[str, Any]) -> List[str]:
        attr = decision.get("entry_attribution") or {}
        if not isinstance(attr, dict) or not attr:
            return []
        lines: List[str] = []
        primary = attr.get("primary_entry_driver")
        timing = attr.get("timing_state")
        permission = attr.get("entry_permission")
        if primary:
            lines.append(f"• Primary driver: {html.escape(str(primary).replace('_', ' ').title())}")
        compact = []
        if timing:
            compact.append(f"Timing {timing}")
        if permission:
            compact.append(f"Permission {permission}")
        if compact:
            lines.append(f"• {' · '.join(html.escape(str(x)) for x in compact)}")
        return lines[:2]

    def _technical_caution_lines(self, decision: Dict[str, Any]) -> List[str]:
        """Formatter for Technical agent cautions."""
        details = decision.get("agent_details") or {}
        trend = details.get("technical") if isinstance(details, dict) else {}
        signals = (trend or {}).get("signals") if isinstance(trend, dict) else []
        cautions = []
        for sig in signals or []:
            lower = str(sig).lower()
            if any(word in lower for word in ("bearish", "weakening", "divergence", "overbought", "oversold", "conflict")):
                cautions.append(f"• Unified Trend caution: {self._friendly_signal_text(sig)}")
        return cautions[:1]

    def _independent_review_lines(self, decision: Dict[str, Any]) -> List[str]:
        """Render Gemini state every time — macro-aware July 2026."""
        review = decision.get("gemini_review")
        lines = ["🧠 <b>GEMINI INDEPENDENT REVIEW</b>"]
        if isinstance(review, dict) and review.get("available"):
            verdict = review.get("verdict") or review.get("signal") or review.get("opinion") or "REVIEWED"
            reason = review.get("reason") or review.get("summary") or "Independent check completed."
            lines.append(f"• <b>Opinion:</b> {self._clean_text(verdict)} - {self._clean_text(reason)}")
            confidence = review.get("confidence")
            if confidence not in {None, ""}:
                lines.append(f"• <b>Review confidence:</b> {html.escape(str(confidence))}%")
            macro_align = review.get("macro_alignment")
            if macro_align:
                emoji = {"ALIGNED": "✅", "CONFLICT": "⚠️", "NEUTRAL": "➖"}.get(str(macro_align).upper(), "•")
                lines.append(f"{emoji} <b>Macro alignment:</b> {html.escape(str(macro_align))}")
            risk_level = review.get("risk_level")
            if risk_level:
                lines.append(f"• <b>Risk:</b> {html.escape(str(risk_level))}")
            invalidation = review.get("invalidation")
            if invalidation:
                lines.append(f"• <b>Invalidation:</b> {self._clean_text(invalidation)}")
            # also show macro context used
            macro_ctx = (decision.get("market_context", {}) or {}).get("macro_direction") or (decision.get("entry_attribution", {}) or {}).get("macro_direction")
            if isinstance(macro_ctx, dict) and macro_ctx.get("bias"):
                mbias = str(macro_ctx.get("bias")).replace("_", " ").title()
                mconf = macro_ctx.get("confidence")
                lines.append(f"• <b>Macro input:</b> {html.escape(mbias)}" + (f" ({mconf}%)" if mconf else ""))
            return lines

        if isinstance(review, dict) and review.get("suppressed"):
            lines.append("• <b>Status:</b> Skipped — no useful extra insight")
            return lines

        if isinstance(review, dict):
            summary = str(review.get("summary") or review.get("reason") or "").lower()
            if any(token in summary for token in ("api key", "not configured", "disabled", "credential")):
                lines.append("• <b>Status:</b> Offline this run")
            else:
                lines.append("• <b>Status:</b> Not available this run")
            return lines

        lines.append("• <b>Status:</b> Offline this run")
        return lines

    def send_session_plan(self, plan: Dict[str, Any]) -> bool:
        symbol = str(plan.get("symbol") or "XAU/USD")
        bias = str(plan.get("session_bias") or plan.get("authority_direction") or "WAIT").upper()
        scenario = str(plan.get("scenario_type") or "DAY_MAP").replace("_", " ").title()
        status = str(plan.get("plan_status") or ("READY" if plan.get("plan_ready") else "NOT_READY")).upper()
        primary_zone = plan.get("primary_entry_zone") or {}
        standby_zone = plan.get("standby_entry_zone") or {}
        confidence = float(plan.get("planner_confidence") or 0)
        grade = str(plan.get("planner_grade") or "--")
        display_quality = plan.get("map_display_quality") or {}
        display_score = float(display_quality.get("score") if isinstance(display_quality, dict) and display_quality.get("score") is not None else min(confidence, 95.0))
        display_grade = str(display_quality.get("grade") if isinstance(display_quality, dict) and display_quality.get("grade") else grade)
        authority = str(plan.get("authority_state") or "--")
        side_word = "BUY" if bias == "BUY" else "SELL" if bias == "SELL" else "TRADE"
        manual_plan = plan.get("manual_plan") or {}
        delivery_context = plan.get("delivery_context") or {}
        delivery_kind = str(delivery_context.get("message_kind") or "OPENING_PLAN").upper()
        delivery_reason = str(delivery_context.get("delivery_reason") or "").strip()
        monitoring_only = bool(plan.get("monitoring_only") or delivery_context.get("monitoring_only"))
        headline = str(manual_plan.get("headline") or f"{side_word} DAY MAP")
        if monitoring_only:
            headline = f"{side_word} WATCH MAP"
        main_area_label = str(manual_plan.get("main_area_label") or f"PRIMARY {side_word} AREA")
        add_area_label = str(manual_plan.get("add_area_label") or f"SECONDARY {side_word} AREA")

        def _zone_text(zone: Dict[str, Any]) -> str:
            try:
                low = float(zone.get("low"))
                high = float(zone.get("high"))
                return f"{self._money(low, symbol)} → {self._money(high, symbol)}"
            except Exception:
                return "--"

        def _f(value: Any) -> float | None:
            try:
                return float(value)
            except Exception:
                return None

        def _targets() -> tuple[float | None, float | None]:
            entry = _f(plan.get("primary_entry_price"))
            invalidation = _f(plan.get("invalidation_level"))
            target = _f(plan.get("target_liquidity"))
            if entry is None or invalidation is None or target is None:
                return None, target
            risk = abs(invalidation - entry)
            reward = abs(target - entry)
            if risk <= 0 or reward <= 0:
                return None, target
            tp1_dist = min(max(risk, reward * 0.35), reward * 0.5)
            if bias == "BUY":
                return round(entry + tp1_dist, 2), round(target, 2)
            if bias == "SELL":
                return round(entry - tp1_dist, 2), round(target, 2)
            return None, round(target, 2)

        def _opinion_line(opinion: Dict[str, Any]) -> str:
            direction = str(opinion.get("direction") or "WAIT").upper()
            emoji = "🟢" if direction == "BUY" else "🔴" if direction == "SELL" else "⚪"
            label = str(opinion.get("label") or opinion.get("key") or "Agent")
            conf = opinion.get("confidence")
            signals = [str(x).strip() for x in (opinion.get("signals") or []) if str(x).strip()]
            note = "; ".join(signals[:2]) if signals else str(opinion.get("summary") or "").strip()
            if len(note) > 180:
                note = note[:177].rstrip() + "..."
            line = f"{emoji} <b>{html.escape(label)}</b>: {html.escape(direction)}"
            if conf not in {None, ""}:
                line += f" ({float(conf):.0f}%)"
            if opinion.get("external_confirmation"):
                line += " · external confirmation"
            else:
                weight = opinion.get("weight")
                if weight not in {None, ""}:
                    line += f" · weight {float(weight) * 100:.0f}%"
                if opinion.get("qualified"):
                    line += " · QUALIFIED"
                else:
                    bar = float(opinion.get("qualification_bar") or 67)
                    line += f" · NOT QUALIFIED (<{bar:.0f}%)"
            if note:
                line += f" — {self._clean_text(note)}"
            return line

        def _conditional_map_lines(opinion: Dict[str, Any]) -> List[str]:
            conditional = opinion.get("conditional_map") or {}
            if not isinstance(conditional, dict) or not conditional:
                return []
            direction = str(conditional.get("direction") or "WAIT").upper()
            if direction not in {"BUY", "SELL"}:
                return []
            emoji = "🟢" if direction == "BUY" else "🔴"
            zone = conditional.get("zone") or {}
            state = str(
                conditional.get("entry_timing") or conditional.get("setup_state") or "WATCH"
            ).upper()
            trigger = str(conditional.get("trigger_state") or "").upper()
            if monitoring_only:
                trigger = trigger.replace("_CONFIRMED", "_OBSERVED")
            counted = bool(opinion.get("conditional_map_counted_as_vote"))
            context_note = "counted as current vote" if counted else "context only · not counted as a vote"
            out = [
                f"↳ {emoji} <b>Conditional {html.escape(direction)} map</b> · {html.escape(context_note)}",
                f"   Zone {_zone_text(zone)} · Entry {self._money(conditional.get('entry_price'), symbol)} · "
                f"SL {self._money(conditional.get('stop_loss'), symbol)} · Target {self._money(conditional.get('target'), symbol)}",
            ]
            quality = conditional.get("quality")
            return_probability = conditional.get("return_probability")
            metrics = [f"State {state}"]
            if trigger:
                metrics.append(f"trigger {trigger}")
            if quality not in {None, ""}:
                metrics.append(f"quality {float(quality):.1f}")
            if return_probability not in {None, ""}:
                metrics.append(f"return {float(return_probability):.1f}")
            out.append("   " + html.escape(" · ".join(metrics)))
            return out

        primary_execution = plan.get("primary_execution") or {}
        tp1_fallback, tp2_fallback = _targets()
        tp1 = primary_execution.get("tp1") if primary_execution.get("tp1") not in {None, ""} else tp1_fallback
        tp2 = primary_execution.get("tp2") if primary_execution.get("tp2") not in {None, ""} else (tp2_fallback if tp2_fallback not in {None, ""} else plan.get("target_liquidity"))
        stop_level = primary_execution.get("stop_loss") if primary_execution.get("stop_loss") not in {None, ""} else plan.get("invalidation_level")
        expected = str(manual_plan.get("expected_path") or plan.get("expected_path") or "").strip()
        confirmation_items = [str(x) for x in (manual_plan.get("confirmation_items") or []) if str(x).strip()]
        execution_items = [str(x) for x in (manual_plan.get("execution_items") or []) if str(x).strip()]
        missed_area_plan = str(manual_plan.get("missed_area_plan") or "").strip()
        map_change_plan = str(manual_plan.get("map_change_plan") or "").strip()
        risk_note = str(manual_plan.get("risk_note") or "").strip()
        agent_opinions = [op for op in (plan.get("agent_opinions") or []) if isinstance(op, dict)]
        execution_admission = plan.get("execution_admission") or {}
        agent_book = plan.get("agent_book_summary") or {}
        shared_market_data = plan.get("shared_market_data") or {}
        qualified_core = sum(1 for op in agent_opinions if op.get("qualified"))
        support_count = int(agent_book.get("support_count", 0) or 0)
        opposition_count = int(agent_book.get("opposition_count", 0) or 0)
        inactive_count = int(agent_book.get("inactive_count", max(0, 5 - qualified_core)) or 0)
        support_names = [str(x) for x in (agent_book.get("supporters") or [])]
        opposition_names = [str(x) for x in (agent_book.get("opponents") or [])]
        gemini_plan_review = plan.get("gemini_plan_review") or {}
        gemini_macro_review = plan.get("gemini_macro_review") or {}
        gemini_news_review = plan.get("gemini_news_review") or {}

        top_title = (
            "WATCH MAP — MONITORING ONLY"
            if monitoring_only
            else "SESSION OPENING PLAN" if delivery_kind == "OPENING_PLAN"
            else "PLAN UPDATE"
        )
        objective_label = str(manual_plan.get("objective_label") or plan.get("day_objective_label") or "").strip()
        market_objective_label = str(manual_plan.get("market_objective_label") or plan.get("market_objective_label") or "").strip()
        execution_priority_label = str(manual_plan.get("execution_priority_label") or "").strip()
        objective_alignment = str(manual_plan.get("objective_alignment") or plan.get("objective_alignment") or "").strip()
        lines = [
            (
                "🛣️ <b>NO EXECUTION PATH — MONITORING ONLY</b>"
                if monitoring_only else path_header(plan)
            ),
            f"🧭 <b>{html.escape(symbol)} — {html.escape(top_title)}</b>",
            f"<b>{html.escape(headline)}</b>",
            "━━━━━━━━━━━━━━━━━━━━━",
        ]
        if monitoring_only:
            lines.extend([
                "🟡 <b>MONITORING ONLY — NOT EXECUTION-ADMITTED</b>",
                "⛔ <b>No Market, Pending or revived-plan order can be created from this card.</b>",
            ])
        lines.extend([
            f"{'🟢' if bias == 'BUY' else '🔴' if bias == 'SELL' else '🟡'} <b>Bias:</b> {html.escape(bias)}",
            f"🏷️ <b>Session:</b> {html.escape(str(plan.get('session_label') or '--'))} · {html.escape(str(plan.get('session_quality') or '--'))}",
            f"🏅 <b>Map quality:</b> {html.escape(display_grade)} {display_score:.1f}/100 <i>(quality, not probability)</i>",
            f"🧭 <b>Authority:</b> {html.escape('MAP CONTEXT ONLY' if monitoring_only else authority)}",
            f"🗳️ <b>Core book:</b> 🟢 {support_count} support · 🔴 {opposition_count} oppose · ⚪ {inactive_count} wait/below {float(plan.get('agent_min_confidence') or 67):.0f}%",
            f"⚙️ <b>Execution admission:</b> {html.escape(str(execution_admission.get('path') or 'BLOCKED'))} · net {float(execution_admission.get('confidence') or 0):.1f}%",
        ])
        if support_names or opposition_names:
            lines.append(
                f"📌 <b>Counted:</b> support [{html.escape(', '.join(support_names) or 'none')}] · "
                f"oppose [{html.escape(', '.join(opposition_names) or 'none')}]"
            )
        if shared_market_data:
            lines.append(
                f"📚 <b>Data:</b> one shared stored MT5 snapshot · "
                f"{html.escape(str(shared_market_data.get('snapshot_id') or '--'))}"
            )
        if market_objective_label:
            lines.append(f"🎯 <b>Market objective:</b> {html.escape(market_objective_label)}")
        if objective_label and objective_label != market_objective_label:
            lines.append(f"🧩 <b>Plan type:</b> {html.escape(objective_label)}")
        elif objective_label and not market_objective_label:
            # Only stand in for the market objective when there isn't one;
            # printing both when they are identical repeated the same sentence.
            lines.append(f"🎯 <b>Objective:</b> {html.escape(objective_label)}")
        if execution_priority_label:
            lines.append(f"🧭 <b>Execution priority:</b> {html.escape(execution_priority_label)}")
        if objective_alignment == "COUNTER_OBJECTIVE_REVERSAL_CONFIRMED":
            lines.append("⚠️ <b>Mode:</b> Counter-objective reversal — no add leg until broader objective flips")
        if delivery_reason:
            lines.append(f"📝 <b>Why now:</b> {html.escape(delivery_reason.replace('_', ' '))}")
        lines.append("──────────────────")
        lines.append(f"🎯 <b>{html.escape(main_area_label)}</b>")
        lines.append(f"• Zone: {html.escape(_zone_text(primary_zone))}")
        lines.append(f"• Ref entry: {self._money(plan.get('primary_entry_price'), symbol)}")
        standby_zone_text = _zone_text(standby_zone)
        standby_entry = plan.get('standby_entry_price')
        if standby_zone_text != "--" or standby_entry not in {None, ""}:
            lines.append(f"• {html.escape(add_area_label)}: {html.escape(standby_zone_text)} @ {self._money(standby_entry, symbol)}")
        lines.append(f"🛑 <b>INVALIDATION</b> · {self._money(stop_level, symbol) if stop_level not in {None, ''} else '--'}")
        if tp1 is not None or tp2 is not None:
            target_bits = []
            if tp1 is not None:
                target_bits.append(f"TP1 {self._money(tp1, symbol)}")
            if tp2 is not None:
                target_bits.append(f"TP2 {self._money(tp2, symbol)}")
            lines.append(f"🎯 <b>TARGETS</b> · {' · '.join(target_bits)}")
        # Display-only liquidity references. TP1/TP2 above remain the exact
        # primary_execution targets. Nearby pool prices are grouped so a $5
        # gap (50 gold points) is not presented as an independent L2.
        try:
            primary_poi = plan.get("primary_poi") or {}
            poi_details = primary_poi.get("details") if isinstance(primary_poi, dict) else {}
            liq_map = poi_details.get("liquidity") if isinstance(poi_details, dict) else {}
            entry_ref = _f(plan.get("primary_entry_price"))
            stop_ref = _f(stop_level)
            if isinstance(liq_map, dict) and entry_ref is not None and stop_ref is not None and bias in {"BUY", "SELL"}:
                side_key = "buy_side" if bias == "BUY" else "sell_side"
                display = liquidity_display_zones(
                    levels=liq_map.get(side_key) or [],
                    direction=bias,
                    entry=entry_ref,
                    stop=stop_ref,
                    symbol=symbol,
                    config=self.config,
                )

                def _display_pool(label: str, pool: Dict[str, Any]) -> str:
                    anchor = _f(pool.get("anchor"))
                    text = f"{label} {self._money(anchor, symbol)}"
                    rr = _f(pool.get("rr"))
                    if rr is not None:
                        text += f" ({rr:.1f}R)"
                    if pool.get("clustered"):
                        low = _f(pool.get("low"))
                        high = _f(pool.get("high"))
                        if low is not None and high is not None:
                            text += f" · zone {self._money(low, symbol)}–{self._money(high, symbol)}"
                    return text

                l1 = display.get("l1") or {}
                l2 = display.get("l2") or {}
                if l1:
                    liq_bits = [_display_pool("L1", l1)]
                    if l2:
                        liq_bits.append(_display_pool("L2", l2))
                    else:
                        gap = float(display.get("min_separation_points") or 0)
                        liq_bits.append(f"L2 -- no independent pool (needs ≥{gap:.0f} pts from L1)")
                    lines.append(f"💧 <b>LIQUIDITY REFERENCES</b> · {' · '.join(liq_bits)}")
                    lines.append("ℹ️ <i>L1/L2 are liquidity references; TP1/TP2 above are the execution targets.</i>")
        except Exception:  # noqa: BLE001 - never block map delivery on formatting
            pass
        if risk_note:
            lines.append(f"⚠️ <b>Risk note:</b> {html.escape(risk_note)}")
        exec_summary = (
            "MONITOR ONLY — wait for full shared admission; no order is authorized"
            if monitoring_only
            else execution_items[0] if execution_items
            else str(plan.get("execution_preference") or scenario)
        )
        lines.append(f"⚙️ <b>{'MONITORING PLAN' if monitoring_only else 'EXECUTION PLAN'}</b> · {self._clean_text(exec_summary)}")
        if str(plan.get("poi_classification") or "").strip():
            lines.append(f"• Class: {html.escape(str(plan.get('poi_classification')))} · Setup: {html.escape(scenario)}")
        if expected:
            lines.append(f"🧠 <b>THESIS</b> · {html.escape(expected)}")
        if confirmation_items and not monitoring_only:
            lines.append(f"✅ <b>CONFIRMATION</b> · {html.escape(confirmation_items[0])}")
        if missed_area_plan:
            lines.append(f"📌 <b>If missed:</b> {html.escape(missed_area_plan)}")
        if map_change_plan:
            lines.append(f"🔄 <b>If map changes:</b> {html.escape(map_change_plan)}")
        if agent_opinions:
            lines.append("──────────────────")
            lines.append("🗳️ <b>AGENT READS</b>")
            for opinion in agent_opinions:
                lines.append(_opinion_line(opinion))
                lines.extend(_conditional_map_lines(opinion))
        ai_lines: List[str] = []
        if isinstance(gemini_plan_review, dict) and gemini_plan_review.get("available"):
            verdict = gemini_plan_review.get("market_bias") or gemini_plan_review.get("verdict") or gemini_plan_review.get("opinion") or "REVIEWED"
            reason = gemini_plan_review.get("reason") or gemini_plan_review.get("summary") or ""
            ai_lines.append(f"🧠 Gemini: {self._clean_text(verdict)}" + (f" — {self._clean_text(reason)}" if reason else ""))
        if isinstance(gemini_macro_review, dict) and gemini_macro_review.get("available"):
            verdict = gemini_macro_review.get("macro_verdict") or gemini_macro_review.get("verdict") or "NEUTRAL"
            conf = gemini_macro_review.get("confidence")
            ai_lines.append(f"🌍 Macro: {self._clean_text(verdict)}" + (f" ({html.escape(str(conf))}%)" if conf not in {None, ''} else ""))
        if isinstance(gemini_news_review, dict) and gemini_news_review.get("available"):
            risk = str(gemini_news_review.get("risk_level") or "LOW").upper()
            advice = str(gemini_news_review.get("trading_advice") or "").strip()
            ai_lines.append(f"📰 News: {html.escape(risk)}" + (f" — {self._clean_text(advice)}" if advice else ""))
        if ai_lines:
            lines.append("──────────────────")
            lines.append("🤖 <b>AI REVIEW</b>")
            lines.extend(ai_lines[:3])
        if status != "READY" and str(plan.get("plan_reason") or "").strip():
            lines.append(f"⚠️ <b>Plan status:</b> {html.escape(str(plan.get('plan_reason')))}")
        lines.append("━━━━━━━━━━━━━━━━━━━━━")
        if monitoring_only:
            lines.append("<i>Monitoring only: shared execution admission is BLOCKED. This card cannot create an order.</i>")
        else:
            lines.append("<i>Shared agent admission passed; final risk, price and broker validation still apply.</i>")
        compact = [line for line in lines if str(line).strip()]
        return self.send_message("\n".join(compact), urgent=not monitoring_only)

    def send_signal(self, decision: Dict[str, Any]) -> bool:
        symbol = str(decision.get("symbol", "XAU/USD"))
        signal = decision.get("signal", {}) or {}
        trade_type = str(decision.get("decision") or signal.get("type") or "WAIT").upper()
        emoji = "🟢" if trade_type == "BUY" else "🔴" if trade_type == "SELL" else "🟡"
        ai = decision.get("ai") or {}
        risk = decision.get("risk") or {}
        dynamic = decision.get("dynamic_risk") or {}
        quality = decision.get("quality") or {}
        entry = signal.get("entry", {}) or {}

        entry_mode = str(decision.get('entry_mode', '')).lower()
        path = resolve_execution_path(decision)
        entry_path_num = int(path.get("number") or 0)
        confirm_source = str(decision.get('confirm_source', ''))
        confirm_conf = decision.get('confirm_confidence')

        # Admission path is the first line on every trade card. Session Plan is
        # execution context, not a fifth route and not an alias for Path 3.
        planner_led = bool(decision.get("planner_execution_gate")) or entry_mode in {
            'session_plan_ladder', 'session_plan_ladder_market',
            'path4_smc_map_auction_limit',
        }
        if entry_path_num == 2:
            confirm_line = f'📊 Macro confirms {trade_type} ({confirm_conf:.0f}% confidence ≥ 55%)' if confirm_conf else None
        elif entry_path_num == 3:
            confirm_line = f'🧠 Gemini confirms {trade_type} ({confirm_conf:.0f}% confidence ≥ 70%)' if confirm_conf else None
        else:
            confirm_line = None

        lines: List[str] = [
            path_header(decision),
            f"{emoji} <b>{html.escape(symbol)} — {html.escape(trade_type)}</b>",
            *(["<b>🧭 SESSION PLAN / DAY MAP</b>"] if planner_led else []),
            "━━━━━━━━━━━━━━━━━━━━━",
            f"📈 Price {self._money(decision.get('current_price'), symbol)} · Confidence {decision.get('confidence')}%",
            f"🕒 {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
        ]
        if confirm_line:
            lines.append(f"✅ {html.escape(confirm_line)}")
        planner_gate = decision.get("planner_execution_gate") or {}
        if planner_led and isinstance(planner_gate, dict) and planner_gate.get("allow"):
            gate_reason = str(planner_gate.get("reason") or "Planner execution admitted").strip()
            lines.append(f"✅ Admission: {html.escape(gate_reason)}")
            # Admission reported only the agents that agreed. A signal headed
            # "3 qualified agents aligned" listed three more disagreeing a few
            # lines below, which read as a contradiction rather than a
            # tolerated minority. State the dissent on the same line.
            dissent = planner_gate.get("oppose_agents") or []
            if isinstance(dissent, list) and dissent:
                labels = ", ".join(str(name).replace("_", " ") for name in dissent)
                lines.append(f"⚠️ Dissent: {len(dissent)} qualified agent(s) opposed — {html.escape(labels)}")
        if planner_led:
            plan = decision.get("session_plan") or {}
            market_objective_label = str(((plan.get("manual_plan") or {}).get("market_objective_label") if isinstance(plan, dict) else "") or plan.get("market_objective_label") or "").strip()
            execution_priority_label = str(((plan.get("manual_plan") or {}).get("execution_priority_label") if isinstance(plan, dict) else "") or "").strip()
            objective_alignment = str(((plan.get("manual_plan") or {}).get("objective_alignment") if isinstance(plan, dict) else "") or plan.get("objective_alignment") or "").strip()
            if market_objective_label:
                lines.append(f"🎯 Objective: {html.escape(market_objective_label)}")
            if execution_priority_label:
                lines.append(f"🧭 Priority: {html.escape(execution_priority_label)}")
            if objective_alignment == "COUNTER_OBJECTIVE_REVERSAL_CONFIRMED":
                lines.append("⚠️ Counter-objective reversal — main leg only")
        if quality:
            # "Quality" alone invited the reader to compare this with the POI
            # grade printed further down, which measures something else
            # entirely. Name the subject: this is the whole signal's grade.
            quality_label = "Setup quality" if planner_led else "Signal quality"
            lines.append(f"🏅 {html.escape(quality_label)}: {html.escape(str(quality.get('grade', '')))} {html.escape(str(quality.get('score', '')))}".rstrip())
        if planner_led:
            planner_quality = decision.get("planner_quality") or {}
            if isinstance(planner_quality, dict) and planner_quality.get("score") not in {None, ""}:
                lines.append(f"🧭 Planner score: {html.escape(str(planner_quality.get('grade') or '--'))} {html.escape(str(planner_quality.get('score')))}")
        strength_line = self._session_plan_signal_strength_line(decision) if planner_led else self._signal_strength_line(decision)
        if strength_line:
            lines.append(strength_line)
        order_kind = str(signal.get("entry_kind") or signal.get("order_type") or entry.get("kind") or "MARKET").upper()
        rr = signal.get("rr_ratio") or signal.get("tp2_rr") or decision.get("planned_rr")
        entry_price = entry.get('price') or decision.get('current_price')
        lines.extend([
            "──────────────────",
            "🎯 <b>TRADE PLAN</b>",
            f"• <b>Order:</b> {html.escape(trade_type)} {html.escape(order_kind)}",
            f"• <b>Entry:</b> {self._money(entry_price, symbol)}",
        ])
        leg_label = self._execution_leg_label(decision.get("setup_context") or {}, decision.get("session_plan") or {}, direction=trade_type)
        if leg_label:
            lines.append(f"• <b>Execution leg:</b> {html.escape(leg_label)}")
        # A target trimmed by the max_rr ceiling is a computed boundary, not a
        # level the market is drawn to. Publishing it unmarked implied a
        # structural objective: a TP2 landing on exactly 4.00R was presented
        # the same way as one sitting on a real liquidity pool.
        tp2_note = ""
        target_method = str(signal.get("target_method") or "")
        if "max_rr_cap" in target_method:
            tp2_note = " <i>(capped at max R:R — not a liquidity level)</i>"
        elif "extended_liquidity" in target_method:
            tp2_note = " <i>(extended to the next pool)</i>"
        lines.extend([
            f"• <b>Stop Loss:</b> {self._money(signal.get('stop_loss'), symbol)}",
            f"• <b>TP1:</b> {self._money(signal.get('tp1'), symbol)}",
            f"• <b>TP2:</b> {self._money(signal.get('tp2'), symbol)}{tp2_note}",
        ])
        if order_kind.endswith("LIMIT") or order_kind.endswith("STOP"):
            try:
                curr = float(entry.get('current_price') or decision.get('current_price') or 0)
                ent = float(entry_price or 0)
                pts = float(entry.get('distance_points') or 0)
            except (TypeError, ValueError):
                curr = 0.0
                ent = 0.0
                pts = 0.0
            activation = "price reaches the entry level"
            if order_kind == "SELL_LIMIT":
                activation = f"price rallies up to {ent:.2f}"
            elif order_kind == "BUY_LIMIT":
                activation = f"price pulls back down to {ent:.2f}"
            elif order_kind == "SELL_STOP":
                activation = f"price breaks down to {ent:.2f}"
            elif order_kind == "BUY_STOP":
                activation = f"price breaks up to {ent:.2f}"
            lines.append("• <b>Status:</b> Pending order — not active yet")
            if curr > 0:
                lines.append(f"• <b>Current price:</b> {curr:.2f} · {pts:.0f} pts to activation")
            lines.append(f"• <b>Activation:</b> This trade activates only when {html.escape(activation)}")
        # Report RR per target. The single number was always the TP2 ratio,
        # but breakeven protection makes an exit at or near TP1 the likelier
        # outcome, so showing only TP2 overstates the expected return.
        rr_line = self._planned_rr_line(signal, rr)
        if rr_line:
            lines.append(rr_line)
        lines.extend(self._management_lines(decision, signal))
        setup_lines = self._setup_lines(decision, signal)
        if setup_lines:
            lines.extend(setup_lines)

        vote_lines = self._votes_lines(decision)
        if vote_lines:
            lines.append("──────────────────")
            lines.extend(vote_lines)

        context_lines: List[str] = []
        if ai.get("available"):
            if ai.get("entry_reason"):
                context_lines.append(f"• AI reason: {self._clean_text(ai.get('entry_reason'))}")
            if ai.get("risk_notes"):
                context_lines.append(f"• Risk note: {self._clean_text(ai.get('risk_notes'))}")
            if self._should_show_invalidation(ai.get("invalidation"), signal.get("stop_loss")):
                context_lines.append(f"• Invalidation: {self._clean_text(ai.get('invalidation'))}")
        daily_bias = decision.get("daily_bias") or {}
        if daily_bias:
            bias_conf = daily_bias.get("confidence")
            bias_conf_text = f" ({bias_conf}%)" if bias_conf is not None else ""
            context_lines.append(
                f"• Daily bias: {html.escape(str(daily_bias.get('bias', 'NEUTRAL')))}{html.escape(bias_conf_text)}"
            )
        # Macro block — rich macro-aware July 2026
        context_lines.extend(self._macro_block(decision))
        session_info = decision.get("session_info") or {}
        if session_info.get("current_session"):
            session_quality = session_info.get("session_quality") or session_info.get("quality")
            suffix = f" · {session_quality}" if session_quality else ""
            # current_session is now classified (e.g. "Asia Morning")
            # instead of the raw config name (e.g. "Main Trading Session")
            context_lines.append(f"• Session: {html.escape(str(session_info.get('current_session')))}{html.escape(suffix)}")
        news_context = decision.get("news_context") or {}
        news_rule = news_context.get("rule_based", {}) if isinstance(news_context, dict) else {}
        if news_rule.get("market_status") or news_rule.get("risk_level"):
            no_block = " — no hard block" if news_rule.get("can_trade", True) is not False else " — blocked"
            context_lines.append(
                f"• News: {html.escape(str(news_rule.get('market_status') or 'OK'))}"
                f" / {html.escape(str(news_rule.get('risk_level') or 'LOW'))}{html.escape(no_block)}"
            )
        if dynamic and str(dynamic.get("level", "NORMAL")).upper() != "NORMAL":
            context_lines.append(f"• Dynamic risk: {html.escape(str(dynamic.get('level')))}")
        # Keep risk details compact and useful; skip empty optional risk block.
        # Derive the stop distance from the trade being sent, not from the
        # risk-settings block. The configured floor was being printed verbatim
        # -- a signal risking 150 points announced "SL distance: 400.0 pts".
        sl_dist = None
        try:
            _entry = float((entry or {}).get("price") or decision.get("current_price") or 0)
            _stop = float(signal.get("stop_loss") or 0)
            if _entry > 0 and _stop > 0:
                from utils.instruments import price_to_points
                sl_dist = round(abs(price_to_points(_entry - _stop, symbol=symbol)), 1)
        except (TypeError, ValueError):
            sl_dist = None
        if not sl_dist:
            sl_dist = ((risk.get("stop_loss") or {}) if isinstance(risk, dict) else {}).get("distance_points")
        if sl_dist:
            context_lines.append(f"• SL distance: {html.escape(str(sl_dist))} pts")
        if context_lines:
            lines.append("──────────────────")
            lines.append("⚠️ <b>RISK / CONTEXT</b>")
            lines.extend(context_lines)

        independent_review = self._independent_review_lines(decision)
        if independent_review:
            lines.append("──────────────────")
            lines.extend(independent_review)

        # Macro independent review — July 2026
        gemini_macro = decision.get("gemini_macro_review", {}) or {}
        if gemini_macro.get("available"):
            lines.append("──────────────────")
            lines.append("🌍 <b>GEMINI MACRO REVIEW</b>")
            mv = str(gemini_macro.get("macro_verdict", "NEUTRAL"))
            mconf = gemini_macro.get("confidence", "")
            mdriver = gemini_macro.get("primary_driver", "")
            mreason = gemini_macro.get("reason", "")
            mtbias = gemini_macro.get("trade_bias", "")
            lines.append(f"• <b>Verdict:</b> {html.escape(mv)}" + (f" ({mconf}%)" if mconf not in {None, ""} else ""))
            if mdriver:
                lines.append(f"• <b>Driver:</b> {html.escape(str(mdriver))}")
            if mreason:
                lines.append(f"• {self._clean_text(mreason)}")
            if mtbias:
                lines.append(f"• <b>Trade bias:</b> {html.escape(str(mtbias))}")
            inval = gemini_macro.get("invalidation")
            if inval:
                lines.append(f"• <b>Invalidation:</b> {self._clean_text(inval)}")

        gemini_news = decision.get("gemini_news_review", {}) or {}
        if gemini_news.get("available"):
            risk_level = str(gemini_news.get("risk_level") or "LOW").upper()
            lines.append("──────────────────")
            lines.append("📰 <b>GEMINI NEWS CHECK</b>")
            lines.append(f"• <b>Risk:</b> {html.escape(risk_level)}")
            bullets = [str(x) for x in (gemini_news.get("summary_bullets") or []) if str(x).strip()]
            for bullet in bullets[:2]:
                lines.append(f"• {self._clean_text(bullet)}")
            advice = str(gemini_news.get("trading_advice") or "").strip()
            if advice and advice.upper() not in {"N/A", "NONE", "NOT APPLICABLE"}:
                lines.append(f"• Advice: {self._clean_text(advice)}")

        lines.extend([
            "━━━━━━━━━━━━━━━━━━━━━",
            "<i>Educational signal; not financial advice.</i>",
            f"<i>ID: {html.escape(str(decision.get('trade_id') or 'N/A'))}</i>",
        ])
        text = "\n".join(line for line in lines if str(line).strip())
        while "\n\n\n" in text:
            text = text.replace("\n\n\n", "\n\n")
        # send_message owns the single canonical DEMO marker and dedup boundary.
        return self.send_message(text)

    def _event_title(self, events: List[str]) -> str:
        for event in self.EVENT_PRIORITY:
            if event in events:
                return self.EVENT_LABELS.get(event, event.replace("_", " ").title())
        return self.EVENT_LABELS.get(events[0], events[0].replace("_", " ").title()) if events else "Trade Update"

    # Each cancellation path gets its own sentence. Nine distinct guards can
    # cancel a pending order; collapsing them into one generic note made it
    # impossible to tell which guard fired when reviewing a paper-trading run.
    CANCEL_REASON_NOTES = {
        # Deliberately does not claim the market moved. PLAN_STALE covers
        # several measured conditions -- waiting time, excursion, path
        # progress, an expired plan -- and the old wording asserted the
        # excursion case for all of them. On 2026-07-29 an order cancelled 103
        # points from activation was reported as "the market moved away",
        # which was simply untrue. The specific measurement is already carried
        # in the cancellation reason line above this note.
        "PLAN_STALE": "Pending order was cancelled because its map is no longer fresh — see the reason above for which limit was reached.",
        "OPPOSITE_PLAN_GUARD": "Pending order was cancelled because a confirmed plan in the opposite direction took over.",
        "RR_BELOW_MINIMUM": "Pending order was cancelled because its planned reward-to-risk fell below the minimum.",
        "LATE_TOUCH_REVALIDATION_FAILED": "Entry was touched late, and revalidation failed (no fresh confirmation, drift too large, or RR degraded).",
        "MARKET_CONVERSION_BLOCKED": "Pending order was cancelled because converting it to a market entry was not allowed.",
        "AUTO_CONVERSION_BLOCKED": "Pending order was cancelled after automatic market conversion was blocked.",
        "POST_NEWS_REVALIDATION_FAILED": "Pending order was cancelled after post-news revalidation failed (invalidated, drift too large, or RR degraded).",
    }

    def _trailing_rule_text(self, updates: Dict[str, Any] | None = None) -> str:
        """Describe the trailing rule that was actually applied.

        This line used to be the literal string "150-point gap / 40-point
        step". A trade running continuation_profile trails at 170/45, so the
        card contradicted both the plan message and the stop it was reporting
        in the same breath. The manager now publishes the values it used.
        """
        updates = updates if isinstance(updates, dict) else {}
        mgmt = (self.config.get("trade_management") or {}) if isinstance(self.config, dict) else {}
        gap = updates.get("trailing_distance_points")
        step = updates.get("trailing_step_points")
        if gap is None:
            gap = mgmt.get("trailing_distance_points", 150)
        if step is None:
            step = mgmt.get("trailing_step_points", 40)
        try:
            gap_txt, step_txt = f"{float(gap):.0f}", f"{float(step):.0f}"
        except (TypeError, ValueError):
            gap_txt, step_txt = "150", "40"
        text = f"{gap_txt}-point gap / {step_txt}-point step"
        if updates.get("reversal_trail_active"):
            text += " (tightened: the agent book turned against this trade)"
        return text

    def _event_notes(self, events: List[str], cancel_reason_code: str | None = None, updates: Dict[str, Any] | None = None) -> List[str]:
        notes = []
        if "NEWS_HOLD" in events:
            notes.append("Pending order touched during a blocked news window; activation was paused until post-news recheck.")
        if "PENDING_CANCELLED" in events:
            notes.append(
                self.CANCEL_REASON_NOTES.get(
                    str(cancel_reason_code or "").upper(),
                    "Pending order was cancelled before activation because the mapped execution conditions were no longer valid.",
                )
            )
        if "EXIT_WARNING" in events:
            notes.append("Exit/risk warning: trade is moving adversely or risk conditions changed.")
        if "LONG_RUNNING" in events:
            notes.append("Trade has been open for a long time; monitor closely.")
        if "MOVE_SL_TO_BE" in events:
            notes.append("Stop loss moved to entry / breakeven protection.")
        if "TRAILING_SL_UPDATED" in events:
            notes.append(f"Trailing stop updated using {self._trailing_rule_text(updates)}.")
        if "THESIS_SCALE_OUT" in events:
            notes.append("Position size was reduced because thesis risk increased before the formal target was reached.")
        if "TP1_HIT" in events:
            notes.append("TP1 reached; partial profit/protection rules applied.")
        if "TP2_HIT" in events:
            notes.append("Final target reached.")
        if "SL_HIT" in events:
            notes.append("Stop loss was hit.")
        if "TRAILING_SL_HIT" in events:
            notes.append("Trailing stop was hit.")
        if "BE_HIT" in events:
            notes.append("Breakeven stop was hit.")
        if "ORDER_FILLED" in events:
            notes.append("Pending order was activated and is now a live trade.")
        if "EXPIRED" in events:
            notes.append("Trade/order expired by time rule.")
        return notes

    @staticmethod
    def _fmt_points(value: Any) -> str:
        try:
            return f"{float(value):+.1f} pts"
        except (TypeError, ValueError):
            return "+0.0 pts"

    def _progress_report(self, trade: Dict[str, Any], updates: Dict[str, Any],
                         evaluation: Dict[str, Any]) -> str | None:
        """Human-readable TP1/TP2 progress.

        Operator directive (2026-08-06): never print a stuck/zero progress. When
        price is between TP1 and TP2 show TP1 done plus how much is left to TP2;
        when TP2 is hit show both completed; below TP1 show both percentages.
        """
        try:
            entry = float(trade.get("entry_price") or 0)
            tp1 = float(trade.get("tp1") or 0)
            tp2 = float(trade.get("tp2") or 0)
        except (TypeError, ValueError):
            return None
        if entry <= 0 or (tp1 <= 0 and tp2 <= 0):
            return None
        price = 0.0
        for source in (updates or {}, trade or {}):
            for key in ("close_price", "current_price"):
                try:
                    v = float(source.get(key))
                    if v:
                        price = v
                        break
                except (TypeError, ValueError):
                    continue
            if price:
                break
        if price <= 0:
            return None
        trade_type = str(trade.get("type") or trade.get("side") or "BUY").upper()

        def frac(target: float) -> float | None:
            dist = abs(target - entry)
            if dist <= 0:
                return None
            move = (price - entry) if trade_type == "BUY" else (entry - price)
            return move / dist

        def pts_left(target: float) -> float:
            return abs(target - price) / 0.10

        p1 = frac(tp1) if tp1 > 0 else None
        p2 = frac(tp2) if tp2 > 0 else None
        tp1_done = p1 is not None and p1 >= 1
        tp2_done = p2 is not None and p2 >= 1
        if tp2_done:
            return "TP1 ✓ · TP2 ✓ completed"
        if tp1_done and p2 is not None:
            return (f"TP1 ✓ · TP2 {max(0.0, min(p2, 1)) * 100:.0f}% "
                    f"({pts_left(tp2):.0f} pts left)")
        parts = []
        if p1 is not None:
            parts.append(f"TP1 {max(0.0, min(p1, 1)) * 100:.0f}%")
        if p2 is not None:
            parts.append(f"TP2 {max(0.0, min(p2, 1)) * 100:.0f}%")
        return " · ".join(parts) or None

    @staticmethod
    def _first_reason(*sources: Any) -> str | None:
        for source in sources:
            if isinstance(source, list) and source:
                text = str(source[0]).strip()
                if text:
                    return text
            if isinstance(source, str) and source.strip():
                return source.strip()
        return None

    def send_trade_events(
        self,
        trade: Dict[str, Any],
        events: List[str],
        current_price: float,
        pnl_points: float,
        evaluation: Dict[str, Any],
    ) -> bool:
        if not events:
            return False
        side = str(trade.get("type") or trade.get("side") or "").upper()
        symbol = str(trade.get("symbol") or "XAU/USD")
        old_status = str(evaluation.get("old_status") or trade.get("status") or "OPEN")
        new_status = str(evaluation.get("new_status") or old_status)
        updates = evaluation.get("updates") or {}
        primary_reason = self._first_reason(updates.get("reasons"), trade.get("reasons"))
        # The event itself now carries the distinction, so the title no longer
        # has to guess it from the wording of the reason. A close written by
        # the automatic thesis check is THESIS_EXIT; MANUAL_CLOSE means a human
        # closed it. Older rows kept the reason-sniffing path below.
        title = self._event_title(events)
        if "THESIS_EXIT" not in events and "MANUAL_CLOSE" in events and primary_reason and "thesis exit" in str(primary_reason).lower():
            title = "Thesis Exit"
        closing = any(e in events for e in {"TP2_HIT", "SL_HIT", "TRAILING_SL_HIT", "BE_HIT", "EXPIRED", "THESIS_EXIT", "MANUAL_CLOSE"})

        lines = [
            f"{path_header(trade)} · 🔔 <b>{html.escape(title)}</b>",
            "━━━━━━━━━━━━━━━━━━━━━",
            f"• <b>Trade:</b> {html.escape(str(trade.get('id', 'N/A')))}",
            f"• <b>Symbol:</b> {html.escape(symbol)}",
            f"• <b>Side:</b> {html.escape(side)}",
        ]
        trade_leg_label = self._trade_execution_leg_label(trade)
        if old_status != new_status:
            lines.append(f"• <b>Status:</b> {html.escape(old_status)} → {html.escape(new_status)}")
        else:
            lines.append(f"• <b>Status:</b> {html.escape(new_status)}")
        # Report the price the order actually filled at.
        #
        # `trade` is the row as it was BEFORE this cycle's update: the send
        # happens at open_trades_manager.py:543 and the database write at
        # :566. So on the cycle that fills an order, `trade["entry_price"]`
        # still holds the PLANNED limit while `updates["entry_price"]` holds
        # the real fill.
        #
        # 2026-08-03, trade 2f72579f: a SELL LIMIT planned at 4037.48 was
        # converted to MARKET and filled at 4031.76. The activation card said
        # "Entry: 4037.48 · Current Price: 4031.76 · Distance to activation:
        # 0 pts" -- three lines that together hide 57 points of slippage and
        # describe a fill that never happened at that price.
        #
        # Every later card reads the same field, so once the row is written
        # the two agree and this changes nothing.
        filled_entry = updates.get("entry_price", trade.get("entry_price"))
        planned_entry = trade.get("entry_price")
        entry_line = f"• <b>Entry:</b> {self._money(filled_entry, symbol)}"
        try:
            if (
                "ORDER_FILLED" in events
                and planned_entry is not None
                and filled_entry is not None
                and abs(float(filled_entry) - float(planned_entry)) >= 0.01
            ):
                from utils.instruments import price_to_points

                slippage = abs(
                    price_to_points(float(filled_entry) - float(planned_entry), symbol=symbol)
                )
                entry_line += (
                    f" (planned {self._money(planned_entry, symbol)}, "
                    f"filled {slippage:.0f} pts away)"
                )
        except (TypeError, ValueError):
            pass
        lines.extend([
            entry_line,
            f"• <b>Current Price:</b> {self._money(current_price, symbol)}",
        ])
        if trade_leg_label:
            lines.append(f"• <b>Plan leg:</b> {html.escape(trade_leg_label)}")
        plan_exec = evaluation.get("plan_execution_context") or {}
        if isinstance(plan_exec, dict) and plan_exec.get("story"):
            lines.append(f"• <b>Execution story:</b> {self._clean_text(plan_exec.get('story'))}")
        if closing:
            close_price = updates.get("close_price") or updates.get("stop_loss") or current_price
            actual = updates.get("final_pnl", pnl_points)
            lines.append(f"• <b>Exit Price:</b> {self._money(close_price, symbol)}")
            lines.append(f"• <b>Actual PnL:</b> {self._fmt_points(actual)}")
        elif "NEWS_HOLD" in events or old_status == "PENDING" or new_status == "PENDING":
            # "Distance to activation" only means something while the order
            # is still waiting. On the cycle that fills it the value is 0 by
            # construction, and printing it next to a market conversion that
            # happened 57 points away from the limit reads as a claim that
            # price reached the entry. It did not -- that is why it converted.
            pts_to_fill = evaluation.get("pending_distance_points")
            if pts_to_fill is not None and "ORDER_FILLED" not in events:
                lines.append(f"• <b>Distance to activation:</b> {float(pts_to_fill):.0f} pts")
            hours_open = evaluation.get("hours_open")
            if hours_open is not None:
                lines.append(f"• <b>Waiting:</b> {float(hours_open):.1f}h")
            if "NEWS_HOLD" in events:
                lines.append("• <b>Activation:</b> Paused — touched during news blackout")
            elif "ORDER_FILLED" in events and old_status == "PENDING":
                activation_reason = updates.get("activation_reason")
                if activation_reason and "market conversion" in str(activation_reason).lower():
                    lines.append("• <b>Activation:</b> Pending order was converted to MARKET and is now live")
                else:
                    lines.append("• <b>Activation:</b> Pending order touched its trigger and is now live")
                if activation_reason:
                    lines.append(f"• <b>Activation review:</b> {self._clean_text(activation_reason)}")
                scenario_gov = evaluation.get("scenario_governor") or {}
                cancelled_siblings = scenario_gov.get("cancelled_ids") or []
                if cancelled_siblings:
                    lines.append(f"• <b>Scenario family:</b> {len(cancelled_siblings)} sibling pending order(s) cancelled")
                    if isinstance(plan_exec, dict) and plan_exec.get("pending_sibling_roles"):
                        roles = " / ".join(str(x) for x in plan_exec.get("pending_sibling_roles") or [])
                        lines.append(f"• <b>Cancelled leg(s):</b> {html.escape(roles)}")
        else:
            lines.append(f"• <b>Current PnL:</b> {self._fmt_points(pnl_points)}")

        progress = evaluation.get("progress_to_tp1")
        progress_line = self._progress_report(trade, updates, evaluation)
        if progress_line:
            lines.append(f"• <b>Progress:</b> {progress_line}")
        elif progress is not None:
            try:
                p = float(progress)
                progress_text = "completed" if p >= 1 else f"{max(0, min(p, 1)) * 100:.0f}%"
                lines.append(f"• <b>TP1 Progress:</b> {progress_text}")
            except (TypeError, ValueError):
                pass
        if "TRAILING_SL_UPDATED" in events:
            new_sl = updates.get("stop_loss")
            if new_sl is not None:
                try:
                    locked = abs(float(new_sl) - float(trade.get("entry_price", new_sl))) / 0.10
                    lines.append(f"• <b>New SL:</b> {self._money(new_sl, symbol)} — locking about +{locked:.0f} pts")
                except (TypeError, ValueError):
                    lines.append(f"• <b>New SL:</b> {self._money(new_sl, symbol)}")
            lines.append(f"• <b>Trailing rule:</b> {self._trailing_rule_text(updates)}")
        if "PENDING_CANCELLED" in events:
            cancel_reason = self._first_reason(updates.get("reasons"), trade.get("reasons"))
            if cancel_reason:
                lines.append(f"• <b>Cancellation reason:</b> {self._clean_text(cancel_reason)}")
        if any(e in events for e in {"THESIS_EXIT", "MANUAL_CLOSE", "THESIS_SCALE_OUT"}) and primary_reason:
            lines.append(f"• <b>Exit reason:</b> {self._clean_text(primary_reason)}")
        # A partial close has to state how much was actually closed and at what
        # price. `partial_close` used to be a label with no size behind it, so
        # a "scale-out" message described a reduction that never happened.
        if "THESIS_SCALE_OUT" in events:
            try:
                fraction = float(updates.get("closed_fraction") or 0.0)
            except (TypeError, ValueError):
                fraction = 0.0
            if fraction > 0:
                closed_txt = f"• <b>Closed:</b> {fraction * 100:.0f}% of the position"
                scale_price = updates.get("scale_out_price")
                if scale_price:
                    closed_txt += f" at {float(scale_price):.2f}"
                lines.append(closed_txt)
                realized = updates.get("realized_pnl_points")
                if realized is not None:
                    lines.append(f"• <b>Realized so far:</b> {float(realized):+.1f} pts")
                lines.append("• <b>Remainder:</b> still open, stop at entry")
        notes = self._event_notes(events, str(evaluation.get("cancel_reason_code") or ""), updates)
        if notes:
            lines.append("──────────────────")
            for note in notes:
                lines.append(f"• {html.escape(note)}")
        lines.append("━━━━━━━━━━━━━━━━━━━━━")
        return self.send_message("\n".join(lines), urgent=True)

    def send_trade_event(
        self,
        trade: Dict[str, Any],
        event: str,
        current_price: float,
        pnl_points: float,
        evaluation: Dict[str, Any],
    ) -> bool:
        return self.send_trade_events(trade, [event], current_price, pnl_points, evaluation)

    def send_pending_governance(self, governance: Dict[str, Any], *, symbol: str, side: str) -> bool:
        action = str(governance.get("action") or "").upper()
        if action not in {"REPLACE_PENDING", "CANCEL_PENDING_ALLOW_NEW", "KEEP_EXISTING_PENDING"}:
            return False
        reason = self._clean_text(governance.get('reason'))
        if action == "KEEP_EXISTING_PENDING" and "blocked" not in reason.lower():
            return False
        old_id = str(governance.get("old_trade_id") or "")
        short = old_id.split("_")[-1] if "_" in old_id else (old_id[-8:] if len(old_id) >= 8 else old_id or "?")
        old_ctx = governance.get("old_context") or {}
        new_ctx = governance.get("new_context") or {}
        if action == "REPLACE_PENDING":
            title = "♻️ <b>Pending Thesis Replaced</b>"
        elif action == "CANCEL_PENDING_ALLOW_NEW":
            title = "🚫 <b>Pending Thesis Cancelled</b>"
        else:
            title = "🛡️ <b>Pending Replacement Blocked</b>"
        lines = [
            title,
            "━━━━━━━━━━━━━━━━━━━━━",
            f"• <b>Symbol:</b> {html.escape(symbol)}",
            f"• <b>Side:</b> {html.escape(side)}",
        ]
        if old_id:
            lines.append(f"• <b>Previous Pending:</b> <code>#{html.escape(short)}</code>")
        lines.append(f"• <b>Reason:</b> {reason}")
        if old_ctx or new_ctx:
            lines.append(
                f"• <b>Dominance:</b> {old_ctx.get('thesis_dominance_score', '--')} → {new_ctx.get('thesis_dominance_score', '--')}"
            )
            lines.append(
                f"• <b>Reach Probability:</b> {old_ctx.get('return_probability_score', '--')} → {new_ctx.get('return_probability_score', '--')}"
            )
        lines.append("━━━━━━━━━━━━━━━━━━━━━")
        return self.send_message("\n".join(lines), urgent=True)

    def send_scenario_governance(self, governance: Dict[str, Any], *, symbol: str, side: str) -> bool:
        action = str(governance.get("action") or "").upper()
        if action not in {"REPLACE_PENDING_FAMILY", "CANCELLED_SIBLINGS_ON_ACTIVATION", "KEEP_EXISTING_FAMILY"}:
            return False
        reason = self._clean_text(governance.get("reason"))
        if action == "KEEP_EXISTING_FAMILY" and not reason:
            return False
        if action == "REPLACE_PENDING_FAMILY":
            title = "🧭 <b>Scenario Family Replaced</b>"
        elif action == "CANCELLED_SIBLINGS_ON_ACTIVATION":
            title = "🪄 <b>Scenario Siblings Cancelled</b>"
        else:
            title = "🛡️ <b>Scenario Family Kept</b>"
        lines = [
            title,
            "━━━━━━━━━━━━━━━━━━━━━",
            f"• <b>Symbol:</b> {html.escape(symbol)}",
            f"• <b>Side:</b> {html.escape(side)}",
        ]
        if governance.get("old_scenario_id") or governance.get("scenario_id"):
            lines.append(
                f"• <b>Scenario:</b> {self._clean_text(governance.get('old_scenario_id') or governance.get('scenario_id'))}"
            )
        if governance.get("new_scenario_id"):
            lines.append(f"• <b>New Scenario:</b> {self._clean_text(governance.get('new_scenario_id'))}")
        if reason:
            lines.append(f"• <b>Reason:</b> {reason}")
        cancelled = governance.get("cancelled_ids") or []
        if cancelled:
            lines.append(f"• <b>Pending Orders Cancelled:</b> {len(cancelled)}")
        lines.append("━━━━━━━━━━━━━━━━━━━━━")
        return self.send_message("\n".join(lines), urgent=True)

    def send_revalidation_block(self, *, symbol: str, side: str, entry_price: Any, reason: str) -> bool:
        lines = [
            "🛑 <b>Re-entry Blocked</b>",
            "━━━━━━━━━━━━━━━━━━━━━",
            f"• <b>Symbol:</b> {html.escape(symbol)}",
            f"• <b>Side:</b> {html.escape(side)}",
            f"• <b>Requested Entry:</b> {self._money(entry_price, symbol)}",
            f"• <b>Reason:</b> {self._clean_text(reason)}",
            "• <b>Guard:</b> Post-exit revalidation requires a materially new thesis before re-entry.",
            "━━━━━━━━━━━━━━━━━━━━━",
        ]
        return self.send_message("\n".join(lines), urgent=True)

    def send_error_alert(self, message: str) -> bool:
        text = (
            "🚨 <b>SmartSignal Error</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━\n"
            f"{html.escape(str(message))[:1200]}"
        )
        ok = self.send_message(text, urgent=True)
        if not ok:
            # 2026-08-19 (SPOF fix, item 14): second alert channel. When the
            # Telegram send fails, try the operator-configured email fallback
            # (alert_email section, DISABLED by default). Failure is silent.
            try:
                sent = send_email_alert(self.config, message)
                if sent:
                    self.logger.info("Error alert delivered via email fallback")
            except Exception:  # noqa: BLE001
                pass
        return ok

    def send_daily_report(self, report: str) -> bool:
        text = html.escape(str(report))
        # Preserve report line breaks after escaping.
        text = text.replace("\n", "\n")
        return self.send_message(text)

    def send_post_news_analysis(self, analysis: Dict[str, Any], event_name: str, symbol: str) -> bool:
        """Send a post-news analysis alert — NOT an entry signal.

        English-only message. Sent after a major economic event releases its numbers.
        Includes: event details, surprise factor, gold impact, DXY impact, recommendation.
        """
        if not analysis.get("available") or analysis.get("suppressed"):
            return False

        event = html.escape(str(analysis.get("event") or event_name))
        surprise = str(analysis.get("surprise", "N/A")).upper()
        gold_impact = str(analysis.get("gold_impact", "N/A")).upper()
        dxy_impact = str(analysis.get("dxy_impact", "N/A")).upper()
        recommendation = html.escape(str(analysis.get("recommendation") or ""))
        confidence = analysis.get("confidence", 0)
        key_insight = html.escape(str(analysis.get("key_insight") or ""))

        # Emoji mapping
        surprise_emoji = {"BETTER": "📈", "WORSE": "📉", "IN_LINE": "➖"}.get(surprise, "❓")
        gold_emoji = {"BULLISH": "🟢", "BEARISH": "🔴", "NEUTRAL": "🟡"}.get(gold_impact, "⚪")
        dxy_emoji = {"STRENGTHENING": "💪", "WEAKENING": "🔻", "NEUTRAL": "➖"}.get(dxy_impact, "⚪")

        message = "\n".join([
            f"📰 <b>Post-News Analysis — {html.escape(symbol)}</b>",
            "━━━━━━━━━━━━━━━━━━━━━",
            f"🔔 <b>Event:</b> {event}",
            f"{surprise_emoji} <b>Surprise:</b> {surprise}",
            "",
            f"{gold_emoji} <b>Gold Impact:</b> {gold_impact}",
            f"{dxy_emoji} <b>DXY Impact:</b> {dxy_impact}",
            f"📊 <b>Confidence:</b> {confidence}%",
            "",
            f"💡 <b>Recommendation:</b> {recommendation}",
            "",
            f"🔑 <b>Key Insight:</b> {key_insight}",
            "",
            "━━━ ⚠️ NOTICE ━━━",
            "This is an <b>observation</b>, NOT an entry signal.",
            "Wait for full 3-agent consensus for any trade.",
            "━━━━━━━━━━━━━━━━━━━━━",
        ])
        return self.send_message(message)

    @staticmethod
    def _format_reason_item(item: Any) -> str:
        """Format a reason/evidence item for display — handles dicts cleanly.

        Converts raw dict evidence like {'name': 'weighted_bias', 'value': None, 'bias': 'NEUTRAL'}
        into a human-readable string like "Weighted Bias: NEUTRAL".
        """
        if isinstance(item, dict):
            name = str(item.get("name", "")).replace("_", " ").title()
            value = item.get("value")
            bias = str(item.get("bias", "")).upper()
            # Skip items with no useful information
            if not name and bias in {"", "NEUTRAL"} and value is None:
                return ""
            parts: list[str] = []
            if name:
                parts.append(name)
            if value is not None:
                parts.append(str(value))
            if bias and bias != "NEUTRAL":
                parts.append(f"({bias})")
            elif bias == "NEUTRAL" and not value and name:
                parts.append("Neutral")
            result = ": ".join([parts[0], " ".join(parts[1:])]) if len(parts) > 1 else parts[0] if parts else ""
            return result if result else str(item)
        return str(item)



# ── Post-news tracker ──

def _post_news_tracker_load() -> dict:
    """Load the post-news alert tracker."""
    try:
        if _POST_NEWS_TRACKER_FILE.exists():
            return _json.loads(_POST_NEWS_TRACKER_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}

def _post_news_tracker_save(data: dict) -> None:
    """Persist the post-news tracker."""
    try:
        _POST_NEWS_TRACKER_FILE.parent.mkdir(parents=True, exist_ok=True)
        _POST_NEWS_TRACKER_FILE.write_text(_json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        pass

def post_news_alert_sent(event_key: str, database: Any = None) -> bool:
    """Check if a post-news alert was already sent for this event.

    Checks Supabase (primary) then local file (fallback).
    """
    if database is not None:
        try:
            if database.use_supabase and database.client:
                response = (
                    database.client.table("post_news_tracker")
                    .select("event_key")
                    .eq("event_key", event_key)
                    .limit(1)
                    .execute()
                )
                if list(response.data or []):
                    return True
        except Exception:
            pass
    tracker = _post_news_tracker_load()
    return event_key in tracker

def post_news_alert_record(event_key: str, database: Any = None) -> None:
    """Record that a post-news alert was sent for this event.

    Saves to Supabase (primary) and local file (backup).
    """
    from datetime import datetime, timezone
    # Save to Supabase
    if database is not None:
        try:
            if database.use_supabase and database.client:
                database.client.table("post_news_tracker").upsert({
                    "event_key": event_key,
                    "sent_at": datetime.now(timezone.utc).isoformat(),
                }).execute()
        except Exception:
            pass
    # Always save to local file as backup
    tracker = _post_news_tracker_load()
    tracker[event_key] = datetime.now(timezone.utc).isoformat()
    _post_news_tracker_save(tracker)
