# =====================================================================
# BUILD31-R13 : SHADOW EVIDENCE + PER-SYMBOL SPREAD CAPS (LOCAL-ONLY)
# Installs:
#   1. services/guard_replay.py          (NEW canonical guard engine)
#   2. services/database.py              (would_block + row evidence)
#   3. utils/instruments.py              (per-symbol spread caps)
#   4. agents/auction_flow_agent.py      (uses per-symbol cap)
#   5. agents/risk_management_agent.py   (uses per-symbol cap)
#   6. scripts/audit_recent_trades.py    (imports canonical engine)
#   7. scripts/diagnose_symbol_funnel.py (NEW funnel diagnosis)
#   8. config.json spread caps           (MERGE - never overwrite)
#   9. tests (4 new + 1 pinned)
# Run: copy APPLY_R13_EVIDENCE_SHADOW.ps1 + Nabil-gold-R13-*.zip into
#      C:\Nabil-gold then:
#      powershell -NoProfile -ExecutionPolicy Bypass -File .\APPLY_R13_EVIDENCE_SHADOW.ps1
# =====================================================================
$ErrorActionPreference = "Stop"
$root = "C:\Nabil-gold"
if (-not (Test-Path $root)) { throw "Project root not found: $root" }
Set-Location $root

$zip = Get-ChildItem -Path $root -Filter "Nabil-gold-R13-*.zip" |
       Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $zip) { throw "No Nabil-gold-R13-*.zip found in $root" }
Write-Host "[1/4] Found package: $($zip.Name)"

$tmp = Join-Path $env:TEMP ("R13_SHADOW_" + [guid]::NewGuid().ToString("N").Substring(0,8))
Expand-Archive -Path $zip.FullName -DestinationPath $tmp -Force

# -- copy payload -----------------------------------------------------
$map = @(
    @{ src = "guard_replay.py";                  dst = "services\guard_replay.py" },
    @{ src = "database.py";                      dst = "services\database.py" },
    @{ src = "instruments.py";                   dst = "utils\instruments.py" },
    @{ src = "auction_flow_agent.py";            dst = "agents\auction_flow_agent.py" },
    @{ src = "risk_management_agent.py";         dst = "agents\risk_management_agent.py" },
    @{ src = "audit_recent_trades.py";           dst = "scripts\audit_recent_trades.py" },
    @{ src = "diagnose_symbol_funnel.py";        dst = "scripts\diagnose_symbol_funnel.py" },
    @{ src = "diagnose_auction_agent.py";        dst = "scripts\diagnose_auction_agent.py" },
    @{ src = "test_auction_agent_diagnosis.py";  dst = "tests\test_auction_agent_diagnosis.py" },
    @{ src = "RUN_SYMBOL_DIAGNOSIS.bat";         dst = "RUN_SYMBOL_DIAGNOSIS.bat" },
    @{ src = "test_guard_replay_service.py";     dst = "tests\test_guard_replay_service.py" },
    @{ src = "test_spread_guard_per_symbol.py";  dst = "tests\test_spread_guard_per_symbol.py" },
    @{ src = "test_database_would_block.py";     dst = "tests\test_database_would_block.py" },
    @{ src = "test_diagnose_symbol_funnel.py";   dst = "tests\test_diagnose_symbol_funnel.py" },
    @{ src = "test_audit_recent_trades_tool.py"; dst = "tests\test_audit_recent_trades_tool.py" }
)
foreach ($m in $map) {
    $s = Join-Path $tmp $m.src
    $d = Join-Path $root $m.dst
    $ddir = Split-Path $d -Parent
    if (-not (Test-Path $ddir)) { New-Item -ItemType Directory -Path $ddir | Out-Null }
    Copy-Item -Path $s -Destination $d -Force
    Write-Host ("      installed: " + $m.dst)
}

# -- config MERGE (never overwrite operator config) --------------------
Write-Host "[2/4] Merging per-symbol spread caps into config.json..."
$mergeOut = & python (Join-Path $root "APPLY_R13_CONFIG_MERGE.py") 2>&1
if ($LASTEXITCODE -ne 0) { throw "config merge failed: $mergeOut" }
Write-Host $mergeOut

# -- verify -----------------------------------------------------------
Write-Host "[3/4] Verifying..."
$pyFiles = @("services\guard_replay.py", "services\database.py", "utils\instruments.py",
             "agents\auction_flow_agent.py", "agents\risk_management_agent.py",
             "scripts\audit_recent_trades.py", "scripts\diagnose_symbol_funnel.py",
             "scripts\diagnose_auction_agent.py")
foreach ($f in $pyFiles) {
    $out = & python -m py_compile (Join-Path $root $f) 2>&1
    if ($LASTEXITCODE -ne 0) { throw "py_compile failed for ${f}: $out" }
}
Write-Host "      py_compile: 8/8 OK"
$tests = & python -m pytest (Join-Path $root "tests") -q -p no:cacheprovider 2>&1
Write-Host $tests[-1]
$diag = & python (Join-Path $root "scripts\diagnose_symbol_funnel.py") --days 7 2>&1
Write-Host "      funnel diagnosis preview:"
Write-Host ($diag | Select-Object -First 12)

Remove-Item -Recurse -Force $tmp
Write-Host "[4/4] DONE."
Write-Host "      Diagnose forex mystery : python scripts\diagnose_symbol_funnel.py --days 7"
Write-Host "      or double-click        RUN_SYMBOL_DIAGNOSIS.bat"
Write-Host "      New trades now carry   would_block + entry evidence (row level)."
