# -*- coding: utf-8 -*-
"""Canonical R10/R11 guard-replay engine (BUILD 31 R13).

One implementation, two consumers:

  1. scripts/audit_recent_trades.py  - forensic report over the trade book.
  2. services/database.py            - shadow metadata: every NEW trade row
                                       gets a ``would_block`` list recorded
                                       at save time (log-only; the guards
                                       themselves are NOT enforced here).

Moving the logic out of the audit script means the shadow field and the
manual report can never drift apart.

Guards replayed (same semantics as R12):
  * QUIET_HOURS_21_06(chase)     - breakout chases in 21:00-06:30 UTC
  * PREMIUM/DISCOUNT_VWAP_BAND   - entry beyond vwap +/- 1.2 x ATR
  * RANGE_TOP_80 / RANGE_BOTTOM_20 (chase)
  * CONSOLIDATION_LOCKDOWN(chase)
  * FLOW_GUARD_65(chase) (+ FLOW_GUARD_DELTA_55_to_65 casualty flag)
  * BUY_THE_DIP_SELL_THE_RALLY   - same-symbol same-direction stack at a
                                   worse price while an earlier one is open
Evidence comes from row-level fields first (entry_vwap, entry_atr,
range_high, range_low - persisted by R13) and falls back to a defensive
dig into signal_snapshot. Missing evidence is reported as UNKNOWN flags -
never guessed.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from utils.instruments import point_size

HEBRON = ZoneInfo("Asia/Hebron")

CLOSED_STATUSES = {"TP2_HIT", "SL_HIT", "TRAILING_SL_HIT", "BE_HIT",
                   "EXPIRED", "THESIS_EXIT", "MANUAL_CLOSE", "CLOSED"}
WIN_STATUSES = {"TP2_HIT", "THESIS_EXIT"}
LOSS_STATUSES = {"SL_HIT", "TRAILING_SL_HIT"}

OLD_FLOW_BAR = 55.0   # pre-R10 hardcoded confirmation bar
NEW_FLOW_BAR = 65.0   # R10+: institutional_flow_min_confidence

# Row-level evidence keys persisted by database._entry_evidence (R13).
ROW_EVIDENCE_KEYS = ("entry_vwap", "entry_atr", "range_high", "range_low")


# -- parsing helpers ----------------------------------------------------------
def parse_ts(value):
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (TypeError, ValueError):
        return None


def hebron_day(dt):
    """The operator's trading day: 03:00 -> 02:59 Hebron.

    Shift back 3 hours then take the calendar date, so 00:00-02:59 local
    belongs to the PREVIOUS trading day (R13 bug fix: the R12 version
    subtracted one second, which left 00:00-02:59 local on the wrong day -
    pinned by tests/test_guard_replay_service.py).
    """
    from datetime import timedelta
    return (dt.astimezone(HEBRON) - timedelta(hours=3)).date()


# -- P&L / outcome ------------------------------------------------------------
def trade_pnl_points(trade):
    for key in ("final_pnl", "current_pnl_points", "pnl_points"):
        try:
            v = trade.get(key)
            if v is not None and float(v) != 0:
                return float(v)
        except (TypeError, ValueError):
            continue
    entry, close = trade.get("entry_price"), trade.get("close_price")
    side = str(trade.get("type") or trade.get("side") or "").upper()
    if entry and close and side in ("BUY", "SELL"):
        direction = 1 if side == "BUY" else -1
        ps = point_size(trade.get("symbol"))
        return (float(close) - float(entry)) * direction / ps if ps else 0.0
    return 0.0


def outcome(trade):
    status = str(trade.get("status") or "").upper()
    pnl = trade_pnl_points(trade)
    if status in CLOSED_STATUSES or trade.get("closed_at"):
        if pnl > 0.5:
            return "WIN"
        if pnl < -0.5:
            return "LOSS"
        return "BE"
    if pnl < -0.5:
        return "LOSS(OPEN)"
    return "OPEN" if status in ("OPEN", "TP1_HIT", "PARTIAL") else status or "PENDING"


def in_quiet_hours(dt_utc):
    h, m = dt_utc.hour, dt_utc.minute
    return h >= 21 or h < 6 or (h == 6 and m < 30)


# -- evidence digging ---------------------------------------------------------
def _dig(d, *paths):
    for path in paths:
        cur = d
        try:
            for key in path:
                cur = cur.get(key) if isinstance(cur, dict) else None
                if cur is None:
                    break
            if cur is not None:
                return cur
        except AttributeError:
            continue
    return None


def _deep_find_first(obj, key, _depth=0):
    """BFS for the first dict key matching ``key`` anywhere in a JSON blob."""
    if _depth > 8:
        return None
    if isinstance(obj, dict):
        if key in obj and obj[key] is not None:
            return obj[key]
        for v in obj.values():
            found = _deep_find_first(v, key, _depth + 1)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for item in obj:
            found = _deep_find_first(item, key, _depth + 1)
            if found is not None:
                return found
    return None


def collect_evidence(trade, snap):
    """Row-level fields first (R13), snapshot dig second, None when absent."""
    return {
        "vwap": (trade.get("entry_vwap")
                 or _dig(snap, ("auction_flow", "session_vwap"),
                         ("agents", "auction_flow", "session_vwap"))),
        "atr": (trade.get("entry_atr")
                or _dig(snap, ("technical", "atr"), ("volatility", "atr"))),
        "zone": str(_dig(snap, ("smc", "zone"), ("setup_context", "zone_context")) or "").upper(),
        "range_high": (trade.get("range_high")
                       or _dig(snap, ("smc", "dealing_range", "high"))),
        "range_low": (trade.get("range_low")
                      or _dig(snap, ("smc", "dealing_range", "low"))),
        "smc_dir": str(_dig(snap, ("smc", "direction"), ("smc", "signal")) or "").upper(),
        "smc_conf": float(_dig(snap, ("smc", "confidence")) or 0),
        "auc_dir": str(_dig(snap, ("auction_flow", "direction"),
                            ("auction_flow", "signal")) or "").upper(),
        "auc_conf": float(_dig(snap, ("auction_flow", "confidence")) or 0),
        "regime": str(_dig(snap, ("market_regime", "regime"))
                      or trade.get("regime_composite")
                      or trade.get("volatility_regime")
                      or trade.get("market_phase") or "").upper(),
    }


def is_breakout_chase(trade, snap):
    setup = str(_dig(snap, ("strategy_profile", "resolved_setup_type")) or "").upper()
    if setup:
        return ("BREAK" in setup or "MOMENTUM" in setup or "EXPANSION" in setup
                or "CHASE" in setup), setup or "UNKNOWN"
    return True, "MOMENTUM_CHASE"


def open_same_direction_at(trade, book):
    """Was another SAME-direction trade in the same symbol already open when
    this one was created? Returns its id (buy-the-dip / sell-the-rally proof)."""
    side = str(trade.get("type") or trade.get("side") or "").upper()
    sym = trade.get("symbol")
    created = parse_ts(trade.get("created_at") or trade.get("entry_time"))
    if not created or not side:
        return None
    for other in book:
        if other is trade or other.get("id") == trade.get("id"):
            continue
        if str(other.get("type") or other.get("side") or "").upper() != side:
            continue
        if str(other.get("symbol")) != str(sym):
            continue
        o_created = parse_ts(other.get("created_at") or other.get("entry_time"))
        o_closed = parse_ts(other.get("closed_at"))
        if not o_created or o_created > created:
            continue
        if o_closed and o_closed <= created:
            continue
        if str(other.get("status") or "").upper() in ("CANCELLED", "REJECTED", "EXPIRED"):
            continue
        prev_entry = float(other.get("entry_price") or 0)
        my_entry = float(trade.get("entry_price") or 0)
        if not prev_entry or not my_entry:
            continue
        worse = my_entry >= prev_entry if side == "BUY" else my_entry <= prev_entry
        if worse:
            return other.get("id")
    return None


def replay_guards(trade, book):
    """Return (blocked_by_list, notes_list, unknown_flags, archetype, evidence)."""
    snap = trade.get("signal_snapshot") or {}
    side = str(trade.get("type") or trade.get("side") or "").upper()
    entry = float(trade.get("entry_price") or 0)
    created = parse_ts(trade.get("created_at") or trade.get("entry_time")) or datetime.now(timezone.utc)
    ev = collect_evidence(trade, snap)
    chase, arch = is_breakout_chase(trade, snap)
    blocked, unknown = [], []
    notes = []

    # 1. quiet hours 21:00-06:30 UTC (breakout chases only)
    if in_quiet_hours(created):
        if chase:
            blocked.append("QUIET_HOURS_21_06(chase)")
        else:
            notes.append("in quiet window, but pullback setup: allowed by design")

    # 2+3. VWAP extreme bands + 80/20 dealing range
    vwap, atr = ev["vwap"], ev["atr"]
    if vwap and atr and entry > 0:
        if side == "BUY" and entry > float(vwap) + 1.2 * float(atr):
            blocked.append("PREMIUM_VWAP_BAND")
        if side == "SELL" and entry < float(vwap) - 1.2 * float(atr):
            blocked.append("DISCOUNT_VWAP_BAND")
    elif entry > 0:
        unknown.append("vwap/atr")

    rh, rl = ev["range_high"], ev["range_low"]
    if rh and rl and float(rh) > float(rl) and entry > 0:
        pos = (entry - float(rl)) / (float(rh) - float(rl))
        if side == "BUY" and pos >= 0.80 and chase:
            blocked.append("RANGE_TOP_80(chase)")
        if side == "SELL" and pos <= 0.20 and chase:
            blocked.append("RANGE_BOTTOM_20(chase)")
    elif entry > 0:
        unknown.append("dealing_range")

    # 4. consolidation lockdown
    if ev["regime"] and any(t in ev["regime"] for t in
                            ("CONSOLIDATION", "COMPRESSION", "RANGE", "LOW_VOL")) and chase:
        blocked.append("CONSOLIDATION_LOCKDOWN(chase)")

    # 5. flow confirmation: old bar 55 vs new bar 65
    aligned = lambda bar: ((ev["smc_dir"] == side and ev["smc_conf"] >= bar)
                           or (ev["auc_dir"] == side and ev["auc_conf"] >= bar))
    if chase:
        if not aligned(NEW_FLOW_BAR):
            blocked.append("FLOW_GUARD_65(chase)")
            if aligned(OLD_FLOW_BAR):
                # would have passed the legacy 55 bar: a NEW-bar casualty
                blocked.append("FLOW_GUARD_DELTA_55_to_65(would-pass-old)")

    # 6. buy-the-dip / sell-the-rally
    dip_id = open_same_direction_at(trade, book)
    if dip_id:
        blocked.append(f"BUY_THE_DIP_SELL_THE_RALLY(vs {dip_id})")

    return blocked, notes, unknown, arch, ev


def would_block_for(trade_row, book_rows):
    """Shadow metadata for a NEW trade row (R13): which R10/R11 guards would
    have blocked it. Log-only - persistence must never fail because of this."""
    try:
        blocked, _notes, _unknown, _arch, _ev = replay_guards(trade_row, book_rows or [])
        return blocked
    except Exception:  # noqa: BLE001 - shadow must never break a save
        return None


def load_json_rows(path):
    data = json.loads(open(path, encoding="utf-8").read())
    if isinstance(data, dict):
        for key in ("trades", "rows", "data"):
            if isinstance(data.get(key), list):
                return data[key]
        return [data]
    return list(data or [])
