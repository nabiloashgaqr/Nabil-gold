#!/usr/bin/env python3
"""BUILD 31 R10 - Post-audit fix verification (one-click self-audit).

Programmatically re-checks EVERY fix applied after the independent forensic
review of BUILD 31 R9 (2026-08-27). Exit code 0 = every fix is in place.

Usage:
    python scripts\\verify_r10_fixes.py               # audit the fixes only
    python scripts\\verify_r10_fixes.py --run-tests   # audit + full pytest

ASCII output only - safe for any Windows console / PowerShell 5.1.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

_OK, _FAIL = "[PASS]", "[FAIL]"
_results: list[tuple[bool, str, str]] = []


def check(number: int, title: str, condition: bool, detail: str = "") -> None:
    _results.append((bool(condition), f"#{number:02d} {title}", detail))
    mark = _OK if condition else _FAIL
    line = f"{mark} {number:02d}/14  {title}"
    if detail:
        line += f"  -> {detail}"
    print(line)


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify BUILD 31 R10 post-audit fixes")
    parser.add_argument("--run-tests", action="store_true", help="also run the full pytest suite")
    parser.add_argument("--no-fix", action="store_true",
                        help="audit only: do NOT auto-migrate legacy shadow storage (check 05)")
    args = parser.parse_args()

    print("=" * 74)
    print("BUILD 31 R10 POST-AUDIT FIX VERIFICATION")
    print("=" * 74)

    # 1. LOCAL-ONLY (R11): nothing GitHub/Supabase/Vercel ships anymore
    cfg_json = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    src16 = (ROOT / "tests" / "test_build16_telegram_polish.py").read_text(encoding="utf-8")
    template = (ROOT / ".env.template").read_text(encoding="utf-8")
    dead = ["SUPABASE_VERIFICATION_CHECKLIST.sql", "VERIFY_ALL_COLUMNS.sql",
            "scripts/migrate_supabase_to_local.py", "tests/test_local_migration.py",
            "tests/test_dashboard_api_leak.py", "deploy/trades_demo.sql",
            "supabase_schema_unified.sql", "deploy/GITHUB_SHUTDOWN_AR.md",
            "deploy/install_auto_updater.ps1", "deploy/tasks/auto_update.bat"]
    leftovers = [f for f in dead if (ROOT / f).exists()]
    check(1, "LOCAL-ONLY: zero cloud artifacts (GitHub/Supabase/Vercel)",
          (not (ROOT / ".github").exists()) and (not (ROOT / "api").exists())
          and (not (ROOT / "dashboard" / "api").exists())
          and "subscription_cron" not in src16
          and str((cfg_json.get("database") or {}).get("provider", "")).lower() == "local"
          and "SUPABASE" not in template.upper() and not leftovers,
          "no .github, no Vercel api/, provider=local" + (f", leftovers: {leftovers}" if leftovers else ""))

    # 2. Quiet-hours guard: clock-first (labels can only widen)
    src_da = (ROOT / "agents" / "decision_agent.py").read_text(encoding="utf-8")
    clock_first = ("in_quiet_hours = (cur_h >= 21)" in src_da
                   and src_da.index("in_quiet_hours = (cur_h >= 21)") < src_da.index('any(s in session_str for s in ["asia", "quiet", "night", "rollover"])'))
    no_shrink = '"london"' not in src_da.split("INSTITUTIONAL RISK")[1][:4000]
    check(2, "Quiet-hours guard: UTC clock is the single source of truth",
          clock_first and no_shrink, "session labels may only widen, never disarm")

    # 3. Institutional Flow Guard bar = 65% (config-pinned)
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    req = cfg.get("signal_requirements") or {}
    check(3, "Institutional Flow Guard threshold raised 55 -> 65 (config)",
          req.get("institutional_flow_min_confidence") == 65
          and "institutional_flow_min_confidence" in src_da,
          "institutional_flow_min_confidence=65")

    # 4. Shadow-mode system-wide kill switch
    sys.path.insert(0, str(ROOT))
    from services import shadow_mode as sm
    check(4, "Shadow mode OFF at code level (kill switch)",
          (not sm.shadow_mode_unlocked()) and sm.is_shadow_config(
              {"instrument": {"mode": "shadow"}}) is False
          and sm.shadow_instruments({"symbols": [{"symbol": "WTI/USD", "enabled": True, "mode": "shadow"}]}) == [],
          f"env override: {sm.SHADOW_ENABLE_ENV}=1 to revive")

    # 5. Shadow data archived out of the live tree (SELF-HEALING, R10a):
    #    on a machine where the operator has not migrated yet, we move the
    #    legacy books into storage/archive/shadow_20260827 right here, then
    #    re-check. Pass --no-fix to audit without touching anything.
    live_shadow = sm.ROOT / "storage" / "shadow"
    archive = sm.ROOT / "storage" / "archive" / "shadow_20260827"
    migrated_note = "already migrated"
    if not args.no_fix:
        if live_shadow.exists() and any(live_shadow.iterdir()):
            archive.mkdir(parents=True, exist_ok=True)
            moved = []
            for child in sorted(live_shadow.iterdir()):
                target = archive / child.name
                if not target.exists():
                    child.rename(target)
                    moved.append(child.name)
                    continue
                # Name collision (R10a): merge contents into the archive dir.
                if child.is_dir() and target.is_dir():
                    for item in sorted(child.iterdir()):
                        dest = target / item.name
                        if not dest.exists():
                            item.rename(dest)
                        elif item.read_bytes() == dest.read_bytes():
                            item.unlink()
                        else:
                            item.rename(target / f"{item.stem}_legacy_shadow{item.suffix}")
                    try:
                        child.rmdir()
                    except OSError:
                        moved.append(f"{child.name}: merged (residual files kept)")
                        continue
                    moved.append(f"{child.name}: merged")
                else:
                    moved.append(f"{child.name}: target exists, left in place")
            try:
                live_shadow.rmdir()
            except OSError:
                pass
            migrated_note = "auto-migrated now -> " + ", ".join(moved)
    else:
        if live_shadow.exists() and any(live_shadow.iterdir()):
            migrated_note = "legacy dirs still live (--no-fix)"
    live_clean = (not live_shadow.exists()) or not any(live_shadow.iterdir())
    check(5, "storage/shadow archived to storage/archive/shadow_20260827",
          live_clean and archive.exists(), migrated_note)

    # 6. Learning service clock = Asia/Hebron
    src_ls = (ROOT / "services" / "learning_service.py").read_text(encoding="utf-8")
    check(6, "Learning service locked to Asia/Hebron (no UTC stamps)",
          "datetime.now(timezone.utc)" not in src_ls and "ZoneInfo" in src_ls and "hebron_now()" in src_ls)

    # 7. Daily-report doc drift removed (no GitHub Actions / 23:00 UTC)
    head_rdr = "\n".join((ROOT / "scripts" / "run_daily_report.py").read_text(encoding="utf-8").splitlines()[:8])
    bat_root = (ROOT / "daily_report_demo.bat").read_bytes().decode("ascii", "replace")
    check(7, "Timezone docs unified on 23:50 Asia/Hebron",
          "GitHub Actions" not in head_rdr and "23:00 UTC" not in head_rdr
          and "deploy\\tasks\\daily_report_demo.bat" in bat_root,
          "root BAT now delegates to the canonical wrapper")

    # 8. Root BATs all delegate (single source of truth)
    delegating = 0
    for name in ("weekly_report_demo.bat", "macro_demo.bat", "demo_analysis.bat",
                 "demo_loop.bat", "demo_smoke.bat", "demo_watchdog.bat",
                 "dashboard_demo.bat", "market_status.bat", "subscription_bot.bat",
                 "tick_manager.bat"):
        text = (ROOT / name).read_bytes().decode("ascii", "replace")
        delegating += 1 if f"deploy\\tasks\\{name}" in text else 0
    check(8, "All duplicated root BATs delegate to deploy/tasks", delegating == 10,
          f"{delegating}/10 delegating")

    # 9. DST-safe scheduler script (no fixed UTC+3 fallback)
    ps1 = (ROOT / "scripts" / "fix_daily_report_timezone.ps1").read_text(encoding="ascii")
    check(9, "Scheduler PS1 has no fixed UTC+3 fallback (DST-safe)",
          "CreateCustomTimeZone" not in ps1
          and ps1.index("Jordan Standard Time") < ps1.index("Middle East Standard Time"))

    # 10. Dashboard drill-down per-pair decimals + multi-asset copy
    app = (ROOT / "dashboard" / "app.js").read_text(encoding="utf-8")
    page = (ROOT / "dashboard" / "index.html").read_text(encoding="utf-8")
    check(10, "Dashboard: per-pair price formatting + six-asset copy",
          "formatTradePrice(t.entry_price, t.symbol)" in app
          and "toFixed(2)</td>" not in app
          and "currently focuses on Gold" not in page
          and "Six-asset coverage" in page)

    # 11. .env.template pure ASCII + no cloud keys
    env_t = (ROOT / ".env.template").read_bytes()
    check(11, ".env.template pure ASCII, local-only (no legacy cloud keys)",
          all(b < 128 for b in env_t) and b"SUPABASE" not in env_t.upper(),
          f"{len(env_t)} bytes")

    # 12. tzdata pinned for Windows ZoneInfo
    reqs = (ROOT / "requirements.txt").read_text(encoding="utf-8")
    check(12, "tzdata pinned in requirements (Windows ZoneInfo)", "tzdata" in reqs)

    # 13. Root duplicates are shims
    ra_root = (ROOT / "run_analysis.py").read_text(encoding="utf-8")
    db_root = (ROOT / "database.py").read_text(encoding="utf-8")
    check(13, "Root run_analysis/mt5_executor/database are delegating shims",
          "runpy.run_path" in ra_root and len(ra_root) < 3000
          and "from services.database import" in db_root,
          "no more stale duplicate logic")

    # 14. R10 verification tests exist and changelog shipped
    r10_tests = (ROOT / "tests" / "test_build31_r10_post_audit_fixes.py").exists()
    r10_doc = (ROOT / "CHANGELOG_BUILD31_R10_POST_AUDIT_FIXES.md").exists()
    check(14, "R10/R11 test suite + changelog shipped", r10_tests and r10_doc)

    failed = [t for ok, t, _ in _results if not ok]
    print("=" * 74)
    print(f"RESULT: {len(_results) - len(failed)}/{len(_results)} checks passed")
    if failed:
        for t in failed:
            print(f"  {t}")
    if args.run_tests:
        print("-" * 74)
        print("Running the FULL pytest suite...")
        rc = subprocess.call([sys.executable, "-m", "pytest", "tests", "-q",
                              "--tb=short", "-p", "no:cacheprovider"], cwd=str(ROOT))
        if rc != 0:
            print(f"{_FAIL} pytest exited with code {rc}")
            return rc
        print(f"{_OK} full pytest suite passed")
        return 1 if failed else 0
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
