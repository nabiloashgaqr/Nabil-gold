"""OIL PATH AUDIT (2026-08-20, read-only, cp1252-safe).

The operator asked: oil (WTI/USD) never entered a trade - where is the fault?
This tool walks EVERY link of the WTI chain from persisted state only:

  1) FILE HASHES     - prove the oil-critical files match the build 16.2 repo
  2) WTI CONFIG      - live instrument rules (points, SL floor, liquidity,
                       targets, breakeven, trailing, auction calibration)
  3) AUCTION FEEDS   - gold tick store vs the WTI suffixed store (last tick,
                       heartbeat age, row counts). The WTI auction agent reads
                       the suffixed store; the shadow collector was its ONLY
                       feeder and WTI left shadow mode.
  4) OIL MACRO STATE - files present, thresholds, live agent run (yfinance)
  5) GOLD-OIL LINK   - correlation guard config + accumulated closes + live
                       XAU/WTI price ratio
  6) WTI PLANS TODAY - session_plans.json rows for WTI/USD: statuses + reasons
  7) WTI TRADES      - trades.json WTI rows + full detail of today's cancelled
                       pending order
  8) SHADOW TREE     - storage/shadow/wtiusd leftovers
  9) ADMISSION REPLAY- latest measurement rows: stored BUY/SELL verdicts and
                       per-path requirement table for WTI

Usage: python scripts\\oil_path_audit.py [--root C:\\Nabil-gold]
"""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

EXPECTED_HASHES = {
    "config.json": "1408b233bf9507da",
    "scripts/run_analysis.py": "668f5eac4ff53392",
    "scripts/run_tick_manager.py": "189b552c9be4ac95",
    "services/thesis_consensus.py": "c19f2f8a9707c02c",
    "services/session_planner.py": "49e1a17d45d8df79",
    "agents/oil_macro_agent.py": "46c62ea6fbf524bc",
    "agents/auction_flow_agent.py": "5560d4344fef2023",
    "services/auction_flow_store.py": "4392f35aaea7d960",
    "agents/smc_agent.py": "c3f9ba9622bee6a0",
    "agents/risk_management_agent.py": "7eb4c477ada775fd",
    "utils/instruments.py": "9987d9a50dc40d54",
}

WTI_FILES = [
    "storage/oil/eia_weekly.json",
    "storage/oil/eia_history.json",
    "storage/oil/opec_context.json",
    "storage/correlation/daily_closes.json",
]


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def _banner(title: str) -> None:
    print("")
    print("=" * 64)
    print(title)
    print("=" * 64)


def section_hashes(root: Path) -> None:
    _banner("1) FILE HASHES (expected = build 16.2 repo bytes)")
    try:
        import hashlib
        for rel, expected in EXPECTED_HASHES.items():
            p = root / rel
            if not p.exists():
                print(f"  MISSING   {rel}")
                continue
            actual = hashlib.sha256(p.read_bytes()).hexdigest()[:16]
            status = "MATCH" if actual == expected else "DIFF"
            print(f"  {status:8s} {rel}")
    except Exception as exc:  # noqa: BLE001
        print(f"  hash scan failed: {exc}")


def section_wti_config(root: Path) -> None:
    _banner("2) WTI CONFIG (live values)")
    cfg = _read_json(root / "config.json") or {}
    try:
        from utils.instruments import get_instrument
        spec = get_instrument(cfg, "WTI/USD") or {}
    except Exception as exc:  # noqa: BLE001
        print(f"  get_instrument failed: {exc}")
        spec = {}
    for inst in cfg.get("instruments") or []:
        if "WTI" in str(inst.get("symbol") or ""):
            spec.update(inst)
            break
    print(f"  point_size             : {spec.get('point_size')}  (1 point = $0.01)")
    print(f"  min_sl_distance_points : {spec.get('min_sl_distance_points')}")
    print(f"  trailing distance/step : {spec.get('trailing_distance')} / {spec.get('trailing_step')}")
    print(f"  early_breakeven_points : {spec.get('early_breakeven_points')}")
    print(f"  duplicate_zone_points  : {spec.get('duplicate_zone_points')}")
    rules = (spec.get("trading_rules") or {})
    print(f"  stop rule              : min_liquidity={rules.get('stop', {}).get('min_liquidity_points')} "
          f"buffer={rules.get('stop', {}).get('safety_buffer_points')} max={rules.get('stop', {}).get('max_stop_points')}")
    print(f"  targets rule           : min_tp1_rr={rules.get('targets', {}).get('min_tp1_rr')} "
          f"tp2_multiple={rules.get('targets', {}).get('tp2_multiple')} max_beyond={rules.get('targets', {}).get('max_beyond_points')} pts")
    print(f"  post_tp2 gate          : {rules.get('post_tp2', {}).get('min_distance_points')} pts / "
          f"{rules.get('post_tp2', {}).get('window_hours')}h")
    planner = (spec.get("session_planner") or {})
    print(f"  planner geometry       : zone_half={planner.get('fallback_zone_half_width_points')} "
          f"max_zone={planner.get('max_primary_zone_width_points')} standby_min={planner.get('standby_min_distance_points')}")
    print(f"  cross_entry_distance   : {spec.get('cross_entry_distance_points')} pts")
    print(f"  auction_flow           : {spec.get('auction_flow')}")
    print(f"  mode key               : {'PRESENT (' + str(spec.get('mode')) + ')' if 'mode' in spec else 'ABSENT -> LIVE'}")
    sig = (cfg.get("signal_requirements") or {})
    print("  admission paths:")
    print(f"    PATH1 three_agent            : enabled={sig.get('three_agent_entry', {}).get('enabled')}")
    print(f"    PATH2 two_agent+macro(gold)  : enabled={sig.get('two_agent_entry', {}).get('macro_confirmation', {}).get('enabled')} min={sig.get('two_agent_entry', {}).get('macro_confirmation', {}).get('min_confidence')}")
    print(f"    PATH2 oil_macro (WTI only)   : enabled={sig.get('two_agent_entry', {}).get('oil_macro_confirmation', {}).get('enabled')} min={sig.get('two_agent_entry', {}).get('oil_macro_confirmation', {}).get('min_confidence')}")
    print(f"    PATH3 gemini                 : enabled={sig.get('two_agent_entry', {}).get('gemini_confirmation', {}).get('enabled')} min={sig.get('two_agent_entry', {}).get('gemini_confirmation', {}).get('min_confidence')}")
    print(f"    PATH4 smc_map+auction        : enabled={sig.get('path4_smc_map_auction', {}).get('enabled')} "
          f"auction_min={sig.get('path4_smc_map_auction', {}).get('min_auction_confidence')}")
    print(f"    PATH5 two_agent+auction      : enabled={sig.get('path5_two_agent_auction', {}).get('enabled')} "
          f"auction_min={sig.get('path5_two_agent_auction', {}).get('min_auction_confidence')}")
    print(f"    agent bar / net floor        : bar={sig.get('agent_min_confidence')} "
          f"net={sig.get('min_consensus_confidence')}")
    env = {}
    for key in ("GEMINI_API_KEY", "EIA_API_KEY"):
        env[key] = "SET" if __import__("os").environ.get(key) else "unset"
    print(f"  env: GEMINI_API_KEY={env['GEMINI_API_KEY']}  EIA_API_KEY={env['EIA_API_KEY']}")


def _store_meta(path: Path) -> None:
    if not path.exists():
        print(f"    {path.name}: MISSING")
        return
    try:
        stat = path.stat()
        age_min = (datetime.now().timestamp() - stat.st_mtime) / 60.0
        print(f"    {path.name}: size={stat.st_size}B last_write={age_min:.0f} min ago")
        con = sqlite3.connect(str(path))
        try:
            meta = {str(k): str(v) for k, v in con.execute("SELECT key, value FROM meta")}
            last_tick = int(meta.get("last_tick_ts_ms") or 0)
            if last_tick:
                tick_age_min = (datetime.now().timestamp() * 1000 - last_tick) / 60000.0
                print(f"      meta.last_tick_ts_ms age = {tick_age_min:.1f} min")
            else:
                print("      meta.last_tick_ts_ms = 0 (no tick ever recorded)")
            hb = meta.get("heartbeat_ts_ms") or meta.get("heartbeat")
            print(f"      meta keys = {sorted(meta.keys())}")
            tables = [r[0] for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")]
            for t in tables:
                try:
                    n = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                    print(f"      table {t}: {n} rows")
                except Exception:  # noqa: BLE001
                    pass
        finally:
            con.close()
    except Exception as exc:  # noqa: BLE001
        print(f"    {path.name}: sqlite read failed: {exc}")


def section_auction_feeds(root: Path) -> None:
    _banner("3) AUCTION FEEDS (gold store vs WTI store)")
    print("  [gold store - fed by tick manager every tick]")
    _store_meta(root / "storage" / "auction_flow.sqlite3")
    print("  [WTI store - the WTI auction agent reads THIS one]")
    _store_meta(root / "storage" / "auction_flow_wtiusd.sqlite3")
    print("")
    print("  FEED ANALYSIS (build 18: every enabled non-base instrument has a")
    print("  live collector with explicit Market Watch selection):")
    for label, path in (("GOLD", root / "storage" / "auction_flow.sqlite3"),
                        ("WTI ", root / "storage" / "auction_flow_wtiusd.sqlite3")):
        if not path.exists():
            print(f"    {label}: store MISSING")
            continue
        try:
            import sqlite3 as _sq
            con = _sq.connect(str(path))
            meta = {str(k): str(v) for k, v in con.execute("SELECT key, value FROM meta")}
            con.close()
            last_write = float(meta.get("last_write_ts") or 0)
            last_tick = int(meta.get("last_tick_ts_ms") or 0)
            now_s = time.time()
            write_age_min = (now_s - last_write) / 60.0 if last_write else 99999
            tick_age_min = ((now_s * 1000) - last_tick) / 60000.0 if last_tick else 99999
            if last_tick and tick_age_min < 10:
                verdict = "ALIVE (ticks flowing)"
            elif write_age_min < 10:
                verdict = "HEARTBEAT ONLY - collector runs but no ticks record -> symbol not selected in Market Watch (or market closed)"
            else:
                verdict = "DEAD - no heartbeat, collector not running"
            print(f"    {label}: tick_age={tick_age_min:.1f}min write_age={write_age_min:.1f}min -> {verdict}")
        except Exception as exc:  # noqa: BLE001
            print(f"    {label}: meta read failed: {exc}")
    print("  => Path 4/5 for oil need the WTI line to read ALIVE.")


def section_oil_macro(root: Path) -> None:
    _banner("4) OIL MACRO STATE")
    cfg = _read_json(root / "config.json") or {}
    om = cfg.get("oil_macro") or {}
    print(f"  enabled={om.get('enabled')} crack_enabled={om.get('crack_enabled')}")
    two = (cfg.get("signal_requirements") or {}).get("two_agent_entry") or {}
    oc = two.get("oil_macro_confirmation") or {}
    print(f"  path-2 confirmation floor: {oc.get('min_confidence')} (oil_macro must be >= this to confirm)")
    for rel in WTI_FILES[:3]:
        p = root / rel
        if p.exists():
            age_h = (datetime.now().timestamp() - p.stat().st_mtime) / 3600.0
            print(f"  {rel}: PRESENT ({age_h:.1f}h old)")
        else:
            print(f"  {rel}: MISSING")
    print("  live agent run (yfinance, cached):")
    try:
        from agents.oil_macro_agent import OilMacroAgent
        agent = OilMacroAgent(cfg)
        r = agent.analyze({"symbol": "WTI/USD"})
        if isinstance(r, dict):
            print(f"    direction={r.get('direction')} bias={r.get('bias')} "
                  f"confidence={r.get('confidence')} signal={r.get('signal')}")
            print(f"    missing={r.get('missing')} score={r.get('score')}")
            if r.get("summary"):
                print(f"    summary={r.get('summary')}")
            else:
                print(f"    reasons={(r.get('reasons') or [])[:3]}")
    except Exception as exc:  # noqa: BLE001
        print(f"    live run failed: {exc}")
    print("  => if confidence < 55, PATH 2 (two-agent + oil macro) is BLOCKED by design.")


def section_correlation(root: Path) -> None:
    _banner("5) GOLD-OIL LINK (correlation guard + price ratio)")
    cfg = _read_json(root / "config.json") or {}
    corr = cfg.get("correlation_guard") or {}
    print(f"  enabled={corr.get('enabled')} enforce={corr.get('enforce')} "
          f"veto_corr={corr.get('veto_correlation')} max_heat={corr.get('max_heat')}")
    p = root / "storage" / "correlation" / "daily_closes.json"
    if not p.exists():
        print("  daily_closes.json: MISSING (no closes accumulated yet)")
    else:
        data = _read_json(p)
        if isinstance(data, dict):
            print(f"  keys={list(data.keys())[:8]}")
        elif isinstance(data, list):
            print(f"  rows={len(data)}")
            if data:
                print(f"  first={json.dumps(data[0])[:160]}")
                print(f"  last ={json.dumps(data[-1])[:160]}")
        try:
            gold, wti = [], []
            rows = data if isinstance(data, list) else None
            for row in rows or []:
                if isinstance(row, dict):
                    g = _f(row.get("gold") or row.get("xau"))
                    w = _f(row.get("wti") or row.get("oil") or row.get("cl"))
                    if g > 0 and w > 0:
                        gold.append(g)
                        wti.append(w)
            if len(gold) >= 3 and len(wti) >= 3:
                n = min(len(gold), len(wti))
                gs, ws = gold[-n:], wti[-n:]
                import statistics
                mg, mw = statistics.mean(gs), statistics.mean(ws)
                cov = sum((a - mg) * (b - mw) for a, b in zip(gs, ws)) / n
                sg = statistics.pstdev(gs) or 1e-9
                sw = statistics.pstdev(ws) or 1e-9
                corr_v = cov / (sg * sw)
                print(f"  closes={n}  pearson_corr={corr_v:+.3f}  "
                      f"ratio_heat={abs(corr_v) / max(float(corr.get('max_heat') or 1.5), 0.01):.2f} (max_heat={corr.get('max_heat')})")
            if gold and wti:
                print(f"  live price ratio XAU/WTI = {gold[-1] / max(wti[-1], 0.01):.1f}")
        except Exception as exc:  # noqa: BLE001
            print(f"  correlation math failed: {exc}")
    try:
        shared = _read_json(root / "storage" / "shared_market_data.json") or {}
        prices = shared.get("prices") or shared.get("instruments") or {}
        if isinstance(prices, dict):
            g = _f(prices.get("XAU/USD"))
            w = _f(prices.get("WTI/USD"))
            if g > 0 and w > 0:
                print(f"  shared_market_data ratio XAU/WTI = {g / w:.1f}")
    except Exception:  # noqa: BLE001
        pass
    print("  => enforce=false: the guard only measures + advises. It blocks nothing today.")


def section_wti_plans(root: Path) -> None:
    _banner("6) WTI PLANS TODAY (session_plans.json)")
    p = root / "storage" / "session_plans.json"
    if not p.exists():
        print("  session_plans.json MISSING")
        return
    data = _read_json(p)
    rows = data if isinstance(data, list) else (data or {}).get("plans", [])
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    wti = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        sym = str(row.get("symbol") or "").upper()
        if "WTI" not in sym:
            continue
        ts = str(row.get("created_at") or row.get("generated_at") or row.get("timestamp") or "")
        if ts.startswith(today) or ts[:10] >= today:
            wti.append(row)
    print(f"  WTI plan rows today: {len(wti)}")
    if not wti:
        print("  (no WTI plans today - planner idle for oil)")
        return
    from collections import Counter
    statuses = Counter(str(r.get("plan_status") or "?") for r in wti)
    print(f"  statuses: {dict(statuses)}")
    ready = [r for r in wti if r.get("plan_ready")]
    print(f"  plan_ready=True: {len(ready)}")
    for r in ready[-6:]:
        print(f"    READY {r.get('created_at')} side={r.get('session_bias')} "
              f"entry={r.get('primary_entry_price')} reason={(str(r.get('plan_reason') or '')[:90])}")
    reasons = Counter((str(r.get('plan_reason') or '')[:80]) for r in wti)
    print("  top plan_reason values:")
    for text, n in reasons.most_common(8):
        print(f"    {n:3d}x  {text}")


def section_wti_trades(root: Path) -> None:
    _banner("7) WTI TRADES (trades.json)")
    p = root / "storage" / "trades.json"
    if not p.exists():
        print("  trades.json MISSING")
        return
    data = _read_json(p)
    rows = data if isinstance(data, list) else []
    wti = [r for r in rows if isinstance(r, dict) and "WTI" in str(r.get("symbol") or "").upper()]
    print(f"  WTI rows total: {len(wti)}")
    for r in wti[-20:]:
        print(f"    {str(r.get('created_at') or '')[:19]}  {str(r.get('type') or r.get('side') or '?'):5s} "
              f"{str(r.get('status') or '?'):12s} entry={r.get('entry_price')} sl={r.get('stop_loss')} "
              f"tp1={r.get('tp1')} tp2={r.get('tp2')} pnl={r.get('pnl_points')}")
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    cancelled_today = [r for r in wti
                       if str(r.get('status') or '').upper() == 'CANCELLED'
                       and str(r.get('closed_at') or '').startswith(today)]
    for r in cancelled_today:
        print("")
        print("  === TODAY'S CANCELLED WTI PENDING (full row) ===")
        for key in ("id", "created_at", "closed_at", "close_time", "symbol", "type", "status",
                    "entry_price", "stop_loss", "tp1", "tp2", "mt5_ticket", "order_kind",
                    "cancel_reason_code", "cancel_reason", "reasons", "plan_reason",
                    "execution_path", "execution_path_number", "admission_path", "trading_mode"):
            if key in r:
                print(f"    {key:22s} = {str(r.get(key))[:200]}")
    if not cancelled_today:
        print("  (no CANCELLED WTI row closed today in trades.json)")
    # pending that aged out without broker placement may carry runtime flags
    for r in wti:
        if str(r.get("status") or "").upper() == "CANCELLED":
            for key in ("cancelled_for_low_rr", "low_rr_cancel_reason", "pending_stale_at",
                        "freshness_state", "keep_pending"):
                if key in r:
                    print(f"    [flag] {key} = {str(r.get(key))[:120]}")


def section_shadow_tree(root: Path) -> None:
    _banner("8) SHADOW TREE (storage/shadow/wtiusd - historical)")
    base = root / "storage" / "shadow" / "wtiusd"
    if not base.exists():
        print("  no shadow tree for WTI")
        return
    files = sorted(base.rglob("*"))
    print(f"  files: {len([f for f in files if f.is_file()])}")
    for f in files:
        if f.is_file():
            age_h = (datetime.now().timestamp() - f.stat().st_mtime) / 3600.0
            print(f"    {f.relative_to(base)}  {f.stat().st_size}B  {age_h:.1f}h old")


def section_admission_replay(root: Path) -> None:
    _banner("9) ADMISSION REPLAY (latest measurement rows)")
    base = root / "storage" / "agent_measurements"
    if not base.exists():
        print("  agent_measurements MISSING")
        return
    files = sorted(base.glob("agent_system_*.jsonl"))
    if not files:
        print("  no measurement files")
        return
    latest = files[-1]
    try:
        rows = [json.loads(line) for line in latest.read_text(encoding="utf-8").splitlines() if line.strip()]
    except Exception as exc:  # noqa: BLE001
        print(f"  read failed: {exc}")
        return
    print(f"  file={latest.name} rows={len(rows)}")
    print("  last 10 rows (decision | map side/ready | BUY verdict | SELL verdict | auction):")
    for row in rows[-10:]:
        adm = row.get("admission") or {}
        buy = adm.get("BUY") or {}
        sell = adm.get("SELL") or {}
        auc = row.get("auction_measurement") or {}
        mp = row.get("map") or {}
        print(f"    {str(row.get('generated_at') or '')[:19]}  dec={str(row.get('decision') or '?'):5s} "
              f"map={str(mp.get('side') or '?')}/{str(mp.get('ready'))[:1]} "
              f"BUY={str(buy.get('allow'))[:1]}:{str(buy.get('path'))[:26]:26s} "
              f"SELL={str(sell.get('allow'))[:1]}:{str(sell.get('path'))[:26]:26s} "
              f"auc_state={str(auc.get('state') or '?')[:30]}")
    print("")
    print("  PATH REQUIREMENTS vs LATEST BOOK (last row):")
    row = rows[-1]
    cfg = _read_json(root / "config.json") or {}
    try:
        from services.thesis_consensus import evaluate_directional_admission
        details = dict(row.get("agents") or {})
        for name in ("auction_flow", "macro_fundamental", "oil_macro", "smc"):
            if name == "auction_flow":
                details[name] = (row.get("auction_measurement") or {})
            elif name == "smc":
                details[name] = (row.get("smc_measurement") or {})
            elif name == "macro_fundamental":
                details[name] = (row.get("macro") or {})
        details["symbol"] = "WTI/USD"
        for side in ("BUY", "SELL"):
            verdict = evaluate_directional_admission(side, details, cfg, symbol="WTI/USD")
            print(f"    {side}: allow={verdict.get('allow')} path={verdict.get('path')} "
                  f"reason={(str(verdict.get('reason') or '')[:110])}")
    except Exception as exc:  # noqa: BLE001
        print(f"    replay failed: {exc}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(ROOT))
    args = parser.parse_args()
    root = Path(args.root)
    print(f"OIL PATH AUDIT  {_iso_now()}  root={root}")
    print("READ-ONLY: prints diagnostics only, writes nothing.")
    for fn in (section_hashes, section_wti_config, section_auction_feeds,
               section_oil_macro, section_correlation, section_wti_plans,
               section_wti_trades, section_shadow_tree, section_admission_replay):
        try:
            fn(root)
        except Exception as exc:  # noqa: BLE001
            print(f"  SECTION FAILED: {exc}")
    _banner("DONE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
