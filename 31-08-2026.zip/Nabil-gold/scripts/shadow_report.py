"""Shadow vs live scoreboard — the promotion evidence (operator 2026-08-16).

Reads the isolated shadow book(s) under storage/shadow/<sym>/ and the live
gold book, computes per-instrument performance over the same window and
prints the promotion checklist agreed with the operator:

  PROMOTE when, over >= 5 trading days:
    * shadow signals >= 8 resolved (SL/TP2/thesis-exit/cancelled excluded
      from resolution counts only when unfilled),
    * shadow profit factor >= 0.8 x gold profit factor (same window),
    * shadow hit rate (TP1-before-SL) >= 50%.

Usage:
    python scripts\\shadow_report.py            (full history)
    python scripts\\shadow_report.py --days 7   (window)
    python scripts\\shadow_report.py --send     (also post the scoreboard to
                                                Telegram with SHADOW banner)
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from services.shadow_mode import shadow_instruments, shadow_paths  # noqa: E402
from utils.helpers import load_config  # noqa: E402
from utils.instruments import normalize_symbol  # noqa: E402

WIN_STATUSES = {"TP1_HIT", "TP2_HIT", "PARTIAL"}
LOSS_STATUSES = {"SL_HIT"}
CLOSED_EXTRA = {"CLOSED", "MANUAL_CLOSE", "THESIS_EXIT", "EXPIRED", "CANCELLED"}


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _load(path: Path) -> List[Dict[str, Any]]:
    try:
        rows = json.loads(path.read_text(encoding="utf-8"))
        return [r for r in rows if isinstance(r, dict)]
    except (OSError, ValueError):
        return []


def _in_window(row: Dict[str, Any], cutoff: datetime | None) -> bool:
    if cutoff is None:
        return True
    stamp = str(row.get("created_at") or row.get("entry_time") or "")
    try:
        return datetime.fromisoformat(stamp.replace("Z", "+00:00")) >= cutoff
    except ValueError:
        return True


def _pnl_points(row: Dict[str, Any]) -> float:
    for key in ("final_pnl_points", "pnl_points", "final_pnl", "pnl"):
        v = row.get(key)
        if v not in (None, "", "-"):
            return _f(v)
    return 0.0


def summarize(rows: List[Dict[str, Any]], cutoff: datetime | None) -> Dict[str, Any]:
    rows = [r for r in rows if _in_window(r, cutoff)]
    total = len(rows)
    open_now = [r for r in rows if str(r.get("status")) in {"OPEN", "PENDING", "TP1_HIT", "PARTIAL"}
                and not r.get("closed_at")]
    resolved = [r for r in rows if r.get("closed_at")
                or str(r.get("status")) in (WIN_STATUSES | LOSS_STATUSES | CLOSED_EXTRA)]
    cancelled = [r for r in resolved if str(r.get("status")) == "CANCELLED"]
    scored = [r for r in resolved if str(r.get("status")) != "CANCELLED"]
    wins = [r for r in scored if _pnl_points(r) > 0]
    losses = [r for r in scored if _pnl_points(r) < 0]
    gross_win = sum(_pnl_points(r) for r in wins)
    gross_loss = abs(sum(_pnl_points(r) for r in losses))
    pf = (gross_win / gross_loss) if gross_loss > 0 else (float("inf") if gross_win > 0 else 0.0)
    hit = len(wins) / len(scored) * 100.0 if scored else 0.0
    return {
        "signals": total,
        "open_or_pending": len(open_now),
        "resolved": len(scored),
        "cancelled_unfilled": len(cancelled),
        "wins": len(wins),
        "losses": len(losses),
        "hit_rate_pct": round(hit, 1),
        "gross_win_points": round(gross_win, 1),
        "gross_loss_points": round(gross_loss, 1),
        "profit_factor": round(pf, 2) if pf != float("inf") else "inf",
        "net_points": round(gross_win - gross_loss, 1),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=0)
    parser.add_argument("--send", action="store_true")
    args = parser.parse_args()

    config = load_config()
    cutoff = (datetime.now(timezone.utc) - timedelta(days=args.days)) if args.days else None

    live_rows = _load(ROOT / "storage" / "trades.json")
    gold = summarize([r for r in live_rows
                      if normalize_symbol(r.get("symbol") or "XAU/USD") == "XAU/USD"], cutoff)

    lines: List[str] = []
    header = (f"SHADOW SCOREBOARD — window: "
              f"{'last %d days' % args.days if args.days else 'all history'}")
    print("=" * 70)
    print(header)
    print("=" * 70)

    def show(tag: str, s: Dict[str, Any]) -> None:
        row = (f"{tag:<12} signals={s['signals']:>3} resolved={s['resolved']:>3} "
               f"hit={s['hit_rate_pct']:>5}% PF={s['profit_factor']:<5} "
               f"net={s['net_points']:>8} pts (open {s['open_or_pending']}, "
               f"unfilled {s['cancelled_unfilled']})")
        print(row)
        lines.append(row)

    show("GOLD (live)", gold)

    verdicts: List[str] = []
    for inst in shadow_instruments(config):
        sym = normalize_symbol(inst.get("symbol"))
        srows = _load(shadow_paths(sym)["trades"])
        s = summarize(srows, cutoff)
        show(f"{sym} \U0001F9EA", s)

        gold_pf = gold["profit_factor"]
        gold_pf_num = 999.0 if gold_pf == "inf" else _f(gold_pf)
        s_pf_num = 999.0 if s["profit_factor"] == "inf" else _f(s["profit_factor"])
        checks = [
            ("resolved >= 8", s["resolved"] >= 8),
            ("hit rate >= 50%", s["hit_rate_pct"] >= 50.0),
            ("PF >= 0.8 x gold" + f" ({0.8 * gold_pf_num:.2f})" if gold_pf_num < 999 else "PF > 1.0",
             s_pf_num >= (0.8 * gold_pf_num if gold_pf_num < 999 else 1.0)),
        ]
        print(f"  promotion checklist for {sym}:")
        all_ok = True
        for name, ok in checks:
            all_ok &= ok
            mark = "PASS" if ok else "not yet"
            print(f"    [{mark:<7}] {name}")
            lines.append(f"  [{mark}] {name}")
        verdict = ("READY TO PROMOTE — remove \"mode\": \"shadow\" from config"
                   if all_ok else "KEEP MEASURING")
        verdicts.append(f"{sym}: {verdict}")
        print(f"  => {verdict}")
        lines.append(f"=> {verdict}")

    if args.send:
        try:
            from services.shadow_mode import shadow_telegram
            from utils.instruments import config_for_instrument
            insts = shadow_instruments(config)
            if insts:
                tg = shadow_telegram(config_for_instrument(config, insts[0]))
                tg.send_message("\U0001F4CA SHADOW SCOREBOARD\n" + "\n".join(lines))
                print("scoreboard sent to Telegram")
        except Exception as exc:  # noqa: BLE001
            print(f"telegram send failed: {exc}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
