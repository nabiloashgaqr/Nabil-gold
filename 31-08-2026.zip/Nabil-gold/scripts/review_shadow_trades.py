"""Review shadow trades' geometry — find scale/target errors (2026-08-16).

For every trade in the shadow book(s) this prints the full geometry and
independently RE-DERIVES what the law says the numbers should have been:

  * stop distance in points and $, checked against the oil stop law
    (band [81,120] oil-points when floored, i.e. $0.81-$1.20);
  * TP1 checked against the 0.8R rung (law minimum);
  * TP2 checked against 2.0 x TP1 distance (+ max_beyond band);
  * R:R sanity and % moves, flagging anything that smells gold-scale
    (a $4+ stop or $8+ target on an $81 instrument is a 10x scale bug).

Usage:
    python scripts\\review_shadow_trades.py            (all shadow trades)
    python scripts\\review_shadow_trades.py --last 10
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from services.shadow_mode import shadow_instruments, shadow_paths  # noqa: E402
from utils.helpers import load_config  # noqa: E402
from utils.instruments import (  # noqa: E402
    config_for_instrument, normalize_symbol, price_to_points,
)
from utils.trading_rules import stop_rule, target_ratios  # noqa: E402


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--last", type=int, default=0)
    args = parser.parse_args()

    config = load_config()
    problems_total = 0
    for inst in shadow_instruments(config):
        sym = normalize_symbol(inst.get("symbol"))
        icfg = config_for_instrument(config, inst)
        srule = stop_rule(icfg)
        ratios = target_ratios(icfg)
        point = float(icfg["instrument"].get("point_size", 0.01))

        trades_path = shadow_paths(sym)["trades"]
        try:
            rows: List[Dict[str, Any]] = json.loads(trades_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            rows = []
        if args.last:
            rows = rows[-args.last:]

        print("=" * 78)
        print(f"SHADOW GEOMETRY REVIEW — {sym} ({len(rows)} trade(s))")
        print(f"law: stop band [{srule['min_liquidity_points'] + srule['safety_buffer_points']:.0f}"
              f"..{srule['max_stop_points']:.0f}] pts "
              f"(${(srule['min_liquidity_points'] + srule['safety_buffer_points']) * point:.2f}"
              f"..${srule['max_stop_points'] * point:.2f}) | "
              f"TP1 >= {ratios['min_tp1_rr']}R | TP2 = {ratios['tp2_multiple']}x TP1 "
              f"(+<= {ratios['max_beyond_points']:.0f} pts pool band)")
        print("=" * 78)
        if not rows:
            print("  (no shadow trades recorded yet)")
            continue

        for t in rows:
            tid = str(t.get("id", "?"))[:28]
            side = str(t.get("type", "?")).upper()
            entry = _f(t.get("entry_price"))
            stop = _f(t.get("initial_stop_loss") or t.get("stop_loss"))
            tp1 = _f(t.get("tp1"))
            tp2 = _f(t.get("tp2"))
            status = t.get("status")
            problems: List[str] = []

            if entry <= 0:
                print(f"\n{tid} {side} — no entry price, skipped")
                continue
            sl_pts = abs(price_to_points(entry - stop, sym)) if stop else 0.0
            tp1_pts = abs(price_to_points(tp1 - entry, sym)) if tp1 else 0.0
            tp2_pts = abs(price_to_points(tp2 - entry, sym)) if tp2 else 0.0
            rr1 = tp1_pts / sl_pts if sl_pts else 0.0
            rr2 = tp2_pts / sl_pts if sl_pts else 0.0

            # direction sanity
            if stop and ((side == "BUY" and stop >= entry) or (side == "SELL" and stop <= entry)):
                problems.append("STOP ON WRONG SIDE of entry")
            for name, tp in (("TP1", tp1), ("TP2", tp2)):
                if tp and ((side == "BUY" and tp <= entry) or (side == "SELL" and tp >= entry)):
                    problems.append(f"{name} ON WRONG SIDE of entry")

            # scale sanity: gold-scale leakage detector
            if sl_pts > srule["max_stop_points"] * 1.05:
                problems.append(
                    f"stop {sl_pts:.0f} pts (${sl_pts * point:.2f}) EXCEEDS law cap "
                    f"{srule['max_stop_points']:.0f} — gold-scale leak?")
            if tp2_pts > srule["max_stop_points"] * ratios["tp2_multiple"] * 2.5:
                problems.append(
                    f"TP2 {tp2_pts:.0f} pts (${tp2_pts * point:.2f}) absurdly far "
                    "— gold-scale leak?")

            # law re-derivation
            if sl_pts and tp1_pts and rr1 < ratios["min_tp1_rr"] - 0.02:
                problems.append(f"TP1 {rr1:.2f}R < law minimum {ratios['min_tp1_rr']}R")
            if tp1_pts and tp2_pts:
                expected_tp2 = ratios["tp2_multiple"] * tp1_pts
                if tp2_pts < expected_tp2 - 1e-9 and (expected_tp2 - tp2_pts) > ratios["max_beyond_points"]:
                    problems.append(
                        f"TP2 {tp2_pts:.0f} pts < law {expected_tp2:.0f} pts "
                        f"(2x TP1) beyond the pool band")

            flag = " !! " if problems else "  ok"
            print(f"\n[{flag}] {tid}  {side}  status={status}")
            print(f"      entry {entry:.2f} | stop {stop:.2f} ({sl_pts:.0f} pts ${sl_pts*point:.2f})"
                  f" | TP1 {tp1:.2f} ({tp1_pts:.0f} pts, {rr1:.2f}R)"
                  f" | TP2 {tp2:.2f} ({tp2_pts:.0f} pts, {rr2:.2f}R)")
            for pb in problems:
                problems_total += 1
                print(f"      -> {pb}")

    print()
    print("=" * 78)
    print(f"TOTAL GEOMETRY PROBLEMS: {problems_total}")
    if problems_total:
        print("Fix path: these trades were built BEFORE the oil-scale rules patch;")
        print("re-check after the next fresh shadow signal. If a FRESH trade still")
        print("flags, send this output back for a deeper trace.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
