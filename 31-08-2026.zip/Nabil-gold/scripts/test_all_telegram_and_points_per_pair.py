#!/usr/bin/env python3
"""Comprehensive test suite for Telegram formatting, decimals, and point calculations
across all 6 instruments: XAU/USD, WTI/USD, EUR/USD, GBP/USD, USD/CAD, USD/JPY.
"""

import sys
import unittest
from pathlib import Path

# Add project root to path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from utils.instruments import (
    get_instrument,
    point_size,
    price_decimals,
    format_price,
    round_price,
    points_to_price,
    price_to_points,
    normalize_symbol,
    enabled_instruments,
)
from utils.helpers import load_config, calculate_pips
from services.shadow_mode import shadow_instruments
from services.telegram_bot import TelegramService


class MultiPairTelegramAndPointsTest(unittest.TestCase):
    def setUp(self):
        self.config = load_config()
        self.bot = TelegramService(self.config)
        # Capture sent messages without actual network calls
        self.sent_messages = []
        self.bot.send_message = lambda text, urgent=False, chat_id=None: self.sent_messages.append(text) or True

    def test_shadow_mode_is_empty(self):
        """Verify that NO instrument is left in shadow mode."""
        shadows = shadow_instruments(self.config)
        self.assertEqual(shadows, [], f"Expected 0 shadow instruments, got: {shadows}")

        enabled = [i["symbol"] for i in enabled_instruments(self.config)]
        self.assertEqual(
            enabled,
            ["XAU/USD", "WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"],
            "All 6 instruments must be enabled for live execution"
        )

    def test_point_calculations_per_instrument(self):
        """Verify mathematical precision of point and pip calculations across all 6 symbols."""
        cases = [
            ("XAU/USD", 2650.00, 2665.00, 150.0, 0.10, 2),
            ("WTI/USD", 75.00, 75.60, 60.0, 0.01, 2),
            ("EUR/USD", 1.08500, 1.08580, 80.0, 0.00001, 5),
            ("GBP/USD", 1.27500, 1.27600, 100.0, 0.00001, 5),
            ("USD/CAD", 1.36500, 1.36580, 80.0, 0.00001, 5),
            ("USD/JPY", 155.200, 155.300, 100.0, 0.001, 3),
        ]
        for sym, entry, target, expected_pts, expected_ps, expected_dec in cases:
            ps = point_size(sym, self.config)
            dec = price_decimals(sym, self.config)
            self.assertEqual(ps, expected_ps, f"Point size mismatch for {sym}")
            self.assertEqual(dec, expected_dec, f"Decimals mismatch for {sym}")

            calc_pts = calculate_pips(entry, target, "BUY", sym)
            self.assertAlmostEqual(calc_pts, expected_pts, places=1, msg=f"Points calculation mismatch for {sym}")

            # Test round trip conversion
            converted_price = points_to_price(expected_pts, sym, self.config)
            self.assertAlmostEqual(converted_price, target - entry, places=5)
            back_to_pts = price_to_points(converted_price, sym, self.config)
            self.assertAlmostEqual(back_to_pts, expected_pts, places=1)

    def test_signal_card_formatting_forex_and_oil(self):
        """Verify that signal cards format exact decimals and pair-specific management rules."""
        test_instruments = [
            ("XAU/USD", 2650.00, 2640.00, 2658.00, 2670.00, "2650.00", "2640.00", "150 pts", "40 pts"),
            ("WTI/USD", 75.00, 73.40, 76.28, 78.00, "75.00", "73.40", "60 pts", "16 pts"),
            ("EUR/USD", 1.08500, 1.08300, 1.08660, 1.08900, "1.08500", "1.08300", "80 pts", "20 pts"),
            ("GBP/USD", 1.27500, 1.27250, 1.27700, 1.28000, "1.27500", "1.27250", "100 pts", "25 pts"),
            ("USD/CAD", 1.36500, 1.36300, 1.36660, 1.36900, "1.36500", "1.36300", "80 pts", "20 pts"),
            ("USD/JPY", 155.200, 154.950, 155.400, 155.700, "155.200", "154.950", "100 pts", "25 pts"),
        ]

        for sym, entry, sl, tp1, tp2, ent_str, sl_str, exp_gap, exp_step in test_instruments:
            self.sent_messages.clear()
            decision = {
                "symbol": sym,
                "decision": "BUY",
                "current_price": entry,
                "confidence": 85,
                "signal": {
                    "type": "BUY",
                    "entry": {"price": entry, "kind": "MARKET"},
                    "stop_loss": sl,
                    "tp1": tp1,
                    "tp2": tp2,
                    "rr_ratio": 2.0,
                },
                "risk": {
                    "stop_loss": {"price": sl, "distance_points": calculate_pips(entry, sl, "BUY", sym)},
                },
                "admission_path": "path1_unified_five_agents",
            }
            res = self.bot.send_signal(decision)
            self.assertTrue(res)
            self.assertEqual(len(self.sent_messages), 1)
            msg = self.sent_messages[0]

            # Verify Symbol and Entry Price
            self.assertIn(f"{sym} — BUY", msg)
            self.assertIn(f"Entry:</b> {ent_str}", msg)
            self.assertIn(f"Stop Loss:</b> {sl_str}", msg)

            # Verify Management / Trailing Gap & Step
            self.assertIn(f"Trail gap {exp_gap} / step {exp_step}", msg, f"Trailing gap mismatch for {sym} in:\n{msg}")

    def test_pending_order_activation_text_formatting(self):
        """Verify pending limit order text formatting for 5-decimal and 3-decimal pairs."""
        cases = [
            ("EUR/USD", "BUY_LIMIT", 1.08500, 1.08600, "price pulls back down to 1.08500", "1.08600"),
            ("GBP/USD", "SELL_LIMIT", 1.27500, 1.27400, "price rallies up to 1.27500", "1.27400"),
            ("USD/JPY", "BUY_LIMIT", 155.200, 155.400, "price pulls back down to 155.200", "155.400"),
            ("WTI/USD", "SELL_LIMIT", 75.50, 75.00, "price rallies up to 75.50", "75.00"),
        ]

        for sym, order_kind, ent, curr, exp_activation, curr_str in cases:
            self.sent_messages.clear()
            decision = {
                "symbol": sym,
                "decision": "BUY" if "BUY" in order_kind else "SELL",
                "current_price": curr,
                "confidence": 80,
                "signal": {
                    "type": "BUY" if "BUY" in order_kind else "SELL",
                    "entry": {"price": ent, "kind": order_kind, "distance_points": calculate_pips(curr, ent, "BUY", sym)},
                    "stop_loss": ent - 0.00200 if "BUY" in order_kind else ent + 0.00200,
                    "tp1": ent + 0.00200 if "BUY" in order_kind else ent - 0.00200,
                    "tp2": ent + 0.00400 if "BUY" in order_kind else ent - 0.00400,
                },
                "admission_path": "path1_unified_five_agents",
            }
            res = self.bot.send_signal(decision)
            self.assertTrue(res)
            msg = self.sent_messages[0]

            self.assertIn(exp_activation, msg, f"Expected activation line '{exp_activation}' in:\n{msg}")
            self.assertIn(f"Current price:</b> {curr_str}", msg)

    def test_trade_event_notes_and_trailing_update(self):
        """Verify trade update event messages show correct trailing rules per instrument."""
        cases = [
            ("EUR/USD", "80-point gap / 20-point step"),
            ("GBP/USD", "100-point gap / 25-point step"),
            ("USD/CAD", "80-point gap / 20-point step"),
            ("USD/JPY", "100-point gap / 25-point step"),
            ("WTI/USD", "60-point gap / 16-point step"),
            ("XAU/USD", "150-point gap / 40-point step"),
        ]

        for sym, exp_rule_text in cases:
            self.sent_messages.clear()
            trade = {
                "id": f"test_{sym.replace('/', '_')}",
                "symbol": sym,
                "type": "BUY",
                "status": "OPEN",
                "entry_price": 1.08500 if "EUR" in sym else (155.00 if "JPY" in sym else 2650.00),
            }
            evaluation = {
                "old_status": "OPEN",
                "new_status": "OPEN",
                "updates": {
                    "trailing_distance_points": None, # Should resolve to instrument default
                    "trailing_step_points": None,
                }
            }
            res = self.bot.send_trade_events(
                trade=trade,
                events=["TRAILING_SL_UPDATED"],
                current_price=trade["entry_price"] + 0.0050,
                pnl_points=50.0,
                evaluation=evaluation,
            )
            self.assertTrue(res)
            msg = self.sent_messages[0]
            self.assertIn(f"Trailing stop updated using {exp_rule_text}", msg, f"Mismatch for {sym} in:\n{msg}")


if __name__ == "__main__":
    unittest.main()
