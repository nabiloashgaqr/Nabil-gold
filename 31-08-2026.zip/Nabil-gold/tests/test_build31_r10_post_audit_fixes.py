"""BUILD 31 R10/R11 - Post-audit fixes verification (2026-08-27).

Pins every fix applied after the independent forensic review of the R9
release, updated for the LOCAL-ONLY R11 decision (nothing ships on GitHub,
Supabase or Vercel anymore - local VPS, local storage, local dashboard).

1.  Local-only invariants      -> no cloud artifacts ship, DB provider=local.
2.  Quiet-hours clock-first    -> a wrong session label can no longer disarm
                                   the 21:00-06:30 UTC guard.
3.  Institutional Flow Guard   -> confirmation bar 65% (config-driven),
                                   not the old weak hardcoded 55%.
4.  Shadow kill-switch         -> shadow mode is OFF at code level for all
                                   assets; NABIL_ENABLE_SHADOW=1 is the only
                                   way back in.
5.  Learning clock             -> Asia/Hebron, not UTC.
6.  Buy-the-dip messages       -> per-instrument decimal rendering.
7.  Timezone doc drift         -> root BATs delegate; no "23:00 UTC"/GitHub
                                   Actions leftovers in the daily report.
8.  Dashboard drill-down       -> per-pair price formatting everywhere.
9.  DST-safe scheduler         -> no fixed UTC+3 fallback in the PS1.
10. Root shims                 -> stale duplicates now delegate.
11. Shadow data archived       -> storage/shadow no longer ships live.
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

from agents.decision_agent import DecisionAgent
from utils.helpers import load_config
from utils.instruments import config_for_instrument

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def base_config():
    return load_config()


# ── shared breakout-chase mock (mirrors test_institutional_safety_guards) ──
def _breakout_mock(price=4640.0, smc_conf=65.0, smc_dir="BUY", auc_conf=65.0,
                   auc_dir="BUY", session_info=None, vwap=None):
    return {
        "current_price": price,
        "technical": {"direction": "BUY", "confidence": 75.0, "atr": 5.0},
        "multitimeframe": {"direction": "BUY", "confidence": 85.0},
        "classical": {"direction": "BUY", "confidence": 70.0},
        "smc": {"direction": smc_dir, "confidence": smc_conf,
                "setup_structure": {"setup_type": "CONTINUATION_BREAKDOWN"}},
        "price_action": {"direction": "BUY", "confidence": 70.0},
        "auction_flow": {"direction": auc_dir, "confidence": auc_conf,
                         "session_vwap": vwap if vwap is not None else price},
        "setup_context": {"setup_type": "CONTINUATION_BREAKDOWN"},
        "session": {"trading_allowed": True, "allow_signals": True},
        "session_info": session_info or {},
    }


def _decide_at(base_config, results, utc_time):
    da = DecisionAgent(base_config)
    with patch("agents.decision_agent.datetime") as mock_dt:
        mock_dt.now.return_value = utc_time
        mock_dt.side_effect = lambda *a, **k: datetime(*a, **k)
        return da.analyze(results)


# ── 1) LOCAL-ONLY invariants (R11) ──────────────────────────────────────────
def test_no_cloud_artifacts_ship():
    """The system is 100% local: nothing GitHub/Supabase/Vercel remains."""
    assert not (ROOT / ".github").exists(), "GitHub workflows must not ship"
    assert not (ROOT / "api").exists(), "Vercel API client must not ship"
    assert not (ROOT / "dashboard" / "api").exists(), "Vercel API client must not ship"
    for legacy in ("SUPABASE_VERIFICATION_CHECKLIST.sql", "VERIFY_ALL_COLUMNS.sql",
                   "PHASE6_ANALYST_DISTILLATION_MIGRATION.sql", "deploy/trades_demo.sql",
                   "scripts/migrate_supabase_to_local.py"):
        assert not (ROOT / legacy).exists(), f"cloud-era artifact still ships: {legacy}"


def test_database_provider_is_local():
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    db = cfg.get("database") or {}
    assert str(db.get("provider", "")).lower() == "local"
    assert "local_fallback_file" in db


def test_env_template_has_no_cloud_keys():
    template = (ROOT / ".env.template").read_text(encoding="utf-8")
    assert "SUPABASE" not in template.upper()
    assert "TELEGRAM_BOT_TOKEN" in template


def test_no_github_test_left_in_build16():
    src = (ROOT / "tests" / "test_build16_telegram_polish.py").read_text(encoding="utf-8")
    assert "subscription_cron" not in src
    assert ".github" not in src


# ── 2) quiet-hours guard: clock-first, labels may only widen ────────────────
def test_quiet_hours_survive_wrong_london_label(base_config):
    """22:30 UTC IS the quiet window even if the session agent says London."""
    res = _breakout_mock(session_info={"current_session": "LONDON"})
    out = _decide_at(base_config, res, datetime(2026, 8, 25, 22, 30, tzinfo=timezone.utc))
    assert out["signal"] == "WAIT"
    assert any("Quiet Session Guard" in w for w in out["warnings"])


def test_asia_label_widens_quiet_window(base_config):
    """10:00 UTC is active time, but an ASIA label may only ADD caution."""
    res = _breakout_mock(session_info={"current_session": "ASIA"})
    out = _decide_at(base_config, res, datetime(2026, 8, 25, 10, 0, tzinfo=timezone.utc))
    assert out["signal"] == "WAIT"
    assert any("Quiet Session Guard" in w for w in out["warnings"])


def test_active_session_label_cannot_arm_london_clock(base_config):
    """08:30 UTC with a LONDON label still trades (no false blocking)."""
    res = _breakout_mock(session_info={"current_session": "LONDON"})
    out = _decide_at(base_config, res, datetime(2026, 8, 25, 8, 30, tzinfo=timezone.utc))
    assert out["signal"] == "BUY"


# ── 3) institutional flow guard at the qualified-agent bar (65%) ────────────
def test_flow_guard_blocks_60_percent_alignment(base_config):
    """60% same-direction SMC used to slip through at the old 55% bar.
    Auction Flow is NOT aligned here, so no leg of the OR can save it."""
    res = _breakout_mock(smc_conf=60.0, auc_dir="WAIT", auc_conf=50.0)
    out = _decide_at(base_config, res, datetime(2026, 8, 25, 9, 0, tzinfo=timezone.utc))
    assert out["signal"] == "WAIT"
    assert any("Institutional Flow Guard" in w and ">= 65%" in w for w in out["warnings"])


def test_flow_guard_passes_65_percent_alignment(base_config):
    res = _breakout_mock(smc_conf=65.0, auc_dir="WAIT", auc_conf=50.0)
    out = _decide_at(base_config, res, datetime(2026, 8, 25, 9, 0, tzinfo=timezone.utc))
    assert out["signal"] == "BUY"


def test_flow_guard_threshold_is_config_pinned(base_config):
    req = base_config.get("signal_requirements") or {}
    assert req.get("institutional_flow_min_confidence") == 65
    assert req.get("institutional_flow_min_confidence") >= req.get("agent_min_confidence", 65)


# ── 4) shadow-mode system-wide kill switch ──────────────────────────────────
def test_shadow_dead_by_default(monkeypatch):
    from services.shadow_mode import is_shadow_config, shadow_instruments, shadow_mode_unlocked
    monkeypatch.delenv("NABIL_ENABLE_SHADOW", raising=False)
    assert shadow_mode_unlocked() is False
    synthetic = {"symbol": "WTI/USD", "enabled": True, "mode": "shadow",
                 "instrument": {"symbol": "WTI/USD", "mode": "shadow"}}
    assert is_shadow_config(synthetic) is False
    assert shadow_instruments({"symbols": [{"symbol": "WTI/USD", "enabled": True, "mode": "shadow"}]}) == []


def test_shadow_revivable_only_by_explicit_env(monkeypatch):
    from services.shadow_mode import is_shadow_config, shadow_instruments
    monkeypatch.setenv("NABIL_ENABLE_SHADOW", "1")
    synthetic = {"symbol": "WTI/USD", "enabled": True, "mode": "shadow",
                 "instrument": {"symbol": "WTI/USD", "mode": "shadow"}}
    assert is_shadow_config(synthetic) is True
    assert [i["symbol"] for i in shadow_instruments(
        {"symbols": [{"symbol": "WTI/USD", "enabled": True, "mode": "shadow"}]})] == ["WTI/USD"]


def test_shadow_storage_archived_out_of_the_live_tree():
    """CODE invariant (always asserted): the kill switch lives in
    services/shadow_mode.py.

    ENVIRONMENT invariant (conditional): legacy shadow books must be migrated
    by scripts/verify_r10_fixes.py (self-healing) or the R11 installer. Until
    then this test SKIPS - a machine state is not a code defect."""
    from services import shadow_mode
    legacy = shadow_mode.ROOT / "storage" / "shadow"
    archive = shadow_mode.ROOT / "storage" / "archive" / "shadow_20260827"
    src = (shadow_mode.ROOT / "services" / "shadow_mode.py").read_text(encoding="utf-8")
    assert "NABIL_ENABLE_SHADOW" in src
    if legacy.exists() and any(legacy.iterdir()):
        pytest.skip("legacy shadow storage still live - run python scripts\\verify_r10_fixes.py "
                    "to auto-migrate it to storage\\archive")
    assert not legacy.exists() or not any(legacy.iterdir())
    # On a fresh checkout (no production books at all) there is nothing to have
    # archived; the archive exists only on a machine that ran the migration.
    if not archive.exists():
        pytest.skip("no shadow books on this machine (clean checkout) - nothing to archive")
    assert archive.exists()


# ── 5) learning service clock = Asia/Hebron ─────────────────────────────────
def test_learning_service_clock_is_hebron():
    from services import learning_service as ls
    now = ls.hebron_now()
    assert now.tzinfo is not None
    assert now.utcoffset() in (timedelta(hours=2), timedelta(hours=3))
    src = (ROOT / "services" / "learning_service.py").read_text(encoding="utf-8")
    assert "datetime.now(timezone.utc)" not in src, "learning must never stamp UTC directly"


# ── 6) buy-the-dip / sell-the-rally messages respect pair decimals ─────────
class _FakeDB:
    def __init__(self, trades):
        self._trades = trades

    def get_open_trades(self):
        return self._trades


def test_sell_the_rally_message_renders_five_decimals(base_config):
    import scripts.run_analysis as ra
    decision = {
        "decision": "SELL",
        "symbol": "EUR/USD",
        "signal": {"entry": {"price": 1.08000}},
        "current_price": 1.08000,
    }
    db = _FakeDB([{"type": "SELL", "symbol": "EUR/USD", "entry_price": 1.08543}])
    reason = ra._cross_path_distance_check(decision, db, base_config, cross_distance_points=100)
    assert reason is not None
    assert "1.08000" in reason and "1.08543" in reason, reason


def test_buy_the_dip_still_blocks_higher_buy(base_config):
    import scripts.run_analysis as ra
    decision = {
        "decision": "BUY",
        "symbol": "EUR/USD",
        "signal": {"entry": {"price": 1.09000}},
        "current_price": 1.09000,
    }
    db = _FakeDB([{"type": "BUY", "symbol": "EUR/USD", "entry_price": 1.08543}])
    reason = ra._cross_path_distance_check(decision, db, base_config, cross_distance_points=100)
    assert reason is not None and "buy the dip" in reason


# ── 7) timezone doc drift eliminated ────────────────────────────────────────
def test_root_daily_bat_delegates_to_canonical():
    bat = (ROOT / "daily_report_demo.bat").read_bytes().decode("ascii")
    assert "deploy\\tasks\\daily_report_demo.bat" in bat
    assert "23:00 UTC" not in bat
    weekly = (ROOT / "weekly_report_demo.bat").read_bytes().decode("ascii")
    assert "deploy\\tasks\\weekly_report_demo.bat" in weekly


def test_daily_report_docstring_names_scheduler_not_github():
    head = "\n".join((ROOT / "scripts" / "run_daily_report.py").read_text(encoding="utf-8").splitlines()[:8])
    assert "GitHub Actions" not in head
    assert "23:50" in head and "Asia/Hebron" in head


# ── 8) dashboard drill-down uses the per-pair decimal engine ────────────────
def test_dashboard_drilldown_formats_per_pair():
    app = (ROOT / "dashboard" / "app.js").read_text(encoding="utf-8")
    assert "formatTradePrice(t.entry_price, t.symbol)" in app
    assert "formatTradePrice(t.stop_loss, t.symbol)" in app
    assert "toFixed(2)</td>" not in app


def test_dashboard_marketing_copy_is_multi_asset():
    page = (ROOT / "dashboard" / "index.html").read_text(encoding="utf-8")
    assert "currently focuses on Gold" not in page
    assert "Six-asset coverage" in page
    for pair in ("EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"):
        assert f'value="{pair}"' in page


# ── 9) DST-safe scheduler script ────────────────────────────────────────────
def test_scheduler_ps1_has_no_fixed_utc3_fallback():
    ps1 = (ROOT / "scripts" / "fix_daily_report_timezone.ps1").read_text(encoding="ascii")
    assert "CreateCustomTimeZone" not in ps1, "fixed UTC+3 fallback drifts one hour in winter"
    assert ps1.index("Jordan Standard Time") < ps1.index("Middle East Standard Time")


# ── 10) root duplicates are shims now ───────────────────────────────────────
def test_root_run_analysis_is_a_delegating_shim():
    src = (ROOT / "run_analysis.py").read_text(encoding="utf-8")
    assert "runpy.run_path" in src and "scripts" in src
    assert len(src) < 3000, "root run_analysis.py must stay a thin shim"


def test_root_mt5_executor_and_database_reexport_canonical():
    import mt5_executor
    from services import mt5_executor as canonical
    assert mt5_executor.Mt5DemoExecutor is canonical.Mt5DemoExecutor
    # database shim: content-based (sys.modules may be polluted by other tests)
    src = (ROOT / "database.py").read_text(encoding="utf-8")
    assert "from services.database import" in src and "DatabaseService" in src
