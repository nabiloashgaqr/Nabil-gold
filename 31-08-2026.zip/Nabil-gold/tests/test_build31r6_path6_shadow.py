"""BUILD 31 R6 (2026-08-24, operator order): "fix it + measure 3 levels
50/60/70 + shadow only, stop the execution".

Covers:
  1. the FIXED OTE formula (retracements measured from the extreme);
  2. shadow mode: all gates run, NO order is placed, three levels are
     recorded and a clearly branded notice is sent (no trade card);
  3. shadow tracking to resolution (touch / SL-first-in-bar / TP1 / TP2 /
     independent levels / 24h expiry);
  4. regression: with shadow OFF the live execution path is unchanged.

Fixtures (candles / books / fakes) follow tests/test_build30_prearm_ote.py.
"""
import json
from datetime import datetime, timedelta, timezone

import pytest

import services.pre_arm_ote as pa


def _candle(o, h, l, c):
    return {"open": o, "high": h, "low": l, "close": c}


def _flat_then_impulse_up(points=40.0, n_flat=12):
    """12 flat candles around 4600, then a strong UP leg of `points`."""
    candles = []
    base = 4600.0
    for _ in range(n_flat):
        candles.append(_candle(base, base + 1, base - 1, base))
    step = points / 3
    for i in range(3):
        o = base + step * i
        c = base + step * (i + 1)
        candles.append(_candle(o, c + 1, o - 1, c))
    top = base + points
    candles.append(_candle(top, top + 0.5, top - 0.5, top))
    return candles


class _DB:
    def __init__(self):
        self.saved = []

    def new_trade_id(self):
        return "TRADE_PREARM_R6"

    def save_trade(self, decision):
        self.saved.append(decision)
        return decision["trade_id"]


class _TG:
    def __init__(self):
        self.messages = []

    def send_message(self, text, urgent=False, chat_id=None):
        self.messages.append(text)
        return True

    def send_signal(self, decision):
        self.messages.append(("signal", decision))
        return True


def _data(candles, current_price):
    return {"timeframes": {"15m": {"data": candles}},
            "current_price": current_price}


def _classic_book(direction="BUY", n_support=3, n_oppose=0, net=68.0):
    agents = ["technical", "multitimeframe", "classical", "smc",
              "price_action", "auction_flow"]
    opposite = "SELL" if direction == "BUY" else "BUY"
    supporters, opponents = ["smc"], []
    budget = n_support - 1
    for name in (a for a in agents if a != "smc"):
        if budget > 0:
            supporters.append(name)
            budget -= 1
        elif n_oppose > 0:
            opponents.append(name)
            n_oppose -= 1
    edge = 0.5 * (len(supporters) - len(opponents))
    return {"consensus": {
        direction: {"supporters": supporters, "opponents": opponents,
                    "support_count": len(supporters),
                    "opposition_count": len(opponents),
                    "edge": edge, "confidence": net},
        opposite: {"supporters": opponents, "opponents": supporters,
                   "support_count": len(opponents),
                   "opposition_count": len(supporters),
                   "edge": -edge, "confidence": 40.0},
    }}


def _macro_ok(direction="BUY", conf=58.0):
    return {"macro_fundamental": {"macro_direction": {
        "bias": "BULLISH_GOLD" if direction == "BUY" else "BEARISH_GOLD",
        "confidence": conf}}}


# ── 1) the fixed formula ──────────────────────────────────────────────────

def test_ote_formula_is_true_retracement_buy():
    leg = {"direction": "BUY", "leg_origin": 100.0, "leg_peak": 200.0,
           "leg_size": 100.0, "peak_idx": 5, "atr": 10.0}
    ote = pa.project_ote(leg, pa._cfg({}))
    # 70% retracement FROM THE PEAK: 200 - 0.70*100 = 130 (not 170!)
    assert ote["entry"] == pytest.approx(130.0)
    # the OTE zone [62%, 79%] as retracements: [200-79, 200-62] = [121, 138]
    assert ote["zone_low"] == pytest.approx(121.0)
    assert ote["zone_high"] == pytest.approx(138.0)
    assert ote["stop"] == pytest.approx(90.0)    # origin - 1*ATR
    assert ote["target"] == 200.0                # the leg peak


def test_ote_formula_is_true_retracement_sell():
    leg = {"direction": "SELL", "leg_origin": 200.0, "leg_peak": 100.0,
           "leg_size": 100.0, "peak_idx": 5, "atr": 10.0}
    ote = pa.project_ote(leg, pa._cfg({}))
    # 70% retracement UP FROM THE TROUGH: 100 + 0.70*100 = 170
    assert ote["entry"] == pytest.approx(170.0)
    assert ote["zone_low"] == pytest.approx(162.0)   # 100 + 62
    assert ote["zone_high"] == pytest.approx(179.0)  # 100 + 79
    assert ote["stop"] == pytest.approx(210.0)       # origin + 1*ATR
    assert ote["target"] == 100.0


# ── 2) shadow mode: measure, never execute ────────────────────────────────

def test_shadow_mode_places_no_order_and_records_3_levels(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    candles = _flat_then_impulse_up(points=40.0)
    peak = max(c["high"] for c in candles)
    cp = peak - 5.0
    db, tg = _DB(), _TG()
    all_results = {"smc": {"trend": "BULLISH"}, "risk": {"approved": True},
                   **_macro_ok("BUY", 58.0)}
    side = pa.try_pre_arm(
        data=_data(candles, cp), all_results=all_results,
        config={"pre_arm_ote": {"shadow": True}}, symbol="XAU/USD",
        open_trades_snapshot=[], database=db, telegram=tg,
        current_price=cp,
        classic_book=_classic_book("BUY", n_support=3, n_oppose=1, net=68.0))
    # NO armed side is returned (the reactive suppression never fires)
    assert side is None
    # NO trade saved, NO trade card (only the shadow notice)
    assert db.saved == []
    texts = [m for m in tg.messages if isinstance(m, str)]
    assert len(texts) == 1
    msg = texts[0]
    assert "SHADOW" in msg
    assert "No order" in msg
    assert "50%" in msg and "60%" in msg and "70%" in msg
    # the shadow book has ONE arm with THREE measured levels
    arms = pa._load_shadow_arms()
    assert len(arms) == 1
    arm = arms[0]
    assert arm["side"] == "BUY" and arm["status"] == "OPEN"
    assert set(arm["levels"]) == {"50", "60", "70"}
    leg = arm["leg"]
    for key, pct in (("50", 0.50), ("60", 0.60), ("70", 0.70)):
        lv = arm["levels"][key]
        # each level is a TRUE retracement from the peak, same stop for all
        assert lv["entry"] == pytest.approx(
            leg["peak"] - leg["size"] * pct, abs=0.01)
    assert arm["levels"]["50"]["stop"] == arm["levels"]["60"]["stop"]
    assert arm["levels"]["60"]["stop"] == arm["levels"]["70"]["stop"]
    # the book travels with the arm (who decided is auditable)
    assert arm["vote"]["confirm_source"] == "macro"
    assert arm["vote"]["net_confidence"] == 68.0


def test_shadow_off_still_executes_live(tmp_path, monkeypatch):
    """Regression: with no shadow flag the live execution path is
    unchanged (order saved, side returned)."""
    monkeypatch.chdir(tmp_path)
    candles = _flat_then_impulse_up(points=40.0)
    peak = max(c["high"] for c in candles)
    cp = peak - 5.0
    db, tg = _DB(), _TG()
    all_results = {"smc": {"trend": "BULLISH"}, "risk": {"approved": True},
                   **_macro_ok("BUY", 58.0)}
    side = pa.try_pre_arm(
        data=_data(candles, cp), all_results=all_results,
        config={}, symbol="XAU/USD",
        open_trades_snapshot=[], database=db, telegram=tg,
        current_price=cp,
        classic_book=_classic_book("BUY", n_support=3, n_oppose=1, net=68.0))
    assert side == "BUY"
    assert len(db.saved) == 1
    assert pa._load_shadow_arms() == []  # nothing measured in live mode


# ── 3) shadow tracking to resolution ──────────────────────────────────────

def _mk_arm(side="BUY", hours_ago=0.5, levels=None, symbol="XAU/USD"):
    ts = (datetime.now(timezone.utc) - timedelta(hours=hours_ago)).isoformat()
    if levels is None:
        # explicit numbers: 50@4620, 60@4615.8, 70@4611.6, stop 4591
        levels = {
            "50": {"entry": 4620.0, "stop": 4591.0, "tp1": 4635.0,
                   "tp2": 4660.0, "rr": 1.5, "risk_points": 29.0,
                   "distance_points": 16.0},
            "60": {"entry": 4615.8, "stop": 4591.0, "tp1": 4645.0,
                   "tp2": 4670.0, "rr": 1.5, "risk_points": 24.8,
                   "distance_points": 20.2},
            "70": {"entry": 4611.6, "stop": 4591.0, "tp1": 4650.0,
                   "tp2": 4680.0, "rr": 1.5, "risk_points": 20.6,
                   "distance_points": 24.4},
        }
    out = {}
    for key, lv in levels.items():
        out[key] = dict(lv, status="OPEN", touched_at=None, outcome=None,
                        pnl_points=None, resolved_at=None)
    return {"id": "TEST_ARM", "ts": ts, "symbol": symbol, "side": side,
            "current_price": 4636.0, "smc_trend": "BULLISH",
            "leg": {"origin": 4599.0, "peak": 4641.0, "size": 42.0},
            "vote": {"confirm_source": "macro", "net_confidence": 68.0},
            "levels": out, "status": "OPEN"}


def _seed(tmp_path, monkeypatch, arm):
    monkeypatch.chdir(tmp_path)
    with open(pa.SHADOW_FILE, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(arm) + "\n")


def _run_update(candles, cp):
    pa._update_shadow_arms(symbol="XAU/USD", candles=candles,
                           current_price=cp)


def test_shadow_tracking_touch_then_tp1(tmp_path, monkeypatch):
    _seed(tmp_path, monkeypatch, _mk_arm())
    # cycle 1: the pullback reaches the 50 level (low 4619 <= 4620),
    # not the deeper levels (low stays above 4615.8)
    bar_touch = _candle(4625.0, 4626.0, 4619.0, 4621.0)
    _run_update([bar_touch, _candle(4621.0, 4622.0, 4620.0, 4621.0)], 4621.0)
    arm = pa._load_shadow_arms()[0]
    assert arm["levels"]["50"]["status"] == "TOUCHED"
    assert arm["levels"]["60"]["status"] == "OPEN"
    assert arm["levels"]["70"]["status"] == "OPEN"
    assert arm["status"] == "OPEN"
    # cycle 2: the rally takes the 50 level to TP1 (high 4650 >= 4635,
    # low 4620 > stop 4591)
    bar_up = _candle(4621.0, 4650.0, 4620.0, 4649.0)
    _run_update([bar_up, _candle(4649.0, 4650.0, 4648.0, 4649.0)], 4649.0)
    arm = pa._load_shadow_arms()[0]
    assert arm["levels"]["50"]["outcome"] == "TP1"
    assert arm["levels"]["50"]["pnl_points"] == pytest.approx(
        4635.0 - 4620.0)
    assert arm["status"] == "OPEN"  # the deeper levels are still open


def test_shadow_conservative_sl_first_within_a_bar(tmp_path, monkeypatch):
    """A bar whose range covers BOTH the stop and TP1 resolves as SL
    (the conservative rule)."""
    _seed(tmp_path, monkeypatch, _mk_arm(levels={
        "50": {"entry": 4620.0, "stop": 4591.0, "tp1": 4635.0,
               "tp2": 4660.0, "rr": 1.5, "risk_points": 29.0,
               "distance_points": 16.0},
    }))
    # touch first (a mild pullback)
    _run_update([_candle(4625.0, 4626.0, 4618.0, 4620.0),
                 _candle(4620.0, 4621.0, 4619.0, 4620.0)], 4620.0)
    # then one bar that swings through stop AND tp1
    _run_update([_candle(4620.0, 4640.0, 4590.0, 4600.0),
                 _candle(4600.0, 4601.0, 4599.0, 4600.0)], 4600.0)
    arm = pa._load_shadow_arms()[0]
    assert arm["levels"]["50"]["outcome"] == "SL"
    assert arm["levels"]["50"]["pnl_points"] == pytest.approx(
        4591.0 - 4620.0)
    assert arm["status"] == "CLOSED"


def test_shadow_deeper_levels_track_independently(tmp_path, monkeypatch):
    """A pullback that reaches 50 AND 60 but not 70: the two touched
    levels resolve on their own, the untouched one stays OPEN."""
    _seed(tmp_path, monkeypatch, _mk_arm())
    # cycle 1: low 4614 crosses 50 (4620) and 60 (4615.8), not 70 (4611.6)
    _run_update([_candle(4622.0, 4623.0, 4614.0, 4615.0),
                 _candle(4615.0, 4616.0, 4614.5, 4615.0)], 4615.0)
    # cycle 2: a rally to 4640 -> the 50 level (tp1 4635) closes TP1,
    # the 60 level (tp1 4645) is still running
    _run_update([_candle(4615.0, 4640.0, 4614.5, 4639.0),
                 _candle(4639.0, 4640.0, 4638.0, 4639.0)], 4639.0)
    arm = pa._load_shadow_arms()[0]
    assert arm["levels"]["50"]["outcome"] == "TP1"
    assert arm["levels"]["60"]["status"] == "TOUCHED"
    assert arm["levels"]["70"]["status"] == "OPEN"
    assert arm["status"] == "OPEN"


def test_shadow_expiry_after_24h(tmp_path, monkeypatch):
    """An arm whose levels were never touched expires after 24h."""
    _seed(tmp_path, monkeypatch, _mk_arm(hours_ago=25.0))
    _run_update([_candle(4660.0, 4662.0, 4658.0, 4661.0),
                 _candle(4661.0, 4662.0, 4660.0, 4661.0)], 4661.0)
    arm = pa._load_shadow_arms()[0]
    assert arm["status"] == "CLOSED"
    for lv in arm["levels"].values():
        assert lv["status"] == "CLOSED"
        assert lv["outcome"] == "EXPIRED_NEVER_TOUCHED"
        assert lv["pnl_points"] == 0.0
