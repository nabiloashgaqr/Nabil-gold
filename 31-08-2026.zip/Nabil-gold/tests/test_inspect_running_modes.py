"""2026-08-19: running-modes inspection tool tests."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class TestInspectRunningModes:
    def _fixture(self, root: Path) -> None:
        (root / "storage" / "agent_measurements").mkdir(parents=True, exist_ok=True)
        (root / "storage" / "shadow" / "wtiusd").mkdir(parents=True, exist_ok=True)
        (root / "logs").mkdir(parents=True, exist_ok=True)
        (root / "config.json").write_text(json.dumps({
            "schedule": {"timezone": "Asia/Hebron"},
            "agent_measurement": {"enabled": True},
            "correlation_guard": {"enabled": True, "enforce": False},
            "symbols": [
                {"symbol": "XAU/USD", "enabled": True},
                {"symbol": "WTI/USD", "enabled": True, "mode": "shadow"},
            ],
            "execution": {"execution_mode": "mt5_demo"},
        }), encoding="utf-8")
        plans = [
            {"created_at": "2026-08-19T08:00:00+00:00", "symbol": "XAU/USD",
             "plan_status": "WATCH_ONLY", "plan_reason": "counter-objective BUY plan lacks reversal proof: x"},
            {"created_at": "2026-08-19T09:00:00+00:00", "symbol": "XAU/USD",
             "plan_status": "READY"},
            {"created_at": "2026-08-19T10:00:00+00:00", "symbol": "WTI/USD",
             "plan_status": "WATCH_ONLY", "plan_reason": "archetype conviction is LOW: y"},
            {"created_at": "2026-08-19T11:00:00+00:00", "symbol": "XAU/USD",
             "plan_status": "WATCH_ONLY", "plan_reason": "quality below floor"},
        ]
        (root / "storage" / "session_plans.json").write_text(json.dumps(plans), encoding="utf-8")
        (root / "storage" / "agent_measurements" / "agent_system_2026-08-19.jsonl").write_text(
            '{"a":1}\n{"a":2}\n', encoding="utf-8")
        (root / "storage" / "shadow" / "wtiusd" / "trades.json").write_text("[]", encoding="utf-8")
        (root / "logs" / "tick_manager.log").write_text(
            "WARNING: Demo order refused: daily cap reached\n" * 3, encoding="utf-8")
        (root / ".demo_halt").write_text("REAL MT5 account refused", encoding="utf-8")

    def _run(self, root: Path, date="2026-08-19") -> subprocess.CompletedProcess:
        script = Path(__file__).resolve().parents[1] / "scripts" / "inspect_running_modes.py"
        return subprocess.run(
            [sys.executable, str(script), "--root", str(root), "--date", date],
            capture_output=True, text=True, timeout=180,
        )

    def test_full_inspection(self, tmp_path):
        self._fixture(tmp_path)
        out = self._run(tmp_path)
        assert out.returncode == 0, out.stderr
        assert "WATCH_ONLY" in out.stdout
        assert "reversal_proof" in out.stdout
        assert "archetype_conviction" in out.stdout
        assert "agent_measurement.enabled = True" in out.stdout
        assert "mode=shadow" in out.stdout
        assert ".demo_halt EXISTS" in out.stdout
        assert "Demo order refused" in out.stdout
        assert "daily cap" in out.stdout

    def test_empty_root_graceful(self, tmp_path):
        out = self._run(tmp_path)
        assert out.returncode == 0, out.stderr
        assert "RUNNING MODES INSPECTION" in out.stdout
