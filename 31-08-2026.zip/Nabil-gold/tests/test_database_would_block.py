# -*- coding: utf-8 -*-
"""BUILD31-R13: save_trade persists shadow metadata.

Every NEW trade row carries:
  * entry evidence (entry_vwap / entry_atr / range_high / range_low) at row
    level so the guard replay stops answering UNKNOWN, and
  * ``would_block`` - which R10/R11 guards would have blocked the entry
    (log-only; never blocks the save, never raises).
"""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from services.database import DatabaseService as Database  # noqa: E402


def _decision(**overrides):
    decision = {
        "trade_id": "TRADE_20260827_120000_TEST01",
        "symbol": "XAU/USD",
        "decision": "BUY",
        "confidence": 70,
        "current_price": 2640.0,
        "signal": {
            "entry": {"price": 2640.0},
            "stop_loss": 2630.0,
            "tp1": 2650.0,
            "tp2": 2660.0,
            "rr_ratio": 2.0,
        },
        "agents": {"auction_flow": {"session_vwap": 2638.0}},
        "market_context": {"technical_regime": {"volatility_regime": "NORMAL",
                                                "market_phase": "TREND_UP"}},
        "session_info": {"current_session": "Asia", "session_quality": "NORMAL"},
    }
    decision.update(overrides)
    return decision


class TestWouldBlockShadowPersistence(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.book = Path(self.tmp.name) / "trades.json"
        self.book.write_text("[]", encoding="utf-8")  # load_json_rows needs a file
        self.db = Database(config={})
        self.db.local_path = self.book  # redirect persistence to tmp
        self.db.use_supabase = False
        self.db.client = None

    def tearDown(self):
        self.tmp.cleanup()

    def _saved_rows(self):
        return json.loads(self.book.read_text(encoding="utf-8"))

    def test_new_row_has_would_block_and_evidence(self):
        self.db.save_trade(_decision())
        rows = self._saved_rows()
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertIsInstance(row.get("would_block"), list)
        # evidence extracted from decision.agents.auction_flow.session_vwap
        self.assertAlmostEqual(row.get("entry_vwap"), 2638.0, places=2)
        for key in ("entry_atr", "range_high", "range_low"):
            self.assertIn(key, row)

    def test_dip_guard_fires_on_worse_priced_stack(self):
        # existing OPEN BUY at 2620 (better price) still open
        self.book.write_text(json.dumps([{
            "id": "TRADE_20260827_110000_ANCHOR", "type": "BUY",
            "symbol": "XAU/USD", "entry_price": 2620.0, "status": "OPEN",
            "created_at": "2026-08-27T02:00:00+00:00", "signal_snapshot": {},
        }]), encoding="utf-8")
        self.db.save_trade(_decision())
        row = self._saved_rows()[-1]
        self.assertTrue(any("BUY_THE_DIP" in g for g in (row.get("would_block") or [])))

    def test_shadow_failure_never_breaks_the_save(self):
        # a failing shadow eval (book read explodes) must not break the save
        import services.guard_replay as gr

        original = gr.load_json_rows
        gr.load_json_rows = lambda *_a, **_k: (_ for _ in ()).throw(RuntimeError("boom"))
        try:
            trade_id = self.db.save_trade(_decision())
        finally:
            gr.load_json_rows = original
        self.assertTrue(str(trade_id).startswith("TRADE_"))
        row = self._saved_rows()[0]
        self.assertIsNone(row.get("would_block"))

    def test_evidence_fields_are_row_level_not_snapshot_only(self):
        self.db.save_trade(_decision(signal={
            "entry": {"price": 2640.0}, "stop_loss": 2630.0,
            "tp1": 2650.0, "tp2": 2660.0,
        }, technical_note=None))
        row = self._saved_rows()[0]
        # fields live at TOP level (reports must not parse the snapshot JSON)
        self.assertIn("entry_vwap", row)
        self.assertIn("range_high", row)


if __name__ == "__main__":
    unittest.main()
