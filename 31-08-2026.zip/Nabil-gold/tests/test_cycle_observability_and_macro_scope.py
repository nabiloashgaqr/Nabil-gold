"""Two production-log lessons from 2026-08-17.

1. THE SILENT CYCLE. At 10:06:09 the why_no_map diagnostic showed a BUY book
   of 3 qualified supporters at net 74.7%; the production cycle at 10:06:11
   logged nothing between its start and "Market status suppressed". Whether
   the book had really collapsed in those two seconds was unknowable, because
   no line recorded what the voted book WAS. Every cycle must now log one
   BOOK line with the per-side support/net/opposition and the rejection
   reason, before any path logic runs.

2. THE GOLD VERDICT JUDGING CRUDE. The WTI shadow cycles logged
   "Path 2: Macro does NOT confirm BUY (bias=BEARISH_GOLD ...)" — the macro
   agent's output is literally a gold verdict (BULLISH_GOLD/BEARISH_GOLD),
   so using it to confirm or refuse an oil entry is a category error. It was
   harmless for execution (shadow never executes) but it poisons the shadow
   scorecard that the WTI promotion decision will be read from. Macro
   confirmation is now gold-only; other symbols log an explicit skip and
   fall through to Gemini/Auction confirmation.
"""

from __future__ import annotations

import io
import re

SRC = io.open("scripts/run_analysis.py", encoding="utf-8").read()


# ── 1. the BOOK line ────────────────────────────────────────────────────────

def test_every_cycle_logs_the_voted_book():
    assert '"BOOK %s: decision=%s | BUY %d sup net=%s%% (%s) opp=%d | "' in SRC
    assert '"SELL %d sup net=%s%% (%s) opp=%d | reject=%s | safety=%s"' in SRC


def test_the_book_line_reads_the_real_consensus_block():
    block = SRC.split("BOOK %s: decision=")[1][:2000]
    # It must read the decision agent's own consensus metrics, not recompute
    # a second book that could disagree with the one that actually voted.
    head = SRC.split("BOOK %s: decision=")[0][-2000:]
    assert '(decision.get("classic") or {}).get("consensus")' in head
    assert 'rejection_reason' in block


def test_the_book_line_shows_the_safety_veto():
    """2026-08-17 11:06: 'BUY 3 sup net=73.2% opp=0 | reject=-' yet WAIT.
    Consensus accepted; a post-vote safety filter flipped it and wrote its
    reason only into decision["warnings"]. The line must surface that reason
    (the LAST warning — filters append in veto order), else every accepted-
    then-vetoed cycle reads as an unexplained contradiction."""
    head = SRC.split("BOOK %s: decision=")[0][-2500:]
    assert 'decision.get("warnings")' in head
    tail = SRC.split('| reject=%s | safety=%s"')[1][:1500]
    assert "_bw[-1]" in tail, "must print the most recent (veto) warning"


def test_the_book_line_runs_before_path_two():
    book_at = SRC.index("BOOK %s: decision=")
    path2_at = SRC.index("Path 2: Two-Agent Entry with External Confirmation")
    assert book_at < path2_at, "the BOOK line must precede all path logic"


def test_the_book_line_cannot_break_the_cycle():
    head = SRC.split("BOOK %s: decision=")[0][-2500:]
    assert "try:" in head
    tail = SRC.split("reject=%s | safety=%s")[1][:1500]
    assert "except Exception" in tail


# ── 2. macro confirmation is gold-only ──────────────────────────────────────

def test_macro_confirmation_follows_the_config_symbol_list():
    """R25.7-M1 (operator 2026-08-28): judging is a symbol list.

    The macro agent is multi-instrument (its own docstring names the FX-4
    pairs; the live books carried per-symbol verdicts). The old gold-only
    monopoly line is replaced by a config list; gold keeps its exact old
    behaviour because the list ships with "XAU/USD" first.
    """
    assert "_macro_symbols = {normalize_symbol(x) for x in" in SRC
    assert '(macro_cfg.get("symbols") or ["XAU/USD"])' in SRC
    assert '_macro_applies = normalize_symbol(symbol) in _macro_symbols' in SRC
    assert 'if macro_cfg.get("enabled", True) and not _macro_applies:' in SRC


def test_non_gold_symbols_log_an_explicit_macro_skip():
    assert "Macro confirmation skipped for %s" in SRC
    # The skip must not silently disable the whole path: Gemini and Auction
    # confirmation still follow it in the source.
    skip_at = SRC.index("Macro confirmation skipped for %s")
    assert SRC.index("Step B: Fallback to Gemini Confirmation", skip_at) > skip_at
    assert SRC.index("Fallback to Auction Flow Confirmation", skip_at) > skip_at


def test_the_gold_bias_strings_are_only_compared_for_gold():
    """The expected-bias mapping lives inside the gold-scoped block."""
    scoped = SRC.split('if macro_cfg.get("enabled", True) and _macro_applies:')[1]
    scoped = scoped.split("Step B: Fallback to Gemini Confirmation")[0]
    assert '"BULLISH_GOLD" if side == "BUY" else "BEARISH_GOLD"' in scoped
    # And no other CODE line in the Path-2 confirmation chain compares them
    # (comment mentions do not count).
    chain = SRC.split("Step A: Try Macro Confirmation")[1]
    chain = chain.split("Fallback to Auction Flow Confirmation")[0]
    code_lines = [ln for ln in chain.splitlines() if "BULLISH_GOLD" in ln and not ln.lstrip().startswith("#")]
    assert len(code_lines) == 1, code_lines
