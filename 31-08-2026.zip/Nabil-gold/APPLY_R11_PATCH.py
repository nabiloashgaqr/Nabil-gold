#!/usr/bin/env python3
"""BUILD 31 R11 LOCAL-ONLY patcher (run from the repo root).

Applies the local-only decision surgically and idempotently:
  - config.json            -> database.provider = "local"
  - requirements.txt       -> supabase becomes optional
  - .env.template          -> local-only template (no cloud keys)
  - .env (LIVE)            -> BACKUP + strip legacy cloud keys
  - tests/test_build16...  -> remove the obsolete GitHub cron test
  - tests/test_build31_r10_post_audit_fixes.py -> fix the two
    live-checkout failures (github artifact test -> local-only test,
    shadow test -> conditional skip until migration)
  - scripts/verify_r10_fixes.py -> check 01 becomes the LOCAL-ONLY law
  - storage/shadow         -> self-healing migration to storage/archive

Exit 0 = every patch OK. ASCII output only.
"""
import json
import re
import sys
import time
from pathlib import Path

ROOT = Path.cwd()
if not (ROOT / "config.json").exists():
    print("[FAIL] run from the repo root (C:\\Nabil-gold)")
    sys.exit(2)

ok, fail = [], []


def patch(name, cond, detail=""):
    (ok if cond else fail).append(name + ((" - " + detail) if detail else ""))


# -- config.json --------------------------------------------------------------
try:
    p = ROOT / "config.json"
    cfg = json.loads(p.read_text(encoding="utf-8"))
    db = cfg.get("database") or {}
    db["provider"] = "local"
    db["description"] = ("BUILD 31 R11 (local-only 2026-08-27): the system runs 100% on the local VPS - "
                         "local JSON storage (storage/trades.json). No GitHub, no Supabase, no Vercel.")
    db.pop("url", None)
    db.pop("key", None)
    cfg["database"] = db
    p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    patch("config.json -> database.provider=local", True)
except Exception as e:
    patch("config.json", False, str(e))

# -- requirements.txt ----------------------------------------------------------
try:
    p = ROOT / "requirements.txt"
    s = p.read_text(encoding="utf-8")
    if "supabase>=" in s and "legacy cloud migration" not in s:
        s = s.replace(
            "supabase>=2.10.0,<3.0.0",
            "# BUILD 31 R11 (local-only): storage is local JSON.\n"
            "# supabase>=2.10.0,<3.0.0  # optional, only for a legacy cloud migration")
        p.write_text(s, encoding="utf-8")
    patch("requirements.txt -> supabase optional", True)
except Exception as e:
    patch("requirements.txt", False, str(e))

# -- .env.template ---------------------------------------------------------------
try:
    tpl = (
        "# ============================================================\n"
        "# Nabil-gold -- LOCAL-ONLY VPS .env (BUILD 31 R11, 2026-08-27)\n"
        "# Copy to C:\\Nabil-gold\\.env and fill EVERY key.\n"
        "# The system is 100% local: local storage, local dashboard.\n"
        "# Legacy cloud keys of any kind do NOT belong here - they are\n"
        "# ignored by policy and stripped by APPLY_R11_LOCAL_ONLY.ps1.\n"
        "# ============================================================\n"
        "\n"
        "# ---- Telegram (the demo chat receives all TEST DEMO cards) ----\n"
        "TELEGRAM_BOT_TOKEN=REPLACE_ME\n"
        "TELEGRAM_CHAT_ID=REPLACE_ME\n"
        "TELEGRAM_DEMO_CHAT_ID=REPLACE_ME\n"
        "\n"
        "# ---- LLM (Gemini is the working key; the other two optional) ----\n"
        "GEMINI_API_KEY=REPLACE_ME\n"
        "OPENAI_API_KEY=REPLACE_ME\n"
        "ANTHROPIC_API_KEY=REPLACE_ME\n"
        "\n"
        "# ---- Market data: FALLBACK only when the MT5 feed fails ----\n"
        "TWELVEDATA_API_KEY=REPLACE_ME\n"
        "\n"
        "# ---- Oil macro (FREE key: https://www.eia.gov/opendata/) ----\n"
        "EIA_API_KEY=REPLACE_ME\n"
        "\n"
        "# ---- Demo stream (fixed; wrappers set the same values too) ----\n"
        "EXECUTION_MODE=REPLACE_ME\n"
        "TRADES_TABLE=REPLACE_ME\n"
        "DATA_SOURCE_PRIMARY=REPLACE_ME\n")
    (ROOT / ".env.template").write_text(tpl, encoding="ascii")
    patch(".env.template -> local-only", True)
except Exception as e:
    patch(".env.template", False, str(e))

# -- live .env sanitation (the REAL operational fix) -----------------------------
try:
    envp = ROOT / ".env"
    if envp.exists():
        bak = ROOT / (".env.backup_R11_" + time.strftime("%Y%m%d_%H%M%S"))
        bak.write_bytes(envp.read_bytes())
        lines = envp.read_text(encoding="utf-8", errors="replace").splitlines()
        kept, stripped = [], []
        for ln in lines:
            u = ln.strip().upper()
            if u.startswith("SUPABASE_") or u.startswith("GITHUB_TOKEN") or u.startswith("VERCEL_"):
                stripped.append(u.split("=")[0])
                continue
            kept.append(ln)
        envp.write_text("\n".join(kept) + "\n", encoding="utf-8")
        patch(".env sanitized (backup: " + bak.name + ")", True,
              "stripped: " + (", ".join(stripped) if stripped else "none found"))
    else:
        patch(".env sanitation", True, "no .env file present")
except Exception as e:
    patch(".env sanitation", False, str(e))

# -- tests/test_build16: remove the obsolete GitHub cron test --------------------
try:
    p = ROOT / "tests" / "test_build16_telegram_polish.py"
    s = p.read_text(encoding="utf-8")
    if "def test_subscription_cron_every_4_hours" in s:
        idx = s.index("def test_subscription_cron_every_4_hours")
        tail = s[idx + 10:]
        m = re.search(r"\n(?:def |# \u2500|@pytest)", tail)
        end = (idx + 10 + m.start() + 1) if m else len(s)
        s = s[:idx] + s[end:]
        p.write_text(s, encoding="utf-8")
    patch("test_build16: GitHub cron test removed",
          "subscription_cron" not in (ROOT / "tests" / "test_build16_telegram_polish.py").read_text(encoding="utf-8"))
except Exception as e:
    patch("test_build16", False, str(e))

# -- R10 verification tests: the two live-checkout fixes -------------------------
try:
    p = ROOT / "tests" / "test_build31_r10_post_audit_fixes.py"
    s = p.read_text(encoding="utf-8")

    def replace_func(src, func_name, new_body):
        marker = "def " + func_name + "():"
        if marker not in src:
            return src, False
        start = src.index(marker)
        tail = src[start + 10:]
        m = re.search(r"\n(?:def |# \u2500)", tail)
        end = (start + 10 + m.start() + 1) if m else len(src)
        return src[:start] + new_body.strip() + "\n\n\n" + src[end:].lstrip("\n"), True

    n1 = (
        "def test_local_only_no_cloud_artifacts():\n"
        '    """R11 (local-only): nothing GitHub/Supabase/Vercel ships anymore."""\n'
        "    import json as _json\n"
        '    assert not (ROOT / ".github").exists(), "GitHub workflows must not ship"\n'
        '    assert not (ROOT / "api").exists(), "Vercel API client must not ship"\n'
        '    assert not (ROOT / "dashboard" / "api").exists(), "Vercel API client must not ship"\n'
        '    cfg = _json.loads((ROOT / "config.json").read_text(encoding="utf-8"))\n'
        '    assert str((cfg.get("database") or {}).get("provider", "")).lower() == "local"\n'
        '    src16 = (ROOT / "tests" / "test_build16_telegram_polish.py").read_text(encoding="utf-8")\n'
        '    assert "subscription_cron" not in src16\n')

    n2 = (
        "def test_shadow_storage_archived_out_of_the_live_tree():\n"
        '    """CODE invariant always; ENVIRONMENT invariant until migration runs."""\n'
        "    from services import shadow_mode\n"
        '    legacy = shadow_mode.ROOT / "storage" / "shadow"\n'
        '    archive = shadow_mode.ROOT / "storage" / "archive" / "shadow_20260827"\n'
        "    if legacy.exists() and any(legacy.iterdir()):\n"
        '        pytest.skip("legacy shadow storage still live - this patch migrated it; re-run pytest")\n'
        "    assert not legacy.exists() or not any(legacy.iterdir())\n"
        "    assert archive.exists()\n")

    s, c1 = replace_func(s, "test_github_workflow_absence_no_longer_breaks_suite", n1)
    s, c2 = replace_func(s, "test_shadow_storage_archived_out_of_the_live_tree", n2)
    if c1 or c2:
        p.write_text(s, encoding="utf-8")
    patch("R10 tests: github test -> local-only test", c1 or "already patched")
    patch("R10 tests: shadow test -> conditional", c2 or "already patched")
except Exception as e:
    patch("R10 tests", False, str(e))

# -- verifier check 01 -> the LOCAL-ONLY law --------------------------------------
try:
    p = ROOT / "scripts" / "verify_r10_fixes.py"
    s = p.read_text(encoding="utf-8")
    if "# 1. Cron-test" in s or "# 1. LOCAL-ONLY" not in s:
        start = s.index("    # 1. Cron-test") if "    # 1. Cron-test" in s else s.index("    # 1. LOCAL-ONLY")
        ends = [s.find('"workflow absent + skip logic present")', start),
                s.find('"schedule promise asserted, skip guard armed")', start)]
        ends = [e for e in ends if e != -1]
        if ends:
            end = min(ends) + len('"workflow absent + skip logic present")')
            new_block = (
                '    # 1. LOCAL-ONLY (R11): nothing GitHub/Supabase/Vercel ships anymore\n'
                '    src16 = (ROOT / "tests" / "test_build16_telegram_polish.py").read_text(encoding="utf-8")\n'
                '    template = (ROOT / ".env.template").read_text(encoding="utf-8")\n'
                '    dead = ["SUPABASE_VERIFICATION_CHECKLIST.sql", "VERIFY_ALL_COLUMNS.sql",\n'
                '            "scripts/migrate_supabase_to_local.py", "tests/test_local_migration.py",\n'
                '            "tests/test_dashboard_api_leak.py", "deploy/trades_demo.sql"]\n'
                '    leftovers = [f for f in dead if (ROOT / f).exists()]\n'
                '    check(1, "LOCAL-ONLY: zero cloud artifacts (GitHub/Supabase/Vercel)",\n'
                '          (not (ROOT / ".github").exists()) and (not (ROOT / "api").exists())\n'
                '          and (not (ROOT / "dashboard" / "api").exists())\n'
                '          and "subscription_cron" not in src16\n'
                '          and str((json.loads((ROOT / "config.json").read_text(encoding="utf-8")).get("database") or {}).get("provider", "")).lower() == "local"\n'
                '          and "SUPABASE" not in template.upper() and not leftovers,\n'
                '          "no .github, no Vercel api/, provider=local" + (f", leftovers: {leftovers}" if leftovers else ""))')
            s = s[:start] + new_block + s[end:]
            p.write_text(s, encoding="utf-8")
    patch("verify_r10_fixes.py check 01 -> LOCAL-ONLY",
          "Cron-test" not in (ROOT / "scripts" / "verify_r10_fixes.py").read_text(encoding="utf-8"))
except Exception as e:
    patch("verifier", False, str(e))

# -- main.py docstring --------------------------------------------------------------
try:
    p = ROOT / "main.py"
    s = p.read_text(encoding="utf-8")
    s = s.replace(
        "under .github/workflows. This file simply runs one analysis cycle locally.",
        "by the Windows Task Scheduler on the local VPS. This file simply runs one analysis cycle locally.")
    p.write_text(s, encoding="utf-8")
    patch("main.py docstring", True)
except Exception as e:
    patch("main.py", False, str(e))

# -- shadow storage self-healing migration ------------------------------------------
try:
    from services import shadow_mode as sm
    live = sm.ROOT / "storage" / "shadow"
    archive = sm.ROOT / "storage" / "archive" / "shadow_20260827"
    note = "already migrated"
    if live.exists() and any(live.iterdir()):
        archive.mkdir(parents=True, exist_ok=True)
        moved = []
        for child in sorted(live.iterdir()):
            target = archive / child.name
            if not target.exists():
                child.rename(target)
                moved.append(child.name)
                continue
            if child.is_dir() and target.is_dir():
                for item in sorted(child.iterdir()):
                    dest = target / item.name
                    if not dest.exists():
                        item.rename(dest)
                    elif item.read_bytes() == dest.read_bytes():
                        item.unlink()
                    else:
                        item.rename(target / (item.stem + "_legacy_shadow" + item.suffix))
                try:
                    child.rmdir()
                except OSError:
                    pass
                moved.append(child.name + ": merged")
            else:
                moved.append(child.name + ": left in place")
        try:
            live.rmdir()
        except OSError:
            pass
        note = "migrated: " + ", ".join(moved)
    clean = (not live.exists()) or not any(live.iterdir())
    patch("storage/shadow -> storage/archive/shadow_20260827", clean and archive.exists(), note)
except Exception as e:
    patch("shadow migration", False, str(e))

print("")
for line in ok:
    print("[OK]   " + line)
for line in fail:
    print("[FAIL] " + line)
sys.exit(1 if fail else 0)
