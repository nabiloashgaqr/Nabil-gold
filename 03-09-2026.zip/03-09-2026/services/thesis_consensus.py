"""Shared entry-grade directional admission for thesis exits and flip guards."""
from __future__ import annotations

from typing import Any, Dict

from utils.helpers import get_agent_weights

# Operator 2026-08-14: the original five voting agents are restored.  Auction
# Flow is a standalone non-voting agent: it confirms Path 4 (SMC conditional
# map) and Path 5 (two-agent + auction) but never casts a core vote.
VOTING_AGENTS = ("technical", "multitimeframe", "classical", "smc", "price_action")
LEGACY_AGENT_ALIASES: Dict[str, str] = {}

# Opposition-veto census (operator 2026-08-18f choice A, widened 2026-08-18g).
# Auction Flow and Macro do not VOTE for admission — that stays exactly as
# decided (2026-08-14, and macro was never a voter). But a veto is not a
# vote: on 2026-08-18 15:01 an add card itself displayed "price_action SELL
# 68 + auction_flow SELL 71" and the add still entered, because the opponent
# counter only saw the five voters. For counting who OPPOSES an addition
# (scale-in veto, pending activation gate) and who opposes a live thesis
# (thesis-exit vote), the standalone flow reader AND the macro read are
# full-rights opponents. Each source qualifies at its own established bar:
# agents (incl. auction_flow) at agent_min_confidence (65); macro at its
# macro_confirmation floor (55) — the same bar that lets it confirm entries.
VETO_AGENTS = VOTING_AGENTS + ("auction_flow",)

_MACRO_BIAS_SIDES = {"BULLISH_GOLD": "BUY", "BEARISH_GOLD": "SELL"}


def _macro_veto_read(details: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any] | None:
    """Normalize the macro read for veto counting, or None if unusable.

    Accepts either the compact form {"direction": BUY/SELL, "confidence": n}
    (agent books, admission details) or the raw agent payload carrying
    macro_direction {"bias": BULLISH_GOLD/BEARISH_GOLD, ...}. The macro
    verdict is a GOLD verdict: for any other symbol the caller must not
    inject a macro entry into the details it passes here.

    R26.9.4 (2026-09-01): SYMBOL-ROUTED, like every other macro reader
    (the R26.9 single-voice doctrine). An OIL symbol is judged by its own
    ``oil_macro`` voice — NEVER by the dollar/gold macro. Live defect this
    closes (16:40 cycle today): a WTI BUY book with 4 qualified supporters
    across two families was refused inside this evaluator with "Path 1
    blocked: macro reads SELL at 74%" while oil_macro — the only voice
    allowed to judge crude — was neutral (WAIT 0). This was the FOURTH
    macro reader, the one R26.9 left un-unified (the hard veto, the exit
    mirror and the auditor were already routed via macro_voice). Fail-open
    when oil has no committed verdict, exactly like counter_macro_block.
    """
    sym = str(((details.get("symbol") if isinstance(details, dict) else "")
               or (config.get("symbol") if isinstance(config, dict) else "")
               or "")).upper()
    macro_min = _f((((config.get("signal_requirements") or {}).get("two_agent_entry") or {})
                    .get("macro_confirmation") or {}).get("min_confidence"), 55.0)
    # R26.9.13 (operator 2026-09-03): the HARD VETO has its own, higher bar.
    # Confirming an entry at 55 stayed; OPPOSING one (blocking admission or
    # killing a live thesis) now needs 60 — a stale or conflicted macro read
    # (age-decayed under v2) must not hold a hard veto. Config-overridable:
    # signal_requirements.two_agent_entry.macro_veto.min_confidence.
    macro_veto_min = _f((((config.get("signal_requirements") or {}).get("two_agent_entry") or {})
                         .get("macro_veto") or {}).get("min_confidence"), 60.0)
    # The 60 bar disciplines the DOLLAR/GOLD macro (stale-able yfinance law).
    # oil_macro keeps its own R26.9.4 doctrine bar (55) — it is a separate,
    # supply/EIA-based voice, not the judge this order is about.
    if "WTI" not in sym:
        macro_min = max(macro_min, macro_veto_min)
    if "WTI" in sym:
        oil = details.get("oil_macro")
        if not isinstance(oil, dict) or not oil:
            return None  # no oil voice -> fail-open, never the dollar macro
        direction = _direction(oil)
        if direction not in {"BUY", "SELL"}:
            bias = str(oil.get("bias") or "").upper()
            if "BEARISH" in bias or bias in {"SELL", "BEAR"}:
                direction = "SELL"
            elif "BULLISH" in bias or bias in {"BUY", "BULL"}:
                direction = "BUY"
            else:
                return None
        confidence = _f(oil.get("confidence"))
        if direction in {"BUY", "SELL"} and confidence > 0:
            return {"direction": direction, "confidence": confidence,
                    "min": macro_min, "source": "oil_macro"}
        return None
    macro = (details.get("macro_fundamental") or details.get("macro")
             or (details.get("news_context") or {}).get("macro")
             or (details.get("market_context") or {}))
    if not isinstance(macro, dict) or not macro:
        return None
    inner = macro.get("macro_direction") if isinstance(macro.get("macro_direction"), dict) else None
    direction = _direction(macro)
    if direction not in {"BUY", "SELL"}:
        inner = inner or {}
        bias = str(inner.get("bias") or inner.get("direction") or "").upper()
        direction = _MACRO_BIAS_SIDES.get(bias)
        if direction is None:
            if bias == "SELL" or "BEARISH" in bias or bias == "BEAR":
                direction = "SELL"
            elif bias == "BUY" or "BULLISH" in bias or bias == "BULL":
                direction = "BUY"
            else:
                direction = "WAIT"
        confidence = _f(inner.get("confidence"), _f(macro.get("confidence"), 0.0))
    else:
        confidence = _f(macro.get("confidence"), 0.0)
    if direction not in {"BUY", "SELL"}:
        return None
    return {"direction": direction, "confidence": confidence,
            "min": macro_min, "source": "macro_fundamental"}


def evaluate_strong_structure(*_args: Any, **_kwargs: Any) -> Dict[str, Any]:
    """RETIRED (R25.7-C, operator 2026-08-28): the FX-4 dedicated lane is gone.

    The seven base paths admit every instrument (the FX-4 macro has been a
    first-class PATH 2 confirmer since R25.7-M1), so a dedicated forex lane
    has no job. Kept as a hard-refusal stub only so any stale import fails
    safe (never opens a trade) instead of crashing the cycle.
    """
    return {"allow": False, "reason": "Path 9 retired 2026-08-28 (R25.7-C): seven base paths cover FX-4"}


def count_veto_opponents(
    target_side: str,
    agent_details: Dict[str, Any] | None,
    config: Dict[str, Any],
) -> Dict[str, Any]:
    """Count qualified opponents of ``target_side`` (VETO_AGENTS + macro).

    Returns {"count": int, "opponents": [names]}. Agents qualify at the
    shared agent_min_confidence bar; macro qualifies at its own
    confirmation floor. Missing/empty book counts nobody.
    """
    details = agent_details if isinstance(agent_details, dict) else {}
    target = str(target_side or "").upper()
    opposite = "SELL" if target == "BUY" else "BUY"
    min_conf = _f((config.get("signal_requirements") or {}).get("agent_min_confidence"), 65.0)
    opponents = []
    for name in VETO_AGENTS:
        detail = details.get(name)
        if not isinstance(detail, dict):
            continue
        if _direction(detail) == opposite and _f(detail.get("confidence"), 0.0) >= min_conf:
            opponents.append(name)
    macro = _macro_veto_read(details, config)
    if macro and macro["direction"] == opposite and macro["confidence"] >= macro["min"]:
        # R26.9.4: label the voice that actually fired (oil_macro on crude).
        opponents.append(str(macro.get("source") or "macro_fundamental"))
    return {"count": len(opponents), "opponents": opponents}

# ── Agent families (operator 2026-08-17) ────────────────────────────────────
# The five voters are not five independent opinions. Technical,
# multitimeframe and classical all read trend/indicator inputs (EMA, ADX,
# timeframe alignment) and therefore tend to be wrong TOGETHER at liquidity
# turns; smc and price_action read structure. The live case: 2026-08-17
# 11:06, BUY admitted by exactly technical+multitimeframe+classical at the
# top of a buyside-liquidity sweep while smc (29.5) and price_action (45.7)
# both refused — the whole trend family agreed on the same mistake.
# The operator had previously merged two of these agents for this very
# reason; the family gate keeps the five separate voices but refuses to let
# one family carry Path 1 alone.
DEFAULT_AGENT_FAMILIES: Dict[str, str] = {
    "technical": "trend",
    "multitimeframe": "trend",
    "classical": "trend",
    "smc": "structure",
    "price_action": "structure",
}


def _voting_agents(config: Dict[str, Any]) -> tuple:
    """Effective voting roster. Auction Flow joins ONLY via auction_promotion."""
    promo = config.get("auction_promotion") or {}
    if bool(promo.get("enabled")):
        return VOTING_AGENTS + ("auction_flow",)
    return VOTING_AGENTS


def _agent_families(config: Dict[str, Any]) -> Dict[str, str]:
    """Family map, overridable from config (family_diversity.families)."""
    cfg = (config.get("signal_requirements") or {}).get("family_diversity") or {}
    families = dict(DEFAULT_AGENT_FAMILIES)
    override = cfg.get("families")
    if isinstance(override, dict):
        for family, members in override.items():
            if isinstance(members, (list, tuple)):
                for member in members:
                    families[str(member)] = str(family)
    # 2026-08-19: auction_flow joins the map ONLY when promoted to a voter.
    # It reads the live tick tape / flow profile — "tape", not trend/structure.
    if bool((config.get("auction_promotion") or {}).get("enabled")):
        families.setdefault("auction_flow", "tape")
    return families


def _family_diversity_check(
    supporters: list, config: Dict[str, Any],
) -> Dict[str, Any]:
    """Is this support book more than one correlated family?

    Returns {"diverse": bool, "families": [...], "enabled": bool}. A book
    whose qualified supporters ALL belong to one family is not three
    independent confirmations — it is one thesis counted three times.
    """
    cfg = (config.get("signal_requirements") or {}).get("family_diversity") or {}
    enabled = bool(cfg.get("enabled", False))
    families = _agent_families(config)
    seen = sorted({families.get(str(name), "unknown") for name in supporters})
    return {
        "enabled": enabled,
        "diverse": (not enabled) or len(seen) >= 2 or not supporters,
        "families": seen,
    }


def _all_trend_supporters(supporters: list, config: Dict[str, Any]) -> bool:
    """True when every supporter belongs to the trend family."""
    families = _agent_families(config)
    return bool(supporters) and all(
        families.get(str(name)) == "trend" for name in supporters
    )


#: R25.12: the single default for Rule A's confirmers (owner constant).
SINGLE_FAMILY_CONFIRMERS_DEFAULT = ["macro"]


def _single_family_confirmers(config: Dict[str, Any]) -> list:
    """Which external confirmers may rescue an ALL-TREND book?

    Measured basis (agent_correlation_report, 740 cycles to 2026-08-17):
    the four auction rescues of pure-trend books went 0/4 at both +2h and
    +4h — worse than the unrescued books themselves (23%). The mechanism:
    at momentum extremes auction flow AGREES with momentum by construction
    (flow is strong because price is moving), so it re-confirms the trend
    block at exactly the wrong moments. Macro is the one confirmer whose
    inputs (rates, USD, geopolitics) are independent of the last hour of
    price action. Default: macro only. Config list so the operator can
    widen it (e.g. add "gemini") without a patch.
    """
    cfg = (config.get("signal_requirements") or {}).get("family_diversity") or {}
    raw = cfg.get("single_family_confirmers", SINGLE_FAMILY_CONFIRMERS_DEFAULT)
    if not isinstance(raw, (list, tuple)):
        raw = ["macro"]
    return [str(x).lower() for x in raw]



def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _direction(detail: Dict[str, Any] | None) -> str:
    value = str((detail or {}).get("direction") or (detail or {}).get("signal") or "WAIT").upper()
    return "WAIT" if value in {"NEUTRAL", "HOLD", "NO_TRADE", "NONE", ""} else value


def _smc_conditional_map(details: Dict[str, Any]) -> tuple[Dict[str, Any], Dict[str, Any]]:
    """Return (SMC result, selected conditional map) without inventing a vote."""
    smc = details.get("smc") or {}
    if not isinstance(smc, dict):
        return {}, {}
    candidate = smc.get("conditional_map") or smc.get("setup_structure") or {}
    return smc, candidate if isinstance(candidate, dict) else {}


def _map_quality(candidate: Dict[str, Any]) -> float:
    value = candidate.get("quality_score", candidate.get("poi_quality_score"))
    if value in {None, ""}:
        setup_quality = candidate.get("setup_quality") or {}
        if isinstance(setup_quality, dict):
            value = setup_quality.get("score")
    return _f(value, 0.0)


def _map_structure_quality(smc: Dict[str, Any], candidate: Dict[str, Any]) -> str:
    details = candidate.get("details") or {}
    if not isinstance(details, dict):
        details = {}
    market_structure = smc.get("market_structure") or {}
    if not isinstance(market_structure, dict):
        market_structure = {}
    return str(
        candidate.get("structure_quality")
        or details.get("structure_quality")
        or market_structure.get("structure_quality")
        or "WEAK"
    ).upper()


def path4_candidate_matches(admission: Dict[str, Any], candidate: Dict[str, Any] | None) -> bool:
    """Prove the order candidate is the exact SMC map that earned Path 4."""
    if str((admission or {}).get("path") or "") != "SMC_MAP_AUCTION_CONFIRMATION":
        return False
    current = candidate if isinstance(candidate, dict) else {}
    expected_id = str(admission.get("smc_map_id") or "")
    expected_key = str(admission.get("smc_map_state_key") or "")
    if expected_id and str(current.get("id") or ""):
        return expected_id == str(current.get("id") or "")
    if expected_key and str(current.get("state_key") or ""):
        return expected_key == str(current.get("state_key") or "")
    expected_entry = _f(admission.get("smc_map_entry_price"), 0.0)
    current_entry = _f(current.get("entry_price"), 0.0)
    expected_side = str(admission.get("target_side") or "").upper()
    current_side = _direction(current)
    return bool(
        expected_entry > 0 and current_entry > 0
        and abs(expected_entry - current_entry) <= 0.011
        and expected_side == current_side
    )


def _external_confirmation(
    target_side: str,
    details: Dict[str, Any],
    config: Dict[str, Any],
) -> Dict[str, Any]:
    signal_cfg = (config.get("signal_requirements") or {}) if isinstance(config, dict) else {}
    path2 = signal_cfg.get("two_agent_entry") or {}
    macro_cfg = path2.get("macro_confirmation") or {}
    gemini_cfg = path2.get("gemini_confirmation") or {}
    oil_cfg = path2.get("oil_macro_confirmation") or {}

    # 2026-08-19 (build 9): symbol-aware confirmer ladder.
    # Macro's verdict is a GOLD verdict (gold-only by design). For a WTI run
    # the oil macro (EIA/OPEC/spread) is the fundamental confirmer instead.
    symbol = str((details or {}).get("symbol") or "").upper()

    if "WTI" in symbol:
        oil = details.get("oil_macro") or {}
        oil_side = _direction(oil)
        oil_conf = _f(oil.get("confidence"), 0.0)
        oil_min = _f(oil_cfg.get("min_confidence"), 55.0)
        if bool(oil_cfg.get("enabled", True)) and oil_side == target_side and oil_conf >= oil_min:
            return {"allow": True, "source": "oil_macro", "confidence": oil_conf}
    else:
        macro = details.get("macro_fundamental") or details.get("macro") or {}
        macro_side = _direction(macro)
        macro_conf = _f(macro.get("confidence"), 0.0)
        macro_min = _f(macro_cfg.get("min_confidence"), 55.0)
        if bool(macro_cfg.get("enabled", True)) and macro_side == target_side and macro_conf >= macro_min:
            return {"allow": True, "source": "macro", "confidence": macro_conf}

    gemini = details.get("gemini") or details.get("gemini_review") or {}
    gemini_side = _direction(gemini)
    gemini_conf = _f(gemini.get("confidence"), 0.0)
    gemini_min = _f(gemini_cfg.get("min_confidence"), 70.0)
    available = gemini.get("available", True) if isinstance(gemini, dict) else False
    if (bool(gemini_cfg.get("enabled", True)) and available
            and gemini_side == target_side and gemini_conf >= gemini_min):
        return {"allow": True, "source": "gemini", "confidence": gemini_conf}
    return {"allow": False, "source": None, "confidence": 0.0}


def evaluate_directional_admission(
    target_side: str,
    agent_details: Dict[str, Any] | None,
    config: Dict[str, Any],
    *,
    allow_path4: bool = True,
    symbol: str = "",
) -> Dict[str, Any]:
    """Apply the operator's entry theses to ``target_side``.

    1) >=3 qualified core agents with net weighted confidence >=72;
    2) at least 2 qualified core agents at the same confidence + Macro;
    3) at least 2 qualified core agents at the same confidence + Gemini;
    5) at least 2 qualified core agents at the same confidence + Auction Flow
       pointing the same way at >= its own threshold (default 72);
    4) SMC conditional map + Auction Flow confirmation (limit-only route).
    Qualified opposition is deducted with the same formula as DecisionAgent.
    The core book is the original five: technical, multitimeframe, classical,
    smc, price_action.  Auction Flow never votes.
    """
    target_side = str(target_side or "").upper()
    details = agent_details if isinstance(agent_details, dict) else {}
    if symbol:
        # 2026-08-19 (build 9): carry the symbol into the details so the
        # external-confirmer ladder can route WTI to oil_macro. Callers that
        # embed "symbol" in the details already flow without this.
        details = dict(details)
        details.setdefault("symbol", symbol)
    if target_side not in {"BUY", "SELL"} or not details:
        return {"allow": False, "path": None, "available": False,
                "supporters": [], "opponents": [], "confidence": 0.0}

    sig = config.get("signal_requirements") or {}
    min_agent_conf = _f(sig.get("agent_min_confidence"), 67.0)
    min_agents = int(sig.get("min_agents_agree", 3) or 3)
    min_consensus = _f(sig.get("min_consensus_confidence"), 72.0)
    path2 = sig.get("two_agent_entry") or {}
    path2_min_agents = int(path2.get("min_agents_agree", 2) or 2)
    path2_min_conf = _f(path2.get("min_consensus_confidence"), min_consensus)
    weights = get_agent_weights(config)
    opposite = "SELL" if target_side == "BUY" else "BUY"

    supporters = []
    opponents = []
    support_score = 0.0
    opposition_score = 0.0
    support_weight = 0.0
    weighted_conf_sum = 0.0
    for name in _voting_agents(config):
        used_name = name
        detail = details.get(name)
        if not isinstance(detail, dict):
            legacy = LEGACY_AGENT_ALIASES.get(name)
            detail = details.get(legacy) if legacy else None
            if isinstance(detail, dict):
                used_name = str(legacy)
        if not isinstance(detail, dict):
            continue
        confidence = _f(detail.get("confidence"), 0.0)
        if confidence < min_agent_conf:
            continue
        side = _direction(detail)
        weight = _f(weights.get(name), 0.0)
        score = confidence / 100.0 * weight
        if side == target_side:
            supporters.append(used_name)
            support_score += score
            support_weight += weight
            weighted_conf_sum += confidence * weight
        elif side == opposite:
            opponents.append(used_name)
            opposition_score += score

    support_avg = weighted_conf_sum / support_weight if support_weight else 0.0
    edge = support_score - opposition_score
    opposition_ratio = opposition_score / max(support_score, 0.0001)
    opposition_penalty = min(30.0, opposition_ratio * 30.0)
    confidence = max(0.0, min(95.0, support_avg - opposition_penalty))

    common = {
        "available": True,
        "target_side": target_side,
        "supporters": supporters,
        "opponents": opponents,
        "support_count": len(supporters),
        "opposition_count": len(opponents),
        "support_score": round(support_score, 4),
        "opposition_score": round(opposition_score, 4),
        "edge": round(edge, 4),
        "confidence": round(confidence, 1),
        "min_agent_confidence": min_agent_conf,
        "min_consensus_confidence": min_consensus,
    }

    # 2026-08-19 (data decision): PATH 1 kill switch. The measured ledger
    # showed PATH 1 (unconfirmed three-agent consensus) as the ONLY losing
    # path: PF 0.95 / success 43.8% / net -83 pts (n=16 resolved) against
    # PATH 2 (macro-confirmed) PF 7.86 / 75.0% / +3240 pts (n=24).
    # From now on every direct entry requires an external confirmer
    # (macro/gemini/auction per the two-agent paths) or a qualified SMC map
    # (PATH 4). Default stays enabled for backward compatibility with
    # historical tests; production config.json ships enabled=false.
    three_cfg = sig.get("three_agent_entry") or {}
    three_enabled = bool(three_cfg.get("enabled", True))
    if not three_enabled:
        common["path1_disabled"] = True
        common["path1_disable_reason"] = (
            "PATH 1 disabled by data decision 2026-08-19: unconfirmed consensus "
            "measured PF 0.95 (only losing path)"
        )

    if (three_enabled and len(supporters) >= min_agents and edge > 0
            and confidence >= min_consensus):
        # Family diversity gate (operator 2026-08-17): Path 1's whole premise
        # is three INDEPENDENT confirmations. Three supporters from one
        # correlated family (e.g. technical+multitimeframe+classical, all
        # trend readers) are one thesis counted three times, so they do NOT
        # earn the unconfirmed direct entry — the book falls through to
        # Paths 2/3/5 below, where an external confirmer (Macro/Gemini/
        # Auction) supplies the independent voice this book lacks.
        # R26.2 (2026-08-31): macro is not a voter in the core loop, so its
        # opposition never showed up in `opponents` - the counter-trend gold
        # BUY was admitted while macro read SELL >= floor. The macro veto that
        # count_veto_opponents already exposes is applied HERE too: an
        # unconfirmed consensus (Path 1) may NOT trade against a macro verdict
        # that meets its confirmation floor (operator threshold = 55%). Path 1
        # has no external confirmer, so macro opposition is final.
        mveto = _macro_veto_read(details, config)
        if mveto and mveto["direction"] == opposite and mveto["confidence"] >= mveto["min"]:
            common["macro_veto"] = True
            common["macro_veto_detail"] = (
                f"Path 1 blocked: macro reads {opposite} at {mveto['confidence']:.0f}% "
                f"(floor {mveto['min']:.0f}%) against {target_side}")
            return {**common, "allow": False, "path": None,
                    "reason": common["macro_veto_detail"]}
        diversity = _family_diversity_check(supporters, config)
        if diversity["diverse"]:
            return {**common, "allow": True, "path": "THREE_AGENT_CONSENSUS",
                    "supporter_families": diversity["families"],
                    "reason": f"{len(supporters)} qualified agents admit {target_side} at {confidence:.1f}%"}
        common["family_diversity_blocked"] = True
        common["supporter_families"] = diversity["families"]
        common["family_diversity_reason"] = (
            f"all {len(supporters)} supporters are one '{diversity['families'][0]}' family; "
            "Path 1 needs a second family or an external confirmation"
        )

    if (bool(path2.get("enabled", True)) and len(supporters) >= path2_min_agents
            and edge > 0 and confidence >= path2_min_conf):
        external = _external_confirmation(target_side, details, config)
        # R25.7-F (operator 2026-08-28, "مسار ٢ والثالث يجب يكونان من
        # عائلتين مع تأكيد خارجي ماكرو أو جيميناي"): Paths 2/3 need the
        # qualified supporter set to span TWO families — the same family
        # map the Path 1 gate uses (trend: technical/multitimeframe/
        # classical; structure: smc/price_action). A same-family pair is
        # one thesis counted twice: the live 2026-08-28 EUR card admitted
        # [technical, classical]. This gate runs BEFORE the
        # confirmer ladder, so macro/gemini can no longer rescue a
        # single-family book on Paths 2/3 — it supersedes Rule A's rescue
        # and R25.6-G2's gemini addition there (both remain in config and
        # return exactly when path23_require_two_families is set false).
        _p23_fam_map = _agent_families(config)
        _p23_families = sorted(
            {_p23_fam_map.get(str(name), "unknown") for name in supporters})
        _p23_two_families = bool(
            ((sig.get("family_diversity") or {})
             .get("path23_require_two_families", True)))
        if _p23_two_families and len(_p23_families) < 2:
            common["path23_single_family_refused"] = _p23_families
        elif external.get("allow"):
            source = str(external.get("source") or "").upper()
            # Rule A (operator 2026-08-17): a FULL all-trend book demoted by
            # the family gate (>= min_agents supporters, one family) may only
            # be rescued by the confirmers in single_family_confirmers
            # (default: macro alone — the one voice independent of the last
            # hour of price action). Auction rescues of pure-trend books
            # measured 0/4. Ordinary two-agent trend pairs are NOT touched
            # here: macro/gemini remain open to them as before; only Rule B
            # below restricts their auction confirmation.
            _src_lower = str(external.get("source") or "").lower()
            # BUILD 26 (2026-08-21): Rule A is symbol-aware. The gold rule
            # names "macro" as the only voice independent of recent price
            # action; for a WTI book the OIL macro is that same voice (the
            # ladder already routes WTI confirmations to oil_macro), so an
            # all-trend WTI book may be rescued by its own macro instead of
            # being refused for a source the gold rule never heard of.
            _confirmers = _single_family_confirmers(config)
            _rule_symbol = str((details or {}).get("symbol") or "").upper()
            if ("WTI" in _rule_symbol and "macro" in _confirmers
                    and "oil_macro" not in _confirmers):
                _confirmers = [*_confirmers, "oil_macro"]
            if (common.get("family_diversity_blocked")
                    and _src_lower not in _confirmers):
                common["single_family_confirmer_refused"] = _src_lower
            else:
                return {
                    **common, "allow": True, "path": f"TWO_AGENT_{source}",
                    "confirm_source": external.get("source"),
                    "confirm_confidence": external.get("confidence"),
                    "reason": (
                        f"{len(supporters)} qualified agents admit {target_side} at "
                        f"{confidence:.1f}% + {external.get('source')} "
                        f"{_f(external.get('confidence')):.1f}%"
                    ),
                }

    # PATH 5 — TWO-AGENT + AUCTION FLOW (operator 2026-08-14).
    # Auction Flow left the voting book and became the third external
    # confirmer alongside Macro (Path 2) and Gemini (Path 3): two qualified
    # core agents plus a same-direction standalone Auction Flow read at or
    # above its own threshold. Qualified opposition is allowed but deducted
    # by the standard penalty, exactly like Paths 2/3 — the net confidence
    # must still clear the floor.
    path5 = sig.get("path5_two_agent_auction") or {}
    if bool(path5.get("enabled", False)):
        path5_min_agents = int(path5.get("min_agents_agree", 2) or 2)
        path5_min_conf = _f(path5.get("min_consensus_confidence"), min_consensus)
        min_auction = _f(path5.get("min_auction_confidence"), 72.0)
        auction = details.get("auction_flow") or {}
        if not isinstance(auction, dict):
            auction = {}
        auction_direction = _direction(auction)
        auction_confidence = _f(auction.get("confidence"), 0.0)
        # Rule B (operator 2026-08-17): auction flow must never confirm a
        # support book that is ENTIRELY trend agents. Flow strength at a
        # momentum extreme is a consequence of the same move the trend
        # agents are voting on — momentum confirming momentum. The pair
        # (technical, multitimeframe) agrees 94.9% of the time; auction
        # stacked on top of it is the trend block wearing a third hat.
        # A pair with at least one structure agent keeps Path 5 intact.
        _p5_diversity_ok = True
        if bool(path5.get("require_family_diversity", True)) and bool(
                ((config.get("signal_requirements") or {})
                 .get("family_diversity") or {}).get("enabled", False)):
            _p5_diversity_ok = not _all_trend_supporters(supporters, config)
        if not _p5_diversity_ok:
            common["path5_family_refused"] = True
        # 2026-08-19 (auction promotion): when auction_flow votes it must NOT
        # also confirm Path 5 — the same read would be counted twice (once as
        # a supporter, once as the external confirmer).
        _auction_is_voter = (
            bool((config.get("auction_promotion") or {}).get("enabled"))
            and "auction_flow" in supporters
        )
        if _auction_is_voter:
            common["path5_disabled_auction_is_voter"] = True
        if (_p5_diversity_ok and not _auction_is_voter
                and len(supporters) >= path5_min_agents and edge > 0
                and confidence >= path5_min_conf
                and auction_direction == target_side
                and auction_confidence >= min_auction):
            return {
                **common, "allow": True, "path": "TWO_AGENT_AUCTION",
                "confirm_source": "auction",
                "confirm_confidence": auction_confidence,
                "auction_direction": auction_direction,
                "auction_confidence": round(auction_confidence, 1),
                "reason": (
                    f"{len(supporters)} qualified agents admit {target_side} at "
                    f"{confidence:.1f}% + auction flow {auction_confidence:.1f}%"
                ),
            }

    # PATH 4 is deliberately a map-confirmation route, not a synthetic SMC
    # vote.  The SMC agent may still be WAIT: its selected conditional map is
    # judged on map quality/revisit/dominance/trigger/structure, while Auction
    # Flow must independently point the same way at >= its own threshold.
    # Any qualified opposite core vote blocks the route.
    path4 = sig.get("path4_smc_map_auction") or {}
    if allow_path4 and bool(path4.get("enabled", False)):
        smc, smc_map = _smc_conditional_map(details)
        map_direction = _direction(smc_map)
        map_quality = _map_quality(smc_map)
        return_probability = _f(smc_map.get("return_probability_score", smc_map.get("return_probability")), 0.0)
        dominance = _f(smc_map.get("thesis_dominance_score", smc_map.get("dominance")), 0.0)
        trigger_score = _f(smc_map.get("trigger_score"), 0.0)
        trigger_ready = bool(smc_map.get("trigger_ready", False))
        structure_quality = _map_structure_quality(smc, smc_map)
        structure_rank = {"WEAK": 0, "MODERATE": 1, "STRONG": 2}
        minimum_structure = str(path4.get("min_structure_quality", "MODERATE") or "MODERATE").upper()

        # Auction Flow only — multitimeframe is a core voting agent again and
        # must never masquerade as the independent auction confirmation.
        auction = details.get("auction_flow") or {}
        if not isinstance(auction, dict):
            auction = {}
        auction_direction = _direction(auction)
        auction_confidence = _f(auction.get("confidence"), 0.0)

        min_quality = _f(path4.get("min_map_quality"), 60.0)
        min_return = _f(path4.get("min_return_probability"), 55.0)
        min_dominance = _f(path4.get("min_dominance"), 70.0)
        min_trigger = _f(path4.get("min_trigger_score"), 70.0)
        min_auction = _f(path4.get("min_auction_confidence"), 72.0)
        max_opposition = int(path4.get("max_qualified_opposition", 0) or 0)

        path4_checks = {
            "map_direction": map_direction == target_side,
            "map_quality": map_quality >= min_quality,
            "return_probability": return_probability >= min_return,
            "dominance": dominance >= min_dominance,
            "trigger_score": trigger_score >= min_trigger,
            "trigger_ready": trigger_ready,
            "structure_quality": structure_rank.get(structure_quality, -1) >= structure_rank.get(minimum_structure, 1),
            "auction_direction": auction_direction == target_side,
            "auction_confidence": auction_confidence >= min_auction,
            "qualified_opposition": len(opponents) <= max_opposition,
        }
        if smc_map and all(path4_checks.values()):
            return {
                **common,
                "allow": True,
                "path": "SMC_MAP_AUCTION_CONFIRMATION",
                # The map is evidence, never a sixth vote and never an SMC
                # confidence. ``supporters`` remains the real core vote book.
                "smc_map_counted_as_vote": False,
                "smc_map_id": smc_map.get("id"),
                "smc_map_state_key": smc_map.get("state_key"),
                "smc_map_entry_price": smc_map.get("entry_price"),
                "smc_map_direction": map_direction,
                "smc_map_quality": round(map_quality, 1),
                "smc_return_probability": round(return_probability, 1),
                "smc_dominance": round(dominance, 1),
                "smc_trigger_score": round(trigger_score, 1),
                "smc_trigger_ready": trigger_ready,
                "smc_structure_quality": structure_quality,
                "auction_direction": auction_direction,
                "auction_confidence": round(auction_confidence, 1),
                "path4_checks": path4_checks,
                "order_policy": "LIMIT_ONLY_AT_SMC_POI",
                "reason": (
                    f"SMC conditional {target_side} map confirmed by Auction Flow "
                    f"{auction_confidence:.1f}%; quality={map_quality:.1f}, "
                    f"return={return_probability:.1f}, dominance={dominance:.1f}, "
                    f"trigger={trigger_score:.1f}, opposition={len(opponents)}"
                ),
            }

    if common.get("family_diversity_blocked"):
        extra = ("; all-trend books accept only: "
                 + (",".join(_single_family_confirmers(config)) or "none"))
        if common.get("single_family_confirmer_refused"):
            extra += (f"; {common['single_family_confirmer_refused']} "
                      "confirmation refused by Rule A")
        if common.get("path5_family_refused"):
            extra += "; auction cannot confirm an all-trend book (Rule B)"
        return {
            **common, "allow": False, "path": None,
            "reason": (
                f"{target_side} blocked by family diversity: "
                f"{common.get('family_diversity_reason')} "
                f"(support={len(supporters)}, net={confidence:.1f}%, "
                f"no admissible external confirmation{extra})"
            ),
        }
    if common.get("path5_family_refused"):
        return {
            **common, "allow": False, "path": None,
            "reason": (
                f"{target_side} refused: auction cannot confirm an all-trend "
                f"pair (Rule B; support={len(supporters)}, net={confidence:.1f}%)"
            ),
        }
    return {
        **common, "allow": False, "path": None,
        "reason": (
            f"{target_side} admission failed: support={len(supporters)}, "
            f"opposition={len(opponents)}, net={confidence:.1f}%"
        ),
    }
