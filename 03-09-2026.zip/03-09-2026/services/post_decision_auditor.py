# -*- coding: utf-8 -*-
"""Post-decision compliance auditor (R26.3, operator order 2026-08-31).

PURPOSE
-------
An OBSERVATIONAL agent that runs AFTER the Decision Agent has admitted a trade.
It does NOT block, veto, change numbers, or return a refusal -- ever. It only
asks one question: *did this admitted trade actually satisfy every rule as
designed* (agent book, map/POI, path mandates, stop/R:R/$-risk laws, macro
coherence, no voting-authority violations)?  Every deviation it finds becomes a
WARN finding; helpful context becomes INFO; everything else is silent.

Findings go to:
  * storage/trade_compliance_audit.jsonl   (durable, one JSON row per audit)
  * a Telegram alert (WARN only, rate-limited) so the operator can open the
    code/config and fix the root cause.

DESIGN CONSTRAINTS (hard)
-------------------------
* Pure stdlib + the system's own single-source modules (never invents numbers).
* Fail-open: any internal error -> a single "auditor unavailable" INFO and no
  findings; it must never crash or delay the trading cycle.
* Never vetoes -- the caller ignores the return for flow control.
* Reads the SAME thresholds the trading code uses (config_for_instrument,
  trading_rules.stop_rule, lot solver, thesis admission, discipline gates).
"""
from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, List, Optional

try:  # all imports defensive: the auditor must never break the cycle
    from utils.instruments import price_to_points
except Exception:  # noqa: BLE001
    def price_to_points(*_a, **_k):  # type: ignore
        return 0.0

WARN, INFO, OK = "WARN", "INFO", "OK"


# ───────────────────────────────────────────────────────────────────────────
# small helpers (all defensive)
# ───────────────────────────────────────────────────────────────────────────
def _f(v: Any, d: float = 0.0) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return d


def _side(decision: Dict[str, Any]) -> str:
    s = str(decision.get("decision")
            or (decision.get("signal") or {}).get("type") or "").upper()
    return s if s in {"BUY", "SELL"} else ""


def _path(decision: Dict[str, Any]) -> str:
    return str(decision.get("execution_path_id")
               or (decision.get("signal") or {}).get("execution_path_id") or "").upper()


def _cfg_for_symbol(config: Dict[str, Any], symbol: str) -> Dict[str, Any]:
    try:
        from utils.instruments import config_for_instrument, enabled_instruments
        for inst in enabled_instruments(config):
            if str(inst.get("symbol")) == symbol:
                return config_for_instrument(config, inst)
    except Exception:  # noqa: BLE001
        pass
    return config


def _stop_law(icfg: Dict[str, Any], symbol: str = "") -> Dict[str, float]:
    # Read through the single-source PER-SYMBOL loader only (R26.6); the
    # loader's dict order is noise, buffer, cap (+ enabled). We do NOT name the
    # rule keys here (the one-source guard forbids re-reading them outside
    # utils/trading_rules.py). Passing the symbol is mandatory: without it the
    # base (gold) band would wrongly flag valid 486-720pt forex stops.
    try:
        import utils.trading_rules as _tr
        sym = symbol or icfg.get("symbol") or ""
        rule = (_tr.stop_rule_for_symbol(icfg, sym) if sym
                else _tr.stop_rule(icfg)) or {}
        nums = [v for k, v in rule.items() if k != "enabled"]
        nums = [_f(v) for v in nums]
        while len(nums) < 3:
            nums.append(0.0)
        return {"noise": nums[0], "buffer": nums[1], "cap": nums[2]}
    except Exception:  # noqa: BLE001
        return {"noise": 0.0, "buffer": 0.0, "cap": 0.0}


def _agent_book(decision: Dict[str, Any], all_results: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Best-effort agent book from whatever the decision/snapshot carries."""
    for src in (all_results, decision.get("agent_details"), decision.get("results"),
                (decision.get("signal_snapshot") or {}).get("agent_details")):
        if isinstance(src, dict) and src:
            return src
    return {}


def _dir_of(detail: Any) -> str:
    if not isinstance(detail, dict):
        return ""
    d = str(detail.get("direction") or detail.get("signal") or detail.get("bias")
            or detail.get("trade_bias") or "").upper()
    if "BUY" in d or "BULL" in d:
        return "BUY"
    if "SELL" in d or "BEAR" in d:
        return "SELL"
    return ""


def _macro_read(decision, all_results, config=None):
    """The routed fundamental macro verdict for THIS symbol - delegated to
    the single source (services.macro_voice) so the auditor, the hard veto
    and the exit-mirror veto can never disagree (R26.9). Returns
    {side: BUY|SELL|'', conf}."""
    try:
        from services.macro_voice import macro_voice
        v = macro_voice(decision, all_results, config)
        return {"side": v.get("side") or "", "conf": float(v.get("conf") or 0.0)}
    except Exception:  # noqa: BLE001 - auditor must never break the cycle
        return {"side": "", "conf": 0.0}


# ───────────────────────────────────────────────────────────────────────────
# the audit
# ───────────────────────────────────────────────────────────────────────────
def audit_decision(decision: Dict[str, Any], config: Dict[str, Any],
                   all_results: Optional[Dict[str, Any]] = None,
                   open_trades: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Return {symbol, side, path, trade_id, findings:[{severity,code,msg}], ok}.

    Never raises (a raised exception in the caller would be a design violation
    of "the auditor does not interfere")."""
    findings: List[Dict[str, str]] = []

    def warn(code: str, msg: str) -> None:
        findings.append({"severity": WARN, "code": code, "msg": msg})

    def info(code: str, msg: str) -> None:
        findings.append({"severity": INFO, "code": code, "msg": msg})

    try:
        d = decision if isinstance(decision, dict) else {}
        side = _side(d)
        symbol = str(d.get("symbol") or config.get("symbol") or "")
        path = _path(d)
        icfg = _cfg_for_symbol(config, symbol)
        signal = d.get("signal") if isinstance(d.get("signal"), dict) else {}
        entry = _f((signal.get("entry") or {}).get("price")) or _f(d.get("current_price"))
        stop = _f(signal.get("stop_loss"))
        tp1 = _f(signal.get("tp1"))
        tp2 = _f(signal.get("tp2"))
        lot = _f(signal.get("lot") or signal.get("volume") or d.get("lot"))

        # 0) attribution -----------------------------------------------------
        if not path:
            warn("PATH_MISSING", "صفقة بلا execution_path_id — لا يمكن إثبات مسار دخولها")

        # 1) macro coherence -------------------------------------------------
        macro = _macro_read(d, all_results, config)
        mfloor = _f(((config.get("discipline_gates") or {}).get("macro_block_conf")), 55.0)
        if macro["side"] and side and macro["side"] != side and macro["conf"] >= mfloor:
            if "PATH_9" in path or "SCALP" in path:
                info("MACRO_OPPOSES_EXEMPT",
                     f"الماكرو {macro['side']} {macro['conf']:.0f}% عكس الصفقة لكن المسار مستثنى "
                     f"({path or 'exempt'}) — راقب: الانعكاس يحتاج تأكيده كاملًا")
            else:
                warn("MACRO_OPPOSES",
                     f"الماكرو {macro['side']} بثقة {macro['conf']:.0f}% (≥{mfloor:.0f}) عكس اتجاه "
                     f"الصفقة {side} على مسار غير مستثنى — كان يُفترض أن يمنعها الفيتو")

        # 2) agent-book compliance vs thesis admission ----------------------
        adm: Dict[str, Any] = {}
        try:
            from services.thesis_consensus import evaluate_directional_admission
            book = _agent_book(d, all_results)
            if book and side:
                adm = evaluate_directional_admission(side, book, config,
                                                     symbol=symbol) or {}
                if adm.get("available") and adm.get("allow") is False and "PATH_4" not in path:
                    # informational only: an admitted trade that the raw core
                    # book would not have passed relies on a map/path route.
                    info("ADMISSION_BOOK",
                         f"قواعد القبول الأساسية لم تكن لتسمح وحدها ({str(adm.get('reason'))[:120]}) — "
                         f"اعتمدت الصفقة على مسار/خريطة؛ راجع توافق الوكلاء")
        except Exception:  # noqa: BLE001
            pass

        # 2b) auction must never be a core VOTER. Its mere presence in the
        # book is normal (PATH 4/5 use it as a confirmer); it only becomes a
        # violation if the canonical admission actually counted it as a
        # SUPPORTER on a non-auction path. (Auction joins voters only when
        # auction_promotion is enabled; default off.)
        try:
            supporters = adm.get("supporters") or []
            if "auction_flow" in supporters and "PATH_5" not in path and "PATH_4" not in path:
                warn("AUCTION_AS_VOTER",
                     "الأوكشن فلو حُسب ضمن مؤيّدي القبول على مسار غير 4/5 — الأوكشن مؤكِّد لا ناخب")
        except Exception:  # noqa: BLE001
            pass

        # 3) setup/direction coherence --------------------------------------
        setup = str(d.get("setup_type")
                    or (d.get("planner_execution_gate") or {}).get("setup_type") or "").upper()
        try:
            book = _agent_book(d, all_results)
            mtf = book.get("multitimeframe") or book.get("mtf") or {}
            mtf_side = _dir_of(mtf)
            mtf_conf = _f(mtf.get("confidence"))
            if "CONTINUATION_BREAKDOWN" in setup and mtf_side and mtf_side != side and mtf_conf >= 65:
                warn("SETUP_DIRECTION_CONTRADICTION",
                     f"النمط {setup} استمرار {mtf_side} لكن الأمر {side} — استمرار عكس الترند")
        except Exception:  # noqa: BLE001
            pass

        # 4) stop band law ---------------------------------------------------
        # A small tolerance covers the difference between the planner's entry
        # price (used here) and the live tick the executor (mt5_executor,
        # R25.7-E) actually clamped the stop against: a MARKET fill a few
        # points away from the planned entry can read 1-3 points over the cap
        # even though the executor's own band clamp was satisfied. Real
        # violations are dozens of points out (legacy stops at 100-330 forex),
        # so a 5-point margin never hides one.
        _BAND_TOLERANCE_PTS = 5.0
        law = _stop_law(icfg, symbol)
        if entry > 0 and stop > 0 and law["cap"] > 0:
            stop_pts = abs(price_to_points(entry - stop, symbol=symbol, config=icfg))
            floor = law["noise"] + law["buffer"]
            if stop_pts > law["cap"] + _BAND_TOLERANCE_PTS or stop_pts < floor - _BAND_TOLERANCE_PTS:
                warn("STOP_OUT_OF_BAND",
                     f"الوقف {stop_pts:.0f} نقطة خارج نطاق الرمز [{floor:.0f}, {law['cap']:.0f}]")

        # 5) R:R law ---------------------------------------------------------
        if entry > 0 and stop > 0:
            risk_pts = abs(price_to_points(entry - stop, symbol=symbol, config=icfg))
            if risk_pts > 0:
                if tp1 > 0:
                    rr1 = abs(price_to_points(tp1 - entry, symbol=symbol, config=icfg)) / risk_pts
                    if rr1 < 0.8 - 1e-9:
                        warn("RR1_TOO_LOW", f"هدف 1 = {rr1:.2f}R تحت أرضية 0.8R")
                else:
                    warn("TP1_MISSING", "لا يوجد هدف أول (tp1)")
                if tp2 > 0:
                    rr2 = abs(price_to_points(tp2 - entry, symbol=symbol, config=icfg)) / risk_pts
                    if rr2 < 1.5 - 1e-9:
                        warn("RR2_TOO_LOW", f"هدف 2 = {rr2:.2f}R تحت 1.5R")
                else:
                    info("TP2_MISSING", "لا يوجد هدف ثانٍ (tp2)")

        # 6) $ risk band (lot solved for the stop) --------------------------
        if lot > 0 and entry > 0 and stop > 0:
            try:
                from services.risk_usd import usd_per_point
                px = entry
                loss = lot * usd_per_point(symbol, 1.0, px) * abs(
                    price_to_points(entry - stop, symbol=symbol, config=icfg))
                if not (260.0 <= loss <= 430.0):
                    warn("DOLLAR_RISK", f"خسارة الوقف المحسوبة ≈ {loss:.0f}$ خارج نطاق 270–400$")
            except Exception:  # noqa: BLE001
                pass

        # 7) PATH 4 (SMC map) mandates --------------------------------------
        if "PATH_4" in path:
            if str(signal.get("order_type") or "").upper().find("LIMIT") < 0 and \
               str(signal.get("order_type") or "").upper() != "BUY_LIMIT" and \
               str(signal.get("order_type") or "").upper() != "SELL_LIMIT":
                warn("PATH4_NOT_LIMIT", "المسار 4 يسمح بأمر LIMIT عند POI فقط (لا MARKET)")
            poiprice = _f((d.get("planner_execution_gate") or {}).get("smc_map_entry_price"))
            if poiprice > 0 and entry > 0 and abs(entry - poiprice) > 0.011:
                warn("PATH4_ENTRY_OFF_POI",
                     f"دخول المسار 4 {entry:.2f} يبعد عن POI المؤكَّد {poiprice:.2f}")
            # auction confirmation
            book = _agent_book(d, all_results)
            af = book.get("auction_flow") if isinstance(book, dict) else None
            if not (isinstance(af, dict) and _f(af.get("weight"), -1) > 0
                    and _dir_of(af) in {"BUY", "SELL"}):
                warn("PATH4_NO_AUCTION", "المسار 4 يحتاج تأكيد مزاد (وزن + اتجاه) ولم يُرصد")

        # 8) PATH 9 auction witness -----------------------------------------
        if "PATH_9" in path:
            book = _agent_book(d, all_results)
            af = book.get("auction_flow") if isinstance(book, dict) else None
            if not (isinstance(af, dict) and _dir_of(af) in {"BUY", "SELL"}
                    and str(af.get("state") or "").upper().find("REFUS") < 0):
                warn("PATH9_NO_WITNESS", "المسار 9 يتطلب شاهد مزاد مؤهَّل ولم يُرصد")

        # 9) duplicate / close-zone entry ------------------------------------
        try:
            dup = _f(icfg.get("duplicate_zone_points"), 150.0)
            for t in (open_trades or []):
                if str(t.get("symbol")) != symbol:
                    continue
                tsig = t.get("signal") or (t.get("signal_snapshot") or {}).get("signal") or {}
                te = _f(tsig.get("entry_price") or tsig.get("entry") or t.get("entry_price"))
                tside = str(t.get("type") or t.get("side") or "").upper()
                if te > 0 and entry > 0 and abs(price_to_points(entry - te, symbol=symbol, config=icfg)) < dup:
                    warn("DUPLICATE_ZONE",
                         f"صفقة {tside or '?'} قائمة على بُعد "
                         f"{abs(price_to_points(entry-te, symbol=symbol, config=icfg)):.0f} نقطة < {dup:.0f} (منطقة تكرار)")
                    break
        except Exception:  # noqa: BLE001
            pass

        # 10) discipline gate cross-check (non-blocking) -- surface ONLY gate
        # failures not already covered by the dedicated checks above (stop band
        # / R:R are checked directly; macro & setup-contradiction already have
        # their own findings), so an admitted trade that still trips a gate is
        # visible without duplicate warnings.
        try:
            from services.admission_discipline_gates import discipline_violations
            for v in discipline_violations(d, config, all_results):
                low = v.lower()
                if "macro veto" in low or "counter-macro" in low or "contradiction" in low:
                    continue  # already flagged as MACRO_OPPOSES / SETUP_DIRECTION
                warn("GATE_VIOLATION", str(v)[:160])
        except Exception:  # noqa: BLE001
            pass

    except Exception as exc:  # noqa: BLE001 - auditor must never break the cycle
        return {"ok": True, "findings": [{"severity": INFO, "code": "AUDITOR_UNAVAILABLE",
                                          "msg": f"auditor skipped: {type(exc).__name__}"}],
                "warnings": 0}

    warns = [f for f in findings if f["severity"] == WARN]
    return {"ok": True, "findings": findings, "warnings": len(warns)}


# ───────────────────────────────────────────────────────────────────────────
# persistence + telegram (best-effort)
# ───────────────────────────────────────────────────────────────────────────
def _audit_path(root: str) -> str:
    return os.path.join(root, "storage", "trade_compliance_audit.jsonl")


def record_and_alert(decision: Dict[str, Any], config: Dict[str, Any], *,
                     all_results: Optional[Dict[str, Any]] = None,
                     open_trades: Optional[List[Dict[str, Any]]] = None,
                     telegram: Any = None, root: str = ".",
                     stage: str = "post_decision") -> Dict[str, Any]:
    """Run the audit, append a JSONL row, and (WARN only) send one Telegram
    alert. Always returns the verdict; never raises into the trading loop."""
    try:
        verdict = audit_decision(decision, config, all_results, open_trades)
        row = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "stage": stage,
            "symbol": str(decision.get("symbol") or config.get("symbol") or ""),
            "side": _side(decision), "path": _path(decision),
            "trade_id": decision.get("trade_id"),
            "warnings": verdict.get("warnings", 0),
            "findings": verdict.get("findings", []),
        }
        try:
            if not root:
                root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            os.makedirs(os.path.join(root, "storage"), exist_ok=True)
            with open(_audit_path(root), "a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")
        except Exception:  # noqa: BLE001
            pass

        warns = [f for f in verdict.get("findings", []) if f["severity"] == WARN]
        if warns and telegram is not None:
            try:
                lines = ["🛡️ تدقيق ما بعد القرار — تحذيرات تحتاج مراجعة:",
                         f"{row['symbol']} {row['side']} ({row['path'] or 'بلا مسار'})"]
                for f in warns[:8]:
                    lines.append(f"• [{f['code']}] {f['msg']}")
                lines.append("(تحذير مرصِد فقط — لم تُمنع الصفقة؛ راجع وأصلح السبب)")
                telegram.send_message("\n".join(lines), urgent=False)
            except Exception:  # noqa: BLE001
                pass
        return verdict
    except Exception:  # noqa: BLE001
        return {"ok": True, "findings": [], "warnings": 0}
