# -*- coding: utf-8 -*-
"""
DIAGNOSE_ALL.py — فحص شامل وقراءة-فقط لنظام نابيل (ذهب/نفط/فوركس).

التشغيل من جذر المشروع (حيث يوجد مجلد storage و config.json):
    python DIAGNOSE_ALL.py

السكربت لا يُعدّل أي شيء إطلاقًا — يقرأ فقط، ويكتب تقريره الخاص في:
    diagnostics/full_check_YYYYMMDD_HHMMSS.txt  و  .json

يفحص:
  1) المفاتيح/الإعدادات الحاكمة (المبدّل، المسار 9، الأوكشن، السكالب، البطاقات...).
  2) مخزن تيكات المزاد لكل رمز (هل يقرأ تغذية رمز آخر؟ هل المتجر فارغ/قديم؟).
  3) ليدجر الصفقات (storage/trades.json + path_performance): ربح/خسارة/تعادل،
     لكل رمز ولكل مسار/استراتيجية، مع تحليل سبب كل خسارة.
  4) فحوص صحية على كل صفقة: ستوب خارج النطاق المطلق، R:R، عكس الماكرو،
     صفقة بلا شاهد مزاد، تكرار/مطاردة.
  5) تطابق جاهزية الخرائط وحالة بوابات العائلتين.

أي قسم يفشل في بيئة ما (مثل غياب ملف) يُسجَّل بوضوح ولا يُسقط البقية.
"""
from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

STORAGE = ROOT / "storage"
DIAG = ROOT / "diagnostics"
DIAG.mkdir(exist_ok=True)

NOW = datetime.now(timezone.utc)
STAMP = NOW.strftime("%Y%m%d_%H%M%S")
REPORT_TXT = DIAG / f"full_check_{STAMP}.txt"
REPORT_JSON = DIAG / f"full_check_{STAMP}.json"

LINES: list[str] = []
FINDINGS: list[dict] = []   # {level, code, msg}


def out(line: str = "") -> None:
    LINES.append(line)


def finding(level: str, code: str, msg: str) -> None:
    FINDINGS.append({"level": level, "code": code, "msg": msg})
    mark = {"CRIT": "🔴 حرج", "WARN": "🟡 تنبيه", "OK": "🟢 سليم",
            "INFO": "ℹ️  معلومة"}.get(level, "ℹ️")
    out(f"  {mark} [{code}] {msg}")


def hr(title: str) -> None:
    out("")
    out("=" * 74)
    out(title)
    out("=" * 74)


def _safe(default):
    def deco(fn):
        def wrap(*a, **k):
            try:
                return fn(*a, **k)
            except Exception as exc:  # noqa: BLE001
                finding("WARN", "SECTION_ERROR",
                        f"تعذّر قسم {fn.__name__}: {type(exc).__name__}: {exc}")
                return default
        wrap.__name__ = fn.__name__
        return wrap
    return deco


# ── project helpers (imported; read-only) ──────────────────────────────────
def load_config():
    try:
        from utils.helpers import load_config
        return load_config()
    except Exception:
        with (ROOT / "config.json").open("r", encoding="utf-8") as fh:
            return json.load(fh)


def inst_helpers():
    h = {}
    try:
        from utils import instruments as I
        h["normalize_symbol"] = I.normalize_symbol
        h["point_size"] = I.point_size
        h["price_to_points"] = I.price_to_points
        h["price_sanity_range"] = I.price_sanity_range
        h["enabled_instruments"] = I.enabled_instruments
    except Exception as exc:  # noqa: BLE001
        finding("WARN", "IMPORT_INSTRUMENTS", f"تعذّر استيراد utils.instruments: {exc}")
    return h


# ── 1) config switches ─────────────────────────────────────────────────────
@_safe(None)
def section_config(cfg):
    hr("1) حالة المفاتيح الحاكمة في config.json")
    def g(path, default=None):
        cur = cfg
        for key in path.split("."):
            if not isinstance(cur, dict):
                return default
            cur = cur.get(key, default)
        return cur
    checks = [
        ("regime_switcher.enabled", True, "المبدّل المركزي يعمل"),
        ("regime_switcher.enforce", False, "المبدّل استشاري (enforce=false) — لا يحجب"),
        ("regime_switcher.announce_on_telegram", True, "رأي المبدّل يظهر في تيليجرام"),
        ("path9_reversal.enabled", True, "المسار 9 (اقتناص السيولة) حي"),
        ("path9_reversal.require_flow_witness", True, "شاهد المزاد إلزامي للمسار 9"),
        ("reflection_agent.enabled", True, "وكيل التأمل/الذاكرة حي"),
        ("regime_state_machine.enabled", True, "آلة حالة الأنظمة حية"),
        ("auction_promotion.enabled", False, "الأوكشن ليس ناخبًا (يبقى مؤكِّدًا فقط)"),
        ("session_plan_delivery.armed_map_watch.enabled", False, "بطاقة الخريطة المسلّحة مطفأة"),
        ("session_plan_delivery.monitoring_only.enabled", False, "بطاقات المراقبة WATCH مطفأة"),
        ("r25_scalp.enabled", True, "سكالب R25-2 مفعّل"),
    ]
    for path, expected, label in checks:
        val = g(path)
        ok = (val == expected)
        finding("OK" if ok else "WARN", f"CFG:{path}",
                f"{label}: {val} (المتوقع {expected}) {'✓' if ok else '✗'}")
    mode = g("r25_scalp.mode")
    finding("OK" if str(mode).lower() == "live" else "WARN", "CFG:scalp_mode",
            f"وضع السكالب = {mode} (المتوقع live)")
    near = g("near_miss_execution.enabled")
    if near is not None:
        finding("OK" if near is False else "WARN", "CFG:near_miss",
                f"near_miss_execution.enabled = {near} (المتوقع False)")


# ── 2) auction tick stores per symbol ─────────────────────────────────────
@_safe(None)
def section_auction_stores(cfg, H):
    hr("2) مخازن تيكات المزاد (Auction Flow) لكل رمز — فحص عميق للصفوف")
    import sqlite3
    if "enabled_instruments" not in H:
        finding("WARN", "AUCTION:NO_HELPERS", "تعذّر فحص المخازن (دوال الرموز غير متاحة)")
        return
    norm = H["normalize_symbol"]
    sanity = H.get("price_sanity_range")
    enabled = H["enabled_instruments"](cfg)
    symbols = [norm(str(i.get("symbol"))) for i in enabled if isinstance(i, dict)]
    if "XAU/USD" not in symbols:
        symbols.insert(0, "XAU/USD")
    out(f"  الرموز المفعّلة: {', '.join(symbols)}")
    now_ts = NOW.timestamp()
    for sym in symbols:
        stem = sym.replace("/", "").lower()
        fname = "auction_flow.sqlite3" if sym == "XAU/USD" else f"auction_flow_{stem}.sqlite3"
        path = STORAGE / fname
        calib = STORAGE / "model_calibration" / (
            "auction_flow_v1.json" if sym == "XAU/USD"
            else f"auction_flow_v1_{stem}.json")
        calib_ok = calib.exists()
        if not path.exists():
            out(f"  • {sym:8s} {fname} — ❌ غير موجود")
            finding("WARN", "AUCTION:NO_STORE",
                    f"{sym}: لا يوجد مخزن تيكات خاص به → المزاد WAIT دائمًا (المسار 4/5/9 بلا شاهد لهذا الرمز)")
            continue
        size = path.stat().st_size
        lo = hi = None
        if sanity is not None:
            try:
                lo, hi = sanity(sym, cfg)
            except Exception:
                lo = hi = None
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        meta = dict(con.execute("SELECT key,value FROM meta").fetchall())
        last_mid = None
        try:
            last_mid = float(str(meta.get("last_mid")).strip("'"))
        except Exception:
            last_mid = None
        # الطزاجة الحقيقية: لحظة كتابة آخر تيك (UTC) وليس ts الصفوف (وقت المزوّد +إزاحة)
        write_age = tick_age = None
        try:
            write_age = now_ts - float(meta.get("last_write_ts"))
        except Exception:
            pass
        try:
            tick_age = now_ts - float(meta.get("last_tick_ts_ms")) / 1000.0
        except Exception:
            pass
        store_sym = meta.get("symbol", "")
        # فحص الصفوف نفسها: شموع دقائق آخر 7 أيام
        bad_rows = 0
        total_rows = 0
        bad_example = None
        foreign_max = 0.0
        try:
            rows = con.execute(
                "SELECT ts,close_mid,high_mid,low_mid FROM minutes WHERE ts>=?",
                (int(now_ts) - 7 * 86400,)).fetchall()
            total_rows = len(rows)
            for ts, cm, hm, lm in rows:
                worst = cm
                if lo is not None:
                    if not (lo <= cm <= hi):
                        bad_rows += 1
                        if bad_example is None:
                            bad_example = (ts, cm)
                        if abs(cm) > foreign_max:
                            foreign_max = abs(cm)
        except Exception as exc:  # noqa: BLE001
            out(f"  • {sym:8s} تعذّر فحص الصفوف: {exc}")
        con.close()
        wa = f"{write_age/3600:.1f}س" if write_age is not None else "؟"
        out(f"  • {sym:8s} {fname} حجم={size}B last_mid={last_mid} "
            f"عمر_آخر_كتابة={wa} رمز_المتجر='{store_sym}' "
            f"شموع_7أيام={total_rows} خارج_النطاق={bad_rows} معايرة={calib_ok}")
        if not calib_ok:
            finding("WARN", "AUCTION:NO_CALIB",
                    f"{sym}: لا توجد معايرة مزاد → الوكيل قد ينتظر CALIBRATION_INVALID")
        if write_age is not None and write_age > 3600:
            finding("WARN", "AUCTION:STALE",
                    f"{sym}: آخر كتابة تيك قبل {write_age/3600:.1f} ساعة → التغذية لا تصل لهذا الرمز الآن")
        if store_sym and store_sym != sym:
            finding("CRIT", "AUCTION:WRONG_SYMBOL_META",
                    f"{fname}: ميتا 'symbol'='{store_sym}' بينما المتجر خاص بـ {sym} → المتجر أُنشئ بتغذية رمز آخر")
        if last_mid is not None and lo is not None and not (lo <= last_mid <= hi):
            finding("CRIT", "AUCTION:FOREIGN_FEED_META",
                    f"{sym}: last_mid={last_mid} خارج نطاقه [{lo:.4f},{hi:.4f}] → تغذية رمز آخر في الميتا")
        if bad_rows > 0:
            finding("CRIT", "AUCTION:FOREIGN_FEED_ROWS",
                    f"{sym}: {bad_rows} من {total_rows} شمعة دقائق (آخر 7 أيام) أسعارها خارج نطاق الرمز "
                    f"[{lo:.4f},{hi:.4f}] — مثال close_mid={bad_example[1]:.3f} → صفوف ملوّثة بتغذية رمز آخر "
                    f"يجب تنظيفها (تفسير FOREIGN_FEED_REFUSED)")


# ── 3+4) trades ledger ────────────────────────────────────────────────────
OUTCOME_KEYS = {"WIN": "ربح", "LOSS": "خسارة", "BREAKEVEN": "تعادل",
                "CANCELLED": "ملغاة", "OPEN": "مفتوحة", "PENDING": "معلّقة"}


@_safe(None)
def section_trades(cfg, H):
    hr("3) ليدجر الصفقات وتحليل الخسائر")
    trades = _load_trades()
    if trades is None:
        finding("WARN", "TRADES:NONE",
                "لا يوجد storage/trades.json محليًا. إن كانت الصفقات في Supabase "
                "صدّرها (أو شغّل السكربت على VPS حيث الوصول للقاعدة).")
        return
    out(f"  إجمالي الصفوف المقروءة: {len(trades)}")

    def pnl_of(t):
        for k in ("final_pnl", "current_pnl"):
            v = t.get(k)
            if v is not None:
                try:
                    return float(v)
                except (TypeError, ValueError):
                    pass
        return 0.0

    def outcome(t):
        st = str(t.get("status", "")).upper()
        if st in {"OPEN", "PARTIAL", "TP1_HIT"}:
            return "OPEN"
        if st == "PENDING":
            return "PENDING"
        if st in {"CANCELLED", "REJECTED", "EXPIRED"} and pnl_of(t) == 0:
            return "CANCELLED"
        res = str(t.get("result", "")).upper()
        if res in {"WIN", "LOSS", "BREAKEVEN", "BE"}:
            return "BREAKEVEN" if res in {"BREAKEVEN", "BE"} else res
        pnl = pnl_of(t)
        if pnl > 0:
            return "WIN"
        if pnl < 0:
            return "LOSS"
        return "BREAKEVEN"

    from collections import defaultdict
    by_outcome = defaultdict(list)
    by_symbol = defaultdict(lambda: defaultdict(int))
    by_path = defaultdict(lambda: defaultdict(int))
    pnl_path = defaultdict(float)
    pnl_symbol = defaultdict(float)
    missing_path = 0
    for t in trades:
        oc = outcome(t)
        by_outcome[oc].append(t)
        sym = H.get("normalize_symbol", lambda x: x)(str(t.get("symbol") or "?")) if H else str(t.get("symbol") or "?")
        by_symbol[sym][oc] += 1
        pnl_symbol[sym] += pnl_of(t)
        path = str(t.get("execution_path_id") or "").strip()
        if not path:
            missing_path += 1
            path = "(بدون مسار)"
        by_path[path][oc] += 1
        pnl_path[path] += pnl_of(t)

    out("\n  -- النتيجة الإجمالية --")
    for oc in ("WIN", "LOSS", "BREAKEVEN", "CANCELLED", "OPEN", "PENDING"):
        out(f"     {OUTCOME_KEYS.get(oc, oc):8s}: {len(by_outcome[oc])}")
    closed = len(by_outcome["WIN"]) + len(by_outcome["LOSS"]) + len(by_outcome["BREAKEVEN"])
    total_pnl = sum(pnl_of(t) for t in trades)
    win_pnl = sum(pnl_of(t) for t in by_outcome["WIN"])
    loss_pnl = sum(pnl_of(t) for t in by_outcome["LOSS"])
    if closed:
        wr = 100.0 * len(by_outcome["WIN"]) / closed
        out(f"     نسبة الربح (مغلقة): {wr:.1f}%  (ربح {len(by_outcome['WIN'])} / خسارة {len(by_outcome['LOSS'])} / تعادل {len(by_outcome['BREAKEVEN'])})")
    out(f"     إجمالي PnL بالدولار: {total_pnl:.2f}  (أرباح {win_pnl:.2f} / خسائر {loss_pnl:.2f})")
    if loss_pnl < 0 and win_pnl > 0:
        out(f"     عامل الربح PF: {win_pnl / abs(loss_pnl):.2f}  | متوسط الربح {win_pnl/max(1,len(by_outcome['WIN'])):.2f} "
            f"مقابل متوسط الخسارة {loss_pnl/max(1,len(by_outcome['LOSS'])):.2f}")

    out("\n  -- لكل رمز (PnL $) --")
    for sym, d in sorted(by_symbol.items()):
        out(f"     {sym:9s} ربح={d['WIN']} خسارة={d['LOSS']} تعادل={d['BREAKEVEN']} "
            f"إلغاء={d['CANCELLED']} | PnL={pnl_symbol[sym]:.2f}$")

    out("\n  -- لكل مسار (PnL $) --")
    for path, d in sorted(by_path.items()):
        out(f"     {path:42s} ربح={d['WIN']} خسارة={d['LOSS']} تعادل={d['BREAKEVEN']} "
            f"إلغاء={d['CANCELLED']} | PnL={pnl_path[path]:.2f}$")
    if missing_path:
        finding("WARN", "TRADES:NO_PATH",
                f"{missing_path} صفقة بلا execution_path_id — قياس أداء المسارات ناقص لها")

    be_exits = defaultdict(int)
    sl_moved = 0
    for t in by_outcome["BREAKEVEN"]:
        be_exits[str(t.get("status", "?"))] += 1
        if t.get("sl_moved_to_entry"):
            sl_moved += 1
    out(f"\n  -- صفقات التعادل ({len(by_outcome['BREAKEVEN'])}) حسب حالة الإغلاق: "
        f"{dict(be_exits)}؛ ستوب نُقل للدخول في {sl_moved} منها --")

    # detailed loss analysis
    hr("4) تحليل الصفقات الخاسرة (سبب محتمل لكل صفقة)")
    losses = by_outcome["LOSS"]
    out(f"  عدد الخسائر: {len(losses)}")
    point_size = H.get("point_size")
    p2pts = H.get("price_to_points")
    # R26.9.3 (2026-09-01): the band is PER SYMBOL from the single source
    # (stop_rule_for_symbol): gold [270,400], oil [135,200], FX ×1.8
    # [486,720]. The old hard-coded default (230,330) flagged LEGAL forex
    # stops (600) and passed ILLEGAL tight ones (USD/JPY 271 < 486).
    def _band_for(sym_name):
        try:
            from utils.trading_rules import stop_rule_for_symbol
            r = stop_rule_for_symbol(cfg, sym_name)
            return (r.get("min_liquidity_points", 0.0) + r.get("safety_buffer_points", 0.0),
                    r.get("max_stop_points", 0.0))
        except Exception:
            return (230.0, 330.0)
    loss_rows = []
    for t in losses:
        sym = H.get("normalize_symbol", lambda x: x)(str(t.get("symbol") or "?")) if H else str(t.get("symbol") or "?")
        entry = _f(t.get("entry_price"))
        stop = _f(t.get("stop_loss")) or _f(t.get("initial_stop_loss"))
        tp2 = _f(t.get("tp2"))
        side = str(t.get("type") or t.get("decision") or "?").upper()
        reasons = []
        if entry <= 0 or stop <= 0:
            reasons.append("⚠️ بيانات الدخول/الستوب غير محفوظة في الليدجر")
        if entry and stop and point_size and p2pts:
            try:
                pts = abs(p2pts(entry - stop, sym, cfg))
                lo, hi = _band_for(sym)
                if pts < lo - 1 or pts > hi + 1:
                    reasons.append(f"ستوب {pts:.0f}ن خارج النطاق [{lo:.0f},{hi:.0f}]")
            except Exception:
                pass
        if entry and stop and tp2 and abs(entry - stop) > 0:
            rr = abs(tp2 - entry) / abs(entry - stop)
            if rr < 1.49:
                reasons.append(f"R:R منخفض {rr:.2f}")
        try:
            macro = (t.get("news_context") or {}).get("macro") or {}
            md = macro.get("macro_direction") or {}
            bias = str(md.get("bias") or "").upper()
            mconf = _f(md.get("confidence"))
            macro_side = ("BUY" if ("BULLISH" in bias or bias == "BUY")
                          else "SELL" if ("BEARISH" in bias or bias == "SELL") else "")
            if macro_side and macro_side != side and mconf >= 70:
                reasons.append(f"عكس الماكرو ({bias} {mconf:.0f}%)")
        except Exception:
            pass
        pathid = str(t.get("execution_path_id") or "")
        if "PATH_9" in pathid:
            sig9 = t.get("signal") if isinstance(t.get("signal"), dict) else {}
            if not (sig9.get("path9") or {}).get("flow") and not t.get("flow_witness"):
                reasons.append("المسار 9 بلا توقيع شاهد المزاد")
        tid = t.get("id") or t.get("trade_id") or "?"
        out(f"  • {tid} {sym} {side} | دخول {entry} ستوب {stop} tp2 {tp2} | "
            f"PnL {pnl_of(t):.2f}$ | الحالة {t.get('status')} | المسار: {pathid or '(بدون)'}")
        out(f"      السبب/العلامات: {'; '.join(reasons) if reasons else 'لا علامة آلية — راجع الإدارة/الخبر/السبريد/توقيت الدخول'}")
        loss_rows.append({"id": tid, "symbol": sym, "side": side, "pnl": pnl_of(t),
                          "status": t.get("status"), "path": pathid,
                          "entry": entry, "stop": stop, "tp2": tp2, "flags": reasons})
        if not reasons:
            finding("INFO", "LOSS:NEEDS_REVIEW", f"{tid} {sym}: خسارة بلا مخالفة آلية")
        for r in reasons:
            code = "LOSS:DATA_MISSING" if r.startswith("⚠️") else "LOSS:FLAG"
            finding("WARN", code, f"{tid} {sym}: {r}")
    dump = DIAG / f"{REPORT_TXT.stem}_trades.json"
    dump.write_text(json.dumps(
        {"summary": {"wins": len(by_outcome["WIN"]), "losses": len(by_outcome["LOSS"]),
                     "breakeven": len(by_outcome["BREAKEVEN"]), "total_pnl": total_pnl},
         "losses": loss_rows,
         "trades": [{k: t.get(k) for k in (
             "id", "symbol", "type", "status", "result", "entry_price", "stop_loss",
             "initial_stop_loss", "tp1", "tp2", "final_pnl", "final_pnl_points",
             "current_pnl", "confidence", "execution_path_id", "order_kind",
             "entry_time", "closed_at", "sl_moved_to_entry", "news_context")}
             for t in trades]},
        ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    out(f"\n  📄 تفاصيل كل الصفقات حُفظت في: diagnostics/{dump.name}")


def _f(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _load_trades():
    candidates = [
        STORAGE / "trades.json",
        STORAGE / "path_performance" / "trades.json",
    ]
    for p in candidates:
        if p.exists():
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(data, list):
                    return data
                if isinstance(data, dict):
                    for key in ("trades", "rows", "data"):
                        if isinstance(data.get(key), list):
                            return data[key]
            except Exception as exc:  # noqa: BLE001
                finding("WARN", "TRADES:READ", f"تعذّر قراءة {p}: {exc}")
    return None


# ── 5) maps / misc files quick presence ───────────────────────────────────
@_safe(None)
def section_storage_presence():
    hr("5) ملفات التخزين الأساسية (حضور/حجم/آخر تعديل)")
    targets = [
        "decision_audit.json", "reflection_memory.json",
        "auction_flow.sqlite3", "hourly_status_last.json",
        "path_performance/trades.json", "trades.json",
        "macro_context.json",
    ]
    for rel in targets:
        p = STORAGE / rel
        if p.exists():
            age = (NOW - datetime.fromtimestamp(p.stat().st_mtime, timezone.utc))
            out(f"  • {rel:34s} موجود ({p.stat().st_size}B، آخر تعديل قبل {age.total_seconds()/3600:.1f} ساعة)")
            if rel == "reflection_memory.json":
                finding("OK", "REFLECTION:FILE", "ملف ذاكرة التأمل موجود (الوكيل يثابر بين الدورات)")
            if rel == "macro_context.json":
                # R26.9.3: الماكرو بلا بيانات طازجة = NEUTRAL: لا تأكيد
                # مسار 2 للفوركس ولا فيتو — يعمل النظام بلا عقل أساسيات.
                age_h = age.total_seconds() / 3600.0
                if age_h > 2.0:
                    finding("WARN", "MACRO:STALE_CONTEXT",
                            f"macro_context.json عمره {age_h:.1f} ساعة (>2) — مهمة "
                            "update_macro_context متوقفة على الأرجح: الماكرو يصدر "
                            "NEUTRAL (لا تأكيد ولا فيتو) حتى تجديدها")
                else:
                    finding("OK", "MACRO:CONTEXT_FRESH",
                            f"سياق الماكرو طازج ({age_h:.1f} ساعة) — التأكيد/الفيتو يعملان ببيانات حية")
        else:
            out(f"  • {rel:34s} غير موجود")
            if rel == "reflection_memory.json":
                finding("WARN", "REFLECTION:MISSING",
                        "وكيل التأمل مفعّل لكن storage/reflection_memory.json غير موجود — "
                        "إما أنه لم يكتب بعد، أو مسار الكتابة/الصلاحيات معطّل (ذاكرة لا تتراكم)")
            if rel == "macro_context.json":
                finding("WARN", "MACRO:NO_CONTEXT",
                        "storage/macro_context.json غير موجود — شغّل "
                        "scripts/update_macro_context.py كل ساعة وإلا بقي الماكرو NEUTRAL "
                        "(لا تأكيد مسار 2 ولا فيتو R26.2)")


def main():
    out("فحص نظام نابيل الشامل — تقرير قراءة-فقط")
    out(f"الجذر: {ROOT}")
    out(f"الوقت (UTC): {NOW.isoformat()}")
    cfg = load_config()
    H = inst_helpers()
    section_config(cfg)
    section_auction_stores(cfg, H)
    section_trades(cfg, H)
    section_storage_presence()

    hr("خلاصة النتائج")
    crits = [f for f in FINDINGS if f["level"] == "CRIT"]
    warns = [f for f in FINDINGS if f["level"] == "WARN"]
    oks = [f for f in FINDINGS if f["level"] == "OK"]
    out(f"🔴 حرج: {len(crits)}   🟡 تنبيه: {len(warns)}   🟢 سليم: {len(oks)}")
    if crits:
        out("\nأولويات الإصلاح (الحرج أولًا):")
        for f in crits:
            out(f"  - [{f['code']}] {f['msg']}")
    out("\nأرسل الملفين التاليين للمحلل:")
    out(f"  {REPORT_TXT}")
    out(f"  {REPORT_JSON}")

    REPORT_TXT.write_text("\n".join(LINES), encoding="utf-8")
    REPORT_JSON.write_text(json.dumps(
        {"generated_at": NOW.isoformat(), "root": str(ROOT),
         "findings": FINDINGS}, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n".join(LINES))
    print(f"\n✅ حُفظ التقرير:\n  {REPORT_TXT}\n  {REPORT_JSON}")


if __name__ == "__main__":
    try:
        main()
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        sys.exit(1)
