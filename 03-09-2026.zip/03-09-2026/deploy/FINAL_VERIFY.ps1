﻿$ErrorActionPreference = 'Continue'
$root = 'C:\Nabil-gold'
Write-Output '=============================================='
Write-Output 'FINAL OIL VERIFICATION  (read-only)'
Write-Output '=============================================='
Set-Location $root
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
& python scripts\final_verification.py --root $root
Write-Output ('EXIT=' + $LASTEXITCODE)
