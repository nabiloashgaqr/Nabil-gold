# -*- coding: utf-8 -*-
"""R26.9.3 + R26.9.5: merge the forex ×1.8 law AND the auction-calibration
lock into an EXISTING config.json.

The operator's production config.json may carry local tweaks (telegram ids,
supabase keys, risk numbers) - it must NEVER be overwritten wholesale. This
merge ONLY touches the keys below and leaves every other existing key
byte-identical:

  1. instruments[EUR/USD|GBP/USD|USD/CAD|USD/JPY].min_sl_distance_points
       -> 720 (was 900 under the retired ×2.25 law; added when absent).
     NOTE: the rest of the ×1.8 law (band 360/126/720, trailing 270/72,
     breakeven 270, post-TP2 450, planner zones) lives in the NEW
     utils/instruments.py you already copied - config's instruments rows
     carry no trading_rules block, so the merged defaults apply by design.
     Only min_sl_distance_points is READ from the config row (it overrides
     the code default), which is why exactly this key must be merged here.
  2. trading_rules.stop.description: the "الفوركس ×2.25 ..." sentence is
     rewritten to the ×1.8 law text (kept only when it still carries the
     retired ×2.25 wording; a custom text is left untouched with a notice).
  4. R26.9.11 (operator 2026-09-02: "الذهب الأساسي: تعزيز -150"): the gold
     law's add trigger is 150 points (documented in the repo config since
     2026-08-18). The server config carries a stale 270 — it is merged back
     to the law's 150 (the engine then scales it per symbol: gold 150 /
     WTI x0.5 = 75 / FX x1.8 = 270 = 27 pips).
  3. R26.9.5 (operator 2026-09-01: "اجعل كل شي true — المعايرة جاهزة
     ومقفلة لكل الأزواج"): instruments[EUR/USD|GBP/USD|USD/CAD|USD/JPY]
     .auction_flow.calibration_required -> true (block created when absent).
     Gold (root flag true) and WTI (already true) are untouched. The
     validated curves live on the server (diagnose_auction_agent showed
     "all checks passed" for all six), so this only LOCKS the strict path:
     a future missing/weak curve makes the agent WAIT (CALIBRATION_INVALID)
     instead of silently falling back to the uncalibrated linear mode.

Safety:
  * timestamped backup: config.backup_R26.9.5_<ts>.json next to the file.
  * idempotent: re-running makes no further changes (SKIP paths).
  * preflight: refuses to run when utils/instruments.py is still the OLD
    ×2.25 copy (max_stop_points 900) - merging 720 into the config while
    the code defaults say 900 would produce two disagreeing laws.
  * verification: after writing, the per-symbol law is resolved through
    the real loader (stop_rule_for_symbol) for all six symbols and must
    read gold [270,400], oil [135,200], FX [486,720], and all four FX
    rows must carry auction_flow.calibration_required=true - or the merge
    reports FAIL and restores the backup.

Usage:
  python MERGE_CONFIG_R26_9_3.py                 # project root = parent dir
  python MERGE_CONFIG_R26_9_3.py --root C:\\Nabil-gold
  python MERGE_CONFIG_R26_9_3.py --check         # dry-run: report only
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import time
from collections import OrderedDict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

FX4 = ("EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")
FX_MIN_SL = 720  # ×1.8 of the gold 400 cap (was 900 under ×2.25)
CAL_REQUIRED = True  # R26.9.5: lock the validated auction curves

OLD_DESC_PART = "الفوركس ×2.25: 450/150/900 ⇒ [600,900] (60–90 بيب)"
NEW_DESC_PART = ("الفوركس ×1.8 (R26.9.3، أمر المشغّل 2026-09-01): "
                 "360/126/720 ⇒ [486,720] (48.6–72 بيب)")


def _norm(s) -> str:
    return str(s or "").strip().upper().replace(" ", "")


def preflight(root: Path) -> bool:
    """The new utils/instruments.py must already be in place."""
    try:
        sys.path.insert(0, str(root))
        from utils.instruments import DEFAULT_INSTRUMENTS  # noqa: E402
        st = DEFAULT_INSTRUMENTS["EUR/USD"]["trading_rules"]["stop"]
        ok = (st["min_liquidity_points"] == 360
              and st["safety_buffer_points"] == 126
              and st["max_stop_points"] == 720)
        if not ok:
            print("FAIL: utils/instruments.py لا يزال النسخة القديمة (×2.25).")
            print("      انسخ ملفات حزمة R26.9.3 أولاً (خصوصاً utils/instruments.py)")
            print("      ثم أعد هذا الدمج — وإلا سيتنازع القانونان.")
        return ok
    except Exception as exc:  # noqa: BLE001
        print(f"FAIL: تعذّر قراءة utils/instruments.py من الجذر: {exc}")
        return False


def merge_config(cfg: dict) -> tuple[dict, list[str], list[str]]:
    """Return (merged_cfg, changes, notes). Only the law keys are touched."""
    changes: list[str] = []
    notes: list[str] = []

    instruments = cfg.get("instruments")
    if not isinstance(instruments, list) or not instruments:
        instruments = []
        cfg["instruments"] = instruments
        notes.append("أُنشئ بلوك instruments (لم يكن موجوداً)")

    seen = {}
    for inst in instruments:
        if not isinstance(inst, dict):
            continue
        sym = _norm(inst.get("symbol"))
        if sym in FX4:
            seen[sym] = inst

    for sym in FX4:
        if sym not in seen:
            # أضف صفاً كاملاً للزوج (نادر جداً) — بأدنى مفاتيح مطلوبة
            row = OrderedDict([("symbol", sym), ("min_sl_distance_points", FX_MIN_SL)])
            instruments.append(row)
            changes.append(f"instruments[{sym}]: أُنشئ الصف مع min_sl_distance_points={FX_MIN_SL}")
            continue
        inst = seen[sym]
        cur = inst.get("min_sl_distance_points")
        if cur == FX_MIN_SL:
            changes.append(f"instruments[{sym}].min_sl_distance_points:هو {FX_MIN_SL} مسبقاً (تخطٍّ)")
        else:
            inst["min_sl_distance_points"] = FX_MIN_SL
            changes.append(
                f"instruments[{sym}].min_sl_distance_points: {cur} → {FX_MIN_SL}")

    # ── R26.9.5: قفل معايرة المزاد للأزواج الأربعة ──────────────────────
    for sym in FX4:
        inst = seen.get(sym)
        if inst is None:
            # صفاً أُنشئ للتو أعلاه — أضف العلم إليه مباشرة
            for row in instruments:
                if isinstance(row, dict) and _norm(row.get("symbol")) == sym:
                    inst = row
                    break
        if inst is None:
            notes.append(f"instruments[{sym}]: لم يوجد الصف — تخطّي علم المعايرة (غير متوقع)")
            continue
        auc = inst.get("auction_flow")
        if not isinstance(auc, dict):
            auc = OrderedDict()
            inst["auction_flow"] = auc
        if auc.get("calibration_required") is CAL_REQUIRED:
            changes.append(f"instruments[{sym}].auction_flow.calibration_required: هو true مسبقاً (تخطٍّ)")
        else:
            old = auc.get("calibration_required")
            auc["calibration_required"] = CAL_REQUIRED
            changes.append(
                f"instruments[{sym}].auction_flow.calibration_required: {old} → true")

    # ── R26.9.11: قانون التعزيز — القاعدة الذهبية 150 ────────────────────
    oe = cfg.get("order_execution")
    if not isinstance(oe, dict):
        oe = OrderedDict()
        cfg["order_execution"] = oe
    frb = oe.get("fixed_risk")
    if not isinstance(frb, dict):
        frb = OrderedDict()
        oe["fixed_risk"] = frb
    cur_trig = frb.get("scale_in_trigger_points")
    if cur_trig == 150:
        changes.append("order_execution.fixed_risk.scale_in_trigger_points: هو 150 مسبقاً (تخطٍّ)")
    else:
        frb["scale_in_trigger_points"] = 150
        changes.append(
            f"order_execution.fixed_risk.scale_in_trigger_points: {cur_trig} → 150 (قانون الذهب: تعزيز عند −150)")

    # R26.9.15: كنس عودي — القيمة المخزّنة في أي مكان هي أساس الذهب 150 فقط،
    # والمحرك يضرب النسبة بنفسه. أي قيمة مُسبقة الضرب (270 فوركس / 75 نفط)
    # يتضاعف عليها المحرك: اليورو طالب 486 بدل 270، والنفط 37.5 بدل 75.
    def _sweep(o, path):
        if isinstance(o, dict):
            for k, v in o.items():
                if k == "scale_in_trigger_points" and v != 150:
                    changes.append(
                        f"{path}.scale_in_trigger_points: {v} → 150 (أساس الذهب؛ المحرك يضرب النسبة)")
                    o[k] = 150
                else:
                    _sweep(v, f"{path}.{k}" if k != "instruments" else "instruments")
        elif isinstance(o, list):
            for i, v in enumerate(o):
                _sweep(v, f"{path}[{i}]")
    _sweep(cfg, "")

    # وصف القانون — يُحدَّث فقط إذا كان لا يزال يحمل نص ×2.25 المتقاعد
    tr = cfg.get("trading_rules")
    if isinstance(tr, dict) and isinstance(tr.get("stop"), dict):
        desc = str(tr["stop"].get("description") or "")
        if OLD_DESC_PART in desc:
            tr["stop"]["description"] = desc.replace(OLD_DESC_PART, NEW_DESC_PART)
            changes.append("trading_rules.stop.description: حُدّث نص ×2.25 → ×1.8")
        elif NEW_DESC_PART in desc:
            changes.append("trading_rules.stop.description: محدّث مسبقاً (تخطٍّ)")
        else:
            notes.append(
                "trading_rules.stop.description نص مخصص (لا يحمل صيغة ×2.25) — تُرك كما هو؛ "
                "القانون الفعلي في instruments/utils وليس في الوصف")
    return cfg, changes, notes


def verify(root: Path) -> list[str]:
    """Resolve the real per-symbol law + calibration lock; problems listed."""
    problems = []
    try:
        from utils.trading_rules import stop_rule_for_symbol
        expected = {
            "XAU/USD": (200.0, 70.0, 400.0),
            "WTI/USD": (100.0, 35.0, 200.0),
            "EUR/USD": (360.0, 126.0, 720.0),
            "GBP/USD": (360.0, 126.0, 720.0),
            "USD/CAD": (360.0, 126.0, 720.0),
            "USD/JPY": (360.0, 126.0, 720.0),
        }
        for sym, want in expected.items():
            r = stop_rule_for_symbol(_load_cfg_for_verify(root), sym)
            got = (r.get("min_liquidity_points"), r.get("safety_buffer_points"),
                   r.get("max_stop_points"))
            if tuple(float(x) for x in got) != want:
                problems.append(f"{sym}: القانون المحلول {got} ≠ المطلوب {want}")
    except Exception as exc:  # noqa: BLE001
        problems.append(f"تعذر التحليل عبر stop_rule_for_symbol: {exc}")
    # R26.9.5: الأعلام الأربعة يجب أن تكون true فعلاً في الملف المكتوب
    try:
        cfg = _load_cfg_for_verify(root)
        for inst in cfg.get("instruments") or []:
            if isinstance(inst, dict) and _norm(inst.get("symbol")) in FX4:
                flag = (inst.get("auction_flow") or {}).get("calibration_required")
                if flag is not True:
                    problems.append(
                        f"{_norm(inst.get('symbol'))}: calibration_required={flag} ≠ true")
    except Exception as exc:  # noqa: BLE001
        problems.append(f"تعذر فحص أعلام المعايرة: {exc}")
    # R26.9.11: قاعدة التعزيز الذهبية 150
    try:
        cfg = _load_cfg_for_verify(root)
        trig = (((cfg.get("order_execution") or {}).get("fixed_risk")) or {}).get("scale_in_trigger_points")
        if trig != 150:
            problems.append(f"scale_in_trigger_points={trig} ≠ 150 (قانون الذهب)")
        # R26.9.15: أي قيمة مُسبقة الضرب في أي مسار = مضاعفة مزدوجة قادمة
        def _find_stale(o, path):
            if isinstance(o, dict):
                for k, v in o.items():
                    if k == "scale_in_trigger_points" and v != 150:
                        problems.append(f"{path}.scale_in_trigger_points={v} ≠ 150 (مُسبقة الضرب — المحرك سيضاعفها)")
                    else:
                        _find_stale(v, f"{path}.{k}")
            elif isinstance(o, list):
                for i, v in enumerate(o):
                    _find_stale(v, f"{path}[{i}]")
        _find_stale(cfg, "")
    except Exception as exc:  # noqa: BLE001
        problems.append(f"تعذر فحص قاعدة التعزيز: {exc}")
    return problems


def _load_cfg_for_verify(root: Path) -> dict:
    return json.loads((root / "config.json").read_text(encoding="utf-8"))


def main() -> int:
    ap = argparse.ArgumentParser(
        description="دمج قانون الفوركس ×1.8 + قفل معايرة المزاد (R26.9.5) في config.json القائم (بدون استبدال الملف)")
    ap.add_argument("--root", default=None,
                    help="جذر المشروع الحاوي config.json (الافتراضي: مجلد أعلى هذا السكربت)")
    ap.add_argument("--check", action="store_true",
                    help="فحص فقط دون كتابة (dry-run)")
    args = ap.parse_args()
    if args.root:
        root = Path(args.root)
    else:
        # اكتشاف تلقائي: مجلد السكربت، ثم أبوه، ثم مجلد التشغيل الحالي
        cands = [Path(__file__).resolve().parent,
                 Path(__file__).resolve().parents[1],
                 Path.cwd()]
        root = next((c for c in cands if (c / "config.json").exists()), ROOT)
    path = root / "config.json"
    print(f"الجذر المكتشف: {root}")
    if not path.exists():
        print(f"FAIL: config.json غير موجود في {path} (استخدم --root C:\\Nabil-gold)")
        return 1
    if not preflight(root):
        return 1

    cfg = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=OrderedDict)
    merged, changes, notes = merge_config(cfg)

    print("═" * 62)
    for c in changes:
        print("  • " + c)
    for n in notes:
        print("  ℹ️ " + n)

    if args.check:
        print("─" * 62)
        print("CHECK ONLY: لم تُكتب أي تغييرات (شغّل بدون --check للتطبيق)")
        return 0

    real_changes = [c for c in changes if "تخطٍّ" not in c and "محدّث مسبقاً" not in c]
    if not real_changes:
        print("─" * 62)
        print("✅ لا شيء يحتاج دمجاً — الكونفق يحمل قانون ×1.8 وقفل المعايرة بالفعل (العملية idempotent)")
        return 0

    ts = time.strftime("%Y%m%d_%H%M%S")
    backup = path.with_name(f"config.backup_R26.9.5_{ts}.json")
    shutil.copy2(path, backup)
    path.write_text(json.dumps(merged, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")
    print("─" * 62)
    print(f"  💾 نسخة احتياطية: {backup.name}")

    problems = verify(root)
    if problems:
        print("  ❌ فشل التحقق بعد الدمج — استعادة النسخة الاحتياطية:")
        for p in problems:
            print("     - " + p)
        shutil.copy2(backup, path)
        print(f"  ↩️ أُعيد الأصل من {backup.name}")
        return 1
    print("  ✅ التحقق: الذهب [270,400] · النفط [135,200] · الفوركس [486,720]")
    print("  ✅ التحقق: auction_flow.calibration_required=true للأزواج الأربعة")
    print("  ✅ اكتمل الدمج — لم يُلمس أي مفتاح آخر في الكونفق")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
