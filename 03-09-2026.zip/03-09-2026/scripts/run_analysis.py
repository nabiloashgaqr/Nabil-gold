"""Main analysis script.

Runs every 5 minutes via cron-job.org/GitHub Actions. Fetches market data, runs agents,
يطبق إدارة المخاطر وDecision، ثم يحفظ ويرسل الإشارة إذا كانت مؤهلة.
"""

from __future__ import annotations

# --- VPS: load .env if present (real env vars ALWAYS win over .env) ---
try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv()  # override=False: task-wrapper vars take precedence
except Exception:
    pass

import json
import logging
import os
import sys
import html
import traceback
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo
from typing import Any, Dict, List

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.classical_agent import ClassicalAgent
from agents.auction_flow_agent import AuctionFlowAgent
from agents.technical_agent import TechnicalAgent
from agents.multitimeframe_agent import MultiTimeframeAgent
from agents.decision_agent import DecisionAgent
from agents.daily_bias_agent import DailyBiasAgent
from agents.macro_fundamental_agent import MacroFundamentalAgent
from agents.news_risk_agent import NewsRiskAgent
from agents.price_action_agent import PriceActionAgent
from agents.sentiment_agent import SentimentAgent
from agents.volatility_agent import VolatilityAgent
from agents.oil_macro_agent import OilMacroAgent
from agents.risk_management_agent import RiskManagementAgent
from agents.smc_agent import SMCAgent
from services.map_quality import bounded_map_display_quality
from services.market_snapshot import build_market_snapshot
from services.shared_market_data import publish_shared_market_data
from agents.trading_session_agent import TradingSessionAgent
from agents.open_trades_manager import OpenTradesManager
from services.database import DatabaseService
from services.dynamic_risk import DynamicRiskManager, should_block_signal
from services.market_data import MarketDataService
from services.telegram_bot import TelegramService, post_news_alert_sent, post_news_alert_record
from services.post_news_digest import digest_event_key
from services.learning_service import get_learning_service
from services.llm_review import get_gemini_review_service
from services.pending_governor import PendingGovernor
from services.scenario_governor import ScenarioGovernor
from services.adaptive_execution import AdaptiveExecutionService
from services.agent_measurement import record_agent_measurement
from services.directional_authority import DirectionalAuthorityService
from services.day_map_sanity import DayMapSanityService
from services.setup_memory import SetupMemoryService
from services.setup_performance import SetupPerformanceService
from services.session_planner import SessionPlannerService
from services.thesis_consensus import evaluate_directional_admission, path4_candidate_matches
from services.execution_paths import (
    PATH_1, PATH_2, PATH_3, PATH_4, PATH_5, PATH_8,
    path_header, stamp_execution_path,
)
from utils.helpers import load_config, setup_logging, get_agent_weights, format_price
from utils import trading_rules as _tr
from utils.instruments import enabled_instruments, config_for_instrument, normalize_symbol, price_to_points, points_to_price, point_size, price_sanity_range

setup_logging()
logger = logging.getLogger(__name__)

# Operator 2026-08-14: original five voting agents restored; Auction Flow is a
# standalone non-voting confirmer for Paths 4 and 5.
CORE_VOTING_AGENTS = ("technical", "multitimeframe", "classical", "smc", "price_action")
LEGACY_AGENT_ALIASES: dict[str, str] = {}


def _apply_regime_and_correlation_gates(
    decision: Dict[str, Any],
    config: Dict[str, Any],
    all_results: Dict[str, Any],
    open_trades: List[Dict[str, Any]],
    symbol: str,
) -> Dict[str, Any]:
    """2026-08-19 upgrade: D1 market-regime gate + cross-asset correlation guard.

    Both are post-decision vetoes that downgrade BUY/SELL to WAIT with an
    explicit reason card. The regime gate blocks two-agent paths (2/3/5) in a
    RANGE daily regime; the correlation guard vetoes opposite-direction trades
    on correlated assets once enforce=true (advisory otherwise).
    Both fail open: any exception leaves the decision untouched.
    """
    regime_cfg = config.get("market_regime", {}) or {}
    if bool(regime_cfg.get("enabled", True)):
        regime = all_results.get("market_regime") or {"regime": "MT5_UNAVAILABLE"}
        try:
            from services.market_regime import apply_range_gate

            decision = apply_range_gate(decision, regime, config)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Regime gate crashed (fail-open): %s", exc)

    # R25.8 (2026-08-29): the central REGIME SWITCHER. It looks at the
    # environment once (D1 regime + intraday ADX/phase + news blackout +
    # ATR/volatility) and routes WHICH paths may fire - TREND admits the
    # continuation/consensus paths, RANGE restricts to the fades
    # (PATH 1/4/7/9), a news/high-vol window leaves only the news-leg (PATH 6)
    # and the sweep-raid reversal (PATH 9). Fail-open: a disabled/absent block
    # or any error leaves the decision exactly as the legacy RANGE gate left
    # it, so this never changes behaviour unless the operator switches it on.
    switcher_cfg = config.get("regime_switcher", {}) or {}
    if bool(switcher_cfg.get("enabled", False)):
        try:
            from services.regime_switcher import resolve_regime, apply_regime_switch

            tech = all_results.get("technical", {}) or {}
            tech_regime = (tech.get("market_regime") or {})
            atr_now = float(tech.get("atr") or 0.0)
            news_obj = all_results.get("news", {}) or {}
            _blackout = bool(
                news_obj.get("blackout")
                or news_obj.get("news_blackout")
                or str(news_obj.get("market_status", "")).upper() in {"DANGER", "HIGH_VOLATILITY"}
            )
            signals = {
                "d1_regime": all_results.get("market_regime") or {},
                "intraday": {
                    "adx": tech_regime.get("adx_value"),
                    "market_phase": tech_regime.get("market_phase"),
                },
                "atr": {"atr": atr_now,
                        "multiple": float(tech_regime.get("atr_multiple") or 0.0) or None},
                "news": {"blackout": _blackout,
                         "event": (news_obj.get("next_event") or {}).get("event")
                                  if isinstance(news_obj.get("next_event"), dict) else None},
                "volatility": all_results.get("volatility", {}) or {},
            }
            regime_decision = resolve_regime(signals, config)
            # apply_regime_switch stamps regime_switch_state (with opinion_line)
            # and only downgrades when regime_switcher.enforce is true. In the
            # shipped ADVISORY mode (enforce=false) it never changes a decision;
            # the verdict rides along onto cards / Telegram for observation.
            decision = apply_regime_switch(decision, regime_decision, config)
            try:
                all_results["regime_switch"] = regime_decision
            except Exception:  # noqa: BLE001
                pass
            logger.info("REGIME SWITCH (advisory=%s): %s",
                        not bool(switcher_cfg.get("enforce", True)),
                        regime_decision.get("regime"))
            # Surface the verdict in Telegram: append the Arabic opinion line
            # to the decision reasons (the field signal/status cards render),
            # and stash it for the hourly status builder. Advisory only - this
            # changes text, never the decision.
            try:
                from services.regime_switcher import regime_opinion_line
                _op_line = regime_opinion_line(regime_decision, config)
                if _op_line:
                    _existing = [str(r) for r in (decision.get("reasons") or [])]
                    if not any("البيئة:" in r for r in _existing):
                        decision["reasons"] = _existing + [_op_line]
                    decision["regime_opinion_line"] = _op_line
                    all_results["regime_opinion_line"] = _op_line
            except Exception:  # noqa: BLE001
                pass
        except Exception as exc:  # noqa: BLE001 — fail-open by contract
            logger.warning("Regime switcher crashed (fail-open): %s", exc)

    corr_cfg = config.get("correlation_guard", {}) or {}
    if bool(corr_cfg.get("enabled", False)) and len(config.get("instruments") or []) >= 2:
        try:
            from services.correlation_exposure import CorrelationExposureManager

            manager = CorrelationExposureManager(config)
            verdict = manager.review(decision, open_trades)
            decision["correlation_guard"] = verdict
            if verdict.get("action") == "VETO":
                _sig = str(decision.get("decision") or "").upper()
                if _sig in {"BUY", "SELL"}:
                    decision["decision"] = "WAIT"
                    decision["confidence"] = 0
                    decision["signal"] = {}
                    decision["correlation_veto"] = True
                    decision["warnings"] = list(decision.get("warnings") or []) + [
                        f"CORRELATION_VETO: {verdict.get('reason')}"
                    ]
        except Exception as exc:  # noqa: BLE001
            logger.warning("Correlation guard crashed (fail-open): %s", exc)

    # Global Parabolic Surge & Velocity Guard for ALL paths
    _sig = str(decision.get("decision") or "").upper()
    if _sig in {"BUY", "SELL"}:
        try:
            candles_15m = (((all_results.get("timeframes", {}) or {}).get("15m") or {}).get("data") or all_results.get("data") or [])
            tech = all_results.get("technical", {}) or {}
            atr = float(tech.get("atr") or (all_results.get("indicators") or {}).get("atr") or 0.0)
            if candles_15m and atr > 0:
                recent = candles_15m[-2:]
                max_body_atr = float((config.get("pre_arm_ote") or {}).get("max_drop_candle_atr", 1.4) or 1.4)
                for c_item in recent:
                    o = float(c_item.get("open", 0) or 0)
                    c = float(c_item.get("close", 0) or 0)
                    body = abs(c - o)
                    if _sig == "BUY" and c < o and body > max_body_atr * atr:
                        decision["decision"] = "WAIT"
                        decision["confidence"] = 0
                        decision["signal"] = {}
                        decision["velocity_veto"] = True
                        decision["warnings"] = list(decision.get("warnings") or []) + [
                            f"VIOLENT_DROP_VETO: Heavy bearish candle ({body/atr:.1f}x ATR > {max_body_atr}x) falling into level"
                        ]
                        logger.info("Universal Velocity Guard VETO: %s blocked due to violent drop", _sig)
                        break
                    elif _sig == "SELL" and c > o and body > max_body_atr * atr:
                        decision["decision"] = "WAIT"
                        decision["confidence"] = 0
                        decision["signal"] = {}
                        decision["velocity_veto"] = True
                        decision["warnings"] = list(decision.get("warnings") or []) + [
                            f"VIOLENT_SURGE_VETO: Heavy bullish candle ({body/atr:.1f}x ATR > {max_body_atr}x) surging into level"
                        ]
                        logger.info("Universal Velocity Guard VETO: %s blocked due to violent surge", _sig)
                        break
        except Exception as exc:  # noqa: BLE001
            logger.warning("Universal velocity guard check failed (fail-open): %s", exc)

    return decision


def _maybe_refresh_macro_context(data: Dict[str, Any], config: Dict[str, Any],
                                 database: Any,
                                 marker_path: Optional[Path] = None,
                                 context_path: Optional[Path] = None,
                                 events_path: Optional[Path] = None) -> None:
    """R26.9.16 (operator 2026-09-02: "إعادة حساب الصوت بعد البيانات الطازجة"):
    keep the macro judge's DATA fresh at the exact moments the regime can
    change. The provider is otherwise hourly; when a violent displacement
    (>= displacement_atr x ATR on M15) is live on this symbol, the macro
    context is rebuilt NOW and saved, and again at most once per cooldown
    window (10 min) while the shock persists — the delayed shots catch the
    candles that actually printed the shock. The live lesson: the macro read
    BEARISH 66% all through a +111$ gold day because its inputs were an hour
    stale and its eye a 5-day net. Fail-open: any error changes nothing.

    R26.9.13 (operator 2026-09-03 "قلب سريع"): TWO more standing triggers —
    (2) stale_age: the saved context is >= max_age_minutes (60) old, so the
    judge never sits on an hour-stale read; (3) calendar_window: now is
    inside [−calendar_pre_minutes, +calendar_post_minutes] around a tier-1
    release for a relevant currency. The cooldown marker records which
    reason fired.
    """
    try:
        cfg = (config.get("macro_refresh") or {}) if isinstance(config, dict) else {}
        if not bool(cfg.get("enabled", True)):
            return
        threshold = float(cfg.get("displacement_atr", 5.0) or 5.0)
        cooldown = float(cfg.get("cooldown_minutes", 10.0) or 10.0)
        max_age = float(cfg.get("max_age_minutes", 60.0) or 60.0)
        cal_before = float(cfg.get("calendar_pre_minutes", 15.0) or 15.0)
        cal_after = float(cfg.get("calendar_post_minutes", 5.0) or 5.0)
        candles = ((((data.get("timeframes", {}) or {}).get("15m") or {})
                    .get("data")) or [])
        if len(candles) < 10:
            return
        now = datetime.now(timezone.utc)
        reason, mult = None, 0.0
        if candles:
            from utils.indicators import calculate_atr
            atr_series = calculate_atr(candles, 14)
            atr = next((float(x) for x in reversed(atr_series) if x), 0.0)
            if atr > 0:
                from services.pre_arm_ote import detect_impulse_leg
                for cand in ("BUY", "SELL"):
                    leg = detect_impulse_leg(list(candles), atr, {}, cand)
                    if leg:
                        mult = max(mult, float(leg["leg_size"]) / max(atr, 1e-9))
                if mult >= threshold:
                    reason = "displacement"
        if reason is None:
            # R26.9.13 (operator 2026-09-03): the macro judge must never sit
            # on an hour-stale read — the +111$ gold day stayed BEARISH 66%
            # on exactly that. At/after max_age_minutes the context rebuilds.
            try:
                ctx_path = context_path or (Path(__file__).resolve().parents[1]
                                            / "storage" / "macro_context.json")
                if ctx_path.exists():
                    stamp = str((json.loads(ctx_path.read_text(encoding="utf-8"))
                                 or {}).get("generated_at") or "")
                    ts = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
                    if ts.tzinfo is None:
                        ts = ts.replace(tzinfo=timezone.utc)
                    if (now - ts).total_seconds() / 60.0 >= max_age:
                        reason = "stale_age"
            except Exception:  # noqa: BLE001 - unreadable stamp never blocks
                pass
        if reason is None:
            # R26.9.13: a tier-1 release window is when the regime actually
            # flips — re-ask inside [−pre, +post] minutes around it.
            try:
                sym = str((config.get("symbol") if isinstance(config, dict) else "")
                          or "").upper()
                usd_relevant = True  # every traded symbol is USD-anchored today
                base_ccy = sym[:3] if "/" in sym else ""
                ev_path = events_path or (Path(__file__).resolve().parents[1]
                                          / "storage" / "macro" / "economic_events.json")
                if ev_path.exists():
                    for row in json.loads(ev_path.read_text(encoding="utf-8")):
                        if not isinstance(row, dict):
                            continue
                        tier = str(row.get("impact") or row.get("tier") or "").upper()
                        if tier not in {"1", "TIER_1", "HIGH", "TIER 1"}:
                            continue
                        ccy = str(row.get("currency") or "USD").upper()
                        if ccy != "USD" and ccy != base_ccy:
                            continue
                        if not (usd_relevant or ccy == base_ccy):
                            continue
                        try:
                            when = datetime.fromisoformat(
                                str(row.get("date") or "").replace("Z", "+00:00"))
                            if when.tzinfo is None:
                                when = when.replace(tzinfo=timezone.utc)
                        except (TypeError, ValueError):
                            continue
                        dt_min = (now - when).total_seconds() / 60.0
                        if -cal_before <= dt_min <= cal_after:
                            reason = "calendar_window"
                            break
            except Exception:  # noqa: BLE001 - a broken calendar never blocks
                pass
        if reason is None:
            return
        marker = marker_path or (Path(__file__).resolve().parents[1]
                                 / "storage" / "macro" / "refresh_marker.json")
        try:
            if marker.exists():
                nxt = datetime.fromisoformat(str(json.loads(
                    marker.read_text(encoding="utf-8")).get("next_at", "")))
                if nxt.tzinfo is None:
                    nxt = nxt.replace(tzinfo=timezone.utc)
                if now < nxt:
                    return  # cooldown: one re-ask per window while live
        except Exception:  # noqa: BLE001 - a broken marker never blocks
            pass
        from services.macro_data_provider import MacroDataProvider
        context = MacroDataProvider(config).build_context()
        if isinstance(context, dict) and context:
            try:
                database.save_macro_context(context)
            except Exception as exc:  # noqa: BLE001
                logger.warning("MACRO REFRESH save failed: %s", exc)
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text(json.dumps({
            "next_at": (now + timedelta(minutes=cooldown)).isoformat(),
            "last_multiple": round(mult, 2),
            "reason": reason,
            "refreshed_at": now.isoformat()}), encoding="utf-8")
        logger.info("MACRO REFRESH for %s: %.1fx ATR displacement live — the "
                    "judge's data re-asked NOW (hourly provider bypassed; "
                    "next shot in >= %.0f min)",
                    str(data.get("symbol") or config.get("symbol") or "?"),
                    mult, cooldown)
    except Exception as exc:  # noqa: BLE001 - refresh must never break a cycle
        logger.warning("MACRO REFRESH check failed (fail-open): %s", exc)


def _path4_cover_actionable(all_results: Dict[str, Any], config: Dict[str, Any],
                             plan_side: str) -> bool:
    """R26.9.17: can the PATH-4 cover actually run THIS cycle?

    A ready session plan owns its side only while its own admission holds on
    the current book. Fail-open to True on any evaluation error, so the fence
    keeps its historical behaviour instead of silently disarming the reserve.
    """
    if plan_side not in {"BUY", "SELL"}:
        return False
    try:
        from services.thesis_consensus import evaluate_directional_admission
        verdict = evaluate_directional_admission(
            plan_side, _compact_agent_details(all_results), config)
        return bool(verdict.get("allow"))
    except Exception:  # noqa: BLE001 — the fence must never crash the cycle
        return True


def _evaluate_path9_reversal(data: Dict[str, Any], all_results: Dict[str, Any],
                             config: Dict[str, Any], symbol: str):
    """R25.8: evaluate the PATH 9 liquidity-sweep raid reversal for this cycle.

    Returns the direction ("BUY"/"SELL") to admit and builds the signal payload
    onto ``all_results``-adjacent decision data, or None to abstain. It only
    FIRES on a clean raid+rejection pattern; every other cycle returns None and
    the reactive paths proceed untouched. Pure read over the frozen book.
    """
    block = config.get("path9_reversal", {}) or {}
    if not bool(block.get("enabled", True)):
        return None
    try:
        from services.path9_reversal import evaluate_path9_reversal
        from services.execution_paths import PATH_9

        # ── Fence 1: the PATH 4 reserve ─────────────────────────────────
        # PATH 4 owns the high-grade raid: a morning/session SMC map that has
        # already prepared a resting LIMIT at the POI (the patient trapper).
        # PATH 9 is the orphan-raid snapper, so it stands down when a READY
        # day map or an armed SMC LIQUIDITY_REVERSAL candidate already covers
        # the reversal side for this symbol. No duplicates; PATH 9 only fires
        # where nobody owns a trap.
        try:
            plan = all_results.get("session_plan", {}) or {}
            plan_side = str(plan.get("session_bias") or plan.get("authority_direction") or "").upper()
            armed_smc_side = ""
            smc_res0 = all_results.get("smc", {}) or {}
            for _c in (smc_res0.get("setup_candidates") or []):
                if isinstance(_c, dict) and str(_c.get("setup_type") or "").upper() in {
                        "LIQUIDITY_REVERSAL", "REVERSAL_ATTEMPT"}:
                    armed_smc_side = str(_c.get("direction") or "").upper()
                    break
            # A READY day map on either side, or an armed SMC liquidity-
            # reversal candidate, means PATH 4 (the patient trapper) owns the
            # raid — PATH 9 stays in its lane (orphan raids nobody mapped).
            # R26.9.17 (operator 2026-09-02): a cover OWNS the side only
            # when it can actually RUN this cycle. The live deadlock: the
            # plan was READY on BUY yet its ladder was blocked by admission
            # (support=2 < 3 after a 7.7x displacement) — a named owner that
            # cannot act left the side a FUNCTIONAL ORPHAN while PATH 9
            # kept standing down. Actionability = the cover's own side
            # earns entry admission on the CURRENT book.
            if bool(block.get("respect_path4_reserve", True)) and (
                (plan.get("plan_ready") and plan_side in {"BUY", "SELL"}
                 and _path4_cover_actionable(all_results, config, plan_side))
                or armed_smc_side in {"BUY", "SELL"}
            ):
                logger.info("PATH 9 stands down for %s: side covered by a ready "
                            "SMC/planner map (PATH 4 reserve)", symbol)
                return None
        except Exception:  # noqa: BLE001 — reserve check never blocks evaluation
            pass

        # Candles: the M5 book is both the raid window and the reversal
        # confirmation. Take a short window (freshness fence), fall back to
        # the primary data series.
        candles = ((((data.get("timeframes", {}) or {}).get("5m") or {})
                    .get("data")) or data.get("data") or [])
        if len(candles) < 2:
            return None
        _window = int(float(block.get("max_reversal_candles", 2) or 2)) + 1
        m5 = candles[-max(_window, 3):]
        # Build resting pools from the SMC conditional map's liquidity pools
        # plus the latest daily/session context the agents computed.
        smc = all_results.get("smc", {}) or {}
        context: Dict[str, Any] = {}
        try:
            liq = (((smc.get("conditional_map") or {}).get("details") or {})
                   .get("liquidity") or {})
            if liq:
                context["liquidity_map"] = liq
        except Exception:  # noqa: BLE001
            liq = {}
        # Previous-day / session extremes from the market snapshot if present.
        snap = data.get("verified_snapshot") or {}
        for src_key, dst_key in (
            ("previous_day_high", "pdh"), ("pdh", "pdh"),
            ("previous_day_low", "pdl"), ("pdl", "pdl"),
        ):
            v = snap.get(src_key) or data.get(src_key)
            if v and dst_key not in context:
                try:
                    context[dst_key] = float(v)
                except (TypeError, ValueError):
                    pass
        # Auction/flow TAPE — the MANDATORY independent witness (operator
        # 2026-08-30): the reverse of PATH 4. A responsive tape step against
        # the raid is what proves the trap; no signature -> no trade.
        flow = None
        auction = all_results.get("auction_flow", {}) or {}
        try:
            a_side = str(auction.get("signal") or auction.get("direction") or "").upper()
            a_conf = float(auction.get("confidence") or 0.0)
            # Acceptance/rejection is the tape's own responsive read.
            _ar = auction.get("acceptance_rejection") or {}
            a_responsive = auction.get("responsive")
            if a_responsive is None and isinstance(_ar, dict):
                a_responsive = bool(_ar.get("responsive")
                                    or _ar.get("state") in {"REJECTION", "RESPONSIVE"})
            if a_side in {"BUY", "SELL"} and a_conf > 0:
                flow = {"direction": a_side, "confidence": a_conf,
                        "responsive": bool(a_responsive if a_responsive is not None else True)}
        except (TypeError, ValueError):
            flow = None

        # SMC is the CONFIRMING witness (boost, never a gate): its own sweep
        # read + directional read. PATH 9 is for the raid SMC did not map, so
        # absence here is expected and never refuses the trade.
        smc_witness = None
        try:
            _liq = (((smc.get("conditional_map") or {}).get("details") or {})
                    .get("liquidity") or {})
            _recent = _liq.get("recent_sweep") if isinstance(_liq, dict) else None
            smc_witness = {
                "direction": str(smc.get("signal") or smc.get("direction") or "").upper(),
                "confidence": float(smc.get("confidence") or 0.0),
                "recent_sweep": _recent if isinstance(_recent, dict) else {},
            }
        except (TypeError, ValueError):
            smc_witness = None

        verdict = evaluate_path9_reversal(
            symbol=symbol,
            raid_candle=None,          # scan the fresh window (fence 2)
            m5_candles=m5,
            context=context,
            flow=flow,
            smc=smc_witness,
            config=config,
        )
        if not verdict.get("allow"):
            # R26.9.19 (operator 2026-09-02): scalp type 2 REMOVED from
            # production by operator order ("احذف النوع الثاني نهائي") —
            # the fence fix (R26.9.17) stays; the lab measurement of
            # shallower zones lives in SIM_SCALP2_REPLAY.py only.
            return None

        side = str(verdict["direction"]).upper()
        if side not in {"BUY", "SELL"}:
            return None

        # Fence 1 (same-side reserve): PATH 4 owns a side it has already
        # armed. A ready map/armed reversal candidate or a resting Path-4
        # LIMIT on the SAME side takes the trade; PATH 9 covers only the
        # orphan side nobody trapped.
        try:
            _plan = all_results.get("session_plan", {}) or {}
            _plan_side = str(_plan.get("session_bias")
                             or _plan.get("authority_direction") or "").upper()
            _armed_same = any(
                isinstance(_c, dict)
                and str(_c.get("direction") or "").upper() == side
                and str(_c.get("setup_type") or "").upper() in {
                    "LIQUIDITY_REVERSAL", "REVERSAL_ATTEMPT"}
                for _c in (smc.get("setup_candidates") or []))
            if bool(block.get("respect_path4_reserve", True)) and (
                (_plan.get("plan_ready") and _plan_side == side
                 and _path4_cover_actionable(all_results, config, _plan_side))
                or _armed_same
            ):
                logger.info("PATH 9 stands down for %s %s: same side owned by a "
                            "ready map (PATH 4 reserve)", symbol, side)
                return None
        except Exception:  # noqa: BLE001
            pass

        # R24-0 SUPREMACY: a refused risk book refuses PATH 9 too.
        risk = all_results.get("risk", {}) or {}
        if risk.get("approved") is False:
            logger.info("PATH 9 blocked for %s by R24-0 risk veto: %s",
                        symbol, risk.get("rejection_reason") or "not approved")
            return None

        entry = float(verdict["entry"] or 0.0)
        if entry <= 0:
            return None
        _checks = verdict.get("checks", {}) or {}
        _sweep_side = str((verdict.get("sweep") or {}).get("sweep_side") or "").lower()
        # Hand the admitted reversal to the main flow through a signal payload
        # stamped PATH 9; the planner/direct branches pick up decision_type.
        signal = {
            "type": side,
            "entry": {"price": entry, "kind": "LIMIT",
                      "order_type": f"{side}_LIMIT",
                      "basis": "PATH 9 liquidity sweep raid reversal",
                      "current_price": entry},
            "stop_loss": verdict.get("stop"),
            "tp1": verdict.get("tp1"),
            "tp2": verdict.get("tp2"),
            "tp1_rr": verdict.get("rr_ratio"),
            "tp2_rr": verdict.get("rr_ratio"),
            "rr_ratio": verdict.get("rr_ratio"),
            "order_type": f"{side}_LIMIT",
            "entry_kind": "LIMIT",
            "path9": {
                "swept_level": verdict.get("swept_level"),
                "sweep": verdict.get("sweep"),
                "trigger": verdict.get("trigger"),
                "flow": _checks.get("flow"),
                "smc": _checks.get("smc"),
                "reversal_lag_candles": verdict.get("reversal_lag_candles"),
                "reasons": verdict.get("reasons"),
            },
        }
        # Write onto a synthetic decision object the main flow reads. It is
        # fully STAMPED PATH 9 (id + setup_context) here so the generic stamp
        # step leaves it alone and the flip authority reads a real reversal.
        path9_decision: Dict[str, Any] = {
            "decision": side,
            "symbol": symbol,
            "confidence": float(verdict.get("confidence") or (flow or {}).get("confidence") or 70.0),
            "signal": signal,
            "current_price": entry,
            "entry_mode": "path9_liquidity_sweep_reversal",
            "reasons": [f"PATH 9 sweep-raid reversal {side}: swept "
                        f"{verdict.get('swept_level')} ({verdict.get('trigger')}); "
                        f"auction tape witness signed"
                        + ("; SMC confirms" if _checks.get("smc") else "")],
            "warnings": [],
            # R24-style reversal provenance so DirectionalAuthority can judge a
            # map challenge honestly (reversal thesis + rejection + fresh sweep).
            "setup_context": {
                "setup_type": "LIQUIDITY_REVERSAL",
                "trigger_state": "REJECTION_CONFIRMED",
                "sweep_side": _sweep_side,
                "trigger_score": float((_checks.get("flow") or {}).get("confidence") or 0.0),
                "thesis_source": ("PATH 9 orphan raid reversal — tape-signed; "
                                  "not part of the day-map thesis; R24-0 binds"),
            },
        }
        stamp_execution_path(path9_decision, PATH_9)
        all_results["path9_decision"] = path9_decision
        logger.info("PATH 9 LIQUIDITY SWEEP REVERSAL armed for %s %s: swept=%s "
                    "trigger=%s tape=%s smc=%s",
                    symbol, side, verdict.get("swept_level"), verdict.get("trigger"),
                    bool(_checks.get("flow")), bool(_checks.get("smc")))
        return side
    except Exception as exc:  # noqa: BLE001 — never break the cycle
        logger.warning("PATH 9 evaluation crashed (fail-open): %s", exc)
        return None


def _book_agent(book: Dict[str, Any] | None, name: str) -> tuple[str, Dict[str, Any]]:
    """Read the new book; accept old snapshots only for historical replay."""
    payload = book if isinstance(book, dict) else {}
    value = payload.get(name)
    if isinstance(value, dict):
        return name, value
    legacy = LEGACY_AGENT_ALIASES.get(name)
    value = payload.get(legacy) if legacy else None
    return (str(legacy), value) if isinstance(value, dict) else (name, {})


def synthetic_timeframe_sources(data: Dict[str, Any]) -> list[str]:
    """Return timeframe/source names that are synthetic demo data."""
    synthetic: list[str] = []
    if data.get("source") == "synthetic_demo":
        synthetic.append(str(data.get("timeframe") or "primary"))
    for timeframe, payload in (data.get("timeframes", {}) or {}).items():
        if isinstance(payload, dict) and payload.get("source") == "synthetic_demo":
            name = str(timeframe)
            if name not in synthetic:
                synthetic.append(name)
    return synthetic


def _manual_status_enabled() -> bool:
    """Return True only when a human explicitly asks a workflow_dispatch run to
    send WAIT/status messages."""
    if os.environ.get("GITHUB_EVENT_NAME") != "workflow_dispatch":
        return False
    return str(os.environ.get("SEND_STATUS_ON_MANUAL", "false")).strip().lower() in {"1", "true", "yes", "y"}


def should_send_status(config: Dict[str, Any]) -> bool:
    """Send blocked/no-signal messages only when configured."""
    if os.environ.get("GITHUB_EVENT_NAME") == "workflow_dispatch":
        return _manual_status_enabled()
    notif = config.get("notifications", {}) or {}
    return bool(notif.get("send_no_signal_updates", False)) or bool(notif.get("notify_on_blocked_signal", False))


def should_send_hourly_status(config: Dict[str, Any]) -> bool:
    """Send a clean market status update roughly once per hour."""
    if os.environ.get("GITHUB_EVENT_NAME") == "workflow_dispatch":
        return _manual_status_enabled()
    notif = config.get("notifications", {}) or {}
    if not (bool(notif.get("send_no_signal_updates", False)) or bool(notif.get("hourly_status", False))):
        return False
    now = datetime.now(timezone.utc)
    interval = int(notif.get("hourly_status_interval_minutes", 60) or 60)
    if interval <= 10:
        return True
    return now.minute < 10


def _hourly_status_state_path() -> Path:
    return Path(__file__).resolve().parents[1] / "storage" / "hourly_status_last.json"


def _claim_hourly_status_slot(config: Dict[str, Any]) -> bool:
    """BUILD 16 (2026-08-20): allow exactly ONE hourly status per UTC hour.

    The 5-minute analysis task satisfies ``minute < 10`` on TWO cycles per
    hour (e.g. 14:00 and 14:05), and a second sender (the legacy market-status
    task) ran the same builder again — four messages per hour. This slot file
    makes the first claim the winner; every later cycle in the same UTC hour
    skips silently. Storage hiccups fail open (never swallow a status).
    """
    notif = config.get("notifications", {}) or {}
    if not bool(notif.get("hourly_status_dedup", True)):
        return True
    now = datetime.now(timezone.utc)
    key = now.strftime("%Y-%m-%dT%H")
    try:
        state_path = _hourly_status_state_path()
        if state_path.exists():
            try:
                data = json.loads(state_path.read_text(encoding="utf-8") or "{}")
            except (json.JSONDecodeError, OSError):
                data = {}
            if isinstance(data, dict) and data.get("hour") == key:
                return False
        state_path.parent.mkdir(parents=True, exist_ok=True)
        state_path.write_text(json.dumps({"hour": key, "sent_at": now.isoformat()}), encoding="utf-8")
        return True
    except Exception:  # noqa: BLE001 - never block the status on a storage hiccup
        return True


def _send_hourly_status_once(telegram: Any, config: Dict[str, Any], body: str) -> bool:
    """Send an hourly status only when this cycle owns the hourly slot."""
    if not _claim_hourly_status_slot(config):
        logger.info("Hourly status already sent this hour - dedup guard skipped a duplicate")
        return False
    try:
        telegram.send_message(body)
        return True
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to send hourly status: %s", exc)
        return False


def _parse_datetime(value: Any) -> datetime | None:
    """Parse common ISO timestamps safely as UTC-aware datetimes."""
    if not value:
        return None
    try:
        text = str(value).replace('Z', '+00:00')
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _trade_direction(trade: Dict[str, Any]) -> str:
    return str(trade.get('type') or trade.get('side') or trade.get('trade_type') or trade.get('decision') or '').upper()


def _trade_entry_price(trade: Dict[str, Any]) -> float | None:
    """Reference price for duplicate/cooldown logic.

    - OPEN trades should be compared by their original entry zone.
    - RECENTLY CLOSED trades should be compared by their close/exit zone first,
      because an immediate re-entry near the fresh exit area is the real
      duplicate/revenge-risk case. Using the old entry price let a trade entered
      at 4040 and trailed out at 3993 re-enter immediately at 3992 without any
      cooldown block, simply because 3992 was far from the original 4040 entry.
    """
    outcome = _trade_outcome(trade)
    keys = ('entry_price', 'current_price') if outcome == 'OPEN' else ('close_price', 'entry_price', 'current_price')
    for key in keys:
        value = trade.get(key)
        try:
            if value is not None:
                return float(value)
        except (TypeError, ValueError):
            continue
    return None


_OPEN_STATUSES = {"OPEN", "PARTIAL", "TP1_HIT", "PENDING"}
_LOSS_STATUSES = {"SL_HIT"}
_WIN_STATUSES = {"TP2_HIT"}
_BREAKEVEN_STATUSES = {"BE_HIT", "EXPIRED", "THESIS_EXIT", "MANUAL_CLOSE"}


def _trade_outcome(trade: Dict[str, Any]) -> str:
    """Classify a trade as OPEN / WIN / LOSS / BREAKEVEN."""
    status = str(trade.get("status", "")).upper()
    if status in _OPEN_STATUSES:
        return "OPEN"
    result = str(trade.get("result", "") or "").upper()
    if result in {"WIN", "LOSS", "BREAKEVEN"}:
        return result
    for key in ("final_pnl", "final_pnl_points", "current_pnl", "current_pnl_points"):
        try:
            pnl = float(trade.get(key))
        except (TypeError, ValueError):
            continue
        if pnl > 0: return "WIN"
        if pnl < 0: return "LOSS"
        return "BREAKEVEN"
    if status in _LOSS_STATUSES: return "LOSS"
    if status in _WIN_STATUSES: return "WIN"
    if status in _BREAKEVEN_STATUSES: return "BREAKEVEN"
    return "BREAKEVEN"


def _trade_reference_time(trade: Dict[str, Any], now: datetime) -> datetime:
    closed = _parse_datetime(trade.get("closed_at") or trade.get("close_time"))
    if closed: return closed
    opened = _parse_datetime(trade.get("created_at") or trade.get("entry_time") or trade.get("opened_at"))
    return opened or now


_SETUP_STATE_RANK = {
    "DETECTED": 0,
    "SWEEP_CONFIRMED": 1,
    "POI_MARKED": 2,
    "ENTRY_ARMED": 3,
    "ENTRY_TRIGGERED": 4,
    "INVALIDATED": 5,
    "EXPIRED": 5,
}

# Terminal setup-memory states: a candidate here is a finished thesis and must
# never produce a live order. Mirrors SessionPlannerService.TERMINAL_SETUP_STATES.
TERMINAL_SETUP_STATES = {"INVALIDATED", "EXPIRED", "ENTRY_TRIGGERED"}


def _trade_setup_context(trade: Dict[str, Any]) -> Dict[str, Any]:
    snap = trade.get("signal_snapshot") or {}
    if isinstance(snap, str):
        try:
            import json
            snap = json.loads(snap)
        except Exception:
            snap = {}
    if not isinstance(snap, dict):
        snap = {}
    setup = snap.get("setup_context") or trade.get("setup_context") or {}
    return dict(setup) if isinstance(setup, dict) else {}


def _setup_state_rank(value: Any) -> int:
    return _SETUP_STATE_RANK.get(str(value or "").upper(), -1)


def _setup_zone_midpoint(setup: Dict[str, Any]) -> float | None:
    zone = setup.get("poi_zone") or {}
    try:
        top = float(zone.get("top"))
        bottom = float(zone.get("bottom"))
        if top > 0 and bottom > 0:
            return (top + bottom) / 2.0
    except (TypeError, ValueError, AttributeError):
        pass
    try:
        high = float(setup.get("poi_high"))
        low = float(setup.get("poi_low"))
        if high > 0 and low > 0:
            return (high + low) / 2.0
    except (TypeError, ValueError):
        pass
    return None


def _setup_sweep_time(setup: Dict[str, Any]) -> datetime | None:
    details = setup.get("details") or {}
    if isinstance(details, dict):
        sweep = details.get("recent_sweep") or {}
        if isinstance(sweep, dict):
            return _parse_datetime(sweep.get("time"))
    return None


def _decision_scenario_id(decision: Dict[str, Any]) -> str:
    plan = decision.get("session_plan") or {}
    if isinstance(plan, dict) and plan.get("scenario_id"):
        return str(plan.get("scenario_id"))
    setup = decision.get("setup_context") or {}
    if isinstance(setup, dict) and setup.get("scenario_id"):
        return str(setup.get("scenario_id"))
    return ""



def _decision_ladder_role(decision: Dict[str, Any]) -> str:
    setup = decision.get("setup_context") or {}
    if isinstance(setup, dict) and setup.get("pending_plan_role"):
        return str(setup.get("pending_plan_role")).upper()
    if isinstance(setup, dict) and setup.get("selection_role"):
        return str(setup.get("selection_role")).upper()
    return ""



def _trade_session_plan(trade: Dict[str, Any]) -> Dict[str, Any]:
    snap = trade.get("signal_snapshot") or {}
    if isinstance(snap, str):
        try:
            import json
            snap = json.loads(snap)
        except Exception:
            snap = {}
    if not isinstance(snap, dict):
        snap = {}
    plan = snap.get("session_plan") or trade.get("session_plan") or {}
    return dict(plan) if isinstance(plan, dict) else {}



def _trade_scenario_id(trade: Dict[str, Any]) -> str:
    plan = _trade_session_plan(trade)
    if plan.get("scenario_id"):
        return str(plan.get("scenario_id"))
    setup = _trade_setup_context(trade)
    if setup.get("scenario_id"):
        return str(setup.get("scenario_id"))
    return ""



def _trade_ladder_role(trade: Dict[str, Any]) -> str:
    setup = _trade_setup_context(trade)
    if setup.get("pending_plan_role"):
        return str(setup.get("pending_plan_role")).upper()
    if setup.get("selection_role"):
        return str(setup.get("selection_role")).upper()
    return ""



def _ladder_sibling_allowed(decision: Dict[str, Any], trade: Dict[str, Any]) -> bool:
    current_sid = _decision_scenario_id(decision)
    existing_sid = _trade_scenario_id(trade)
    if not current_sid or current_sid != existing_sid:
        return False
    current_role = _decision_ladder_role(decision)
    existing_role = _trade_ladder_role(trade)
    if not current_role or not existing_role:
        return False
    return current_role != existing_role



def _plan_execution_hierarchy(plan: Dict[str, Any], role: str) -> Dict[str, Any]:
    manual_plan = (plan.get("manual_plan") or {}) if isinstance(plan, dict) else {}
    direction = str(plan.get("session_bias") or "").upper()
    side_word = "BUY" if direction == "BUY" else "SELL" if direction == "SELL" else "TRADE"
    main_label = str(manual_plan.get("main_area_label") or f"MAIN {side_word} AREA")
    add_label = str(manual_plan.get("add_area_label") or f"ADD {side_word} AREA")
    role = str(role or "PRIMARY").upper()
    if role == "PRIMARY":
        return {"execution_leg": "MAIN_AREA", "execution_leg_label": main_label, "execution_stage": "MAIN"}
    if role == "STANDBY":
        return {"execution_leg": "ADD_AREA", "execution_leg_label": add_label, "execution_stage": "ADD"}
    if role == "STARTER":
        return {"execution_leg": "STARTER", "execution_leg_label": f"STARTER inside {main_label}", "execution_stage": "MAIN"}
    if role == "ADD_ON":
        return {"execution_leg": "ADD_ON", "execution_leg_label": f"ADD-ON from {add_label}", "execution_stage": "ADD"}
    return {"execution_leg": role or "MAIN_AREA", "execution_leg_label": role or main_label, "execution_stage": "MAIN"}



def _clamp_leg_stop_to_law(stop_loss: float, entry_price: float, direction: str,
                            symbol: str, config: Dict[str, Any]) -> float:
    """R26.9.9 (operator 2026-09-01): a ladder leg's stop obeys the SAME law
    as every other door -- gold's rules in full with the ratio difference
    (WTI x0.5 135-200 / FX x1.8 486-720). The planner ships the MAP's
    structural invalidation verbatim, and a live GBP/USD leg carried a
    1025-pt stop on 2026-09-01 (cap 720) -- lawful geometry is enforced at
    the execution boundary, whatever the map drew. XAU/USD (and symbols
    without a law of their own) are returned UNTOUCHED: their legs keep the
    legacy planner behaviour byte-for-byte."""
    lo_pts, hi_pts = _tr.law_band_points(config, symbol)
    if hi_pts <= 0 or entry_price <= 0 or stop_loss <= 0:
        return stop_loss
    risk_pts = abs(price_to_points(entry_price - stop_loss, symbol=symbol))
    if lo_pts > 0 and risk_pts < lo_pts:
        new_stop = (entry_price - points_to_price(lo_pts, symbol)) if direction == "BUY" \
            else (entry_price + points_to_price(lo_pts, symbol))
        logger.info("Session-plan leg stop floored to law for %s %s: %.0f -> %.0f pts",
                    symbol, direction, risk_pts, lo_pts)
        return new_stop
    if risk_pts > hi_pts:
        new_stop = (entry_price - points_to_price(hi_pts, symbol)) if direction == "BUY" \
            else (entry_price + points_to_price(hi_pts, symbol))
        logger.info("Session-plan leg stop capped to law for %s %s: %.0f -> %.0f pts",
                    symbol, direction, risk_pts, hi_pts)
        return new_stop
    return stop_loss


def _planned_order_type(
    config: Dict[str, Any],
    direction: str,
    entry: float,
    current_price: float,
    symbol: str,
    planned_stop: float | None = None,
) -> str:
    oe = config.get("order_execution", {}) or {}
    entry_style = str(oe.get("entry_style", "market")).lower()
    if entry_style in {"market", "fixed_risk"}:
        return f"{direction}_MARKET"
    if entry_style == "hybrid":
        threshold = points_to_price(_safe_float(oe.get("market_threshold_points"), 30), symbol=symbol)
    else:
        threshold = points_to_price(_safe_float(oe.get("pending_threshold_points"), 20), symbol=symbol)
    if abs(entry - current_price) <= max(threshold, 0.01):
        return f"{direction}_MARKET"
    # Entries are MARKET or LIMIT. Never STOP.
    #
    # A STOP entry buys above the market or sells below it -- it pays a worse
    # price than the one available now, in exchange for waiting for the move
    # to prove itself. That is chasing, and it is the shape of the 2026-07-29
    # loss: BUY STOP at 4028.77 placed above the market while three qualified
    # agents read SELL, filled into a 310-point decline.
    #
    # A LIMIT is the opposite trade: it sells into a rally or buys into a dip,
    # always at a price better than the market. When the mapped level is on
    # the wrong side to do that, the entry is taken at the market instead of
    # waiting for a worse one. Nothing is skipped and nothing is chased.
    #
    # The market fill is only offered while the mapped stop still protects the
    # live price. A plan whose stop sits between the market and its own entry
    # -- price 3992 for a BUY mapped 4042/4039 -- cannot be repriced to the
    # market without inverting the trade, so it is refused outright rather
    # than shipped as an unprotected position. This is caught downstream by
    # validate_signal_before_send too; declaring it here keeps the refusal
    # legible instead of surfacing as a late validation error.
    stop_loss = _safe_float(planned_stop, 0.0)
    if direction == "BUY":
        if entry < current_price:
            return "BUY_LIMIT"
        if stop_loss > 0 and stop_loss >= current_price:
            return "NO_ENTRY"
        return "BUY_MARKET"
    if direction == "SELL":
        if entry > current_price:
            return "SELL_LIMIT"
        if stop_loss > 0 and stop_loss <= current_price:
            return "NO_ENTRY"
        return "SELL_MARKET"
    return "UNKNOWN"



def _plan_targets(direction: str, entry_price: float, stop_loss: float, target_price: float) -> tuple[float, float, float]:
    risk = abs(stop_loss - entry_price)
    reward = abs(target_price - entry_price)
    if risk <= 0 or reward <= 0:
        tp1 = target_price
        tp2 = target_price
        rr = 0.0
        return round(tp1, 2), round(tp2, 2), rr
    one_r = risk
    half_reward = reward * 0.5
    tp1_dist = min(max(one_r, reward * 0.35), half_reward if half_reward > 0 else one_r)
    if direction == "BUY":
        tp1 = entry_price + tp1_dist
        tp2 = target_price
    else:
        tp1 = entry_price - tp1_dist
        tp2 = target_price
    rr = reward / risk if risk > 0 else 0.0
    return round(tp1, 2), round(tp2, 2), round(rr, 2)



def _resolve_reward_target(
    direction: str,
    entry_price: float,
    stop_loss: float,
    target_price: float,
    candidate: Dict[str, Any] | None,
    min_rr: float,
    symbol: str = "XAU/USD",
    min_tp1_rr: float = 0.0,
    prefer_far: bool = True,
    max_rr: float = 0.0,
    min_tp2_beyond_rr: float = 0.5,
    tp2_multiple: float = 2.0,
    risk_cfg: Dict[str, Any] | None = None,
) -> tuple[float, float, str | None]:
    """Pick TP1 and TP2 from the liquidity map.

    Returns (tp1, tp2, rejection_reason).

    TARGET POLICY (operator directive, 2026-08-04): look at FAR liquidity
    first, then near -- far liquidity is better. TP2 is the level the trade
    is actually held for, so it aims at the FURTHEST real pool whose reward
    the risk justifies (rr >= min_rr), never beyond max_rr when a cap is set,
    so the pick stays a level the map actually drew. Near pools are used only
    when nothing far qualifies. Before this directive the nearest qualifying
    pool was taken, which left the move's real objective unaimed at -- the
    same gap the manual analyst flagged on 2026-07-30 when his extended target
    sat 257 points beyond the system's shipped TP2.

    TP1 stays the nearest usable real level short of TP2 (at least
    min_tp1_rr away): it books the first half and arms breakeven early, while
    the runner is aimed at the far objective. A level closer than min_tp1_rr
    is skipped rather than rejected; only if nothing usable remains does TP1
    fall back to the midpoint of the run.

    Targets are still never invented: TP2 must be an actual level from the
    liquidity map or the plan, otherwise the leg is rejected.
    """
    risk = abs(entry_price - stop_loss)
    if risk <= 0 or entry_price <= 0:
        return target_price, target_price, None

    def _rr(level: float) -> float:
        return abs(level - entry_price) / risk

    def _is_ahead(level: float) -> bool:
        return level > entry_price if direction == "BUY" else level < entry_price

    # Collect every structural level ahead of us, nearest first.
    levels: List[float] = []
    if target_price > 0 and _is_ahead(target_price):
        levels.append(target_price)
    details = (candidate or {}).get("details") or {}
    liquidity_map = details.get("liquidity") if isinstance(details, dict) else {}
    side_key = "buy_side" if direction == "BUY" else "sell_side"
    if isinstance(liquidity_map, dict):
        for raw in liquidity_map.get(side_key) or []:
            level = _safe_float(raw, 0.0)
            if level > 0 and _is_ahead(level):
                levels.append(level)
    for key in ("secondary_target", "extended_target", "next_liquidity", "target_price_2"):
        level = _safe_float((candidate or {}).get(key), 0.0)
        if level > 0 and _is_ahead(level):
            levels.append(level)

    ordered = sorted(set(levels), key=lambda lv: abs(lv - entry_price))
    # Operator directive 2026-08-07c: an approved plan is NEVER refused on
    # reward. Targets compare liquidity against stop ratios and ship the
    # FARTHER objective:
    #     TP1 = farther(0.8R of the stop, nearest pool)
    #     TP2 = farther(1.5R of the stop, farthest pool)
    # Example (operator's own): stop 270 -> ratio TP1 216~220 pts; a pool at
    # 250 is farther -> TP1 = 250. Minimums are enforced BY CONSTRUCTION;
    # nothing is rejected, so the agent-approved map always ships.
    def _dist(lv: float) -> float:
        return abs(lv - entry_price)

    def _level(rr_r: float) -> float:
        return entry_price + risk * rr_r if direction == "BUY" else entry_price - risk * rr_r

    # 2026-08-07 audit: the target law lives ONCE in utils.trading_rules.
    risk_cfg = risk_cfg or {}
    tp1, tp2, _used = _tr.targets_law(
        direction=direction, entry=entry_price,
        risk_price=abs(entry_price - stop_loss),
        levels=ordered, cfg={}, symbol=symbol, risk_cfg=risk_cfg)
    return round(tp1, 2), round(tp2, 2), None


def _stop_from_liquidity_points(
    direction: str,
    entry: float,
    candidate: Dict[str, Any] | None,
    rule_cfg: Dict[str, Any],
    symbol: str,
) -> float:
    """Thin wrapper over the single source of truth
    (utils.trading_rules.stop_from_liquidity_points). 2026-08-07 audit: the
    formula lives ONCE in the loader; every door delegates."""
    details = ((candidate or {}).get("details") or {}) if isinstance(candidate, dict) else {}
    liquidity = details.get("liquidity") or {}
    return _tr.stop_from_liquidity_points(
        direction=direction, entry=entry, liquidity_map=liquidity,
        cfg={}, symbol=symbol, rule=rule_cfg)


def _planner_trade_levels(
    config: Dict[str, Any],
    *,
    direction: str,
    entry_price: float,
    stop_loss: float,
    target_price: float,
    symbol: str,
    candidate: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    risk_cfg = (config.get("risk_settings") or {}) if isinstance(config, dict) else {}
    min_sl_points = _safe_float(risk_cfg.get("min_sl_distance_points"), 0.0)
    min_sl_distance = points_to_price(min_sl_points, symbol=symbol) if min_sl_points > 0 else 0.0
    max_rr = _safe_float(risk_cfg.get("max_rr_ratio"), 0.0)
    target_method = "mapped_target"
    floor_applied = False

    adjusted_stop = float(stop_loss)
    structural_points = abs(price_to_points(entry_price - adjusted_stop, symbol=symbol))

    # The floor exists because gold can travel 50-100 points in seconds, so a
    # stop pinned to a narrow POI is noise-bait. But a single fixed distance
    # ignores how volatile the session actually is: on XAU it engaged on every
    # plan, multiplying structural risk by up to 18x and pushing reward-to-risk
    # below the minimum even for sound setups.
    #
    # Scale it instead. The structural stop already embeds an ATR buffer, so a
    # multiple of it tracks volatility, bounded so it can neither collapse to
    # the POI width nor exceed the configured ceiling.
    # Operator directive (2026-08-07b) -- the liquidity rule for stops, same
    # arithmetic as RiskManagementAgent._stop_from_liquidity_points (ONE rule,
    # BOTH doors): ignore liquidity closer than 200 pts; stop = first eligible
    # level + 70 safety; past 400 or none -> 400 directly. Band [270, 400].
    # 2026-08-17: canonical instrument-scale stop rule (trading_rules.stop,
    # merged per instrument by config_for_instrument) — the legacy gold-point
    # block (200/70/400) shipped a $4 stop on the first WTI live trade.
    # The legacy block only retains its enabled switch.
    rule_cfg = _tr.stop_rule(config)
    _legacy_rule = (risk_cfg.get("stop_from_liquidity") or {}) if isinstance(risk_cfg, dict) else {}
    _canonical_block = ((config or {}).get("trading_rules") or {}).get("stop") or {}
    if "enabled" in _legacy_rule:
        rule_cfg["enabled"] = bool(_legacy_rule.get("enabled"))
    rule_active = bool(rule_cfg.get("enabled", False)) and bool(_canonical_block or _legacy_rule)
    if rule_active:
        structural_points = _stop_from_liquidity_points(
            direction, entry_price, candidate, rule_cfg, symbol)
        min_sl_distance = points_to_price(structural_points, symbol=symbol)
        adjusted_stop = entry_price - min_sl_distance if direction == "BUY" else entry_price + min_sl_distance
        floor_applied = True

    if not rule_active and min_sl_distance > 0 and abs(entry_price - adjusted_stop) < min_sl_distance:
        adjusted_stop = entry_price - min_sl_distance if direction == "BUY" else entry_price + min_sl_distance
        floor_applied = True

    # Targets must be anchored to structure. Widening the stop to the risk
    # floor used to trigger a purely ratio-based target (floor x ATR multiple),
    # which discarded the mapped liquidity entirely -- publishing TP1 460 pts
    # beyond a target that was only 40 pts away, and a 2.25R label on a trade
    # whose real reward-to-risk was 0.58.
    min_rr = _safe_float(risk_cfg.get("min_rr_ratio"), 1.5) or 1.5
    # 2026-08-07 phase 1: ratios/multiples/bands are read ONLY inside
    # utils.trading_rules; the doors pass the raw risk block and delegate.
    tp1, tp2, reject_reason = _resolve_reward_target(
        direction, entry_price, adjusted_stop, target_price, candidate, min_rr,
        symbol=symbol,
        risk_cfg=risk_cfg,
    )
    if reject_reason:
        return {
            "entry_price": round(entry_price, 2),
            "stop_loss": round(adjusted_stop, 2),
            "tp1": 0.0,
            "tp2": 0.0,
            "rr": 0.0,
            "floor_applied": floor_applied,
            "target_method": "rejected_insufficient_reward",
            "reject_reason": reject_reason,
            "min_sl_distance_points": round(min_sl_points, 1),
        }
    if tp2 != target_price:
        target_method = "extended_liquidity"
    if floor_applied and target_method == "mapped_target":
        target_method = "mapped_target_with_floored_sl"

    # 2026-08-07 audit: the max_rr cap is removed here as well -- with the
    # liquidity rule (stop >= 270 pts) it is mathematically inert, and as a
    # directive the operator's band/double rule is the only target law.
    risk = abs(adjusted_stop - entry_price)
    rr = abs(tp2 - entry_price) / risk if risk > 0 else 0.0
    return {
        "entry_price": round(entry_price, 2),
        "stop_loss": round(adjusted_stop, 2),
        "tp1": round(tp1, 2),
        "tp2": round(tp2, 2),
        "rr": round(rr, 2),
        "floor_applied": floor_applied,
        "target_method": target_method,
        "min_sl_distance_points": round(min_sl_points, 1),
    }



def _max_pending_distance_points(config: Dict[str, Any]) -> float:
    """Furthest a resting order may sit from the market, in points.

    Derived from the map's own geometry rather than a new invented number:
    ``session_planner.max_primary_zone_width_points`` is the widest zone the
    planner is allowed to publish, so an entry further away than that cannot
    be a mapped level -- there is no zone that reaches it.

    Set ``execution_guards.max_pending_distance_points`` to override, or 0 to
    disable the check.
    """
    guards = (config.get("execution_guards") or {}) if isinstance(config, dict) else {}
    if "max_pending_distance_points" in guards:
        return max(0.0, _safe_float(guards.get("max_pending_distance_points"), 0.0))
    planner = (config.get("session_planner") or {}) if isinstance(config, dict) else {}
    return max(0.0, _safe_float(planner.get("max_primary_zone_width_points"), 450.0))


def _unreachable_pending_violation(
    decision: Dict[str, Any], config: Dict[str, Any]
) -> str | None:
    """Refuse a resting order the market would have to travel absurdly far to fill.

    2026-07-31, 13:16 UTC. With SELL d917b1d5 already live and deep in
    profit, the system published TRADE_..._6e31ddf6: a SELL LIMIT at 4076.93
    while price was 4023.21 -- 537 points ABOVE a market that was collapsing
    toward the very target its own live trade was about to hit. Thirty
    minutes later it cancelled the order itself: "market covered 61% of
    target path without fill".

    The cancellation was right. The placement was the fault. That order could
    only ever fill on a 537-point rally against the system's own winning
    thesis, and while it sat there it occupied the map.

    Distance is measured to the entry the order will actually rest at, and
    only in the direction that would have to be travelled to reach it. An
    entry the market has already passed through is a different case entirely
    and is left to the normal fill logic.
    """
    limit = _max_pending_distance_points(config)
    if limit <= 0:
        return None

    side = str(decision.get("decision") or "").upper()
    if side not in {"BUY", "SELL"}:
        return None
    signal = decision.get("signal") or {}
    if not isinstance(signal, dict):
        return None

    order_type = str(signal.get("order_type") or "").upper()
    if order_type.endswith("MARKET"):
        return None

    symbol = str(decision.get("symbol") or config.get("symbol", "XAU/USD"))
    entry_info = signal.get("entry") or {}
    entry = _safe_float(entry_info.get("price") if isinstance(entry_info, dict) else None, 0.0)
    current = _safe_float(decision.get("current_price"), 0.0)
    if entry <= 0 or current <= 0:
        return None

    # Points the market must travel to reach the resting entry. A SELL LIMIT
    # sits above the market and needs a rally; a BUY LIMIT sits below and
    # needs a decline. Anything on the other side is already reachable.
    if side == "SELL":
        travel = price_to_points(entry - current, symbol=symbol)
    else:
        travel = price_to_points(current - entry, symbol=symbol)
    if travel <= 0:
        return None
    if travel <= limit:
        return None

    return (
        f"resting {side} entry {entry:.2f} is {travel:.0f} pts from the market "
        f"at {current:.2f}, beyond the {limit:.0f}-pt reach of the widest "
        "mapped zone; it could only fill on a move that would invalidate the "
        "setup it is based on"
    )


def _queue_opposite_exposure_exit(
    decision: Dict[str, Any],
    open_trades: List[Dict[str, Any]],
    database: DatabaseService,
    config: Dict[str, Any],
) -> List[str]:
    """Queue broker-first closure before an accepted opposite entry.

    Called only at the final order boundary, after every admission/validation
    gate has passed. The new row carries dependencies so TickManager cannot
    place it until the old MT5 positions have actually disappeared.
    """
    guard = (config.get("opposite_entry_guard") or {}) if isinstance(config, dict) else {}
    if not bool(guard.get("enabled", True)):
        return []
    side = str(decision.get("decision") or "").upper()
    symbol = normalize_symbol(decision.get("symbol") or config.get("symbol", "XAU/USD"))
    if side not in {"BUY", "SELL"}:
        return []
    opposite = "SELL" if side == "BUY" else "BUY"
    live_ids: List[str] = []
    pending_ids: List[str] = []
    for trade in open_trades or []:
        if normalize_symbol(trade.get("symbol") or symbol) != symbol:
            continue
        trade_side = str(trade.get("type") or trade.get("side") or "").upper()
        if trade_side != opposite:
            continue
        status = str(trade.get("status") or "").upper()
        tid = str(trade.get("id") or "")
        if not tid:
            continue
        if status in {"OPEN", "PARTIAL", "TP1_HIT"}:
            database.update_trade(tid, {
                "requested_exit": True,
                "requested_exit_reason": "OPPOSITE_ENTRY_FLIP",
                "flip_target_side": side,
                "flip_target_trade_id": decision.get("trade_id"),
            })
            live_ids.append(tid)
        elif status == "PENDING":
            database.update_trade(tid, {
                "status": "CANCELLED", "result": "CANCELLED",
                "reasons": [f"Cancelled before accepted opposite {side} entry"],
                "last_updated": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
            })
            pending_ids.append(tid)
    if live_ids:
        decision["opposite_exit_required"] = True
        decision["opposite_trade_ids"] = live_ids
        decision.setdefault("reasons", []).append(
            f"Broker-first flip guard: close {len(live_ids)} live {opposite} position(s) before {side}")
    if pending_ids:
        decision["opposite_pending_cancelled_ids"] = pending_ids
    return live_ids


def _counter_to_live_winner_violation(
    decision: Dict[str, Any],
    config: Dict[str, Any],
    open_trades: List[Dict[str, Any]] | None,
) -> str | None:
    """Refuse a resting order that is a bet against the system's own winner.

    The same 2026-07-31 incident from the other side. A SELL LIMIT placed
    537 points above the market fills only if price rallies that far -- which
    is precisely the move that would have destroyed the live SELL then
    running to its target. The system was, in effect, hedging against its own
    correct call while that call was winning.

    Narrow by construction. It only refuses a *resting* order in the *same
    direction* as a live trade that is *already in profit* and whose entry
    the new order sits *worse than*. A genuine pyramid -- adding at a better
    price, or scaling a loser's recovery -- is untouched, and a market order
    is never blocked.
    """
    guards = (config.get("execution_guards") or {}) if isinstance(config, dict) else {}
    if guards.get("block_pending_behind_live_winner") is False:
        return None

    side = str(decision.get("decision") or "").upper()
    if side not in {"BUY", "SELL"}:
        return None
    signal = decision.get("signal") or {}
    if not isinstance(signal, dict):
        return None
    if str(signal.get("order_type") or "").upper().endswith("MARKET"):
        return None

    symbol = str(decision.get("symbol") or config.get("symbol", "XAU/USD"))
    normalized = normalize_symbol(symbol)
    entry_info = signal.get("entry") or {}
    entry = _safe_float(entry_info.get("price") if isinstance(entry_info, dict) else None, 0.0)
    if entry <= 0:
        return None

    for trade in open_trades or []:
        if normalize_symbol(trade.get("symbol") or symbol) != normalized:
            continue
        if str(trade.get("status") or "").upper() not in {"OPEN", "PARTIAL", "TP1_HIT"}:
            continue
        if str(trade.get("type") or trade.get("side") or "").upper() != side:
            continue
        live_pnl = _safe_float(
            trade.get("current_pnl_points", trade.get("current_pnl")), 0.0
        )
        if live_pnl <= 0:
            continue
        live_entry = _safe_float(trade.get("entry_price"), 0.0)
        if live_entry <= 0:
            continue
        # "Worse than" the live entry: for a SELL that means higher (needs a
        # rally against the winner); for a BUY, lower.
        worse = entry > live_entry if side == "SELL" else entry < live_entry
        if not worse:
            continue
        gap = abs(price_to_points(entry - live_entry, symbol=symbol))
        return (
            f"resting {side} entry {entry:.2f} sits {gap:.0f} pts worse than live "
            f"{side} {trade.get('id') or ''} (entry {live_entry:.2f}, +{live_pnl:.0f} pts "
            "open); it can only fill on the move that would end the winning trade"
        ).replace("  ", " ")
    return None


def _rejected_setup_execution_block(
    decision: Dict[str, Any], config: Dict[str, Any]
) -> str | None:
    """Refuse to trade a setup the SMC agent ranked and declined.

    ``selection_role`` carries SMCAgent's verdict on its own candidates.
    REJECTED means it was ranked and not chosen -- neither the primary thesis
    nor a qualifying standby. Publishing one is trading a setup the agent that
    discovered it did not believe in.

    2026-07-31, TRADE_20260731_152110_326407_a5520ee6: a SELL LIMIT went out
    with "role REJECTED · quality C · dominance 47.6 · reach 40.8". The
    planner would have refused it at two separate floors
    (min_primary_dominance 50, min_return_probability 42); the dual-agent path
    does not run those floors, so nothing stopped it.

    This is a quality gate, not a risk gate: no stop, target, size or ratio is
    affected. Set ``execution_guards.allow_rejected_setups: true`` to restore
    the previous behaviour.
    """
    guards = (config.get("execution_guards") or {}) if isinstance(config, dict) else {}
    if guards.get("allow_rejected_setups") is True:
        return None

    side = str(decision.get("decision") or "").upper()
    if side not in {"BUY", "SELL"}:
        return None

    setup = decision.get("setup_context") or {}
    if not isinstance(setup, dict):
        return None
    role = str(setup.get("selection_role") or "").upper()
    # No role at all means the snapshot predates the labelling; do not block
    # on an absence of information.
    if not role or role in _SELECTED_SETUP_ROLES:
        return None

    dominance = _safe_float(setup.get("thesis_dominance_score"), 0.0)
    reach = _safe_float(setup.get("return_probability_score"), 0.0)
    return (
        f"setup was ranked {role} by the SMC agent — it was not chosen as the "
        f"primary thesis or a qualifying standby (dominance {dominance:.1f}, "
        f"return probability {reach:.1f}); trading it overrides the agent that "
        "found it"
    )


def validate_signal_before_send(
    decision: Dict[str, Any],
    config: Dict[str, Any],
    open_trades: List[Dict[str, Any]] | None = None,
    all_results: Dict[str, Any] | None = None,
) -> List[str]:
    """Final arithmetic check on a finished signal. Returns violations.

    Every execution fault found so far was individually invisible and jointly
    obvious: a first target 5 points from entry against a 150-point stop, a
    protection threshold that could never be reached before that target, a
    stop distance quoted from config rather than from the trade, a thesis
    whose stated objective sat on the wrong side of the entry.

    None of them needed market knowledge to catch -- only for someone to
    check the finished numbers against each other once. That is what this
    does, at the single point where a signal becomes real.

    A non-empty list means the signal is arithmetically incoherent and must
    not be sent or saved. It is deliberately not a strategy opinion: it only
    rejects what cannot be true.
    """
    violations: List[str] = []

    side = str(decision.get("decision") or "").upper()
    if side not in {"BUY", "SELL"}:
        return violations

    symbol = str(decision.get("symbol") or config.get("symbol", "XAU/USD"))
    signal = decision.get("signal") or {}
    if not isinstance(signal, dict) or not signal:
        return ["signal payload is missing"]

    entry_info = signal.get("entry") or {}
    entry = _safe_float(entry_info.get("price") if isinstance(entry_info, dict) else None, 0.0)
    if entry <= 0:
        entry = _safe_float(decision.get("current_price"), 0.0)
    stop = _safe_float(signal.get("stop_loss"), 0.0)
    tp1 = _safe_float(signal.get("tp1"), 0.0)
    tp2 = _safe_float(signal.get("tp2"), 0.0)

    if entry <= 0 or stop <= 0:
        return [f"entry ({entry}) and stop ({stop}) must both be positive"]

    ahead = (lambda level: level > entry) if side == "BUY" else (lambda level: level < entry)
    behind = (lambda level: level < entry) if side == "BUY" else (lambda level: level > entry)

    # 1. Geometry. A stop on the wrong side is not a stop.
    if not behind(stop):
        violations.append(
            f"stop {stop:.2f} is not protective for a {side} entered at {entry:.2f}"
        )
    for label, level in (("tp1", tp1), ("tp2", tp2)):
        if level > 0 and not ahead(level):
            violations.append(
                f"{label} {level:.2f} is not ahead of a {side} entered at {entry:.2f}"
            )

    risk_points = abs(price_to_points(entry - stop, symbol=symbol))
    if risk_points <= 0:
        violations.append("risk distance is zero; the stop sits on the entry")
        return violations

    # 2. Reward. Reaching TP1 arms the breakeven stop, so a token first target
    #    converts a correct call into a flat trade.
    risk_cfg = (config.get("risk_settings") or {}) if isinstance(config, dict) else {}
    min_tp1_rr = _tr.target_ratios(config or {}, default_min_tp1_rr=0.0)["min_tp1_rr"]
    min_rr = _safe_float(risk_cfg.get("min_rr_ratio"), 0.0)
    # R25.4 (operator 2026-08-28): a SCALP row is judged by its OWN RR
    # contract - its geometry is fixed-stop with a midpoint partial and a
    # pending-level final, so the day-trade floors (0.8R / 1.5R) do not
    # describe it. The floors live in the rules loader (single source of
    # truth); paths 1-6 keep the global pair exactly as it is.
    if (decision.get("setup_context") or {}).get("r25_scalp"):
        _scalp_rr = _tr.scalp_rr_floors(config or {})
        min_tp1_rr = _safe_float(_scalp_rr["min_tp1_rr"], min_tp1_rr)
        min_rr = _safe_float(_scalp_rr["min_tp2_rr"], min_rr)
    tp1_rr = abs(price_to_points(tp1 - entry, symbol=symbol)) / risk_points if tp1 > 0 else 0.0
    tp2_rr = abs(price_to_points(tp2 - entry, symbol=symbol)) / risk_points if tp2 > 0 else 0.0

    if min_tp1_rr > 0 and tp1 > 0 and tp1_rr < min_tp1_rr:
        violations.append(
            f"tp1 is only {tp1_rr:.2f}R from entry (minimum {min_tp1_rr:.2f}R); "
            "reaching it would arm breakeven before the trade has travelled"
        )
    if min_rr > 0 and tp2 > 0 and tp2_rr < min_rr:
        violations.append(f"tp2 is only {tp2_rr:.2f}R from entry (minimum {min_rr:.2f}R)")
    if tp1 > 0 and tp2 > 0 and abs(tp2 - entry) < abs(tp1 - entry):
        violations.append("tp2 is nearer than tp1")

    # 3. Coherence between protection and the first target.
    #
    # Two wirings exist, and the check must judge the one that actually runs:
    #   * auto_move_sl_to_entry_after_tp1 (the wired promise): on a TP1 touch
    #     the stop moves to entry whatever TP1's value, so a "breakeven beyond
    #     TP1" ordering contradiction cannot arise. What must hold instead is
    #     that TP1 is far enough for the manager's R-guard (min_breakeven_rr)
    #     to let the touch arm the stop -- otherwise TP1 hits, the partial
    #     books, and the promised protection still does not apply.
    #   * legacy distance-only breakeven (auto_be false): a +N trigger beyond
    #     TP1 can never fire before the target it claims to precede.
    #
    # The 2026-08-04 A+ 97.8% map died under the old text: TP1 140.5 pts away
    # against a 150-pt trigger -- refused -- while the manager would have
    # armed breakeven at TP1 anyway. The validator judged a promise the
    # engine no longer exclusively makes.
    tm_cfg = (config.get("trade_management") or {}) if isinstance(config, dict) else {}
    breakeven_points = _safe_float(tm_cfg.get("early_breakeven_points"), 0.0)
    tp1_points = abs(price_to_points(tp1 - entry, symbol=symbol)) if tp1 > 0 else 0.0
    auto_be_at_tp1 = bool(tm_cfg.get("auto_move_sl_to_entry_after_tp1", True))
    if auto_be_at_tp1:
        min_be_rr = _safe_float(tm_cfg.get("min_breakeven_rr"), 0.0)
        if tp1 > 0 and min_be_rr > 0 and risk_points > 0 and tp1_rr < min_be_rr:
            violations.append(
                f"tp1 is only {tp1_rr:.2f}R away; the manager arms breakeven at TP1 "
                f"only from {min_be_rr:.2f}R travelled, so the promised protection "
                "would not apply"
            )
    elif breakeven_points > 0 and tp1_points > 0 and breakeven_points >= tp1_points:
        violations.append(
            f"breakeven trigger (+{breakeven_points:.0f} pts) is not reachable before "
            f"tp1 ({tp1_points:.0f} pts away); the promised protection cannot apply"
        )

    # 4. Reachability. A resting order the market cannot plausibly reach is
    #    not a plan, and one that can only fill by destroying a live winner is
    #    a bet against the system's own thesis. Both were published on
    #    2026-07-31 as a single SELL LIMIT 537 pts above a collapsing market.
    unreachable = _unreachable_pending_violation(decision, config)
    if unreachable:
        violations.append(unreachable)
    counter_bet = _counter_to_live_winner_violation(decision, config, open_trades)
    if counter_bet:
        violations.append(counter_bet)

    # 5. Provenance. A setup the SMC agent ranked and declined must not be
    #    traded, whatever its arithmetic looks like.
    rejected_setup = _rejected_setup_execution_block(decision, config)
    if rejected_setup:
        violations.append(rejected_setup)

    # 6. Path 4 is a resting LIMIT at the exact admitted SMC POI. This final
    # invariant catches persisted/revived decisions and prevents any later
    # adaptive layer from silently promoting it to MARKET.
    if str(decision.get("execution_path_id") or "") == PATH_4:
        order_type = str(signal.get("order_type") or entry_info.get("order_type") or "").upper()
        if not order_type.endswith("LIMIT"):
            violations.append("Path 4 permits LIMIT only at the SMC POI; MARKET chasing is forbidden")
        gate = decision.get("planner_execution_gate") or {}
        expected_entry = _safe_float(gate.get("smc_map_entry_price"), 0.0) if isinstance(gate, dict) else 0.0
        if expected_entry > 0 and abs(entry - expected_entry) > 0.011:
            violations.append(
                f"Path 4 entry {entry:.2f} differs from admitted SMC POI {expected_entry:.2f}"
            )

    # 7. R26 admission-discipline gates (fail-open, config-driven). These
    #    refuse the live loss pattern: a direction the macro opposes at high
    #    confidence while the tape cannot witness (dead/refused) and SMC is not
    #    a qualified supporter; a single trend "family" masquerading as
    #    consensus over a dead tape; a stop outside the documented per-symbol
    #    band; and a tp2 under the configured R:R floor. They only reject -
    #    they never change numbers, weights, or the regime switcher.
    try:
        from services.admission_discipline_gates import discipline_violations as _disc_violations
        violations.extend(_disc_violations(decision, config, all_results))
    except Exception as _disc_exc:  # noqa: BLE001 - fail-open if the module is absent
        logger.warning("Discipline gates skipped (fail-open): %s", _disc_exc)

    return violations


def apply_target_distance_caps(
    decision: Dict[str, Any],
    config: Dict[str, Any],
) -> Dict[str, Any]:
    """BUILD 18 (2026-08-20): per-instrument absolute target distance caps.

    Applied at the single point where a signal becomes real, for EVERY entry
    path (planner ladder, dual-agent, revived plans). Gold's target law ships
    liquidity objectives ~2% away; on WTI the same philosophy shipped TP2
    477 pts (5.5% of price) from round-number pools. WTI caps
    (max_tp1_points=150 ~2x ATR1h, max_tp2_points=350 ~1 daily ATR) pull the
    structure back to the law's own fallbacks: TP1 -> 0.8R rung, TP2 -> 2x
    TP1 distance. No cap key (0) = historical behaviour unchanged (gold).
    """
    if not isinstance(decision, dict):
        return decision
    side = str(decision.get("decision") or "").upper()
    if side not in {"BUY", "SELL"}:
        return decision
    signal = decision.get("signal") or {}
    if not isinstance(signal, dict) or not signal:
        return decision
    entry_info = signal.get("entry")
    entry = _safe_float(entry_info.get("price") if isinstance(entry_info, dict) else None, 0.0)
    if entry <= 0:
        entry = _safe_float(signal.get("entry_price"), 0.0)
    stop = _safe_float(signal.get("stop_loss"), 0.0)
    tp1 = _safe_float(signal.get("tp1"), 0.0)
    tp2 = _safe_float(signal.get("tp2"), 0.0)
    if entry <= 0 or stop <= 0 or tp1 <= 0 or tp2 <= 0:
        return decision
    targets_cfg = ((config or {}).get("trading_rules") or {}).get("targets") or {}
    max_tp1_pts = _safe_float(targets_cfg.get("max_tp1_points"), 0.0)
    max_tp2_pts = _safe_float(targets_cfg.get("max_tp2_points"), 0.0)
    if max_tp1_pts <= 0 and max_tp2_pts <= 0:
        return decision
    symbol = str(decision.get("symbol") or config.get("symbol") or "XAU/USD")
    risk = abs(entry - stop)
    if risk <= 0:
        return decision

    def _away(dist: float) -> float:
        return entry + dist if side == "BUY" else entry - dist

    changed = False
    if max_tp1_pts > 0:
        cap1 = points_to_price(max_tp1_pts, symbol=symbol)
        if abs(tp1 - entry) > cap1:
            tp1 = _away(risk * 0.8)
            changed = True
    if max_tp2_pts > 0:
        cap2 = points_to_price(max_tp2_pts, symbol=symbol)
        if abs(tp2 - entry) > cap2:
            tp2 = _away(2.0 * abs(tp1 - entry))
            changed = True
    if abs(tp2 - entry) < abs(tp1 - entry):
        tp2 = tp1
        changed = True
    if not changed:
        return decision
    signal["tp1"] = round(tp1, 2)
    signal["tp2"] = round(tp2, 2)
    signal["rr_ratio"] = round(abs(tp2 - entry) / risk, 2)
    signal["tp1_rr"] = round(abs(tp1 - entry) / risk, 2)
    signal["tp2_rr"] = round(abs(tp2 - entry) / risk, 2)
    signal["target_cap_applied"] = True
    signal["target_cap_note"] = (
        f"{symbol} target distance capped (max_tp1={max_tp1_pts:.0f}, "
        f"max_tp2={max_tp2_pts:.0f} pts oil scale)"
    )
    decision["signal"] = signal
    logger.info(
        "Target distance caps applied for %s %s: tp1=%.2f tp2=%.2f (cap %.0f/%.0f pts)",
        symbol, side, tp1, tp2, max_tp1_pts, max_tp2_pts,
    )
    return decision


def _candidate_zone_bounds(candidate: Dict[str, Any]) -> tuple[float, float] | None:
    zone = candidate.get("poi_zone") or {}
    if isinstance(zone, dict) and zone.get("top") is not None and zone.get("bottom") is not None:
        low = _safe_float(zone.get("bottom"), 0.0)
        high = _safe_float(zone.get("top"), 0.0)
        if low > 0 and high > 0:
            return min(low, high), max(low, high)
    low = _safe_float(candidate.get("poi_low"), 0.0)
    high = _safe_float(candidate.get("poi_high"), 0.0)
    if low > 0 and high > 0:
        return min(low, high), max(low, high)
    return None



def _zone_progress_pct(direction: str, current_price: float, low: float, high: float) -> float:
    width = max(high - low, 0.0001)
    if direction == "SELL":
        return max(0.0, min(100.0, ((current_price - low) / width) * 100.0))
    return max(0.0, min(100.0, ((high - current_price) / width) * 100.0))



def _split_execution_cfg(config: Dict[str, Any]) -> Dict[str, Any]:
    return (config.get("split_execution") or {}) if isinstance(config, dict) else {}


def _r24_gates_cfg(config: Dict[str, Any]) -> Dict[str, Any]:
    """R24 (2026-08-28) gate switches. Defaults ON - the operator's laws."""
    cfg = (config or {}).get("r24_gates") or {}
    out = {
        "enabled": True,
        "risk_veto_supremacy": True,
        "trigger_supremacy": True,
        "trigger_market_states": ["REJECTION_CONFIRMED"],
        "range_gate_enabled": True,
        "range_market_phases": ["RANGING"],
        "range_max_adx": 25.0,
        "range_premium_pct": 0.70,
        "snapshot_lock_enabled": True,
        "snapshot_lock_points": 30.0,
        "snapshot_lock_hours": 12.0,
    }
    if isinstance(cfg, dict):
        out.update({k: v for k, v in cfg.items() if k in out})
        for sub in ("range_gate", "snapshot_lock"):
            block = cfg.get(sub) or {}
            if isinstance(block, dict):
                out.update({k: v for k, v in block.items() if k in out})
    return out


def r24_risk_veto_reason(decision: Dict[str, Any], config: Dict[str, Any]) -> str | None:
    """R24-0: the risk agent's veto binds EVERY execution path.

    Live incident 2026-08-27 19:01: a session-plan ladder leg executed
    BUY_MARKET 4612.56 while the same decision carried
    risk.approved=false, trade_grade F (39/100), label "Reject",
    risk_multiplier 0.0. The shared-admission gate (PATH 2) never
    consulted it. Now: approved=false on the decision blocks the ladder.
    """
    g = _r24_gates_cfg(config)
    if not (g["enabled"] and g["risk_veto_supremacy"]):
        return None
    risk = decision.get("risk") if isinstance(decision.get("risk"), dict) else {}
    if not risk or risk.get("approved") is not False:
        return None
    grade = ((risk.get("risk_metrics") or {}).get("trade_grade")
             or risk.get("trade_grade") or {})
    label = ("grade {0} {1}".format(grade.get("grade"), grade.get("score"))
             if grade else "grade n/a")
    return "R24-0 RISK-VETO: risk agent refused the trade ({0}) - {1}".format(
        label, risk.get("rejection_reason") or "not approved")


def r24_trigger_market_reason(candidate: Dict[str, Any],
                              config: Dict[str, Any]) -> str | None:
    """R24-1: agent admission is PERMISSION; the setup trigger owns TIMING.

    The incident leg converted to MARKET with trigger_ready=false and
    trigger_state=TOUCH_NO_REJECTION while its own strategy profile
    demands REJECTION_CONFIRMED. A touch is not a rejection.
    """
    g = _r24_gates_cfg(config)
    if not (g["enabled"] and g["trigger_supremacy"]):
        return None
    has_metadata = ("trigger_state" in candidate) or ("trigger_ready" in candidate)
    if not has_metadata:
        # A setup that never carried trigger semantics is not governed by
        # this gate (and production is protected by the R24-2 config kill
        # regardless). Any setup WITH metadata - like the incident map - is
        # fully governed.
        return None
    ready = bool(candidate.get("trigger_ready"))
    state = str(candidate.get("trigger_state") or "").upper()
    allowed = {str(x).upper() for x in (g["trigger_market_states"] or [])}
    if ready or (state and state in allowed):
        return None
    return ("R24-1 TRIGGER-SUPREMACY: market execution needs trigger_ready "
            "or {0}; this setup is {1}".format(
                "/".join(sorted(allowed)) or "a confirmed trigger",
                state or "UNSPECIFIED"))


def _r24_known_range(base_decision: Dict[str, Any]) -> tuple[float, float]:
    """The dealing range this cycle actually knows (R24-3 source of truth)."""
    dr = (((base_decision.get("agent_details") or {}).get("smc") or {})
          .get("conditional_map") or {})
    dr = (dr.get("details") or {}).get("dealing_range") or {}
    hi = _safe_float(dr.get("high"), 0.0)
    lo = _safe_float(dr.get("low"), 0.0)
    if hi <= 0 or lo <= 0 or hi <= lo:
        hi = _safe_float(base_decision.get("range_high"), 0.0)
        lo = _safe_float(base_decision.get("range_low"), 0.0)
    return hi, lo


def r24_range_chase_reason(base_decision: Dict[str, Any],
                           candidate: Dict[str, Any], direction: str,
                           entry_price: float, config: Dict[str, Any]) -> str | None:
    """R24-3: no momentum chase deep inside a ranging range.

    Incident: BUY at 4612.56 = 77% of the dealing range [4588.83-4616.73],
    market_phase RANGING, ADX 21.9 - bought the TOP of the range while
    Classical painted Head&Shoulders. Gate applies to chase entries in a
    configured phase with ADX under the ceiling: BUY above the premium
    pct, SELL below (1 - premium pct).
    """
    g = _r24_gates_cfg(config)
    if not (g["enabled"] and g["range_gate_enabled"]):
        return None
    direction = str(direction or "").upper()
    if direction not in {"BUY", "SELL"} or not entry_price:
        return None
    regime = ((base_decision.get("market_context") or {}).get("technical_regime") or {})
    phase = str(regime.get("market_phase") or "").upper()
    allowed_phases = {str(x).upper() for x in (g["range_market_phases"] or [])}
    if phase and allowed_phases and phase not in allowed_phases:
        return None
    adx = regime.get("adx_value")
    if adx is not None:
        try:
            if float(adx) >= float(g["range_max_adx"]):
                return None
        except (TypeError, ValueError):
            pass
    hi, lo = _r24_known_range(base_decision)
    if hi <= 0 or lo <= 0 or hi <= lo:
        return None  # no range knowledge -> gate abstains honestly
    span = hi - lo
    pct = (float(entry_price) - lo) / span
    premium = float(g["range_premium_pct"])
    if direction == "BUY" and pct >= premium:
        return ("R24-3 RANGE-GATE: BUY chase at {0:.0f}% of the {1} range "
                "[{2:.2f}-{3:.2f}] (premium floor {4:.0f}%)".format(
                    pct * 100.0, phase or "RANGE", lo, hi, premium * 100.0))
    if direction == "SELL" and pct <= (1.0 - premium):
        return ("R24-3 RANGE-GATE: SELL chase at {0:.0f}% of the {1} range "
                "[{2:.2f}-{3:.2f}] (discount ceiling {4:.0f}%)".format(
                    pct * 100.0, phase or "RANGE", lo, hi,
                    (1.0 - premium) * 100.0))
    return None


def r24_snapshot_lock_reason(rows: List[Dict[str, Any]], symbol: str,
                             side: str, entry_price: float,
                             config: Dict[str, Any], now: float | None = None) -> str | None:
    """R24-4: the SNAPSHOT LOCK - a cancelled pending keeps its price.

    Incident: BUY_LIMIT 4571.84 cancelled at 16:46; at 19:01 the ladder
    bought 4612.56 - 40.7 pts WORSE - with no memory of the cancelled
    level. Now, for `snapshot_lock_hours` after a same-side LIMIT is
    cancelled/expired at price P, a same-side entry worse than
    P +/- snapshot_lock_points is refused. Better/equal prices stay free
    (the pullback returning to the mapped level is a gift, not a crime).
    """
    import time as _t
    from datetime import datetime as _dt
    g = _r24_gates_cfg(config)
    if not (g["enabled"] and g["snapshot_lock_enabled"]):
        return None
    now = float(now if now is not None else _t.time())
    side = str(side or "").upper()
    if side not in {"BUY", "SELL"} or not entry_price:
        return None
    horizon = now - float(g["snapshot_lock_hours"]) * 3600.0
    points = float(g["snapshot_lock_points"])
    for row in (rows or []):
        try:
            if normalize_symbol(row.get("symbol") or "") != normalize_symbol(symbol):
                continue
            otype = str(row.get("order_type") or row.get("type") or "").upper()
            status = str(row.get("status") or "").upper()
            if not otype.endswith("LIMIT"):
                continue
            if status not in {"CANCELLED", "EXPIRED", "REJECTED"}:
                continue
            row_side = ("BUY" if otype.startswith("BUY")
                        else "SELL" if otype.startswith("SELL") else "")
            if row_side != side:
                continue
            ts = str(row.get("opened_at") or row.get("created_at") or "")
            if not ts:
                continue
            t = _dt.fromisoformat(ts.replace("Z", "+00:00")).timestamp()
            if t < horizon:
                continue
            p = _safe_float(row.get("entry_price"), 0.0)
            if p <= 0:
                continue
            if side == "BUY" and float(entry_price) > p + points:
                return ("R24-4 SNAPSHOT-LOCK: BUY at {0:.2f} is {1:.1f} pts worse "
                        "than the cancelled pending {2:.2f} (lock {3:.0f} pts, "
                        "{4:.0f}h)".format(float(entry_price),
                                           float(entry_price) - p, p, points,
                                           float(g["snapshot_lock_hours"])))
            if side == "SELL" and float(entry_price) < p - points:
                return ("R24-4 SNAPSHOT-LOCK: SELL at {0:.2f} is {1:.1f} pts worse "
                        "than the cancelled pending {2:.2f} (lock {3:.0f} pts, "
                        "{4:.0f}h)".format(float(entry_price),
                                           p - float(entry_price), p, points,
                                           float(g["snapshot_lock_hours"])))
        except Exception:  # noqa: BLE001 - one bad row never kills the gate
            continue
    return None



def _r25_scalp_cfg(config: Dict[str, Any]) -> Dict[str, Any]:
    """R25-2 scalp-fade configuration with safe defaults."""
    cfg = (config.get("r25_scalp") or {}) if isinstance(config, dict) else {}
    return {
        "enabled": bool(cfg.get("enabled", True)),
        "mode": "live",  # R26.7: scalp always executes; shadow mode removed
        "min_family_conf": float(cfg.get("min_family_conf", 70.0) or 70.0),
        "premium_min": float(cfg.get("premium_min", 0.70) or 0.70),
        "retest_pct": float(cfg.get("retest_pct", 0.80) or 0.80),
        # R25.4 (operator 2026-08-28 night): the stop is a FIXED 350 SYSTEM
        # points ($35 on gold - the incident's own unit: 307.3 pts = $30.73),
        # the final target is the OPPOSITE PENDING level, or - when no such
        # level is known - derived from the stop (2R = 700 pts) as before;
        # the partial close sits at the MIDPOINT of entry->final distance.
        "stop_points": float(cfg.get("stop_points", 350.0) or 350.0),
        "final_rr_fallback": float(cfg.get("final_rr_fallback", 2.0) or 2.0),
        "t1_close_fraction": float(cfg.get("t1_close_fraction", 0.50) or 0.50),
        "trail_dist_pct": float(cfg.get("trail_dist_pct", 0.35) or 0.35),
        "ttl_minutes": float(cfg.get("ttl_minutes", 45.0) or 45.0),
        "time_stop_minutes": float(cfg.get("time_stop_minutes", 60.0) or 60.0),
        "trigger_states": [str(x).upper() for x in
                           (cfg.get("trigger_states") or ["REJECTION_CONFIRMED"])],
        "max_adx": float(cfg.get("max_adx", 25.0) or 25.0),
        "market_phases": [str(x).upper() for x in
                          (cfg.get("market_phases") or ["RANGING"])],
    }


def r25_scalp_fade_plan(base_decision: Dict[str, Any], config: Dict[str, Any],
                        *, trigger_state: str = "", price: float = 0.0,
                        plan_buy_entry: float = 0.0,
                        plan_sell_entry: float = 0.0) -> Dict[str, Any]:
    """R25-2: the premium-fade SCALP plan (operator-approved 3-tier design).

    SELL at the premium / BUY at the discount of a KNOWN RANGING range when
    the two independent families agree (classical + smc >= min_family_conf),
    the trend reader (MTF) is neutral, and a confirmed rejection trigger
    fired at the extreme. Returns {"ok": True, "side", "plan"} or
    {"ok": False, "reason"}. The plan never chases: the LIMIT rests at the
    retest band and the runner's hard cap is the opposing planned level
    (the hand-off), never beyond it.
    """
    g = _r25_scalp_cfg(config)
    if not g["enabled"]:
        return {"ok": False, "reason": "R25-2 disabled"}
    regime = ((base_decision.get("market_context") or {}).get("technical_regime") or {})
    phase = str(regime.get("market_phase") or "").upper()
    if g["market_phases"] and phase and phase not in g["market_phases"]:
        return {"ok": False, "reason": f"phase {phase or 'UNKNOWN'} not range-fade weather"}
    adx = regime.get("adx_value")
    if adx is not None:
        try:
            if float(adx) > g["max_adx"]:
                return {"ok": False, "reason": f"ADX {float(adx):.1f} above {g['max_adx']:.0f}"}
        except (TypeError, ValueError):
            pass
    details = base_decision.get("agent_details") or {}
    def _conf(name: str) -> tuple[str, float]:
        row = details.get(name) or {}
        d = str(row.get("direction") or "").upper()
        try:
            return d, float(row.get("confidence") or 0.0)
        except (TypeError, ValueError):
            return d, 0.0
    cl_d, cl_c = _conf("classical")
    smc_d, smc_c = _conf("smc")
    minf = g["min_family_conf"]
    side = ""
    if cl_d == smc_d and cl_d in {"BUY", "SELL"} and min(cl_c, smc_c) >= minf:
        side = cl_d
    else:
        return {"ok": False, "reason":
                f"no two-family agreement (classical {cl_d} {cl_c:.0f}, smc {smc_d} {smc_c:.0f})"}
    mtf_d, mtf_c = _conf("multitimeframe")
    if mtf_d in {"BUY", "SELL"} and mtf_c >= 65.0:
        return {"ok": False, "reason": f"MTF directional {mtf_d} {mtf_c:.0f} - no fade against trend"}
    hi, lo = _r24_known_range(base_decision)
    if hi <= 0 or lo <= 0 or hi <= lo:
        return {"ok": False, "reason": "no known range - abstain honestly"}
    span = hi - lo
    px = _safe_float(price or base_decision.get("current_price"), 0.0)
    if px <= 0:
        return {"ok": False, "reason": "no price"}
    pct = (px - lo) / span
    if side == "SELL":
        if pct < g["premium_min"]:
            return {"ok": False, "reason": f"price at {pct * 100:.0f}% - premium floor {g['premium_min'] * 100:.0f}%"}
    else:
        if pct > (1.0 - g["premium_min"]):
            return {"ok": False, "reason": f"price at {pct * 100:.0f}% - discount ceiling {(1 - g['premium_min']) * 100:.0f}%"}
    trig = str(trigger_state or "").upper()
    if trig not in g["trigger_states"]:
        return {"ok": False, "reason":
                f"waiting rejection trigger (state={trig or 'NONE'})"}
    stop_dist = _safe_float(g["stop_points"], 350.0) / 10.0  # system pts -> price
    if side == "SELL":
        entry = lo + g["retest_pct"] * span
        sl = entry + stop_dist
        final = _safe_float(plan_buy_entry, 0.0)
        if final <= 0 or final >= entry:
            final = entry - _safe_float(g["final_rr_fallback"], 2.0) * stop_dist
    else:
        entry = lo + (1.0 - g["retest_pct"]) * span
        sl = entry - stop_dist
        final = _safe_float(plan_sell_entry, 0.0)
        if final <= 0 or final <= entry:
            final = entry + _safe_float(g["final_rr_fallback"], 2.0) * stop_dist
    t1 = (entry + final) / 2.0                       # partial at the midpoint
    trail_pts = round(g["trail_dist_pct"] * span * 10.0, 2)  # system points
    plan = {
        "side": side,
        "entry": round(entry, 2), "sl": round(sl, 2),
        "t1_mid": round(t1, 2),                  # midpoint partial
        "t3_handoff_cap": round(final, 2),       # final: pending level or 2R
        "stop_points": g["stop_points"],
        "t1_close_fraction": g["t1_close_fraction"],
        "trail_distance_pts": trail_pts,
        "ttl_minutes": g["ttl_minutes"],
        "time_stop_minutes": g["time_stop_minutes"],
        "size_fraction": 0.5,
        "trigger_state": trig, "range": [round(lo, 2), round(hi, 2)],
        "price_pct_of_range": round(pct, 3), "mode": g["mode"],
    }
    return {"ok": True, "side": side, "plan": plan}


def _r25_book_site_basis(all_results: Dict[str, Any],
                         details: Dict[str, Any]) -> Dict[str, Any]:
    """R25-4: attach the per-agent site basis the activation book carries.

    classical -> patterns_score (max pattern contribution across frames);
    smc -> basis_text (its own entry_reason). Missing pieces stay missing;
    the contextual veto counts voices conservatively when basis is absent.
    """
    try:
        ta = (all_results.get("classical") or {}).get("timeframe_analysis") or {}
        scores = []
        for row in ta.values():
            if isinstance(row, dict):
                v = (row.get("score_components") or {}).get("patterns_and_quality")
                try:
                    scores.append(float(v))
                except (TypeError, ValueError):
                    pass
        cl = details.get("classical")
        if scores and isinstance(cl, dict):
            cl["patterns_score"] = max(scores)
        smc_res = all_results.get("smc") or {}
        reason = str((smc_res.get("setup_structure") or {}).get("entry_reason") or "")
        smc = details.get("smc")
        if reason and isinstance(smc, dict):
            smc["basis_text"] = reason[:220]
    except Exception:  # noqa: BLE001 - basis is additive, never breaking
        pass
    return details


def _r25_site_range(decision: Dict[str, Any]) -> Dict[str, Any]:
    hi, lo = _r24_known_range(decision)
    ctx: Dict[str, Any] = {}
    if hi > 0 and lo > 0 and hi > lo:
        ctx = {"range_high": hi, "range_low": lo}
    return ctx


def _r25_scalp_execute(decision: Dict[str, Any], symbol: str,
                       config: Dict[str, Any], database: Any,
                       telegram: Any, open_trades_snapshot: Any, *,
                       demo_execution: bool = False) -> None:
    """R25-2 (operator order 2026-08-28 evening): the scalp trades LIVE.

    When the fade plan arms, a real SELL/BUY LIMIT is created through THE SAME
    delivery machinery the planner ladder uses - duplicate filter, final
    signal validation, the opposite-exposure hand-off (the BUY plan is queued
    to close before the SELL scalp goes on), demo-intent vs telegram
    delivery, and a named audit row. R24-0 supremacy is re-checked here: a
    grade-F book refuses the scalp too. One scalp at a time per symbol.
    """
    g = _r25_scalp_cfg(config)
    plan_obj = decision.get("session_plan") or {}
    prim = (plan_obj.get("primary_poi") or {}) if isinstance(plan_obj, dict) else {}
    bias = str(plan_obj.get("session_bias") or "").upper()
    prim_entry = _safe_float(prim.get("entry_price"), 0.0)
    res = r25_scalp_fade_plan(
        decision, config,
        trigger_state=str(prim.get("trigger_state") or ""),
        price=_safe_float(decision.get("current_price"), 0.0),
        plan_buy_entry=prim_entry if bias == "BUY" else 0.0,
        plan_sell_entry=prim_entry if bias == "SELL" else 0.0,
    )
    reason = str(res.get("reason") or "")
    if not res.get("ok"):
        logger.info("R25-2 scalp waiting for %s: %s", symbol, reason)
        return
    # R24-0 SUPREMACY: a refused risk book refuses every order, scalp included.
    _risk_reason = r24_risk_veto_reason(decision, config)
    if _risk_reason:
        logger.info("R24-0 risk veto blocks the R25-2 scalp for %s: %s",
                    symbol, _risk_reason)
        try:
            _record_decision_audit(database, decision, config,
                                   stage="r25 scalp", outcome="REFUSED",
                                   reason=f"R24-0: {_risk_reason}")
        except Exception:  # noqa: BLE001
            logger.debug("r25 audit row failed", exc_info=True)
        return
    # One scalp at a time per symbol.
    live_flags = {"PENDING", "OPEN", "PARTIAL", "TP1_HIT"}
    normalized = normalize_symbol(symbol)
    existing = [t for t in (open_trades_snapshot or [])
                if normalize_symbol(t.get("symbol") or symbol) == normalized
                and str(t.get("status") or "").upper() in live_flags
                and ((t.get("signal_snapshot") or {}).get("setup_context") or {}).get("r25_scalp")]
    if existing:
        logger.info("R25-2 scalp skipped for %s: one scalp at a time (%s live)",
                    symbol, len(existing))
        return
    plan = res["plan"]
    side = str(res["side"])
    scalp = {
        "trade_id": database.new_trade_id(),
        "symbol": symbol,
        "decision": side,
        "strategy": "R25-2_scalp_fade",
        "signal": {
            "order_type": f"{side}_LIMIT",
            "entry": {"kind": "LIMIT", "price": plan["entry"]},
            "stop_loss": plan["sl"],
            "tp1": plan["t1_mid"],
            "tp2": plan["t3_handoff_cap"],
        },
        "current_price": _safe_float(decision.get("current_price"), 0.0),
        "agent_details": decision.get("agent_details") or {},
        "reasons": [(f"R25-2 SCALP {side} at {plan['price_pct_of_range'] * 100:.0f}% "
                     f"of range {plan['range']}; fixed SL {plan['stop_points']:.0f} "
                     f"system pts; final target = the opposite pending level "
                     f"{plan['t3_handoff_cap']} (or 2R fallback); partial 50% at "
                     f"the midpoint {plan['t1_mid']}; conditions met BY NAME: "
                     f"classical {side} >=70 AND smc {side} >=70 (two "
                     f"families), multitimeframe neutral, trigger "
                     f"{plan['trigger_state']}; risk R24-0 passed")],
        "invalidation_level": plan["sl"],
        "setup_context": {"r25_scalp": True, "strategy": "R25-2_scalp_fade",
                          "trigger_state": plan["trigger_state"],
                          "t3_handoff_cap": plan["t3_handoff_cap"],
                          "trail_distance_pts": plan["trail_distance_pts"],
                          "thesis_source": ("R25-2 standalone lane - NOT part "
                                            "of the day-map thesis; consensus "
                                            "untouched; R24-0 binds")},
    }
    stamp_execution_path(scalp, "R25_SCALP_FADE")
    snapshot = list(open_trades_snapshot or [])
    dup = duplicate_signal_reason(scalp, database, config)
    if dup:
        logger.info("R25-2 scalp blocked for %s by duplicate filter: %s", symbol, dup)
        return
    violations = validate_signal_before_send(scalp, config, snapshot)
    if violations:
        logger.info("R25-2 scalp failed final validation for %s: %s",
                    symbol, "; ".join(violations))
        try:
            _record_decision_audit(database, scalp, config,
                                   stage="r25 scalp", outcome="REFUSED",
                                   reason="final validation: " + "; ".join(violations))
        except Exception:  # noqa: BLE001
            logger.debug("r25 audit row failed", exc_info=True)
        return
    _queue_opposite_exposure_exit(scalp, snapshot, database, config)
    if demo_execution:
        scalp["_telegram_signal_sent"] = False
        database.save_trade(scalp)
        delivered = True
    else:
        try:
            delivered = bool(telegram.send_signal(scalp))
        except Exception as exc:  # noqa: BLE001
            logger.warning("R25-2 scalp telegram delivery failed for %s: %s", symbol, exc)
            delivered = False
        if not delivered:
            return
        database.save_trade(scalp)
    _record_decision_audit(
        database, scalp, config,
        stage="r25 scalp",
        outcome="QUEUED" if demo_execution else "SENT",
        reason=f"scalp-fade {side} LIMIT {plan['entry']} (T1 {plan['t1_mid']}, "
               f"cap {plan['t3_handoff_cap']}, TTL {plan['ttl_minutes']:.0f}m)",
    )
    logger.info("R25-2 scalp %s LIMIT %.2f placed for %s (SL %.2f, T1 %.2f, "
                "cap %.2f, TTL %.0fm)", side, plan["entry"], symbol,
                plan["sl"], plan["t1_mid"], plan["t3_handoff_cap"],
                plan["ttl_minutes"])


def _planner_display_confidence(
    base_decision: Dict[str, Any],
    plan: Dict[str, Any],
    candidate: Dict[str, Any],
    config: Dict[str, Any],
    *,
    direction: str,
) -> float:
    sig_cfg = (config.get("signal_requirements") or {}) if isinstance(config, dict) else {}
    min_agent_conf = float(sig_cfg.get("agent_min_confidence", 67) or 67)
    details = base_decision.get("agent_details") or {}
    support_confidences: List[float] = []
    oppose_confidences: List[float] = []
    for key in CORE_VOTING_AGENTS:
        used_key, detail = _book_agent(details, key)
        if not detail:
            continue
        agent_direction = str(detail.get("direction") or "WAIT").upper()
        agent_confidence = _safe_float(detail.get("confidence"), 0.0)
        if agent_confidence < min_agent_conf:
            continue
        if agent_direction == direction:
            support_confidences.append(agent_confidence)
        elif agent_direction in {"BUY", "SELL"}:
            # A qualified agent voting the other way is evidence against the
            # thesis and is weighted with the same threshold as a supporter.
            oppose_confidences.append(agent_confidence)

    dominance = _safe_float(candidate.get("thesis_dominance_score"), 0.0)
    quality_score = _safe_float(candidate.get("quality_score"), _safe_float((candidate.get("setup_quality") or {}).get("score"), 0.0))
    if support_confidences:
        avg_support = sum(support_confidences) / max(len(support_confidences), 1)
        display_confidence = avg_support * 0.75 + dominance * 0.25
    else:
        display_confidence = max(dominance, quality_score * 0.80, 60.0)

    # Symmetry: confirmation adds, contradiction subtracts.
    #
    # Only agreement moved this number before. A qualified agent voting the
    # opposite way at 95% produced exactly the same confidence as an
    # unqualified one at 27%, and a macro read opposing the trade at 90% cost
    # nothing while a supporting one added 2.0. Every disagreement in the
    # system was silently rounded down to zero, so the published figure only
    # ever described the evidence that agreed with the trade.
    context_confirmation = _planner_context_confirmation(base_decision, config, direction)
    if len(support_confidences) >= 2 and context_confirmation.get("allow"):
        display_confidence += 2.0

    if oppose_confidences:
        avg_oppose = sum(oppose_confidences) / len(oppose_confidences)
        # Scale with both how many disagree and how strongly, so two strong
        # opponents cost more than one marginal one.
        display_confidence -= (avg_oppose / 100.0) * 6.0 * len(oppose_confidences)

    # BUILD 26 (2026-08-21): the opposition penalty is symbol-aware. The
    # gold macro may not punish a WTI card (and vice versa); each symbol's
    # own fundamental voice is the only one that adjusts its display.
    _display_symbol = str(base_decision.get("symbol") or config.get("symbol") or "").upper()
    if "WTI" in _display_symbol:
        _oil_src = (details.get("oil_macro") or base_decision.get("oil_macro")
                    or (base_decision.get("all_results") or {}).get("oil_macro") or {})
        if isinstance(_oil_src, dict):
            _oil_side = str(_oil_src.get("direction") or _oil_src.get("bias") or "").upper()
            if _oil_side.startswith("BEARISH"):
                _oil_side = "SELL"
            elif _oil_side.startswith("BULLISH"):
                _oil_side = "BUY"
            _oil_conf = _safe_float(_oil_src.get("confidence"), 0.0)
            if _oil_side in {"BUY", "SELL"} and _oil_side != direction and _oil_conf > 0:
                display_confidence -= 5.0 if _oil_conf >= 80 else 3.0 if _oil_conf >= 55 else 1.5
    else:
        macro_direction = _macro_direction_for(base_decision)
        macro_bias = str(macro_direction.get("bias") or "").upper()
        macro_side = {"BULLISH_GOLD": "BUY", "BEARISH_GOLD": "SELL"}.get(macro_bias)
        macro_conf = _safe_float(macro_direction.get("confidence"), 0.0)
        if macro_side and macro_side != direction and macro_conf > 0:
            display_confidence -= 5.0 if macro_conf >= 80 else 3.0 if macro_conf >= 55 else 1.5

    cap = 95.0 if len(support_confidences) >= 3 else 92.0 if len(support_confidences) >= 2 else 88.0
    return round(max(50.0, min(cap, display_confidence)), 1)



def _build_plan_ladder_decision(
    base_decision: Dict[str, Any],
    plan: Dict[str, Any],
    candidate: Dict[str, Any],
    config: Dict[str, Any],
    *,
    force_market: bool = False,
    role_override: str | None = None,
    entry_price_override: float | None = None,
    risk_share: float | None = None,
    basis_override: str | None = None,
    limit_only: bool = False,
) -> Dict[str, Any] | None:
    direction = str(plan.get("session_bias") or candidate.get("direction") or "").upper()
    symbol = str(plan.get("symbol") or base_decision.get("symbol") or config.get("symbol", "XAU/USD"))
    if direction not in {"BUY", "SELL"}:
        return None
    entry_price = _safe_float(entry_price_override if entry_price_override is not None else candidate.get("entry_price"), 0.0)
    stop_loss = _safe_float(candidate.get("stop_loss"), 0.0)
    # Keep the structural stop: a market conversion below reprices from the
    # mapped invalidation, not from an already-floored stop.
    raw_stop_loss = stop_loss
    target_price = _safe_float(candidate.get("target_price") or candidate.get("target_liquidity"), 0.0)
    current_price = _safe_float(base_decision.get("current_price"), 0.0)
    if entry_price <= 0 or stop_loss <= 0 or target_price <= 0 or current_price <= 0:
        return None

    levels = _planner_trade_levels(
        config,
        direction=direction,
        entry_price=entry_price,
        stop_loss=stop_loss,
        target_price=target_price,
        symbol=symbol,
        candidate=candidate,
    )
    if levels.get("reject_reason"):
        logger.info(
            "Session-plan leg rejected for %s %s: %s",
            symbol,
            direction,
            levels.get("reject_reason"),
        )
        return None
    stop_loss = _clamp_leg_stop_to_law(levels["stop_loss"], entry_price, direction, symbol, config)
    order_type = f"{direction}_MARKET" if force_market else _planned_order_type(
        config, direction, entry_price, current_price, symbol, planned_stop=stop_loss,
    )
    if order_type == "NO_ENTRY":
        logger.info(
            "Session-plan leg skipped for %s %s: mapped stop %.2f does not "
            "protect a market fill at %.2f, and a stop entry is not permitted",
            symbol, direction, stop_loss, current_price,
        )
        return None
    if limit_only and not order_type.endswith("LIMIT"):
        logger.info(
            "Path 4 leg refused for %s %s: exact SMC POI %.2f does not form "
            "a resting LIMIT from current price %.2f; MARKET chasing is forbidden",
            symbol, direction, entry_price, current_price,
        )
        return None
    # Price sitting inside the mapped area is the setup arriving, not a reason
    # to stand down. This branch used to return None whenever the leg priced as
    # MARKET, so a confirmed map produced an order only while price was still
    # far away, and refused one the moment price actually reached the level --
    # the map was published, price traded through the zone, and nothing was
    # ever placed.
    #
    # Convert instead of abandoning: the leg has already cleared the reward,
    # risk-floor and reject_reason checks above, and everything downstream
    # (planner gate, day-map sanity, duplicate and pending governors) still
    # runs. Entry is repriced to the live price so the recorded fill is the
    # real one, and the executed leg is never better than the mapped edge.
    market_conversion = False
    if order_type.endswith("MARKET") and not force_market:
        # Market conversion exists so a PRIMARY map that price has reached
        # is not silently abandoned. It must NEVER apply to an add leg:
        # the STANDBY/ADD_ON is by definition the DEEPER entry, and letting
        # it chase market inverts the ladder. Live failure 2026-08-18
        # 01:26: PRIMARY rested as BUY LIMIT 4406.54 while the STANDBY
        # converted to BUY MARKET at 4423.08 — the "add" bought 165 points
        # ABOVE the main entry and stopped out; the buy-the-dip rule that
        # scale-in and cross-path enforce was bypassed entirely.
        _leg_role = str(role_override or candidate.get("selection_role") or "PRIMARY").upper()
        if _leg_role in {"STANDBY", "ADD_ON"}:
            logger.info(
                "Session-plan %s leg refused for %s %s: price already inside its "
                "zone and add legs never chase market (they must rest deeper "
                "than the primary)",
                _leg_role, symbol, direction,
            )
            return None
        _trig_reason = r24_trigger_market_reason(candidate, config)
        if _trig_reason:
            logger.info(
                "R24-1 trigger supremacy - %s leg refused for %s %s: %s",
                _leg_role, symbol, direction, _trig_reason,
            )
            return None
        _range_reason = r24_range_chase_reason(
            base_decision, candidate, direction, current_price, config)
        if _range_reason:
            logger.info(
                "R24-3 range gate - %s leg refused for %s %s: %s",
                _leg_role, symbol, direction, _range_reason,
            )
            return None
        if not bool(_split_execution_cfg(config).get("convert_touched_zone_to_market", True)):
            logger.info(
                "Session-plan leg skipped for %s %s: price inside the mapped area "
                "and market conversion is disabled",
                symbol, direction,
            )
            return None
        market_conversion = True
        entry_price = current_price
        levels = _planner_trade_levels(
            config,
            direction=direction,
            entry_price=entry_price,
            stop_loss=raw_stop_loss,
            target_price=target_price,
            symbol=symbol,
            candidate=candidate,
        )
        if levels.get("reject_reason"):
            logger.info(
                "Session-plan market conversion rejected for %s %s: %s",
                symbol, direction, levels.get("reject_reason"),
            )
            return None
        stop_loss = levels["stop_loss"]
        logger.info(
            "Session-plan leg converted to market for %s %s at %.2f "
            "(price reached the mapped area)",
            symbol, direction, entry_price,
        )
    entry_kind = "MARKET" if (force_market or market_conversion) else order_type.split("_")[-1]
    zone = candidate.get("poi_zone") or {}
    if isinstance(zone, dict) and zone.get("top") is not None and zone.get("bottom") is not None:
        low = min(_safe_float(zone.get("top"), entry_price), _safe_float(zone.get("bottom"), entry_price))
        high = max(_safe_float(zone.get("top"), entry_price), _safe_float(zone.get("bottom"), entry_price))
    else:
        low = _safe_float(candidate.get("poi_low"), entry_price)
        high = _safe_float(candidate.get("poi_high"), entry_price)
        if low <= 0 or high <= 0:
            low = high = entry_price

    # Publish the area the planner actually mandates, not the raw POI.
    #
    # `session_planner.min_entry_zone_width_points` (60) is enforced by
    # SessionPlannerService._enforce_min_zone_width, which widens a narrow POI
    # symmetrically around the reference entry. That method is called from
    # _zone_payload -- the planner's own view of the map -- but this function
    # builds the order that is actually sent, and it read the raw POI instead.
    #
    # 2026-07-31, TRADE_..._b4f85832: the card published "Entry zone
    # 4029.85 → 4033.69", which is 38.4 points. The floor is 60. The planner,
    # asked directly, returns 4028.77 → 4034.77 = exactly 60.0.
    #
    # A published area narrower than the floor is the precise failure the
    # floor exists to prevent: the order rests at one price inside it, and a
    # touch that misses that price by a few points leaves the plan unfilled
    # while price runs to target. Risk does not drift from widening --
    # zone_touch_activation carries the stop the same distance it moves the
    # entry (preserve_planned_risk=true).
    if not (force_market or market_conversion) and high > low:
        try:
            widened_low, widened_high, _widened = SessionPlannerService(config)._enforce_min_zone_width(
                low, high, entry_price=entry_price, symbol=symbol,
            )
            if _widened and widened_low > 0 and widened_high > widened_low:
                logger.info(
                    "Entry area widened to the configured floor for %s %s: "
                    "%.2f-%.2f (%.0f pts) -> %.2f-%.2f (%.0f pts)",
                    symbol, direction, low, high,
                    abs(price_to_points(high - low, symbol=symbol)),
                    widened_low, widened_high,
                    abs(price_to_points(widened_high - widened_low, symbol=symbol)),
                )
                low, high = widened_low, widened_high
        except Exception as exc:  # noqa: BLE001 - never block a valid signal
            logger.warning("Could not apply the minimum entry-zone width: %s", exc)
    tp1 = levels["tp1"]
    tp2 = levels["tp2"]
    rr = levels["rr"]
    role = str(role_override or candidate.get("selection_role") or "PRIMARY").upper()
    hierarchy = _plan_execution_hierarchy(plan, role)

    decision = deepcopy(base_decision)
    decision.update(
        {
            "decision": direction,
            "symbol": symbol,
            "confidence": _planner_display_confidence(base_decision, plan, candidate, config, direction=direction),
            "entry_mode": (
                "path4_smc_map_auction_limit" if limit_only
                else "session_plan_ladder_market" if (force_market or market_conversion)
                else "session_plan_ladder"
            ),
            "entry_path": 4 if limit_only else 3,
            "reasons": [
                f"Session plan {plan.get('scenario_type')} ({role})",
                f"Execution leg: {hierarchy.get('execution_leg_label')}",
                *([f"Planner SL floored to {levels.get('min_sl_distance_points', 0):.0f} points minimum risk distance."] if levels.get("floor_applied") else []),
                f"Morning/session planner prepared this pending thesis before the move.",
            ],
            # Two different measurements, reported separately instead of being
            # blended. Mixing them (grade from the plan, score from max() of
            # both scales) produced nonsense like "C 100.0" -- a plan graded C
            # displaying a POI score of 100.
            "quality": {
                "grade": candidate.get("quality_grade") or plan.get("planner_grade") or "B",
                "score": _safe_float(
                    candidate.get("quality_score"),
                    _safe_float(plan.get("planner_confidence"), 0.0),
                ),
            },
            "planner_quality": {
                "grade": plan.get("planner_grade") or "B",
                "score": _safe_float(plan.get("planner_confidence"), 0.0),
            },
            "session_plan": deepcopy(plan),
        }
    )
    setup_context = deepcopy(candidate)
    setup_context.update(
        {
            "scenario_id": plan.get("scenario_id"),
            "plan_id": plan.get("plan_id"),
            "pending_plan_role": role,
            "selection_role": role,
            "execution_leg": hierarchy.get("execution_leg"),
            "execution_leg_label": hierarchy.get("execution_leg_label"),
            "execution_stage": hierarchy.get("execution_stage"),
        }
    )
    decision["setup_context"] = setup_context
    decision["setup_id"] = setup_context.get("id")
    decision["setup_type"] = setup_context.get("setup_type")
    decision["setup_state"] = setup_context.get("setup_state")
    decision["lead_agent"] = setup_context.get("lead_agent")
    decision["setup_quality"] = setup_context.get("quality_grade") or candidate.get("quality_grade")
    position_size = {}
    if risk_share is not None:
        position_size["scenario_risk_share"] = round(float(risk_share), 3)
    decision["signal"] = {
        "type": direction,
        "entry": {
            "price": round(entry_price, 2),
            "low": round(current_price if (force_market or market_conversion) else low, 2),
            "high": round(current_price if (force_market or market_conversion) else high, 2),
            "kind": entry_kind,
            "order_type": order_type,
            "basis": basis_override or f"{hierarchy.get('execution_leg_label')} · session plan",
            "current_price": round(current_price, 2),
            "distance_points": 0.0 if (force_market or market_conversion) else abs(price_to_points(entry_price - current_price, symbol=symbol)),
        },
        "stop_loss": round(stop_loss, 2),
        "tp1": round(tp1, 2),
        "tp2": round(tp2, 2),
        "rr_ratio": rr,
        "tp1_rr": round(abs(tp1 - entry_price) / max(abs(stop_loss - entry_price), 0.01), 2),
        "tp2_rr": rr,
        "order_type": order_type,
        "entry_kind": entry_kind,
        "position_size": position_size,
        "risk_summary": f"Session planner {hierarchy.get('execution_leg_label')} {'market' if (force_market or market_conversion) else 'pending'} · {levels.get('target_method')}",
        "execution_leg": hierarchy.get("execution_leg"),
        "execution_leg_label": hierarchy.get("execution_leg_label"),
        "target_method": levels.get("target_method"),
    }
    decision["execution_leg"] = hierarchy.get("execution_leg")
    decision["execution_leg_label"] = hierarchy.get("execution_leg_label")
    return decision



def _macro_direction_for(decision: Dict[str, Any]) -> Dict[str, Any]:
    """Read the macro bias payload, wherever this decision carries it."""
    news_context = decision.get("news_context") or {}
    macro_agent = (news_context.get("macro") or {}) if isinstance(news_context, dict) else {}
    macro_direction = (macro_agent.get("macro_direction") or {}) if isinstance(macro_agent, dict) else {}
    if not macro_direction:
        market_context = decision.get("market_context") or {}
        if isinstance(market_context, dict):
            macro_direction = market_context.get("macro_direction") or {}
    return macro_direction if isinstance(macro_direction, dict) else {}


def _planner_context_confirmation(decision: Dict[str, Any], config: Dict[str, Any], side: str) -> Dict[str, Any]:
    sig_cfg = (config.get("signal_requirements") or {}) if isinstance(config, dict) else {}
    two_agent_cfg = (sig_cfg.get("two_agent_entry") or {}) if isinstance(sig_cfg, dict) else {}
    macro_cfg = (two_agent_cfg.get("macro_confirmation") or {}) if isinstance(two_agent_cfg, dict) else {}
    gemini_cfg = (two_agent_cfg.get("gemini_confirmation") or {}) if isinstance(two_agent_cfg, dict) else {}
    macro_min = float(macro_cfg.get("min_confidence", 55) or 55)
    gemini_min = float(gemini_cfg.get("min_confidence", 70) or 70)

    news_context = decision.get("news_context") or {}
    macro_agent = (news_context.get("macro") or {}) if isinstance(news_context, dict) else {}
    macro_direction = (macro_agent.get("macro_direction") or {}) if isinstance(macro_agent, dict) else {}
    macro_bias = str(macro_direction.get("bias") or "").upper()
    macro_conf = _safe_float(macro_direction.get("confidence"), 0.0)
    expected_macro = "BULLISH_GOLD" if side == "BUY" else "BEARISH_GOLD"

    # BUILD 26 (2026-08-21): symbol-aware display confirmation. For a WTI
    # decision the OIL macro is the fundamental voice (the same routing the
    # entry ladder uses) - the gold macro's BULLISH_GOLD/BEARISH_GOLD
    # semantics must neither confirm nor punish an oil card.
    _display_symbol = str(decision.get("symbol") or config.get("symbol") or "").upper()
    if "WTI" in _display_symbol:
        oil_min = float((two_agent_cfg.get("oil_macro_confirmation") or {}).get("min_confidence", 55) or 55)
        oil_source = (decision.get("agent_details") or {}).get("oil_macro") or decision.get("oil_macro")
        if not isinstance(oil_source, dict):
            oil_source = (decision.get("all_results") or {}).get("oil_macro") or {}
        oil_side = str(oil_source.get("direction") or oil_source.get("bias") or "").upper()
        if oil_side.startswith("BEARISH"):
            oil_side = "SELL"
        elif oil_side.startswith("BULLISH"):
            oil_side = "BUY"
        oil_conf = _safe_float(oil_source.get("confidence"), 0.0)
        if oil_side == side and oil_conf >= oil_min:
            return {
                "allow": True,
                "source": "oil_macro",
                "confidence": round(oil_conf, 1),
                "reason": f"oil macro confirms {side} ({oil_conf:.0f}% ≥ {oil_min:.0f}%)",
            }
    else:
        # R26.9.1 (2026-09-01): forex macro verdicts are SYMBOL-SUFFIXED
        # (BULLISH_EURUSD, BEARISH_USDJPY, ...). The card used to compare
        # them with the gold codes and displayed "macro does not confirm"
        # even right after the entry ladder had confirmed — accept the
        # pair's own suffixed verdict now. Gold (and a card with no symbol
        # at all) keeps the historical gold codes.
        _pair_sym = normalize_symbol(_display_symbol) if _display_symbol else ""
        if _pair_sym and _pair_sym != "XAU/USD":
            expected_macro = ("BULLISH_" if side == "BUY" else "BEARISH_") + _pair_sym.replace("/", "")
        if macro_bias == expected_macro and macro_conf >= macro_min:
            return {
                "allow": True,
                "source": "macro",
                "confidence": round(macro_conf, 1),
                "reason": f"macro context confirms {side} ({macro_conf:.0f}% ≥ {macro_min:.0f}%)",
            }

    gemini_macro = decision.get("gemini_macro_review") or {}
    if isinstance(gemini_macro, dict) and gemini_macro.get("available"):
        verdict = str(gemini_macro.get("macro_verdict") or gemini_macro.get("verdict") or "").upper()
        conf = _safe_float(gemini_macro.get("confidence"), 0.0)
        if verdict == expected_macro and conf >= gemini_min:
            return {
                "allow": True,
                "source": "gemini",
                "confidence": round(conf, 1),
                "reason": f"gemini macro review confirms {side} ({conf:.0f}% ≥ {gemini_min:.0f}%)",
            }

    gemini_review = decision.get("gemini_review") or {}
    if isinstance(gemini_review, dict) and gemini_review.get("available"):
        verdict = str(gemini_review.get("verdict") or gemini_review.get("signal") or gemini_review.get("opinion") or "").upper()
        conf = _safe_float(gemini_review.get("confidence"), 0.0)
        if verdict == side and conf >= gemini_min:
            return {
                "allow": True,
                "source": "gemini",
                "confidence": round(conf, 1),
                "reason": f"gemini signal review confirms {side} ({conf:.0f}% ≥ {gemini_min:.0f}%)",
            }

    gemini_analysis = decision.get("gemini_analysis") or {}
    if isinstance(gemini_analysis, dict) and gemini_analysis.get("available"):
        bias = str(gemini_analysis.get("market_bias") or gemini_analysis.get("verdict") or "").upper()
        conf = _safe_float(gemini_analysis.get("confidence"), 0.0)
        if bias == side and conf >= gemini_min:
            return {
                "allow": True,
                "source": "gemini",
                "confidence": round(conf, 1),
                "reason": f"gemini market context confirms {side} ({conf:.0f}% ≥ {gemini_min:.0f}%)",
            }

    return {"allow": False}


def _planner_execution_gate(decision: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
    """Use the exact shared Entry/Thesis admission at the order boundary."""
    side = str(decision.get("decision") or "").upper()
    if side not in {"BUY", "SELL"}:
        plan = decision.get("session_plan") or {}
        if isinstance(plan, dict) and plan.get("plan_ready"):
            side = str(plan.get("session_bias") or plan.get("authority_direction") or "").upper()
    if side not in {"BUY", "SELL"}:
        return {"allow": False, "reason": "no approved directional admission"}

    details = dict(decision.get("agent_details") or {})
    external_mode = None
    confirm_source = str(decision.get("confirm_source") or "").lower()
    confirm_conf = _safe_float(decision.get("confirm_confidence"), 0.0)
    if confirm_source == "macro":
        details["macro_fundamental"] = {"direction": side, "confidence": confirm_conf}
        external_mode = "direct"
    elif confirm_source == "gemini":
        details["gemini"] = {"direction": side, "confidence": confirm_conf, "available": True}
        external_mode = "direct"
    context_confirmation = _planner_context_confirmation(decision, config, side)
    if context_confirmation.get("allow"):
        source = str(context_confirmation.get("source") or "").lower()
        confidence = _safe_float(context_confirmation.get("confidence"), 0.0)
        if source == "macro":
            details["macro_fundamental"] = {"direction": side, "confidence": confidence}
        elif source == "gemini":
            details["gemini"] = {"direction": side, "confidence": confidence, "available": True}
        external_mode = external_mode or "context"
    # The shared evaluator accepts these canonical external-confirmation keys.
    for candidate in (
        decision.get("gemini_review"), decision.get("gemini_macro_review"),
        decision.get("gemini_analysis"),
    ):
        if "gemini" not in details and isinstance(candidate, dict) and candidate.get("available"):
            details["gemini"] = candidate
            break
    admission = evaluate_directional_admission(side, details, config)

    planner_cfg = (config.get("session_planner") or {}) if isinstance(config, dict) else {}
    try:
        max_opposing = int(planner_cfg.get("max_opposing_agents_for_ready", 1))
    except (TypeError, ValueError):
        max_opposing = 1
    oppose_count = int(admission.get("opposition_count", 0) or 0)
    if oppose_count > max_opposing:
        return {
            **admission,
            "allow": False,
            "kind": "OPPOSED_BY_LIVE_AGENTS",
            "support_agents": list(admission.get("supporters") or []),
            "oppose_agents": list(admission.get("opponents") or []),
            "oppose_count": oppose_count,
            "reason": (
                f"{oppose_count} qualified agents oppose the mapped {side} "
                f"(limit {max_opposing})"
            ),
        }
    if admission.get("allow"):
        path = str(admission.get("path") or "SHARED_ADMISSION")
        if path == "THREE_AGENT_CONSENSUS":
            kind = "THREE_AGENT_ADMISSION"
        elif path.startswith("TWO_AGENT_") and external_mode == "direct":
            kind = "TWO_AGENT_CONFIRMED_ADMISSION"
        elif path.startswith("TWO_AGENT_"):
            kind = "TWO_AGENT_CONTEXT_CONFIRMED_ADMISSION"
        elif path == "SMC_MAP_AUCTION_CONFIRMATION":
            kind = "PATH4_SMC_MAP_AUCTION_ADMISSION"
        else:
            kind = path
        return {
            **admission,
            "kind": kind,
            "support_agents": list(admission.get("supporters") or []),
            "oppose_agents": list(admission.get("opponents") or []),
            "oppose_count": oppose_count,
            "reason": str(admission.get("reason") or "shared admission passed"),
        }
    return {
        **admission,
        "allow": False,
        "kind": "SHARED_ADMISSION_BLOCKED",
        "support_agents": list(admission.get("supporters") or []),
        "oppose_agents": list(admission.get("opponents") or []),
        "oppose_count": oppose_count,
        "reason": str(admission.get("reason") or "shared admission failed"),
    }

def _add_leg_rejection_reason(
    plan: Dict[str, Any],
    primary: Dict[str, Any],
    standby: Dict[str, Any],
    config: Dict[str, Any],
) -> str | None:
    """Reject an add leg that cannot honestly improve a live main thesis.

    Two independent failure modes are checked at the execution boundary,
    because a plan may be persisted and replayed after the planner ran:

    1. The add entry sits beyond the main leg's stop loss. The only price path
       that fills it is main-fills -> main-stopped -> price continues, i.e.
       averaging into a rejected thesis while labelled "main then add".
    2. The add is both far away and structurally unlikely to be revisited, so
       it occupies a pending slot it will never use.
    """
    direction = str(plan.get("session_bias") or primary.get("direction") or standby.get("direction") or "").upper()
    if direction not in {"BUY", "SELL"}:
        return None

    add_entry = _safe_float(standby.get("entry_price"), 0.0)
    # Compare against the stop the main order will actually ship with, not the
    # raw structural stop: the risk floor can widen it substantially, and the
    # floored level is the real invalidation point for the live order.
    main_stop = _safe_float(primary.get("stop_loss"), 0.0)
    main_entry = _safe_float(primary.get("entry_price"), 0.0)
    main_target = _safe_float(primary.get("target_price") or primary.get("target_liquidity"), 0.0)
    if main_entry > 0 and main_stop > 0 and main_target > 0:
        try:
            main_stop = _safe_float(
                _planner_trade_levels(
                    config,
                    direction=direction,
                    entry_price=main_entry,
                    stop_loss=main_stop,
                    target_price=main_target,
                    symbol=str(plan.get("symbol") or config.get("symbol", "XAU/USD")),
                ).get("stop_loss"),
                main_stop,
            )
        except Exception:  # noqa: BLE001 - fall back to the structural stop
            pass
    if add_entry > 0 and main_stop > 0:
        beyond_invalidation = (
            (direction == "BUY" and add_entry <= main_stop)
            or (direction == "SELL" and add_entry >= main_stop)
        )
        if beyond_invalidation:
            return (
                f"add entry {add_entry:.2f} is beyond the main invalidation {main_stop:.2f} "
                f"({direction}); filling it would average into a rejected thesis"
            )

    planner_cfg = (config.get("session_planner") or {}) if isinstance(config, dict) else {}
    min_reach = _safe_float(planner_cfg.get("min_add_leg_return_probability", 25.0), 25.0)
    reach = _safe_float(standby.get("return_probability_score"), 0.0)
    revisit = str(standby.get("expected_revisit_window") or "").upper()
    if revisit == "LOW" and reach < min_reach:
        return (
            f"add leg revisit window is LOW with reach {reach:.1f} below {min_reach:.1f}; "
            "price is not expected to return to this area"
        )
    return None


def _split_execution_decisions(
    base_decision: Dict[str, Any],
    plan: Dict[str, Any],
    primary: Dict[str, Any],
    standby: Dict[str, Any] | None,
    config: Dict[str, Any],
) -> List[Dict[str, Any]]:
    split_cfg = _split_execution_cfg(config)
    if not bool(split_cfg.get("enabled", True)):
        return []
    if not bool(plan.get("extreme_poi", False)):
        return []
    if str(plan.get("execution_preference") or "").upper() != "SPLIT_EXECUTION_WATCH":
        return []
    direction = str(plan.get("session_bias") or primary.get("direction") or "").upper()
    current_price = _safe_float(base_decision.get("current_price"), 0.0)
    zone = _candidate_zone_bounds(primary)
    if direction not in {"BUY", "SELL"} or current_price <= 0 or not zone:
        return []
    low, high = zone
    if not (low <= current_price <= high):
        return []
    zone_progress = _zone_progress_pct(direction, current_price, low, high)
    starter_max_progress = float(split_cfg.get("starter_max_zone_progress_pct", 45) or 45)
    if zone_progress > starter_max_progress:
        return []
    starter_share = float(split_cfg.get("starter_risk_share", 0.4) or 0.4)
    addon_share = float(split_cfg.get("add_on_risk_share", max(0.0, 1.0 - starter_share)) or max(0.0, 1.0 - starter_share))
    starter = _build_plan_ladder_decision(
        base_decision,
        plan,
        primary,
        config,
        force_market=True,
        role_override="STARTER",
        entry_price_override=current_price,
        risk_share=starter_share,
        basis_override="Extreme POI starter market execution",
    )
    if not starter:
        return []
    if isinstance(standby, dict) and standby:
        addon_candidate = standby
    else:
        addon_candidate = deepcopy(primary)
        addon_candidate["selection_role"] = "ADD_ON"
        addon_zone = _candidate_zone_bounds(primary)
        if addon_zone:
            low_z, high_z = addon_zone
            if direction == "SELL":
                addon_candidate["entry_price"] = round(low_z + (high_z - low_z) * 0.5, 2)
            else:
                addon_candidate["entry_price"] = round(high_z - (high_z - low_z) * 0.5, 2)
    addon = _build_plan_ladder_decision(
        base_decision,
        plan,
        addon_candidate,
        config,
        role_override="ADD_ON",
        risk_share=addon_share,
        basis_override="Extreme POI add-on pending",
    )
    return [starter] + ([addon] if addon else [])



def _revive_recent_ready_plan(
    database: Any,
    config: Dict[str, Any],
    *,
    symbol: str,
    now: datetime,
    base_decision: Dict[str, Any] | None = None,
    all_results: Dict[str, Any] | None = None,
) -> Dict[str, Any] | None:
    """Reuse a still-valid day map when this cycle could not rebuild one.

    Plans are rebuilt from scratch every cycle and never persisted for reuse,
    so a map only ever gets one chance to place its orders: the cycle that
    produced it. If price had not yet reached a workable distance in that
    cycle, or agents briefly disagreed in the next one, the map was silently
    forgotten -- which is why a confirmed A+ plan could be published and no
    order ever appear.

    A day map is a standing thesis with an explicit lifetime (plan_expires_at),
    so an unexpired one remains actionable. Reviving it changes nothing about
    the checks that follow: the admission gate, reward test, duplicate filter
    and price-distance rule all still run against live prices.
    """
    planner_cfg = (config.get("session_planner") or {}) if isinstance(config, dict) else {}
    if not bool(planner_cfg.get("revive_unexpired_plans", True)):
        return None
    try:
        rows = database.get_recent_session_plans(limit=12, symbol=symbol, plan_ready_only=True)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to load recent session plans for revival: %s", exc)
        return None

    for row in rows or []:
        payload = row.get("payload") if isinstance(row, dict) else None
        if isinstance(payload, str):
            import json as _json
            try:
                payload = _json.loads(payload)
            except (ValueError, TypeError):
                payload = None
        if not isinstance(payload, dict) or not payload.get("plan_ready"):
            continue
        expires_at = _parse_datetime(str(payload.get("plan_expires_at") or ""))
        if not expires_at or now >= expires_at:
            continue
        if not (payload.get("primary_poi") or {}):
            continue

        # Re-authorise against the agents as they are *now*.
        #
        # The snapshot carries its own verdict -- authority CONFIRMED, an
        # archetype scored 86%, planner grade A+ -- and those fields were
        # replayed unchallenged. A live signal therefore went out headed
        # "3 qualified agents aligned" while the same message listed
        # Technical, Price Action and Multi-Timeframe all opposing, because
        # the stamp was hours old and the agents had since turned.
        #
        # Reviving a thesis is not the same as re-approving it: the map may
        # keep its shape, but the permission to trade it has to be earned
        # again from the current book. Refusing here leaves the cycle with no
        # plan, which is the correct outcome when the market has moved against
        # the map.
        revived_bias = str(payload.get("session_bias") or payload.get("authority_direction") or "").upper()
        if base_decision is not None and revived_bias in {"BUY", "SELL"}:
            recheck = _planner_execution_gate(
                {**base_decision, "decision": revived_bias, "session_plan": payload},
                config,
            )
            if not recheck.get("allow"):
                logger.info(
                    "Revived %s day map for %s rejected on re-authorisation: %s",
                    revived_bias, symbol, recheck.get("reason"),
                )
                continue

        age_minutes = 0.0
        created = _parse_datetime(str(row.get("analysis_run_at") or payload.get("created_at") or ""))
        if created:
            age_minutes = max(0.0, (now - created).total_seconds() / 60.0)
        logger.info(
            "Reusing unexpired %s day map for %s (built %.0f min ago, expires %s); "
            "this cycle could not rebuild one",
            payload.get("session_bias"), symbol, age_minutes, payload.get("plan_expires_at"),
        )
        revived = deepcopy(payload)
        revived["revived_from_snapshot"] = True
        revived["revived_age_minutes"] = round(age_minutes, 1)
        # An order created from this map is new, but it used to inherit the
        # original map's expiry -- so a plan built at 02:00 produced a 07:41
        # order that was already 71% through its life at birth, and the
        # planner cancelled it at 10:14 as "session plan expired" after only
        # 2.5 hours. Half an hour later the same area was republished, which
        # reads as the system contradicting itself.
        #
        # The thesis is still the original one, so the map keeps its identity
        # and its own age is recorded; what is refreshed is the deadline any
        # order derived from it will be judged against. The order's own
        # staleness window (pending_freshness.stale_after_hours) remains the
        # binding limit, which is the check that should have governed all
        # along.
        planner_cfg = (config.get("session_planner") or {}) if isinstance(config, dict) else {}
        expire_hours = _safe_float(planner_cfg.get("expire_after_hours"), 8.0) or 8.0
        renewed = now + timedelta(hours=expire_hours)
        revived["original_plan_expires_at"] = payload.get("plan_expires_at")
        revived["plan_expires_at"] = renewed.replace(microsecond=0).isoformat()
        revived["plan_expiry_renewed_on_revival"] = True
        # RE-JUDGE EXECUTION READINESS AGAINST THE LIVE BOOK.
        #
        # The gate recheck above re-counts the agents, but the readiness the
        # ladder's next gate reads was still the stamp written when the map
        # was BUILT. A map stored as WATCH_EXECUTION at 12:45 therefore stayed
        # "waiting for stronger execution confirmation" forever, even after
        # the live agents and macro lined up -- measured on 2026-08-04 17:25:
        # the revived BUY map was blocked by a readiness sentence describing
        # the 12:45 book while the same cycle confirmed BUY via 2 agents at
        # 92% and macro at 68%. The sentence looked live; it was a fossil.
        #
        # This is the readiness half of the same repair the re-authorisation
        # above already does for the agent count: reviving a thesis must earn
        # its permission to trade again from the current book, in BOTH gates.
        # The function recomputed here is the very one the planner uses, run
        # with fallback_day_map strictness, so a revived map is judged by the
        # same standard as a fresh one -- including the direction where live
        # support has DRIFFED and a stored READY must degrade back to WATCH.
        if isinstance(all_results, dict):
            try:
                old_readiness = payload.get("execution_readiness") or {}
                # Judge readiness from the SAME live evidence the agent gate
                # above was judged on: cycle agent results first, falling back
                # to this cycle's agent_details for any agent missing from
                # all_results. Two different books for the two gates is how a
                # fossil stamp survives under a fresh coat of paint.
                live_for_readiness = dict(all_results)
                details = (base_decision or {}).get("agent_details") or {}
                for _agent_name in ("technical", "multitimeframe", "classical",
                                    "smc", "price_action", "auction_flow"):
                    if not isinstance(live_for_readiness.get(_agent_name), dict):
                        _detail = details.get(_agent_name)
                        if isinstance(_detail, dict):
                            live_for_readiness[_agent_name] = {
                                "signal": _detail.get("direction") or "WAIT",
                                "confidence": _detail.get("confidence") or 0.0,
                            }
                fresh_readiness = SessionPlannerService(config)._execution_readiness(
                    planner_source="fallback_day_map",
                    direction=revived_bias,
                    primary=payload.get("primary_poi") or {},
                    standby=payload.get("standby_poi") or None,
                    all_results=live_for_readiness,
                    preferred_execution_family=str(
                        payload.get("preferred_execution_family")
                        or payload.get("scenario_type") or ""
                    ),
                    macro=all_results.get("macro_fundamental") or {},
                )
                revived["readiness_at_revival"] = {
                    "stored_state": str(old_readiness.get("state") or ""),
                    "stored_reason": str(old_readiness.get("reason") or ""),
                }
                revived["execution_readiness"] = fresh_readiness
                revived["readiness_rejudged_on_revival"] = True
            except Exception as exc:  # noqa: BLE001 - keep the stored verdict rather than drop the map
                logger.warning(
                    "Readiness re-judgement failed on revival for %s; keeping the stored verdict: %s",
                    symbol, exc,
                )
        logger.info(
            "Revived day map expiry renewed: %s -> %s (orders judged by their "
            "own age, not the source map's)",
            payload.get("plan_expires_at"), revived["plan_expires_at"],
        )
        return revived
    return None


def _dynamic_risk_block_for_cycle(
    *,
    decision_type: str,
    decision: Dict[str, Any],
    session_plan: Dict[str, Any],
    dynamic_risk: Dict[str, Any],
) -> str | None:
    """Apply the dynamic-risk halt to whichever thesis this cycle can execute.

    Two routes can create an order: the direct BUY/SELL path and the planner
    ladder. The ladder builds from the plan's session_bias, so it can place
    orders on a cycle whose live consensus reads WAIT -- which is why the
    direction falls back to the plan here. A halt has to cover both.

    But the numbers must belong to the thesis being judged. When the fallback
    was used, `confidence` and `quality` were still read off the WAIT
    decision, where both are 0.0, so a CONFIRMED A+ 98.6% day map was refused
    as "Confidence 0.0% below Dynamic Risk requirement 65.0%" -- a sentence
    about a number the map never had. `planner_confidence` is the same field
    the planner-quality block already uses for a mapped plan.
    """
    plan_ready = isinstance(session_plan, dict) and bool(session_plan.get("plan_ready"))
    side = decision_type if decision_type in {"BUY", "SELL"} else (
        str(session_plan.get("session_bias") or "").upper() if plan_ready else ""
    )
    if side not in {"BUY", "SELL"}:
        return None
    probe = {**decision, "decision": side}
    if decision_type not in {"BUY", "SELL"} and plan_ready:
        planner_conf = _safe_float(session_plan.get("planner_confidence"), 0.0)
        probe["confidence"] = planner_conf
        probe["quality"] = {"score": planner_conf}
    return should_block_signal(probe, dynamic_risk)


#: Why the last session-plan ladder attempt produced no order.
#:
#: `execution_audit` recorded the planner GATE verdict and the order count,
#: and nothing in between. Measured on 2026-08-04: of 21 published maps only
#: 1 became an order, and 9 of the 20 failures carried a gate reason that
#: reads as a PASS ("3 qualified agents aligned with the mapped direction").
#: The gate had allowed them; something after it stopped the ladder, and the
#: audit had no field to say what.
#:
#: `_execute_session_plan_ladder` has nine early exits after that gate --
#: a live trade already open, a terminal setup state, an entry too close to
#: price to rest as a pending order, a scenario family kept, and so on. Each
#: logs its reason and returns 0. This carries the last one out so the audit
#: can name it.
_LAST_LADDER_STOP: Dict[str, Any] = {}


def _ladder_stop(reason: str, **detail: Any) -> int:
    """Record why the ladder produced no order, then return 0."""
    _LAST_LADDER_STOP.clear()
    _LAST_LADDER_STOP.update({"reason": reason, **detail})
    return 0


def _execute_session_plan_ladder(
    base_decision: Dict[str, Any],
    all_results: Dict[str, Any],
    open_trades: List[Dict[str, Any]],
    database: DatabaseService,
    telegram: TelegramService,
    config: Dict[str, Any],
    *,
    demo_execution: bool = False,
) -> int:
    # Clear first: a stale reason from a previous cycle would be worse than
    # no reason at all, because it would read as fact.
    _LAST_LADDER_STOP.clear()
    planner_cfg = (config.get("session_planner") or {}) if isinstance(config, dict) else {}
    # Every exit from this function is logged. A plan can be published while no
    # order appears for several independent reasons, and silent returns made
    # that impossible to diagnose from the run output alone.
    if not bool(planner_cfg.get("create_pending_orders_from_plan", True)):
        logger.info("Session-plan ladder skipped: create_pending_orders_from_plan is disabled")
        return _ladder_stop("create_pending_orders_from_plan disabled")
    plan = base_decision.get("session_plan") or {}
    if not isinstance(plan, dict) or not plan.get("plan_ready"):
        # A map that could not be rebuilt this cycle is not necessarily gone:
        # agents drift in and out of agreement minute to minute, while the
        # thesis it expressed has its own lifetime. Fall back to the most
        # recent unexpired one before giving up.
        revived = _revive_recent_ready_plan(
            database, config, symbol=str(base_decision.get("symbol") or config.get("symbol", "XAU/USD")),
            now=datetime.now(timezone.utc),
            # Carries this cycle's agent_details so the snapshot is re-judged
            # against the live book rather than its own stored verdict -- and
            # all_results so EXECUTION READINESS is re-judged the same way,
            # not replayed as the stamp the build cycle wrote.
            base_decision=base_decision,
            all_results=all_results,
        )
        if not revived:
            logger.info(
                "Session-plan ladder skipped: plan not ready (status=%s, reason=%s) "
                "and no unexpired day map to fall back on",
                (plan or {}).get("plan_status") if isinstance(plan, dict) else "no-plan",
                (plan or {}).get("plan_reason") if isinstance(plan, dict) else "no session_plan on decision",
            )
            return _ladder_stop(
                "plan not ready and no unexpired day map",
                plan_status=(plan or {}).get("plan_status") if isinstance(plan, dict) else None,
            )
        plan = revived
        base_decision = deepcopy(base_decision)
        base_decision["session_plan"] = revived
    readiness = (plan.get("execution_readiness") or {}) if isinstance(plan.get("execution_readiness"), dict) else {}
    readiness_state = str(readiness.get("state") or "")
    if readiness_state and readiness_state not in {"PENDING_EXECUTION_READY", "MARKET_EXECUTION_READY"}:
        logger.info("Session-plan ladder blocked by execution readiness: %s", readiness.get("reason") or readiness_state or "unknown")
        return _ladder_stop(
            f"execution readiness {readiness_state or 'unknown'}",
            detail=readiness.get("reason"),
        )
    gate = _planner_execution_gate(base_decision, config)
    if not gate.get("allow"):
        logger.info("Session-plan ladder blocked: %s", gate.get("reason"))
        return _ladder_stop(str(gate.get("reason") or "planner gate refused"))
    # R24-0 (2026-08-28): RISK-VETO SUPREMACY. The shared-admission gate
    # above is a PERMISSION; it must never override the risk agent's veto.
    # Live incident: the ladder executed BUY_MARKET 4612.56 while the very
    # same decision carried risk.approved=false / trade_grade F (39) /
    # risk_multiplier 0.0 - the veto sat in the snapshot unread.
    _risk_reason = r24_risk_veto_reason(base_decision, config)
    if _risk_reason:
        logger.info("R24-0 risk veto blocks the session-plan ladder: %s", _risk_reason)
        try:
            _record_decision_audit(
                database, base_decision, config,
                stage="r24 gate", outcome="REFUSED", reason=_risk_reason,
            )
        except Exception:  # noqa: BLE001 - visibility must never crash flow
            logger.debug("r24 audit row failed", exc_info=True)
        return _ladder_stop(_risk_reason)
    symbol = str(base_decision.get("symbol") or plan.get("symbol") or config.get("symbol", "XAU/USD"))
    normalized_symbol = normalize_symbol(symbol)
    symbol_open_trades = [t for t in (open_trades or []) if normalize_symbol(t.get("symbol") or symbol) == normalized_symbol]
    scenario_review = ScenarioGovernor(config).review_new_plan(plan, symbol_open_trades, database=database)
    if scenario_review.get("action") == "KEEP_EXISTING_FAMILY":
        logger.info("Session-plan family kept for %s: %s", symbol, scenario_review.get("reason"))
        return _ladder_stop("scenario family kept", detail=scenario_review.get("reason"))
    if scenario_review.get("action") == "REPLACE_PENDING_FAMILY":
        logger.info("Session-plan family replaced for %s: %s", symbol, scenario_review.get("reason"))
        try:
            telegram.send_scenario_governance(scenario_review, symbol=symbol, side=str(plan.get("session_bias") or ""))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to send scenario family replacement message: %s", exc)
        symbol_open_trades = [
            t for t in symbol_open_trades
            if str(t.get("status") or "").upper() != "PENDING"
        ]
    live_now = [t for t in symbol_open_trades if str(t.get("status") or "").upper() in {"OPEN", "PARTIAL", "TP1_HIT"}]
    if live_now:
        logger.info(
            "Session-plan ladder skipped: %s live trade(s) already open on %s",
            len(live_now), symbol,
        )
        return _ladder_stop(
            f"{len(live_now)} live trade(s) already open", live_trades=len(live_now)
        )

    primary = plan.get("primary_poi") or {}
    standby = plan.get("standby_poi") or {}
    if not isinstance(primary, dict) or not primary:
        logger.info("Session-plan ladder skipped: plan carries no primary POI")
        return _ladder_stop("plan carries no primary POI")

    path4_limit_only = str(gate.get("path") or "") == "SMC_MAP_AUCTION_CONFIRMATION"
    if path4_limit_only:
        if not path4_candidate_matches(gate, primary):
            logger.info("Path 4 blocked: planner primary is not the exact SMC map that earned admission")
            return _ladder_stop("Path 4 primary does not match admitted SMC conditional map")
        # The operator approved one LIMIT at the SMC POI. A standby/add leg
        # would be a second thesis that Auction Flow never confirmed.
        standby = {}

    # Terminal-state guard at the execution boundary. The planner already
    # filters these out when ranking, but a plan can be persisted, replayed
    # from a snapshot, or invalidated between planning and execution -- so the
    # leg that actually creates orders must re-check rather than trust the map.
    if str(primary.get("setup_state") or "").upper() in TERMINAL_SETUP_STATES:
        logger.info(
            "Session-plan ladder blocked: primary leg is in terminal state %s",
            primary.get("setup_state"),
        )
        return _ladder_stop(
            f"primary leg terminal state {primary.get('setup_state')}"
        )
    if isinstance(standby, dict) and standby and str(standby.get("setup_state") or "").upper() in TERMINAL_SETUP_STATES:
        logger.info(
            "Session-plan add leg dropped: standby is in terminal state %s",
            standby.get("setup_state"),
        )
        standby = {}

    if isinstance(standby, dict) and standby:
        drop_reason = _add_leg_rejection_reason(plan, primary, standby, config)
        if drop_reason:
            logger.info("Session-plan add leg dropped: %s", drop_reason)
            standby = {}

    split_decisions = (
        [] if path4_limit_only
        else _split_execution_decisions(
            base_decision, plan, primary,
            standby if isinstance(standby, dict) else None, config,
        )
    )
    if split_decisions:
        plan_decisions = split_decisions
    else:
        primary_decision = _build_plan_ladder_decision(
            base_decision, plan, primary, config,
            limit_only=path4_limit_only,
        )
        if not primary_decision:
            # Most often the market has walked into the mapped area, so the leg
            # prices as MARKET rather than a pending order and this function
            # declines it. Say so, instead of returning zero in silence.
            entry_price = _safe_float(primary.get("entry_price"), 0.0)
            current_price = _safe_float(base_decision.get("current_price"), 0.0)
            distance = abs(price_to_points(entry_price - current_price, symbol=symbol)) if entry_price and current_price else 0.0
            logger.info(
                "Session-plan ladder skipped: primary leg produced no pending order "
                "(entry %.2f vs price %.2f, %.0f pts apart; inside the market threshold "
                "means it would execute now rather than rest as a pending order)",
                entry_price, current_price, distance,
            )
            return _ladder_stop(
                "primary entry too close to price to rest as a pending order",
                entry=round(entry_price, 2), price=round(current_price, 2),
                points_apart=round(distance, 1),
            )
        plan_decisions = [primary_decision] + ([ _build_plan_ladder_decision(base_decision, plan, standby, config) ] if isinstance(standby, dict) and standby else [])

    # Buy-the-dip invariant for the ladder itself (operator 2026-08-18):
    # every ADD/STANDBY leg must rest DEEPER than the first leg — below it
    # for BUY, above it for SELL. Scale-in and cross-path already enforce
    # this for later entries; the ladder assembled both legs in one cycle
    # and never compared them.
    _lead_leg = next((d for d in plan_decisions if d), None)
    if _lead_leg:
        _lead_entry = _safe_float(((_lead_leg.get("signal") or {}).get("entry") or {}).get("price"), 0.0)
        _lead_dir = str(_lead_leg.get("decision") or "").upper()
        _kept: List[Dict[str, Any]] = [_lead_leg]
        for _leg in plan_decisions[1:]:
            if not _leg:
                continue
            _leg_entry = _safe_float(((_leg.get("signal") or {}).get("entry") or {}).get("price"), 0.0)
            _deeper = (_leg_entry < _lead_entry) if _lead_dir == "BUY" else (_leg_entry > _lead_entry)
            if _lead_entry > 0 and _leg_entry > 0 and not _deeper:
                logger.info(
                    "Session-plan add leg dropped for %s: %s entry %.2f is not %s "
                    "the lead entry %.2f (add legs must be the deeper price)",
                    symbol, _decision_ladder_role(_leg), _leg_entry,
                    "below" if _lead_dir == "BUY" else "above", _lead_entry,
                )
                _ladder_stop(
                    f"add leg {_leg_entry:.2f} not deeper than lead {_lead_entry:.2f}")
                continue
            _kept.append(_leg)
        plan_decisions = _kept

    created = 0
    staged_trades = list(symbol_open_trades)
    for ladder_decision in plan_decisions:
        if not ladder_decision:
            continue
        ladder_decision["planner_execution_gate"] = deepcopy(gate)
        stamp_execution_path(ladder_decision, gate)
        # 2026-08-19 (build 12): carry the thesis invalidation into the row so
        # the tick manager can kill ONLY on real thesis death (invalidation
        # breach), never on an arbitrary excursion.
        if isinstance(plan, dict) and plan.get("invalidation_level"):
            ladder_decision["invalidation_level"] = plan.get("invalidation_level")
        ladder_decision.setdefault("reasons", []).append(f"Planner admission: {gate.get('reason')}")
        role = _decision_ladder_role(ladder_decision)
        # R25.6 (operator 2026-08-28): the reinforcement leg travels under
        # its OWN registered path (PATH 8). It reuses the parent's admission
        # - the provenance is kept in the reasons - but the weekly report
        # must count the reinforcement path explicitly, not as the twin.
        if role in {"STANDBY", "ADD_ON"}:
            _parent_path = str((ladder_decision.get("execution_path") or {}).get("id") or "")
            stamp_execution_path(ladder_decision, PATH_8)
            ladder_decision.setdefault("reasons", []).append(
                f"Reinforcement leg (parent admission: {_parent_path or 'shared gate'})")
        # R24-4 (2026-08-28): SNAPSHOT LOCK - a recently cancelled same-side
        # LIMIT forbids re-entering WORSE within the lock window. The market
        # returning to the mapped level remains welcome.
        try:
            from utils.helpers import load_trades as _r24_load_trades
            _leg_entry = _safe_float(
                ((ladder_decision.get("signal") or {}).get("entry") or {}).get("price"), 0.0)
            _leg_side = str(ladder_decision.get("decision") or "").upper()
            # R21-lesson scope: read THIS run's store (database.local_path),
            # never the repo default - otherwise tests and production would
            # each look at a different court record.
            _lock_reason = r24_snapshot_lock_reason(
                _r24_load_trades(getattr(database, "local_path", None)),
                symbol, _leg_side, _leg_entry, config)
        except Exception:  # noqa: BLE001 - gate input problems abstain
            _lock_reason = None
        if _lock_reason:
            logger.info(
                "R24-4 snapshot lock - %s %s leg refused for %s: %s",
                _leg_side, role, symbol, _lock_reason,
            )
            try:
                _record_decision_audit(
                    database, ladder_decision, config,
                    stage="r24 gate", outcome="REFUSED", reason=_lock_reason,
                )
            except Exception:  # noqa: BLE001
                logger.debug("r24 audit row failed", exc_info=True)
            _ladder_stop(_lock_reason)
            continue
        # EVERY exit from the order loop names itself. On 2026-08-04 nine
        # published maps that produced no order carried a gate reason that
        # reads as a PASS, and the audit said "stop not recorded" -- because
        # these in-loop refusals returned without telling `_LAST_LADDER_STOP`.
        # The measured replay of the A+ 97.8% Asia Morning map died at final
        # validation here (breakeven beyond TP1) and left no trace in the row.
        if any(_trade_scenario_id(t) == _decision_scenario_id(ladder_decision) and _trade_ladder_role(t) == role for t in staged_trades):
            _ladder_stop(f"{role} leg already staged for this scenario")
            continue
        duplicate_reason = duplicate_signal_reason(ladder_decision, database, config)
        if duplicate_reason:
            logger.info("Session-plan ladder %s blocked for %s: %s", role, symbol, duplicate_reason)
            _ladder_stop(f"{role} blocked by duplicate filter: {duplicate_reason}")
            if role in {"PRIMARY", "STARTER"}:
                return created
            continue
        ladder_decision = apply_target_distance_caps(ladder_decision, config)
        ladder_violations = validate_signal_before_send(ladder_decision, config, staged_trades)
        if ladder_violations:
            logger.error(
                "Session-plan ladder %s failed final validation for %s: %s",
                role, symbol, "; ".join(ladder_violations),
            )
            _ladder_stop(f"{role} failed final validation: {'; '.join(ladder_violations)}")
            if role in {"PRIMARY", "STARTER"}:
                return created
            continue
        trade_id = database.new_trade_id()
        ladder_decision["trade_id"] = trade_id
        _queue_opposite_exposure_exit(
            ladder_decision, staged_trades, database, config)
        if demo_execution:
            # Broker-first delivery: persist an unsent execution intent. The
            # tick manager sends the rich card only after MT5 accepts it.
            ladder_decision["_telegram_signal_sent"] = False
            database.save_trade(ladder_decision)
            delivered = True
        else:
            delivered = False
            try:
                delivered = bool(telegram.send_signal(ladder_decision))
            except Exception as exc:  # noqa: BLE001
                logger.warning("Failed to send session-plan ladder signal (%s) for %s: %s", role, symbol, exc)
                delivered = False
            if not delivered:
                _ladder_stop(f"{role} telegram delivery failed; order not recorded")
                if role in {"PRIMARY", "STARTER"}:
                    return created
                continue
            database.save_trade(ladder_decision)
        _record_decision_audit(
            database, ladder_decision, config,
            stage="execution_queued" if demo_execution else "delivered",
            outcome="QUEUED" if demo_execution else "SENT",
            reason=f"planner ladder {role}",
        )
        staged_trades.append(
            {
                "id": trade_id,
                "symbol": symbol,
                "type": ladder_decision.get("decision"),
                "status": "OPEN" if str(((ladder_decision.get("signal") or {}).get("order_type") or "")).endswith("MARKET") else "PENDING",
                "entry_price": ((ladder_decision.get("signal") or {}).get("entry") or {}).get("price"),
                "signal_snapshot": ladder_decision,
            }
        )
        created += 1
    return created



def _post_exit_revalidation_review(
    decision: Dict[str, Any],
    closed_trade: Dict[str, Any],
    config: Dict[str, Any],
    *,
    now: datetime,
    symbol: str,
) -> Dict[str, Any]:
    """Allow same-zone re-entry only when a materially new thesis appears.

    Manual-analyst intent:
    - do NOT re-enter just because the previous trade closed;
    - do allow a fresh same-direction entry when there is genuinely new setup
      evidence: a different POI, a stronger setup-state progression, or a fresh
      sweep/displacement event after the previous exit.
    """
    cfg = (config.get("post_exit_revalidation") or {}) if isinstance(config, dict) else {}
    if cfg.get("enabled", True) is False:
        return {"allow": False, "reason": "post-exit revalidation is disabled"}

    new_setup = decision.get("setup_context") or {}
    old_setup = _trade_setup_context(closed_trade)
    if not isinstance(new_setup, dict) or not new_setup:
        return {"allow": False, "reason": "new signal has no rich setup context"}
    if not old_setup:
        return {"allow": False, "reason": "previous trade has no setup context to prove a new thesis"}

    new_key = str(new_setup.get("state_key") or "")
    old_key = str(old_setup.get("state_key") or "")
    new_type = str(new_setup.get("setup_type") or "")
    old_type = str(old_setup.get("setup_type") or "")
    new_poi = str(new_setup.get("poi_type") or "")
    old_poi = str(old_setup.get("poi_type") or "")

    zone_shift_pts = 0.0
    new_mid = _setup_zone_midpoint(new_setup)
    old_mid = _setup_zone_midpoint(old_setup)
    if new_mid is not None and old_mid is not None:
        zone_shift_pts = abs(price_to_points(new_mid - old_mid, symbol=symbol))
    new_poi_min_distance_points = float(cfg.get("new_poi_min_distance_points", 80) or 80)
    different_poi = bool(
        new_key and old_key and new_key != old_key and (
            zone_shift_pts >= new_poi_min_distance_points or new_type != old_type or new_poi != old_poi
        )
    )

    old_state_rank = _setup_state_rank(old_setup.get("setup_state"))
    new_state_rank = _setup_state_rank(new_setup.get("setup_state"))
    min_state_progress_steps = int(cfg.get("min_state_progress_steps", 1) or 1)
    state_progressed = new_state_rank >= old_state_rank + min_state_progress_steps

    old_trigger_score = _safe_float(old_setup.get("trigger_score"), 0.0)
    new_trigger_score = _safe_float(new_setup.get("trigger_score"), 0.0)
    min_trigger_score_improvement = float(cfg.get("min_trigger_score_improvement", 8) or 8)
    trigger_improved = new_trigger_score >= old_trigger_score + min_trigger_score_improvement
    new_trigger_state = str(new_setup.get("trigger_state") or "").upper()
    old_trigger_state = str(old_setup.get("trigger_state") or "").upper()
    rejection_upgrade = new_trigger_state == "REJECTION_CONFIRMED" and old_trigger_state != "REJECTION_CONFIRMED"

    old_disp = _safe_float(old_setup.get("displacement_score"), 0.0)
    new_disp = _safe_float(new_setup.get("displacement_score"), 0.0)
    min_displacement_improvement = float(cfg.get("min_displacement_improvement", 5) or 5)
    displacement_improved = new_disp >= old_disp + min_displacement_improvement

    exit_time = _trade_reference_time(closed_trade, now)
    new_sweep_time = _setup_sweep_time(new_setup)
    old_sweep_time = _setup_sweep_time(old_setup)
    fresh_sweep_after_exit = bool(new_sweep_time and new_sweep_time > exit_time and (old_sweep_time is None or new_sweep_time > old_sweep_time))

    old_dom = _safe_float(old_setup.get("thesis_dominance_score"), 0.0)
    new_dom = _safe_float(new_setup.get("thesis_dominance_score"), 0.0)
    min_dominance_improvement = float(cfg.get("min_dominance_improvement", 6) or 6)
    dominance_improved = new_dom >= old_dom + min_dominance_improvement

    if different_poi:
        return {
            "allow": True,
            "reason": f"new POI / state_key detected (zone shift {zone_shift_pts:.0f} pts)",
        }
    if state_progressed and (trigger_improved or rejection_upgrade or dominance_improved):
        return {
            "allow": True,
            "reason": "setup state progressed with stronger trigger / thesis quality",
        }
    if fresh_sweep_after_exit and (displacement_improved or rejection_upgrade or dominance_improved):
        return {
            "allow": True,
            "reason": "fresh post-exit sweep / displacement created a new same-direction thesis",
        }

    blockers = []
    if not different_poi:
        blockers.append("no materially new POI")
    if not state_progressed:
        blockers.append("no stronger setup-state progression")
    if not fresh_sweep_after_exit:
        blockers.append("no fresh sweep after the previous exit")
    if not (trigger_improved or rejection_upgrade):
        blockers.append("trigger did not improve enough")
    if not dominance_improved:
        blockers.append("thesis dominance did not improve enough")
    return {"allow": False, "reason": "; ".join(blockers[:3])}


def _trade_tp2_price(trade: Dict[str, Any]) -> float | None:
    """The TP2 level a closed trade was actually settled at."""
    for key in ("tp2", "take_profit_2"):
        try:
            value = float(trade.get(key) or 0)
        except (TypeError, ValueError):
            continue
        if value > 0:
            return value
    snapshot = _trade_setup_context(trade)
    if isinstance(snapshot, dict):
        try:
            value = float((snapshot.get("signal") or {}).get("tp2") or 0)
        except (TypeError, ValueError):
            value = 0.0
        if value > 0:
            return value
    return None


def _trim_zero(value: float) -> str:
    """Format a possibly-fractional hour count without lying about it.

    ``f"{2.5:.0f}"`` renders "2", so a 2.5-hour window announced itself as
    "within 2h" -- the message contradicted the rule enforcing it. Keeping
    one decimal only when it carries information means 3.0 stays "3" and
    2.5 stays "2.5".
    """
    text = f"{float(value):.1f}"
    return text[:-2] if text.endswith(".0") else text


def _post_tp2_reentry_block(
    decision: Dict[str, Any],
    candidates: List[Dict[str, Any]],
    config: Dict[str, Any],
    *,
    now: datetime,
    symbol: str,
    entry_price: float,
    direction: str,
) -> str | None:
    """After a trade takes TP2, refuse a same-direction re-entry too near it.

    TP2 is where a move ENDS, because it is where the liquidity that fuelled
    it was consumed. Re-entering the same direction at that same level is
    entering into the bounce, and the existing cooldown could not see it: it
    measures distance from the previous trade's ENTRY, not from the level it
    closed at.

    2026-07-31 is the case that motivated this rule. d917b1d5 took TP2 at
    4029.17 around 13:50. Twenty-one minutes later b4f85832 was published as
    a SELL LIMIT at 4031.77 -- 26 points above that TP2 -- and by 15:21 it
    was 116 points offside. The old guard skipped it because it sat 430
    points from the prior ENTRY (4074.78), outside the 200-pt duplicate zone.

    Measuring from TP2 is the whole point of this check.

    BOTH DIRECTIONS, MIRRORED
    -------------------------
    The safe side is always AWAY from the exhausted level, back toward where
    the move began:

        SELL: TP2 sits below entry, so a new SELL must be ABOVE it
              -> entry - tp2 >= min_distance_points
        BUY:  TP2 sits above entry, so a new BUY must be BELOW it
              -> tp2 - entry >= min_distance_points

    A re-entry on the far side of TP2 -- already beyond the level -- is not a
    repeat of the exhausted move and is left alone.

    Only a same-direction trade arms the rule: a BUY after a SELL's TP2 is a
    reversal, not a repeat.

    Also:
      * Time-boxed: the block expires after ``window_hours``.
      * Overridden by a genuinely new thesis -- the same
        ``_post_exit_revalidation_review`` evidence already used elsewhere
        (a different POI, a fresh sweep after the exit, or a state
        progression with a stronger trigger). A trend that keeps giving new
        structure is not blocked; a lazy re-entry at an exhausted level is.

    No risk setting is touched: this refuses a signal, it never resizes,
    re-prices or re-stops one.
    """
    cfg = (config.get("post_tp2_reentry") or {}) if isinstance(config, dict) else {}
    if _tr.post_tp2_rule({"post_tp2_reentry": cfg})["enabled"] is False:
        return None
    if direction not in {"BUY", "SELL"}:
        return None

    rule = _tr.post_tp2_rule({"post_tp2_reentry": cfg})
    min_distance_points = rule["min_distance_points"]
    window_hours = rule["window_hours"]
    if min_distance_points <= 0 or window_hours <= 0:
        return None

    for trade in candidates:
        if _trade_outcome(trade) == "OPEN":
            continue
        if str(trade.get("status") or "").upper() != "TP2_HIT":
            continue
        # Only the same direction repeats an exhausted move.
        if _trade_direction(trade) != direction:
            continue
        tp2 = _trade_tp2_price(trade)
        if tp2 is None or tp2 <= 0:
            continue

        closed_at = _trade_reference_time(trade, now)
        hours_since = (now - closed_at).total_seconds() / 3600.0
        if hours_since < 0 or hours_since > window_hours:
            continue

        # Operator directive 2026-08-07 (داac4022): the rule is ABSOLUTE for
        # the whole window. A new BUY must sit at least min_distance_points
        # BELOW the exhausted TP2 (a SELL, above it) -- an entry ON or BEYOND
        # the exhausted level is chasing the consumed move, which is exactly
        # what the rule exists to refuse. The earlier "far side is not a
        # repeat" exemption let the 10:02 BUY at 4317.26 sail 172 pts ABOVE
        # the 4300.00 TP2 taken hours earlier.
        if direction == "SELL":
            distance = price_to_points(entry_price - tp2, symbol=symbol)
            side_word = "above"
        else:
            distance = price_to_points(tp2 - entry_price, symbol=symbol)
            side_word = "below"
        if distance >= min_distance_points:
            continue

        # 2026-08-07 (operator option 1): NO early release. The "new thesis"
        # revalidation override is gone; the block expires only by the
        # window. _post_exit_revalidation_review stays in use by the other
        # post-exit cooldown path, untouched.
        if distance < 0:
            where = (f"{-distance:.0f} pts BEYOND the TP2 (chasing the "
                     f"consumed move)")
        else:
            where = f"only {distance:.0f} pts {side_word} the TP2"
        return (
            f"Post-TP2 re-entry blocked: {direction} entry {entry_price:.2f} is "
            f"{where} {tp2:.2f} taken {hours_since:.1f}h ago "
            # The window accepts fractions (2.5 since 2026-08-03). ".0f"
            # rounded it for display, so a 2.5-hour rule announced itself as
            # "within 2h" -- a message that contradicts the rule it is
            # reporting. Trim only a trailing ".0" so whole numbers still
            # read "3h" rather than "3.0h".
            f"(needs ≥{min_distance_points:.0f} pts {side_word} within "
            f"{_trim_zero(window_hours)}h; absolute, no early release)."
        )
    return None


def _post_tp2_reentry_reason(
    decision: Dict[str, Any], database: DatabaseService, config: Dict[str, Any]
) -> str | None:
    """The post-TP2 block, callable independently of the duplicate filter.

    ``duplicate_signal_reason`` runs this check as part of its sweep, but the
    adaptive-execution path skips that whole function on purpose (a
    replacement order is meant to resemble the order it replaces). An
    exhausted target level is exhausted regardless of which route the signal
    took, so this wrapper lets the block be evaluated on its own.

    Same candidate set as the duplicate filter -- open trades plus recent
    history in the same direction and symbol -- so the two paths cannot drift
    apart in what they look at.
    """
    direction = str(decision.get("decision") or "").upper()
    if direction not in {"BUY", "SELL"}:
        return None
    signal = decision.get("signal") or {}
    entry_info = signal.get("entry") or {}
    entry_price = _safe_float(
        entry_info.get("price") if isinstance(entry_info, dict) else None, 0.0
    ) or _safe_float(decision.get("current_price"), 0.0)
    if entry_price <= 0:
        return None

    symbol = str(
        decision.get("symbol") or signal.get("symbol") or config.get("symbol", "XAU/USD")
    )
    normalized = normalize_symbol(symbol)

    candidates: List[Dict[str, Any]] = []
    seen: set = set()
    # A guard that cannot see the trade cannot guard against it.
    #
    # `get_recent_trades` orders by created_at and truncates. A trade that
    # OPENED at 11:26 and took TP2 at 13:38 is old by creation order, so once
    # enough newer rows exist -- cancelled pendings, ladder legs, the other
    # symbol -- it falls out of the window entirely.
    #
    # 2026-08-03: TP2 was taken at 4022.31 at 13:38 and a SELL LIMIT went out
    # at 4037.48 at 14:10, 152 points above it. The rule was configured, the
    # code was deployed, and it allowed the signal because the closed trade
    # was no longer in the list it was handed. Reproduced with 60 newer rows:
    # the guard returns ALLOWED and the TP2 row is absent from limit=50.
    #
    # The window this rule cares about is TIME SINCE CLOSING, so ask for
    # enough history to cover it rather than trusting a fixed row count. The
    # filter below still discards anything outside the configured hours.
    window_hours = _tr.post_tp2_rule(config or {})["window_hours"]
    # ~12 five-minute cycles an hour, and a cycle can write several rows.
    # Scaled to the window with a floor that keeps the old behaviour for
    # short windows, and a ceiling so a misconfiguration cannot pull the
    # whole table.
    lookback_rows = int(min(500, max(50, window_hours * 120)))
    since_iso = (
        datetime.now(timezone.utc) - timedelta(hours=window_hours)
    ).replace(microsecond=0).isoformat()
    try:
        pool = list(database.get_open_trades() or []) + list(
            database.get_recent_trades(limit=lookback_rows) or []
        )
        # Ask the database directly for trades that CLOSED inside the window.
        # This is the authoritative source for this rule; the wider row scan
        # above stays as a fallback for schemas without a closed_at column.
        if hasattr(database, "get_trades_closed_since"):
            try:
                pool += list(
                    database.get_trades_closed_since(since_iso, symbol=symbol) or []
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("Post-TP2 guard could not read closed trades: %s", exc)
    except Exception as exc:  # noqa: BLE001 - a guard must not break the cycle
        logger.warning("Post-TP2 guard could not read trade history: %s", exc)
        return None
    for trade in pool:
        if not isinstance(trade, dict):
            continue
        if normalize_symbol(trade.get("symbol") or symbol) != normalized:
            continue
        if _trade_direction(trade) != direction:
            continue
        tid = str(trade.get("id") or "")
        if tid and tid in seen:
            continue
        if tid:
            seen.add(tid)
        candidates.append(trade)

    return _post_tp2_reentry_block(
        decision, candidates, config,
        now=datetime.now(timezone.utc), symbol=symbol,
        entry_price=entry_price, direction=direction,
    )


def duplicate_signal_reason(decision: Dict[str, Any], database: DatabaseService, config: Dict[str, Any]) -> str | None:
    filt = config.get('duplicate_signal_filter', {}) or {}
    if not filt.get('enabled', True): return None
    direction = str(decision.get('decision', '')).upper()
    if direction not in {'BUY', 'SELL'}: return None
    signal = decision.get('signal', {}) or {}
    entry = signal.get('entry', {}) or {}
    try:
        entry_price = float(entry.get('price') or decision.get('current_price') or 0)
    except (TypeError, ValueError):
        entry_price = 0.0
    if entry_price <= 0: return None
    now = datetime.now(timezone.utc)
    price_zone_points = float(filt.get('price_zone_points', filt.get('same_direction_price_zone_points', 50)))
    open_cfg = filt.get('open_trade', {}) or {}
    block_open_any_price = bool(open_cfg.get('block_same_direction_any_price', filt.get('block_if_open_same_direction', False)))
    block_open_in_zone = bool(open_cfg.get('block_same_direction_in_zone', True))
    max_open_same_direction = int(open_cfg.get('max_open_same_direction', filt.get('max_open_same_direction', 2)))
    cooldown_cfg = filt.get('cooldown', {}) or {}
    legacy_cooldown = float(filt.get('lookback_minutes', 90))
    cooldown_after_loss = float(cooldown_cfg.get('after_loss_minutes', legacy_cooldown))
    cooldown_after_breakeven = float(cooldown_cfg.get('after_breakeven_minutes', max(legacy_cooldown * 0.5, 30)))
    cooldown_after_win = float(cooldown_cfg.get('after_win_minutes', max(legacy_cooldown * 0.33, 20)))
    lookback_hours = float(cooldown_cfg.get('lookback_hours', 6))
    symbol = str(decision.get("symbol") or (decision.get("signal", {}) or {}).get("symbol") or config.get("symbol", "XAU/USD"))

    def _points_away(prev_price: float) -> float:
        return abs(price_to_points(entry_price - prev_price, symbol=symbol))

    candidates: List[Dict[str, Any]] = []
    seen_ids: set = set()

    def _add(trade: Dict[str, Any]) -> None:
        trade_symbol = str(trade.get('symbol') or config.get('symbol', 'XAU/USD')).upper()
        if trade_symbol != str(symbol).upper(): return
        tid = str(trade.get('id', ''))
        if tid and tid in seen_ids: return
        if tid: seen_ids.add(tid)
        candidates.append(trade)

    for trade in database.get_open_trades():
        if _trade_direction(trade) == direction: _add(trade)
    for trade in database.get_recent_trades(limit=50):
        if _trade_direction(trade) == direction: _add(trade)

    if max_open_same_direction > 0:
        open_same_direction = [t for t in candidates if _trade_outcome(t) == "OPEN"]
        if len(open_same_direction) >= max_open_same_direction:
            return f"Same-direction exposure cap: {len(open_same_direction)} open {direction} trade(s) already exist, blocking another {direction}."

    # A target that was reached is an exhausted level, not a fresh one.
    post_tp2 = _post_tp2_reentry_block(
        decision, candidates, config,
        now=now, symbol=symbol, entry_price=entry_price, direction=direction,
    )
    if post_tp2:
        return post_tp2

    for trade in candidates:
        if _trade_outcome(trade) == "OPEN":
            prev_entry = _trade_entry_price(trade)
            if prev_entry is None: continue
            if _ladder_sibling_allowed(decision, trade):
                continue
            if block_open_any_price: return f"Duplicate {direction} blocked: one position per direction."
            if block_open_in_zone:
                pts = _points_away(prev_entry)
                if pts <= price_zone_points: return f"Duplicate {direction} blocked: already open in same price zone."
        else:
            outcome = _trade_outcome(trade)
            prev_entry = _trade_entry_price(trade)
            if prev_entry is None: continue
            ref_time = _trade_reference_time(trade, now)
            age_minutes = (now - ref_time).total_seconds() / 60.0
            if age_minutes > lookback_hours * 60.0: continue
            pts = _points_away(prev_entry)
            if pts > price_zone_points: continue
            cooldown = {"LOSS": cooldown_after_loss, "WIN": cooldown_after_win}.get(outcome, cooldown_after_breakeven)
            if age_minutes <= cooldown:
                review = _post_exit_revalidation_review(decision, trade, config, now=now, symbol=symbol)
                if review.get("allow"):
                    continue
                detail = str(review.get("reason") or "").strip()
                suffix = f" Revalidation: {detail}." if detail else ""
                return f"Post-exit revalidation blocked: recently closed {outcome} trade in same zone.{suffix}"
    return None


def _dedupe_warnings(warnings: list) -> list:
    seen: set = set()
    result: list = []
    news_block_kept = False
    for w in warnings:
        text = str(w).strip()
        if not text: continue
        key = " ".join(text.lower().split())
        if key in seen: continue
        lower = text.lower()
        if lower.startswith("news blocked") or lower.startswith("ai news blocked"):
            if news_block_kept: continue
            news_block_kept = True
        seen.add(key)
        result.append(text)
    return result


def _safe_float(value: Any, default: float = 0.0) -> float:
    try: return float(value)
    except (TypeError, ValueError): return default


def _levels_from_results(all_results: Dict[str, Any], side: str) -> List[float]:
    """Extract support/resistance levels relevant for a fixed-risk scale-in.

    BUY scale-ins are considered near support below/around price; SELL scale-ins
    are considered near resistance above/around price.  The project has used a
    few different key names over time, so this helper accepts the common shapes
    without raising when an agent omits a section.
    """
    side = str(side or "").upper()
    wanted_keys = (
        ("support_levels", "supports", "support")
        if side == "BUY"
        else ("resistance_levels", "resistances", "resistance")
    )
    levels: List[float] = []
    for section_name in ("classical", "smc", "price_action", "technical", "multitimeframe", "auction_flow"):
        section = all_results.get(section_name, {}) or {}
        for key in wanted_keys:
            raw = section.get(key)
            if raw is None:
                continue
            if not isinstance(raw, list):
                raw = [raw]
            for item in raw:
                value = item.get("price") if isinstance(item, dict) else item
                price = _safe_float(value, 0.0)
                if price > 0:
                    levels.append(price)
    return levels


def _scaled_add_trigger(fr: Dict[str, Any], config: Dict[str, Any], symbol: str) -> float:
    """R26.9.7: the configured scale-in trigger is GOLD points; the operator's
    ratio law scales it per symbol (gold 1.0 / WTI x0.5 / FX x1.8 — derived
    from the law's own caps, single source: utils.trading_rules.distance_ratio).
    A 270-pt gold pullback demand was being imposed verbatim on forex
    (27 pips) and oil — same defect class as BUILD31-R13 / R26.9.5-9.6."""
    return float(fr.get("scale_in_trigger_points", 150) or 150) * _tr.distance_ratio(config, symbol)


#: R26.9.8: the add engine's mechanical screen (operator 2026-08-18d).
#: Deliberately NAMED and module-level so the one-open-per-symbol law
#: (risk agent, 2026-09-01) can be frozen OUT of it: the scale-in is the
#: only legal second position on a symbol, and it must never be blocked by
#: a check that exists to stop second DIRECT entries. Grade/quality of the
#: instant does not gate an add either.
_MECH_FILTERS = {"max_open_trades_filter", "max_daily_signals_filter",
                 "atr_filter", "spread_filter", "consecutive_losses_filter"}


def _scale_in_count_for_parent(open_trades: List[Dict[str, Any]], parent_id: str) -> int:
    """Count already-open scale-ins for a parent trade from known schema shapes."""
    count = 0
    for trade in open_trades:
        signal = trade.get("signal") or (trade.get("signal_snapshot", {}) or {}).get("signal", {}) or {}
        if not isinstance(signal, dict):
            signal = {}
        if bool(signal.get("scale_in") or trade.get("scale_in")) and str(
            signal.get("parent_trade_id") or trade.get("parent_trade_id") or ""
        ) == str(parent_id):
            count += 1
    return count


async def _check_scale_in(
    config: Dict[str, Any],
    all_results: Dict[str, Any],
    open_trades: List[Dict[str, Any]],
    database: DatabaseService,
    telegram: TelegramService,
    *,
    demo_execution: bool = False,
) -> None:
    """Send and persist scale-in (add) trades when price retests a level.

    Rules (operator 2026-08-18b):
    1. Pullback of >= trigger_points (150) from parent entry — better price only
    2. NO fresh consensus needed: the parent earned it at entry. The one
       agent condition is the hard veto — >= 2 qualified opponents = no add
    3. One add per parent (scale_in_max=1); max 2 live positions
    4. All risk filters pass (news, spread, ATR, etc.)
    """
    oe = config.get("order_execution", {}) or {}
    fr = oe.get("fixed_risk", {}) or {}
    symbol = str(all_results.get("symbol") or config.get("symbol") or "XAU/USD")
    # R25.14 (operator 2026-08-28, "نفذ جولة الاثبات من الجاني"): every
    # scale-in decision writes a court-record row (storage/decision_audit,
    # stage="scale_in") naming the cause verbatim - the gate, the measured
    # distance, the qualified opponents by name, the failed filter. Pure
    # EVIDENCE: nothing here changes any decision; the logger.info lines
    # stay exactly as they were (log-only reasons proved unanswerable
    # after the fact: the GBP/USD add question on 2026-08-28).
    def _scale_in_audit(audit_outcome: str, audit_reason: str,
                        parent_id: str = "", side_hint: str = "",
                        entry_price: float = 0.0) -> None:
        try:
            database.save_decision_audit({
                "symbol": symbol,
                "stage": "scale_in",
                "outcome": audit_outcome,
                "side": side_hint,
                "reason": str(audit_reason)[:500] or None,
                "entry_price": round(entry_price, 5) if entry_price else None,
                "trade_id": parent_id or None,
            })
        except Exception as _aud_exc:  # noqa: BLE001 - evidence never breaks trading
            logger.warning("Scale-in audit row failed (%s %s): %s",
                           audit_outcome, symbol, _aud_exc)

    # The scale-in engine historically lived behind entry_style=="fixed_risk"
    # and the guard survived the system's move to "hybrid" — so the whole
    # add path silently never ran: on 2026-08-18 a live BUY sat 156 points
    # into a clean-book pullback (opp=0 for an hour) and the log showed no
    # Scale-in line at all, not even a refusal. The operator's add policy
    # is system policy, not a legacy-mode feature: allow both styles, and
    # name every early exit instead of returning in silence.
    entry_style = str(oe.get("entry_style", "")).lower()
    if entry_style not in {"fixed_risk", "hybrid"}:
        logger.info("Scale-in skipped for %s: entry_style=%s supports no adds", symbol, entry_style or "unset")
        _scale_in_audit("BLOCKED", "entry_style=%s supports no adds" % (entry_style or "unset"))
        return
    if not bool(fr.get("scale_in_enabled", False)):
        logger.info("Scale-in skipped for %s: scale_in_enabled=false", symbol)
        _scale_in_audit("BLOCKED", "scale_in_enabled=false")
        return
    if _is_news_hard_block({}, all_results):
        logger.info("Scale-in skipped for %s: news hard block active", symbol)
        _scale_in_audit("BLOCKED", "news hard block active")
        return

    current_price = _safe_float(all_results.get("current_price"), 0.0)
    if current_price <= 0:
        return
    # R26.9.7: the configured trigger is GOLD points; the ratio law scales it.
    trigger_points = _scaled_add_trigger(fr, config, symbol)
    max_scale_ins = int(fr.get("scale_in_max", 1) or 1)
    if max_scale_ins <= 0:
        _scale_in_audit("BLOCKED", "scale_in_max<=0")
        return

    # Respect the same-direction cap: count all open trades in this direction
    # (parents + scale-ins). If already at the limit, no more scale-ins.
    max_open_same_dir = int(
        (config.get("duplicate_signal_filter", {}) or {})
        .get("open_trade", {})
        .get("max_open_same_direction", 2)
    )

    # POST-LOSS COOLDOWN FOR ADDS (operator 2026-08-18h, fix 2 of 3).
    # duplicate_signal_reason applies after_loss_minutes (90) to new
    # SIGNALS, but the add path never called it — so on 2026-08-18 a fresh
    # BUY add entered minutes after the previous BUY add stopped out, six
    # times in a row. A same-direction SL_HIT inside the window freezes
    # ALL adds in that direction on this symbol: a stop that just fired is
    # the market rejecting the thesis, and an add is the last order that
    # should argue with it.
    _cool_cfg = (config.get("duplicate_signal_filter", {}) or {}).get("cooldown", {}) or {}
    _cool_minutes = float(_cool_cfg.get("after_loss_minutes", 90) or 90)
    _now_utc = datetime.now(timezone.utc)
    _cooldown_side: Dict[str, datetime] = {}
    if _cool_minutes > 0:
        try:
            for _t in database.get_recent_trades(limit=50):
                if normalize_symbol(_t.get("symbol") or symbol) != normalize_symbol(symbol):
                    continue
                if _trade_outcome(_t) != "LOSS":
                    continue
                _ref = _trade_reference_time(_t, _now_utc)
                _age_min = (_now_utc - _ref).total_seconds() / 60.0
                if 0 <= _age_min <= _cool_minutes:
                    _d = _trade_direction(_t)
                    if _d in {"BUY", "SELL"}:
                        _prev = _cooldown_side.get(_d)
                        if _prev is None or _ref > _prev:
                            _cooldown_side[_d] = _ref
        except Exception as _cool_exc:  # noqa: BLE001 - cooldown scan must not break the cycle
            logger.warning("Scale-in cooldown scan failed (adds proceed unguarded): %s", _cool_exc)

    for parent in open_trades:
        parent_id = str(parent.get("id") or parent.get("trade_id") or "")
        side = _trade_direction(parent)
        if not parent_id or side not in {"BUY", "SELL"}:
            continue
        if str(parent.get("status", "OPEN")).upper() not in {"OPEN", "PARTIAL", "TP1_HIT"}:
            continue
        # AN ADD IS NEVER A PARENT (operator 2026-08-18h, fix 1 of 3).
        # "One add per parent" was true per-parent yet false per-thesis:
        # each add, once open, became a legitimate parent for the NEXT add,
        # and every SL_HIT freed a seat under the 2-open cap. Live chain,
        # 2026-08-18 13:31->15:21: six BUY adds walked a falling knife
        # (13:31, 13:56, 14:36, 15:01, 15:16, 15:21) — a martingale the
        # operator explicitly never ordered. Only an ORIGINAL entry may
        # anchor an add; scale-in rows are barred from the parent census.
        _p_signal = parent.get("signal") or (parent.get("signal_snapshot", {}) or {}).get("signal", {}) or {}
        if not isinstance(_p_signal, dict):
            _p_signal = {}
        if bool(_p_signal.get("scale_in") or parent.get("scale_in")):
            _scale_in_audit("BLOCKED", "parent is itself a scale-in (an add is never a parent)", parent_id, side)
            continue
        if side in _cooldown_side:
            _since = (_now_utc - _cooldown_side[side]).total_seconds() / 60.0
            logger.info(
                "Scale-in blocked for %s %s: same-direction loss %.0f min ago "
                "(cooldown %.0f min) — no adds while the market is rejecting the thesis",
                side, symbol, _since, _cool_minutes,
            )
            _scale_in_audit("BLOCKED",
                            "post-loss cooldown: same-direction LOSS %.0f min ago (window %.0f min)"
                            % (_since, _cool_minutes), parent_id, side)
            continue
        if _scale_in_count_for_parent(open_trades, parent_id) >= max_scale_ins:
            _scale_in_audit("BLOCKED", "one add per parent already used (%d/%d)"
                            % (_scale_in_count_for_parent(open_trades, parent_id), max_scale_ins),
                            parent_id, side)
            continue

        # Block scale-in if total open trades in same direction already at cap
        if max_open_same_dir > 0:
            open_same_dir = len([t for t in open_trades if _trade_direction(t) == side and str(t.get("status", "OPEN")).upper() in {"OPEN", "PARTIAL", "TP1_HIT"}])
            if open_same_dir >= max_open_same_dir:
                logger.info(
                    "Scale-in blocked for %s %s: %d open same-direction trades already at cap %d",
                    side, symbol, open_same_dir, max_open_same_dir,
                )
                _scale_in_audit("BLOCKED", "same-direction open cap reached (%d/%d)"
                                % (open_same_dir, max_open_same_dir), parent_id, side)
                continue

        parent_entry = _safe_float(parent.get("entry_price"), 0.0)

        # Scale-in only at a BETTER price than the parent entry:
        #   BUY  → price must be at least trigger_points BELOW entry (pullback/discount)
        #   SELL → price must be at least trigger_points ABOVE entry (pullback/discount)
        # This prevents scale-ins at the same price or worse (adding to a loser).
        if parent_entry > 0:
            if side == "BUY":
                pullback_pts = price_to_points(parent_entry - current_price, symbol=symbol)
            else:
                pullback_pts = price_to_points(current_price - parent_entry, symbol=symbol)
            if pullback_pts < trigger_points:
                logger.info(
                    "Scale-in skipped for %s %s: price %.2f is only %.0f pts pullback from entry %.2f (need ≥%d pts %s entry)",
                    side, symbol, current_price, pullback_pts, parent_entry, trigger_points,
                    "below" if side == "BUY" else "above",
                )
                _scale_in_audit("BLOCKED",
                                "distance short: %.0f pts pullback < %d required (%.2f vs entry %.2f)"
                                % (pullback_pts, trigger_points, current_price, parent_entry),
                                parent_id, side, current_price)
                continue

        # Scale-in is a NEW entry and must use the exact shared
        # Entry/Thesis admission function, including opposition and the
        # two-agent + Macro/Gemini paths. A local confidence formula here used
        # to create a second, inconsistent book.
        agent_names = ["technical", "multitimeframe", "classical", "smc", "price_action", "auction_flow"]
        admission_details = _compact_agent_details(all_results)
        # R26.9.12 (operator 2026-09-02: "الذهب هو المرجع — طبّق نفس القوانين
        # مع النسبة"): GOLD's add law is that THE macro voice entitled to
        # judge the symbol sits in the admission book (shared admission +
        # the >=2-opponents hard veto). The pass-through compactor shipped
        # the DOLLAR/gold verdict to every symbol (crude judged by the gold
        # regime, forex by the dollar vote) while the oil entry arrived
        # signal-WAIT (its lean rides in `bias`, which the compactor does
        # not read) -- so WTI adds ran with NO oil voice and FX adds with
        # the wrong one. Strip both pass-throughs and inject the ONE routed
        # voice (services.macro_voice, the same reader Paths 1/2/6 use):
        # gold -> macro_fundamental (byte-identical verdict), WTI ->
        # oil_macro, FX -> its per-symbol bias (BULLISH_EURUSD ...). No
        # committed verdict -> no entry at all (fail-open), exactly like
        # gold on a silent day.
        admission_details.pop("macro_fundamental", None)
        admission_details.pop("oil_macro", None)
        try:
            from services.macro_voice import macro_voice
            _mv = macro_voice({"symbol": symbol}, all_results, config)
            if str(_mv.get("side") or "").upper() in {"BUY", "SELL"}:
                admission_details[str(_mv.get("source") or "macro_fundamental")] = {
                    "direction": str(_mv["side"]).upper(),
                    "confidence": _safe_float(_mv.get("conf"), 0.0),
                }
        except Exception:  # noqa: BLE001 - routing must never block an add
            pass
        admission = evaluate_directional_admission(side, admission_details, config)
        agree_count = int(admission.get("support_count", 0) or 0)
        consensus_conf = _safe_float(admission.get("confidence"), 0.0)
        # Hard opposition veto (operator 2026-08-18, census widened
        # 2026-08-18f choice A): a scale-in is averaging a live position,
        # not opening a fresh idea — >= 2 qualified opponents means NO add,
        # whatever the weighted net says. The census is VETO_AGENTS (the
        # five voters + auction_flow): the 15:01 add card itself displayed
        # "price_action SELL 68 + auction_flow SELL 71" yet entered,
        # because the counter only saw the voters and read 1 < 2. A veto is
        # not a vote — the standalone flow reader opposes with full rights.
        from services.thesis_consensus import count_veto_opponents
        _veto = count_veto_opponents(side, admission_details, config)
        oppose_count = int(_veto["count"])
        # R26.9.13 (operator 2026-09-02: "لا تعزيز إذا وكيلان معارضان من
        # عائلتين"): the veto counts DISTINCT FAMILIES, not names. The family
        # doctrine (2026-08-17) is why the voters exist apart: technical,
        # multitimeframe and classical read the same trend inputs and are
        # wrong TOGETHER -- two of them opposing is ONE correlated voice, not
        # two. The name-count veto blocked lawful adds on exactly that
        # correlated pair. Unlisted voices (auction_flow, macro_fundamental,
        # oil_macro) are each their own family.
        _veto_families: Dict[str, list] = {}
        try:
            from services.thesis_consensus import _agent_families
            _fam_map = _agent_families(config)
        except Exception:  # noqa: BLE001 - the veto must never crash an add
            _fam_map = {}
        for _opp in (_veto.get("opponents") or []):
            _fam = str(_fam_map.get(str(_opp), str(_opp)))
            _veto_families.setdefault(_fam, []).append(str(_opp))
        if oppose_count >= 2 and len(_veto_families) >= 2:
            logger.info(
                "Scale-in blocked for %s %s: %d qualified opponents across %d families (%s) — hard veto, adds require opponents from TWO families",
                side, symbol, oppose_count, len(_veto_families),
                ", ".join(f"{f}: {', '.join(n)}" for f, n in _veto_families.items()),
            )
            _scale_in_audit("BLOCKED",
                            "hard veto: %d qualified opponents across %d families (%s) — adds require opponents from TWO families"
                            % (oppose_count, len(_veto_families),
                               ", ".join(
                                   "%s@%.0f" % (name, float((admission_details.get(name) or {}).get("confidence") or 0.0))
                                   for name in (_veto.get("opponents") or [])),
                               ),
                            parent_id, side, current_price)
            continue
        if oppose_count >= 2:
            logger.info(
                "Scale-in for %s %s: %d qualified opponents but ONE family (%s) — one correlated voice, no two-family veto",
                side, symbol, oppose_count,
                ", ".join(f"{f}: {', '.join(n)}" for f, n in _veto_families.items()),
            )
            _scale_in_audit("ONE_FAMILY_PASS",
                            "%d qualified opponents but ONE family (%s) — one correlated voice, the two-family veto does not fire"
                            % (oppose_count, ", ".join(sorted(_veto_families))),
                            parent_id, side, current_price)
        # CORRECTION (operator 2026-08-18b): the add does NOT need a fresh
        # shared admission. The parent already earned consensus at entry;
        # the add's job is a better price on the SAME thesis, and demanding
        # a new full admission at the pullback (when momentum agents
        # naturally read against it) made adds nearly impossible. The whole
        # qualification is now the veto above: >= 2 qualified opponents
        # block the add, anything less is allowed. Distance (150), better
        # price only, one add per parent (scale_in_max=1), the 2-open cap,
        # and the risk filters still apply.
        min_agent_conf = _safe_float(
            admission.get("min_agent_confidence"),
            _safe_float((config.get("signal_requirements") or {}).get("agent_min_confidence"), 65.0),
        )

        # Check risk filters — MECHANICAL ones only (operator 2026-08-18d).
        #
        # The first live add attempt (13:11, gold 150+ pts into a clean-book
        # pullback, zero opponents) was refused by the AGGREGATE
        # risk["approved"], and the culprit was trade_grade_filter: the
        # moment grade is computed like a NEW signal's, and at a deep
        # pullback the momentum agents are silent by construction, so the
        # grade is ALWAYS poor exactly when the add price is best. That is
        # the consensus requirement the operator explicitly removed,
        # sneaking back through the risk door.
        #
        # An add is governed by: distance (>=150), better price only, the
        # >= 2 qualified-opponents veto, one add per parent, the 2-open cap
        # — plus these MECHANICAL market-state filters. Grade/quality of
        # the instant does not gate an add.
        risk = all_results.get("risk", {}) or {}
        risk_checks = risk.get("checks", risk.get("risk_checks", {})) or {}
        failed = [k for k in _MECH_FILTERS if not risk_checks.get(k, True)]
        if failed:
            logger.info("Scale-in blocked for %s %s: risk filters failed: %s", side, symbol, failed)
            _scale_in_audit("BLOCKED", "mechanical risk filters failed: %s" % ",".join(failed),
                            parent_id, side, current_price)
            continue

        levels = _levels_from_results(all_results, side)
        if not levels:
            _scale_in_audit("BLOCKED", "no structure levels available for entry sizing",
                            parent_id, side, current_price)
            continue
        if side == "BUY":
            directional_levels = [level for level in levels if level <= current_price]
        else:
            directional_levels = [level for level in levels if level >= current_price]
        if not directional_levels:
            directional_levels = levels
        nearest_level = min(directional_levels, key=lambda level: abs(level - current_price))
        distance_points = abs(price_to_points(current_price - nearest_level, symbol=symbol))

        entry_price = current_price
        parent_sl = _safe_float(parent.get("stop_loss"), 0.0)
        parent_tp1 = _safe_float(parent.get("tp1"), 0.0)
        parent_tp2 = _safe_float(parent.get("tp2"), 0.0)
        # Recalculate SL/TP for scale-in based on its own entry price,
        # preserving the same distance ratios as the parent trade.
        if parent_entry > 0 and parent_sl > 0:
            sl_distance = abs(parent_entry - parent_sl)
            stop_loss = entry_price - sl_distance if side == "BUY" else entry_price + sl_distance
        else:
            stop_loss = parent_sl
        # R26.9.12 (operator 2026-09-02: "طبّق قانون الذهب مع النسبة"): the
        # add is a NEW entry and its stop obeys the SAME law band as every
        # other door (the R26.9.9 execution-boundary clamp). The clone above
        # copies the parent's CURRENT geometry -- if management already moved
        # the parent stop (BE lock +150xratio, trailing ratchet), the copied
        # distance is the MOVED one and the add can go live with an
        # out-of-band stop (live edge: a BE-locked FX parent hands its add a
        # 270-pt stop = 27 pips, far under the 486 floor; a legacy wide
        # parent hands a 1025-pt stop over the 720 cap). XAU/USD returns the
        # (0, 0) band and is therefore UNTOUCHED: byte-identical clone, the
        # reference behaviour verbatim.
        stop_loss = _clamp_leg_stop_to_law(stop_loss, entry_price, side, symbol, config)
        if parent_entry > 0 and parent_tp1 > 0:
            tp1_distance = abs(parent_tp1 - parent_entry)
            tp1 = entry_price + tp1_distance if side == "BUY" else entry_price - tp1_distance
        else:
            tp1 = parent_tp1
        if parent_entry > 0 and parent_tp2 > 0:
            tp2_distance = abs(parent_tp2 - parent_entry)
            tp2 = entry_price + tp2_distance if side == "BUY" else entry_price - tp2_distance
        else:
            tp2 = parent_tp2
        trade_id = database.new_trade_id()
        # Operator law (2026-09-02: "التعزيز بحجم كامل"): the add's size is
        # FULL (1.0x) of the parent. The legacy 0.5 fallback contradicted
        # the confirmed law and even turned an explicit 0 into 0.5.
        _size_ratio = float(fr.get("scale_in_size_ratio", 1.0) or 1.0)
        reason = (
            f"Pullback {pullback_pts:.0f} pts from entry at a better price; "
            f"no qualified opposition veto ({oppose_count} opponent(s) < 2); "
            f"book: {agree_count} supporting, net {consensus_conf:.0f}%"
            + (f"; admission {admission.get('path')}" if admission.get("allow") else "")
        )
        decision: Dict[str, Any] = {
            "trade_id": trade_id,
            "decision": side,
            "symbol": symbol,
            "current_price": entry_price,
            "confidence": int(_safe_float(all_results.get("confidence"), 75)),
            "trading_mode": oe.get("mode", "paper"),
            "paper_trading": True,
            "reasons": [reason, f"Fixed-risk scale-in for parent trade {parent_id}"],
            "signal": {
                "symbol": symbol,
                "type": side,
                "scale_in": True,
                "parent_trade_id": parent_id,
                "scale_in_size_ratio": _size_ratio,
                "entry": {"price": entry_price, "kind": "MARKET"},
                "entry_kind": "MARKET",
                "stop_loss": stop_loss,
                "tp1": tp1,
                "tp2": tp2,
            },
        }
        stamp_execution_path(decision, admission)
        # Build agent votes line for Telegram
        vote_emojis = {"BUY": "🟢", "SELL": "🔴", "WAIT": "🟡"}
        agent_lines = []
        for name in agent_names:
            _used_name, result = _book_agent(all_results, name)
            agent_signal = str(result.get("signal") or result.get("direction") or "WAIT").upper()
            agent_conf = float(result.get("confidence", 0) or 0)
            if agent_conf < min_agent_conf:
                emoji = "⚪"
                label = "skip"
            else:
                emoji = vote_emojis.get(agent_signal, "⚪")
                label = f"{agent_signal} {agent_conf:.0f}%"
            agent_lines.append(f"{emoji} {name.title()} {label}")
        votes_block = "\n".join(agent_lines)
        message = (
            f"{path_header(decision)}\n"
            f"➕ <b>Scale-In {html.escape(symbol)} — {html.escape(side)}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━\n"
            f"• <b>Parent:</b> {html.escape(parent_id)}\n"
            f"• <b>Pullback:</b> {pullback_pts:.0f} pts from entry ({parent_entry:.2f} → {entry_price:.2f})\n"
            f"• <b>Opposition check:</b> {oppose_count} qualified opponent(s) — under the 2-veto\n"
            "──────────────────\n"
            "🗳️ AGENT VOTES\n"
            f"{votes_block}\n"
            "──────────────────\n"
            "🎯 TRADE PLAN\n"
            f"• <b>Entry:</b> {entry_price:.2f}\n"
            f"• <b>Stop Loss:</b> {stop_loss:.2f}\n"
            f"• <b>TP1:</b> {tp1:.2f}\n"
            f"• <b>TP2:</b> {tp2:.2f}\n"
            f"• <b>Size:</b> {decision['signal']['scale_in_size_ratio']}x\n"
            f"• <b>RR:</b> {abs(tp2 - entry_price) / max(abs(stop_loss - entry_price), 0.01):.2f}R\n"
            "━━━━━━━━━━━━━━━━━━━━━\n"
            f"<i>ID: {html.escape(trade_id)}</i>"
        )
        # SUCCESS IS NEVER SILENT (operator 2026-08-18e). The first live add
        # (13:31, gold) entered with no log line at all: every refusal names
        # itself but the accept path wrote nothing, so the operator watched a
        # second position appear in MT5 against a log full of blocks and
        # asked, reasonably, "دخلت رغم السجل يقول منع كيف؟". One line, same
        # shape as the refusals, stating what was done and on which terms.
        logger.info(
            "Scale-in ENTERED for %s %s: add @ %.2f (parent %s @ %.2f, "
            "pullback %.0f pts >= %.0f), stop %.2f, opponents %d < 2, trade %s",
            side, symbol, entry_price, parent_id, parent_entry,
            pullback_pts, trigger_points, stop_loss, oppose_count, trade_id,
        )
        if demo_execution:
            decision["_telegram_signal_sent"] = False
            decision["_telegram_pending_message"] = message
            database.save_trade(decision)
            _scale_in_audit(
                "ENTERED",
                "add entered (demo path): pullback %.0f pts >= %d required; %d qualified opponent(s) < 2 veto; trade %s"
                % (pullback_pts, trigger_points, oppose_count, trade_id),
                parent_id, side, entry_price)
        else:
            delivered = False
            try:
                delivered = bool(telegram.send_message(message, urgent=True))
            except Exception as exc:  # noqa: BLE001
                logger.exception("Failed to send scale-in Telegram message for %s: %s", parent_id, exc)
            if delivered:
                database.save_trade(decision)
                _scale_in_audit(
                    "ENTERED",
                    "add entered: pullback %.0f pts >= %d required; %d qualified opponent(s) < 2 veto; trade %s"
                    % (pullback_pts, trigger_points, oppose_count, trade_id),
                    parent_id, side, entry_price)
            else:
                logger.error("Scale-in for %s was not saved because Telegram delivery failed", parent_id)
                _scale_in_audit(
                    "ATTEMPTED_NOT_SAVED",
                    "all gates passed (pullback %.0f pts >= %d; %d opponent(s) < 2) but Telegram delivery failed - trade NOT persisted"
                    % (pullback_pts, trigger_points, oppose_count),
                    parent_id, side, entry_price)
        return


def _session_plan_delivery_cfg(config: Dict[str, Any]) -> Dict[str, Any]:
    return (config.get("session_plan_delivery") or {}) if isinstance(config, dict) else {}


def _session_plan_payload(plan_or_row: Dict[str, Any] | None) -> Dict[str, Any]:
    if not isinstance(plan_or_row, dict):
        return {}
    payload = plan_or_row.get("payload")
    if isinstance(payload, dict) and payload:
        return dict(payload)
    return dict(plan_or_row)

def _session_plan_reference_time(plan_or_row: Dict[str, Any] | None) -> datetime | None:
    if not isinstance(plan_or_row, dict):
        return None
    for key in ("telegram_sent_at", "analysis_run_at", "plan_created_at", "created_at"):
        parsed = _parse_datetime(plan_or_row.get(key))
        if parsed:
            return parsed
    payload = _session_plan_payload(plan_or_row)
    for key in ("telegram_sent_at", "analysis_run_at", "plan_created_at", "created_at"):
        parsed = _parse_datetime(payload.get(key))
        if parsed:
            return parsed
    return None


def _session_plan_session_key(plan_or_row: Dict[str, Any] | None, config: Dict[str, Any], *, symbol: str) -> str:
    payload = _session_plan_payload(plan_or_row)
    session_label = str(payload.get("session_label") or plan_or_row.get("session_label") or "UNKNOWN")
    ref = _session_plan_reference_time(plan_or_row) or datetime.now(timezone.utc)
    tz_name = str((config.get("schedule", {}) or {}).get("timezone") or (config.get("trading_hours", {}) or {}).get("timezone") or "Asia/Hebron")
    try:
        local_dt = ref.astimezone(ZoneInfo(tz_name))
    except Exception:
        local_dt = ref.astimezone(timezone.utc)
    return f"{symbol}::{local_dt.strftime('%Y-%m-%d')}::{session_label}"


def _session_plan_delivery_meta(current_plan: Dict[str, Any], sent_rows: List[Dict[str, Any]], config: Dict[str, Any], *, symbol: str) -> Dict[str, Any]:
    cfg = _session_plan_delivery_cfg(config)
    if not bool(cfg.get("enabled", True)):
        return {"send": False, "reason": None, "kind": None, "previous": None}
    if bool(cfg.get("only_when_ready", True)) and not bool(current_plan.get("plan_ready")):
        return {"send": False, "reason": None, "kind": None, "previous": None}
    current_key = _session_plan_session_key(current_plan, config, symbol=symbol)
    same_session_rows = [row for row in (sent_rows or []) if _session_plan_session_key(row, config, symbol=symbol) == current_key]
    previous = same_session_rows[0] if same_session_rows else None
    if previous is None:
        return {"send": bool(current_plan.get("plan_ready")), "reason": "first_ready_plan_this_session", "kind": "OPENING_PLAN", "previous": None}
    min_interval = float(cfg.get("min_update_interval_minutes", 25) or 25)
    previous_time = _session_plan_reference_time(previous)
    if previous_time:
        age_minutes = (datetime.now(timezone.utc) - previous_time).total_seconds() / 60.0
        if age_minutes < min_interval:
            return {"send": False, "reason": None, "kind": None, "previous": previous}
    reason = _session_plan_delivery_reason(current_plan, previous, config, symbol=symbol)
    if not reason:
        return {"send": False, "reason": None, "kind": None, "previous": previous}
    return {"send": True, "reason": reason, "kind": "PLAN_UPDATE", "previous": previous}


def _session_plan_execution_audit(plan: Dict[str, Any], **extra: Any) -> Dict[str, Any]:
    manual_plan = (plan.get("manual_plan") or {}) if isinstance(plan, dict) else {}
    primary = (plan.get("primary_poi") or {}) if isinstance(plan, dict) else {}
    standby = (plan.get("standby_poi") or {}) if isinstance(plan, dict) else {}
    return {
        "plan_ready": bool(plan.get("plan_ready")),
        "plan_status": plan.get("plan_status"),
        "plan_reason": plan.get("plan_reason"),
        "authority_state": plan.get("authority_state"),
        "authority_direction": plan.get("authority_direction"),
        "market_objective": plan.get("market_objective"),
        "market_objective_direction": plan.get("market_objective_direction"),
        "day_archetype": plan.get("day_archetype"),
        "day_archetype_confidence": plan.get("day_archetype_confidence"),
        "preferred_execution_family": plan.get("preferred_execution_family"),
        "objective_alignment": plan.get("objective_alignment"),
        "same_box_ladder": bool(plan.get("same_box_ladder") or manual_plan.get("same_box_ladder")),
        "execution_readiness_state": str(((plan.get("execution_readiness") or {}) if isinstance(plan.get("execution_readiness"), dict) else {}).get("state") or ""),
        "execution_readiness_reason": str(((plan.get("execution_readiness") or {}) if isinstance(plan.get("execution_readiness"), dict) else {}).get("reason") or ""),
        "reversal_watch_active": bool((plan.get("reversal_watch") or {}).get("active")) if isinstance(plan.get("reversal_watch"), dict) else False,
        "primary_entry_price": plan.get("primary_entry_price") or primary.get("entry_price"),
        "standby_entry_price": plan.get("standby_entry_price") or standby.get("entry_price"),
        **extra,
    }


def _active_reversal_watch(database: DatabaseService, *, symbol: str) -> Dict[str, Any]:
    try:
        recent = database.get_recent_trades(limit=20)
    except Exception:
        recent = []
    for trade in recent or []:
        if normalize_symbol(trade.get("symbol") or symbol) != normalize_symbol(symbol):
            continue
        snapshot = trade.get("signal_snapshot") or {}
        if isinstance(snapshot, str):
            try:
                import json as _json
                snapshot = _json.loads(snapshot)
            except Exception:
                snapshot = {}
        if not isinstance(snapshot, dict):
            snapshot = {}
        watch = snapshot.get("reversal_watch") or {}
        if not isinstance(watch, dict) or not watch:
            continue
        if not bool(watch.get("active", True)):
            continue
        direction = str(watch.get("direction") or "").upper()
        expires_at = _parse_datetime(watch.get("expires_at"))
        if direction in {"BUY", "SELL"} and (expires_at is None or expires_at > datetime.now(timezone.utc)):
            return dict(watch)
    return {}


def _plan_field_changed(prev: Dict[str, Any], curr: Dict[str, Any], key: str, *, symbol: str, min_change_points: float) -> bool:
    try:
        old_v = float(prev.get(key))
        new_v = float(curr.get(key))
    except (TypeError, ValueError):
        return False
    return abs(price_to_points(new_v - old_v, symbol=symbol)) >= min_change_points


def _session_plan_delivery_reason(current_plan: Dict[str, Any], previous_snapshot: Dict[str, Any] | None, config: Dict[str, Any], *, symbol: str) -> str | None:
    cfg = _session_plan_delivery_cfg(config)
    if not bool(cfg.get("enabled", True)):
        return None
    if bool(cfg.get("only_when_ready", True)) and not bool(current_plan.get("plan_ready")):
        return None
    prev = _session_plan_payload(previous_snapshot)
    if not prev:
        return "first_ready_plan"
    if not bool(prev.get("plan_ready")) and bool(current_plan.get("plan_ready")):
        return "became_ready"
    # Metadata-only changes (scenario_type / poi_classification / planner_source)
    # must not spam users with a fresh PLAN UPDATE. Only material directional,
    # authority, execution, or price-level changes deserve a new broadcast.
    keys = ["session_bias", "authority_state", "authority_direction", "execution_preference", "plan_status"]
    for key in keys:
        if str(prev.get(key) or "") != str(current_plan.get(key) or ""):
            return f"changed_{key}"
    min_change_points = float(cfg.get("min_change_points", 60) or 60)
    for key in ["primary_entry_price", "standby_entry_price", "invalidation_level", "target_liquidity"]:
        if _plan_field_changed(prev, current_plan, key, symbol=symbol, min_change_points=min_change_points):
            return f"changed_{key}_materially"
    prev_zone = prev.get("primary_entry_zone") or {}
    curr_zone = current_plan.get("primary_entry_zone") or {}
    for key in ["low", "high"]:
        try:
            old_v = float(prev_zone.get(key))
            new_v = float(curr_zone.get(key))
            if abs(price_to_points(new_v - old_v, symbol=symbol)) >= min_change_points:
                return f"changed_primary_zone_{key}"
        except (TypeError, ValueError):
            pass
    return None


def _should_send_session_plan_telegram(current_plan: Dict[str, Any], previous_snapshot: Dict[str, Any] | None, config: Dict[str, Any], *, symbol: str) -> bool:
    return _session_plan_delivery_reason(current_plan, previous_snapshot, config, symbol=symbol) is not None


def _crash_site(exc: BaseException) -> str:
    """The deepest frame inside this repository, as ``file.py:line in func``.

    An exception message describes the symptom. ``'NoneType' object has no
    attribute 'get'`` fits every one of the hundreds of ``.get(`` calls under
    the planner, so on its own it is not actionable -- five crashed cycles
    appeared in every rejection report from 2026-08-04 onward with no way to
    find them.

    The traceback is already written to the run log by ``logger.exception``,
    but the report reads the stored row, not the log. Folding the frame into
    the stored reason puts the location where the analysis can see it.

    Frames from site-packages and the standard library are skipped: the last
    frame is usually inside a dependency, while the line worth fixing is the
    last one we own.
    """
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    site_marker = os.sep + "site-packages" + os.sep
    best = None
    try:
        for frame in traceback.extract_tb(exc.__traceback__):
            path = os.path.abspath(frame.filename)
            if site_marker in path or not path.startswith(root):
                continue
            best = frame
    except Exception:  # noqa: BLE001 - diagnostics must never raise
        return "unknown"
    if best is None:
        return "outside project"
    return f"{os.path.basename(best.filename)}:{best.lineno} in {best.name}"


def _session_plan_agent_opinions(
    agent_details: Dict[str, Any],
    *,
    weights: Dict[str, Any] | None = None,
    min_confidence: float = 67.0,
) -> List[Dict[str, Any]]:
    opinions: List[Dict[str, Any]] = []
    weights = weights if isinstance(weights, dict) else {}
    # 2026-08-19 (build 13, operator order): restore the previous card design
    # (six rows). oil_macro stays INTERNAL for WTI confirmation only.
    for key in [*CORE_VOTING_AGENTS, "macro_fundamental"]:
        used_key, detail = _book_agent(agent_details, key)
        if not detail:
            continue
        direction = str(detail.get("direction") or "WAIT").upper()
        confidence = _safe_float(detail.get("confidence"), 0.0)
        signals = [str(x) for x in (detail.get("signals") or []) if str(x).strip()]
        summary = str(detail.get("summary") or "").strip()
        if not summary and not signals and direction == "WAIT":
            summary = "No strong directional edge yet."
        opinions.append(
            {
                "key": used_key,
                "label": str(detail.get("label") or used_key),
                "direction": direction,
                "confidence": round(confidence, 1),
                "weight": round(_safe_float(weights.get(key), 0.0), 4) if key in CORE_VOTING_AGENTS else None,
                "qualified": bool(key in CORE_VOTING_AGENTS and direction in {"BUY", "SELL"} and confidence >= min_confidence),
                "external_confirmation": key == "macro_fundamental",
                "qualification_bar": round(float(min_confidence), 1),
                "summary": summary,
                "signals": signals[:2],
            }
        )
    return opinions


def _session_plan_book_summary(
    opinions: List[Dict[str, Any]],
    *,
    target_side: str,
    min_confidence: float,
) -> Dict[str, Any]:
    """Recount the Telegram header directly from the rendered core opinions."""
    side = str(target_side or "").upper()
    opposite = "SELL" if side == "BUY" else "BUY"
    supporters: List[str] = []
    opponents: List[str] = []
    inactive: List[str] = []
    support_score = 0.0
    opposition_score = 0.0
    aliases: dict[str, str] = {}
    for opinion in opinions:
        if not isinstance(opinion, dict) or opinion.get("external_confirmation"):
            continue
        raw_key = str(opinion.get("key") or "")
        key = aliases.get(raw_key, raw_key)
        if key not in CORE_VOTING_AGENTS:
            continue
        direction = str(opinion.get("direction") or "WAIT").upper()
        confidence = _safe_float(opinion.get("confidence"), 0.0)
        weight = _safe_float(opinion.get("weight"), 0.0)
        qualified = direction in {"BUY", "SELL"} and confidence >= min_confidence
        if not qualified:
            inactive.append(key)
            continue
        score = weight * confidence / 100.0
        if direction == side:
            supporters.append(key)
            support_score += score
        elif direction == opposite:
            opponents.append(key)
            opposition_score += score
        else:
            inactive.append(key)
    return {
        "target_side": side,
        "supporters": supporters,
        "opponents": opponents,
        "inactive_or_unqualified": inactive,
        "support_count": len(supporters),
        "opposition_count": len(opponents),
        "inactive_count": len(inactive),
        "support_score": round(support_score, 4),
        "opposition_score": round(opposition_score, 4),
        "agent_min_confidence": float(min_confidence),
    }


def _monitoring_map_delivery_gate(
    plan: Dict[str, Any], config: Dict[str, Any],
) -> Dict[str, Any]:
    """Admit a structurally complete two-agent map for display only.

    This gate never participates in order creation. It only decides whether a
    shared-admission BLOCKED map contains enough canonical evidence and enough
    complete levels to be useful as a Telegram watch card.
    """
    delivery_cfg = _session_plan_delivery_cfg(config)
    watch_cfg = delivery_cfg.get("monitoring_only") or {}
    if not bool(watch_cfg.get("enabled", False)):
        return {"allow": False, "reason": "monitoring-only delivery disabled"}
    if not bool(plan.get("plan_ready")):
        return {"allow": False, "reason": "map is not structurally ready"}

    side = str(plan.get("session_bias") or plan.get("authority_direction") or "").upper()
    if side not in {"BUY", "SELL"}:
        return {"allow": False, "reason": "map has no directional side"}
    admission = plan.get("execution_admission") or {}
    book = plan.get("agent_book_summary") or {}
    if bool(admission.get("allow")):
        return {"allow": False, "reason": "shared execution admission already passed"}
    if not bool(book.get("matches_execution_admission")):
        return {"allow": False, "reason": "rendered book does not match shared admission"}

    signal_cfg = (config.get("signal_requirements") or {}) if isinstance(config, dict) else {}
    path2 = signal_cfg.get("two_agent_entry") or {}
    planner_cfg = (config.get("session_planner") or {}) if isinstance(config, dict) else {}
    min_support = int(watch_cfg.get("min_supporting_agents", path2.get("min_agents_agree", 2)) or 2)
    min_net = float(watch_cfg.get("min_net_confidence", path2.get("min_consensus_confidence", signal_cfg.get("min_consensus_confidence", 72))) or 72)
    max_oppose = int(watch_cfg.get("max_opposing_agents", planner_cfg.get("max_opposing_agents_for_ready", 1)) or 1)
    support = int(admission.get("support_count", 0) or 0)
    oppose = int(admission.get("opposition_count", 0) or 0)
    net = float(admission.get("confidence", 0) or 0)
    if support < min_support:
        return {"allow": False, "reason": f"monitoring support {support} < {min_support}"}
    if net < min_net:
        return {"allow": False, "reason": f"monitoring net {net:.1f}% < {min_net:.1f}%"}
    if oppose > max_oppose:
        return {"allow": False, "reason": f"monitoring opposition {oppose} > {max_oppose}"}

    if bool(watch_cfg.get("require_complete_levels", True)):
        zone = plan.get("primary_entry_zone") or {}
        execution = plan.get("primary_execution") or {}
        primary = plan.get("primary_poi") or {}
        entry = plan.get("primary_entry_price") or primary.get("entry_price")
        stop = execution.get("stop_loss") or plan.get("invalidation_level") or primary.get("stop_loss")
        target = execution.get("tp2") or plan.get("target_liquidity") or primary.get("target_liquidity") or primary.get("target_price")
        try:
            complete = (
                float(zone.get("low")) > 0 and float(zone.get("high")) > 0
                and float(entry) > 0 and float(stop) > 0 and float(target) > 0
            )
        except (TypeError, ValueError):
            complete = False
        details = primary.get("details") if isinstance(primary, dict) else {}
        liquidity = details.get("liquidity") if isinstance(details, dict) else {}
        side_key = "buy_side" if side == "BUY" else "sell_side"
        has_liquidity = isinstance(liquidity, dict) and bool(liquidity.get(side_key))
        if not complete or not has_liquidity:
            return {"allow": False, "reason": "monitoring map lacks zone, stop, target or liquidity"}

    return {
        "allow": True,
        "mode": "MONITORING_ONLY",
        "reason": (
            f"{support} qualified core agents at net {net:.1f}%; "
            "waiting for full shared execution admission"
        ),
        "support_count": support,
        "opposition_count": oppose,
        "confidence": net,
    }
def _decorate_session_plan_for_delivery(
    plan: Dict[str, Any],
    decision: Dict[str, Any],
    all_results: Dict[str, Any],
    delivery_context: Dict[str, Any] | None = None,
    config: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    payload = deepcopy(plan) if isinstance(plan, dict) else {}
    cfg = config if isinstance(config, dict) else {}
    payload["map_display_quality"] = bounded_map_display_quality(payload, cfg)
    agent_details = decision.get("agent_details") or _compact_agent_details(all_results)
    weights = decision.get("weights") or get_agent_weights(cfg)
    min_agent_conf = _safe_float((cfg.get("signal_requirements") or {}).get("agent_min_confidence"), 67.0)
    payload["agent_opinions"] = _session_plan_agent_opinions(
        agent_details if isinstance(agent_details, dict) else {},
        weights=weights if isinstance(weights, dict) else {},
        min_confidence=min_agent_conf,
    )
    # SMC can hold a conditional POI map while its current vote is WAIT. Carry
    # that map as context, never as a synthetic SELL/BUY vote, so Telegram can
    # show what it is watching without changing the five-agent book.
    smc_result = all_results.get("smc") or {}
    smc_setup = smc_result.get("setup_structure") if isinstance(smc_result, dict) else None
    if isinstance(smc_setup, dict) and str(smc_setup.get("direction") or "").upper() in {"BUY", "SELL"}:
        raw_zone = smc_setup.get("poi_zone") or {}
        quality = smc_setup.get("quality_score")
        if quality in {None, ""} and isinstance(smc_setup.get("setup_quality"), dict):
            quality = (smc_setup.get("setup_quality") or {}).get("score")
        conditional = {
            "direction": str(smc_setup.get("direction") or "").upper(),
            "setup_type": smc_setup.get("setup_type"),
            "setup_state": smc_setup.get("setup_state"),
            "entry_timing": smc_setup.get("entry_timing"),
            "trigger_state": smc_setup.get("trigger_state"),
            "zone": {
                "low": raw_zone.get("low", raw_zone.get("bottom", smc_setup.get("poi_low"))),
                "high": raw_zone.get("high", raw_zone.get("top", smc_setup.get("poi_high"))),
            },
            "entry_price": smc_setup.get("entry_price"),
            "stop_loss": smc_setup.get("stop_loss"),
            "target": smc_setup.get("target_liquidity") or smc_setup.get("target_price"),
            "quality": quality,
            "return_probability": smc_setup.get("return_probability_score"),
            "return_probability_model": smc_setup.get("return_probability_model"),
            "return_probability_breakdown": deepcopy(smc_setup.get("return_probability_breakdown") or {}),
        }
        for opinion in payload["agent_opinions"]:
            if str(opinion.get("key") or "") == "smc":
                opinion["conditional_map"] = conditional
                opinion["conditional_map_counted_as_vote"] = bool(
                    opinion.get("qualified")
                    and str(opinion.get("direction") or "").upper() == conditional["direction"]
                )
                break
    admission_details = dict(agent_details) if isinstance(agent_details, dict) else {}
    target_side = str(payload.get("session_bias") or payload.get("authority_direction") or "").upper()
    context_confirmation = _planner_context_confirmation(decision, cfg, target_side)
    if context_confirmation.get("allow"):
        source = str(context_confirmation.get("source") or "").lower()
        confidence = _safe_float(context_confirmation.get("confidence"), 0.0)
        if source == "macro":
            admission_details["macro_fundamental"] = {"direction": target_side, "confidence": confidence}
        elif source == "gemini":
            admission_details["gemini"] = {"direction": target_side, "confidence": confidence, "available": True}
    for candidate in (
        decision.get("gemini_review"), decision.get("gemini_macro_review"),
        decision.get("gemini_analysis"),
    ):
        if "gemini" not in admission_details and isinstance(candidate, dict) and candidate.get("available"):
            admission_details["gemini"] = candidate
            break
    payload["execution_admission"] = evaluate_directional_admission(target_side, admission_details, cfg)
    if str((payload.get("execution_admission") or {}).get("path") or "") == "SMC_MAP_AUCTION_CONFIRMATION":
        for opinion in payload.get("agent_opinions") or []:
            if str(opinion.get("key") or "") == "smc" and opinion.get("conditional_map"):
                opinion["conditional_map_counted_as_vote"] = False
                opinion["conditional_map_path4_evidence"] = True
                break
    payload["agent_book_summary"] = _session_plan_book_summary(
        payload.get("agent_opinions") or [],
        target_side=target_side,
        min_confidence=min_agent_conf,
    )
    admission_support = set((payload.get("execution_admission") or {}).get("supporters") or [])
    admission_oppose = set((payload.get("execution_admission") or {}).get("opponents") or [])
    rendered_support = set((payload.get("agent_book_summary") or {}).get("supporters") or [])
    rendered_oppose = set((payload.get("agent_book_summary") or {}).get("opponents") or [])
    payload["agent_book_summary"]["matches_execution_admission"] = (
        admission_support == rendered_support and admission_oppose == rendered_oppose
    )
    payload["decision_weights"] = deepcopy(weights if isinstance(weights, dict) else {})
    payload["agent_min_confidence"] = min_agent_conf
    payload["shared_market_data"] = deepcopy(all_results.get("shared_market_data") or {})
    payload["gemini_plan_review"] = deepcopy(decision.get("gemini_analysis") or {})
    payload["gemini_macro_review"] = deepcopy(decision.get("gemini_macro_review") or {})
    payload["gemini_news_review"] = deepcopy(decision.get("gemini_news_review") or {})
    payload["macro_plan"] = deepcopy(all_results.get("macro_fundamental") or {})
    payload["delivery_context"] = dict(delivery_context or {})
    return payload


def _is_news_hard_block(decision: Dict[str, Any], all_results: Dict[str, Any]) -> bool:
    warnings = [str(w).lower() for w in (decision.get("warnings") or [])]
    if any(w.startswith("news blocked") or w.startswith("ai news blocked") for w in warnings): return True
    news = all_results.get("news", {}) or {}
    if news.get("can_trade") is False or str(news.get("market_status", "")).upper() in {"DANGER", "HIGH_VOLATILITY"}: return True
    news_ai = all_results.get("news_ai", {}) or news.get("ai_interpretation", {}) or {}
    if news_ai.get("available"):
        if bool(news_ai.get("block_trading", False)): return True
        if str(news_ai.get("allowed_direction", "BOTH")).upper() == "NONE": return True
        if str(news_ai.get("risk_level", "")).upper() == "EXTREME": return True
    return False


def _reason_key(text: str) -> str:
    value = str(text or "").lower()
    value = value.replace("&gt;=", ">=").replace("≥", ">=")
    value = value.replace("agreeing agents", "agents")
    value = value.replace("with weighted confidence", "weighted confidence")
    return " ".join(value.split())


def _append_unique_reason(lines: List[str], text: str) -> None:
    clean = str(text or "").strip()
    if not clean: return
    key = _reason_key(clean)
    existing_keys = [_reason_key(line.lstrip("• ")) for line in lines]
    if key not in existing_keys:
        lines.append(f"• {clean}")


def _payload_supports_signal_generation(payload: Dict[str, Any] | None) -> bool:
    if not payload:
        return False
    if isinstance(payload, dict) and payload.get("supports_signal_generation") is not None:
        return bool(payload.get("supports_signal_generation"))
    source = str((payload or {}).get("source") or "") if isinstance(payload, dict) else ""
    return source == "twelvedata"


def _payload_supports_pending_activation(payload: Dict[str, Any] | None) -> bool:
    if not payload:
        return False
    if isinstance(payload, dict) and payload.get("supports_pending_activation") is not None:
        return bool(payload.get("supports_pending_activation"))
    source = str((payload or {}).get("source") or "") if isinstance(payload, dict) else ""
    return source == "twelvedata"


def _market_prices_text(config: Dict[str, Any] | None, current_symbol: str, current_price: float) -> str:
    try:
        base_config = config or load_config()
        instruments = enabled_instruments(base_config)
    except Exception:
        base_config = config or {}
        instruments = [{"symbol": current_symbol or "XAU/USD"}]
    lines: List[str] = []
    seen: set[str] = set()
    for instrument in instruments:
        symbol = str(instrument.get("symbol") or "").strip() or "XAU/USD"
        if symbol in seen: continue
        seen.add(symbol)
        price = 0.0
        if symbol == current_symbol and current_price > 0: price = current_price
        else:
            try:
                symbol_config = config_for_instrument(base_config, instrument)
                payload = MarketDataService(symbol_config).get_ohlcv("5m", outputsize=3)
                if payload: price = _safe_float(payload.get("current_price"), 0.0)
            except Exception: pass
        price_label = format_price(price, symbol) if price > 0 else "N/A"
        lines.append(f"• {html.escape(symbol)}: {html.escape(price_label)}")
    return "\n".join(lines) if lines else f"• {html.escape(current_symbol)}: N/A"


def _pending_age_hours(trade: Dict[str, Any]) -> float:
    ref = _parse_datetime(trade.get("created_at") or trade.get("entry_time") or trade.get("opened_at"))
    if not ref:
        return 0.0
    return max(0.0, (datetime.now(timezone.utc) - ref).total_seconds() / 3600.0)


def _report_data_outage(
    telegram: Any,
    config: Dict[str, Any],
    symbol: str,
    reason: str,
    delivery: Any = None,
) -> None:
    """Announce a cycle abandoned before analysis could run.

    A data failure returns before any decision exists, so the normal status
    message cannot be built. Staying silent here is indistinguishable from a
    quiet market, which hides an outage that may already be hours long.
    """
    if not should_send_hourly_status(config):
        return
    # This outage note replaces the generic hourly status for this cycle.
    if delivery is not None:
        delivery.mark_sent()
    _send_hourly_status_once(
        telegram, config,
        "⚠️ <b>SmartSignal — Analysis skipped</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 {html.escape(str(symbol))}\n"
        "🎯 Decision: NONE (cycle stopped before analysis)\n\n"
        f"<b>Reason:</b>\n• {html.escape(str(reason))}\n"
        "━━━━━━━━━━━━━━━━━━━━"
    )


class _HourlyStatusDelivery:
    """Guarantee the hourly status is sent exactly once per analysis cycle.

    The status send used to sit on the WAIT branch at the end of the function.
    Any of the fourteen earlier `return` statements — a directional decision, a
    filter, a data problem — skipped it entirely, so an hour could pass with no
    message and a green workflow. This tracker is armed once the cycle knows a
    status is due and flushed from a `finally` block, so no exit path can
    swallow it. `send_once` keeps a real trade signal from being duplicated by
    a status message in the same cycle.
    """

    def __init__(self, telegram: Any, config: Dict[str, Any]) -> None:
        self.telegram = telegram
        self.config = config
        self.due = False
        self.sent = False
        self.decision: Dict[str, Any] = {}
        self.all_results: Dict[str, Any] = {}
        self.database: Any = None
        self.note: str | None = None

    def arm(self, *, decision, all_results, database, note=None) -> None:
        self.due = True
        self.decision = decision or {}
        self.all_results = all_results or {}
        self.database = database
        if note:
            self.note = str(note)

    def mark_sent(self) -> None:
        self.sent = True

    def flush(self) -> None:
        if not self.due or self.sent:
            return
        self.sent = True
        # A cycle can be armed and then die before the database handle is
        # attached, or die inside the message builder itself (Supabase down,
        # a malformed trade row). Both used to end in silence, which is the
        # exact failure this class exists to prevent: an hour with no message
        # and a green workflow. Fall back to a minimal note that needs no
        # database and no formatting.
        body = None
        if self.database is not None:
            try:
                body = _build_market_status_message(
                    self.decision, self.all_results, self.database, self.config
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("Failed to build hourly status message: %s", exc)
        if body is None:
            symbol = str(
                self.decision.get("symbol")
                or self.all_results.get("symbol")
                or self.config.get("symbol")
                or "XAU/USD"
            )
            decision_txt = str(self.decision.get("decision") or "UNKNOWN").upper()
            body = (
                "🟡 <b>SmartSignal — Market Status</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"📊 {html.escape(symbol)}\n"
                f"🎯 Decision: {html.escape(decision_txt)}\n\n"
                "<i>Full status unavailable this cycle "
                "(database or formatting error — see workflow log).</i>\n"
                "━━━━━━━━━━━━━━━━━━━━"
            )
        if self.note:
            body = f"{html.escape(self.note)}\n{body}"
        _send_hourly_status_once(self.telegram, self.config, body)


def _record_decision_audit(
    database: Any,
    decision: Dict[str, Any],
    config: Dict[str, Any],
    *,
    stage: str,
    outcome: str,
    reason: Any = None,
) -> None:
    """Write one row describing how this cycle ended.

    Deliberately best-effort: an audit failure must never stop a trade or a
    refusal from happening. The row carries the numbers needed to judge the
    decision later -- the R-multiples especially, since a target too close to
    entry was the fault that took longest to see.
    """
    if database is None:
        return
    try:
        symbol = str(decision.get("symbol") or config.get("symbol", "XAU/USD"))
        signal = decision.get("signal") or {}
        entry_info = (signal.get("entry") or {}) if isinstance(signal, dict) else {}
        entry = _safe_float(entry_info.get("price"), 0.0) or _safe_float(decision.get("current_price"), 0.0)
        stop = _safe_float(signal.get("stop_loss"), 0.0) if isinstance(signal, dict) else 0.0
        tp1 = _safe_float(signal.get("tp1"), 0.0) if isinstance(signal, dict) else 0.0
        tp2 = _safe_float(signal.get("tp2"), 0.0) if isinstance(signal, dict) else 0.0
        risk = abs(price_to_points(entry - stop, symbol=symbol)) if entry > 0 and stop > 0 else 0.0
        gate = decision.get("planner_execution_gate") or {}
        database.save_decision_audit({
            "symbol": symbol,
            "stage": stage,
            "outcome": outcome,
            "side": str(decision.get("decision") or "").upper(),
            "reason": str(reason or "")[:500] or None,
            "entry_price": round(entry, 2) if entry else None,
            "stop_loss": round(stop, 2) if stop else None,
            "tp1": round(tp1, 2) if tp1 else None,
            "tp2": round(tp2, 2) if tp2 else None,
            "tp1_rr": round(abs(price_to_points(tp1 - entry, symbol=symbol)) / risk, 2) if risk > 0 and tp1 > 0 else None,
            "tp2_rr": round(abs(price_to_points(tp2 - entry, symbol=symbol)) / risk, 2) if risk > 0 and tp2 > 0 else None,
            "confidence": _safe_float(decision.get("confidence"), 0.0) or None,
            "support_count": gate.get("support_count") if isinstance(gate, dict) else None,
            "oppose_count": gate.get("oppose_count") if isinstance(gate, dict) else None,
            "entry_mode": decision.get("entry_mode"),
            "trade_id": decision.get("trade_id"),
        })
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to record decision audit (%s): %s", stage, exc)


def _notify_blocked_directional_signal(
    *,
    telegram: Any,
    decision: Dict[str, Any],
    all_results: Dict[str, Any],
    database: DatabaseService,
    config: Dict[str, Any],
    send_hourly_now: bool,
    stage: str,
    reason: Any,
    delivery: Any = None,
) -> None:
    """Annotate the pending hourly status with why a directional signal stopped.

    Delivery itself is owned by `_HourlyStatusDelivery`, so this only records
    the stage and reason; the message goes out even if this is never called.

    Two independent switches can open this path: the hourly status window, and
    `notify_on_blocked_signal` -- the setting that exists specifically to
    surface rejection reasons. Only the first was ever consulted, which left
    `should_send_status` defined and unused while the setting it reads did
    nothing.
    """
    # Persist first, notify second. Telegram delivery is optional and gated by
    # the status window; the audit trail is not. Recording only what was
    # announced would leave the quiet refusals -- the majority -- invisible,
    # which is how a filter can block every signal for a week unnoticed.
    _record_decision_audit(
        database, decision, config, stage=stage, outcome="BLOCKED", reason=reason,
    )
    if not (send_hourly_now or should_send_status(config)):
        return
    side = str(decision.get("decision") or decision.get("signal") or "").upper()
    reason_text = str(reason or "").strip() or "no reason recorded"
    note = f"🚫 {side} signal blocked at {stage} — {reason_text}"
    if delivery is not None:
        delivery.arm(
            decision=decision, all_results=all_results,
            database=database, note=note,
        )
        return
    try:
        telegram.send_message(
            html.escape(note) + "\n"
            + _build_market_status_message(decision, all_results, database, config)
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to send blocked-signal status for %s: %s", decision.get("symbol"), exc)


def _trade_row_price(
    trade_symbol: str,
    current_symbol: str,
    current_price: float,
    all_results: Dict[str, Any],
    config: Dict[str, Any] | None,
) -> float:
    """BUILD 22 (2026-08-21): the price of THIS trade's symbol, not the cycle's.

    The hourly status lists open trades of EVERY symbol while the cycle price
    belongs to one symbol only. Measuring a WTI row with the gold price
    produced nonsense PnL and a fake 'TP1 reached' mark. Order of preference:
    the cycle's own price (same symbol), the shared snapshot's prices, then a
    live fetch via MarketDataService. 0.0 = unknown (the row then falls back
    to its stored PnL and shows no progress mark).
    """
    norm = normalize_symbol(str(trade_symbol or ""))
    if not norm:
        return 0.0
    if norm == normalize_symbol(str(current_symbol or "")):
        return current_price
    shared = (all_results or {}).get("shared_market_data") or {}
    if isinstance(shared, dict):
        prices = shared.get("prices") or shared.get("instruments") or {}
        if isinstance(prices, dict):
            for key in (trade_symbol, norm):
                value = prices.get(key)
                if value is not None:
                    try:
                        price = float(value)
                        if price > 0:
                            return price
                    except (TypeError, ValueError):
                        pass
    try:
        base_config = config or load_config()
        symbol_config = config_for_instrument(base_config, {"symbol": norm})
        payload = MarketDataService(symbol_config).get_ohlcv("5m", outputsize=3)
        price = _safe_float(payload.get("current_price"), 0.0) if isinstance(payload, dict) else 0.0
        if price > 0:
            return price
    except Exception:  # noqa: BLE001 - a failed fetch must not break the message
        pass
    return 0.0


def _status_oil_macro_line(config: Dict[str, Any] | None) -> str:
    """BUILD 25 (2026-08-21, operator order): the OIL macro read on its own
    line in the status card - computed locally via the crack/spread/EIA
    layers (the same agent the WTI path uses)."""
    try:
        base_config = config or load_config()
        wti_cfg = config_for_instrument(base_config, {"symbol": "WTI/USD"})
        result = OilMacroAgent(wti_cfg).analyze({"symbol": "WTI/USD"})
        if not isinstance(result, dict):
            return ""
        direction = str(result.get("direction") or "WAIT").upper()
        confidence = _safe_float(result.get("confidence"), 0.0)
        summary = str(result.get("summary") or "").strip()
        if direction in {"BUY", "SELL"}:
            line = f"🛢️ <b>Oil Macro:</b> {html.escape(direction)} {confidence:.0f}%"
        else:
            score = _safe_float(result.get("score"), 0.0)
            line = f"🛢️ <b>Oil Macro:</b> WAIT (score {score:+.1f})"
        if summary:
            line += f" — {html.escape(summary[:60])}"
        return line + "\n"
    except Exception:  # noqa: BLE001 - the line is optional
        return ""


def _status_gemini_cache_path(config: Dict[str, Any] | None) -> Path:
    llm_cfg = (config or {}).get("llm_review") or {}
    raw = str(llm_cfg.get("status_cache_path")
              or "storage/llm/gemini_status_cache.json")
    p = Path(raw)
    if not p.is_absolute():
        p = Path(__file__).resolve().parents[1] / p
    return p


def _status_macro_line(all_results: Dict[str, Any], config: Dict[str, Any] | None,
                       database: Any) -> str:
    """BUILD 24 (2026-08-21, operator order): the macro read on the hourly
    status card. Pure LOCAL computation (no API cost) - every hour."""
    macro_result = (all_results or {}).get("macro_fundamental") or {}
    md = (macro_result.get("macro_direction") or {}) if isinstance(macro_result, dict) else {}
    if not isinstance(md, dict) or not md:
        try:
            context = database.get_macro_context() if database is not None else None
            md = MacroFundamentalAgent(config or {}).macro_direction(context) if context else {}
        except Exception:  # noqa: BLE001 - the line is optional
            md = {}
    bias = str(md.get("bias") or "").upper()
    confidence = _safe_float(md.get("confidence"), 0.0)
    summary = str(md.get("summary") or "").strip()
    if not bias or confidence <= 0:
        return ""
    label = {"BULLISH_GOLD": "Bullish Gold", "BEARISH_GOLD": "Bearish Gold"}.get(bias, bias)
    line = f"🌍 <b>Macro:</b> {html.escape(label)} {confidence:.0f}%"
    if summary:
        line += f" — {html.escape(summary[:70])}"
    return line + "\n"


def _status_gemini_line(config: Dict[str, Any] | None, all_results: Dict[str, Any],
                        symbol: str, now: datetime | None = None,
                        price: float = 0.0) -> str:
    """BUILD 28 R2 (2026-08-22, operator order): the Gemini opinion for ONE
    symbol on the hourly status card, via the shared stored-opinion store
    (services/gemini_opinion_store.py).

    * The hourly update fetches a NEW opinion when the stored one is older
      than 30 minutes (``stored_opinion_hours``, default 0.5) - it runs the
      whole trading week (the old even-UTC-hours gate is gone).
    * A trade entry forces a fresh opinion (run_tick_manager, force=True).
    * Every other display (signal / plan / trade cards) reads the store
      only - no extra API call.
    * Same model chain as before (GeminiReviewService fallback order).
    Fail-open: any problem -> the stored verdict (or nothing), never a
    broken card.
    """
    from services import gemini_opinion_store as gos

    now = now or datetime.now(timezone.utc)
    try:
        verdict, refreshed, age_h = gos.refresh_opinion(
            symbol, config, all_results=all_results or {},
            current_price=price or 0.0, now=now)
    except Exception as exc:  # noqa: BLE001 - the line is optional
        logger.warning("Gemini status opinion failed for %s: %s", symbol, exc)
        try:
            verdict, age_h = gos.get_stored(symbol, config, now=now)
            refreshed = False
        except Exception:  # noqa: BLE001
            verdict, age_h, refreshed = None, None, False
    if not verdict:
        return ""
    bias = str(verdict.get("bias") or verdict.get("market_bias") or "").upper()
    action = str(verdict.get("action") or "").upper()
    reason = str(verdict.get("reason") or "").strip()
    if not bias:
        return ""
    line = f"🧠 <b>Gemini {html.escape(symbol)}:</b> {html.escape(bias)}"
    if action:
        line += f" ({html.escape(action)})"
    if reason:
        line += f" — {html.escape(reason[:60])}"
    if not refreshed and age_h is not None and age_h >= 0:
        line += f" <i>(stored {age_h:.1f}h)</i>"
    return line + "\n"


def _status_opinion_lines(
    config: Dict[str, Any] | None,
    all_results: Dict[str, Any],
    database: Any,
    current_symbol: str,
    current_price: float,
    now: datetime | None = None,
) -> str:
    """BUILD 25: every opinion line of the status card, per symbol.

    Macro (gold, local) + Oil Macro (local) always; Gemini per enabled
    symbol (cache-first, 2h cadence, separate cache entries per symbol)."""
    lines: List[str] = []
    macro_line = _status_macro_line(all_results, config, database)
    if macro_line:
        lines.append(macro_line)
    oil_line = _status_oil_macro_line(config)
    if oil_line:
        lines.append(oil_line)
    try:
        base_config = config or load_config()
        instruments = enabled_instruments(base_config)
    except Exception:  # noqa: BLE001
        instruments = [{"symbol": current_symbol or "XAU/USD"}]
    for instrument in instruments:
        symbol = normalize_symbol(str(instrument.get("symbol") or ""))
        if not symbol:
            continue
        price = _trade_row_price(symbol, current_symbol, current_price, all_results, config)
        line = _status_gemini_line(config, all_results, symbol, now=now, price=price)
        if line:
            lines.append(line)
    return "".join(lines)


def _status_regime_line(all_results: Dict[str, Any],
                        decision: Dict[str, Any],
                        config: Dict[str, Any] | None) -> str:
    """R25.8 advisory: the central regime-switcher opinion for the hourly
    status card. Fail-open: any problem returns an empty line."""
    try:
        if not bool(((config or {}).get("regime_switcher") or {}).get("enabled", False)):
            return ""
        from services.regime_switcher import regime_opinion_line
        line = (decision.get("regime_opinion_line")
                or (all_results or {}).get("regime_opinion_line") or "")
        if not line:
            regime = (all_results or {}).get("regime_switch") or {}
            line = regime_opinion_line(regime, config) if regime else ""
        if not line:
            return ""
        return html.escape(line) + "\n"
    except Exception:  # noqa: BLE001
        return ""


def _build_market_status_message(
    decision: Dict[str, Any],
    all_results: Dict[str, Any],
    database: DatabaseService,
    config: Dict[str, Any] | None = None,
) -> str:
    current_symbol = str(decision.get("symbol") or all_results.get("symbol") or (config or {}).get("symbol") or "XAU/USD")
    current_price = _safe_float(decision.get("current_price", all_results.get("current_price", 0)), 0.0)
    prices_text = _market_prices_text(config, current_symbol, current_price)

    # ── Open trades / pending orders summary ─────────────────────────────
    tracked_trades = database.get_open_trades()
    trades_section = ""
    if tracked_trades:
        from utils.instruments import price_to_points
        live_statuses = {"OPEN", "PARTIAL", "TP1_HIT"}
        pending_statuses = {"PENDING"}
        live_trades = [t for t in tracked_trades if str(t.get("status") or "OPEN").upper() in live_statuses]
        pending_trades = [t for t in tracked_trades if str(t.get("status") or "").upper() in pending_statuses]
        parts: List[str] = ["──────────────────"]

        if live_trades:
            trade_lines: List[str] = []
            net_pts = 0.0
            net_usd = 0.0
            for t in live_trades[:20]:
                tid = str(t.get("id", ""))
                short = tid.split("_")[-1] if "_" in tid else (tid[-8:] if len(tid) >= 8 else tid)
                direction = str(t.get("type") or t.get("side") or "BUY").upper()
                row_symbol = str(t.get("symbol") or current_symbol)
                row_price = _trade_row_price(row_symbol, current_symbol, current_price, all_results, config)
                entry = _safe_float(t.get("entry_price"), 0.0)
                tp1 = _safe_float(t.get("tp1"), 0.0)
                tp2 = _safe_float(t.get("tp2"), 0.0)
                # BUILD 22: live PnL from the ROW's symbol price; the stored
                # number is only the fallback when no live price exists.
                pnl_pts = 0.0
                if entry > 0 and row_price > 0:
                    raw = (row_price - entry) if direction == "BUY" else (entry - row_price)
                    pnl_pts = price_to_points(raw, symbol=row_symbol)
                elif entry > 0:
                    pnl_pts = _safe_float(t.get("current_pnl_points"), 0.0)
                row_pv = point_size(row_symbol, config or {})
                usd = pnl_pts * row_pv
                net_pts += pnl_pts
                net_usd += usd
                status = str(t.get("status") or "OPEN").upper()
                marker = "🟢" if pnl_pts > 0 else "🔴" if pnl_pts < 0 else "➖"
                prog_txt = ""
                tp1_dist = abs(price_to_points(tp1 - entry, symbol=row_symbol)) if tp1 and entry else 0
                if tp1_dist > 0 and pnl_pts > 0:
                    pct = min(pnl_pts / tp1_dist * 100, 100)
                    prog_txt = f" · {pct:.0f}%➜TP1"
                elif (tp1 and entry and row_price > 0
                      and ((direction == "BUY" and row_price >= tp1)
                           or (direction == "SELL" and row_price <= tp1))):
                    # BUILD 22: only the ROW's own price may claim a TP1 touch.
                    prog_txt = " · ✅TP1"
                status_txt = "" if status == "OPEN" else f" [{html.escape(status)}]"
                # Operator directive (2026-08-06): show entry / TP1 / TP2 / P&L
                # clearly for every open trade in the status message.
                levels_txt = ""
                if entry:
                    levels_txt += f" · Entry {entry:.2f}"
                if tp1:
                    levels_txt += f" · TP1 {tp1:.2f}"
                if tp2:
                    levels_txt += f" · TP2 {tp2:.2f}"
                trade_lines.append(
                    f"{marker} {direction} <code>#{html.escape(short)}</code>{levels_txt} · "
                    f"{pnl_pts:+.0f}pts ({usd:+.1f}$){prog_txt}{status_txt}"
                )
            if len(live_trades) > 20:
                trade_lines.append(f"… and {len(live_trades) - 20} more")
            net_marker = "🟢" if net_pts > 0 else "🔴" if net_pts < 0 else "➖"
            parts.append(f"📊 <b>Open Trades ({len(live_trades)})</b>")
            parts.extend(trade_lines)
            parts.append(f"{net_marker} <b>Net:</b> {net_pts:+.0f}pts ({net_usd:+.1f}$)")

        if pending_trades:
            if live_trades:
                parts.append("──────────────────")
            pending_lines: List[str] = []
            for t in pending_trades[:20]:
                tid = str(t.get("id", ""))
                short = tid.split("_")[-1] if "_" in tid else (tid[-8:] if len(tid) >= 8 else tid)
                direction = str(t.get("type") or t.get("side") or "BUY").upper()
                entry = _safe_float(t.get("entry_price"), 0.0)
                status = str(t.get("status") or "PENDING").upper()
                order_type = str(t.get("order_type") or t.get("order_kind") or status).upper()
                row_symbol = str(t.get("symbol") or current_symbol)
                row_price = _trade_row_price(row_symbol, current_symbol, current_price, all_results, config)
                pts_to_fill = abs(price_to_points(entry - row_price, symbol=row_symbol)) if entry and row_price > 0 else 0.0
                age_h = _pending_age_hours(t)
                pending_lines.append(
                    f"🟡 {direction} <code>#{html.escape(short)}</code> @ {entry:.2f} [{html.escape(order_type)}] · {pts_to_fill:.0f} pts to fill · waiting {age_h:.1f}h"
                )
            if len(pending_trades) > 20:
                pending_lines.append(f"… and {len(pending_trades) - 20} more")
            parts.append(f"⏳ <b>Pending Orders ({len(pending_trades)})</b>")
            parts.extend(pending_lines)

        trades_section = "\n".join(parts) + "\n"

    book_line = _status_book_line(all_results)
    gates_line = _status_gates_line(config, decision)
    # BUILD 25: opinion lines per symbol - gold macro + oil macro (local),
    # and one cache-first Gemini line per enabled symbol (2h cadence).
    opinion_lines = _status_opinion_lines(
        config, all_results, database, current_symbol, current_price,
        now=datetime.now(timezone.utc),
    )

    return (
        "🟡 <b>SmartSignal — Market Status</b> · "
        f"{datetime.now(timezone.utc).strftime('%H:%M UTC')}\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 {_compact_prices_line(prices_text)}\n"
        f"🎯 Decision: {html.escape(str(decision.get('decision') or 'WAIT').upper())}\n"
        f"{_status_regime_line(all_results, decision, config)}"
        f"{book_line}"
        f"{gates_line}"
        f"{opinion_lines}"
        f"{trades_section}"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "<i>Market status • Next update in ~1 hour</i>"
    )


def _compact_prices_line(prices_text: str) -> str:
    """BUILD 16: '• XAU/USD: 4452.84' bullets -> 'XAU/USD 4452.84 · WTI 85.40'."""
    parts = []
    for chunk in (prices_text or "").split("\n"):
        chunk = chunk.strip()
        if not chunk.startswith("•"):
            continue
        body = chunk.lstrip("•").strip()
        if ":" in body:
            sym, val = body.split(":", 1)
            parts.append(f"{html.escape(sym.strip())} {html.escape(val.strip())}")
    return " · ".join(parts) if parts else "N/A"


def _status_book_line(all_results: Dict[str, Any]) -> str:
    """BUILD 16: one compact line with the six-agent book."""
    labels = (("technical", "tech"), ("multitimeframe", "mtf"), ("classical", "class"),
              ("smc", "smc"), ("price_action", "pa"), ("auction_flow", "auction"))
    parts = []
    for key, label in labels:
        result = (all_results or {}).get(key) or {}
        if not isinstance(result, dict):
            continue
        direction = str(result.get("signal") or result.get("direction") or "WAIT").upper()
        if direction in {"NEUTRAL", "HOLD", "NO_TRADE", "NONE", ""}:
            direction = "WAIT"
        confidence = _safe_float(result.get("confidence"), 0.0)
        tag = f"{direction[:1]}{confidence:.0f}"
        parts.append(f"{label} {tag}")
    return f"🧠 <b>Book:</b> {' · '.join(parts)}\n" if parts else ""


def _status_gates_line(config: Dict[str, Any], decision: Dict[str, Any]) -> str:
    """BUILD 16: one compact gates line (session/risk/news) — only claims what is known."""
    gates = []
    try:
        session = TradingSessionAgent(config).check()
        gates.append(f"Session {'ACTIVE' if session.get('trading_allowed') else 'OFF'}")
    except Exception:  # noqa: BLE001
        pass
    risk_level = None
    dynamic = decision.get("dynamic_risk") if isinstance(decision.get("dynamic_risk"), dict) else None
    if dynamic:
        risk_level = dynamic.get("level")
    risk_level = risk_level or decision.get("risk_level")
    if risk_level:
        gates.append(f"Risk {html.escape(str(risk_level).upper())}")
    if "news_blocked" in decision:
        gates.append(f"News {'BLOCKED' if decision.get('news_blocked') else 'CLEAR'}")
    return f"🛡️ <b>Gates:</b> {' · '.join(gates)}\n" if gates else ""


def _compact_agent_details(all_results: Dict[str, Any]) -> Dict[str, Any]:
    labels = {"technical": "Technical", "multitimeframe": "Multi-Timeframe", "classical": "Classical", "smc": "SMC", "price_action": "Price Action", "auction_flow": "Auction Flow", "macro_fundamental": "Macro / Fundamental", "oil_macro": "Oil Macro"}
    details: Dict[str, Any] = {}
    # 2026-08-19 (build 9): the admission ladder routes WTI confirmations to
    # oil_macro - the symbol must ride inside the details it evaluates.
    if all_results.get("symbol"):
        details["symbol"] = str(all_results.get("symbol"))
    for key, label in labels.items():
        used_key, result = _book_agent(all_results, key)
        # Unify reading order: signal first, then direction (same as DecisionAgent._collect_votes)
        direction = str(result.get("signal") or result.get("direction") or "WAIT").upper()
        if direction in {"NEUTRAL", "HOLD", "NO_TRADE", "NONE", ""}: direction = "WAIT"
        signals = result.get("signals") or result.get("reasons") or []
        if not signals and key in {"technical", "multitimeframe"}: signals = result.get("reasons") or []
        if not isinstance(signals, list): signals = [signals] if signals else []
        summary = result.get("summary") or result.get("reasoning") or ""
        entry = {
            "label": label,
            "direction": direction,
            "confidence": result.get("confidence", 0),
            "summary": summary,
            "signals": [str(x) for x in signals[:4] if x],
            "raw_edge": result.get("raw_edge"),
            "coherence": result.get("coherence"),
            "coverage": result.get("coverage"),
            "state": result.get("state"),
            "family_scores": deepcopy(result.get("family_scores") or {}),
            "timeframe_analysis": deepcopy(result.get("timeframe_analysis") or result.get("timeframe_family_scores") or {}),
            "key_levels": deepcopy(result.get("key_levels") or {}),
        }
        if key == "oil_macro":
            # never a voter; carry the raw fundamental bias so routed macro
            # gates/confirmations see BULLISH_OIL/BEARISH_OIL (direction stays
            # WAIT so nothing counts oil_macro as a core supporter).
            entry["bias"] = result.get("bias")
        details[key] = entry
        if key == "smc":
            # Path 4 reads the selected conditional map as MAP evidence only.
            # Carrying it here does not alter ``direction`` or confidence and
            # therefore cannot turn SMC WAIT into a synthetic Core vote.
            setup = result.get("setup_structure") or {}
            if isinstance(setup, dict):
                details[key]["conditional_map"] = deepcopy(setup)
            details[key]["market_structure"] = deepcopy(result.get("market_structure") or {})
    return details


#: Roles SMCAgent assigns to the candidates it actually selected. Anything
#: else -- in practice "REJECTED" -- is a candidate it ranked and declined.
_SELECTED_SETUP_ROLES = {"PRIMARY", "STANDBY", "STARTER", "ADD_ON"}


def _select_setup_candidate(decision_type: str, all_results: Dict[str, Any]) -> Dict[str, Any]:
    """The setup a signal is allowed to describe itself with.

    SMCAgent ranks every candidate and records the verdict in
    ``selection_role``: rank 1 becomes PRIMARY, a qualifying rank 2 becomes
    STANDBY, and everything else is labelled REJECTED (agents/smc_agent.py
    :1148). REJECTED is not a neutral label -- it means the agent that found
    the setup looked at it and did not choose it.

    This function used to re-sort ALL candidates by quality score and return
    the top one, never reading the role. A declined candidate could therefore
    be handed straight to a live order by having the best score among the
    leftovers.

    2026-07-31, TRADE_20260731_152110_326407_a5520ee6 shipped as a SELL LIMIT
    carrying "role REJECTED · quality C · dominance 47.6 · reach 40.8". Both
    of those numbers sit below the planner's own floors (min_primary_dominance
    50, min_return_probability 42), which is why the planner path would have
    refused it -- but the dual-agent path reads this function instead, so the
    floors were never consulted.

    Selected roles are now preferred absolutely: a PRIMARY or STANDBY always
    outranks a REJECTED, whatever their scores. Within the selected group the
    existing quality ordering is unchanged.

    A rejected candidate is still RETURNED when nothing else exists, because
    the payload it builds is also used for reporting and diagnostics. Refusing
    to publish is a separate decision, taken by
    ``_rejected_setup_execution_block`` at the point an order is created.
    """
    smc = all_results.get("smc", {}) or {}
    candidates = list(smc.get("setup_candidates") or [])
    if not candidates:
        return {}

    def _score(candidate: Dict[str, Any]) -> float:
        quality = candidate.get("setup_quality") or {}
        return float(quality.get("score", candidate.get("quality_score", 0)) or 0)

    def _was_selected(candidate: Dict[str, Any]) -> bool:
        role = str(candidate.get("selection_role") or "").upper()
        # An absent role predates the labelling and is treated as selected,
        # so older snapshots behave exactly as they did before.
        return role in _SELECTED_SETUP_ROLES or not role

    # Sort by (selected first, then quality). Python's sort is stable, so
    # equal-score candidates keep their original ranking.
    def _ordered(pool: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        return sorted(pool, key=lambda c: (0 if _was_selected(c) else 1, -_score(c)))

    side = str(decision_type or "").upper()
    if side in {"BUY", "SELL"}:
        directional = [c for c in candidates if str(c.get("direction", "")).upper() == side]
        if directional:
            return _ordered(directional)[0]
    return _ordered(candidates)[0]


def _setup_context_payload(decision: Dict[str, Any], all_results: Dict[str, Any]) -> Dict[str, Any]:
    decision_type = str(decision.get("decision") or "").upper()
    selected = _select_setup_candidate(decision_type, all_results)
    mtf = all_results.get("multitimeframe", {}) or {}
    quality = decision.get("quality") or {}
    entry_attr = decision.get("entry_attribution") or {}
    classic = decision.get("classic", {}) or {}
    strongest = classic.get("strongest_directional") or {}
    smc_structure = (all_results.get("smc", {}) or {}).get("setup_structure") or {}
    quality_obj = selected.get("setup_quality") if isinstance(selected.get("setup_quality"), dict) else None
    payload = {
        "id": selected.get("id"),
        "state_key": selected.get("state_key"),
        "setup_type": selected.get("setup_type") or mtf.get("setup_type") or smc_structure.get("setup_type") or "CONSENSUS_GENERIC",
        "setup_state": selected.get("setup_state") or smc_structure.get("setup_state") or ("ENTRY_TRIGGERED" if decision_type in {"BUY", "SELL"} else "DETECTED"),
        "lead_agent": selected.get("lead_agent") or entry_attr.get("primary_entry_driver") or strongest.get("agent") or "consensus",
        "quality_grade": (quality_obj or {}).get("grade") or selected.get("quality_grade") or quality.get("grade") or ((decision.get("trade_grade") or {}).get("grade") if isinstance(decision.get("trade_grade"), dict) else None),
        "quality_score": (quality_obj or {}).get("score") or selected.get("quality_score") or quality.get("score"),
        "poi_type": selected.get("poi_type") or smc_structure.get("poi_type"),
        "poi_zone": selected.get("poi_zone"),
        "poi_rank_score": selected.get("poi_rank_score") or smc_structure.get("poi_rank_score"),
        "poi_rank_reasons": selected.get("poi_rank_reasons") or smc_structure.get("poi_rank_reasons"),
        "poi_quality_score": selected.get("poi_quality_score") or smc_structure.get("poi_quality_score"),
        "return_probability_score": selected.get("return_probability_score") or smc_structure.get("return_probability_score"),
        "thesis_dominance_score": selected.get("thesis_dominance_score") or smc_structure.get("thesis_dominance_score"),
        "selection_role": selected.get("selection_role") or smc_structure.get("selection_role"),
        "selection_rank": selected.get("selection_rank") or smc_structure.get("selection_rank"),
        "expected_revisit_window": selected.get("expected_revisit_window") or smc_structure.get("expected_revisit_window"),
        "sweep_side": selected.get("sweep_side") or smc_structure.get("sweep_side"),
        "displacement_score": selected.get("displacement_score") or smc_structure.get("displacement_score"),
        "trigger_state": selected.get("trigger_state") or smc_structure.get("trigger_state"),
        "trigger_score": selected.get("trigger_score") or smc_structure.get("trigger_score"),
        "trigger_ready": selected.get("trigger_ready") if selected.get("trigger_ready") is not None else smc_structure.get("trigger_ready"),
        "execution_hint": selected.get("execution_hint") or smc_structure.get("execution_hint"),
        "target_liquidity": selected.get("target_liquidity") or smc_structure.get("target_liquidity"),
        "entry_reason": selected.get("entry_reason"),
        "details": selected.get("details") or {},
    }
    # Operator audit 2026-08-07 (card 17:02): never publish a wrong-side
    # target liquidity (BUY target below market, SELL above) from ANY source.
    _ref = float(decision.get("current_price") or 0.0)
    _tl = payload.get("target_liquidity")
    if _tl and _ref > 0:
        _wrong = (_tl <= _ref) if decision_type == "BUY" else (_tl >= _ref)
        if _wrong:
            payload["target_liquidity"] = None
    # (the final filter drops the None, so the card omits wrong-side targets)
    return {k: v for k, v in payload.items() if v not in (None, "", {}, [])}


def run_agent(agent_name: str, agent: Any, data: Dict[str, Any]) -> Dict[str, Any]:
    try:
        logger.info("Running agent: %s", agent_name)
        result = agent.analyze(data)
        if isinstance(result, dict) and isinstance(data.get("shared_market_data"), dict):
            result["shared_market_data"] = deepcopy(data.get("shared_market_data"))
        return result
    except Exception as exc:
        logger.exception("Agent %s failed", agent_name)
        return {"agent": agent_name, "signal": "WAIT", "confidence": 0, "reasoning": f"Agent failed: {exc}"}


def _log_gemini_result(label: str, result: Dict[str, Any] | None) -> None:
    result = result or {}
    if result.get("available"):
        logger.info("🧠 Gemini %s: added quality=%s", label, result.get("quality", "ok"))
    elif result.get("suppressed"):
        logger.info("🧠 Gemini %s: suppressed (%s)", label, result.get("suppress_reason", "generic"))
    else:
        logger.info("🧠 Gemini %s: unavailable/skipped (%s)", label, result.get("summary") or result.get("reason") or "unknown")


def _post_news_release_bucket(event: Dict[str, Any], minutes_until: Any, now: datetime) -> str:
    """BUILD 27 (2026-08-21): the release minute as 'YYYY-MM-DDTHH:MM'.

    The old tracker key used the RAW time string, which drifts between the
    merged news sources (local file vs live ForexFactory fetch), so the same
    event produced new keys across cycles and re-sent every time. The bucket
    is derived from the parsed release time (fallback: now + minutes_until)
    and is immune to formatting drift. Events released in the SAME minute
    share one bucket -> one card per symbol for a simultaneous release
    (e.g. Manufacturing + Services PMI at 13:45).
    """
    raw = str(event.get("time") or "")
    if raw:
        parsed = _parse_datetime(raw)
        if parsed:
            return parsed.strftime("%Y-%m-%dT%H:%M")
    try:
        released = now + timedelta(minutes=int(minutes_until or 0))
    except (TypeError, ValueError):
        released = now
    return released.strftime("%Y-%m-%dT%H:%M")


def _check_and_send_post_news(
    gemini, telegram, news_result: Dict[str, Any],
    symbol: str, current_price: float, config: Dict[str, Any],
    database: Any = None,
) -> None:
    """Check if a TIER_1/TIER_2 event recently released and send post-news analysis.

    Trigger: event was released 3-60 minutes ago.
    BUILD 27 (2026-08-21) fixes the unlimited duplication:
      * the tracker FILE is now really defined (it was a silent NameError);
      * the tracker key = symbol + release-minute bucket (not the raw time
        string), so an event is sent ONCE per symbol across all cycles and
        news sources;
      * events released in the same minute are grouped into ONE card per
        symbol ("Flash Manufacturing PMI + Flash Services PMI");
      * WTI requests carry the oil macro so the card reads Oil Impact with
        oil fundamentals instead of a gold recommendation.
    """
    from utils.helpers import get_current_session
    try:
        upcoming = news_result.get("upcoming_events") or []
        now = datetime.now(timezone.utc)

        # Collect + group eligible events by their release-minute bucket.
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        for event in upcoming:
            if not isinstance(event, dict):
                continue
            tier = str(event.get("tier", "")).upper()
            if tier not in {"TIER_1", "TIER_2"}:
                continue
            minutes_until = event.get("minutes_until", 0)
            if not (-60 <= minutes_until <= -3):
                continue
            bucket = _post_news_release_bucket(event, minutes_until, now)
            grouped.setdefault(bucket, []).append(event)
        if not grouped:
            return

        # Per-symbol fundamentals for the payload.
        oil_macro_ctx = None
        if "WTI" in symbol.upper():
            try:
                # BUILD 27 fix (2026-08-22): use the module-level OilMacroAgent
                # import (line 42) - the previous function-local `from ... import`
                # re-bound the name from the source module on every call, so a
                # test monkeypatch of scripts.run_analysis.OilMacroAgent was
                # silently ignored and the real (data-dependent) agent ran.
                wti_cfg = config_for_instrument(config, {"symbol": "WTI/USD"})
                om = OilMacroAgent(wti_cfg).analyze({"symbol": "WTI/USD"})
                if isinstance(om, dict) and om:
                    oil_macro_ctx = {
                        "direction": om.get("direction"),
                        "bias": om.get("bias"),
                        "confidence": om.get("confidence"),
                        "score": om.get("score"),
                        "summary": str(om.get("summary") or "")[:200],
                    }
            except Exception:  # noqa: BLE001 - the block is optional
                pass

        macro_context = {}
        if database:
            try:
                macro_context = database.get_macro_context()
            except Exception:  # noqa: BLE001
                pass

        # R19-A (2026-08-27): the DIGEST path selector. The instrument
        # registry survives config_for_instrument's deepcopy, so every
        # per-symbol cycle can see the FULL watchlist. When it is present
        # (and not disabled), ONE card per EVENT replaces six per-symbol
        # cards; the legacy path below stays for single-instrument configs
        # and for notifications.post_news_digest=false.
        _instruments = config.get("instruments")
        _digest_on = (bool((config.get("notifications") or {}).get(
            "post_news_digest", True))
            and isinstance(_instruments, list) and len(_instruments) > 1)
        # Shared digest context, built ONCE per call (not per symbol): the
        # DXY/macro line and the WTI oil-macro block for the digest card.
        _digest_oil_macro = oil_macro_ctx
        _digest_dxy_info = ""
        if _digest_on:
            if _digest_oil_macro is None and any(
                "WTI" in str((i or {}).get("symbol") or "").upper()
                for i in _instruments if isinstance(i, dict)
            ):
                try:
                    wti_cfg = config_for_instrument(config, {"symbol": "WTI/USD"})
                    om = OilMacroAgent(wti_cfg).analyze({"symbol": "WTI/USD"})
                    if isinstance(om, dict) and om:
                        _digest_oil_macro = {
                            "direction": om.get("direction"),
                            "bias": om.get("bias"),
                            "confidence": om.get("confidence"),
                            "score": om.get("score"),
                            "summary": str(om.get("summary") or "")[:200],
                        }
                except Exception:  # noqa: BLE001 - optional context only
                    pass
            try:
                from agents.macro_fundamental_agent import MacroFundamentalAgent
                _macro_agent = MacroFundamentalAgent(config)
                _macro = (_macro_agent.macro_direction(macro_context)
                          if macro_context else _macro_agent.macro_direction({}))
                _dxy_trend = (macro_context.get("dxy_trend")
                              or macro_context.get("usd_trend") or "unknown")
                _risk = macro_context.get("risk_sentiment") or "unknown"
                _digest_dxy_info = f"DXY trend: {_dxy_trend}, Risk: {_risk}"
                if _macro.get("summary"):
                    _digest_dxy_info += f", Macro: {_macro['summary']}"
            except Exception:  # noqa: BLE001 - optional context only
                _digest_dxy_info = "DXY trend: unknown, Risk: unknown"

        for bucket, events in grouped.items():
            names = " + ".join(
                dict.fromkeys(str(e.get("event") or "Unknown Event") for e in events))
            primary = events[0]
            if _digest_on:
                event_key = digest_event_key(bucket)
                if post_news_alert_sent(event_key, database=database):
                    continue
                logger.info("Post-news digest trigger: %s (bucket %s)", names, bucket)
                _caller = normalize_symbol(symbol)
                _payloads = []
                for _inst in _instruments:
                    if not isinstance(_inst, dict):
                        continue
                    _sym = normalize_symbol(str(_inst.get("symbol") or ""))
                    if not _sym:
                        continue
                    _payloads.append({
                        "symbol": _sym,
                        "event_name": names,
                        "actual": primary.get("actual") or primary.get("expected"),
                        "forecast": primary.get("expected") or primary.get("forecast"),
                        "previous": primary.get("previous"),
                        "impact_tier": str(primary.get("tier", "")).upper(),
                        "minutes_since_release": abs(primary.get("minutes_until", 0) or 0),
                        # Only the calling symbol carries a fresh price; every
                        # other instrument gets None and the digest prompt
                        # forbids quoting levels without a provided price.
                        "current_price": current_price if _sym == _caller else None,
                        "price_before_event": None,
                        "price_change_since_event": None,
                        "dxy_macro": _digest_dxy_info,
                        "oil_macro": _digest_oil_macro if "WTI" in _sym.upper() else None,
                        "session": get_current_session(),
                    })
                if _payloads:
                    _analysis = gemini.interpret_post_news_digest(_payloads)
                    _log_gemini_result("post-news-digest", _analysis)
                    if _analysis.get("available") and not _analysis.get("suppressed"):
                        if telegram.send_post_news_digest(_analysis, names):
                            post_news_alert_record(event_key, database=database)
                            logger.info(
                                "Post-news DIGEST sent for %s (%d instruments)",
                                names, len(_payloads))
                # A failed/unavailable digest stays UNRECORDED so a later
                # instrument's cycle retries it - the card is never lost,
                # only deferred.
                continue
            event_key = f"{symbol}_{bucket}"
            if post_news_alert_sent(event_key, database=database):
                continue
            logger.info("📰 Post-news trigger: %s (bucket %s)", names, bucket)
            from agents.macro_fundamental_agent import MacroFundamentalAgent
            macro_agent = MacroFundamentalAgent(config)
            macro = macro_agent.macro_direction(macro_context) if macro_context else macro_agent.macro_direction({})
            dxy_trend = macro_context.get("dxy_trend") or macro_context.get("usd_trend") or "unknown"
            risk_sentiment = macro_context.get("risk_sentiment") or "unknown"
            dxy_info = f"DXY trend: {dxy_trend}, Risk: {risk_sentiment}"
            if macro.get("summary"):
                dxy_info += f", Macro: {macro['summary']}"
            payload = {
                "symbol": symbol,
                "event_name": names,
                "actual": primary.get("actual") or primary.get("expected"),
                "forecast": primary.get("expected") or primary.get("forecast"),
                "previous": primary.get("previous"),
                "impact_tier": str(primary.get("tier", "")).upper(),
                "minutes_since_release": abs(primary.get("minutes_until", 0)),
                "current_price": current_price,
                "price_before_event": None,  # not tracked per-event
                "price_change_since_event": None,
                "dxy_macro": dxy_info,
                "oil_macro": oil_macro_ctx,
                "session": get_current_session(),
            }
            analysis = gemini.interpret_post_news(payload)
            _log_gemini_result("post-news", analysis)
            if analysis.get("available") and not analysis.get("suppressed"):
                sent = telegram.send_post_news_analysis(analysis, names, symbol)
                if sent:
                    post_news_alert_record(event_key, database=database)
                    logger.info("📰 Post-news analysis sent for: %s", names)
    except Exception as exc:
        logger.warning("Post-news analysis check failed: %s", exc)


async def _run_analysis_for_config(config: Dict[str, Any]) -> None:
    # R26.7: shadow mode removed entirely (operator 2026-09-01) — every
    # enabled instrument runs the full pipeline against the LIVE services
    # (real trade book + real Telegram card). There is no isolated
    # measurement book and no banner; PATH 6 OTE executes as a live pending.
    telegram = TelegramService(config)
    status_delivery = _HourlyStatusDelivery(telegram, config)
    try:
        database = DatabaseService(config)
        # Exactly one mode read in this entrypoint: every demo delivery path
        # below persists first, then lets the tick manager announce only after
        # MT5 accepts the order.
        demo_execution = (os.environ.get("EXECUTION_MODE") == "mt5_demo")
        symbol = str(config.get("symbol", "XAU/USD"))
        # Arm immediately, not 400 lines later at the decision. An agent that
        # raises, a market-data timeout, or a Supabase error all abort the
        # cycle long before a decision exists; without this the `finally`
        # flush has nothing to send and the hour passes silently. The payload
        # is upgraded in place once the real decision is known.
        if should_send_hourly_status(config):
            status_delivery.arm(
                decision={"symbol": symbol, "decision": "PENDING"},
                all_results={"symbol": symbol},
                database=database,
            )
        normalized_symbol = normalize_symbol(symbol)
        open_trades_snapshot = database.get_open_trades()
        has_symbol_active_trades = any(normalize_symbol(t.get("symbol") or symbol) == normalized_symbol for t in open_trades_snapshot)
        session = TradingSessionAgent(config).check()
        if not session.get("trading_allowed") and not has_symbol_active_trades:
            # Post-news check: even outside hours, fire if a TIER_1/TIER_2
            # event just released — subscribers need the briefing regardless.
            post_news_was_sent = False
            try:
                gemini_off_hours = get_gemini_review_service(config)
                if gemini_off_hours.enabled:
                    news_off = NewsRiskAgent({**config, "macro_context": database.get_macro_context()}).check()
                    _check_and_send_post_news(
                        gemini=gemini_off_hours, telegram=telegram,
                        news_result=news_off, symbol=symbol,
                        current_price=None, config=config, database=database,
                    )
                    post_news_was_sent = any(
                        "post-news" in str(getattr(telegram, '_last_msg', ''))
                    )
            except Exception: pass
            
            if should_send_hourly_status(config) and not post_news_was_sent:
                status_delivery.mark_sent()
                _send_hourly_status_once(telegram, config,
                    "🟡 <b>SmartSignal — Market Status</b>\n━━━━━━━━━━━━━━━━━━━━\n📈 Price: N/A\n🎯 Decision: WAIT\n📊 Outside trading hours\n\n<b>Reason:</b>\n• Outside trading hours\n━━━━━━━━━━━━━━━━━━━━")
            if post_news_was_sent:
                status_delivery.mark_sent()
            return
        market_data = MarketDataService(config)
        data = market_data.get_gold_data()
        if not data:
            _report_data_outage(
                telegram, config, symbol, delivery=status_delivery,
                reason="No market data returned (provider quota, rate limit, or outage).",
            )
            # R17: silent exits used to leave the funnel blind ("ZERO audit
            # rows -> never cycled"). Every gate exit now writes a named row.
            _record_decision_audit(
                database, {"symbol": symbol}, config,
                stage="data gate", outcome="REFUSED",
                reason="No market data returned (provider quota, rate limit, or outage).",
            )
            return
        integrity = data.get("source_integrity") or {}
        logger.info(
            "Market data integrity for %s: source=%s type=%s grade=%s signal_generation=%s pending_activation=%s",
            symbol,
            integrity.get("source") or data.get("source"),
            integrity.get("source_type") or "unknown",
            integrity.get("reliability_grade") or "UNKNOWN",
            integrity.get("supports_signal_generation"),
            integrity.get("supports_pending_activation"),
        )
        if not _payload_supports_signal_generation(data):
            logger.error(
                "Analysis stopped for %s: source %s is not reliable enough for signal generation.",
                symbol,
                integrity.get("source") or data.get("source"),
            )
            _report_data_outage(
                telegram, config, symbol, delivery=status_delivery,
                reason=f"Data source '{integrity.get('source') or data.get('source')}' cannot support signal generation.",
            )
            # R17: named audit row (see gate 1 comment).
            _record_decision_audit(
                database, {"symbol": symbol}, config,
                stage="data gate", outcome="REFUSED",
                reason=f"Data source '{integrity.get('source') or data.get('source')}' cannot support signal generation.",
            )
            return
        # Global price sanity — reject obviously corrupt ticks before analysis
        _cp = float(data.get('current_price', 0))
        _sym = str(config.get('symbol', 'XAU/USD'))
        from utils.instruments import price_sanity_range
        _sane_min, _sane_max = price_sanity_range(_sym, config)
        if _cp > 0 and (_cp < _sane_min or _cp > _sane_max):
            logger.error(
                'PRICE SANITY FAILED (analysis): %s price=%.5f outside [%.2f-%.2f]. '
                'Skipping cycle — data provider glitch.',
                _sym, _cp, _sane_min, _sane_max,
            )
            _report_data_outage(
                telegram, config, symbol, delivery=status_delivery,
                reason=f"Price {_cp:.5f} failed the sanity range [{_sane_min:.2f}-{_sane_max:.2f}].",
            )
            # R17: named audit row (see gate 1 comment).
            _record_decision_audit(
                database, {"symbol": symbol}, config,
                stage="data gate", outcome="REFUSED",
                reason=f"Price {_cp:.5f} failed the sanity range [{_sane_min:.2f}-{_sane_max:.2f}].",
            )
            return
        # Publish the exact frozen native book once. Every core agent below
        # receives this same object/snapshot_id; no agent fetches candles.
        data = publish_shared_market_data(data, config)
        logger.info(
            "Shared market-data book ready: %s source=%s stored=%s path=%s",
            (data.get("shared_market_data") or {}).get("snapshot_id"),
            (data.get("shared_market_data") or {}).get("source"),
            # True = swapped to disk; False = held lock, cycle continued on the
            # in-memory book (graceful degradation, operator 2026-08-14).
            (data.get("shared_market_data") or {}).get("stored"),
            (data.get("shared_market_data") or {}).get("storage_path"),
        )
        # R26.9.16: a live violent displacement (>=5x ATR on M15) re-asks
        # the macro judge with FRESH data right here — before this cycle
        # reads the verdict that gates entries and thesis exits.
        _maybe_refresh_macro_context(data, config, database)
        persisted_macro_context = database.get_macro_context()
        # The verified snapshot is an input to three of the five voting agents,
        # so it has to exist before any of them are asked anything. It is built
        # purely from `data` and `config`, both already in hand.
        verified_snapshot = build_market_snapshot(data, config)
        data["verified_snapshot"] = verified_snapshot
        # Macro is part of both entry Path 2 and the mirrored thesis-exit Path
        # 2, so compute it once before managing existing positions.
        macro_input = {**data, "macro_context": persisted_macro_context} if persisted_macro_context else data
        macro = run_agent("macro_fundamental", MacroFundamentalAgent(config), macro_input)
        # R26.9 (2026-09-01): the oil fundamental voice must exist BEFORE the
        # exit-mirror book is built, so a crude flip is routed to oil_macro
        # (EIA/OPEC/spread) instead of the dollar/gold macro. Computed once.
        oil_macro = run_agent("oil_macro", OilMacroAgent(config), data)
        if has_symbol_active_trades:
            high, low = _latest_candle_extremes(data)
            recent_candles = (((data.get("timeframes", {}) or {}).get("5m") or {}).get("data") or data.get("data") or [])[-6:]
            try:
                news_pre_cfg = {**config, "macro_context": persisted_macro_context} if persisted_macro_context else config
                news_pre = NewsRiskAgent(news_pre_cfg).check()
            except Exception:
                news_pre = {}
            news_blocked_pre = bool(news_pre.get("can_trade") is False or str(news_pre.get("market_status", "")).upper() in {"DANGER", "HIGH_VOLATILITY"})
            # Give the exit the same agent read the rest of the cycle gets.
            #
            # The thesis exit used to decide on two candles alone, 23 lines
            # before these agents were polled -- so on 2026-07-30 it closed a
            # SELL while Classical 71, SMC 90 and Multi-Timeframe 83 were all
            # still arguing SELL, and the planner republished that exact zone
            # as an A+ map hours later.
            #
            # These are the same six calls the cycle makes below, on the same
            # `data`. Failure is non-fatal: an empty book makes the exit behave
            # exactly as it did before.
            exit_agent_details: Dict[str, Any] | None = None
            try:
                pre_exit_results = {
                    "technical": run_agent("technical", TechnicalAgent(config), data),
                    "multitimeframe": run_agent("multitimeframe", MultiTimeframeAgent(config), data),
                    "classical": run_agent("classical", ClassicalAgent(config), data),
                    "smc": run_agent("smc", SMCAgent(config), data),
                    "price_action": run_agent("price_action", PriceActionAgent(config), data),
                    "auction_flow": run_agent("auction_flow", AuctionFlowAgent(config), data),
                    "macro_fundamental": macro,
                    # R26.9: give the exit mirror the SAME fundamental voice
                    # the entry gate routes to for this symbol (oil_macro for
                    # crude). The agent never votes (signal WAIT); the gate
                    # reads its bias.
                    "oil_macro": oil_macro,
                }
                exit_agent_details = _compact_agent_details(pre_exit_results)
                logger.info(
                    "Exit agent book for %s: %s",
                    symbol,
                    {k: f"{v.get('direction')} {v.get('confidence')}" for k, v in exit_agent_details.items()},
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("Could not build the exit agent book for %s: %s", symbol, exc)
                exit_agent_details = None
            # Demo mode (2026-08-10 single-owner + thesis handoff): the
            # embedded manager may DECIDE (thesis exits/scale-outs/staleness)
            # but never BOOK execution — DemoHandoffDB converts close intents
            # into requested_* flags the tick manager executes at the broker
            # first, and suppresses its cards (tick sends truthful ones).
            if demo_execution:
                from services.demo_handoff import DemoHandoffDB
                _db = DemoHandoffDB(database)
                _tg = None
            else:
                _db = database
                _tg = telegram
            OpenTradesManager(config).update_trades(
                open_trades=[t for t in open_trades_snapshot if normalize_symbol(t.get("symbol") or symbol) == normalized_symbol],
                current_price=float(data.get("current_price", 0)),
                candle_high=high,
                candle_low=low,
                recent_candles=recent_candles,
                database=_db,
                telegram=_tg,
                now=datetime.now(timezone.utc),
                news_blocked=news_blocked_pre,
                news_context=news_pre,
                market_data_source=str(data.get("source") or ""),
                agent_details=exit_agent_details,
            )
        if not session.get("trading_allowed"): return
        news_config = {**config, "macro_context": persisted_macro_context} if persisted_macro_context else config
        news = NewsRiskAgent(news_config).check()
        if isinstance(news, dict) and isinstance(macro, dict) and macro.get("macro_direction"):
            news["macro_direction"] = macro.get("macro_direction")
            news["macro_agent"] = macro
        # ── 2026-08-19: D1 market regime (MT5-native, fail-open) ──────────
        # Computed BEFORE the agents dict so VolatilityAgent can use the ATR
        # percentile for its regime escalation.
        _market_regime_ctx = {}
        try:
            from services.market_regime import fetch_d1_context

            _market_regime_ctx = fetch_d1_context(config)
        except Exception as _regime_exc:  # noqa: BLE001
            _market_regime_ctx = {"regime": "ERROR", "error": str(_regime_exc)}
        all_results = {"technical": run_agent("technical", TechnicalAgent(config), data), "multitimeframe": run_agent("multitimeframe", MultiTimeframeAgent(config), data), "classical": run_agent("classical", ClassicalAgent(config), data), "smc": run_agent("smc", SMCAgent(config), data), "price_action": run_agent("price_action", PriceActionAgent(config), data), "auction_flow": run_agent("auction_flow", AuctionFlowAgent(config), data), "macro_fundamental": macro, "current_price": data["current_price"], "symbol": symbol, "session": session, "verified_snapshot": verified_snapshot, "shared_market_data": deepcopy(data.get("shared_market_data") or {}), "news": news, "daily_bias": run_agent("daily_bias", DailyBiasAgent(config), data), "market_regime": _market_regime_ctx,
 "sentiment": run_agent("sentiment", SentimentAgent(config), data),
 "volatility": run_agent("volatility", VolatilityAgent(config), {**data, "market_regime": _market_regime_ctx}),
 "oil_macro": oil_macro}
        # Sprint 2 foundation: persist setup-state transitions across cycles.
        setup_memory = SetupMemoryService(database, config)
        try:
            processed_candidates = setup_memory.process_candidates(
                list(((all_results.get("smc", {}) or {}).get("setup_candidates") or []))[:3],
                current_price=float(data.get("current_price", 0) or 0),
                symbol=symbol,
            )
            if "smc" in all_results and isinstance(all_results["smc"], dict):
                all_results["smc"]["setup_candidates"] = processed_candidates
                if processed_candidates:
                    all_results["smc"]["setup_structure"] = processed_candidates[0]
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to process setup-memory state transitions: %s", exc)
        try:
            all_results["reversal_watch"] = _active_reversal_watch(database, symbol=symbol)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to load active reversal watch for %s: %s", symbol, exc)
            all_results["reversal_watch"] = {}

        # Phase 1 foundation: build a morning/session plan BEFORE the move.
        # This is planning-only for now; later phases can translate PRIMARY /
        # STANDBY plan objects into live laddered pending orders.
        previous_sent_session_plan_rows: List[Dict[str, Any]] = []
        session_plan_context = {
            "symbol": symbol,
            "current_price": float(data.get("current_price") or 0),
            "market_data_source": str(data.get("source") or ""),
            "analysis_run_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        }
        session_plan_snapshot_id = None
        session_plan_delivery_meta = {"send": False, "reason": None, "kind": None, "previous": None}
        try:
            previous_sent_session_plan_rows = database.get_recent_session_plans(limit=12, symbol=symbol, sent_only=True)
        except Exception as prev_exc:  # noqa: BLE001
            logger.warning("Failed to load previously delivered session plans: %s", prev_exc)
        try:
            session_plan = SessionPlannerService(config).build_plan(all_results, persist=False)
            all_results["session_plan"] = session_plan
            if session_plan.get("plan_ready"):
                logger.info(
                    "Session plan ready for %s: %s %s | primary=%s | standby=%s | score=%s",
                    symbol,
                    session_plan.get("session_bias"),
                    session_plan.get("scenario_type"),
                    ((session_plan.get("primary_poi") or {}).get("entry_price")),
                    ((session_plan.get("standby_poi") or {}).get("entry_price")) if session_plan.get("standby_poi") else None,
                    session_plan.get("planner_confidence"),
                )
            else:
                logger.info("Session plan not ready for %s: %s", symbol, session_plan.get("plan_reason"))
            session_plan["execution_audit"] = _session_plan_execution_audit(session_plan, stage="plan_built")
            try:
                session_plan_snapshot_id = database.save_session_plan(session_plan, session_plan_context)
            except Exception as persist_exc:  # noqa: BLE001
                logger.warning("Failed to persist session plan snapshot: %s", persist_exc)
            session_plan_delivery_meta = _session_plan_delivery_meta(
                session_plan,
                previous_sent_session_plan_rows,
                config,
                symbol=symbol,
            )
            if session_plan_snapshot_id:
                try:
                    database.merge_session_plan_payload(
                        session_plan_snapshot_id,
                        {
                            "execution_audit": _session_plan_execution_audit(
                                session_plan,
                                stage="delivery_evaluated",
                                delivery_send_planned=bool(session_plan_delivery_meta.get("send")),
                                delivery_reason=session_plan_delivery_meta.get("reason"),
                                delivery_kind=session_plan_delivery_meta.get("kind"),
                            )
                        },
                    )
                except Exception as audit_exc:  # noqa: BLE001
                    logger.warning("Failed to merge session plan execution audit: %s", audit_exc)
        except Exception as exc:  # noqa: BLE001
            # 21 of the last 300 cycles died here with a bare
            # "'NoneType' object has no attribute 'get'" and no traceback, so
            # the failing line was unknowable from the logs. A crash rate of
            # 7% is not a rounding error: those are cycles that produced no
            # map at all, and nobody could see why.
            logger.exception("Failed to build session plan for %s", symbol)
            all_results["session_plan"] = {
                "enabled": True,
                "plan_ready": False,
                "plan_status": "ERROR",
                # Keep the type in the stored reason so the rejection report
                # can separate real refusals from crashes at a glance.
                #
                # ...and the LOCATION. "'NoneType' object has no attribute
                # 'get'" names the symptom, never the site: there are
                # hundreds of `.get(` calls under build_plan and the message
                # fits every one of them. Five crashed cycles have been
                # sitting in every report since #16 with no way to act on
                # them, because `logger.exception` writes the traceback to
                # the run log while the REPORT reads the stored row, and the
                # stored row had only the text.
                #
                # The last in-project frame is the one that matters -- the
                # deepest line inside this repository, skipping site-packages
                # -- so it is folded into the reason the report already
                # groups on. Truncated because that grouping key is 48 chars.
                "plan_reason": (
                    f"planner crashed: {type(exc).__name__}: {exc}"
                    f" @ {_crash_site(exc)}"
                ),
                "crash_site": _crash_site(exc),
                "crash_traceback": "".join(
                    traceback.format_exception(type(exc), exc, exc.__traceback__)
                )[-4000:],
            }
            try:
                session_plan_snapshot_id = database.save_session_plan(all_results["session_plan"], session_plan_context)
            except Exception as persist_exc:  # noqa: BLE001
                logger.warning("Failed to persist errored session plan snapshot: %s", persist_exc)
        # Inject portfolio info so RiskManagementAgent can enforce max_open_trades
        # and max_daily_signals filters. Without this, those filters see 0 and
        # never block — which caused 15 simultaneous BUY trades.
        from datetime import date as _date
        _today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        _open_trades_count = len([t for t in open_trades_snapshot if str(t.get("status", "OPEN")).upper() in {"OPEN", "PARTIAL", "TP1_HIT", "PENDING"}])
        # 2026-08-19 (build 15, operator order): per-symbol open count for the
        # per-pair cap (max_open_trades_per_symbol). Each pair gets its own
        # limit instead of one aggregate across all pairs.
        # R26.9.9 (operator 2026-09-01): PENDING rows are COMMITTED capital --
        # a resting order is a position the broker will fill. Excluding them
        # made every risk count read 0 while pendings rested, so consecutive
        # cycles kept creating more (live: THREE full GBP/USD entries within
        # 5 minutes, 2026-09-01 19:32/19:34/19:37). Every count now sees
        # ACTIVE = {OPEN, PARTIAL, TP1_HIT, PENDING}.
        _open_trades_count_this_symbol = len([
            t for t in open_trades_snapshot
            if normalize_symbol(t.get("symbol") or symbol) == normalized_symbol
            and str(t.get("status", "OPEN")).upper() in {"OPEN", "PARTIAL", "TP1_HIT", "PENDING"}
        ])
        _today_signals = database.get_recent_trades(limit=100)
        _today_signals_count = len([t for t in _today_signals if (t.get("created_at") or t.get("entry_time") or "").startswith(_today_str)])
        all_results["portfolio"] = {
            "open_trades_count": _open_trades_count,
            "open_trades_count_this_symbol": _open_trades_count_this_symbol,
            "today_signals_count": _today_signals_count,
        }
        # ── 2026-08-19: D1 market regime computed earlier (see agent dict) ─
        all_results["risk"] = RiskManagementAgent(config).evaluate(all_results)
        # DYNAMIC RISK BEFORE ADDS (operator 2026-08-18h, fix 3 of 3).
        # The account circuit breaker was computed AFTER _check_scale_in ran,
        # so the add engine never saw it: on 2026-08-18 the loss streak hit
        # 3 (halt_after_losses) mid-chain and the adds kept coming — four
        # SL_HITs deep. The breaker is evaluated first now, and a HALT-level
        # verdict silences the add engine for the cycle. Adds are the most
        # aggressive order type in the system; they go first, not last.
        all_results["dynamic_risk"] = DynamicRiskManager(config).evaluate(database)
        # Scale-in AFTER risk evaluation so it can check risk filters
        if has_symbol_active_trades:
            _dr = all_results.get("dynamic_risk", {}) or {}
            _dr_level = str(_dr.get("level") or _dr.get("risk_level") or "").upper()
            if "HALT" in _dr_level:
                logger.info(
                    "Scale-in engine silenced for %s: dynamic risk level %s (%s)",
                    symbol, _dr_level,
                    "; ".join(str(w) for w in (_dr.get("warnings") or [])[:2]) or "circuit breaker",
                )
            else:
                await _check_scale_in(
                    config,
                    all_results,
                    [t for t in open_trades_snapshot if normalize_symbol(t.get("symbol") or symbol) == normalized_symbol],
                    database,
                    telegram,
                    demo_execution=demo_execution,
                )
        learning_service = None
        try:
            learning_service = get_learning_service(database, config)
            # Note: load_current_weights() now reads from config.json (single source of truth).
            # We still initialize learning_service for confidence adjustments and recommendations.
        except Exception: pass
        decision = await DecisionAgent(config, learning_service=learning_service).decide_async(all_results)
        decision["agent_details"] = _compact_agent_details(all_results)
        decision["symbol"] = symbol
        decision["shared_market_data"] = deepcopy(all_results.get("shared_market_data") or {})
        decision["session_plan"] = all_results.get("session_plan", {})
        # ── 2026-08-19 upgrade gates: D1 regime + cross-asset correlation ──
        try:
            decision = _apply_regime_and_correlation_gates(
                decision, config, all_results, open_trades_snapshot, symbol,
            )
        except Exception as _gate_exc:  # noqa: BLE001 — gates must fail open
            logger.warning("Regime/correlation gates failed (fail-open): %s", _gate_exc)
        try:
            # Freshest book for the activation gate (operator 2026-08-18):
            # the trade-update/tick processes activate pendings but never run
            # agents; this store is how they see the book at touch time.
            try:
                from services.agent_book_store import save_agent_book
                save_agent_book(
                    symbol,
                    _r25_book_site_basis(all_results,
                                         _compact_agent_details(all_results)),
                    site_context=_r25_site_range(decision),
                )
            except Exception as book_exc:  # noqa: BLE001
                logger.warning("Agent book store write failed (gate will fail open): %s", book_exc)
            # R25-2 (2026-08-28): SCALP-FADE. Evaluates the premium fade every
            # cycle and places the scalp order when the plan arms (R26.7: the
            # former paper/journal-only mode was removed — scalp trades live).
            try:
                _r25_scalp_execute(decision, symbol, config, database,
                                   telegram, open_trades_snapshot,
                                   demo_execution=demo_execution)
            except Exception:  # noqa: BLE001 - scalp never breaks the cycle
                logger.debug("r25 scalp execute failed", exc_info=True)
            measurement_path = record_agent_measurement(all_results, decision, config)
            if measurement_path:
                logger.info("Non-trading agent measurement captured: %s", measurement_path)
        except Exception as measurement_exc:  # noqa: BLE001
            logger.warning("Agent measurement capture failed without affecting trading: %s", measurement_exc)
        # Persist opinions/actual decision weights for EVERY map snapshot,
        # including NOT_READY. Previously these existed only in a throwaway
        # Telegram copy or READY execution audit, making current refusals
        # impossible to diagnose from session_plans.json.
        if session_plan_snapshot_id:
            try:
                database.merge_session_plan_payload(
                    session_plan_snapshot_id,
                    {
                        "agent_opinions": _session_plan_agent_opinions(
                            decision.get("agent_details") or {}),
                        "decision_context": {
                            "decision": decision.get("decision"),
                            "confidence": decision.get("confidence"),
                            "weights": deepcopy(decision.get("weights") or {}),
                            "strategy_profile": deepcopy(decision.get("strategy_profile") or {}),
                            "rejection_reason": ((decision.get("classic") or {}).get("rejection_reason")
                                                 if isinstance(decision.get("classic"), dict) else None),
                        },
                    },
                )
            except Exception as audit_exc:  # noqa: BLE001
                logger.warning("Failed to persist map agent opinions: %s", audit_exc)
        # Phase 5 data-enrichment: persist compact context with each trade so
        # learning/weekly reports can reason about sessions, news proximity,
        # volatility regime, and planned-vs-actual R:R without reconstructing
        # the original analysis run later.
        decision["session_info"] = session
        decision["daily_bias"] = all_results.get("daily_bias", {})
        decision["news_context"] = {
            "rule_based": all_results.get("news", {}),
            "macro": all_results.get("macro_fundamental", {}),
            "ai": all_results.get("news_ai", {}),
        }
        decision["market_context"] = {
            "technical_regime": (all_results.get("technical", {}) or {}).get("market_regime") or {},
            "rsi": ((all_results.get("technical", {}) or {}).get("technical") or {}).get("rsi"),
            "daily_bias": all_results.get("daily_bias", {}),
            "daily_regime": all_results.get("market_regime", {}),
            "macro_direction": (all_results.get("news", {}) or {}).get("macro_direction") or (all_results.get("macro_fundamental", {}) or {}).get("macro_direction", {}),
            # 2026-08-19 phase-2 agents (non-voting context)
            "sentiment_bias": (all_results.get("sentiment", {}) or {}).get("bias"),
            "sentiment_confidence": (all_results.get("sentiment", {}) or {}).get("confidence"),
            "volatility_regime": (all_results.get("volatility", {}) or {}).get("regime"),
            "volatility_multiplier": (all_results.get("volatility", {}) or {}).get("suggested_risk_multiplier"),
            "oil_macro_bias": (all_results.get("oil_macro", {}) or {}).get("bias"),
            "oil_macro_confidence": (all_results.get("oil_macro", {}) or {}).get("confidence"),
        }
        setup_context = _setup_context_payload(decision, all_results)
        decision["setup_context"] = setup_context
        decision["setup_id"] = setup_context.get("id")
        decision["setup_type"] = setup_context.get("setup_type")
        decision["setup_state"] = setup_context.get("setup_state")
        decision["lead_agent"] = setup_context.get("lead_agent")
        decision["setup_quality"] = setup_context.get("quality_grade")
        decision_type = str(decision.get("decision") or "").upper()

        # ── BOOK line (operator 2026-08-17b) ─────────────────────────────
        # One line per cycle stating what the voted book actually was. On
        # 2026-08-17 the 10:06 cycle went completely silent while the
        # diagnostic tool two seconds earlier showed 3 qualified BUY
        # supporters at net 74.7% — with no record of what the production
        # cycle itself saw, that gap was unexplainable from the log alone.
        #
        # safety= (operator 2026-08-17c): the very first BOOK lines exposed
        # the next blind spot. 11:06 read "BUY 3 sup net=73.2% opp=0 |
        # reject=-" yet decision=WAIT — consensus ACCEPTED and a post-vote
        # safety filter (session/news/daily-bias/risk) flipped it. Those
        # filters write their reason into decision["warnings"], which the
        # line did not show, so an accepted-then-vetoed book was again
        # unexplainable. Print the last warning: it is the one appended by
        # whichever filter flipped the signal (they append in veto order).
        try:
            _bk = (decision.get("classic") or {}).get("consensus") or {}
            _bb = _bk.get("BUY") or {}
            _bs = _bk.get("SELL") or {}
            _bw = [str(w) for w in (decision.get("warnings") or []) if str(w).strip()]
            logger.info(
                "BOOK %s: decision=%s | BUY %d sup net=%s%% (%s) opp=%d | "
                "SELL %d sup net=%s%% (%s) opp=%d | reject=%s | safety=%s",
                symbol, decision_type,
                int(_bb.get("support_count") or 0), _bb.get("confidence"),
                ",".join(str(x) for x in (_bb.get("supporters") or [])) or "-",
                int(_bb.get("opposition_count") or 0),
                int(_bs.get("support_count") or 0), _bs.get("confidence"),
                ",".join(str(x) for x in (_bs.get("supporters") or [])) or "-",
                int(_bs.get("opposition_count") or 0),
                (decision.get("classic") or {}).get("rejection_reason") or "-",
                (_bw[-1][:160] if _bw else "-"),
            )
        except Exception:  # noqa: BLE001 - observability must never break the cycle
            logger.debug("BOOK line failed", exc_info=True)


        # ── BUILD 30: PRE-ARM OTE (operator order 2026-08-22, live) ──────
        # A fresh confirmed impulse arms a PENDING order at the PROJECTED
        # OTE retracement BEFORE the pullback arrives: earlier entry in
        # price and time, same conservative gates, zero LLM cost. Fully
        # additive + defensive: on ANY problem the reactive paths below
        # proceed exactly as before. Kill switch: pre_arm_ote.enabled=false.
        try:
            from services import pre_arm_ote as _pre_arm

            _pa_side = _pre_arm.try_pre_arm(
                data=data, all_results=all_results, config=config,
                symbol=symbol,
                open_trades_snapshot=open_trades_snapshot,
                database=database, telegram=telegram,
                current_price=float(data.get("current_price") or 0),
                demo_execution=bool(demo_execution),
                # BUILD 31 R3: PATH 6 reads THIS cycle's finished agent
                # book (same numbers paths 2/3 use) — the two-agent
                # condition + the confirmation chain decide the arm.
                classic_book=decision.get("classic") or {},
            )
            if _pa_side:
                # A pre-armed pending for direction D supplants the
                # reactive D entry this cycle (one pending family per
                # symbol+direction). Opposite-side or WAIT books proceed.
                if decision_type == _pa_side:
                    decision_type = "WAIT"
                    decision["decision"] = "WAIT"
                    decision.setdefault("warnings", []).append(
                        f"pre_arm_ote: {_pa_side} pending armed at the "
                        f"projected OTE; reactive entry suppressed"
                    )
                logger.info(
                    "PRE-ARM OTE active for %s: %s PENDING armed at the "
                    "projected OTE; reactive same-direction entry "
                    "suppressed this cycle", symbol, _pa_side,
                )
        except Exception as exc:  # noqa: BLE001 - never break the cycle
            logger.warning("PRE-ARM OTE stage skipped (non-fatal): %s", exc)

        # ═══════════════════════════════════════════════════════════════════
        # ── Path 2: Two-Agent Entry with External Confirmation ──
        # ═══════════════════════════════════════════════════════════════════
        if decision_type == "WAIT":
            two_agent = (decision.get("classic") or {}).get("two_agent")
            if isinstance(two_agent, dict) and two_agent:
                side = str(two_agent.get("side", "")).upper()
                if side in {"BUY", "SELL"}:
                    tae_cfg = (config.get("signal_requirements") or {}).get("two_agent_entry") or {}
                    cross_pts = int(tae_cfg.get("cross_entry_distance_points", 150) or 150)
                    macro_confirmed = False
                    gemini_confirmed = False
                    auction_confirmed = False
                    confirm_source = None
                    confirm_conf = 0.0

                    # ── Step A: Try Macro Confirmation ──
                    # GOLD ONLY. The macro agent's verdict is literally
                    # BULLISH_GOLD / BEARISH_GOLD — a statement about gold,
                    # not about crude. Early multi-instrument cycles were
                    # being judged against the gold bias (log 2026-08-17:
                    # "Path 2: Macro does NOT confirm BUY (bias=BEARISH_GOLD
                    # ...)" inside the WTI cycle), which mis-scored oil.
                    macro_cfg = tae_cfg.get("macro_confirmation") or {}
                    # R25.7-M1 (operator 2026-08-28): macro judging is a
                    # SYMBOL LIST, not a gold monopoly. The macro agent is a
                    # multi-instrument reader (its own docstring + the live
                    # books: EUR/USD macro 65, WTI macro 74) and its
                    # macro_direction() resolves the cycle symbol with a
                    # symbol-specific context merge. Gold keeps its exact
                    # old behaviour; the FX-4 pairs join when listed.
                    _macro_symbols = {normalize_symbol(x) for x in
                                      (macro_cfg.get("symbols") or ["XAU/USD"])}
                    _macro_applies = normalize_symbol(symbol) in _macro_symbols
                    if macro_cfg.get("enabled", True) and not _macro_applies:
                        logger.info(
                            "Path 2: Macro confirmation skipped for %s — the macro "
                            "bias is a gold verdict and cannot judge this symbol",
                            symbol,
                        )
                    if macro_cfg.get("enabled", True) and _macro_applies:
                        macro_agent = all_results.get("macro_fundamental", {}) or {}
                        macro_dir = macro_agent.get("macro_direction", {}) or {}
                        macro_bias = str(macro_dir.get("bias", "")).upper()
                        macro_conf_val = float(macro_dir.get("confidence", 0) or 0)
                        macro_min = float(macro_cfg.get("min_confidence", 55) or 55)
                        # R26.9.1 (2026-09-01): the agent publishes a
                        # SYMBOL-SUFFIXED verdict (BULLISH_EURUSD,
                        # BEARISH_USDJPY, ...) — the old code compared the
                        # FX bias against plain "BUY"/"SELL", which could
                        # never match, so macro never confirmed an FX trade
                        # on this ladder. Match the pair's own suffixed code
                        # now; gold keeps its historical literal codes.
                        _norm_sym = normalize_symbol(symbol)
                        _sym_tag = _norm_sym.replace("/", "")
                        if _norm_sym == "XAU/USD":
                            expected_bias = "BULLISH_GOLD" if side == "BUY" else "BEARISH_GOLD"
                        else:
                            expected_bias = ("BULLISH_" if side == "BUY" else "BEARISH_") + _sym_tag
                        if macro_bias == expected_bias and macro_conf_val >= macro_min:
                            macro_confirmed = True
                            confirm_source = "macro"
                            confirm_conf = macro_conf_val
                            logger.info(
                                "✅ Path 2: Macro confirms %s (bias=%s, conf=%.0f%% ≥ %.0f%%)",
                                side, macro_bias, macro_conf_val, macro_min
                            )
                        else:
                            logger.info(
                                "Path 2: Macro does NOT confirm %s (bias=%s, need=%s, conf=%.0f%% < %.0f%% or mismatch)",
                                side, macro_bias, expected_bias, macro_conf_val, macro_min
                            )

                    # ── Step A-OIL (R26.9.1): WTI fundamental confirmation ──
                    # The oil_macro_confirmation setting (enabled, 55%) is
                    # honoured by every mirror of this ladder (pre_arm_ote,
                    # thesis_consensus, the planner display card) — but the
                    # DIRECT Path-2 ladder itself, the busiest entry route,
                    # never consulted the oil voice at all: WTI two-agent
                    # books ran with no fundamental word, against the
                    # operator's config promise and the R26.9 single-voice
                    # doctrine. Same routing and thresholds as the mirrors:
                    # direction + confidence >= its own floor, the path
                    # stays 2 and the flags are the macro flags.
                    _oil_cfg = tae_cfg.get("oil_macro_confirmation") or {}
                    if ("WTI" in str(symbol).upper()
                            and not macro_confirmed
                            and bool(_oil_cfg.get("enabled", True))):
                        oil_agent = all_results.get("oil_macro", {}) or {}
                        _oil_dir = str(oil_agent.get("direction") or oil_agent.get("bias") or "").upper()
                        if _oil_dir.startswith("BEARISH"):
                            _oil_dir = "SELL"
                        elif _oil_dir.startswith("BULLISH"):
                            _oil_dir = "BUY"
                        _oil_conf = float(oil_agent.get("confidence", 0) or 0)
                        _oil_min = float(_oil_cfg.get("min_confidence", 55) or 55)
                        if _oil_dir == side and _oil_conf >= _oil_min:
                            macro_confirmed = True
                            confirm_source = "oil_macro"
                            confirm_conf = _oil_conf
                            logger.info(
                                "✅ Path 2: Oil macro confirms %s (direction=%s, conf=%.0f%% ≥ %.0f%%)",
                                side, _oil_dir, _oil_conf, _oil_min
                            )
                        else:
                            logger.info(
                                "Path 2: Oil macro does NOT confirm %s (direction=%s, conf=%.0f%% < %.0f%% or mismatch)",
                                side, _oil_dir, _oil_conf, _oil_min
                            )

                    # ── Step B: Fallback to Gemini Confirmation ──
                    # Rule A (operator 2026-08-17): a FULL all-trend book that
                    # the family gate demoted (>= min_agents supporters, all
                    # trend) accepts only the confirmers listed in
                    # single_family_confirmers (default: macro). Gemini and
                    # auction are skipped for those books unless the operator
                    # widens the config list. Ordinary 2-agent candidates are
                    # untouched by Rule A (Rule B guards their auction step).
                    from services.thesis_consensus import (
                        _all_trend_supporters as _tc_all_trend,
                        _single_family_confirmers as _tc_sfc,
                    )
                    _ta_supporters = list(two_agent.get("supporters") or [])
                    _ta_min_agents = int((config.get("signal_requirements") or {}).get("min_agents_agree", 3) or 3)
                    _fd_on = bool(((config.get("signal_requirements") or {})
                                   .get("family_diversity") or {}).get("enabled", False))
                    _rule_a_book = (_fd_on and len(_ta_supporters) >= _ta_min_agents
                                    and _tc_all_trend(_ta_supporters, config))
                    _allowed_confirmers = _tc_sfc(config) if _rule_a_book else None
                    if _rule_a_book and "gemini" not in (_allowed_confirmers or []):
                        if not macro_confirmed:
                            logger.info(
                                "Rule A: demoted all-trend book (%s) accepts only %s — Gemini skipped",
                                ", ".join(_ta_supporters), ",".join(_allowed_confirmers or []),
                            )
                        gemini_cfg = {"enabled": False}
                    else:
                        gemini_cfg = tae_cfg.get("gemini_confirmation") or {}
                    if not macro_confirmed and gemini_cfg.get("enabled", True):
                        try:
                            gemini_svc = get_gemini_review_service(config)
                            if gemini_svc.enabled:
                                # QUARTER-HOUR THROTTLE (operator 2026-08-18i).
                                # A standing two-agent candidate used to ask
                                # Gemini every 5-minute cycle — 12 times in
                                # one hour on 2026-08-17 for essentially the
                                # same book. The verdict (yes OR no) is now
                                # cached on disk per symbol+side and REUSED
                                # for confirmation_cache_minutes (default 15).
                                # Unavailable results are never cached, so a
                                # transient 503 cannot lock the window.
                                from services.gemini_confirm_cache import (
                                    load_confirmation, store_confirmation,
                                )
                                _g_ttl = _safe_float(
                                    (config.get("llm_review") or {}).get("confirmation_cache_minutes"), 15.0)
                                _atr_sig = _safe_float(((all_results.get("technical") or {}).get("atr")), 0.0)
                                _vol_inv = _safe_float((config.get("llm_review") or {}).get("cache_vol_invalidation_pct"), 25.0)
                                gemini_review = load_confirmation(symbol, side, max_age_minutes=_g_ttl, vol_signature=_atr_sig if _atr_sig > 0 else None, vol_invalidation_pct=_vol_inv)
                                if gemini_review is not None:
                                    logger.info(
                                        "Path 3: Gemini verdict reused from cache (age %.1f min < %.0f)",
                                        _safe_float(gemini_review.get("_cache_age_minutes")), _g_ttl,
                                    )
                                else:
                                    gemini_review = gemini_svc.review_signal({
                                        "symbol": symbol,
                                        "decision": decision,
                                        "all_results": all_results
                                    })
                                    if isinstance(gemini_review, dict) and _atr_sig > 0:
                                        gemini_review = dict(gemini_review)
                                        gemini_review["_vol_signature_hint"] = _atr_sig
                                    store_confirmation(symbol, side, gemini_review)
                                g_verdict = str(gemini_review.get("verdict", "")).upper()
                                g_conf_val = float(gemini_review.get("confidence", 0) or 0)
                                g_min = float(gemini_cfg.get("min_confidence", 70) or 70)
                                if g_verdict == side and g_conf_val >= g_min:
                                    gemini_confirmed = True
                                    confirm_source = "gemini"
                                    confirm_conf = g_conf_val
                                    logger.info(
                                        "✅ Path 2: Gemini confirms %s (verdict=%s, conf=%.0f%% ≥ %.0f%%)",
                                        side, g_verdict, g_conf_val, g_min
                                    )
                                    decision["gemini_review"] = gemini_review
                                else:
                                    logger.info(
                                        "❌ Path 2: Gemini does NOT confirm (verdict=%s vs %s, conf=%.0f%% < %.0f%%)",
                                        g_verdict, side, g_conf_val, g_min
                                    )
                            else:
                                logger.info("Path 2: Gemini skipped — API key not configured")
                        except Exception as _g_exc:
                            logger.warning("Path 2: Gemini confirmation failed: %s", _g_exc)

                    # ── Step C: Fallback to Auction Flow Confirmation (Path 5) ──
                    # Operator 2026-08-14: the standalone Auction Flow agent is
                    # the third external confirmer. Same shape as Macro/Gemini:
                    # same direction, at or above its own confidence floor.
                    path5_cfg = (config.get("signal_requirements") or {}).get("path5_two_agent_auction") or {}
                    # Rule B (operator 2026-08-17): auction never confirms an
                    # all-trend pair. Flow strength at a momentum extreme IS
                    # the move the trend agents voted on — the replay measured
                    # auction rescues of pure-trend books at 0/4. A pair with
                    # a structure agent (smc/price_action) keeps Path 5 open.
                    _p5_pair_ok = True
                    if (bool(path5_cfg.get("require_family_diversity", True))
                            and bool(((config.get("signal_requirements") or {})
                                      .get("family_diversity") or {}).get("enabled", False))):
                        from services.thesis_consensus import _all_trend_supporters
                        _p5_pair_ok = not _all_trend_supporters(
                            list(two_agent.get("supporters") or []), config)
                    if (not macro_confirmed and not gemini_confirmed
                            and bool(path5_cfg.get("enabled", False))
                            and not _p5_pair_ok):
                        logger.info(
                            "Path 5 refused for %s: both supporters (%s) are trend "
                            "family — auction cannot confirm momentum with momentum",
                            side, ", ".join(str(x) for x in (two_agent.get("supporters") or [])),
                        )
                    if (not macro_confirmed and not gemini_confirmed
                            and bool(path5_cfg.get("enabled", False))
                            and _p5_pair_ok):
                        auction_result = all_results.get("auction_flow", {}) or {}
                        a_side = str(auction_result.get("signal") or auction_result.get("direction") or "WAIT").upper()
                        a_conf = float(auction_result.get("confidence", 0) or 0)
                        a_min = float(path5_cfg.get("min_auction_confidence", 72) or 72)
                        if a_side == side and a_conf >= a_min:
                            auction_confirmed = True
                            confirm_source = "auction"
                            confirm_conf = a_conf
                            logger.info(
                                "✅ Path 5: Auction Flow confirms %s (signal=%s, conf=%.0f%% ≥ %.0f%%)",
                                side, a_side, a_conf, a_min,
                            )
                        else:
                            logger.info(
                                "Path 5: Auction Flow does NOT confirm %s (signal=%s, conf=%.0f%% < %.0f%% or mismatch)",
                                side, a_side, a_conf, a_min,
                            )

                    # ── The risk agent's verdict is not advisory ──
                    #
                    # This path rebuilt the signal straight out of
                    # ``all_results["risk"]`` -- its entry, its stop, its
                    # targets -- while ignoring the one field that says
                    # whether that plan is tradeable at all. So a setup the
                    # risk agent had already refused was published as a live
                    # pending order, carrying the refused numbers.
                    #
                    # 2026-08-03 16:11, TRADE_..._d0c708d9: SELL 4045.99 with
                    # a 398-point stop. ``rr_filter`` was False (no mapped
                    # level pays for that stop) and ``trade_grade_filter`` was
                    # False, so ``approved`` was False. The card went out
                    # anyway as "SELL LIMIT ... Status: Pending order".
                    #
                    # Every other execution route honours this flag; the
                    # scale-in path checks it at line ~2552. This one did not,
                    # which made the whole risk layer optional on the busiest
                    # path in the system.
                    #
                    # Refusing here costs nothing that was ever legitimate: if
                    # the plan clears the risk agent, ``approved`` is True and
                    # the branch runs exactly as before.
                    if (macro_confirmed or gemini_confirmed or auction_confirmed) and not (
                        all_results.get("risk", {}) or {}
                    ).get("approved", True):
                        _risk = all_results.get("risk", {}) or {}
                        _failed = [
                            name for name, ok in
                            ((_risk.get("risk_metrics") or {}).get("checks") or {}).items()
                            if not ok
                        ]
                        logger.info(
                            "❌ Path 2 blocked: risk agent refused this plan (%s; failed: %s)",
                            _risk.get("rejection_reason") or "not approved",
                            ", ".join(_failed) or "unspecified",
                        )
                        macro_confirmed = False
                        gemini_confirmed = False
                        auction_confirmed = False

                    # ── If confirmed → rebuild signal payload and finalize entry ──
                    if macro_confirmed or gemini_confirmed or auction_confirmed:
                        risk = all_results.get("risk", {}) or {}
                        current_price = all_results.get("current_price")
                        entry_info = risk.get("entry", {}) or {}
                        entry_zone = entry_info.get("zone", {}) or {}
                        sl = risk.get("stop_loss", {}) or {}
                        tp = risk.get("take_profit", {}) or {}
                        tp1 = tp.get("tp1", {}) or {}
                        tp2 = tp.get("tp2", {}) or {}
                        entry_price = entry_info.get("price") or current_price
                        order_type = entry_info.get("order_type") or f"{side}_MARKET"
                        entry_kind = entry_info.get("kind") or "MARKET"

                        # Rebuild signal payload
                        decision["decision"] = side
                        decision["confidence"] = float(two_agent.get("confidence", 0))
                        decision["signal"] = {
                            "type": side,
                            "entry": {
                                "price": entry_price,
                                "low": entry_zone.get("low", entry_price),
                                "high": entry_zone.get("high", entry_price),
                                "kind": entry_kind,
                                "order_type": order_type,
                                "basis": entry_info.get("basis", ""),
                                "current_price": entry_info.get("current_price", current_price),
                                "distance_points": entry_info.get("distance_points", 0.0),
                            },
                            "stop_loss": sl.get("price", 0),
                            "tp1": tp1.get("price", 0),
                            "tp2": tp2.get("price", 0),
                            "tp1_rr": tp1.get("rr_ratio", 0),
                            "tp2_rr": tp2.get("rr_ratio", 0),
                            "rr_ratio": tp2.get("rr_ratio", tp1.get("rr_ratio", 0)),
                            "order_type": order_type,
                            "entry_kind": entry_kind,
                            "position_size": risk.get("position_size", {}),
                            "risk_summary": risk.get("summary", ""),
                        }
                        # RECORD THE PRE-FLOOR STOP SO IT CAN BE AUDITED.
                        #
                        # `analyze_sl_floor` answers the only question that
                        # decides whether the noise floor earns its keep:
                        # would the structural stop have survived? It reads
                        # that stop from `signal_snapshot.session_plan`, which
                        # only the planner path writes.
                        #
                        # Every consensus and dual-agent trade therefore fell
                        # into `no_structural_stop` and was silently excluded
                        # -- including 36e5cc8a, the exact trade that raised
                        # the question. The measurement would have covered the
                        # minority path and reported it as the whole picture.
                        #
                        # The risk agent already computes this; it just was
                        # never persisted on this route.
                        _rm = (risk.get("risk_metrics") or {})
                        decision["risk_geometry"] = {
                            "structural_sl_points": _rm.get("structural_sl_points"),
                            "shipped_sl_points": sl.get("distance_points"),
                            "floor_points": _rm.get("min_sl_distance_points"),
                            "target_method": _rm.get("target_method"),
                            "sl_method": sl.get("method"),
                        }
                        decision["entry_mode"] = f"two_agent_{confirm_source}"
                        decision["entry_path"] = 5 if confirm_source == "auction" else 2
                        decision["confirm_source"] = confirm_source
                        decision["confirm_confidence"] = confirm_conf
                        existing_reasons = list(decision.get("reasons", []))
                        existing_reasons.append(
                            f"Two-agent entry: {side} confirmed by {confirm_source} ({confirm_conf:.0f}%)"
                        )
                        decision["reasons"] = existing_reasons

                        # Check cross-path distance BEFORE proceeding
                        cross_reason = _cross_path_distance_check(
                            decision, database, config, cross_distance_points=cross_pts
                        )
                        if cross_reason:
                            logger.info("❌ Path 2 blocked by cross-path distance: %s", cross_reason)
                            decision["decision"] = "WAIT"
                            decision["signal"] = {}
                            decision["entry_mode"] = "wait"
                            decision["entry_path"] = 0
                            decision_type = "WAIT"
                        else:
                            decision_type = side  # Set for downstream flow
                            logger.info(
                                "✅ Path 2 entry confirmed: %s via %s (2-agent conf=%.0f%%, %s conf=%.0f%%)",
                                side, confirm_source,
                                float(two_agent.get("confidence", 0)),
                                confirm_source, confirm_conf
                            )

        # ═══════════════════════════════════════════════════════════════
        # ── PATH 9: LIQUIDITY SWEEP RAID REVERSAL (R25.8, operator order) ──
        # A raid of a major pool (PDH/PDL, session extreme, swing) rejected
        # back inside with responsive flow + an M5 reversal candle. It is a
        # pure evaluator (services/path9_reversal) that obeys the single-source
        # stop band + target law and still passes R24-0 risk supremacy. It is
        # evaluated when the main book is WAIT (a fade against the last move),
        # and like the scalp/pre-arm it never breaks the cycle. Kill switch:
        # config.path9_reversal.enabled=false.
        try:
            if decision_type not in {"BUY", "SELL"}:
                _p9 = _evaluate_path9_reversal(data, all_results, config, symbol)
                if _p9 is not None and isinstance(all_results.get("path9_decision"), dict):
                    _p9d = all_results["path9_decision"]
                    decision["decision"] = _p9
                    decision["confidence"] = _p9d.get("confidence", 70.0)
                    decision["signal"] = _p9d.get("signal", {})
                    decision["current_price"] = _p9d.get("current_price")
                    decision["entry_mode"] = _p9d.get("entry_mode")
                    decision["reasons"] = list(decision.get("reasons", [])) + list(_p9d.get("reasons", []))
                    decision["path9"] = (_p9d.get("signal", {}) or {}).get("path9", {})
                    decision["warnings"] = list(decision.get("warnings", []))
                    # Carry the stamped PATH-9 admission + reversal context so
                    # the generic stamp leaves it and the flip authority reads
                    # a genuine rejection-confirmed reversal thesis.
                    for _k in ("execution_path_id", "execution_path",
                               "execution_path_number", "execution_path_name",
                               "entry_path", "setup_context", "lead_agent"):
                        if _k in _p9d:
                            decision[_k] = _p9d[_k]
                    decision_type = _p9
        except Exception as _p9_exc:  # noqa: BLE001 — path 9 never breaks the cycle
            logger.warning("PATH 9 sweep-reversal stage skipped (non-fatal): %s", _p9_exc)

        # Stamp admission provenance before any Telegram/save/adaptive branch.
        # Planner legs are re-stamped from their exact shared gate later.
        if decision_type in {"BUY", "SELL"}:
            # R25.8 (2026-08-29): PATH 9 reborn as LIQUIDITY SWEEP RAID
            # REVERSAL; it carries its own stamped admission (set when the
            # reversal decision was built), so leave a stamped path alone.
            if str(decision.get("execution_path_id") or "") == "PATH_9_LIQUIDITY_SWEEP_REVERSAL":
                pass
            # R25.7-C (2026-08-28, operator order): the old FX-4 lane is
            # RETIRED - the seven base paths (1,2,3,4,5,6,7) admit every
            # instrument including the forex four (macro included since
            # R25.7-M1), so no dedicated forex lane survives.
            # R26.9.1: oil_macro is the oil voice of the SAME macro step
            # (Step A-OIL) — a WTI two-agent entry confirmed by the oil
            # macro is still PATH 2 — TWO-AGENT + MACRO.
            if str(decision.get("confirm_source") or "").lower() in {"macro", "oil_macro"}:
                stamp_execution_path(decision, "TWO_AGENT_MACRO")
            elif str(decision.get("confirm_source") or "").lower() == "gemini":
                stamp_execution_path(decision, "TWO_AGENT_GEMINI")
            elif str(decision.get("confirm_source") or "").lower() == "auction":
                stamp_execution_path(decision, "TWO_AGENT_AUCTION")
            else:
                # R26.9.3 (2026-09-01): PATH 1 is DISABLED in production
                # (three_agent_entry.enabled=false, data decision
                # 2026-08-19). This fallback used to stamp
                # THREE_AGENT_CONSENSUS on ANY confirmed decision without a
                # two-agent confirmer — the ledger carries a USD/JPY row
                # stamped PATH_1 on 2026-08-30, eleven days after the path
                # was retired, corrupting the per-path scorecards. A row
                # that cannot prove its route is now left UNSTAMPED: cards
                # resolve it as "NOT RECORDED" and the post-decision
                # auditor raises PATH_MISSING — honest reporting instead of
                # borrowing a dead path's name. With the path re-enabled
                # the historical label returns unchanged.
                _three_enabled = bool(
                    ((config.get("signal_requirements") or {})
                     .get("three_agent_entry") or {}).get("enabled", True))
                if _three_enabled:
                    stamp_execution_path(decision, "THREE_AGENT_CONSENSUS")

        # Phase D: a confirmed day-map authority must not be overridden by a
        # weak local opposite-direction idea. Only high-authority reversal /
        # regime-flip setups may challenge the day map.
        if decision_type in {"BUY", "SELL"}:
            authority_review = DirectionalAuthorityService(config).review(
                decision,
                all_results.get("session_plan", {}) or {},
                [t for t in open_trades_snapshot if normalize_symbol(t.get("symbol") or symbol) == normalized_symbol],
            )
            decision["directional_authority"] = authority_review
            action = str(authority_review.get("action") or "ALLOW")
            if action == "BLOCK_OPPOSITE_LOCAL":
                logger.info("Directional authority blocked %s for %s: %s", decision_type, symbol, authority_review.get("reason"))
                decision["warnings"] = list(decision.get("warnings", [])) + [str(authority_review.get("reason") or "Directional authority blocked")]
                decision["decision"] = "WAIT"
                decision["signal"] = {}
                decision_type = "WAIT"
            elif action == "ALLOW_REGIME_FLIP":
                logger.info("Directional authority allowed regime flip %s for %s: %s", decision_type, symbol, authority_review.get("reason"))
                decision.setdefault("reasons", []).append(str(authority_review.get("reason") or "Directional authority allowed regime flip"))
            elif action == "ALLOW_MAP_RETIRED":
                # The live book has outvoted a map that no longer describes
                # it. Write the verdict onto the plan before anything else
                # reads it: DayMapSanityService refuses any side that
                # disagrees with a CONFIRMED map, so leaving the old stamp in
                # place would block this same signal one gate later, and the
                # retirement would be an announcement with no effect.
                logger.info(
                    "Directional authority retired the %s day map for %s: %s",
                    authority_review.get("authority_direction"), symbol,
                    authority_review.get("reason"),
                )
                for _plan_ref in (
                    all_results.get("session_plan"),
                    decision.get("session_plan"),
                ):
                    DirectionalAuthorityService.apply_retirement(_plan_ref, authority_review)
                decision.setdefault("reasons", []).append(str(authority_review.get("reason") or "Day map retired by the live agent book"))

        send_hourly_now = should_send_hourly_status(config)
        # Arm as soon as the cycle has a decision: every later exit is covered
        # by the flush in `finally`, whatever branch it takes.
        if send_hourly_now:
            status_delivery.arm(decision=decision, all_results=all_results, database=database)
        session_plan_ready_for_delivery = bool((all_results.get("session_plan") or {}).get("plan_ready")) and bool(_session_plan_delivery_cfg(config).get("enabled", True))
        # GEMINI HAS ONE CONSUMING JOB (operator 2026-08-18i): confirming a
        # two-agent entry candidate — throttled to one API ask per quarter
        # hour in Step B above. The display reviews that used to run here
        # (hourly WAIT market-context + news + macro reviews, and the
        # post-decision documentation reviews) burned 3-4 calls per hour
        # for words no gate ever read; on 2026-08-18 01:21 the daily quota
        # (RPD) was exhausted before the London session opened. All of them
        # are retired. The ONLY survivor is the post-news briefing after a
        # TIER_1/TIER_2 release: rare (2-4/day), subscriber-facing, and most
        # valuable exactly when a position is open through the event.
        try:
            gemini = get_gemini_review_service(config)
            if gemini.enabled:
                _check_and_send_post_news(
                    gemini=gemini, telegram=telegram,
                    news_result=all_results.get("news", {}),
                    symbol=symbol,
                    current_price=data.get("current_price"),
                    config=config,
                    database=database,
                )
        except Exception:
            logger.exception("🧠 Gemini post-news block failed")

        if session_plan_delivery_meta.get("send"):
            try:
                plan_message = _decorate_session_plan_for_delivery(
                    all_results.get("session_plan") or {},
                    decision,
                    all_results,
                    {
                        "message_kind": session_plan_delivery_meta.get("kind"),
                        "delivery_reason": session_plan_delivery_meta.get("reason"),
                    },
                    config,
                )
                enforce_shared_delivery = bool((config.get("shared_market_data") or {}).get("enabled", False))
                admission_allowed = bool((plan_message.get("execution_admission") or {}).get("allow"))
                book_consistent = bool((plan_message.get("agent_book_summary") or {}).get("matches_execution_admission"))
                monitoring_gate = _monitoring_map_delivery_gate(plan_message, config)
                if enforce_shared_delivery and not book_consistent:
                    logger.info(
                        "Session plan Telegram suppressed: rendered book differs from shared admission"
                    )
                    sent = False
                elif enforce_shared_delivery and not admission_allowed and monitoring_gate.get("allow"):
                    plan_message["monitoring_only"] = True
                    plan_message.setdefault("delivery_context", {})["monitoring_only"] = True
                    plan_message["delivery_context"]["message_kind"] = "WATCH_MAP"
                    plan_message["delivery_context"]["delivery_reason"] = "two_agent_monitoring_map"
                    plan_message["monitoring_gate"] = monitoring_gate
                    logger.info("Sending monitoring-only map: %s", monitoring_gate.get("reason"))
                    sent = telegram.send_session_plan(plan_message)
                elif enforce_shared_delivery and not admission_allowed:
                    logger.info(
                        "Session plan Telegram suppressed: admission=%s monitoring=%s reason=%s",
                        admission_allowed,
                        monitoring_gate.get("reason"),
                        (plan_message.get("execution_admission") or {}).get("reason"),
                    )
                    sent = False
                else:
                    sent = telegram.send_session_plan(plan_message)
                if sent:
                    if session_plan_snapshot_id:
                        try:
                            database.mark_session_plan_telegram_sent(session_plan_snapshot_id, str(session_plan_delivery_meta.get("reason") or session_plan_delivery_meta.get("kind") or "session_plan_delivery"))
                            database.merge_session_plan_payload(
                                session_plan_snapshot_id,
                                {
                                    "execution_audit": {
                                        "delivery_sent": True,
                                        "delivery_sent_reason": session_plan_delivery_meta.get("reason"),
                                        "delivery_class": (
                                            "MONITORING_ONLY" if plan_message.get("monitoring_only")
                                            else "EXECUTION_ADMITTED"
                                        ),
                                    }
                                },
                            )
                        except Exception as mark_exc:  # noqa: BLE001
                            logger.warning("Failed to mark session plan Telegram delivery: %s", mark_exc)
                    logger.info("Session plan Telegram sent for %s (%s)", symbol, session_plan_delivery_meta.get("reason"))
                else:
                    logger.warning("Session plan Telegram returned False for %s", symbol)
            except Exception as delivery_exc:  # noqa: BLE001
                logger.warning("Failed to deliver session plan Telegram for %s: %s", symbol, delivery_exc)

        # ── AGENT WATCH card (operator 2026-08-17) ──────────────────────────
        # The WATCH_MAP card above requires a structurally READY SMC map, so
        # a strong two-agent book with NO qualifying map was invisible: on
        # 2026-08-17 09:46 the book read technical BUY 71 + multitimeframe
        # BUY 92 (net 80%, zero opposition) while the map was refused on
        # quality 59 < 70 — and Telegram stayed silent. This display-only
        # card covers exactly that gap. It fires when:
        #   * the cycle decided WAIT (no execution path fired), and
        #   * >= 2 qualified core agents agree at net >= the consensus floor
        #     with <= 1 qualified opponent, and
        #   * NO ready session plan exists (otherwise WATCH_MAP owns it).
        # It creates no orders, no trades, no plan rows — words only.
        #
        # THROTTLE (operator 2026-08-17b): send on CHANGE, not persistence.
        # The card re-announced the same state every 5-minute cycle (six
        # near-identical cards 10:01-11:01) because the telegram dedup
        # window (180s) is shorter than the cycle (300s) and the body
        # mutates a little each time. services/agent_watch_throttle.py now
        # decides: NEW / FLIP / SUPPORTERS / CONFIDENCE / hourly REMINDER —
        # and clears the state when the book stops qualifying, so the next
        # appearance is NEW again.
        try:
            from services.agent_watch_throttle import (
                decide as _aw_decide, load_states as _aw_load,
                save_states as _aw_save, should_clear as _aw_should_clear,
                state_path as _aw_path, throttle_config as _aw_cfg,
            )
            watch_cfg_aw = _session_plan_delivery_cfg(config).get("monitoring_only") or {}
            _aw_states_path = _aw_path()
            _aw_states = _aw_load(_aw_states_path)
            _aw_key = normalize_symbol(symbol)
            if (decision_type == "WAIT"
                    and bool(watch_cfg_aw.get("agent_watch_enabled", True))
                    and not bool((all_results.get("session_plan") or {}).get("plan_ready"))):
                _aw_details = _compact_agent_details(all_results)
                _aw_best = None
                for _aw_side in ("BUY", "SELL"):
                    _aw = evaluate_directional_admission(_aw_side, _aw_details, config)
                    if _aw.get("allow"):
                        _aw_best = None  # an allowed side is handled elsewhere
                        break
                    _aw_net_floor = _safe_float(
                        (config.get("signal_requirements") or {}).get("min_consensus_confidence"), 65.0)
                    if (int(_aw.get("support_count") or 0) >= 2
                            and _safe_float(_aw.get("confidence")) >= _aw_net_floor
                            and int(_aw.get("opposition_count") or 0) <= 1):
                        if _aw_best is None or _safe_float(_aw.get("confidence")) > _safe_float(_aw_best.get("confidence")):
                            _aw_best = _aw
                if _aw_best:
                    _aw_side = str(_aw_best.get("target_side"))
                    _aw_supp_list = [str(x) for x in (_aw_best.get("supporters") or [])]
                    _aw_supp = ", ".join(_aw_supp_list)
                    _aw_conf = _safe_float(_aw_best.get("confidence"))
                    _aw_verdict = _aw_decide(
                        _aw_states.get(_aw_key),
                        side=_aw_side, supporters=_aw_supp_list,
                        confidence=_aw_conf, cfg=_aw_cfg(config),
                    )
                    if _aw_verdict["send"]:
                        _aw_kind = str(_aw_verdict.get("kind") or "NEW")
                        if _aw_kind == "REMINDER":
                            import datetime as _aw_dt
                            _aw_since = _aw_dt.datetime.fromtimestamp(
                                float((_aw_states.get(_aw_key) or {}).get("first_seen") or 0),
                                tz=timezone.utc).strftime("%H:%M")
                            telegram.send_message(
                                "\U0001F440 " + _aw_side + " watch still standing on "
                                + html.escape(symbol) + " \u2014 net "
                                + f"{_aw_conf:.0f}% (" + html.escape(_aw_supp)
                                + ") since " + _aw_since + " UTC")
                        else:
                            _aw_plan_reason = str((all_results.get("session_plan") or {}).get("plan_reason") or "no ready map")
                            _aw_tag = {"NEW": "", "FLIP": " \u00b7 REVERSED",
                                       "SUPPORTERS": " \u00b7 NEW LINE-UP",
                                       "CONFIDENCE": " \u00b7 SHIFT"}.get(_aw_kind, "")
                            # Say WHY this book is blocked, from the real
                            # admission verdict. The static "needs a 3rd
                            # agent or Macro/Gemini/Auction" line predates
                            # the family gate and misread its first live
                            # case (2026-08-17 21:4x): a 3-agent all-trend
                            # book that only macro may rescue (Rule A).
                            if _aw_best.get("family_diversity_blocked"):
                                from services.thesis_consensus import _single_family_confirmers as _aw_sfc
                                _aw_conf_names = list(_aw_sfc(config))
                                # Macro is a GOLD verdict (BULLISH_GOLD /
                                # BEARISH_GOLD) and never judges other
                                # symbols — a WTI card promising "macro
                                # confirmation" advertised a door that does
                                # not exist for oil (live, 2026-08-17 22:31).
                                if normalize_symbol(symbol) != "XAU/USD" and "macro" in _aw_conf_names:
                                    _aw_conf_names.remove("macro")
                                _aw_conf_list = ",".join(_aw_conf_names)
                                _aw_blocked_line = (
                                    "\u251c Blocked: all supporters are one family \u2014 needs a structure agent"
                                    + (" or " + html.escape(_aw_conf_list) + " confirmation (Rule A)"
                                       if _aw_conf_list else
                                       " (Rule A; macro does not judge this symbol)"))
                            else:
                                _aw_blocked_line = ("\u251c Blocked from execution: needs a 3rd agent "
                                                    "or Macro/Gemini/Auction confirmation")
                            _aw_lines = [
                                "\U0001F440 <b>AGENT WATCH \u2014 " + html.escape(symbol) + "</b>" + _aw_tag,
                                "\u250c " + _aw_side + " book: "
                                + str(int(_aw_best.get("support_count") or 0))
                                + " qualified agents (" + html.escape(_aw_supp) + ")",
                                "\u251c Net confidence: "
                                + f"{_aw_conf:.1f}% \u00b7 opposition "
                                + str(int(_aw_best.get("opposition_count") or 0)),
                                _aw_blocked_line,
                                "\u2514 Map status: " + html.escape(_aw_plan_reason[:140]),
                                "\u26a0\ufe0f Display only \u2014 no order, no map, no levels.",
                            ]
                            telegram.send_message("\n".join(_aw_lines))
                        logger.info("AGENT WATCH card sent (%s): %s net=%.1f supporters=%s",
                                    _aw_kind, _aw_side, _aw_conf, _aw_supp)
                    else:
                        logger.info("AGENT WATCH suppressed (unchanged): %s net=%.1f supporters=%s",
                                    _aw_side, _aw_conf, _aw_supp)
                    _aw_states[_aw_key] = _aw_verdict["state"]
                    _aw_save(_aw_states_path, _aw_states)
                elif _aw_key in _aw_states:
                    # The book no longer qualifies. Do NOT forget instantly:
                    # a book hovering around the 65 bar de-qualifies for one
                    # cycle and returns the next, and instant clearing made
                    # every return a NEW card (live: WTI cleared 22:01, NEW
                    # 22:21, cleared 22:26, NEW 22:31). The state survives a
                    # grace window; returns inside it are continuations.
                    if _aw_should_clear(_aw_states.get(_aw_key), _aw_cfg(config)):
                        _aw_states.pop(_aw_key, None)
                        _aw_save(_aw_states_path, _aw_states)
                        logger.info("AGENT WATCH state cleared for %s (book no longer qualifies, grace expired)", symbol)
                    else:
                        logger.info("AGENT WATCH state kept for %s (de-qualified, inside grace window)", symbol)
            elif _aw_key in _aw_states:
                # Cycle is not a candidate at all (trade opened / plan ready /
                # feature off): the standing watch is over. Same grace logic —
                # a plan flickering in and out must not reset the watch story.
                if _aw_should_clear(_aw_states.get(_aw_key), _aw_cfg(config)):
                    _aw_states.pop(_aw_key, None)
                    _aw_save(_aw_states_path, _aw_states)
                    logger.info("AGENT WATCH state cleared for %s (cycle not a watch candidate, grace expired)", symbol)
        except Exception:  # noqa: BLE001 - a display card must never break the cycle
            logger.exception("AGENT WATCH card failed (cycle unaffected)")

        # ── ARMED MAP card (operator 2026-08-19) ────────────────────────────
        # The 4399 post-mortem: the repaired SMC agent maps the manual
        # analyst's trade AT the raid (replay: SELL LIQUIDITY_REVERSAL
        # 4396.5, quality 76 / dominance 92 / return 79 / trigger 87
        # REJECTION_CONFIRMED) — clearing every Path-4 floor except the
        # auction read. Such a map used to die in total silence; the
        # operator saw the losing adds but never the winning map. This
        # display-only card fires when a Path-4-grade map is waiting on
        # auction ALONE, throttled on change like AGENT WATCH.
        try:
            from services.armed_map_watch import (
                armed_map_review, decide_card as _am_decide,
                load_states as _am_load, save_states as _am_save,
                should_clear as _am_should_clear, state_path as _am_path,
                watch_config as _am_cfg,
            )
            _am_conf = _am_cfg(config)
            if bool(_am_conf.get("enabled", True)):
                _am_states_path = _am_path()
                _am_states = _am_load(_am_states_path)
                _am_key = normalize_symbol(symbol)
                _smc_res = all_results.get("smc") or {}
                _am_candidate = None
                for _c in (_smc_res.get("setup_candidates") or []):
                    if isinstance(_c, dict):
                        _rv = armed_map_review(
                            _c, all_results.get("auction_flow"),
                            int((evaluate_directional_admission(
                                str(_c.get("direction") or "").upper(),
                                _compact_agent_details(all_results), config)
                                ).get("opposition_count") or 0),
                            config)
                        if _rv.get("armed"):
                            _am_candidate = _rv
                            break
                if _am_candidate and decision_type == "WAIT":
                    _am_verdict = _am_decide(_am_states.get(_am_key), _am_candidate, _am_conf)
                    if _am_verdict["send"]:
                        _am_kind = str(_am_verdict.get("kind") or "NEW")
                        _am_tag = {"NEW": "", "FLIP": " \u00b7 REVERSED",
                                   "MOVED": " \u00b7 LEVEL MOVED"}.get(_am_kind, "")
                        if _am_kind == "REMINDER":
                            telegram.send_message(
                                "\U0001F5FA " + str(_am_candidate.get("direction")) + " map still armed on "
                                + html.escape(symbol) + " @ "
                                + f"{_safe_float(_am_candidate.get('entry_price')):.2f}"
                                + " \u2014 auction now " + html.escape(str(_am_candidate.get("auction_now"))))
                        else:
                            _am_lines = [
                                "\U0001F5FA <b>ARMED MAP \u2014 " + html.escape(symbol) + "</b>" + _am_tag,
                                "\u250c " + str(_am_candidate.get("direction")) + " "
                                + html.escape(str(_am_candidate.get("setup_type") or "map"))
                                + " @ " + f"{_safe_float(_am_candidate.get('entry_price')):.2f}"
                                + " \u00b7 stop " + f"{_safe_float(_am_candidate.get('stop_loss')):.2f}",
                                "\u251c Path-4 floors PASSED: quality "
                                + f"{_safe_float(_am_candidate.get('quality')):.0f}"
                                + " \u00b7 dominance " + f"{_safe_float(_am_candidate.get('dominance')):.0f}"
                                + " \u00b7 return " + f"{_safe_float(_am_candidate.get('return_probability')):.0f}"
                                + " \u00b7 trigger " + f"{_safe_float(_am_candidate.get('trigger_score')):.0f}",
                                "\u251c Waiting on ONE witness: auction now "
                                + html.escape(str(_am_candidate.get("auction_now")))
                                + " \u2014 needs " + html.escape(str(_am_candidate.get("auction_needed"))),
                                "\u2514 If flow confirms, Path 4 places a LIMIT at the POI automatically.",
                                "\u26a0\ufe0f Display only \u2014 no order until the auction witness signs.",
                            ]
                            telegram.send_message("\n".join(_am_lines))
                        logger.info("ARMED MAP card sent (%s): %s @ %.2f auction=%s",
                                    _am_kind, _am_candidate.get("direction"),
                                    _safe_float(_am_candidate.get("entry_price")),
                                    _am_candidate.get("auction_now"))
                    else:
                        logger.info("ARMED MAP suppressed (unchanged): %s @ %.2f",
                                    _am_candidate.get("direction"),
                                    _safe_float(_am_candidate.get("entry_price")))
                    _am_states[_am_key] = _am_verdict["state"]
                    _am_save(_am_states_path, _am_states)
                elif _am_key in _am_states:
                    if _am_should_clear(_am_states.get(_am_key), _am_conf):
                        _am_states.pop(_am_key, None)
                        _am_save(_am_states_path, _am_states)
                        logger.info("ARMED MAP state cleared for %s (no armed map, grace expired)", symbol)
        except Exception:  # noqa: BLE001 - a display card must never break the cycle
            logger.exception("ARMED MAP card failed (cycle unaffected)")

        # Dynamic risk is the account-level circuit breaker: it halts trading
        # after a losing streak, after the daily loss limit is spent, and
        # raises the confidence/quality bar in between. Its verdict was being
        # computed into all_results and then never read, so none of those
        # protections actually stopped anything -- the system kept opening
        # trades no matter how much it had just lost.
        #
        # The check sits here, ahead of BOTH execution routes (planner ladder
        # and the direct BUY/SELL path), because a halt must apply to every
        # way an order can be created, not just the one that happens to run.
        #
        # The ladder builds its legs from the plan's session_bias rather than
        # from decision_type, so it can place orders on a cycle that reads
        # WAIT. Gating on decision_type alone would leave that route open
        # during a halt, which is precisely the path that fired yesterday.
        dynamic_block = _dynamic_risk_block_for_cycle(
            decision_type=decision_type,
            decision=decision,
            session_plan=all_results.get("session_plan") or {},
            dynamic_risk=all_results.get("dynamic_risk", {}) or {},
        )
        if dynamic_block:
            logger.info(
                "Dynamic risk blocked %s for %s: %s",
                decision_type, symbol, dynamic_block,
            )
            decision["dynamic_risk_block"] = dynamic_block
            _notify_blocked_directional_signal(
                telegram=telegram, decision=decision, all_results=all_results,
                database=database, config=config, send_hourly_now=send_hourly_now,
                delivery=status_delivery,
                stage="dynamic risk", reason=dynamic_block,
            )
            return

        # Phase 2: if the morning/session planner already prepared a strong
        # PRIMARY / STANDBY thesis before the move, publish those pending ladder
        # orders now instead of waiting for a late one-off signal after price has
        # already traveled.
        planner_gate_preview = _planner_execution_gate(decision, config) if isinstance((all_results.get("session_plan") or {}), dict) and (all_results.get("session_plan") or {}).get("plan_ready") else None
        ladder_created = _execute_session_plan_ladder(
            decision,
            all_results,
            [t for t in open_trades_snapshot if normalize_symbol(t.get("symbol") or symbol) == normalized_symbol],
            database,
            telegram,
            config,
            demo_execution=demo_execution,
        )
        if session_plan_snapshot_id and planner_gate_preview:
            try:
                database.merge_session_plan_payload(
                    session_plan_snapshot_id,
                    {
                        "execution_audit": {
                            "planner_gate_allow": bool(planner_gate_preview.get("allow")),
                            "planner_gate_kind": planner_gate_preview.get("kind"),
                            "planner_gate_reason": planner_gate_preview.get("reason"),
                            "ladder_created": int(ladder_created or 0),
                            # The gate verdict alone was not enough. On
                            # 2026-08-04, 9 of 20 maps that produced no order
                            # carried a gate reason that reads as a PASS --
                            # "3 qualified agents aligned with the mapped
                            # direction" -- because the gate had allowed them
                            # and a LATER check stopped the ladder. Without
                            # this field the audit pointed at the wrong step.
                            "ladder_stop_reason": (
                                _LAST_LADDER_STOP.get("reason")
                                if not ladder_created and _LAST_LADDER_STOP
                                else None
                            ),
                            "ladder_stop_detail": (
                                {k: v for k, v in _LAST_LADDER_STOP.items() if k != "reason"}
                                or None
                            ) if not ladder_created else None,
                            # THE AGENT COUNT, AS IT STOOD.
                            #
                            # "requires 3 qualified agents ... got 2" is the
                            # largest single reason a READY map produces no
                            # order. Whether that is the bar working or the
                            # bar missing by a hair depends on HOW FAR the
                            # agents that agreed fell short -- and nothing
                            # recorded it.
                            #
                            # `_session_plan_agent_opinions` already computes
                            # exactly this, but only inside
                            # `_decorate_session_plan_for_delivery`, which
                            # builds a throwaway copy for the Telegram card.
                            # The persisted row never carried it, so the
                            # question could not be answered from history.
                            "agent_reads": _session_plan_agent_opinions(
                                decision.get("agent_details") or {}
                            ),
                            "agent_min_confidence": _safe_float(
                                ((config.get("signal_requirements") or {})
                                 .get("agent_min_confidence")), 67.0
                            ),
                            "mapped_side": str(
                                (all_results.get("session_plan") or {}).get("session_bias")
                                or ""
                            ).upper(),
                        }
                    },
                )
            except Exception as audit_exc:  # noqa: BLE001
                logger.warning("Failed to merge planner gate audit: %s", audit_exc)
        if ladder_created:
            logger.info("Session-plan ladder created %s pending order(s) for %s", ladder_created, symbol)
            # The ladder sends its own pending-order alerts.
            status_delivery.mark_sent()
            return
        if decision_type in {"BUY", "SELL"}:
            symbol_trades = [t for t in open_trades_snapshot if normalize_symbol(t.get("symbol") or symbol) == normalized_symbol]
            adaptive = AdaptiveExecutionService(config).review(decision, symbol_trades)
            adaptive_action = str(adaptive.get("action") or "ALLOW_NEW")
            if adaptive_action == "KEEP_PENDING":
                logger.info("Adaptive execution kept pending for %s %s: %s", decision_type, symbol, adaptive.get("reason"))
                _notify_blocked_directional_signal(
                    telegram=telegram, decision=decision, all_results=all_results,
                    database=database, config=config, send_hourly_now=send_hourly_now, delivery=status_delivery,
                    stage="adaptive execution — kept pending", reason=adaptive.get("reason"),
                )
                return
            if adaptive_action == "NO_TRADE_MISSED_MOVE":
                logger.info("Adaptive execution skipped %s %s as missed move: %s", decision_type, symbol, adaptive.get("reason"))
                _notify_blocked_directional_signal(
                    telegram=telegram, decision=decision, all_results=all_results,
                    database=database, config=config, send_hourly_now=send_hourly_now, delivery=status_delivery,
                    stage="adaptive execution — missed move", reason=adaptive.get("reason"),
                )
                return
            if adaptive_action in {"PROMOTE_TO_MARKET", "REPLACE_WITH_CONTINUATION"}:
                decision = adaptive.get("decision") or decision
                decision["adaptive_execution"] = {
                    "action": adaptive_action,
                    "reason": adaptive.get("reason"),
                }
                logger.info("Adaptive execution %s for %s %s: %s", adaptive_action, decision_type, symbol, adaptive.get("reason"))

            # ── Golden dual-entry exception (operator 2026-08-07) ────────
            # Only while a same-direction pending is alive: price tags 0.618,
            # a candle CLOSES back beyond it, >=2 qualified supporters, and
            # the pending rests inside the 0.618-0.786 band -> FULL market
            # now + the pending kept as a second full entry (the single
            # exception to the >=200-pt separation rule).
            golden_dual = None
            if decision_type in {"BUY", "SELL"} and open_trades_snapshot:
                try:
                    from services.golden_dual_entry import review_golden_dual_entry
                    from utils.indicators import detect_swing_points as _gsp
                    _g_candles = (((data.get("timeframes", {}) or {}).get("5m") or {})
                                  .get("data") or data.get("data") or [])
                    _pendings = [
                        t for t in open_trades_snapshot
                        if str(t.get("status") or "").upper() == "PENDING"
                        and str(t.get("type") or t.get("side") or "").upper() == decision_type
                    ]
                    if _g_candles and _pendings:
                        _sw = _gsp(_g_candles)
                        _hi = float((_sw.get("highs") or [{}])[-1].get("price") or 0.0)
                        _lo = float((_sw.get("lows") or [{}])[-1].get("price") or 0.0)
                        _min_conf = float(
                            ((config.get("signal_requirements") or {})
                             .get("agent_min_confidence"))
                            or config.get("agent_min_confidence") or 67)
                        _sup = 0
                        for _an in CORE_VOTING_AGENTS:
                            _used_an, _ar = _book_agent(all_results, _an)
                            if (float(_ar.get("confidence") or 0) >= _min_conf
                                    and str(_ar.get("direction") or "").upper() == decision_type):
                                _sup += 1
                        golden_dual = review_golden_dual_entry(
                            direction=decision_type, candles=_g_candles,
                            swing_low=_lo, swing_high=_hi,
                            pending_entry=float(_pendings[0].get("entry_price") or 0.0),
                            qualified_support=_sup, config=config)
                except Exception as exc:  # noqa: BLE001 - never break the cycle
                    logger.warning("Golden dual review failed: %s", exc)
            if golden_dual and golden_dual.get("action") == "GOLDEN_DUAL_ENTRY":
                decision["golden_dual_entry"] = golden_dual
                logger.info("Golden dual entry armed for %s %s: %s",
                            decision_type, symbol, golden_dual.get("reason"))
                if not str((decision.get("signal") or {}).get("order_type") or ""
                           ).upper().endswith("MARKET"):
                    decision = AdaptiveExecutionService(config)._promote_to_market(
                        decision, float(decision.get("current_price") or 0.0))
                # Both entries carry stops/targets from the unified law
                # (liquidity rule stop + liquidity/RR targets) computed from
                # the market entry's OWN price. The pending keeps the levels
                # it was created with; management stays per-trade.
                try:
                    _g_cand = _select_setup_candidate(decision_type, all_results) or {}
                    _g_lv = _planner_trade_levels(
                        config, direction=decision_type,
                        entry_price=float(decision.get("current_price") or 0.0),
                        stop_loss=float((decision.get("signal") or {})
                                      .get("stop_loss") or 0.0),
                        target_price=float(_g_cand.get("target_liquidity")
                                         or _g_cand.get("target_price") or 0.0),
                        symbol=symbol, candidate=_g_cand)
                    _g_sig = decision.setdefault("signal", {})
                    _g_sig["stop_loss"] = _g_lv["stop_loss"]
                    _g_sig["tp1"] = _g_lv["tp1"]
                    _g_sig["tp2"] = _g_lv["tp2"]
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Golden dual level rebuild failed: %s", exc)

            # Phase E: even if legacy path 1 / path 2 found an entry, it must
            # still be inside or near the confirmed day map. This prevents small
            # local execution zones from bypassing a stronger planner view.
            day_map_review = DayMapSanityService(config).review(decision, all_results.get("session_plan", {}) or {})
            decision["day_map_sanity"] = day_map_review
            if str(day_map_review.get("action") or "ALLOW") != "ALLOW":
                logger.info("Day-map sanity blocked %s for %s: %s", decision_type, symbol, day_map_review.get("reason"))
                _notify_blocked_directional_signal(
                    telegram=telegram, decision=decision, all_results=all_results,
                    database=database, config=config, send_hourly_now=send_hourly_now, delivery=status_delivery,
                    stage="day-map sanity", reason=day_map_review.get("reason"),
                )
                return

            # Cross-path distance check (applies to BOTH Path 1 and Path 2),
            # except when we're intentionally promoting/replacing an existing
            # morning-plan family rather than opening an unrelated duplicate.
            _tae_cfg_cross = (config.get("signal_requirements") or {}).get("two_agent_entry") or {}
            _cross_pts = int(_tae_cfg_cross.get("cross_entry_distance_points", 150) or 150)
            if adaptive_action not in {"PROMOTE_TO_MARKET", "REPLACE_WITH_CONTINUATION"}:
                _cross_block = _cross_path_distance_check(decision, database, config, cross_distance_points=_cross_pts)
                if _cross_block:
                    logger.info("Cross-path distance blocked: %s", _cross_block)
                    _notify_blocked_directional_signal(
                        telegram=telegram, decision=decision, all_results=all_results,
                        database=database, config=config, send_hourly_now=send_hourly_now, delivery=status_delivery,
                        stage="cross-path distance", reason=_cross_block,
                    )
                    return

            if golden_dual and golden_dual.get("action") == "GOLDEN_DUAL_ENTRY":
                governance = {
                    "action": "ALLOW_NEW",
                    "reason": "golden dual entry exception (0.618 close-confirm, pending at >= 0.70 fibo)",
                    "cancelled_ids": [],
                }
            elif adaptive_action in {"PROMOTE_TO_MARKET", "REPLACE_WITH_CONTINUATION"}:
                governance = {
                    "action": "ALLOW_NEW",
                    "reason": f"adaptive execution {adaptive_action.lower()} bypassed normal pending duplication gate",
                    "cancelled_ids": [],
                }
            else:
                governance = PendingGovernor(config).review(
                    decision,
                    symbol_trades,
                    database=database,
                )
            decision["pending_governor"] = governance
            action = str(governance.get("action") or "ALLOW_NEW")
            if action == "KEEP_EXISTING_PENDING":
                logger.info("Pending governor blocked new %s for %s: %s", decision_type, symbol, governance.get("reason"))
                _notify_blocked_directional_signal(
                    telegram=telegram, decision=decision, all_results=all_results,
                    database=database, config=config, send_hourly_now=send_hourly_now, delivery=status_delivery,
                    stage="pending governor", reason=governance.get("reason"),
                )
                return
            if action in {"REPLACE_PENDING", "CANCEL_PENDING_ALLOW_NEW"}:
                logger.info("Pending governor action for %s %s: %s", decision_type, symbol, governance.get("reason"))
                existing_reasons = list(decision.get("reasons", []))
                existing_reasons.append(f"Pending governor: {governance.get('reason')}")
                decision["reasons"] = existing_reasons
                try:
                    telegram.send_pending_governance(governance, symbol=symbol, side=decision_type)
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Failed to send pending governance message: %s", exc)
            elif action == "KEEP_EXISTING_PENDING" and "blocked" in str(governance.get("reason") or "").lower():
                logger.info("Pending governor blocked replacement for %s %s: %s", decision_type, symbol, governance.get("reason"))
                try:
                    telegram.send_pending_governance(governance, symbol=symbol, side=decision_type)
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Failed to send pending replacement-blocked message: %s", exc)
                return

            # Adaptive execution may waive the DUPLICATE filter, never the
            # post-TP2 block.
            #
            # PROMOTE_TO_MARKET and REPLACE_WITH_CONTINUATION exist to let a
            # stronger thesis replace a stale pending order, so skipping the
            # duplicate check is deliberate: the new order is meant to look
            # like the old one. But that skip took the whole of
            # duplicate_signal_reason with it, and the post-TP2 re-entry guard
            # lives inside that function.
            #
            # 2026-08-03: SELL 79fb5a6e took TP2 at 4022.31 at 13:38. Three
            # minutes later a new SELL LIMIT went out at 4037.48 -- 152 points
            # above that TP2, inside both the 250-point distance bar and the
            # 3-hour window. The guard was correct and never ran.
            #
            # An exhausted level is exhausted whatever route the signal took
            # to reach execution, so the block is evaluated separately and
            # unconditionally.
            duplicate_reason = None if adaptive_action in {"PROMOTE_TO_MARKET", "REPLACE_WITH_CONTINUATION"} else duplicate_signal_reason(decision, database, config)
            if not duplicate_reason:
                duplicate_reason = _post_tp2_reentry_reason(decision, database, config)
            if duplicate_reason:
                logger.info("Signal blocked for %s %s: %s", decision_type, symbol, duplicate_reason)
                if str(duplicate_reason).startswith("Post-exit revalidation blocked:"):
                    try:
                        signal_entry = ((decision.get("signal") or {}).get("entry") or {}).get("price") or decision.get("current_price")
                        telegram.send_revalidation_block(
                            symbol=symbol,
                            side=decision_type,
                            entry_price=signal_entry,
                            reason=duplicate_reason,
                        )
                    except Exception as exc:  # noqa: BLE001
                        logger.warning("Failed to send re-entry blocked message: %s", exc)
                _notify_blocked_directional_signal(
                    telegram=telegram, decision=decision, all_results=all_results,
                    database=database, config=config, send_hourly_now=send_hourly_now, delivery=status_delivery,
                    stage="duplicate / re-entry filter", reason=duplicate_reason,
                )
                return
            # Selective memory: how has this exact pattern done lately, in
            # this session? The learning service already consumes the same
            # rows nightly to retune agent weights, but nothing asked the
            # question at the moment of execution -- so a setup could fail
            # three times in a session and still be taken at full confidence
            # the next morning.
            try:
                setup_review = SetupPerformanceService(database, config).review(decision)
                decision["setup_performance"] = setup_review
                penalty = _safe_float(setup_review.get("confidence_penalty"), 0.0)
                if setup_review.get("veto"):
                    logger.info(
                        "Setup memory vetoed %s for %s: %s",
                        decision_type, symbol, setup_review.get("reason"),
                    )
                    _notify_blocked_directional_signal(
                        telegram=telegram, decision=decision, all_results=all_results,
                        database=database, config=config, send_hourly_now=send_hourly_now,
                        delivery=status_delivery,
                        stage="setup memory", reason=setup_review.get("reason"),
                    )
                    return
                if penalty > 0:
                    before = _safe_float(decision.get("confidence"), 0.0)
                    decision["confidence"] = round(max(0.0, before - penalty), 1)
                    decision.setdefault("warnings", []).append(str(setup_review.get("reason")))
                    logger.info(
                        "Setup memory lowered confidence %.1f%% → %.1f%% for %s: %s",
                        before, decision["confidence"], symbol, setup_review.get("reason"),
                    )
            except Exception as exc:  # noqa: BLE001 - memory must never block a trade
                logger.warning("Setup performance review failed: %s", exc)

            # R25.8 (2026-08-29): MEMORY-BASED REFLECTION. When the SAME POI
            # was recently burned by a stop-hunt/sweep (a level price swept and
            # ran past instead of reversing), the reflection memory issues a
            # short, zone-scoped cooldown veto so the system does not walk
            # straight back into the trap. It never fits weights or touches
            # calibration - just a time-boxed, auditable veto. Fail-open.
            try:
                rblock = (config.get("reflection_agent") or {})
                if bool(rblock.get("enabled", True)):
                    from services.reflection_agent import ReflectionAgent
                    _refl = ReflectionAgent(config)
                    _sig0 = decision.get("signal") or {}
                    _ent0 = _sig0.get("entry") if isinstance(_sig0, dict) else {}
                    _poi = float(
                        (_ent0.get("price") if isinstance(_ent0, dict) else None)
                        or decision.get("current_price") or 0.0)
                    if _poi > 0:
                        _veto = _refl.review(symbol=symbol, poi_level=_poi,
                                             direction=decision_type)
                        if _veto.get("veto"):
                            logger.info("Reflection cooldown vetoed %s for %s: %s",
                                        decision_type, symbol, _veto.get("reason"))
                            _notify_blocked_directional_signal(
                                telegram=telegram, decision=decision, all_results=all_results,
                                database=database, config=config, send_hourly_now=send_hourly_now,
                                delivery=status_delivery, stage="reflection cooldown",
                                reason=_veto.get("reason"),
                            )
                            return
            except Exception as _refl_exc:  # noqa: BLE001
                logger.warning("Reflection veto check failed (fail-open): %s", _refl_exc)

            decision = apply_target_distance_caps(decision, config)
            signal_violations = validate_signal_before_send(decision, config, open_trades_snapshot, all_results)
            if signal_violations:
                logger.error(
                    "Signal validation failed for %s %s: %s",
                    decision_type, symbol, "; ".join(signal_violations),
                )
                _notify_blocked_directional_signal(
                    telegram=telegram, decision=decision, all_results=all_results,
                    database=database, config=config, send_hourly_now=send_hourly_now,
                    delivery=status_delivery,
                    stage="final validation", reason="; ".join(signal_violations),
                )
                return
            trade_id = database.new_trade_id()
            decision["trade_id"] = trade_id
            _queue_opposite_exposure_exit(
                decision, open_trades_snapshot, database, config)
            # R26.3 (operator order 2026-08-31): post-decision compliance
            # auditor. Observational only - it NEVER blocks or changes the
            # trade; it records findings to storage/trade_compliance_audit.jsonl
            # and sends a Telegram WARN when an admitted trade violated a rule.
            try:
                from services.post_decision_auditor import record_and_alert as _pda
                _pda(decision, config, all_results=all_results,
                     open_trades=open_trades_snapshot, telegram=telegram,
                     stage="live_admission")
            except Exception as _pda_exc:  # noqa: BLE001 - never interfere
                logger.debug("post-decision auditor skipped: %s", _pda_exc)
            if demo_execution:
                # Do not announce an order that the broker has not accepted.
                # The tick manager retries MT5 and sends this snapshot only
                # after a real position/pending ticket exists.
                decision["_telegram_signal_sent"] = False
                delivered = True  # accepted into the durable execution queue
            else:
                delivered = False
                try:
                    delivered = bool(telegram.send_signal(decision))
                except Exception as exc:  # noqa: BLE001
                    telegram.send_error_alert(f"Signal delivery failed: {exc}")
                    return
            if not delivered:
                telegram.send_error_alert("Signal delivery failed: Telegram returned False; trade was not saved.")
                return

            # Golden dual keeps its existing same-direction pending; every
            # other accepted replacement cancels the older pending family.
            if not decision.get("golden_dual_entry"):
                try:
                    cancelled_pending = database.cancel_pending_orders(
                        reason=f"Replaced by newer {decision_type} signal",
                        symbol=symbol,
                        direction=decision_type,
                    )
                    if cancelled_pending:
                        logger.info("Cancelled %s stale pending %s order(s) for %s before saving new signal", cancelled_pending, decision_type, symbol)
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Failed to cancel stale pending orders before saving new signal: %s", exc)

            # This also fixes the old golden-dual branch that sent its card but
            # skipped save_trade entirely.
            database.save_trade(decision)
            status_delivery.mark_sent()
            _record_decision_audit(
                database, decision, config,
                stage="execution_queued" if demo_execution else "delivered",
                outcome="QUEUED" if demo_execution else "SENT",
                reason=decision.get("entry_mode"),
            )
            if decision.get("setup_id"):
                try:
                    setup_memory.mark_entry_triggered(
                        setup_id=str(decision.get("setup_id")),
                        state_key=str((decision.get("setup_context") or {}).get("state_key") or ""),
                        trade_id=trade_id,
                        current_price=float(decision.get("current_price") or 0),
                        symbol=symbol,
                    )
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Failed to link setup candidate %s to trade %s: %s", decision.get("setup_id"), trade_id, exc)
        elif decision_type == "WAIT":
            # R18: a terminal WAIT used to write NOTHING, so the funnel
            # reported "ZERO audit rows -> never cycled" for symbols that
            # were actually cycling and being refused at the vote (measured
            # on the live VPS: forex cycled every 5m while the funnel was
            # blind). The refusals are the interesting half - record them.
            _reject = str((decision.get("classic") or {}).get("rejection_reason") or "")
            _warn = [str(w) for w in (decision.get("warnings") or []) if str(w).strip()]
            _wait_reason = _reject or (_warn[-1][:200] if _warn else "no qualified consensus")
            _record_decision_audit(
                database, decision, config,
                stage="book", outcome="WAIT", reason=_wait_reason,
            )
            if send_hourly_now:
                status_delivery.arm(decision=decision, all_results=all_results, database=database)
            else:
                # Silence here is intentional, but it used to be indistinguishable
                # from a bug. Record which gate closed so a missing status can be
                # explained from the run log alone.
                notif = config.get("notifications", {}) or {}
                logger.info(
                    "Market status suppressed for %s: WAIT with status gate off "
                    "(event=%s, SEND_STATUS_ON_MANUAL=%s, hourly_status=%s, "
                    "send_no_signal_updates=%s)",
                    symbol,
                    os.environ.get("GITHUB_EVENT_NAME") or "local",
                    os.environ.get("SEND_STATUS_ON_MANUAL") or "unset",
                    notif.get("hourly_status", False),
                    notif.get("send_no_signal_updates", False),
                )
    except Exception as exc:
        # Without the traceback a crash here is invisible: the workflow still
        # prints nothing but the Telegram alert text, which is rarely enough
        # to locate the failing line.
        logger.exception("Analysis cycle failed for %s", config.get("symbol", "unknown"))
        telegram.send_error_alert(str(exc))
    finally:
        status_delivery.flush()

def _cross_path_distance_check(
    decision: Dict[str, Any],
    database: DatabaseService,
    config: Dict[str, Any],
    cross_distance_points: int = 150
) -> str | None:
    """Block new entry if too close to existing open trade in same direction.
    
    BUY: new entry must be LOWER than existing BUY (buy the dip).
    SELL: new entry must be HIGHER than existing SELL (sell the rally).
    Minimum gap: cross_distance_points (default 150 pts for gold, operator 2026-08-18).
    """
    direction = str(decision.get('decision', '')).upper()
    if direction not in {'BUY', 'SELL'}:
        return None

    signal = decision.get('signal', {}) or {}
    entry_info = signal.get('entry', {}) or {}
    try:
        entry_price = float(entry_info.get('price') or decision.get('current_price') or 0)
    except (TypeError, ValueError):
        return None
    if entry_price <= 0:
        return None

    symbol = str(decision.get("symbol") or config.get("symbol", "XAU/USD"))
    norm_sym = normalize_symbol(symbol)
    # R26.9.7: the configured distance is GOLD points; the operator's ratio
    # law scales it per symbol (gold 1.0 / WTI x0.5 / FX x1.8, derived from
    # the law's own caps — single source: utils.trading_rules.distance_ratio).
    required_pts = cross_distance_points * _tr.distance_ratio(config, symbol)

    # BUILD 31 R10: render prices with the instrument's own decimal engine -
    # FX pairs must show 1.08543 (5 digits) / 155.204 (3 digits), not 1.09.
    def _fmt(price: float) -> str:
        return format_price(price, symbol)

    for trade in database.get_open_trades():
        trade_dir = str(trade.get('type') or trade.get('side') or '').upper()
        if trade_dir != direction:
            continue
        trade_sym = normalize_symbol(str(trade.get('symbol') or ''))
        if trade_sym != norm_sym:
            continue

        try:
            prev_entry = float(trade.get('entry_price') or 0)
        except (TypeError, ValueError):
            continue
        if prev_entry <= 0:
            continue

        pts = abs(price_to_points(entry_price - prev_entry, symbol=symbol))

        if pts < required_pts:
            return (
                f"{direction} blocked: only {pts:.0f} pts from existing {direction} "
                f"@ {_fmt(prev_entry)} in {direction} (need ≥{required_pts:.0f} pts)"
            )

        # Directional rule: BUY lower, SELL higher
        if direction == 'BUY' and entry_price >= prev_entry:
            return (
                f"BUY blocked: new entry {_fmt(entry_price)} is not lower than "
                f"existing BUY @ {_fmt(prev_entry)} (buy the dip rule — must be below)"
            )
        if direction == 'SELL' and entry_price <= prev_entry:
            return (
                f"SELL blocked: new entry {_fmt(entry_price)} is not higher than "
                f"existing SELL @ {_fmt(prev_entry)} (sell the rally rule — must be above)"
            )

    return None


def _latest_candle_extremes(data: Dict[str, Any]) -> tuple[float, float]:
    current = float(data.get("current_price") or 0.0)
    candles = (data.get("timeframes", {}).get("5m") or {}).get("data") or data.get("data") or []
    latest = candles[-1] if candles else {}
    high = float(latest.get("high") or current)
    low = float(latest.get("low") or current)
    return max(high, low), min(high, low)

async def run_analysis_async() -> None:
    base_config = load_config()
    for instrument in enabled_instruments(base_config):
        await _run_analysis_for_config(config_for_instrument(base_config, instrument))

def main() -> None:
    # Weekend hard gate (operator directive 2026-08-09): Sat/Sun = no analysis.
    from utils.helpers import is_weekend_hebron
    if is_weekend_hebron():
        logging.info("Weekend (Sat/Sun Hebron) — analysis skipped by operator directive.")
        return

    import asyncio
    asyncio.run(run_analysis_async())

if __name__ == "__main__":
    main()
