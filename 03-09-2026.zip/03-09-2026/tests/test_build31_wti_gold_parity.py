# -*- coding: utf-8 -*-
"""BUILD 31 / R26.1 (2026-08-31) — WTI point alignment.

The point-based stop/target/trailing/planner distances use ONE factor per
symbol against the gold reference (factor 1.0). WTI is factor 0.5:
    stop floor 135 (noise 100 + buffer 35), cap 200
    trail 75 / step 20, breakeven 75, duplicate/cross/scale 75
    planner zones and post-TP2 scaled by the same 0.5
Ratio concepts (TP1 = 0.8R, TP2 = 2x TP1) and time (2.5h) stay identical to
gold; they are not point distances. Gold itself is untouched.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.helpers import load_config
from utils.instruments import config_for_instrument, DEFAULT_INSTRUMENTS, point_size
import utils.trading_rules as tr
from tests._band_table import FLOOR, CAP, NOISE, BUFFER


def _wti():
    return config_for_instrument(load_config(), {"symbol": "WTI/USD"})


def _gold():
    return config_for_instrument(load_config(), {"symbol": "XAU/USD"})


def test_wti_stop_rule_is_factor_0p5():
    ws, gs = tr.stop_rule(_wti()), tr.stop_rule(_gold())
    assert ws["min_liquidity_points"] == float(NOISE["WTI/USD"])   # 100
    assert ws["safety_buffer_points"] == float(BUFFER["WTI/USD"])  # 35
    assert ws["max_stop_points"] == float(CAP["WTI/USD"])          # 200
    # gold reference untouched
    assert (gs["min_liquidity_points"], gs["safety_buffer_points"],
            gs["max_stop_points"]) == (200.0, 70.0, 400.0)


def test_wti_stop_band_is_135_to_200_points():
    cfg = _wti()
    assert tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00, liquidity_map={}, cfg=cfg,
        symbol="WTI/USD") == 200                       # no liquidity -> cap
    # a 120-pt level qualifies -> +35 buffer = 155 (inside [135,200])
    lvl = tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00,
        liquidity_map={"sell_side": [84.00 - 1.20]}, cfg=cfg, symbol="WTI/USD")
    assert abs(lvl - 155) < 0.01, f"120-pt level + 35 = 155, got {lvl}"
    # a level that would need more than the cap -> cap ships (200)
    lvl2 = tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00,
        liquidity_map={"sell_side": [81.00]}, cfg=cfg, symbol="WTI/USD")
    assert abs(lvl2 - 200) < 0.01


def test_wti_target_ratios_are_gold_ratios_distances_scaled():
    cfg = _wti()
    ratios = tr.target_ratios(cfg)
    assert ratios["min_tp1_rr"] == 0.8          # ratio identical
    assert ratios["tp2_multiple"] == 2.0        # ratio identical
    assert ratios["max_beyond_points"] == 100.0  # 200 * 0.5 (distance scales)
    # No pools: TP1 = 0.8R. Stop at the 135-pt floor ($1.35) ->
    # TP1 = 0.8 x $1.35 = $1.08 (108 pts); SELL so targets below entry.
    tp1, tp2, _ = tr.targets_law(
        direction="SELL", entry=85.36, risk_price=1.35, levels=[],
        cfg=cfg, symbol="WTI/USD")
    assert abs(tp1 - (85.36 - 1.08)) < 0.011, "TP1 must be the 0.8R rung"
    assert abs(tp2 - (85.36 - 2.16)) < 0.011, "TP2 must be 2x TP1 distance"


def test_wti_trailing_and_breakeven_scale_by_0p5():
    cfg = _wti()
    t = tr.trailing_params(cfg)
    assert t["distance_points"] == 75.0      # 150 * 0.5
    assert t["step_points"] == 20.0          # 40 * 0.5
    assert t["early_breakeven_points"] == 75.0
    assert t["activation_at"] == "BREAKEVEN"
    assert cfg["risk_settings"]["min_sl_distance_points"] == 200


def test_wti_entry_geometry_and_planner_scale_by_0p5():
    cfg = _wti()
    gold = _gold()
    d = DEFAULT_INSTRUMENTS["WTI/USD"]
    assert d["duplicate_zone_points"] == 75          # 150 * 0.5
    assert d["cross_entry_distance_points"] == 75
    assert d["scale_in_trigger_points"] == 150  # R26.9.15: gold base; engine scales x0.5 -> 75
    assert DEFAULT_INSTRUMENTS["XAU/USD"]["duplicate_zone_points"] == 150
    pl_w = cfg["session_planner"]
    assert pl_w["standby_min_distance_points"] == 75       # 150 * 0.5
    assert pl_w["max_primary_zone_width_points"] == 225    # 450 * 0.5
    assert pl_w["min_entry_zone_width_points"] == 30       # 60 * 0.5
    assert pl_w["min_thesis_objective_points"] == 15       # 30 * 0.5


def test_wti_post_tp2_scales_by_0p5_time_does_not():
    cfg = _wti()
    p = (cfg.get("trading_rules") or {}).get("post_tp2") or {}
    assert p.get("min_distance_points") == 125      # 250 * 0.5
    assert p.get("window_hours") == 2.5             # time is not scaled


def test_gold_reference_unchanged():
    cfg = _gold()
    s = tr.stop_rule(cfg)
    assert (s["min_liquidity_points"], s["safety_buffer_points"],
            s["max_stop_points"]) == (200, 70, 400)
    t = tr.trailing_params(cfg)
    assert (t["distance_points"], t["step_points"],
            t["early_breakeven_points"]) == (150, 40, 150)
