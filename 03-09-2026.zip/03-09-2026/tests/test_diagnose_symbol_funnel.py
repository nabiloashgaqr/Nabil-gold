# -*- coding: utf-8 -*-
"""BUILD31-R13: scripts/diagnose_symbol_funnel.py contract.

The funnel report distinguishes exactly three failure shapes per symbol:
  * entries > 0                -> trading
  * refusal rows with reasons  -> killed by a named gate (e.g. SPREAD_GUARD)
  * ZERO audit rows            -> never even cycled (schedule/watchlist/collector)
Missing files are reported as MISSING/UNKNOWN - never guessed.
"""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPT = os.path.join(ROOT, "scripts", "diagnose_symbol_funnel.py")


def _write(tmp, rel, payload):
    path = tmp / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


class TestFunnelDiagnosis(unittest.TestCase):
    def test_spread_guard_symbol_is_named_as_gate_killer(self):
        # R26.9.13 fix: the seeded rows used HARD-CODED 2026-08-27 stamps
        # while the script's window is now-relative (--days 7) — a time bomb
        # that expired once the fixtures aged past 7 days (the pre-existing
        # 'SPREAD_GUARD not found' failure). Seed RELATIVE stamps instead so
        # the contract test holds on any run date.
        _day_ago = datetime.now(timezone.utc) - timedelta(days=1)
        _audit_ts = _day_ago.isoformat().replace("+00:00", "+00:00")
        _trade_ts = (_day_ago + timedelta(minutes=30)).isoformat()
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            _write(tmp, "config.json", {
                "symbol": "XAU/USD",
                "symbols": [{"symbol": "XAU/USD", "enabled": True},
                            {"symbol": "EUR/USD", "enabled": True}],
                "filters": {"max_spread_points_by_symbol": {"XAU/USD": 5, "EUR/USD": 25}},
            })
            _write(tmp, "storage/decision_audit.json", [
                {"symbol": "EUR/USD", "stage": "SPREAD_GUARD", "outcome": "REFUSED",
                 "reason": "SPREAD_GUARD: Spread 8.0 pts exceeds existing 5.0-pt guard",
                 "created_at": _audit_ts},
                {"symbol": "XAU/USD", "stage": "delivered", "outcome": "SENT",
                 "reason": None, "created_at": _audit_ts},
            ])
            _write(tmp, "storage/trades.json", [
                {"id": "T1", "symbol": "XAU/USD", "created_at": _trade_ts},
            ])
            proc = subprocess.run([sys.executable, SCRIPT, "--root", td, "--days", "7"],
                                  capture_output=True, text=True, timeout=120)
            self.assertEqual(proc.returncode, 0, proc.stderr[-800:])
            self.assertIn("EUR/USD", proc.stdout)
            self.assertIn("SPREAD_GUARD", proc.stdout)
            self.assertIn("spread_guard_hits=1", proc.stdout)
            self.assertIn("spread_cap=25.0", proc.stdout)

    def test_zero_audit_rows_means_never_cycled(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            _write(tmp, "config.json", {
                "symbols": [{"symbol": "GBP/USD", "enabled": True}],
            })
            _write(tmp, "storage/decision_audit.json", [])
            _write(tmp, "storage/trades.json", [])
            proc = subprocess.run([sys.executable, SCRIPT, "--root", td],
                                  capture_output=True, text=True, timeout=120)
            self.assertEqual(proc.returncode, 0, proc.stderr[-800:])
            self.assertIn("ZERO decision-audit rows", proc.stdout)

    def test_missing_files_reported_as_missing(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            (tmp / "config.json").write_text(json.dumps({"symbols": []}), encoding="utf-8")
            proc = subprocess.run([sys.executable, SCRIPT, "--root", td, "--json",
                                   str(tmp / "out.json")],
                                  capture_output=True, text=True, timeout=120)
            self.assertEqual(proc.returncode, 0, proc.stderr[-800:])
            self.assertIn("MISSING", proc.stdout)
            payload = json.loads((tmp / "out.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["decision_audit_file"], "MISSING")
            self.assertEqual(payload["trades_file"], "MISSING")


    def test_unicode_refusal_reason_survives_cp1252_pipe(self):
        """VPS regression: a live reason containing the '>=' glyph printed
        through a cp1252 pipe (installer 2>&1) used to raise
        UnicodeEncodeError and kill the install preview. Now it prints a
        replacement char and exits 0 (JSON keeps full fidelity)."""
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            _write(tmp, "config.json", {
                "symbol": "XAU/USD",
                "symbols": [{"symbol": "XAU/USD", "enabled": True},
                            {"symbol": "EUR/USD", "enabled": True}],
            })
            _write(tmp, "storage/decision_audit.json", [
                {"symbol": "EUR/USD", "stage": "cross-path distance",
                 "outcome": "BLOCKED",
                 "reason": "SELL blocked: only 13 pts from existing SELL (need \u2265150 pts)",
                 "created_at": (datetime.now(timezone.utc) - timedelta(days=1)
                              ).isoformat()},
            ])
            _write(tmp, "storage/trades.json", [])
            env = dict(os.environ)
            env["PYTHONIOENCODING"] = "cp1252:strict"  # the exact VPS recipe
            proc = subprocess.run([sys.executable, SCRIPT, "--root", td, "--days", "7"],
                                  capture_output=True, text=True, timeout=120, env=env)
            self.assertEqual(proc.returncode, 0, proc.stderr[-800:])
            self.assertIn("150 pts", proc.stdout)  # printed with a replaced glyph


if __name__ == "__main__":
    unittest.main()
