"""Auction Flow and Macro count in the add-veto AND the thesis-exit vote.

Operator 2026-08-18g: 'auction والماكرو يجب ان يعدو في التعزيز وان يعدو
في الخروج المبكر thesis'. Neither source VOTES for admission — auction
left the voting book on 2026-08-14 and macro never had a seat — but a
veto tally and an exit tally are not admissions:

  * add/activation veto: a qualified auction_flow or macro read AGAINST
    the direction counts as an opponent (>= 2 => no add / no activation);
  * thesis-exit vote: both count on EITHER side — defending the trade's
    direction or joining the opposition that confirms the exit.

Bars are per-source: agents (incl. auction_flow) at the shared 65;
macro at its own confirmation floor (55) — the exact bar that lets it
confirm entries, so it opposes at the same strength it supports.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from agents.open_trades_manager import OpenTradesManager
from services.thesis_consensus import count_veto_opponents

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def _legacy_vote_manager():
    """Manager with the direct exit-vote branch active (mirror off)."""
    cfg = json.loads(json.dumps(CONFIG))
    cfg["trade_management"]["thesis_exit"]["agent_vote"]["mirror_entry_admission"] = False
    return OpenTradesManager(cfg)


def _quiet_book(**overrides):
    book = {
        "technical": {"direction": "WAIT", "confidence": 30},
        "multitimeframe": {"direction": "WAIT", "confidence": 30},
        "classical": {"direction": "WAIT", "confidence": 30},
        "smc": {"direction": "WAIT", "confidence": 30},
        "price_action": {"direction": "WAIT", "confidence": 30},
    }
    book.update(overrides)
    return book


# ── macro in the add/activation veto ────────────────────────────────────────

def test_macro_plus_one_agent_vetoes_an_add():
    book = _quiet_book(
        price_action={"direction": "SELL", "confidence": 68},
        macro_fundamental={"direction": "SELL", "confidence": 60},
    )
    census = count_veto_opponents("BUY", book, CONFIG)
    assert census["count"] == 2
    assert "macro_fundamental" in census["opponents"]


def test_macro_qualifies_at_its_own_55_bar_not_the_agent_65():
    # R26.9.13 (operator 2026-09-03): the hard-veto bar moved 55 -> 60
    # (signal_requirements.two_agent_entry.macro_veto.min_confidence).
    # A 56% counter-macro no longer blocks an add; 60 still does.
    book = _quiet_book(macro_fundamental={"direction": "SELL", "confidence": 60})
    assert "macro_fundamental" in count_veto_opponents("BUY", book, CONFIG)["opponents"]
    weak = _quiet_book(macro_fundamental={"direction": "SELL", "confidence": 59})
    assert count_veto_opponents("BUY", weak, CONFIG)["count"] == 0


def test_macro_raw_bias_form_is_understood():
    """Books built from the raw agent payload carry macro_direction.bias."""
    book = _quiet_book(macro_fundamental={
        "macro_direction": {"bias": "BEARISH_GOLD", "confidence": 68}})
    assert "macro_fundamental" in count_veto_opponents("BUY", book, CONFIG)["opponents"]


def test_macro_agreeing_with_the_side_never_vetoes():
    book = _quiet_book(macro_fundamental={"direction": "BUY", "confidence": 90})
    assert count_veto_opponents("BUY", book, CONFIG)["count"] == 0


# ── auction + macro in the thesis-exit vote (legacy branch) ─────────────────

def test_auction_flow_joins_the_exit_opposition():
    """Exit confirmation needs min_opponents_to_exit=3 (config) — auction
    flow is now a countable third voice alongside two core agents."""
    manager = _legacy_vote_manager()
    book = _quiet_book(
        price_action={"direction": "SELL", "confidence": 70},
        smc={"direction": "SELL", "confidence": 72},
        auction_flow={"direction": "SELL", "confidence": 71},
    )
    vote = manager._agent_exit_vote(book, "BUY")
    assert vote["verdict"] == "CONFIRM"
    assert "auction_flow" in vote["opponents"]


def test_macro_joins_the_exit_opposition():
    """Macro completes the 3-opponent exit quorum at its own 55 bar."""
    manager = _legacy_vote_manager()
    book = _quiet_book(
        smc={"direction": "SELL", "confidence": 70},
        price_action={"direction": "SELL", "confidence": 68},
        macro_fundamental={"direction": "SELL", "confidence": 60},
    )
    vote = manager._agent_exit_vote(book, "BUY")
    assert vote["verdict"] == "CONFIRM"
    assert "macro_fundamental" in vote["opponents"]


def test_auction_and_macro_can_DEFEND_the_trade_too():
    """The ledger has two sides: a flow reader and a macro view arguing the
    trade's own direction hold it open against a lone dissenter."""
    manager = _legacy_vote_manager()
    book = _quiet_book(
        auction_flow={"direction": "BUY", "confidence": 75},
        macro_fundamental={"direction": "BUY", "confidence": 62},
        smc={"direction": "SELL", "confidence": 70},
    )
    vote = manager._agent_exit_vote(book, "BUY")
    assert vote["verdict"] == "DEFEND"
    assert "auction_flow" in vote["defenders"]
    assert "macro_fundamental" in vote["defenders"]


def test_weak_macro_stays_out_of_the_exit_vote():
    manager = _legacy_vote_manager()
    book = _quiet_book(
        smc={"direction": "SELL", "confidence": 70},
        price_action={"direction": "SELL", "confidence": 70},
        auction_flow={"direction": "SELL", "confidence": 71},
        macro_fundamental={"direction": "BUY", "confidence": 40},  # under 55
    )
    vote = manager._agent_exit_vote(book, "BUY")
    assert "macro_fundamental" not in vote["defenders"]
    assert vote["verdict"] == "CONFIRM", (
        "a sub-bar macro must not defend a trade against a 3-opponent book")


def test_admission_voting_census_is_untouched():
    """The widening is veto/exit only: VOTING_AGENTS stays the five."""
    from services.thesis_consensus import VOTING_AGENTS
    assert "auction_flow" not in VOTING_AGENTS
    assert "macro_fundamental" not in VOTING_AGENTS
