"""Tests for the upgrade modules (run: python -m pytest upgrades/test_upgrades.py -q)"""
import math

import numpy as np
import pytest

from upgrades import wilder_adx, d1_regime_feed, risk_analytics
from upgrades.correlation_exposure import CorrelationExposureManager
from upgrades.margin_guard import pre_send_veto


# ── Wilder ADX ────────────────────────────────────────────────────────────────
class TestWilderADX:
    def test_adx_trending_up(self):
        closes = [100 + i * 0.5 for i in range(120)]
        highs = [c + 1 for c in closes]
        lows = [c - 1 for c in closes]
        candles = [{"high": h, "low": l, "close": c} for h, l, c in zip(highs, lows, closes)]
        adx = wilder_adx.calculate_adx(candles)
        assert adx > 25  # strong trend must be detected

    def test_adx_ranging(self):
        closes = [100 + 2 * math.sin(i / 3) for i in range(200)]
        highs = [c + 0.5 for c in closes]
        lows = [c - 0.5 for c in closes]
        candles = [{"high": h, "low": l, "close": c} for h, l, c in zip(highs, lows, closes)]
        adx = wilder_adx.calculate_adx(candles)
        assert adx < 25

    def test_dmi_direction(self):
        closes = [100 + i * 0.5 for i in range(120)]
        dmi = wilder_adx.calculate_dmi([c + 1 for c in closes], [c - 1 for c in closes], closes)
        assert dmi["plus_di"] > dmi["minus_di"]


# ── D1 regime ──────────────────────────────────────────────────────────────────
class TestD1RegimeFeed:
    def test_trend_up(self):
        closes = [2000 + i * 1.0 for i in range(300)]
        reg = d1_regime_feed.classify_regime(closes, [c + 5 for c in closes], [c - 5 for c in closes])
        assert reg["regime"] == "TREND_UP"

    def test_trend_down(self):
        closes = [3000 - i * 1.0 for i in range(300)]
        reg = d1_regime_feed.classify_regime(closes, [c + 5 for c in closes], [c - 5 for c in closes])
        assert reg["regime"] == "TREND_DOWN"

    def test_range(self):
        closes = [2000 + 10 * math.sin(i / 2) for i in range(300)]
        reg = d1_regime_feed.classify_regime(closes, [c + 4 for c in closes], [c - 4 for c in closes])
        assert reg["regime"] == "RANGE"

    def test_insufficient_data(self):
        reg = d1_regime_feed.classify_regime([2000.0] * 40, [2005.0] * 40, [1995.0] * 40)
        assert reg["regime"] == "INSUFFICIENT_DATA"


# ── Risk analytics ─────────────────────────────────────────────────────────────
class TestRiskAnalytics:
    def test_var_cvar_ordering(self):
        equity = [10000 + 50 * math.sin(i / 2) + i for i in range(300)]
        ra = risk_analytics.RiskAnalytics(equity)
        v = ra.historical_var_cvar(0.95)
        assert v["n"] > 50
        assert v["cvar"] >= v["var"] >= 0

    def test_sharpe_positive_on_uptrend(self):
        equity = [10000 * (1.001 ** i) for i in range(300)]
        assert risk_analytics.RiskAnalytics(equity).sharpe() > 0

    def test_calmar_finite(self):
        equity = [10000 + 100 * i for i in range(100)]
        assert math.isfinite(risk_analytics.RiskAnalytics(equity).calmar())

    def test_dollar_limit_halt(self, tmp_path):
        class FakeDB:
            def get_recent_trades(self, limit=100):
                from datetime import datetime, timezone
                today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
                return [{"created_at": today, "final_pnl": -400.0}]
        cfg = {"risk_settings": {"account_capital": 10000, "max_daily_loss_percent": 3.0}}
        r = risk_analytics.dollar_daily_loss_limit(FakeDB(), cfg)
        assert r["mode"] == "DOLLARS"
        assert r["level"] == "HALT"          # -400 <= -300
        assert r["limit_dollars"] == 300.0


# ── Correlation manager ────────────────────────────────────────────────────────
class TestCorrelationExposure:
    def _manager(self, tmp_path, enforce=False):
        cfg = {
            "instruments": [{"symbol": "XAU/USD"}, {"symbol": "WTI/USD"}],
            "correlation_guard": {
                "lookback_days": 60,
                "veto_correlation": 0.55,
                "max_heat": 1.5,
                "enforce": enforce,
                "daily_closes_path": str(tmp_path / "closes.json"),
            },
        }
        return CorrelationExposureManager(cfg)

    def test_positive_correlation_detected(self, tmp_path):
        m = self._manager(tmp_path)
        rng = np.random.default_rng(7)
        base = rng.normal(0, 1, 80).cumsum()
        gold = 2000 + base * 5
        oil = 70 + base * 0.3 + rng.normal(0, 0.15, 80).cumsum()
        for i, (g, o) in enumerate(zip(gold, oil)):
            m.update_closes("XAU/USD", f"2026-{i % 28 + 1:02d}-{i // 28 + 1:02d}", float(g))
            m.update_closes("WTI/USD", f"2026-{i % 28 + 1:02d}-{i // 28 + 1:02d}", float(o))
        corr = m.correlation("XAU/USD", "WTI/USD")
        assert corr > 0.5

    def test_opposite_trade_veto(self, tmp_path):
        m = self._manager(tmp_path, enforce=True)
        rng = np.random.default_rng(3)
        base = rng.normal(0, 1, 80).cumsum()
        for i in range(80):
            m.update_closes("XAU/USD", f"d{i}", float(2000 + base[i] * 5))
            m.update_closes("WTI/USD", f"d{i}", float(70 + base[i] * 0.3))
        open_trades = [{"symbol": "WTI/USD", "signal": "SELL"}]
        verdict = m.review({"symbol": "XAU/USD", "signal": "BUY"}, open_trades)
        assert verdict["action"] == "VETO"
        assert "correlated" in verdict["reason"]


# ── Margin guard ───────────────────────────────────────────────────────────────
class TestMarginGuard:
    class Acct:
        def __init__(self, equity, margin, margin_level, balance=10000):
            self.equity, self.margin, self.margin_level, self.balance = equity, margin, margin_level, balance

    def test_low_margin_level_veto(self, tmp_path):
        cfg = {"margin_guard": {"peak_file": str(tmp_path / "peak.json")}}
        allow, reason = pre_send_veto(self.Acct(equity=10000, margin=4000, margin_level=150), cfg)
        assert not allow and "margin level" in reason

    def test_high_exposure_veto(self, tmp_path):
        cfg = {"margin_guard": {"peak_file": str(tmp_path / "peak.json")}}
        allow, _ = pre_send_veto(self.Acct(equity=10000, margin=6000, margin_level=500), cfg)
        assert not allow

    def test_healthy_pass(self, tmp_path):
        cfg = {"margin_guard": {"peak_file": str(tmp_path / "peak.json")}}
        allow, _ = pre_send_veto(self.Acct(equity=10000, margin=1000, margin_level=900), cfg)
        assert allow

    def test_equity_drawdown_veto(self, tmp_path):
        peak = tmp_path / "peak.json"
        peak.parent.mkdir(parents=True, exist_ok=True)
        import json
        peak.write_text(json.dumps({"peak": 10000}))
        cfg = {"margin_guard": {"peak_file": str(peak)}}
        allow, reason = pre_send_veto(self.Acct(equity=5000, margin=500, margin_level=900), cfg)
        assert not allow and "drawdown" in reason


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-q"]))
