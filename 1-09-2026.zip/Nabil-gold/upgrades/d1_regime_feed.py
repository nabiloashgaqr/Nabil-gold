"""
upgrades/d1_regime_feed.py — True D1/W1 market-regime layer (fixes the structural blind spot).

Problem (evidence):
  - config timeframes = ['5m','15m','1H','4H']. NO D1, NO W1 anywhere in the
    pipeline. agents/daily_bias_agent.py says it explicitly: "4H is a proxy for
    daily direction". A 15m-system making $40-wide gold stops without a real
    daily regime filter is structurally blind to the regime that dominates gold
    P&L (trend days vs chop days).
  - technical_agent market phase uses the ADX proxy (see upgrades/wilder_adx.py).

Solution: MT5 natively serves D1/W1 candles (zero API cost, no new dependency).
  - fetch_d1_context() pulls MT5_TIMEFRAME_D1 + W1 and computes:
      regime        = TREND_UP / TREND_DOWN / RANGE   (Wilder ADX >= 25 + EMA 50/200)
      vol_percentile= current 20-day ATR vs trailing 120-day ATR distribution
      session_hi/lo = previous day high/low (already used by SMC; now explicit)
  - Integrate: replace the 4H proxy inside daily_bias_agent.analyze() with
    regime from this feed when MT5 is available; keep the 4H fallback for
    GitHub Actions runs (no MT5 there).

Integration:
  from upgrades.d1_regime_feed import fetch_d1_context
  ctx = fetch_d1_context(config)                 # in scripts/run_analysis.py
  all_results["daily_regime"] = ctx              # consumed by daily_bias_agent + risk filters
  Risk filter addition: ctx["regime"] == "RANGE" -> require PATH_1 quality only
  (no 2-agent paths in chop) — a classic institutional regime gate.

Tests: see upgrades/test_upgrades.py::TestD1RegimeFeed (pure functions, MT5-free)
"""
from __future__ import annotations

from typing import Any, Dict, List, Sequence

import numpy as np

from upgrades.wilder_adx import calculate_dmi


def classify_regime(
    d1_closes: Sequence[float], d1_highs: Sequence[float], d1_lows: Sequence[float]
) -> Dict[str, Any]:
    """Pure regime classification (testable without MT5)."""
    closes = list(d1_closes)
    if len(closes) < 130:  # need 120-day ATR window + margin
        return {"regime": "INSUFFICIENT_DATA", "confidence": 0.0}

    ema50 = _ema(closes, 50)
    ema200 = _ema(closes, 200)
    dmi = calculate_dmi(list(d1_highs), list(d1_lows), closes, period=14)
    adx = dmi["adx"]

    if adx >= 25:
        regime = "TREND_UP" if ema50 > ema200 else "TREND_DOWN"
    else:
        regime = "RANGE"

    atr20 = _atr(list(d1_highs), list(d1_lows), closes, 20)
    atr120 = np.array([_atr(list(d1_highs), list(d1_lows), closes, 120)] * 1)
    # percentile of current ATR within trailing 120-day rolling ATR distribution
    rolling = [_atr(list(d1_highs), list(d1_lows), closes, 20, end=i) for i in range(120, len(closes))]
    rolling = np.array([r for r in rolling if r > 0])
    vol_pct = float((rolling < atr20).mean()) if len(rolling) else 0.5

    return {
        "regime": regime,
        "adx": round(adx, 2),
        "ema50": round(ema50, 2),
        "ema200": round(ema200, 2),
        "atr20": round(atr20, 2),
        "vol_percentile": round(vol_pct, 2),
        "vol_label": "LOW" if vol_pct < 0.25 else ("HIGH" if vol_pct > 0.75 else "NORMAL"),
        "confidence": round(min(90.0, adx * 1.2), 1),
    }


def fetch_d1_context(config: Dict[str, Any]) -> Dict[str, Any]:
    """MT5-native D1/W1 fetch; falls back to {} (no crash, no false regime)."""
    try:
        from services.mt5_feed import _mt5, connected, initialize  # repo internals

        mt5 = _mt5()
        if not mt5:
            initialize()
            mt5 = _mt5()
        if not mt5 or not connected():
            return {"regime": "MT5_UNAVAILABLE", "fallback": "4H proxy"}
        symbol = str(config.get("symbol", "XAUUSD")).replace("/", "")
        rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_D1, 0, 500)
        if rates is None or len(rates) < 130:
            return {"regime": "INSUFFICIENT_DATA", "fallback": "4H proxy"}
        closes = [float(r[4]) for r in rates]
        highs = [float(r[2]) for r in rates]
        lows = [float(r[3]) for r in rates]
        return {"source": "mt5_d1", **classify_regime(closes, highs, lows)}
    except Exception as exc:  # noqa: BLE001 — regime feed must never break the cycle
        return {"regime": "ERROR", "error": str(exc), "fallback": "4H proxy"}


# ---- helpers ------------------------------------------------------------------
def _ema(values: Sequence[float], period: int) -> float:
    v = np.asarray(values, dtype=float)
    if len(v) < period:
        return float(v[-1])
    alpha = 2.0 / (period + 1)
    out = v[-period - 1 :].copy()
    seed = out[:period].mean()
    for i in range(period, len(out)):
        out[i] = out[i - 1] + alpha * (out[i] - out[i - 1])
    return float(out[-1]) if len(out) > period else float(seed)


def _tr(high: Sequence[float], low: Sequence[float], close: Sequence[float]) -> np.ndarray:
    h, l, c = np.asarray(high), np.asarray(low), np.asarray(close)
    pc = np.roll(c, 1)
    pc[0] = c[0]
    return np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))


def _atr(
    high: Sequence[float], low: Sequence[float], close: Sequence[float], period: int, end: int | None = None
) -> float:
    h, l, c = np.asarray(high), np.asarray(low), np.asarray(close)
    if end is not None:
        h, l, c = h[:end], l[:end], c[:end]
    if len(c) < period + 1:
        return 0.0
    tr = _tr(h, l, c)[-period:]
    return float(tr.mean())
