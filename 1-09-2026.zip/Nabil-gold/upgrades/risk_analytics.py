"""
upgrades/risk_analytics.py — Portfolio risk analytics: VaR, CVaR, dollar-based limits, MAE/MFE.

Problem (evidence):
  - agents/risk_management_agent.py sizes positions as fixed-fraction % of capital
    only. No Kelly/Optimal-f, no volatility targeting.
  - Daily loss limit is POINTS-based (450 pts gold) — its dollar value silently
    changes when lots or capital change. Capital protection must be currency-based.
  - No VaR/CVaR, no MAE/MFE measurement (the standard institutional exit-quality
    diagnostics).

Integration:
  from upgrades.risk_analytics import RiskAnalytics, dollar_daily_loss_limit
  1) services/dynamic_risk.py evaluate(): replace points check with
     dollar_daily_loss_limit(database, config) — same HALT/STRICT semantics.
  2) services/weekly_report.py: add var_95 / cvar_95 / sharpe from RiskAnalytics.
  3) MAE/MFE: record at close in open_trades_manager (one dict update), then the
     weekly report shows median MAE per path — the industry-standard check for
     "is my stop too wide?".

Tests: see upgrades/test_upgrades.py::TestRiskAnalytics
"""
from __future__ import annotations

import math
from typing import Any, Dict, List

import numpy as np


def dollar_daily_loss_limit(database: Any, config: Dict[str, Any]) -> Dict[str, Any]:
    """Currency-based daily loss limit (replaces points-based).

    config["risk_settings"]["max_daily_loss_percent"]  e.g. 3.0 (% of account)
    Falls back to the legacy points value with an explicit warning card.
    """
    settings = config.get("risk_settings", {}) or {}
    capital = float(settings.get("account_capital", 10_000) or 10_000)
    pct = float(settings.get("max_daily_loss_percent", 0.0) or 0.0)
    if pct <= 0:
        return {
            "mode": "LEGACY_POINTS",
            "limit_dollars": None,
            "warning": "max_daily_loss_percent not set — legacy points limit in use",
        }
    limit_usd = capital * pct / 100.0
    # same query pattern as services/dynamic_risk.py::evaluate
    recent = database.get_recent_trades(limit=100)
    from datetime import datetime, timezone

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    daily_pnl = 0.0
    for t in recent:
        if not str(t.get("created_at") or t.get("entry_time") or "").startswith(today):
            continue
        for key in ("final_pnl", "current_pnl", "pnl"):
            v = t.get(key)
            if isinstance(v, (int, float)):
                daily_pnl += float(v)
                break
    return {
        "mode": "DOLLARS",
        "limit_dollars": round(limit_usd, 2),
        "daily_pnl": round(daily_pnl, 2),
        "remaining": round(limit_usd - daily_pnl, 2),
        "level": "HALT" if daily_pnl <= -limit_usd else ("STRICT" if daily_pnl <= -0.5 * limit_usd else "NORMAL"),
        "capital": capital,
        "pct": pct,
    }


class RiskAnalytics:
    """Historical + parametric VaR / CVaR and equity-curve ratios."""

    def __init__(self, equity_points: List[float]):
        self.equity = np.asarray(equity_points, dtype=float)

    def returns(self) -> np.ndarray:
        e = self.equity
        return np.diff(e) / np.where(e[:-1] == 0, np.nan, e[:-1])

    def historical_var_cvar(self, level: float = 0.95) -> Dict[str, float]:
        r = self.returns()
        r = r[np.isfinite(r)]
        if len(r) < 20:
            return {"var": 0.0, "cvar": 0.0, "n": int(len(r))}
        var = float(-np.quantile(r, 1 - level))
        tail = r[r <= -var]
        cvar = float(-tail.mean()) if len(tail) else var
        return {"var": round(var, 5), "cvar": round(cvar, 5), "n": int(len(r))}

    def parametric_var(self, level: float = 0.95) -> float:
        r = self.returns()
        r = r[np.isfinite(r)]
        if len(r) < 20 or r.std() == 0:
            return 0.0
        from scipy.stats import norm  # optional; degrade to z=1.645 if scipy absent

        z = norm.ppf(level) if norm else 1.645
        return float(-(r.mean() + z * r.std()))

    def sharpe(self, risk_free_annual: float = 0.04, periods_per_year: int = 252) -> float:
        r = self.returns()
        r = r[np.isfinite(r)]
        if len(r) < 10 or r.std() == 0:
            return 0.0
        rf_daily = risk_free_annual / periods_per_year
        return float((r.mean() - rf_daily) / r.std() * math.sqrt(periods_per_year))

    def sortino(self, risk_free_annual: float = 0.04, periods_per_year: int = 252) -> float:
        r = self.returns()
        r = r[np.isfinite(r)]
        if len(r) < 10:
            return 0.0
        rf_daily = risk_free_annual / periods_per_year
        downside = r[r < 0]
        if len(downside) == 0 or downside.std() == 0:
            return 0.0
        return float((r.mean() - rf_daily) / downside.std() * math.sqrt(periods_per_year))

    def calmar(self, periods_per_year: int = 252) -> float:
        r = self.returns()
        r = r[np.isfinite(r)]
        if len(r) < 10:
            return 0.0
        annual_return = r.mean() * periods_per_year
        peak = np.maximum.accumulate(self.equity)
        dd = (self.equity - peak) / np.where(peak == 0, np.nan, peak)
        max_dd = float(np.nanmin(dd)) if len(dd) else 0.0
        if max_dd == 0:
            return 0.0
        return float(annual_return / abs(max_dd))


def mae_mfe_stats(trades: List[Dict[str, Any]]) -> Dict[str, Any]:
    """MAE/MFE per trade from recorded max adverse/favorable excursion (in R multiples).

    Each trade row needs keys added at close time by open_trades_manager:
      mae_r  = max distance against position / initial stop distance (negative)
      mfe_r  = max distance in favour / initial stop distance (positive)
    """
    mae, mfe = [], []
    for t in trades:
        for key, sink in (("mae_r", mae), ("mfe_r", mfe)):
            v = t.get(key)
            if isinstance(v, (int, float)):
                sink.append(float(v))
    if not mae:
        return {"n": 0}
    return {
        "n": len(mae),
        "median_mae_r": round(float(np.median(mae)), 2),
        "p90_mae_r": round(float(np.quantile(mae, 0.10)), 2),   # 90% of trades stay above
        "median_mfe_r": round(float(np.median(mfe)), 2),
        "p90_mfe_r": round(float(np.quantile(mfe, 0.90)), 2),
    }
