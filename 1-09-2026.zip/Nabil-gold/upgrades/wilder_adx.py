"""
upgrades/wilder_adx.py — Wilders True ADX (industry standard) replacing the "ADX proxy".

Problem: utils/indicators.py has no real ADX. technical_agent.py uses a simplified
"ADX proxy" for trend strength. Wilder's smoothing matters: it is the industry
standard and the reference used by every institutional desk.

Integration:
  1) `from utils.indicators import calculate_adx`  (add this file's functions there,
     or keep this module and import it in technical_agent.py)
  2) In technical_agent._technical_analysis replace the proxy value with
     adx = calculate_adx(candles, period=14)
  3) Keep the same score mapping (>=25 trending, <15 ranging) so downstream
     behaviour is unchanged; only the input improves.

Tests: see upgrades/test_upgrades.py::TestWilderADX
"""
from typing import List, Sequence

import numpy as np


def _tr(high: Sequence[float], low: Sequence[float], close: Sequence[float]) -> np.ndarray:
    h = np.asarray(high, dtype=float)
    l = np.asarray(low, dtype=float)
    c = np.asarray(close, dtype=float)
    prev_close = np.roll(c, 1)
    prev_close[0] = c[0]
    return np.maximum(h - l, np.maximum(np.abs(h - prev_close), np.abs(l - prev_close)))


def _wilder_smooth(values: np.ndarray, period: int) -> np.ndarray:
    """Wilder smoothing = EMA with alpha = 1/period, seeded with SMA of first period."""
    out = np.full(values.shape, np.nan, dtype=float)
    out[period - 1] = values[:period].mean()
    alpha = 1.0 / period
    for i in range(period, len(values)):
        out[i] = out[i - 1] + alpha * (values[i] - out[i - 1])
    return out


def calculate_dmi(
    high: Sequence[float], low: Sequence[float], close: Sequence[float], period: int = 14
) -> dict:
    h = np.asarray(high, dtype=float)
    l = np.asarray(low, dtype=float)
    c = np.asarray(close, dtype=float)
    up_move = np.diff(h)
    down_move = -np.diff(l)
    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)
    # np.diff returns N-1 values; align with the N-length ATR series
    plus_dm = np.concatenate(([0.0], plus_dm))
    minus_dm = np.concatenate(([0.0], minus_dm))
    atr = _wilder_smooth(_tr(h, l, c), period)
    plus_di = 100.0 * _wilder_smooth(plus_dm, period) / np.where(atr == 0, np.nan, atr)
    minus_di = 100.0 * _wilder_smooth(minus_dm, period) / np.where(atr == 0, np.nan, atr)
    dx = 100.0 * np.abs(plus_di - minus_di) / np.where((plus_di + minus_di) == 0, np.nan, plus_di + minus_di)
    adx = _wilder_smooth(np.where(np.isnan(dx), 0.0, dx), period)
    return {
        "adx": float(adx[-1]) if len(adx) else 0.0,
        "plus_di": float(plus_di[-1]) if len(plus_di) else 0.0,
        "minus_di": float(minus_di[-1]) if len(minus_di) else 0.0,
        "adx_series": adx.tolist(),
    }


def calculate_adx(candles: Sequence[dict], period: int = 14) -> float:
    """Convenience wrapper matching the candle-dict convention used in this repo."""
    high = [float(c["high"]) for c in candles]
    low = [float(c["low"]) for c in candles]
    close = [float(c["close"]) for c in candles]
    if len(close) < period * 2:
        return 0.0
    return calculate_dmi(high, low, close, period)["adx"]
