"""THE single source of truth for the stop / targets / trailing / post-TP2 laws.

Operator directive 2026-08-07 (full audit): one place owns the maths and the
fallback defaults; every door (run_analysis, the risk agent, the session
planner fallback, open-trades management, the post-TP2 guard) calls this
module and nothing else. `tests/test_one_source_of_trading_rules.py` fails if
any other module mentions the rule keys or re-implements the formulae.

The DATA stays in config.json; this module owns the FORMULAE and the default
values used when a key is absent. Changing a number in config.json binds
every door at once -- that is the whole point.
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

from utils.instruments import (points_to_price, price_to_points, round_price,
                               point_size, get_instrument)

# ── the only fallback defaults in the codebase ─────────────────────────────
DEFAULT_STOP_RULE = {"min_liquidity_points": 200.0, "safety_buffer_points": 70.0,
                     "max_stop_points": 400.0}
DEFAULT_MIN_TP1_RR = 0.8
DEFAULT_TP2_MULTIPLE = 2.0
DEFAULT_MAX_TP2_BEYOND_POINTS = 200.0
DEFAULT_POST_TP2 = {"min_distance_points": 250.0, "window_hours": 2.5}
DEFAULT_TRAILING = {"enabled": False, "distance_points": 150.0, "step_points": 40.0}


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _block(cfg: Dict[str, Any], name: str) -> Dict[str, Any]:
    """Phase 2: the canonical `trading_rules.<name>` block wins; the legacy
    sections (risk_settings / trade_management / trailing_stop /
    post_tp2_reentry) remain read-compatible aliases."""
    return ((cfg or {}).get("trading_rules") or {}).get(name) or {}


# ── stops ───────────────────────────────────────────────────────────────────

def stop_rule(cfg: Dict[str, Any]) -> Dict[str, float]:
    """The liquidity-rule stop parameters (200 / 70 / 400 on gold today)."""
    raw = _block(cfg, "stop") or ((cfg or {}).get("risk_settings") or {}).get("stop_from_liquidity") or {}
    out = dict(DEFAULT_STOP_RULE)
    for key in out:
        if _f(raw.get(key), 0.0) > 0:
            out[key] = _f(raw.get(key))
    out["enabled"] = bool(raw.get("enabled", True))
    return out


def stop_rule_for_symbol(cfg: Dict[str, Any], symbol: Any) -> Dict[str, float]:
    """Single source of truth for the PER-SYMBOL stop law (R26.6).

    Base canonical block (gold 200/70/400) overridden by the instrument spec's
    own trading_rules.stop when present (WTI 100/35/200; FX 450/150/900).
    Every door that needs a stop band — the live clamp AND the observational
    auditor — must call THIS so they can never disagree per symbol.
    """
    rule = stop_rule(cfg)
    try:
        spec = get_instrument(cfg, symbol) or {}
        inst_stop = ((spec.get("trading_rules") or {}).get("stop")) or None
        if isinstance(inst_stop, dict):
            for key in list(rule.keys()):
                if key not in inst_stop:
                    continue
                rule[key] = (bool(inst_stop[key]) if key == "enabled"
                             else _f(inst_stop[key]))
    except Exception:  # noqa: BLE001 - fall back to the base block
        pass
    return rule


def stop_from_liquidity_points(
    *,
    direction: str,
    entry: float,
    liquidity_map: Dict[str, Any] | None,
    cfg: Dict[str, Any],
    symbol: str,
    rule: Dict[str, Any] | None = None,
) -> float:
    """Distance in POINTS of the rule stop from entry.

    Liquidity closer than min_liquidity_points is noise; the stop sits
    safety_buffer_points beyond the first eligible level; beyond
    max_stop_points (or none eligible) ships the cap directly.
    """
    if rule is not None:
        merged = dict(DEFAULT_STOP_RULE)
        for key in merged:
            if _f(rule.get(key), 0.0) > 0:
                merged[key] = _f(rule.get(key))
        merged["enabled"] = bool(rule.get("enabled", True))
        rule = merged
    else:
        rule = stop_rule(cfg)
    if not rule["enabled"]:
        flat = _f(((cfg or {}).get("risk_settings") or {}).get("min_sl_distance_points"), 0.0)
        return flat
    liquidity_map = liquidity_map or {}
    side = "sell_side" if direction == "BUY" else "buy_side"
    distances: List[float] = []
    for raw in list(liquidity_map.get(side) or []):
        level = _f(raw, 0.0)
        if level <= 0:
            continue
        if (level < entry) if direction == "BUY" else (level > entry):
            distances.append(abs(price_to_points(entry - level, symbol)))
    eligible = sorted(d for d in distances if d >= rule["min_liquidity_points"])
    if not eligible or eligible[0] > rule["max_stop_points"]:
        return rule["max_stop_points"]
    return min(eligible[0] + rule["safety_buffer_points"], rule["max_stop_points"])


# ── targets ─────────────────────────────────────────────────────────────────

def clamp_stop_price(*, direction: str, entry: float, stop: float,
                     cfg: Dict[str, Any], symbol: str) -> float:
    """The band law applied to a PRICE level (R25.7-E, live 2026-08-28).

    Live incident: the PATH 6 pre-arm anchored its stop to the leg origin
    + 1.0xATR and shipped a gold SELL LIMIT with a 708.6-pt stop (cap 400)
    on a crash-day ATR. A stop whose distance from entry falls outside the
    symbol's [floor, cap] band is clamped back inside: floor =
    min_liquidity_points + safety_buffer_points, cap = max_stop_points.
    A wrong-side stop (at/beyond entry — BE, trailing, protection) is
    returned UNTOUCHED: this clamp is for INITIAL risk stops only, and
    protection is never widened here.
    """
    # The band is PER SYMBOL, from the single-source loader
    # (gold 200/70/400 -> [270,400]; WTI 100/35/200 -> [135,200];
    # FX 450/150/900 -> [600,900]).
    rule = stop_rule_for_symbol(cfg, symbol)
    entry = float(entry or 0.0)
    stop = float(stop or 0.0)
    if not rule.get("enabled", False) or entry <= 0 or stop <= 0:
        return stop
    pv = point_size(symbol, cfg)
    if pv <= 0:
        return stop
    side = str(direction or "").upper()
    if side not in {"BUY", "SELL"}:
        return stop
    wrong_side = ((side == "BUY" and stop >= entry)
                  or (side == "SELL" and stop <= entry))
    if wrong_side:
        return stop
    pts = abs(entry - stop) / pv
    floor = float(rule["min_liquidity_points"]) + float(rule["safety_buffer_points"])
    cap = float(rule["max_stop_points"])
    if pts > cap:
        target = cap
    elif pts < floor:
        target = floor
    else:
        return stop
    clamped = entry - target * pv if side == "BUY" else entry + target * pv
    return round_price(clamped, symbol, cfg)


def target_ratios(cfg: Dict[str, Any], risk: Dict[str, Any] | None = None,
                  default_min_tp1_rr: float = DEFAULT_MIN_TP1_RR) -> Dict[str, float]:
    """default_min_tp1_rr=0.0 reproduces the old VALIDATOR semantics (skip the
    check when the key is absent); the target law itself enforces 0.8."""
    canon = _block(cfg, "targets")
    risk = risk if risk is not None else ((cfg or {}).get("risk_settings") or {})
    def _pick(canon_key: str, legacy_key: str, default: float) -> float:
        if _f(canon.get(canon_key), 0.0) > 0:
            return _f(canon.get(canon_key))
        return _f(risk.get(legacy_key), default)
    return {
        "min_tp1_rr": _pick("min_tp1_rr", "min_tp1_rr", default_min_tp1_rr) or default_min_tp1_rr,
        "tp2_multiple": _pick("tp2_multiple", "min_tp2_multiple_of_tp1", DEFAULT_TP2_MULTIPLE) or DEFAULT_TP2_MULTIPLE,
        "max_beyond_points": _pick("max_beyond_points", "max_tp2_beyond_tp1_points", DEFAULT_MAX_TP2_BEYOND_POINTS),
    }


def target_ratios_for_symbol(cfg: Dict[str, Any], symbol: Any,
                             risk: Dict[str, Any] | None = None,
                             default_min_tp1_rr: float = DEFAULT_MIN_TP1_RR) -> Dict[str, float]:
    """Per-symbol target ratios (R26.6) — single source, mirrors the stop law.

    The instrument spec's trading_rules.targets (max_beyond 450 on forex vs
    200 on gold; WTI 100) overrides the canonical block. Every door sizing
    targets must call THIS so a symbol's wider pool-search band is honoured.
    """
    ratios = target_ratios(cfg, risk, default_min_tp1_rr)
    try:
        spec = get_instrument(cfg, symbol) or {}
        inst_tgt = ((spec.get("trading_rules") or {}).get("targets")) or None
        if isinstance(inst_tgt, dict):
            for key in ("min_tp1_rr", "tp2_multiple", "max_beyond_points"):
                if key in inst_tgt and _f(inst_tgt.get(key), 0.0) > 0:
                    ratios[key] = _f(inst_tgt[key])
    except Exception:  # noqa: BLE001 - fall back to the base ratios
        pass
    return ratios


def scalp_rr_floors(config: dict | None = None) -> dict:
    """R25.4 (operator 2026-08-28): the SCALP row's own RR floors.

    The R25-2 scalp geometry is fixed-stop (350 system pts) with a
    midpoint partial and a pending-level final, so it validates under its
    own floors (r25_scalp.rr_floors), NOT the day-trade 0.8R/1.5R pair.
    Owned here like every rule key - callers never read the keys directly.
    """
    cfg = (config or {}).get("r25_scalp") or {}
    floors = cfg.get("rr_floors") or {}
    return {
        "min_tp1_rr": float(floors.get("min_tp1_rr", 0.5) or 0.5),
        "min_tp2_rr": float(floors.get("min_tp2_rr", 1.0) or 1.0),
    }


def targets_law(
    *,
    direction: str,
    entry: float,
    risk_price: float,
    levels: List[float] | None,
    cfg: Dict[str, Any],
    symbol: str,
    risk_cfg: Dict[str, Any] | None = None,
) -> Tuple[float, float, bool]:
    """(tp1, tp2, used_pool) under the operator's target law.

    TP1 = a real pool within max_beyond of the 0.8R rung, else the rung.
    TP2 = double the TP1 distance; a pool AFTER the adjusted level within
    max_beyond (200 pts) is a better objective and wins (farthest in band).
    """
    ratios = target_ratios_for_symbol(cfg, symbol, risk_cfg)
    max_beyond = points_to_price(ratios["max_beyond_points"], symbol)

    def _dist(level: float) -> float:
        return abs(level - entry)

    ordered = sorted(
        {lv for lv in (levels or []) if _f(lv, 0.0) > 0 and
         ((lv > entry) if direction == "BUY" else (lv < entry))},
        key=_dist,
    )

    # BUILD 18 (2026-08-20): per-instrument absolute target caps. Gold ships
    # liquidity objectives ~2% away; on WTI the same law shipped TP2 477 pts
    # (5.5% of price) from round-number pools. Far pools beyond the caps are
    # DROPPED before the band math, so the 0.8R rung / 2xTP1 fallbacks ship
    # instead. No cap key (0) = historical behaviour unchanged.
    _tgt_cfg = ((cfg or {}).get("trading_rules") or {}).get("targets") or {}
    _max_tp2_pts = _f(_tgt_cfg.get("max_tp2_points"), 0.0)
    if _max_tp2_pts > 0:
        _cap_price = points_to_price(_max_tp2_pts, symbol)
        ordered = [lv for lv in ordered if _dist(lv) <= _cap_price]

    def _level(rr_r: float) -> float:
        return entry + risk_price * rr_r if direction == "BUY" else entry - risk_price * rr_r

    d_ratio = _dist(_level(ratios["min_tp1_rr"]))
    tp1_pools = [lv for lv in ordered if d_ratio <= _dist(lv) <= d_ratio + max_beyond]
    used_pool = bool(tp1_pools)
    tp1 = min(tp1_pools, key=_dist) if tp1_pools else _level(ratios["min_tp1_rr"])

    d1 = _dist(tp1)
    d2_default = ratios["tp2_multiple"] * d1
    beyond = [lv for lv in ordered if d2_default < _dist(lv) <= d2_default + max_beyond]
    if beyond:
        tp2 = max(beyond, key=_dist)
        used_pool = True
    else:
        tp2 = (entry + d2_default) if direction == "BUY" else (entry - d2_default)
    # BUILD 18: absolute clamp as a last line (a wide stop config could still
    # push the 2x rung past the cap; the cap is about DISTANCE, not R:R).
    if _max_tp2_pts > 0:
        _cap_price = points_to_price(_max_tp2_pts, symbol)
        if _dist(tp2) > _cap_price:
            tp2 = (entry + _cap_price) if direction == "BUY" else (entry - _cap_price)
            if _dist(tp2) < _dist(tp1):
                tp2 = tp1
    return round_price(tp1, symbol, cfg), round_price(tp2, symbol, cfg), used_pool


# ── trailing / breakeven ────────────────────────────────────────────────────

def trailing_params(cfg: Dict[str, Any], profile: str | None = None) -> Dict[str, Any]:
    """Single source for trailing, with the precedence the engine always had:

        canonical trading_rules.trailing  >  specialised profile  >  root
        trade_management  >  default_profile  >  legacy trailing_stop.

    2026-08-07 "150/40 للكل": the shipped config carries the canonical block,
    so every profile gets 150/40 regardless. Legacy configs without the
    canonical block keep the old profile freedom (root outranks
    default_profile; specialised profiles outrank root). early_breakeven
    follows the same chain (unification covered trailing only).
    """
    canon = _block(cfg, "trailing")
    profiles = ((cfg or {}).get("trade_management") or {}).get("profiles") or {}
    pname = profile or "default_profile"
    prof = profiles.get(pname) or {}
    is_default = pname == "default_profile"
    tm = (cfg or {}).get("trade_management") or {}
    ts = (cfg or {}).get("trailing_stop") or {}
    out = dict(DEFAULT_TRAILING)

    def _pick(canon_k: str | None, prof_k: str, tm_k: str, ts_k: str, dflt: float) -> float:
        if canon_k and _f(canon.get(canon_k), 0.0) > 0:
            return _f(canon.get(canon_k))
        if not is_default and _f(prof.get(prof_k), 0.0) > 0:
            return _f(prof.get(prof_k))
        if _f(tm.get(tm_k), 0.0) > 0:
            return _f(tm.get(tm_k))
        if _f(prof.get(prof_k), 0.0) > 0:
            return _f(prof.get(prof_k))
        if _f(ts.get(ts_k), 0.0) > 0:
            return _f(ts.get(ts_k))
        return dflt

    out["enabled"] = bool(canon.get("enabled", prof.get("trailing_enabled",
        tm.get("trailing_stop_enabled", ts.get("enabled", out["enabled"])))) or out["enabled"])
    out["distance_points"] = _pick("distance_points", "trailing_distance_points",
                                   "trailing_distance_points", "trailing_distance",
                                   out["distance_points"])
    out["step_points"] = _pick("step_points", "trailing_step_points",
                               "trailing_step_points", "trailing_step",
                               out["step_points"])
    # 2026-08-07 (operator): early breakeven unified at 150 for ALL profiles;
    # the canonical key now outranks profiles like the rest of trailing.
    out["early_breakeven_points"] = _pick("early_breakeven_points", "early_breakeven_points",
                                          "early_breakeven_points", "early_breakeven_points",
                                          200.0)
    out["activation_at"] = str(canon.get("activation_at", tm.get("trailing_activation_at", "TP1")))
    return out


# ── display wording (phase 3) ───────────────────────────────────────────────

def stop_rule_note(cfg: Dict[str, Any]) -> str:
    """The one sentence every card prints about the stop rule; built from the
    live numbers so a config change rewrites every card automatically."""
    r = stop_rule(cfg)
    return (f"Execution stop set by the operator liquidity rule "
            f"(ignore <{r['min_liquidity_points']:.0f} pts, "
            f"+{r['safety_buffer_points']:.0f} safety, "
            f"cap {r['max_stop_points']:.0f}).")


def post_tp2_note(cfg: Dict[str, Any]) -> str:
    r = post_tp2_rule(cfg)
    window = f"{r['window_hours']:g}h"
    return (f"Post-TP2 same-direction re-entry blocked within "
            f"{r['min_distance_points']:.0f} pts of the exhausted TP2 for "
            f"{window} (absolute, no early release).")


# ── post-TP2 re-entry ───────────────────────────────────────────────────────

def post_tp2_rule(cfg: Dict[str, Any]) -> Dict[str, Any]:
    raw = _block(cfg, "post_tp2") or (cfg or {}).get("post_tp2_reentry") or {}
    out = dict(DEFAULT_POST_TP2)
    if _f(raw.get("min_distance_points"), 0.0) > 0:
        out["min_distance_points"] = _f(raw.get("min_distance_points"))
    if _f(raw.get("window_hours"), 0.0) > 0:
        out["window_hours"] = _f(raw.get("window_hours"))
    out["enabled"] = bool(raw.get("enabled", True))
    return out
