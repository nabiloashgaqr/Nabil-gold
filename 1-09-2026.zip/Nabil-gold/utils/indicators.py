"""Technical indicator calculations for the XAU/USD AI signal bot.

الدوال هنا مكتوبة بدون مكتبات مدفوعة، وتعتمد على Python القياسي فقط حتى تعمل
بسلاسة داخل GitHub Actions. جميع الدوال تقبل إما قائمة أسعار إغلاق أو قائمة
شموع OHLCV بالشكل: {open, high, low, close, volume, time}.
"""

from __future__ import annotations

import math
from statistics import mean, pstdev
from typing import Any, Dict, Iterable, List, Sequence

Number = float | int
Candle = Dict[str, Any]


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _series(data: Sequence[Candle] | Sequence[Number], key: str = "close") -> List[float]:
    """Extract a float series from candles or a numeric list."""
    if not data:
        return []
    first = data[0]
    if isinstance(first, dict):
        return [_as_float(item.get(key)) for item in data if isinstance(item, dict)]  # type: ignore[arg-type]
    return [_as_float(item) for item in data]  # type: ignore[arg-type]


def calculate_sma(data: Sequence[Candle] | Sequence[Number], period: int) -> List[float | None]:
    """Calculate Simple Moving Average list."""
    values = _series(data)
    if period <= 0:
        raise ValueError("period must be positive")
    result: List[float | None] = []
    for index in range(len(values)):
        if index + 1 < period:
            result.append(None)
        else:
            result.append(mean(values[index + 1 - period : index + 1]))
    return result


def calculate_ema(data: Sequence[Candle] | Sequence[Number], period: int) -> List[float | None]:
    """Calculate Exponential Moving Average list."""
    values = _series(data)
    if period <= 0:
        raise ValueError("period must be positive")
    if not values:
        return []

    multiplier = 2 / (period + 1)
    result: List[float | None] = []
    ema: float | None = None

    for index, price in enumerate(values):
        if index + 1 < period:
            result.append(None)
            continue
        if ema is None:
            ema = mean(values[index + 1 - period : index + 1])
        else:
            ema = (price - ema) * multiplier + ema
        result.append(ema)
    return result


def calculate_rsi(data: Sequence[Candle] | Sequence[Number], period: int = 14) -> List[float | None]:
    """Calculate RSI using Wilder smoothing."""
    values = _series(data)
    if period <= 0:
        raise ValueError("period must be positive")
    if len(values) < period + 1:
        return [None for _ in values]

    rsi_values: List[float | None] = [None] * len(values)
    gains: List[float] = []
    losses: List[float] = []

    for i in range(1, period + 1):
        change = values[i] - values[i - 1]
        gains.append(max(change, 0.0))
        losses.append(abs(min(change, 0.0)))

    avg_gain = mean(gains)
    avg_loss = mean(losses)

    def _rsi(gain: float, loss: float) -> float:
        if loss == 0:
            return 100.0
        rs = gain / loss
        return 100 - (100 / (1 + rs))

    rsi_values[period] = _rsi(avg_gain, avg_loss)

    for i in range(period + 1, len(values)):
        change = values[i] - values[i - 1]
        gain = max(change, 0.0)
        loss = abs(min(change, 0.0))
        avg_gain = ((avg_gain * (period - 1)) + gain) / period
        avg_loss = ((avg_loss * (period - 1)) + loss) / period
        rsi_values[i] = _rsi(avg_gain, avg_loss)

    return rsi_values


def calculate_macd(
    data: Sequence[Candle] | Sequence[Number],
    fast: int = 12,
    slow: int = 26,
    signal: int = 9,
) -> Dict[str, List[float | None] | Dict[str, float]]:
    """Calculate MACD, signal line and histogram."""
    values = _series(data)
    if not values:
        empty: List[float | None] = []
        return {"macd": empty, "signal": empty, "histogram": empty, "latest": {"macd": 0.0, "signal": 0.0, "histogram": 0.0}}

    ema_fast = calculate_ema(values, fast)
    ema_slow = calculate_ema(values, slow)
    macd_line: List[float | None] = []
    for f_val, s_val in zip(ema_fast, ema_slow):
        macd_line.append(None if f_val is None or s_val is None else f_val - s_val)

    # Signal EMA over available MACD values while preserving indexes.
    valid_macd = [x for x in macd_line if x is not None]
    valid_signal = calculate_ema(valid_macd, signal) if valid_macd else []
    signal_line: List[float | None] = [None] * len(macd_line)
    valid_index = 0
    for i, m_val in enumerate(macd_line):
        if m_val is None:
            continue
        signal_line[i] = valid_signal[valid_index] if valid_index < len(valid_signal) else None
        valid_index += 1

    histogram: List[float | None] = []
    for m_val, s_val in zip(macd_line, signal_line):
        histogram.append(None if m_val is None or s_val is None else m_val - s_val)

    latest_macd = _last_number(macd_line)
    latest_signal = _last_number(signal_line)
    latest_hist = _last_number(histogram)
    return {
        "macd": macd_line,
        "signal": signal_line,
        "histogram": histogram,
        "latest": {"macd": latest_macd, "signal": latest_signal, "histogram": latest_hist},
    }


def calculate_bollinger_bands(
    data: Sequence[Candle] | Sequence[Number],
    period: int = 20,
    std_dev: float = 2.0,
) -> Dict[str, List[float | None] | Dict[str, float]]:
    """Calculate Bollinger Bands."""
    values = _series(data)
    upper: List[float | None] = []
    middle: List[float | None] = []
    lower: List[float | None] = []

    for index in range(len(values)):
        if index + 1 < period:
            upper.append(None)
            middle.append(None)
            lower.append(None)
            continue
        window = values[index + 1 - period : index + 1]
        mid = mean(window)
        deviation = pstdev(window) if len(window) > 1 else 0.0
        middle.append(mid)
        upper.append(mid + std_dev * deviation)
        lower.append(mid - std_dev * deviation)

    return {
        "upper": upper,
        "middle": middle,
        "lower": lower,
        "latest": {"upper": _last_number(upper), "middle": _last_number(middle), "lower": _last_number(lower)},
    }


def calculate_atr(data: Sequence[Candle], period: int = 14) -> List[float | None]:
    """Calculate Average True Range."""
    if not data:
        return []
    true_ranges: List[float] = []
    previous_close: float | None = None
    for candle in data:
        high = _as_float(candle.get("high"))
        low = _as_float(candle.get("low"))
        close = _as_float(candle.get("close"))
        if previous_close is None:
            tr = high - low
        else:
            tr = max(high - low, abs(high - previous_close), abs(low - previous_close))
        true_ranges.append(max(tr, 0.0))
        previous_close = close

    atr: List[float | None] = []
    current_atr: float | None = None
    for index, tr in enumerate(true_ranges):
        if index + 1 < period:
            atr.append(None)
        elif current_atr is None:
            current_atr = mean(true_ranges[index + 1 - period : index + 1])
            atr.append(current_atr)
        else:
            current_atr = ((current_atr * (period - 1)) + tr) / period
            atr.append(current_atr)
    return atr


def calculate_pivot_points(high: float, low: float, close: float) -> Dict[str, float]:
    """Calculate classic daily pivot points."""
    pivot = (high + low + close) / 3
    return {
        "pivot": pivot,
        "r1": (2 * pivot) - low,
        "s1": (2 * pivot) - high,
        "r2": pivot + (high - low),
        "s2": pivot - (high - low),
        "r3": high + 2 * (pivot - low),
        "s3": low - 2 * (high - pivot),
    }


def calculate_fibonacci_levels(high: float, low: float) -> Dict[str, float]:
    """Calculate Fibonacci retracement levels between high and low."""
    if high < low:
        high, low = low, high
    diff = high - low
    return {
        "23.6": high - diff * 0.236,
        "38.2": high - diff * 0.382,
        "50.0": high - diff * 0.500,
        "61.8": high - diff * 0.618,
        "78.6": high - diff * 0.786,
    }


def detect_swing_points(data: Sequence[Candle], lookback: int = 5) -> Dict[str, List[Dict[str, Any]]]:
    """Detect swing highs and swing lows with a local window."""
    highs: List[Dict[str, Any]] = []
    lows: List[Dict[str, Any]] = []
    if len(data) < (lookback * 2) + 1:
        return {"highs": highs, "lows": lows}

    for index in range(lookback, len(data) - lookback):
        high = _as_float(data[index].get("high"))
        low = _as_float(data[index].get("low"))
        left = data[index - lookback : index]
        right = data[index + 1 : index + lookback + 1]
        if all(high >= _as_float(c.get("high")) for c in left + right):
            highs.append({"index": index, "price": high, "time": data[index].get("time")})
        if all(low <= _as_float(c.get("low")) for c in left + right):
            lows.append({"index": index, "price": low, "time": data[index].get("time")})
    return {"highs": highs, "lows": lows}


def detect_support_resistance(data: Sequence[Candle], lookback: int = 50) -> Dict[str, List[float]]:
    """Detect nearest support and resistance levels from recent swings."""
    recent = list(data[-lookback:]) if len(data) > lookback else list(data)
    swings = detect_swing_points(recent, lookback=3)
    supports = _cluster_levels([point["price"] for point in swings["lows"]])
    resistances = _cluster_levels([point["price"] for point in swings["highs"]])

    # Fallback to simple extrema if swings are scarce.
    if not supports and recent:
        lows = sorted({_as_float(c.get("low")) for c in recent})
        supports = lows[:3]
    if not resistances and recent:
        highs = sorted({_as_float(c.get("high")) for c in recent}, reverse=True)
        resistances = sorted(highs[:3])

    return {"supports": supports[:5], "resistances": resistances[:5]}


def _cluster_levels(levels: Iterable[float], tolerance: float = 1.5) -> List[float]:
    """Group nearby levels into rounded representative prices."""
    ordered = sorted(levels)
    if not ordered:
        return []
    clusters: List[List[float]] = [[ordered[0]]]
    for level in ordered[1:]:
        if abs(level - mean(clusters[-1])) <= tolerance:
            clusters[-1].append(level)
        else:
            clusters.append([level])
    # Stronger clusters first, then price order.
    ranked = sorted(clusters, key=lambda cluster: (-len(cluster), mean(cluster)))
    return [round(mean(cluster), 2) for cluster in ranked]


def _last_number(values: Sequence[float | None], default: float = 0.0) -> float:
    for value in reversed(values):
        if value is not None and not math.isnan(float(value)):
            return float(value)
    return default


# ── Wilder ADX (2026-08-19 upgrade: canonical location) ──────────────────────
# Ported verbatim from TechnicalAgent._calculate_adx_proxy (operator 2026-08-14)
# so the pinned Wilder reference test values remain identical, but the indicator
# now lives in the canonical indicators module and is reusable by other agents
# (market regime feed, future Stochastic/Ichimoku additions).

def calculate_dmi(candles: Sequence[Candle], period: int = 14) -> Dict[str, Any]:
    """Wilder-smoothed +DI/-DI/ADX. Returns latest values + full ADX series."""
    if len(candles) < period * 2 + 2:
        return {"adx": 0.0, "plus_di": 0.0, "minus_di": 0.0, "adx_series": []}
    plus_dm: List[float] = []
    minus_dm: List[float] = []
    tr_values: List[float] = []
    for i in range(1, len(candles)):
        high = _as_float(candles[i].get("high"))
        low = _as_float(candles[i].get("low"))
        close_prev = _as_float(candles[i - 1].get("close"))
        high_prev = _as_float(candles[i - 1].get("high"))
        low_prev = _as_float(candles[i - 1].get("low"))
        up_move = high - high_prev
        down_move = low_prev - low
        plus_dm.append(up_move if up_move > down_move and up_move > 0 else 0.0)
        minus_dm.append(down_move if down_move > up_move and down_move > 0 else 0.0)
        tr_values.append(max(high - low, abs(high - close_prev), abs(low - close_prev)))
    smoothed_tr = sum(tr_values[:period])
    smoothed_pdm = sum(plus_dm[:period])
    smoothed_mdm = sum(minus_dm[:period])
    pdi = mdi = 0.0
    dx_values: List[float] = []
    for i in range(period, len(tr_values)):
        smoothed_tr = smoothed_tr - smoothed_tr / period + tr_values[i]
        smoothed_pdm = smoothed_pdm - smoothed_pdm / period + plus_dm[i]
        smoothed_mdm = smoothed_mdm - smoothed_mdm / period + minus_dm[i]
        pdi = 100 * smoothed_pdm / max(smoothed_tr, 0.0001)
        mdi = 100 * smoothed_mdm / max(smoothed_tr, 0.0001)
        dx_values.append(abs(pdi - mdi) / max(pdi + mdi, 0.0001) * 100)
    if len(dx_values) < period:
        dx = dx_values[-1] if dx_values else 0.0
        return {"adx": dx, "plus_di": pdi, "minus_di": mdi, "adx_series": list(dx_values)}
    adx = sum(dx_values[:period]) / period
    adx_series: List[float] = [adx]
    for dx in dx_values[period:]:
        adx = (adx * (period - 1) + dx) / period
        adx_series.append(adx)
    return {"adx": adx, "plus_di": pdi, "minus_di": mdi, "adx_series": adx_series}


def calculate_adx(candles: Sequence[Candle], period: int = 14) -> Tuple[float, str]:
    """Wilder ADX + direction label (BULLISH/BEARISH/NEUTRAL).

    Returns the same tuple contract as TechnicalAgent._calculate_adx_proxy so
    callers can migrate one line at a time.
    """
    dmi = calculate_dmi(candles, period)
    label = (
        "BULLISH" if dmi["plus_di"] > dmi["minus_di"]
        else "BEARISH" if dmi["minus_di"] > dmi["plus_di"]
        else "NEUTRAL"
    )
    return float(dmi["adx"]), label


# ── Stochastic + Ichimoku (2026-08-19 agent fixes) ───────────────────────────

def calculate_stochastic(
    candles: Sequence[Candle], period: int = 14, smooth_k: int = 3, smooth_d: int = 3
) -> Dict[str, Any]:
    """Slow Stochastic %K/%D (period, smooth_k, smooth_d).

    Non-voting timing confirmer for the technical agent: overbought/oversold
    state + crossover direction, used as evidence only.
    """
    if len(candles) < period + smooth_k + smooth_d:
        return {"k": 50.0, "d": 50.0, "state": "INSUFFICIENT_DATA", "crossover": "NONE"}
    k_raw: List[float] = []
    for i in range(period - 1, len(candles)):
        window = candles[i - period + 1 : i + 1]
        high = max(_as_float(c.get("high")) for c in window)
        low = min(_as_float(c.get("low")) for c in window)
        close = _as_float(candles[i].get("close"))
        k_raw.append(50.0 if high == low else (close - low) / (high - low) * 100.0)

    def _sma_series(values: List[float], period_s: int) -> List[float]:
        out: List[float] = []
        for i in range(len(values)):
            if i < period_s - 1:
                out.append(values[i])
            else:
                out.append(sum(values[i - period_s + 1 : i + 1]) / period_s)
        return out

    k_series = _sma_series(k_raw, smooth_k)
    d_series = _sma_series(k_series, smooth_d)
    k = round(k_series[-1], 2)
    d = round(d_series[-1], 2)
    crossover = "NONE"
    if len(k_series) >= 2:
        if k_series[-1] > d_series[-1] and k_series[-2] <= d_series[-2]:
            crossover = "BULLISH"
        elif k_series[-1] < d_series[-1] and k_series[-2] >= d_series[-2]:
            crossover = "BEARISH"
    state = "OVERBOUGHT" if k >= 80 else "OVERSOLD" if k <= 20 else "NEUTRAL"
    return {"k": k, "d": d, "state": state, "crossover": crossover}


def calculate_ichimoku(
    candles: Sequence[Candle],
    tenkan: int = 9, kijun: int = 26, senkou_b: int = 52, displacement: int = 26,
) -> Dict[str, Any]:
    """Ichimoku cloud: tenkan/kijun/senkou A/B + cloud state at the latest bar.

    Non-voting trend filter for the technical agent: price above/below the
    cloud and cloud colour are evidence only, exposed for the gold daily-bias
    context.
    """
    if len(candles) < senkou_b + displacement:
        return {"state": "INSUFFICIENT_DATA", "cloud": "NONE", "tenkan": 0.0,
                "kijun": 0.0, "senkou_a": 0.0, "senkou_b": 0.0}

    def _mid(i: int, period: int) -> float:
        window = candles[i - period + 1 : i + 1]
        highs = [_as_float(c.get("high")) for c in window]
        lows = [_as_float(c.get("low")) for c in window]
        return (max(highs) + min(lows)) / 2.0

    idx = len(candles) - 1
    tenkan_val = _mid(idx, tenkan)
    kijun_val = _mid(idx, kijun)
    # senkou spans are displaced forward; the CURRENT cloud = spans computed
    # `displacement` bars ago.
    past = idx - displacement
    if past < senkou_b - 1:
        return {"state": "INSUFFICIENT_DATA", "cloud": "NONE", "tenkan": round(tenkan_val, 2),
                "kijun": round(kijun_val, 2), "senkou_a": 0.0, "senkou_b": 0.0}
    senkou_a = (_mid(past, tenkan) + _mid(past, kijun)) / 2.0
    senkou_b = _mid(past, senkou_b)
    close = _as_float(candles[idx].get("close"))

    cloud_top, cloud_bottom = max(senkou_a, senkou_b), min(senkou_a, senkou_b)
    if close > cloud_top:
        state = "ABOVE_CLOUD"
    elif close < cloud_bottom:
        state = "BELOW_CLOUD"
    else:
        state = "INSIDE_CLOUD"
    cloud = "BULLISH" if senkou_a > senkou_b else "BEARISH" if senkou_b > senkou_a else "FLAT"

    return {
        "state": state,
        "cloud": cloud,
        "tenkan": round(tenkan_val, 2),
        "kijun": round(kijun_val, 2),
        "senkou_a": round(senkou_a, 2),
        "senkou_b": round(senkou_b, 2),
        "close": round(close, 2),
    }
