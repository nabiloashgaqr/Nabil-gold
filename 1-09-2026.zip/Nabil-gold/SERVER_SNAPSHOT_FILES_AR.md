# ملفات السيرفر التي يجب حفظها مع كل سناب شوت (باك-أب)

> القاعدة: **الكود يُستعاد من الحزمة، لكن الحالة الحيّة لا تُستعاد إلا من الباك-أب.**
> احفظ ما يلي من `C:\Nabil-gold` قبل أي ترقية أو إعادة تثبيت أو انتقال VPS.

## 1) أهم ملف على الإطلاق

| الملف | لماذا يُحفظ؟ |
|---|---|
| `config.json` | كل إعداداتك الحيّة: رأس المال، المخاطر، الأعلام، **توكِن تيليجرام و chat_id ومفاتيح البيانات/الـAPI**. بدونها النظام يفقد هويته. (بداخل الحزمة نسخة مرجعية مُعقَّمة فقط — لا تستبدل ملفك بها). |
| `.env` (إن وُجد) | أسرار البيئة (مفاتيح، توكِنات) التي لا تُكتب داخل config. (الحزمة فيها `.env.template` فقط). |

## 2) حالة التداول والحفظ الدائم (لا يمكن إعادة توليدها)

مجلد `storage\` كاملاً — خصوصاً:

| الملف/المجلد | المحتوى |
|---|---|
| `storage\trades.json` | **دفتر الصفقات الكامل** (كل الصفقات، الحالات، PnL، اللقطات). أهم ملف بيانات. |
| `storage\decision_audit.json` | سجل تدقيق كل قرار (الوكلاء، الأوزان، أسباب القبول/الرفض). |
| `storage\session_plans.json` | خطط الجلسات وخرائط المناطق وحالاتها. |
| `storage\reflection_memory.json` | ذاكرة وكيل التأمل (تثابر بين الدورات). |
| `storage\path_performance\trades.json` | أداء كل مسار تنفيذ (إحصاء PATH 1..6). |
| `storage\learning_history.json` | تاريخ تعلّم الوكلاء/الذاكرة. |
| `storage\setup_state_events.json` | أحداث حالات النماذج. |
| `storage\trade_compliance_audit.jsonl` | سجل تدقيق الامتثال. |
| `storage\hourly_status_last.json` | آخر حالة مُرسلة (منع تكرار الرسائل). |
| `storage\shared_market_data.json` | بيانات السوق المشتركة بين الرموز. |
| `storage\macro_context.json`, `storage\news_events.json`, `storage\post_news_tracker.json` | سياق الماكرو والأخبار ومتتبّع ما بعد الخبر. |
| `storage\macro\`, `storage\oil\`, `storage\sentiment\`, `storage\correlation\` | كاش الأحداث الاقتصادية، EIA/أوبك، تقارير COT، إغلاقات الارتباط. |
| `storage\llm\` (gemini_quota_state / status_cache) | حالة حصّة Gemini وكاشها. |
| `storage\model_calibration\auction_flow_v1.json` | معايرة نموذج المزاد. |
| `storage\agent_books\` | سجل كِتب الوكلاء (أدلة القبول). |
| `storage\margin_guard_peak.json` | ذروة مراقب الهامش. |

## 3) قواعد بيانات تيكات المزاد (Auction Flow) — تتراكم ولا يُعاد بناؤها بسرعة

- `storage\auction_flow.sqlite3` (الذهب)
- `storage\auction_flow_wtiusd.sqlite3`
- `storage\auction_flow_eurusd.sqlite3`
- `storage\auction_flow_gbpusd.sqlite3`
- `storage\auction_flow_usdcad.sqlite3`
- `storage\auction_flow_usdjpy.sqlite3`
- `storage\telegram_delivery_dedup.sqlite3` (منع تكرار إرسال التيليجرام)

## 4) ملفات جذر حالة التشغيل

| الملف | المحتوى |
|---|---|
| `pre_arm_vote_rejections.jsonl` | سجل رفض تصويت المسار 6 (تدقيق). |
| `heartbeat.json`, `tick_heartbeat.json` | نبضات حياة روبوت التحليل وبوت التيك. |
| `analyst_labels.json` (و `analyst_comparisons.json`, `analyst_comparison_summary.json` إن وُجدت) | بطاقات/ملصقات المحلل وقياس الأداء. |
| أي ملف `*.halt` / `.demo_halt` | حالة الإيقاف المؤقت إن وُجدت. |

## 5) مجلد السجلّات (اختياري لكن مفيد للتشخيص بعد الحوادث)

- `logs\` كاملاً (مثل `logs\tick_manager.log`, سجلات التحليل) — تُساعد في تشريح أي حادث بعد الترقية.

## 6) مجلد التشخيصات (اختياري)

- `diagnostics\` — تقارير `full_check_*` و`trade_compliance_*` التاريخية (مرجع للمقارنة قبل/بعد).

---

### ما الذي **لا** يلزم حفظه؟ (يُستعاد/يُعاد توليده)
- مجلد الكود كله (`services\ agents\ scripts\ utils\ tests\` …) — موجود في الحزمة.
- `config.REFERENCE_SANITIZED.json`, `.env.template` — داخل الحزمة.
- `__pycache__\`, `.pytest_cache\`, `storage\aux_cache\` — كاش يُعاد توليده.
- ملفات `.lock`.
- **بعد R26.7 لم يعد هناك ظل:** مجلد `storage\shadow\` و`storage\r25_scalp_shadow.jsonl` و`pre_arm_ote_shadow_arms.jsonl` إن بقيت على جهاز قديم — **لا تُرجِعها**؛ السكربت يحذفها.

### أوامر باك-أب سريعة (PowerShell)
```powershell
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$dest  = "D:\backups\Nabil-gold\snapshot_$stamp"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item "C:\Nabil-gold\config.json"            $dest
Copy-Item "C:\Nabil-gold\.env"                   $dest -ErrorAction SilentlyContinue
Copy-Item "C:\Nabil-gold\storage"                $dest\storage -Recurse -Force
Copy-Item "C:\Nabil-gold\logs"                   $dest\logs    -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item "C:\Nabil-gold\diagnostics"            $dest\diagnostics -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item "C:\Nabil-gold\pre_arm_vote_rejections.jsonl" $dest -ErrorAction SilentlyContinue
Copy-Item "C:\Nabil-gold\heartbeat.json","C:\Nabil-gold\tick_heartbeat.json" $dest -ErrorAction SilentlyContinue
Copy-Item "C:\Nabil-gold\analyst_labels.json"    $dest -ErrorAction SilentlyContinue
Write-Host "Backup done: $dest"
```

> تنبيه أمان: ملفات `config.json` و`.env` تحوي توكِنات — لا تشاركها ولا ترفعها في أي مستودع عام؛ خزّنها مشفّرة/مضغوطة بكلمة سر إن أمكن.
