# -*- coding: utf-8 -*-
"""R25.15: config carries the dollar-risk law + the leverage OPTION.

The operator asked (2026-08-28):
  - risk budget per trade in DOLLARS: band [$270, $400] by pair liquidity
    (his gold reference: 400 pts @0.1 = $400 is the ceiling)
  - "اجعل الرافعة 1:100 كخيار" - the planning leverage is a CONFIG OPTION
    (100/500/1000; current account = 1000), honoured by the margin planner.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

from services.risk_usd import expected_margin, lot_for_stop  # noqa: E402

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
EX = CONFIG.get("execution") or {}


def test_config_carries_the_dollar_band_and_the_leverage_option():
    band = EX.get("risk_usd_per_trade") or {}
    assert band.get("min") == 270 and band.get("max") == 400
    assert band.get("target") == 270
    assert EX.get("margin_planning_leverage") in (100, 500, 1000)


def test_lot_solver_honours_the_band_for_all_six_pairs():
    stops = {"XAU/USD": 400, "WTI/USD": 160, "EUR/USD": 200,
             "GBP/USD": 250, "USD/CAD": 200, "USD/JPY": 250}
    from services.risk_usd import usd_loss
    for sym, stop in stops.items():
        lot = lot_for_stop(sym, stop, CONFIG)
        loss = usd_loss(sym, stop, lot)
        assert 269.5 <= loss <= 400.5, "%s: $%.2f outside the band" % (sym, loss)


def test_margin_planner_uses_the_configured_leverage():
    px = {"XAU/USD": 4476.14, "WTI/USD": 82.65, "EUR/USD": 1.15883, "GBP/USD": 1.33398}
    # at the shipped default (1000): gold 0.10 lot = 10 oz = $44,761 notional
    m = expected_margin("XAU/USD", 0.10, px=px["XAU/USD"], config=CONFIG)
    assert m == pytest_approx(44.7614)  # 0.10*100*4476.14/1000
    # switching the option to 100 multiplies the expected margin x10
    m100 = expected_margin("XAU/USD", 0.10, px=px["XAU/USD"], leverage=100)
    assert m100 == pytest_approx(447.614)


def pytest_approx(x):
    import pytest
    return pytest.approx(x)
