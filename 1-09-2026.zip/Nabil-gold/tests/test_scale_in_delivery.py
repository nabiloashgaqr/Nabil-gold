"""Regression tests for fixed-risk scale-in Telegram delivery.

A previous bug built the scale-in Telegram text but never sent it, then checked an
undefined variable named ``delivered``. In production this made the scale-in path
fail silently inside the analysis wrapper.

Updated: scale-in now uses the exact shared Entry/Thesis admission evaluator
(3 agents, or 2 + Macro/Gemini, net >=72) plus the same risk filters.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Dict, List

from scripts.run_analysis import _check_scale_in


@dataclass
class _AIResponse:
    success: bool = True
    content: str = '{"scale_in": true, "confidence": 80, "reason": "near resistance retest"}'


class _FakeAI:
    async def _call_ai(self, prompt: str, agent_type: str) -> _AIResponse:
        return _AIResponse()


class _FakeDB:
    def __init__(self) -> None:
        self.saved: List[Dict[str, Any]] = []

    def new_trade_id(self) -> str:
        return "TRADE_TEST_SCALE_IN"

    def save_trade(self, decision: Dict[str, Any]) -> str:
        self.saved.append(decision)
        return str(decision["trade_id"])


class _FakeTelegram:
    def __init__(self) -> None:
        self.messages: List[str] = []

    def send_message(self, text: str, urgent: bool = False) -> bool:
        self.messages.append(text)
        return True


# Minimal config with all required sections for scale-in consensus check
_SCALE_IN_CONFIG = {
    "order_execution": {
        "entry_style": "fixed_risk",
        "fixed_risk": {
            "scale_in_enabled": True,
            "scale_in_trigger_points": 50,
            "scale_in_max": 1,
            "scale_in_size_ratio": 0.5,
        },
    },
    "signal_requirements": {
        "min_agents_agree": 3,
        "min_consensus_confidence": 72,
        "agent_min_confidence": 67,
        "two_agent_entry": {
            "enabled": True,
            "min_agents_agree": 2,
            "min_consensus_confidence": 72,
            "macro_confirmation": {"enabled": True, "min_confidence": 55},
            "gemini_confirmation": {"enabled": True, "min_confidence": 70},
        },
    },
    "agent_weights": {
        "technical": 0.20,
        "multitimeframe": 0.15,
        "classical": 0.25,
        "smc": 0.20,
        "price_action": 0.20,
    },
}

# All 5 agents agree on SELL → passes consensus check
_SELL_CONSENSUS_RESULTS = {
    "current_price": 4000.0,
    "news": {"can_trade": True, "market_status": "SAFE"},
    "news_ai": {"available": False},
    "technical": {"signal": "SELL", "confidence": 85},
    "multitimeframe": {"signal": "SELL", "confidence": 78},
    "classical": {"signal": "SELL", "confidence": 80, "resistance_levels": [4005.0]},
    "smc": {"signal": "SELL", "confidence": 75},
    "price_action": {"signal": "SELL", "confidence": 82},
    "risk": {
        "approved": True,
        "checks": {
            "max_open_trades_filter": True,
            "max_daily_signals_filter": True,
            "atr_filter": True,
            "spread_filter": True,
            "consecutive_losses_filter": True,
        },
    },
}

_OPEN_TRADE_SELL = [
    {
        "id": "TRADE_PARENT",
        "type": "SELL",
        "entry_price": 3989.7,
        "stop_loss": 4009.7,
        "tp1": 3963.03,
        "tp2": 3943.03,
    }
]


def test_scale_in_sends_message_then_saves_trade() -> None:
    db = _FakeDB()
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(_SCALE_IN_CONFIG, _SELL_CONSENSUS_RESULTS, _OPEN_TRADE_SELL, db, tg))

    assert len(tg.messages) == 1
    assert "Scale-In" in tg.messages[0]
    assert "TRADE_PARENT" in tg.messages[0]
    assert len(db.saved) == 1
    assert db.saved[0]["trade_id"] == "TRADE_TEST_SCALE_IN"
    assert db.saved[0]["signal"]["scale_in"] is True


def test_scale_in_not_saved_if_telegram_delivery_fails() -> None:
    class _FailingTelegram(_FakeTelegram):
        def send_message(self, text: str, urgent: bool = False) -> bool:
            self.messages.append(text)
            return False

    db = _FakeDB()
    tg = _FailingTelegram()

    asyncio.run(_check_scale_in(_SCALE_IN_CONFIG, _SELL_CONSENSUS_RESULTS, _OPEN_TRADE_SELL, db, tg))

    assert len(tg.messages) == 1
    assert db.saved == []


def test_scale_in_blocked_by_two_qualified_opponents() -> None:
    """UPDATED 2026-08-18b: the add needs NO fresh consensus — the parent
    earned it at entry. The only agent condition is the hard veto: >= 2
    QUALIFIED opponents block the add; anything less is allowed."""
    vetoed = dict(_SELL_CONSENSUS_RESULTS)
    vetoed["technical"] = {"signal": "SELL", "confidence": 85}
    vetoed["multitimeframe"] = {"signal": "BUY", "confidence": 80}   # opponent 1
    vetoed["classical"] = {"signal": "WAIT", "confidence": 40, "resistance_levels": [4005.0]}
    vetoed["smc"] = {"signal": "WAIT", "confidence": 30}
    vetoed["price_action"] = {"signal": "BUY", "confidence": 80}     # opponent 2

    db = _FakeDB()
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(_SCALE_IN_CONFIG, vetoed, _OPEN_TRADE_SELL, db, tg))

    assert len(tg.messages) == 0
    assert len(db.saved) == 0


def test_scale_in_runs_under_hybrid_entry_style() -> None:
    """UPDATED 2026-08-18c: the add engine lived behind entry_style ==
    'fixed_risk' and that guard survived the system's move to 'hybrid' —
    the whole path silently never ran in production. Live evidence: a BUY
    sat 156 points into a clean-book pullback (opp=0 for a full hour) and
    the log carried no Scale-in line at all. Hybrid must work."""
    cfg = dict(_SCALE_IN_CONFIG)
    cfg["order_execution"] = dict(cfg["order_execution"])
    cfg["order_execution"]["entry_style"] = "hybrid"
    db = _FakeDB()
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(cfg, _SELL_CONSENSUS_RESULTS, _OPEN_TRADE_SELL, db, tg))

    assert len(tg.messages) == 1, "hybrid style must not silence the add engine"
    assert len(db.saved) == 1


def test_scale_in_still_refuses_unknown_entry_styles() -> None:
    """market-only style has no add semantics; the exit is logged, not silent."""
    cfg = dict(_SCALE_IN_CONFIG)
    cfg["order_execution"] = dict(cfg["order_execution"])
    cfg["order_execution"]["entry_style"] = "market"
    db = _FakeDB()
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(cfg, _SELL_CONSENSUS_RESULTS, _OPEN_TRADE_SELL, db, tg))

    assert tg.messages == []
    assert db.saved == []


def test_every_early_exit_is_named_in_the_source() -> None:
    """No silent returns before the parent loop — the 2026-08-18 lesson."""
    import io
    src = io.open("scripts/run_analysis.py", encoding="utf-8").read()
    head = src.split("async def _check_scale_in")[1]
    head = head.split("for parent in open_trades")[0]
    assert 'entry_style=%s supports no adds' in head
    assert 'scale_in_enabled=false' in head
    assert 'news hard block active' in head


def test_scale_in_ignores_trade_grade_rejection() -> None:
    """The 2026-08-18 13:11 case: gold 150+ pts into a clean-book pullback
    (zero opponents), every MECHANICAL filter green — yet the add was
    refused by the aggregate risk['approved']=False, whose culprit was
    trade_grade_filter. The moment grade is computed like a NEW signal's
    and is poor at every deep pullback by construction, so honouring it
    resurrects the consensus requirement the operator removed. Grade must
    not gate an add; mechanical filters still do."""
    graded_out = dict(_SELL_CONSENSUS_RESULTS)
    graded_out["risk"] = {
        "approved": False,                       # aggregate says no...
        "rejection_reason": "Trade grade too low",
        "checks": {
            "trade_grade_filter": False,         # ...because of grade only
            "max_open_trades_filter": True,
            "max_daily_signals_filter": True,
            "atr_filter": True,
            "spread_filter": True,
            "consecutive_losses_filter": True,
        },
    }
    db = _FakeDB()
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(_SCALE_IN_CONFIG, graded_out, _OPEN_TRADE_SELL, db, tg))

    assert len(tg.messages) == 1, "a grade veto crept back into the add path"
    assert len(db.saved) == 1


def test_scale_in_mechanical_filters_still_block() -> None:
    """The flip side: a genuinely failing MECHANICAL filter (spread) still
    refuses the add, and the log names it."""
    wide_spread = dict(_SELL_CONSENSUS_RESULTS)
    wide_spread["risk"] = {
        "approved": False,
        "checks": {
            "trade_grade_filter": True,
            "max_open_trades_filter": True,
            "max_daily_signals_filter": True,
            "atr_filter": True,
            "spread_filter": False,              # the real market problem
            "consecutive_losses_filter": True,
        },
    }
    db = _FakeDB()
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(_SCALE_IN_CONFIG, wide_spread, _OPEN_TRADE_SELL, db, tg))

    assert tg.messages == []
    assert db.saved == []


def test_scale_in_success_writes_a_log_line() -> None:
    """The first live add (2026-08-18 13:31) entered SILENTLY: refusals all
    name themselves but the accept path wrote nothing, and the operator
    met a second MT5 position with a log full of blocks. Success must log
    with the same discipline as failure."""
    import io
    src = io.open("scripts/run_analysis.py", encoding="utf-8").read()
    assert "Scale-in ENTERED for %s %s" in src
    entered_at = src.index("Scale-in ENTERED for %s %s")
    save_at = src.index("database.save_trade(decision)", entered_at)
    assert entered_at < save_at, "the ENTERED line must precede the save"


def test_scale_in_allowed_with_one_opponent_and_no_consensus() -> None:
    """The flip side of the veto: ONE opponent (even a loud one) does not
    block, and no fresh 3-agent consensus is demanded any more."""
    thin = dict(_SELL_CONSENSUS_RESULTS)
    thin["technical"] = {"signal": "SELL", "confidence": 85}
    thin["multitimeframe"] = {"signal": "WAIT", "confidence": 40}
    thin["classical"] = {"signal": "WAIT", "confidence": 40, "resistance_levels": [4005.0]}
    thin["smc"] = {"signal": "WAIT", "confidence": 30}
    thin["price_action"] = {"signal": "BUY", "confidence": 80}       # lone opponent

    db = _FakeDB()
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(_SCALE_IN_CONFIG, thin, _OPEN_TRADE_SELL, db, tg))

    assert len(tg.messages) == 1
    assert len(db.saved) == 1


def test_scale_in_allows_exact_shared_two_agent_plus_macro_path() -> None:
    results = dict(_SELL_CONSENSUS_RESULTS)
    results.update({
        "technical": {"signal": "SELL", "confidence": 82},
        "multitimeframe": {"signal": "WAIT", "confidence": 40},
        "classical": {"signal": "WAIT", "confidence": 40, "resistance_levels": [4005.0]},
        "smc": {"signal": "SELL", "confidence": 78},
        "price_action": {"signal": "WAIT", "confidence": 40},
        "macro_fundamental": {
            "macro_direction": {"bias": "BEARISH_GOLD", "confidence": 60},
        },
    })
    db = _FakeDB()
    tg = _FakeTelegram()
    asyncio.run(_check_scale_in(_SCALE_IN_CONFIG, results, _OPEN_TRADE_SELL, db, tg))
    assert len(tg.messages) == 1
    assert len(db.saved) == 1
    assert "TWO_AGENT_MACRO" in db.saved[0]["reasons"][0]


def test_scale_in_blocked_when_risk_filter_fails() -> None:
    """Scale-in respects risk filters (max_open_trades, etc.)."""
    risk_failed = dict(_SELL_CONSENSUS_RESULTS)
    risk_failed["risk"] = {
        "approved": False,
        "checks": {
            "max_open_trades_filter": False,
            "max_daily_signals_filter": True,
            "atr_filter": True,
            "spread_filter": True,
            "consecutive_losses_filter": True,
        },
    }

    db = _FakeDB()
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(_SCALE_IN_CONFIG, risk_failed, _OPEN_TRADE_SELL, db, tg))

    assert len(tg.messages) == 0
    assert len(db.saved) == 0
