# -*- coding: utf-8 -*-
"""R21 (2026-08-27): STRUCTURAL per-symbol separation for auction stores.

Operator incident: the USD/JPY auction witness was vetoed ALL DAY with
"Spread 170.0 pts exceeds 25.0-pt guard" while the broker's live JPY
spread was 7.0 pts (verified directly via MetaTrader5 at the same times).
170.0 = a foreign-priced 0.17 tick spread divided by the JPY point size
(0.001). The verdict: foreign-priced ticks can land in a symbol's store
and the spread guard then vetoes with another symbol's scale.

Operator directive: a FINAL separation - every symbol's feed is bound to
its own store, and any mixing must fail CLOSED with a loud named reason,
never silently. Pinned here:
  * every store write stamps meta['symbol']; the agent refuses a store
    stamped for ANOTHER symbol (FOREIGN_STORE_REFUSED);
  * the agent cross-checks the store's last mid against the symbol's own
    current price; a wrong-symbol feed is off by orders of the point size
    and is refused (FOREIGN_FEED_REFUSED) - the exact 170.0 regression
    (gold-scale 0.17 mid/spread inside a JPY store) can never score again;
  * an UNSTAMPED legacy store bootstraps (first run after deploy stamps
    it) instead of bricking every existing store;
  * all six symbols derive DISTINCT store paths; gold keeps the
    historical unsuffixed path.
"""
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from agents.auction_flow_agent import AuctionFlowAgent
from services.auction_flow_store import AuctionFlowStore

SYMBOLS = ["XAU/USD", "WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"]

BASE_CONFIG = {
    "symbol": "XAU/USD",
    "auction_flow": {
        "enabled": True,
        "storage_path": "storage/auction_flow.sqlite3",
        "calibration_path": "storage/model_calibration/auction_flow_v1.json",
        "calibration_required": False,
        "min_unique_ticks_5m": 60,
        "max_tick_age_seconds": 5,
        "max_heartbeat_age_seconds": 10,
        "min_calibration_samples": 300,
    },
    "signal_requirements": {"agent_min_confidence": 65},
}


def _cfg_for(symbol):
    cfg = dict(BASE_CONFIG)
    cfg["symbol"] = symbol
    return cfg


def _fresh_state(symbol_price=1.1639, last_spread=0.00007, mid=None,
                 stamp="EUR/USD", tick_age=0.5):
    """A healthy-looking state whose numbers are internally consistent."""
    mid = mid if mid is not None else symbol_price
    return {
        "session_ticks": 500,
        "health": {
            "store_symbol": stamp,
            "last_tick_age_seconds": tick_age,
            "heartbeat_age_seconds": 2.0,
            "unique_ticks_5m": 15000,
            "current_spread": last_spread,
            "last_mid": mid,
            "path": "storage/auction_flow_eurusd.sqlite3",
        },
    }


class TestStoreStamping(unittest.TestCase):
    def test_store_writes_its_symbol_stamp_on_heartbeat(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = AuctionFlowStore(os.path.join(tmp, "s.sqlite3"), symbol="USD/JPY")
            store.mark_heartbeat()
            self.assertEqual((store.meta() or {}).get("symbol"), "USD/JPY")

    def test_unstamped_store_reads_as_none(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = AuctionFlowStore(os.path.join(tmp, "s.sqlite3"))
            store.mark_heartbeat()
            self.assertFalse((store.meta() or {}).get("symbol"))


class TestForeignStoreRefused(unittest.TestCase):
    def test_agent_refuses_store_stamped_for_another_symbol(self):
        agent = AuctionFlowAgent(_cfg_for("USD/JPY"))
        state = _fresh_state(symbol_price=159.42, last_spread=0.007,
                             mid=159.42, stamp="XAU/USD")
        problem = agent._data_problem(state, 0.001, "USD/JPY",
                                      reference_price=159.42)
        self.assertIsNotNone(problem)
        self.assertEqual(problem[0], "FOREIGN_STORE_REFUSED")
        self.assertIn("XAU/USD", problem[1])

    def test_agent_accepts_own_stamp(self):
        agent = AuctionFlowAgent(_cfg_for("EUR/USD"))
        state = _fresh_state(stamp="EUR/USD")
        problem = agent._data_problem(state, 0.00001, "EUR/USD",
                                      reference_price=1.1639)
        self.assertIsNone(problem)


class TestForeignFeedRefused(unittest.TestCase):
    def test_the_exact_vps_regression_gold_scale_in_jpy_store(self):
        # gold-scale numbers (spread 0.17, mid ~4586) arriving in the JPY
        # store: the pre-R21 guard turned this into "Spread 170.0 pts" and
        # vetoed the witness all day. R21 refuses it as a wrong-symbol feed.
        agent = AuctionFlowAgent(_cfg_for("USD/JPY"))
        state = _fresh_state(symbol_price=159.42, last_spread=0.17,
                             mid=4586.48, stamp="USD/JPY")
        problem = agent._data_problem(state, 0.001, "USD/JPY",
                                      reference_price=159.42)
        self.assertIsNotNone(problem)
        self.assertEqual(problem[0], "FOREIGN_FEED_REFUSED")

    def test_wrong_mid_with_correct_stamp_still_refused(self):
        agent = AuctionFlowAgent(_cfg_for("USD/JPY"))
        state = _fresh_state(symbol_price=159.42, last_spread=0.007,
                             mid=1.1639, stamp="USD/JPY")
        problem = agent._data_problem(state, 0.001, "USD/JPY",
                                      reference_price=159.42)
        self.assertIsNotNone(problem)
        self.assertEqual(problem[0], "FOREIGN_FEED_REFUSED")

    def test_no_reference_price_skips_mid_gate_but_stamp_remains(self):
        agent = AuctionFlowAgent(_cfg_for("EUR/USD"))
        state = _fresh_state(stamp="EUR/USD", mid=999.99)
        problem = agent._data_problem(state, 0.00001, "EUR/USD",
                                      reference_price=None)
        self.assertIsNone(problem)  # mid gate needs a reference; stamp ok

    def test_unstamped_legacy_store_bootstraps(self):
        agent = AuctionFlowAgent(_cfg_for("EUR/USD"))
        state = _fresh_state(stamp="")
        problem = agent._data_problem(state, 0.00001, "EUR/USD",
                                      reference_price=1.1639)
        self.assertIsNone(problem)


class TestPerSymbolPaths(unittest.TestCase):
    def test_six_symbols_six_distinct_store_paths(self):
        paths = set()
        for sym in SYMBOLS:
            agent = AuctionFlowAgent(_cfg_for(sym))
            paths.add(str(Path(agent.store.path).name))
            self.assertEqual(agent._agent_symbol, sym)
        self.assertEqual(len(paths), len(SYMBOLS))
        self.assertIn("auction_flow.sqlite3", paths)  # gold keeps history
        self.assertIn("auction_flow_usdjpy.sqlite3", paths)


if __name__ == "__main__":
    unittest.main()
