# -*- coding: utf-8 -*-
"""BUILD31-R17: the analysis entry-gate probe + gate-exit audit visibility.

The funnel used to report 'ZERO decision-audit rows -> never cycled' for a
symbol that was actually being REFUSED at a data gate (no data / source not
reliable / price sanity) because those exits wrote nothing. Now:
  * scripts/probe_analysis_gate.py names the exact gate per symbol, and
  * every gate exit writes a named decision_audit row.
"""
import os
import sys
import unittest
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from scripts.probe_analysis_gate import evaluate_payload  # noqa: E402


def _payload(source="mt5", price=1.164, grade="HIGH", supports=True, candles=220):
    return {
        "source": source,
        "current_price": price,
        "source_integrity": {"reliability_grade": grade,
                             "supports_signal_generation": supports},
        "timeframes": {"5m": [1] * candles, "15m": [1] * candles},
    }


class TestGateEvaluation(unittest.TestCase):
    def test_healthy_mt5_payload_passes(self):
        gate, detail = evaluate_payload(
            "EUR/USD", _payload(), (0.4, 3.5), True)
        self.assertEqual(gate, "PASS")
        self.assertEqual(detail["tf_candles"]["5m"], 220)

    def test_empty_payload_is_data_none(self):
        gate, _ = evaluate_payload("EUR/USD", None, (0.4, 3.5), False)
        self.assertEqual(gate, "DATA_NONE")

    def test_unsupported_source_is_named(self):
        # no integrity stamp + non-twelvedata source -> SOURCE_RELIABLE
        payload = {"source": "mt5", "current_price": 1.164,
                   "timeframes": {"5m": [1]}}
        gate, detail = evaluate_payload("EUR/USD", payload, (0.4, 3.5), False)
        self.assertEqual(gate, "SOURCE_RELIABLE")
        self.assertFalse(detail["supports_signal_generation"])

    def test_price_outside_sanity_is_named(self):
        gate, detail = evaluate_payload(
            "EUR/USD", _payload(price=4597.0), (0.4, 3.5), True)
        self.assertEqual(gate, "PRICE_SANITY")
        self.assertEqual(detail["sanity_range"], [0.4, 3.5])


class TestGateExitsWriteAuditRows(unittest.TestCase):
    def test_run_analysis_gate_exits_call_decision_audit(self):
        src = (Path(ROOT) / "scripts" / "run_analysis.py").read_text(encoding="utf-8")
        # each of the three outage exits is immediately followed by a named row
        self.assertEqual(src.count('stage="data gate", outcome="REFUSED"'), 3)
        self.assertIn("No market data returned", src)
        self.assertIn("cannot support signal generation", src)
        self.assertIn("failed the sanity range", src)


if __name__ == "__main__":
    unittest.main()
