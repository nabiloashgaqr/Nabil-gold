# -*- coding: utf-8 -*-
"""BUILD31-R16: the forex promotion patch (config_patch/APPLY_R16_PROMOTION.py).

Promotes a pair to calibration_required=true ONLY when its calibration file
passes the SAME checks the agent applies (checksum/version/samples/symbol/
logistic). Anything doubtful is held at false - fail closed, like the rest
of the system.
"""
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _find_promotion_script():
    """The installer copies config_patch into the project; the repo also
    keeps a root-level copy. Accept either, skip honestly if neither."""
    for rel in (os.path.join("config_patch", "APPLY_R16_PROMOTION.py"),
                "APPLY_R16_PROMOTION.py"):
        cand = os.path.join(ROOT, rel)
        if os.path.exists(cand):
            return cand
    return None


SCRIPT = _find_promotion_script()

CONFIG = {
    "symbol": "XAU/USD",
    "auction_flow": {"calibration_version": "auction_flow_v1",
                     "min_calibration_samples": 300,
                     "calibration_path": "storage/model_calibration/auction_flow_v1.json"},
    "instruments": [
        {"symbol": "XAU/USD", "auction_flow": {"calibration_required": True}},
        {"symbol": "WTI/USD", "auction_flow": {"calibration_required": False}},
        {"symbol": "EUR/USD", "auction_flow": {"calibration_required": False}},
        {"symbol": "GBP/USD", "auction_flow": {"calibration_required": False}},
        {"symbol": "USD/CAD", "auction_flow": {"calibration_required": False}},
        {"symbol": "USD/JPY", "auction_flow": {"calibration_required": False}},
    ],
}


def _signed(payload):
    raw = dict(payload)
    raw["checksum"] = hashlib.sha256(
        json.dumps(raw, ensure_ascii=False, sort_keys=True,
                   separators=(",", ":")).encode("utf-8")).hexdigest()
    return json.dumps(raw, indent=2)


def _setup(tmp: Path):
    (tmp / "storage" / "model_calibration").mkdir(parents=True)
    (tmp / "config.json").write_text(json.dumps(CONFIG), encoding="utf-8")
    cal = tmp / "storage" / "model_calibration"
    good = {"version": "auction_flow_v1", "sample_count": 1200,
            "symbol": "EURUSD.s", "logistic": {"a": 1.2, "b": 0.8}}
    (cal / "auction_flow_v1_eurusd.json").write_text(_signed(good), encoding="utf-8")
    # WTI joined the promotion set (operator order): valid file -> promoted
    (cal / "auction_flow_v1_wtiusd.json").write_text(
        _signed({"version": "auction_flow_v1", "sample_count": 1500,
                 "symbol": "WTI.s", "logistic": {"a": 1.0, "b": 0.7}}),
        encoding="utf-8")
    # tampered: valid signature, then edited -> checksum mismatch
    tampered = json.loads(_signed({**good, "symbol": "GBPUSD.s", "sample_count": 900}))
    tampered["sample_count"] = 777
    (cal / "auction_flow_v1_gbpusd.json").write_text(json.dumps(tampered), encoding="utf-8")
    # usdcad: intentionally missing file
    (cal / "auction_flow_v1_usdjpy.json").write_text(
        _signed({**good, "symbol": "USDJPY.s", "sample_count": 120}), encoding="utf-8")


@unittest.skipUnless(SCRIPT, "promotion script not installed (config_patch missing)")
class TestR16Promotion(unittest.TestCase):
    def test_promotes_only_valid_and_holds_doubtful(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            _setup(tmp)
            proc = subprocess.run([sys.executable, SCRIPT, "--root", td],
                                  capture_output=True, text=True, timeout=120)
            self.assertEqual(proc.returncode, 0, proc.stderr[-800:])
            self.assertIn("PROMOTED (calibration valid)", proc.stdout)
            self.assertIn("promoted 2 pair(s): WTI/USD, EUR/USD", proc.stdout)
            self.assertIn("checksum mismatch", proc.stdout)   # GBP/USD held
            self.assertIn("file MISSING", proc.stdout)        # USD/CAD held
            self.assertIn("samples 120 < required 300", proc.stdout)  # USD/JPY held

            cfg = json.loads((tmp / "config.json").read_text(encoding="utf-8"))
            state = {i["symbol"]: i["auction_flow"]["calibration_required"]
                     for i in cfg["instruments"]}
            self.assertTrue(state["EUR/USD"])    # promoted
            self.assertTrue(state["WTI/USD"])    # promoted (valid file)
            self.assertTrue(state["XAU/USD"])    # gold untouched by the script
            self.assertFalse(state["GBP/USD"])   # fail-closed
            self.assertFalse(state["USD/CAD"])   # fail-closed
            self.assertFalse(state["USD/JPY"])   # fail-closed

    def test_idempotent_second_run(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            _setup(tmp)
            subprocess.run([sys.executable, SCRIPT, "--root", td],
                           capture_output=True, text=True, timeout=120)
            proc2 = subprocess.run([sys.executable, SCRIPT, "--root", td],
                                   capture_output=True, text=True, timeout=120)
            self.assertEqual(proc2.returncode, 0, proc2.stderr[-800:])
            self.assertIn("Nothing changed", proc2.stdout)

    def test_fixing_the_file_then_rerun_promotes_it(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            _setup(tmp)
            subprocess.run([sys.executable, SCRIPT, "--root", td],
                           capture_output=True, text=True, timeout=120)
            # operator replaces the bad GBP/USD file with a good one
            cal = tmp / "storage" / "model_calibration" / "auction_flow_v1_gbpusd.json"
            cal.write_text(_signed({"version": "auction_flow_v1", "sample_count": 950,
                                    "symbol": "GBPUSD.s",
                                    "logistic": {"a": 1.1, "b": 0.9}}), encoding="utf-8")
            proc2 = subprocess.run([sys.executable, SCRIPT, "--root", td],
                                   capture_output=True, text=True, timeout=120)
            self.assertEqual(proc2.returncode, 0, proc2.stderr[-800:])
            self.assertIn("promoted 1 pair(s): GBP/USD", proc2.stdout)


if __name__ == "__main__":
    unittest.main()
