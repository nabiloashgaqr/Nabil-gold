"""R25.8/R25.11: the Gemini model law - new-generation chain ONLY (3.5/3.1/3.6).

Operator order 2026-08-28: the production chain is the new generation
exclusively; a persisted resolved_model outside the configured chain is
discarded on load, and out-of-chain leftovers are purged from the state
file on the next write.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.llm_review import GeminiReviewService  # noqa: E402
from services.model_law import ALLOWED_MODELS  # noqa: E402

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
LLM = CONFIG["llm_review"]


def test_chain_is_new_generation_only():
    assert LLM["model"] == "gemini-3.1-flash-lite"          # 500/day primary
    assert LLM["fallback_models"] == [
        "gemini-3.5-flash-lite",                             # 500/day
        "gemini-3.6-flash",                                  # 20/day
        "gemini-3.5-flash",                                  # 20/day
    ]
    # R25.12: the law is positive and single-sourced (services/model_law.py)
    assert LLM["model"] in ALLOWED_MODELS
    assert set(LLM["fallback_models"]) <= ALLOWED_MODELS


def test_stale_resolved_latch_outside_the_chain_is_discarded(tmp_path, monkeypatch):
    GeminiReviewService.reset_quota_state()
    monkeypatch.setenv("GEMINI_API_KEY", "probe-key")
    state = tmp_path / "quota_state.json"
    state.write_text(json.dumps({
        "version": 2, "quota_expiry_utc": "", "exhausted_models": [],
        "unavailable_models": ["gemini-legacy-404"],
        "resolved_model": "gemini-legacy-latch",       # an out-of-chain latch
        "auth_rejected": False, "updated_at": 1787314315}), encoding="utf-8")
    svc = GeminiReviewService({**CONFIG,
                               "llm_review": {**LLM,
                                              "quota_state_path": str(state)}})
    assert GeminiReviewService._resolved_model == ""   # purged on load
    assert svc.model == "gemini-3.1-flash-lite"          # the configured primary


def test_resolved_latch_inside_the_chain_is_still_honoured_when_no_explicit():
    GeminiReviewService.reset_quota_state()
    import tempfile
    from pathlib import Path as _P
    state = _P(tempfile.mkdtemp()) / "quota_state.json"
    state.write_text(json.dumps({
        "version": 2, "quota_expiry_utc": "", "exhausted_models": [],
        "unavailable_models": [],
        "resolved_model": "gemini-3.6-flash",            # a configured candidate
        "auth_rejected": False, "updated_at": 1787314315}), encoding="utf-8")
    llm = {k: v for k, v in LLM.items() if k != "model"}  # NO explicit model
    llm["quota_state_path"] = str(state)
    svc = GeminiReviewService({"llm_review": llm})
    assert svc.model == "gemini-3.6-flash"
