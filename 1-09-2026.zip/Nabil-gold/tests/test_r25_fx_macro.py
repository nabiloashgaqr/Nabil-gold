"""R25.7 (2026-08-28): M1 — the FX-4 macro in the two-agent path.

Operator laws:
  * M1: macro judging is a SYMBOL LIST - the multi-instrument macro agent
    confirms the two-agent path for the FX-4 pairs; gold keeps its old law.
  * R25.7-C retired the dedicated forex strong-structure lane.
  * R25.8 (2026-08-29): PATH 9 is REBORN as the LIQUIDITY SWEEP RAID REVERSAL.
    The retired FX-4 lane no longer occupies PATH 9 — it is demoted to a
    LEGACY history bucket (LEGACY_STRONG_STRUCTURE) so old rows never degrade
    to UNKNOWN, while nothing can stamp it and the active PATH 9 is the sweep
    reversal.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.execution_paths import (  # noqa: E402
    PATH_9, LEGACY_STRONG_STRUCTURE, PATH_DEFINITIONS, path_id_from_admission,
)
from services.thesis_consensus import evaluate_strong_structure  # noqa: E402
from scripts.run_analysis import validate_signal_before_send  # noqa: E402

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
FX4 = ["EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"]


def test_fx4_macro_law_is_shipped():
    assert "forex_strong_structure" not in CONFIG  # the lane's block is gone
    mac = CONFIG["signal_requirements"]["two_agent_entry"]["macro_confirmation"]
    assert mac["enabled"] is True
    assert sorted(mac["symbols"]) == sorted(["XAU/USD"] + FX4)
    assert float(mac["min_confidence"]) == 55.0
    assert "gemini" in (CONFIG["signal_requirements"]["family_diversity"]
                        ["single_family_confirmers"])


# ── the old FX-4 lane: refusal stub survives; PATH 9 is reborn ──────────────

def test_retired_strong_structure_lane_never_admits():
    r = evaluate_strong_structure("SELL", {"price_action": {"direction": "SELL",
                                                            "confidence": 90}}, CONFIG)
    assert r["allow"] is False and "retired" in (r["reason"] or "").lower()


def test_path9_is_reborn_as_liquidity_sweep_reversal():
    assert PATH_9 == "PATH_9_LIQUIDITY_SWEEP_REVERSAL"
    d = PATH_DEFINITIONS[PATH_9]
    assert d["number"] == 9
    assert d["admission_path"] == "LIQUIDITY_SWEEP_REVERSAL"
    assert "SWEEP" in d["name"].upper()
    assert not d.get("legacy")
    assert path_id_from_admission("LIQUIDITY_SWEEP_REVERSAL") == PATH_9


def test_old_fx4_lane_demoted_to_legacy_bucket_not_path9():
    # The retired admission no longer activates PATH 9; it resolves to the
    # dedicated legacy history bucket (kept only so old rows report, never
    # stamped by any active path).
    assert LEGACY_STRONG_STRUCTURE != PATH_9
    assert PATH_DEFINITIONS[LEGACY_STRONG_STRUCTURE].get("legacy") is True
    assert path_id_from_admission("STRONG_STRUCTURE_CONFIRMED") == LEGACY_STRONG_STRUCTURE
    assert path_id_from_admission("STRONG_STRUCTURE_CONFIRMED") != PATH_9


def test_scalp_floors_stay_untouched_by_r25_7():
    sc = CONFIG["r25_scalp"]["rr_floors"]
    assert sc["min_tp1_rr"] == 0.5 and sc["min_tp2_rr"] == 1.0


def test_global_validation_law_stands_for_plain_rows():
    scalp = {"symbol": "XAU/USD", "decision": "SELL",
             "signal": {"order_type": "SELL_LIMIT",
                        "entry": {"kind": "LIMIT", "price": 4611.15},
                        "stop_loss": 4646.15, "tp1": 4591.49, "tp2": 4571.84},
             "current_price": 4612.56, "setup_context": {}}
    v = validate_signal_before_send(scalp, CONFIG, [])
    assert any("0.80R" in x for x in v), "paths 1-6 floors unchanged"
