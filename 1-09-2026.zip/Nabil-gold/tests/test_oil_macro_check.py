"""2026-08-19 build 14: oil macro health check tests (environment-isolated)."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import scripts.oil_macro_check as omc  # noqa: E402


def _run(root: Path) -> subprocess.CompletedProcess:
    script = Path(__file__).resolve().parents[1] / "scripts" / "oil_macro_check.py"
    return subprocess.run(
        [sys.executable, str(script), "--root", str(root)],
        capture_output=True, text=True, timeout=180,
    )


class TestSections:
    def _config(self):
        return {
            "oil_macro": {
                "enabled": True,
                "crack_enabled": True,
                "eia_path": "storage/oil/eia_weekly.json",
                "opec_path": "storage/oil/opec_context.json",
            },
            "signal_requirements": {
                "two_agent_entry": {
                    "oil_macro_confirmation": {"enabled": True, "min_confidence": 55},
                }
            },
            "symbols": [
                {"symbol": "XAU/USD", "enabled": True},
                {"symbol": "WTI/USD", "enabled": True},  # no mode -> LIVE
            ],
        }

    def test_config_section_live_mode(self, tmp_path):
        lines = omc.section_config(tmp_path, self._config())
        text = " | ".join(lines)
        assert "crack_enabled = True" in text
        assert "min_confidence=55" in text
        assert "LIVE (executes on MT5)" in text

    def test_files_missing_reported(self, tmp_path):
        lines, problems = omc.section_files(tmp_path, self._config())
        text = " | ".join(lines)
        assert "eia_weekly.json MISSING" in text
        assert "opec_context.json MISSING" in text
        assert problems == 2

    def test_files_filled_ok(self, tmp_path):
        oil = tmp_path / "storage" / "oil"
        oil.mkdir(parents=True)
        (oil / "eia_weekly.json").write_text(json.dumps({
            "week": "2026-08-14", "crude_change_mb": -4.0,
            "gasoline_change_mb": 1.0, "distillate_change_mb": -0.5,
            "refinery_util_pct": 92.3,
        }), encoding="utf-8")
        (oil / "opec_context.json").write_text(json.dumps({
            "tone": "CUT", "date": "2026-08-01",
        }), encoding="utf-8")
        lines, problems = omc.section_files(tmp_path, self._config())
        text = " | ".join(lines)
        assert "eia_weekly.json OK" in text
        assert "opec_context.json OK" in text
        assert problems == 0


class TestEndToEnd:
    def _fixture(self, root: Path) -> None:
        (root / "config.json").write_text(json.dumps({
            "oil_macro": {
                "enabled": True,
                "crack_enabled": True,
                "eia_path": "storage/oil/eia_weekly.json",
                "eia_history_path": "storage/oil/eia_history.json",
                "opec_path": "storage/oil/opec_context.json",
            },
            "signal_requirements": {
                "two_agent_entry": {
                    "oil_macro_confirmation": {"enabled": True, "min_confidence": 55},
                }
            },
            "symbols": [
                {"symbol": "XAU/USD", "enabled": True},
                {"symbol": "WTI/USD", "enabled": True},
            ],
        }), encoding="utf-8")

    def test_end_to_end_ascii_safe(self, tmp_path):
        self._fixture(tmp_path)
        out = _run(tmp_path)
        assert out.returncode == 0, out.stderr
        assert "OIL MACRO CHECK" in out.stdout
        assert "A) CONFIG" in out.stdout
        assert "D) AGENT RUN" in out.stdout
        assert "VERDICT:" in out.stdout

    def test_missing_config_still_runs(self, tmp_path):
        # no config.json -> load_config returns {}; the check must not crash
        out = _run(tmp_path)
        assert out.returncode == 0, out.stderr
        assert "OIL MACRO CHECK" in out.stdout
