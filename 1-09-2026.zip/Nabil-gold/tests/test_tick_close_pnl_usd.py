"""R25.15 convoy step 3 (tick side) — broker-closed rows carry pnl_usd.

The broker deal's own profit IS the real USD result. The tick close path now
stamps it on the row, and close_price keeps the symbol's own digits.
"""
from __future__ import annotations

import types
from datetime import datetime, timezone

from scripts.run_tick_manager import TickManager


class _DB:
    def __init__(self):
        self.updates = []

    def update_trade(self, tid, updates):
        self.updates.append((tid, dict(updates)))


def _executor_with_exit(price, profit):
    class _Ex:
        last_close = {}

        def __init__(self):
            self._exit = {"price": price, "profit": profit, "volume": 0.05,
                          "position": 777,
                          "time": datetime.now(timezone.utc).isoformat()}

        def _position_by_magic(self, magic):
            return None

        def last_exit(self, tid):
            return self._exit

    return _Ex()


def _tm():
    tm = TickManager({
        "trading_rules": {"stop": {
            "min_liquidity_points": 200,
            "safety_buffer_points": 70,
            "max_stop_points": 400,
        }},
    }, database=_DB())
    tm._notify = lambda text: None
    return tm


def test_broker_close_stamps_real_deal_profit_on_gbp_row():
    tm = _tm()
    row = {
        "id": "GBP-CLOSE", "symbol": "GBP/USD", "type": "SELL",
        "status": "OPEN", "entry_price": 1.35504, "stop_loss": 1.36504,
        "tp2": 1.34504, "mt5_ticket": 777, "close_price": None,
        "sl_moved_to_entry": True, "partial_close": True,
    }
    tick = types.SimpleNamespace(bid=1.34400, ask=1.34402)
    ex = _executor_with_exit(price=1.34504, profit=5.05)
    tm._handle_row(row, tick, ex, mt5=types.SimpleNamespace())
    tid, updates = tm.database.updates[-1]
    assert updates["status"] == "TP2_HIT"
    assert updates["pnl_usd"] == 5.05          # the BROKER's number
    assert updates["close_price"] == 1.34504   # 5 digits, not 1.35


def test_gold_broker_close_keeps_pnl_usd_and_two_digits():
    tm = _tm()
    row = {
        "id": "XAU-CLOSE", "symbol": "XAU/USD", "type": "BUY",
        "status": "OPEN", "entry_price": 4392.63, "stop_loss": 4368.0,
        "tp2": 4450.0, "mt5_ticket": 778, "close_price": None,
        "sl_moved_to_entry": False, "partial_close": False,
    }
    tick = types.SimpleNamespace(bid=4450.00, ask=4450.03)
    ex = _executor_with_exit(price=4450.0, profit=-442.70)
    tm._handle_row(row, tick, ex, mt5=types.SimpleNamespace())
    tid, updates = tm.database.updates[-1]
    assert updates["status"] == "TP2_HIT"
    assert updates["pnl_usd"] == -442.70
    assert updates["close_price"] == 4450.0
