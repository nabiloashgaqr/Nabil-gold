# -*- coding: utf-8 -*-
"""R25.9 (2026-08-31) tests for the post-diagnostic hardening fixes.

Covers:
  1) Auction-flow write-side price gate: a foreign symbol's tick (e.g. a gold
     ~4432 mid landing in the USD/JPY store) is REJECTED at ingest, while the
     symbol's own ticks are accepted; gate is fail-open without a range.
  2) execution_path_id provenance fallback so no trade row is saved with a
     null path when the admission carried it nested.
  3) reflection burn is recorded (in a temp file) when a trade closes at a loss.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def _tick(bid, ask, last, ts=1_700_000_000_000):
    return {"bid": bid, "ask": ask, "last": last, "time_msc": ts, "flags": 0}


def test_foreign_tick_rejected_for_jpy_store(tmp_path):
    from services.auction_flow_store import AuctionFlowStore
    store = AuctionFlowStore(str(tmp_path / "jpy.sqlite3"),
                             symbol="USD/JPY", price_range=(50.0, 300.0))
    # genuine JPY tick accepted
    assert store.record_tick(_tick(159.880, 159.890, 159.885)) is True
    # foreign gold tick (~4432) rejected
    assert store.record_tick(_tick(4432.10, 4432.40, 4432.25, ts=ts2())) is False
    assert store.rejected_foreign_ticks >= 1
    meta = store.meta()
    # last_mid must stay the JPY price, not the gold one
    assert float(meta["last_mid"]) < 300.0


def test_gold_range_accepts_gold_rejects_forex_price(tmp_path):
    from services.auction_flow_store import AuctionFlowStore
    store = AuctionFlowStore(str(tmp_path / "xau.sqlite3"),
                             symbol="XAU/USD", price_range=(1500.0, 6000.0))
    assert store.record_tick(_tick(4432.10, 4432.40, 4432.25)) is True
    # a stray forex-sized price in the gold store is rejected
    assert store.record_tick(_tick(1.15880, 1.15890, 1.15885, ts=ts2())) is False


def test_gate_is_fail_open_without_range(tmp_path):
    from services.auction_flow_store import AuctionFlowStore
    store = AuctionFlowStore(str(tmp_path / "open.sqlite3"), symbol=None)
    # no price_range => anything structurally valid is accepted (unchanged)
    assert store.record_tick(_tick(4432.10, 4432.40, 4432.25)) is True


def test_bulk_path_also_rejects_foreign(tmp_path):
    from services.auction_flow_store import AuctionFlowStore
    store = AuctionFlowStore(str(tmp_path / "bulk.sqlite3"),
                             symbol="USD/JPY", price_range=(50.0, 300.0))
    ticks = [_tick(159.880, 159.890, 159.885, 1_700_000_000_000),
             _tick(4432.10, 4432.40, 4432.25, 1_700_000_001_000),
             _tick(159.900, 159.910, 159.905, 1_700_000_002_000)]
    n = store.bulk_record_ticks(ticks)
    assert n == 2  # only the two JPY ticks counted
    assert float(store.meta()["last_mid"]) < 300.0


def test_resolve_execution_path_id_fallbacks():
    from services.database import DatabaseService
    r = DatabaseService._resolve_execution_path_id
    assert r({"execution_path_id": "PATH_5_X"}, {}) == "PATH_5_X"
    assert r({"execution_path": {"id": "PATH_9_LIQUIDITY_SWEEP_REVERSAL"}}, {}) \
        == "PATH_9_LIQUIDITY_SWEEP_REVERSAL"
    assert r({}, {"execution_path_id": "PATH_1_THREE_AGENT_CONSENSUS"}) \
        == "PATH_1_THREE_AGENT_CONSENSUS"
    assert r({}, {"path9": {"execution_path_id": "PATH_9_LIQUIDITY_SWEEP_REVERSAL"}}) \
        == "PATH_9_LIQUIDITY_SWEEP_REVERSAL"
    assert r({}, {}) is None


def test_reflection_burn_recorded_on_loss(tmp_path, monkeypatch):
    os.environ["PYTEST_CURRENT_TEST"] = "1"  # suppress inside service by default
    from services import reflection_agent as ra
    mem = tmp_path / "reflection_memory.json"
    agent = ra.ReflectionAgent({"reflection_agent": {"enabled": True}},
                               path=str(mem))
    agent.record_burn(symbol="USD/JPY", level=160.159, direction="BUY",
                      burn_type="stop_hit", trade_id="T1")
    agent2 = ra.ReflectionAgent({"reflection_agent": {"enabled": True}},
                                path=str(mem))
    active = agent2.active_burns("USD/JPY")
    assert len(active) == 1
    assert active[0]["direction"] == "BUY"
    # veto must block an immediate re-buy at essentially the same level
    verdict = agent2.review(symbol="USD/JPY", poi_level=160.16, direction="BUY")
    assert verdict.get("veto") is True


def ts2():
    return 1_700_000_010_000


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
