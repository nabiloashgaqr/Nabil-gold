# -*- coding: utf-8 -*-
"""R25.8 — PATH 9 (Liquidity Sweep Raid Reversal) + Regime Switcher +
Regime State Machine + Reflection Agent.

Pure, storage-free unit tests for the four new modules plus the execution-
path registry rebirth (PATH 9 active, old FX-4 lane demoted to a legacy
history bucket).
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from services import execution_paths as ep
from services.path9_reversal import evaluate_path9_reversal, detect_sweep, config_block as p9_cfg
from services.regime_switcher import (resolve_regime, apply_regime_switch,
                                      path_admitted, REGIME_TREND, REGIME_RANGE,
                                      REGIME_HIGH_VOL_NEWS)
from services.regime_state_machine import RegimeStateMachine
from services.reflection_agent import ReflectionAgent

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def _switcher_on():
    """A config view with the central regime switcher explicitly enabled.

    Production ships it OFF until the operator flips it (fail-open), so the
    routing tests turn it on explicitly.
    """
    cfg = json.loads(json.dumps(CONFIG))
    cfg.setdefault("regime_switcher", {})["enabled"] = True
    return cfg


# ───────────────────────────── PATH 9 registry ──────────────────────────────

def test_path9_is_liquidity_sweep_reversal():
    assert ep.PATH_9 == "PATH_9_LIQUIDITY_SWEEP_REVERSAL"
    d = ep.PATH_DEFINITIONS[ep.PATH_9]
    assert d["number"] == 9
    assert d["admission_path"] == "LIQUIDITY_SWEEP_REVERSAL"
    assert "SWEEP" in d["name"].upper()
    assert not d.get("legacy")


def test_liquidity_sweep_admission_stamps_path9():
    assert ep.path_id_from_admission("LIQUIDITY_SWEEP_REVERSAL") == ep.PATH_9
    snap: dict = {}
    ep.stamp_execution_path(snap, "LIQUIDITY_SWEEP_REVERSAL")
    assert snap["execution_path_id"] == ep.PATH_9
    assert snap["execution_path_number"] == 9


def test_old_fx4_admission_is_only_a_legacy_bucket():
    # The retired admission string no longer activates PATH 9; it resolves to
    # the dedicated legacy history bucket so old rows never go UNKNOWN.
    legacy = ep.path_id_from_admission("STRONG_STRUCTURE_CONFIRMED")
    assert legacy == ep.LEGACY_STRONG_STRUCTURE
    assert legacy != ep.PATH_9
    assert ep.PATH_DEFINITIONS[legacy].get("legacy") is True
    old_row = {"id": "OLD", "status": "TP2_HIT", "pnl_points": 10.0,
               "signal_snapshot": {}}
    ep.stamp_execution_path(old_row["signal_snapshot"], "STRONG_STRUCTURE_CONFIRMED")
    assert ep.resolve_execution_path(old_row)["id"] == ep.LEGACY_STRONG_STRUCTURE


# ───────────────────────── sweep detection ──────────────────────────────────

def _gold_cfg():
    # Gold point = 0.1; 100 points = $10 move.
    return CONFIG


def _tape(direction, confidence=72.0):
    """The MANDATORY auction/tape witness for PATH 9 (operator 2026-08-30)."""
    return {"direction": direction, "confidence": confidence,
            "responsive": True}


def _smc(direction, confidence=70.0, sweep_type="sell_side",
         confirmation="STRONG", with_trend=False):
    """The CONFIRMING SMC witness (boost only; never a gate)."""
    return {"direction": direction, "confidence": confidence,
            "recent_sweep": {"type": sweep_type, "confirmation": confirmation,
                             "with_trend": with_trend}}


def test_sell_side_sweep_admits_buy_reversal():
    """Price raids below PDL by a wide wick, closes back inside, M5 pins up."""
    pdl = 2600.0
    raid = {"open": 2603.0, "high": 2604.0, "low": 2580.0, "close": 2608.0}
    # low 2580 vs level 2600 -> excursion 20.0 price = 200 points; close above.
    m5_pin = {"open": 2601.0, "high": 2606.0, "low": 2582.0, "close": 2605.5}
    context = {"pdl": pdl, "pdh": 2660.0}
    v = evaluate_path9_reversal(symbol="XAU/USD", raid_candle=raid,
                                m5_candles=[raid, m5_pin], context=context,
                                flow=_tape("BUY"), smc=_smc("BUY", sweep_type="sell_side"),
                                config=_gold_cfg())
    assert v["allow"] is True
    assert v["direction"] == "BUY"
    assert v["sweep"]["sweep_side"] == "sell_side"
    assert v["admission_path"] == "LIQUIDITY_SWEEP_REVERSAL"
    assert v["entry"] and v["stop"] and v["tp1"] and v["tp2"]
    # Stop must be below entry for a BUY and within the gold absolute band.
    assert v["stop"] < v["entry"]
    # Tape witness is mandatory and signed; SMC confirms the counter-trend sweep.
    assert v["checks"]["flow"] and v["checks"]["flow"]["direction"] == "BUY"
    assert v["checks"]["smc"] and v["checks"]["smc"]["counter_trend_sweep"] is True


def test_buy_side_sweep_admits_sell_reversal():
    pdh = 2700.0
    raid = {"open": 2697.0, "high": 2720.0, "low": 2696.0, "close": 2692.0}
    m5_pin = {"open": 2699.0, "high": 2718.0, "low": 2694.0, "close": 2694.5}
    context = {"pdh": pdh, "pdl": 2640.0}
    v = evaluate_path9_reversal(symbol="XAU/USD", raid_candle=raid,
                                m5_candles=[raid, m5_pin], context=context,
                                flow=_tape("SELL"), config=_gold_cfg())
    assert v["allow"] is True
    assert v["direction"] == "SELL"
    assert v["sweep"]["sweep_side"] == "buy_side"
    assert v["stop"] > v["entry"]
    # No SMC read -> still trades (orphan raid); witness is the tape only.
    assert v["checks"]["flow"] and v["checks"]["smc"] is None


def test_close_outside_level_is_breakout_not_raid():
    # Sweeps the low but CLOSES below it = continuation breakdown, not a raid.
    pdl = 2600.0
    raid = {"open": 2602.0, "high": 2603.0, "low": 2580.0, "close": 2585.0}
    v = evaluate_path9_reversal(symbol="XAU/USD", raid_candle=raid,
                                m5_candles=[raid], context={"pdl": pdl},
                                config=_gold_cfg())
    assert v["allow"] is False
    assert any("sweep" in r for r in v["reasons"])


def test_no_reversal_candle_refuses():
    pdl = 2600.0
    raid = {"open": 2603.0, "high": 2604.0, "low": 2580.0, "close": 2608.0}
    # A tiny doji ABOVE the level: body and wicks balanced, no rejection pin
    # (lower wick < 55% of range) and no engulf — so nothing confirms the
    # reversal after the raid wick.
    m5 = {"open": 2605.1, "high": 2605.8, "low": 2604.4, "close": 2605.2}
    v = evaluate_path9_reversal(symbol="XAU/USD", raid_candle=raid,
                                m5_candles=[raid, m5], context={"pdl": pdl},
                                flow=_tape("BUY"), config=_gold_cfg())
    assert v["allow"] is False
    assert v["checks"]["sweep"] is True
    assert v["checks"]["reversal"] is False


def test_flow_disagreement_refuses():
    pdl = 2600.0
    raid = {"open": 2603.0, "high": 2604.0, "low": 2580.0, "close": 2608.0}
    m5_pin = {"open": 2601.0, "high": 2606.0, "low": 2582.0, "close": 2605.5}
    v = evaluate_path9_reversal(symbol="XAU/USD", raid_candle=raid,
                                m5_candles=[raid, m5_pin], context={"pdl": pdl},
                                flow={"direction": "SELL", "confidence": 80,
                                      "responsive": True},
                                config=_gold_cfg())
    assert v["allow"] is False
    assert any("flow_disagrees" in r for r in v["reasons"])


def test_stop_is_clamped_into_absolute_band():
    """Even a freak raid extreme yields a stop inside [270,400] gold points."""
    from utils.instruments import point_size
    # Level 2600 raided by a 380-point wick (low 2562, inside the 60..400
    # sweep band) then reclaimed and CLOSED BACK above the level. The raw stop
    # at the wick extreme is forced through the ABSOLUTE [270,400] band clamp.
    pdl = 2600.0
    raid = {"open": 2603.0, "high": 2606.0, "low": 2562.0, "close": 2614.0}
    m5_pin = {"open": 2613.0, "high": 2618.0, "low": 2604.0, "close": 2617.0}
    v = evaluate_path9_reversal(symbol="XAU/USD", raid_candle=raid,
                                m5_candles=[raid, m5_pin], context={"pdl": pdl},
                                flow=_tape("BUY"), config=_gold_cfg())
    assert v["allow"] is True
    pv = point_size("XAU/USD", CONFIG)
    pts = abs(v["entry"] - v["stop"]) / pv
    assert 270.0 - 1 <= pts <= 400.0 + 1


def test_missing_tape_witness_refuses():
    """The reverse of PATH 4: no auction tape signature -> no trade."""
    pdl = 2600.0
    raid = {"open": 2603.0, "high": 2604.0, "low": 2580.0, "close": 2608.0}
    m5_pin = {"open": 2601.0, "high": 2606.0, "low": 2582.0, "close": 2605.5}
    v = evaluate_path9_reversal(symbol="XAU/USD", raid_candle=raid,
                                m5_candles=[raid, m5_pin], context={"pdl": pdl},
                                config=_gold_cfg())  # no flow at all
    assert v["allow"] is False
    assert any("no_auction_tape_witness" in r for r in v["reasons"])


def test_weak_tape_below_floor_refuses():
    pdl = 2600.0
    raid = {"open": 2603.0, "high": 2604.0, "low": 2580.0, "close": 2608.0}
    m5_pin = {"open": 2601.0, "high": 2606.0, "low": 2582.0, "close": 2605.5}
    v = evaluate_path9_reversal(symbol="XAU/USD", raid_candle=raid,
                                m5_candles=[raid, m5_pin], context={"pdl": pdl},
                                flow=_tape("BUY", confidence=50.0),
                                config=_gold_cfg())
    assert v["allow"] is False
    assert any("flow_confidence" in r for r in v["reasons"])


def test_smc_never_vetoes_orphan_raid():
    """SMC disagreement/absence is a boost-only witness, never a gate."""
    pdl = 2600.0
    raid = {"open": 2603.0, "high": 2604.0, "low": 2580.0, "close": 2608.0}
    m5_pin = {"open": 2601.0, "high": 2606.0, "low": 2582.0, "close": 2605.5}
    v = evaluate_path9_reversal(symbol="XAU/USD", raid_candle=raid,
                                m5_candles=[raid, m5_pin], context={"pdl": pdl},
                                flow=_tape("BUY"),
                                smc={"direction": "SELL", "confidence": 80.0,
                                     "recent_sweep": {}},
                                config=_gold_cfg())
    # Tape signs the BUY; SMC reads SELL but may NOT veto an orphan raid.
    assert v["allow"] is True
    assert v["checks"]["smc"] is None


def test_stale_reversal_outside_window_refuses():
    """Fence 2: a trigger more than max_reversal_candles after the raid is late."""
    cfg = json.loads(json.dumps(_gold_cfg()))
    cfg["path9_reversal"]["max_reversal_candles"] = 1
    pdl = 2600.0
    raid = {"open": 2603.0, "high": 2604.0, "low": 2580.0, "close": 2608.0}
    # No reversal on the raid candle or the next one; a pin only arrives 3 later.
    flat1 = {"open": 2605.0, "high": 2606.0, "low": 2604.0, "close": 2605.2}
    flat2 = {"open": 2605.0, "high": 2606.0, "low": 2604.2, "close": 2605.0}
    # Late rejection candle, but its low STAYS ABOVE PDL -> not a raid itself;
    # the only raid is the first candle, whose reversal window already closed.
    late_pin = {"open": 2605.0, "high": 2606.0, "low": 2603.8, "close": 2605.9}
    v = evaluate_path9_reversal(symbol="XAU/USD", raid_candle=raid,
                                m5_candles=[raid, flat1, flat2, late_pin],
                                context={"pdl": pdl}, flow=_tape("BUY"),
                                config=cfg)
    assert v["allow"] is False
    assert any(("no_fresh_liquidity_sweep_reversal" in r
                or "no_m5_reversal_candle_in_window" in r) for r in v["reasons"])


# ───────────────────────────── Regime Switcher ──────────────────────────────

def test_regime_trend_routing():
    r = resolve_regime({"d1_regime": {"regime": "TREND_UP", "adx": 30.0}}, _switcher_on())
    assert r["regime"] == REGIME_TREND
    assert "PATH_2" in r["admit_paths"] and "PATH_3" in r["admit_paths"]
    assert "PATH_7" in r["block_paths"]  # scalp fade stands down in trend


def test_regime_range_routing():
    r = resolve_regime({"d1_regime": {"regime": "RANGE", "adx": 15.0},
                        "intraday": {"market_phase": "RANGING", "adx": 14.0}}, _switcher_on())
    assert r["regime"] == REGIME_RANGE
    assert "PATH_7" in r["admit_paths"] and "PATH_4" in r["admit_paths"]
    assert "PATH_2" in r["block_paths"]
    # PATH 9 (a fade) is admissible in range.
    assert "PATH_9" in r["admit_paths"]


def test_news_blackout_forces_high_vol_regime():
    r = resolve_regime({"d1_regime": {"regime": "TREND_UP", "adx": 32.0},
                        "news": {"blackout": True, "event": "NFP"}}, _switcher_on())
    assert r["regime"] == REGIME_HIGH_VOL_NEWS
    # Only news-leg (6) and sweep reversal (9) survive a news window.
    assert set(r["admit_paths"]) <= {"PATH_6", "PATH_9"}
    assert "PATH_2" in r["block_paths"]


def test_regime_switch_vetoes_blocked_path():
    regime = resolve_regime({"news": {"blackout": True, "event": "CPI"}}, _switcher_on())
    decision = {"decision": "BUY", "execution_path_id": "PATH_2_TWO_AGENT_MACRO",
                "confidence": 70}
    out = apply_regime_switch(decision, regime)
    assert out["decision"] == "WAIT"
    assert out["regime_switch"]["applied"] is True


def test_regime_switch_allows_path9_in_news():
    regime = resolve_regime({"news": {"blackout": True, "event": "CPI"}}, _switcher_on())
    decision = {"decision": "SELL", "execution_path_id": ep.PATH_9,
                "confidence": 72}
    out = apply_regime_switch(decision, regime)
    assert out["decision"] == "SELL"  # sweep reversal allowed
    assert "regime_switch" not in out


# ─────────────────────────── Regime State Machine ───────────────────────────

def test_state_machine_happy_path():
    sm = RegimeStateMachine(CONFIG)
    setup = {"setup_state": "DETECTED", "execution_path_id": "PATH_2_TWO_AGENT_MACRO"}
    for event, expect in [("poi_marked", "POI_MARKED"), ("arm", "ENTRY_ARMED"),
                          ("trigger", "ENTRY_TRIGGERED"), ("fill", "MANAGED"),
                          ("close", "CLOSED")]:
        setup = sm.advance(setup, event=event)
        assert setup["setup_state"] == expect, (event, setup.get("_rsm_last"))


def test_state_machine_regime_refuses_pre_entry_arm():
    sm = RegimeStateMachine(_switcher_on())
    regime = resolve_regime({"news": {"blackout": True}}, _switcher_on())
    setup = {"setup_state": "POI_MARKED", "execution_path_id": "PATH_2_TWO_AGENT_MACRO"}
    out = sm.advance(setup, event="arm", regime=regime)
    assert out["setup_state"] == "REFUSED"
    assert out["_rsm_last"]["veto"] == "regime"


def test_state_machine_never_blocks_after_entry():
    """A MANAGED position is never refused by regime/reflection."""
    sm = RegimeStateMachine(CONFIG)
    regime = resolve_regime({"news": {"blackout": True}}, CONFIG)
    setup = {"setup_state": "ENTRY_TRIGGERED", "execution_path_id": "PATH_2_TWO_AGENT_MACRO"}
    out = sm.advance(setup, event="fill", regime=regime,
                     reflection_veto={"veto": True, "reason": "x"})
    assert out["setup_state"] == "MANAGED"


def test_state_machine_terminal_is_immutable():
    sm = RegimeStateMachine(CONFIG)
    setup = {"setup_state": "CLOSED", "execution_path_id": "PATH_1"}
    out = sm.advance(setup, event="arm")
    assert out["setup_state"] == "CLOSED"
    assert out["_rsm_last"]["allowed"] is False


def test_reflection_veto_refuses_armed_setup():
    sm = RegimeStateMachine(CONFIG)
    setup = {"setup_state": "SWEEP_CONFIRMED", "execution_path_id": ep.PATH_9}
    veto = {"veto": True, "reason": "reflection_cooldown: level burned 20m ago"}
    out = sm.advance(setup, event="arm", reflection_veto=veto)
    assert out["setup_state"] == "REFUSED"
    assert out["_rsm_last"]["veto"] == "reflection"


# ──────────────────────────── Reflection Agent ──────────────────────────────

def test_reflection_records_then_vetoes_same_zone(tmp_path):
    store = tmp_path / "reflection_memory.json"
    agent = ReflectionAgent(CONFIG, path=str(store))
    agent.record_burn(symbol="XAU/USD", level=2600.0, direction="BUY",
                      burn_type="stop_hunt_sweep", trade_id="T1")
    # Same level within band -> veto.
    v = agent.review(symbol="XAU/USD", poi_level=2605.0, direction="BUY")
    assert v["veto"] is True
    assert "cooldown" in v["reason"]
    # Far away level -> no veto.
    v2 = agent.review(symbol="XAU/USD", poi_level=2750.0, direction="BUY")
    assert v2["veto"] is False
    # Opposite direction is not blocked.
    v3 = agent.review(symbol="XAU/USD", poi_level=2603.0, direction="SELL")
    assert v3["veto"] is False


def test_reflection_cooldown_expires(tmp_path):
    from datetime import datetime, timezone, timedelta
    store = tmp_path / "reflection_memory.json"
    agent = ReflectionAgent(CONFIG, path=str(store))
    agent.record_burn(symbol="XAU/USD", level=2600.0, direction="BUY")
    future = datetime.now(timezone.utc) + timedelta(hours=4)
    v = agent.review(symbol="XAU/USD", poi_level=2600.0, direction="BUY", at=future)
    assert v["veto"] is False


def test_reflection_repeated_burn_refreshes_not_duplicates(tmp_path):
    store = tmp_path / "reflection_memory.json"
    agent = ReflectionAgent(CONFIG, path=str(store))
    agent.record_burn(symbol="XAU/USD", level=2600.0, direction="BUY")
    r2 = agent.record_burn(symbol="XAU/USD", level=2602.0, direction="BUY")
    assert r2.get("refreshed") is True
    assert len(agent.active_burns("XAU/USD")) == 1


def test_reflection_note_and_fail_open(tmp_path):
    agent = ReflectionAgent(CONFIG, path=str(tmp_path / "nope" / "r.json"))
    # Missing path -> no veto, no crash.
    assert agent.review(symbol="XAU/USD", poi_level=2600.0)["veto"] is False
    agent.record_burn(symbol="XAU/USD", level=2600.0, direction="SELL")
    note = agent.reflection_note("XAU/USD")
    assert "reflection" in note.lower()
