"""2026-08-19 phase-2 tests: COT parser + sentiment agent + cached fetch."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import agents.sentiment_agent as sa  # noqa: E402
from services.aux_market_data import (  # noqa: E402
    append_cot_history,
    fetch_cot,
    parse_cot_text,
)

# Real CFTC deacom.txt rows (2026-08-11 release) — schema-faithful fixtures.
GOLD_ROW = (
    '"GOLD - COMMODITY EXCHANGE INC.",260811,2026-08-11,088691,CMX ,00,001 ,088 ,'
    "564585,247970,33114,154637,104295,355178,506902,542929,57683,21656,"
    "564585,247970,33114,154637,104295,355178,506902,542929,57683,21656,"
    "0,0,0,0,0,0,0,0,0,0,76273,26588,2380,38544,3097,33637,68229,74561,8044,1712,100.0"
)
WTI_ROW = (
    '"CRUDE OIL, LIGHT SWEET-WTI - ICE FUTURES EUROPE",260811,2026-08-11,067411,ICEU,01,067 ,'
    "1097720,81501,57648,363725,634220,659971,1079447,1081345,18274,16376,"
    "1097720,81501,57648,363725,634220,659971,1079447,1081345,18274,16376,"
    "0,0,0,0,0,0,0,0,0,0,76273,26588,2380,38544,3097,33637,68229,74561,8044,1712,100.0"
)
COT_TEXT = "\n".join([GOLD_ROW, WTI_ROW])


def _cfg(tmp_path, **overrides):
    cfg = {
        "symbol": "XAU/USD",
        "sentiment_agent": {
            "enabled": True,
            "cot_cache_path": str(tmp_path / "cot_cache.json"),
            "cot_history_path": str(tmp_path / "cot_history.json"),
            "min_history_weeks": 8,
        },
    }
    cfg["sentiment_agent"].update(overrides)
    return cfg


def _cot(commodity_values=None):
    cot = {
        "source": "cftc_deacom",
        "fetched_at": "2026-08-18T00:00:00Z",
        "gold": {"report_date": "2026-08-11", "oi": 564585, "mm_long": 506902, "mm_short": 542929},
        "wti": {"report_date": "2026-08-11", "oi": 1097720, "mm_long": 1079447, "mm_short": 1081345},
    }
    if commodity_values:
        for k, v in commodity_values.items():
            cot[k] = v
    return cot


class TestParseCOT:
    def test_real_rows_parse(self):
        p = parse_cot_text(COT_TEXT)
        assert p["gold"]["oi"] == 564585
        assert p["gold"]["mm_long"] == 506902
        assert p["gold"]["mm_short"] == 542929
        assert p["gold"]["report_date"] == "2026-08-11"
        assert p["wti"]["oi"] == 1097720
        assert p["wti"]["mm_long"] == 1079447
        assert p["wti"]["mm_short"] == 1081345

    def test_garbage_fails_open(self):
        p = parse_cot_text("not a cot file\n,,,,\n")
        assert p == {"gold": None, "wti": None}

    def test_micro_gold_not_confused(self):
        micro = GOLD_ROW.replace("GOLD - COMMODITY", "MICRO GOLD - COMMODITY")
        p = parse_cot_text(micro)
        assert p["gold"] is None  # MICRO rows must not be picked up


class TestFetchCOT:
    def test_fetch_and_cache(self, tmp_path, monkeypatch):
        import requests

        calls = {"n": 0}

        def fake_get(url, timeout):
            calls["n"] += 1
            return SimpleNamespace(text=COT_TEXT, raise_for_status=lambda: None)

        monkeypatch.setattr(requests, "get", fake_get)
        cfg = _cfg(tmp_path)
        cot1 = fetch_cot(cfg)
        assert cot1["gold"]["oi"] == 564585
        cot2 = fetch_cot(cfg)  # second call must hit the fresh cache
        assert calls["n"] == 1
        assert cot2["gold"]["oi"] == 564585
        assert (tmp_path / "cot_cache.json").exists()

    def test_history_append_dedupe(self, tmp_path):
        cfg = _cfg(tmp_path)
        cot = _cot()
        hist1 = append_cot_history(cfg, cot)
        hist2 = append_cot_history(cfg, cot)  # same report_date -> no duplicate
        assert len(hist1) == 2  # gold + wti
        assert len(hist2) == 2
        gold = [e for e in hist2 if e["commodity"] == "gold"][0]
        assert abs(gold["mm_net_pct"] - (-6.381)) < 0.01


class TestSentimentAgent:
    def test_crowded_shorts_bullish(self, tmp_path, monkeypatch):
        cfg = _cfg(tmp_path)
        # history: 10 older weeks all LESS short than today's -6.38
        for i in range(10):
            append_cot_history(cfg, {
                "gold": {"report_date": f"2026-06-{i+1:02d}", "oi": 500000,
                         "mm_long": 480000, "mm_short": 492000},  # net -2.4%
                "wti": None,
            })
        monkeypatch.setattr(sa, "fetch_cot", lambda config: _cot())
        monkeypatch.setattr(sa, "yf_closes", lambda *a, **k: None)  # no ETF -> missing but not fatal
        result = sa.SentimentAgent(cfg).analyze({"symbol": "XAU/USD"})
        assert result["direction"] == "BUY"
        assert result["bias"] == "BULLISH_GOLD"
        assert result["confidence"] > 0
        assert result["cot_percentile"] is not None

    def test_crowded_longs_bearish(self, tmp_path, monkeypatch):
        cfg = _cfg(tmp_path)
        # history: 10 older weeks all MORE short than today (-6.38 is the least short)
        for i in range(10):
            append_cot_history(cfg, {
                "gold": {"report_date": f"2026-06-{i+1:02d}", "oi": 500000,
                         "mm_long": 460000, "mm_short": 500000},  # net -8.0%
                "wti": None,
            })
        monkeypatch.setattr(sa, "fetch_cot", lambda config: _cot())
        monkeypatch.setattr(sa, "yf_closes", lambda *a, **k: None)
        result = sa.SentimentAgent(cfg).analyze({"symbol": "XAU/USD"})
        assert result["direction"] == "SELL"
        assert result["bias"] == "BEARISH_GOLD"

    def test_never_votes(self, tmp_path, monkeypatch):
        cfg = _cfg(tmp_path)
        monkeypatch.setattr(sa, "fetch_cot", lambda config: _cot())
        monkeypatch.setattr(sa, "yf_closes", lambda *a, **k: None)
        result = sa.SentimentAgent(cfg).analyze({"symbol": "XAU/USD"})
        assert result["signal"] == "WAIT"  # even when direction is BUY/SELL

    def test_fail_open(self, tmp_path, monkeypatch):
        cfg = _cfg(tmp_path)
        monkeypatch.setattr(sa, "fetch_cot", lambda config: {"gold": None, "wti": None})
        monkeypatch.setattr(sa, "yf_closes", lambda *a, **k: None)
        result = sa.SentimentAgent(cfg).analyze({"symbol": "XAU/USD"})
        assert result["direction"] == "WAIT"
        assert result["confidence"] == 0
        assert "cot" in result["missing"] and "etf_flow" in result["missing"]

    def test_etf_momentum_adds_score(self, tmp_path, monkeypatch):
        cfg = _cfg(tmp_path)
        monkeypatch.setattr(sa, "fetch_cot", lambda config: _cot())
        # ETF +3.9% over the 21d lookback -> +1.5 (bullish), no COT history yet
        monkeypatch.setattr(
            sa, "yf_closes",
            lambda sym, *a, **k: [100.0 + i * 0.2 for i in range(60)],
        )
        result = sa.SentimentAgent(cfg).analyze({"symbol": "XAU/USD"})
        assert result["direction"] == "BUY"
        assert result["bias"] == "BULLISH_GOLD"
        assert result["confidence"] == 55  # 40 + 1.5*10
        assert result["signal"] == "WAIT"

    def test_wti_symbol_uses_wti_row(self, tmp_path, monkeypatch):
        cfg = _cfg(tmp_path)
        monkeypatch.setattr(sa, "fetch_cot", lambda config: _cot())
        monkeypatch.setattr(sa, "yf_closes", lambda *a, **k: None)
        result = sa.SentimentAgent(cfg).analyze({"symbol": "WTI/USD"})
        assert result["commodity"] == "wti"
        # WTI MM net = 1079447-1081345 = -1898 -> -0.17% of OI (no history -> informational)
        assert result["mm_net_pct"] is not None
