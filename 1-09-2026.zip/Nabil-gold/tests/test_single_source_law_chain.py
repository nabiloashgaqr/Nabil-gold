"""R25.7 verification (operator question, 2026-08-28): هل كل شيء — ستوب وأهداف
وتريلينج ورسائل تيليجرام — يقرأ من مصدر واحد ويُطبَّق على ميتاتريد؟

The chain pinned here:
  config.json instruments + DEFAULT_INSTRUMENTS  --(ONE accessor: utils
  .instruments via config_for_instrument)-->  stop_rule / target_ratios /
  trailing_params  -->  BOTH engines (tick manager and the 5-minute
  OpenTradesManager resolve the SAME numbers)  -->  the ORDER carries
  sl/tp2/lot to MetaTrader  -->  the Telegram card prints the same stored
  truth at the symbol's own digits.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import scripts.run_tick_manager as rtm  # noqa: E402
from agents.open_trades_manager import OpenTradesManager  # noqa: E402
from utils.helpers import load_config  # noqa: E402
from utils.instruments import (  # noqa: E402
    DEFAULT_INSTRUMENTS, config_for_instrument, get_instrument,
)
from utils.trading_rules import stop_rule, target_ratios, trailing_params  # noqa: E402

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
FIVE = ("WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")


def _sym_cfg(symbol: str) -> dict:
    return config_for_instrument(CONFIG, get_instrument(CONFIG, symbol))


# ── 1. one source: config.json == DEFAULT_INSTRUMENTS == the law ────────────

@pytest.mark.parametrize("symbol", ("XAU/USD",) + FIVE)
def test_config_and_code_default_agree_on_the_floor(symbol):
    """The instruments table (config) and the merged defaults say the SAME
    floor — two copies would eventually drift into two different laws."""
    from tests._band_table import CAP
    expected = int(CAP[symbol])
    inst = next(i for i in CONFIG["instruments"] if i["symbol"] == symbol)
    assert inst["min_sl_distance_points"] == expected
    assert DEFAULT_INSTRUMENTS[symbol]["min_sl_distance_points"] == expected
    assert _sym_cfg(symbol)["risk_settings"]["min_sl_distance_points"] == expected


def test_gold_law_untouched_and_five_carry_gold_management():
    gs = stop_rule(_sym_cfg("XAU/USD"))
    assert (gs["min_liquidity_points"], gs["safety_buffer_points"],
            gs["max_stop_points"]) == (200.0, 70.0, 400.0)
    from tests._band_table import NOISE, BUFFER, CAP
    for symbol in FIVE:
        cfg = _sym_cfg(symbol)
        s = stop_rule(cfg)
        # R26.1: each instrument carries its OWN factor-scaled law, but the
        # resolved config, the code defaults and the law agree exactly.
        assert (s["min_liquidity_points"], s["safety_buffer_points"],
                s["max_stop_points"]) == (
            float(NOISE[symbol]), float(BUFFER[symbol]), float(CAP[symbol]))
        assert DEFAULT_INSTRUMENTS[symbol]["trading_rules"]["stop"]["max_stop_points"] == CAP[symbol]
        t = trailing_params(cfg)
        d = DEFAULT_INSTRUMENTS[symbol]
        assert (t["distance_points"], t["step_points"],
                t["early_breakeven_points"]) == (
            float(d["trailing_distance"]), float(d["trailing_step"]),
            float(d["early_breakeven_points"]))
        r = target_ratios(cfg)
        assert (r["min_tp1_rr"], r["tp2_multiple"]) == (0.8, 2.0)


@pytest.mark.parametrize("symbol", ("XAU/USD",) + FIVE)
def test_both_engines_resolve_the_same_law(symbol):
    """Tick manager and the 5-minute manager read ONE accessor — their
    effective laws are identical for the same symbol."""
    inst = next(i for i in CONFIG["instruments"] if i["symbol"] == symbol)
    base = dict(CONFIG)
    base["auction_flow"] = {"enabled": False,
                            "storage_path": "storage/auction_flow.sqlite3"}
    db = SimpleNamespace(update_trade=lambda *a, **k: None)
    tm = rtm.TickManager(base, telegram=None, database=db)
    laws = tm._per_symbol_laws({"symbol": symbol})
    mgr = OpenTradesManager(config_for_instrument(base, inst))
    params = mgr._management_params({"symbol": symbol}, symbol)
    s = stop_rule(config_for_instrument(base, inst))
    assert (laws["stop"]["min_liquidity_points"], laws["stop"]["safety_buffer_points"],
            laws["stop"]["max_stop_points"]) == (
        s["min_liquidity_points"], s["safety_buffer_points"], s["max_stop_points"])
    assert laws["trailing"]["distance_points"] == params["trailing_distance_points"]
    assert laws["trailing"]["step_points"] == params["trailing_step_points"]
    assert (laws["trailing"]["early_breakeven_points"]
            == params["early_breakeven_points"])
    assert params["partial_close_fraction"] == pytest.approx(0.5)


# ── 2. the ORDER carries the law to MetaTrader (sl, tp2, solved lot) ───────

def test_market_order_ships_solved_lot_sl_tp2_to_mt5(monkeypatch, tmp_path):
    """end-to-end: ensure_ticket -> ONE order_send with the dollar-law volume
    and the row's own sl/tp2."""
    from services.mt5_executor import Mt5DemoExecutor
    import tests.mt5_fake as mt5_fake
    import importlib
    m5 = importlib.import_module("services.mt5_executor")

    state = mt5_fake.FakeState()
    monkeypatch.setitem(sys.modules, "MetaTrader5", mt5_fake.install(state))
    monkeypatch.setattr(m5, "HALT_FILE", str(tmp_path / ".demo_halt"))
    ex = Mt5DemoExecutor({"execution": {"demo": {}}}, telegram=None)
    # R25.7-E: the stop must sit INSIDE the gold band [270, 400] pts —
    # the old 100-pt stop is sub-floor and the chokepoint now widens it.
    # 330 pts (entry 4300 -> sl 4267) -> $3300/lot -> 270/3300 -> ceil 0.09.
    ticket = ex.ensure_ticket("T-LAW", "BUY", "BUY_MARKET",
                              4300.0, 4267.0, 4320.0, "XAU/USD")
    assert ticket is not None
    assert len(state.requests) == 1
    req = state.requests[0]
    assert req["volume"] == pytest.approx(0.09)   # 330-pt gold stop -> $270/$3300
    assert req["sl"] == pytest.approx(4267.0)
    assert req["tp"] == pytest.approx(4320.0)


# ── 3. the Telegram card prints the SAME stored truth (symbol digits) ──────

def test_fill_card_message_carries_the_true_5_digit_fill():
    """The pending-fill card (demo path) prints the broker fill at the
    symbol's digits — the same value the book stores (no gold rounding)."""
    tm = rtm.TickManager.__new__(rtm.TickManager)
    tm.config = {}
    tm.database = SimpleNamespace(update_trade=lambda *a, **k: None)
    tm._last_price = 0.0
    tm._last_prices = {}
    tm._notification_row = None
    tm._placement_retry_at = {}
    tm._extremes = {}
    tm._partial_alerted = set()
    notes, signals = [], []

    def _notify(text):
        notes.append(text)

    def _signal(row, actual_entry=None, actual_stop=None):
        signals.append((actual_entry, actual_stop))

    tm._notify = _notify
    tm._send_execution_signal = _signal
    tm._pending_stale = lambda row, tick: False
    tm._normalize_execution_stop = lambda *a: 0.0
    row = {"id": "GBP-FILL", "type": "SELL", "symbol": "GBP/USD",
           "status": "PENDING", "entry_price": 1.36, "tp2": 1.34504}
    pos = SimpleNamespace(price_open=1.35504, ticket=4242, volume=1.18)
    ex = SimpleNamespace(_position_by_magic=lambda magic: pos)
    tick = SimpleNamespace(bid=1.35510, ask=1.35512, time_msc=1)
    tm._handle_row(row, tick, ex, None)

    assert row["entry_price"] == 1.35504          # the book holds the truth
    assert row["lots"] == pytest.approx(1.18)     # the dollar law's volume
    assert signals and signals[0][0] == 1.35504   # the execution card too
    assert notes and "1.35504" in notes[-1]       # ...and the human message
