# -*- coding: utf-8 -*-
"""R26.5 (2026-09-01): two live fixes surfaced by the post-baseline auditor.

1. PATH_MISSING: a scale-in / add leg reaches ``save_trade`` through the
   scale-in branch which never ran the run_analysis provenance stamp, so the
   row was stored with ``execution_path_id=None`` (live gold MARKET row
   TRADE_..._826fa13b, 2026-08-31 19:56). A real, entered trade must never
   be recorded with no path -> stamp ``SCALE_IN_ADD`` as a final fallback.

2. STOP_OUT_OF_BAND noise: the executor (mt5_executor R25.7-E) clamps the
   stop against the LIVE tick, while the auditor measures it from the
   planned/stored entry. A MARKET fill a few points away can read 1-3 points
   over the cap (401 vs 400 gold) even though the executor's own clamp was
   satisfied. A small 5-point tolerance hides that measurement gap without
   hiding real violations (legacy stops are tens to hundreds of points out).
"""
from __future__ import annotations

from services.database import DatabaseService


def _db(tmp_path):
    return DatabaseService({"database": {"url": None, "key": None,
                                         "local_fallback_file":
                                         str(tmp_path / "trades.json")}})


# ── path stamping ───────────────────────────────────────────────────────────

def test_scale_in_add_gets_a_path_even_without_stamp(tmp_path):
    db = _db(tmp_path)
    decision = {
        "symbol": "XAU/USD", "decision": "SELL", "confidence": 75,
        "current_price": 4449.31,
        # No execution_path_id / execution_path — exactly the add-leg shape.
        "signal": {"symbol": "XAU/USD", "type": "SELL",
                   "entry_kind": "MARKET", "order_type": "SELL",
                   "scale_in": True, "scale_in_size_ratio": 0.5,
                   "entry": {"price": 4449.31, "kind": "MARKET"},
                   "stop_loss": 4489.6, "tp1": 4415.24, "tp2": 4365.24},
    }
    db.save_trade(decision)
    row = db.get_open_trades()[0]
    assert row["execution_path_id"] == "SCALE_IN_ADD"


def test_scale_in_marker_in_signal_only(tmp_path):
    db = _db(tmp_path)
    decision = {
        "symbol": "XAU/USD", "decision": "BUY", "confidence": 70,
        "current_price": 4400.0,
        "signal": {"type": "BUY", "scale_in": True,
                   "entry": {"price": 4400.0, "kind": "MARKET"},
                   "stop_loss": 4360.0, "tp1": 4432.0, "tp2": 4464.0},
    }
    db.save_trade(decision)
    assert db.get_open_trades()[0]["execution_path_id"] == "SCALE_IN_ADD"


def test_existing_path_stamp_is_never_overwritten(tmp_path):
    db = _db(tmp_path)
    decision = {
        "symbol": "XAU/USD", "decision": "BUY", "confidence": 70,
        "execution_path_id": "PATH_2_TWO_AGENT_MACRO",
        "current_price": 4400.0,
        "signal": {"type": "BUY",
                   "entry": {"price": 4400.0, "kind": "LIMIT"},
                   "stop_loss": 4360.0, "tp1": 4432.0, "tp2": 4464.0},
    }
    db.save_trade(decision)
    assert db.get_open_trades()[0]["execution_path_id"] == "PATH_2_TWO_AGENT_MACRO"


def test_nested_execution_path_resolves_before_fallback(tmp_path):
    db = _db(tmp_path)
    decision = {
        "symbol": "XAU/USD", "decision": "SELL", "confidence": 70,
        "execution_path": {"id": "PATH_5_TWO_AGENT_AUCTION"},
        "current_price": 4400.0,
        "signal": {"type": "SELL",
                   "entry": {"price": 4400.0, "kind": "MARKET"},
                   "stop_loss": 4440.0, "tp1": 4368.0, "tp2": 4336.0},
    }
    db.save_trade(decision)
    assert db.get_open_trades()[0]["execution_path_id"] == "PATH_5_TWO_AGENT_AUCTION"


# ── auditor band tolerance ───────────────────────────────────────────────────

def _audit(decision, config):
    from services.post_decision_auditor import audit_decision
    all_results = {
        "technical": {"direction": "SELL", "confidence": 78},
        "price_action": {"direction": "SELL", "confidence": 74},
    }
    open_trades: list = []
    return audit_decision(decision, config, all_results, open_trades)["findings"]


def _gold_sell(stop_price):
    return {
        "symbol": "XAU/USD", "decision": "SELL", "execution_path_id": "PATH_5_TWO_AGENT_AUCTION",
        "current_price": 4449.31,
        "signal": {"type": "SELL", "order_type": "SELL_LIMIT",
                   "entry": {"price": 4449.31}, "stop_loss": stop_price,
                   "tp1": 4415.24, "tp2": 4365.24},
    }


def test_stop_one_point_over_cap_is_not_flagged(tmp_path):
    """4489.6 vs entry 4449.31 = ~403 pts from stored entry; the executor
    clamped against the live tick. Within the 5-pt tolerance -> no WARN."""
    from utils.helpers import load_config
    config = load_config()
    decision = _gold_sell(4489.6)  # the live 826fa13b geometry
    findings = _audit(decision, config)
    codes = [f["code"] for f in findings]
    assert "STOP_OUT_OF_BAND" not in codes


def test_stop_way_over_cap_is_still_flagged():
    from utils.helpers import load_config
    config = load_config()
    decision = _gold_sell(4449.31 + 600 * 0.10)  # 600 pts, far over the 400 cap
    findings = _audit(decision, config)
    assert "STOP_OUT_OF_BAND" in [f["code"] for f in findings]
