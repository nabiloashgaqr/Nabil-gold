"""2026-08-19 remaining-fix tests: Gemini volatility invalidation, email
alert fallback, MT5 healthcheck section."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from services.gemini_confirm_cache import load_confirmation, store_confirmation  # noqa: E402
from services.telegram_bot import send_email_alert  # noqa: E402


def _review(verdict="BUY", confidence=80):
    return {"verdict": verdict, "confidence": confidence, "available": True}


class TestGeminiVolInvalidation:
    def test_same_signature_reuses(self, tmp_path):
        store_confirmation("XAU/USD", "BUY", _review(), root=tmp_path,
                           now=1000.0, vol_signature=100.0)
        cached = load_confirmation("XAU/USD", "BUY", root=tmp_path, now=1060.0,
                                   vol_signature=100.0)
        assert cached is not None

    def test_vol_jump_invalidates(self, tmp_path):
        store_confirmation("XAU/USD", "BUY", _review(), root=tmp_path,
                           now=1000.0, vol_signature=100.0)
        # ATR jumped 40% -> the old verdict no longer answers the same question
        cached = load_confirmation("XAU/USD", "BUY", root=tmp_path, now=1060.0,
                                   vol_signature=140.0)
        assert cached is None

    def test_small_drift_keeps(self, tmp_path):
        store_confirmation("XAU/USD", "BUY", _review(), root=tmp_path,
                           now=1000.0, vol_signature=100.0)
        cached = load_confirmation("XAU/USD", "BUY", root=tmp_path, now=1060.0,
                                   vol_signature=112.0)  # 12% drift < 25%
        assert cached is not None

    def test_backward_compatible_without_signature(self, tmp_path):
        # stored without a signature (old entries): caller signature is ignored
        store_confirmation("XAU/USD", "BUY", _review(), root=tmp_path, now=1000.0)
        cached = load_confirmation("XAU/USD", "BUY", root=tmp_path, now=1060.0,
                                   vol_signature=900.0)
        assert cached is not None

    def test_ttl_still_enforced(self, tmp_path):
        store_confirmation("XAU/USD", "BUY", _review(), root=tmp_path,
                           now=1000.0, vol_signature=100.0)
        assert load_confirmation("XAU/USD", "BUY", root=tmp_path, now=1000.0 + 16 * 60,
                                 vol_signature=100.0) is None

    def test_unavailable_never_stored(self, tmp_path):
        store_confirmation("XAU/USD", "BUY", {"available": False}, root=tmp_path)
        assert load_confirmation("XAU/USD", "BUY", root=tmp_path) is None


class TestEmailAlertFallback:
    def test_disabled_by_default(self):
        assert send_email_alert({}, "boom") is False
        assert send_email_alert({"alert_email": {"enabled": False}}, "boom") is False

    def test_missing_fields_silent_false(self):
        cfg = {"alert_email": {"enabled": True}}
        assert send_email_alert(cfg, "boom") is False

    def test_sends_when_configured(self, monkeypatch):
        sent = {}

        class FakeSMTP:
            def __init__(self, host, port, timeout):
                sent["conn"] = (host, port)

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def ehlo(self):
                pass

            def starttls(self):
                pass

            def login(self, u, p):
                sent["login"] = (u, p)

            def sendmail(self, frm, to, payload):
                sent["mail"] = (frm, to)

        import smtplib

        monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
        cfg = {"alert_email": {
            "enabled": True, "smtp_host": "smtp.example.com", "smtp_port": 587,
            "username": "u", "password": "p", "from_addr": "a@x", "to_addr": "b@x",
        }}
        assert send_email_alert(cfg, "boom") is True
        assert sent["conn"] == ("smtp.example.com", 587)

    def test_smtp_failure_is_silent_false(self, monkeypatch):
        import smtplib

        def boom(*a, **k):
            raise ConnectionError("down")

        monkeypatch.setattr(smtplib, "SMTP", boom)
        cfg = {"alert_email": {
            "enabled": True, "smtp_host": "h", "smtp_port": 587,
            "username": "u", "password": "p", "from_addr": "a@x", "to_addr": "b@x",
        }}
        assert send_email_alert(cfg, "boom") is False


class TestMT5HealthcheckSection:
    def test_connected(self, monkeypatch):
        import scripts.system_healthcheck as hc
        import services.mt5_feed as feed

        monkeypatch.setattr(feed, "connected", lambda: True)
        monkeypatch.setattr(feed, "initialize", lambda: True)
        ok, detail = hc.check_mt5_terminal()
        assert ok is True
        assert "connected" in detail

    def test_disconnected_reports_frozen_management(self, monkeypatch):
        import scripts.system_healthcheck as hc
        import services.mt5_feed as feed

        monkeypatch.setattr(feed, "connected", lambda: False)
        monkeypatch.setattr(feed, "initialize", lambda: False)
        ok, detail = hc.check_mt5_terminal()
        assert ok is False
        assert "frozen" in detail or "NOT connected" in detail

    def test_initialize_recovers(self, monkeypatch):
        import scripts.system_healthcheck as hc
        import services.mt5_feed as feed

        state = {"calls": 0}

        def connected():
            return state["calls"] > 0

        def initialize():
            state["calls"] += 1
            return True

        monkeypatch.setattr(feed, "connected", connected)
        monkeypatch.setattr(feed, "initialize", initialize)
        ok, detail = hc.check_mt5_terminal()
        assert ok is True
        assert "re-initialized" in detail
