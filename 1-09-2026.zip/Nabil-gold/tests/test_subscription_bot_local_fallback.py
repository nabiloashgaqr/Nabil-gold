"""BUILD 16 (2026-08-20): the subscription bot must run on the VPS without
Supabase. The Windows task runs `python subscription_bot\\cron_maintenance.py`,
so the tests mirror that import shape (subscription_bot dir on sys.path) and
exercise the local JSON backend end-to-end."""
from __future__ import annotations

import sys
from datetime import date, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "subscription_bot"))

import config as sbot_config          # noqa: E402
import database as sbot_db            # noqa: E402


@pytest.fixture(autouse=True)
def _local_mode(monkeypatch, tmp_path):
    monkeypatch.setattr(sbot_config, "SUPABASE_URL", "")
    monkeypatch.setattr(sbot_config, "SUPABASE_KEY", "")
    monkeypatch.setattr(sbot_db, "LOCAL_PATH", tmp_path / "subscription_bot.json")
    monkeypatch.setattr(sbot_db, "_db_instance", None)


def _db():
    return sbot_db.Database()


def test_init_falls_back_to_local(tmp_path):
    db = _db()
    assert db.use_supabase is False
    assert db.client is None
    assert (tmp_path / "subscription_bot.json").exists()


def test_upsert_on_join_creates_then_rejoins():
    db = _db()
    row = db.upsert_on_join(111, "Ahmed", "@ahmed")
    assert row["status"] == "pending_duration"
    assert row["can_dm"] is False
    # re-join resets to pending without duplicating
    again = db.upsert_on_join(111, "Ahmed X", "@ahmed2")
    assert again["id"] == row["id"]
    assert again["full_name"] == "Ahmed X"
    assert again["status"] == "pending_duration"
    assert len(db.get_pending()) == 1


def test_set_subscription_expiry_math():
    db = _db()
    row = db.upsert_on_join(222, "Sami", None)
    expiry = db.set_subscription(row["id"], 7, "day")
    assert expiry == date.today() + timedelta(days=7)
    assert db.get_by_id(row["id"])["status"] == "active"
    assert db.get_active()[0]["expiry_date"] == expiry.isoformat()
    # month == 30 days
    expiry_m = db.set_subscription(row["id"], 1, "month")
    assert expiry_m == date.today() + timedelta(days=30)


def test_expiry_kick_flow_and_stats():
    db = _db()
    row = db.upsert_on_join(333, "Omar", None)
    # expired yesterday -> must appear in the kick list
    db._update_local_row(row["id"], {"status": "active", "expiry_date": (date.today() - timedelta(days=1)).isoformat()})
    expired = db.get_expired_today_or_before()
    assert len(expired) == 1 and expired[0]["id"] == row["id"]
    db.mark_expired_kicked(row["id"])
    assert db.get_by_id(row["id"])["status"] == "expired"
    assert db.get_by_id(row["id"])["kicked"] is True
    stats = db.get_stats()
    assert stats["expired"] == 1
    assert stats["total"] == 1


def test_expiring_in_days():
    db = _db()
    row = db.upsert_on_join(444, "Lina", None)
    target = date.today() + timedelta(days=3)
    db._update_local_row(row["id"], {"status": "active", "expiry_date": target.isoformat()})
    assert len(db.get_expiring_in_days(3)) == 1
    assert len(db.get_expiring_in_days(2)) == 0
    stats = db.get_stats()
    assert stats["expiring_soon"] >= 1


def test_notifications_dedup():
    db = _db()
    row = db.upsert_on_join(555, "Nour", None)
    assert db.has_notification(row["id"], "before_3_days_admin") is False
    db.log_notification(row["id"], "before_3_days_admin", 1, "expiring soon")
    assert db.has_notification(row["id"], "before_3_days_admin") is True
    assert db.has_notification(row["id"], "kicked") is False


def test_search_delete_update_expiry():
    db = _db()
    row = db.upsert_on_join(666, "Yousef Kamal", "@yk")
    assert len(db.search_subscribers("yousef")) == 1
    assert len(db.search_subscribers("@yk")) == 1
    assert db.update_expiry(row["id"], date.today() + timedelta(days=10)) is True
    assert db.get_by_id(row["id"])["expiry_date"] == (date.today() + timedelta(days=10)).isoformat()
    assert db.delete_subscriber(row["id"]) is True
    assert db.get_by_id(row["id"]) is None
    assert db.delete_subscriber(row["id"]) is False


def test_persistence_across_instances():
    db1 = _db()
    row = db1.upsert_on_join(777, "Heba", None)
    db1.set_subscription(row["id"], 2, "week")
    # a fresh instance (new task run) sees the same store
    db2 = _db()
    seen = db2.get_by_id(row["id"])
    assert seen is not None
    assert seen["status"] == "active"
    assert seen["expiry_date"] == (date.today() + timedelta(weeks=2)).isoformat()


def test_get_db_singleton_uses_local():
    db = sbot_db.get_db()
    assert db.use_supabase is False
