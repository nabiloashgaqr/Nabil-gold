"""Auction Flow opposes with full rights in the add/activation vetoes.

Live failure, 2026-08-18 15:01 (operator: '٢ ضد ودخل شراء'): the scale-in
card ITSELF displayed the objection —

    🔴 Price_Action SELL 68%
    🔴 Auction_Flow SELL 71%

— and the BUY add still entered, because the opponent counter walked
VOTING_AGENTS (the five) and read "1 < 2". Auction Flow was removed from
ADMISSION voting on 2026-08-14 to prevent double-confirmation; a VETO is
not a vote. Operator choice A: in the opposition census (scale-in veto +
pending activation gate) auction_flow is a full-rights opponent at the
same shared 65 bar.

One shared counter — count_veto_opponents / VETO_AGENTS — feeds both
gates, so they can never disagree about who objects.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.thesis_consensus import VETO_AGENTS, VOTING_AGENTS, count_veto_opponents

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def _book_15_01():
    """The exact card that slipped through."""
    return {
        "technical": {"direction": "WAIT", "confidence": 30},
        "multitimeframe": {"direction": "WAIT", "confidence": 30},
        "classical": {"direction": "WAIT", "confidence": 30},
        "smc": {"direction": "WAIT", "confidence": 30},
        "price_action": {"direction": "SELL", "confidence": 68},
        "auction_flow": {"direction": "SELL", "confidence": 71},
    }


def test_the_15_01_book_now_counts_two_opponents():
    census = count_veto_opponents("BUY", _book_15_01(), CONFIG)
    assert census["count"] == 2
    assert set(census["opponents"]) == {"price_action", "auction_flow"}


def test_auction_flow_is_in_the_veto_census_not_the_voting_census():
    assert "auction_flow" in VETO_AGENTS
    assert "auction_flow" not in VOTING_AGENTS, (
        "the 2026-08-14 decision stands: auction_flow never VOTES for admission")


def test_unqualified_auction_flow_does_not_count():
    book = _book_15_01()
    book["auction_flow"]["confidence"] = 64.9
    census = count_veto_opponents("BUY", book, CONFIG)
    assert census["count"] == 1


def test_auction_flow_wait_does_not_count():
    book = _book_15_01()
    book["auction_flow"] = {"direction": "WAIT", "confidence": 80}
    assert count_veto_opponents("BUY", book, CONFIG)["count"] == 1


def test_empty_book_counts_nobody():
    assert count_veto_opponents("BUY", None, CONFIG)["count"] == 0
    assert count_veto_opponents("BUY", {}, CONFIG)["count"] == 0


def test_scale_in_and_activation_gate_share_the_counter():
    import io
    analysis = io.open(ROOT / "scripts" / "run_analysis.py", encoding="utf-8").read()
    manager = io.open(ROOT / "agents" / "open_trades_manager.py", encoding="utf-8").read()
    assert "count_veto_opponents" in analysis
    assert "count_veto_opponents" in manager


def test_activation_gate_vetoes_the_15_01_book():
    from agents.open_trades_manager import OpenTradesManager
    manager = OpenTradesManager(CONFIG)
    verdict = manager._activation_book_veto(_book_15_01(), "BUY")
    assert verdict["veto"] is True
    assert set(verdict["opponents"]) == {"price_action", "auction_flow"}


def test_card_no_longer_prints_the_misleading_consensus_line():
    """'Consensus: 0/6 agents · 0%' described a gate that no longer exists
    (2026-08-18b removed the consensus requirement). The card states what
    IS checked: the opposition census against the 2-veto."""
    import io
    src = io.open(ROOT / "scripts" / "run_analysis.py", encoding="utf-8").read()
    assert "Opposition check:</b>" in src
    assert "Consensus:</b> {agree_count}" not in src
