"""An empty ranking is a refusal with a name, not an AttributeError.

Live crash, 2026-08-17 ~21:4x — surfaced to the operator on an AGENT WATCH
card of all places:

    Map status: planner crashed: AttributeError: 'NoneType' object has no
    attribute 'get' @ session_planner.py:252 in build_plan

The path: smc produced setup_candidates (so the no-candidates fallback was
skipped), then _rank_planner_candidates filtered every one of them out and
returned []. ``primary`` became None and the very next line called
``primary.get("direction")``.

"Nothing rankable this cycle" is an ordinary market condition. It must
refuse the plan with a stored reason — like every other refusal branch —
so reports group it honestly instead of counting a crash.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.session_planner import SessionPlannerService as SessionPlanner

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def _results_with_unrankable_candidates() -> dict:
    """setup_candidates present (skips the fallback) but hopeless for ranking."""
    return {
        "symbol": "XAU/USD",
        "current_price": 4400.0,
        "session": {"trading_allowed": True, "allow_signals": True,
                    "current_session": "London Session", "session_quality": "HIGH"},
        "news": {"can_trade": True, "market_status": "SAFE"},
        "daily_bias": {},
        "smc": {
            "setup_candidates": [
                # Direction-less husk: enough to be a candidate, nothing to rank.
                {"id": "husk-1", "direction": None, "entry_price": None},
            ],
            "market_structure": {"trend": "RANGING", "structure_quality": "WEAK"},
            "liquidity": {}, "dealing_range": {},
        },
    }


def test_empty_ranking_refuses_instead_of_crashing(monkeypatch):
    planner = SessionPlanner(CONFIG)
    monkeypatch.setattr(planner, "_rank_planner_candidates", lambda *a, **k: [])

    plan = planner.build_plan(_results_with_unrankable_candidates(), persist=False)

    assert plan["plan_ready"] is False
    assert "crash" not in str(plan.get("plan_reason") or "").lower()
    assert "no ranked planner candidates" in str(plan.get("plan_reason") or "")


def test_the_refusal_is_a_normal_row_not_an_exception(monkeypatch):
    """build_plan must RETURN, not raise — reports read stored rows."""
    planner = SessionPlanner(CONFIG)
    monkeypatch.setattr(planner, "_rank_planner_candidates", lambda *a, **k: [])

    try:
        plan = planner.build_plan(_results_with_unrankable_candidates(), persist=False)
    except AttributeError as exc:  # pragma: no cover - the old defect
        raise AssertionError(f"the 21:4x crash is back: {exc}") from exc

    assert plan["plan_status"] == "NOT_READY"


def test_agent_watch_blocked_line_names_rule_a():
    """The card told the operator 'needs a 3rd agent' while showing THREE
    agents — the static line predates the family gate. It must now read the
    admission verdict and name the real block."""
    import io
    src = io.open("scripts/run_analysis.py", encoding="utf-8").read()
    assert "family_diversity_blocked" in src.split("AGENT WATCH card")[1][:8000]
    assert "all supporters are one family" in src
