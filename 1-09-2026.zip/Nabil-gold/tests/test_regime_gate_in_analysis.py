"""2026-08-19 upgrade tests: _apply_regime_and_correlation_gates wiring.

The gate lives in scripts/run_analysis.py and is called right after decision
assembly. These tests prove the two gates downgrade BUY/SELL -> WAIT exactly
when configured, and that failures fail open (decision untouched).
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import scripts.run_analysis as ra  # noqa: E402


def _decision(signal="BUY", path="PATH_2_TWO_AGENT_MACRO"):
    return {
        "decision": signal,
        "confidence": 74,
        "signal": {"order_type": "BUY_LIMIT", "symbol": "XAU/USD"},
        "execution_path_id": path,
        "warnings": [],
    }


class TestRegimeGateWiring:
    def test_range_regime_downgrades_two_agent_path(self):
        cfg = {"market_regime": {"enabled": True, "strict_range_gate": True}}
        all_results = {"market_regime": {"regime": "RANGE"}}
        d = ra._apply_regime_and_correlation_gates(_decision(), cfg, all_results, [], "XAU/USD")
        assert d["decision"] == "WAIT"
        assert d["regime_gate"]["applied"] is True

    def test_regime_disabled_leaves_decision(self):
        cfg = {"market_regime": {"enabled": False}}
        all_results = {"market_regime": {"regime": "RANGE"}}
        d = ra._apply_regime_and_correlation_gates(_decision(), cfg, all_results, [], "XAU/USD")
        assert d["decision"] == "BUY"

    def test_mt5_unavailable_fails_open(self):
        cfg = {"market_regime": {"enabled": True, "strict_range_gate": True}}
        d = ra._apply_regime_and_correlation_gates(
            _decision(), cfg, {"market_regime": {"regime": "MT5_UNAVAILABLE"}}, [], "XAU/USD"
        )
        assert d["decision"] == "BUY"

    def test_correlation_veto_downgrades_when_enforced(self, tmp_path):
        cfg = {
            "instruments": [{"symbol": "XAU/USD"}, {"symbol": "WTI/USD"}],
            "market_regime": {"enabled": False},
            "correlation_guard": {
                "enabled": True,
                "enforce": True,
                "lookback_days": 60,
                "veto_correlation": 0.55,
                "max_heat": 1.5,
                "daily_closes_path": str(tmp_path / "closes.json"),
            },
        }
        from services.correlation_exposure import CorrelationExposureManager

        m = CorrelationExposureManager(cfg)
        rng = np.random.default_rng(11)
        base = rng.normal(0, 1, 80).cumsum()
        for i in range(80):
            m.update_closes("XAU/USD", f"d{i:03d}", float(2000 + base[i] * 5))
            m.update_closes("WTI/USD", f"d{i:03d}", float(70 + base[i] * 0.3))
        open_trades = [{"symbol": "WTI/USD", "signal": "SELL"}]
        d = ra._apply_regime_and_correlation_gates(
            _decision("BUY"), cfg, {"market_regime": {"regime": "TREND_UP"}}, open_trades, "XAU/USD"
        )
        assert d["decision"] == "WAIT"
        assert d["correlation_veto"] is True
        assert "CORRELATION_VETO" in d["warnings"][-1]

    def test_gates_crash_fails_open(self):
        cfg = {
            "market_regime": {"enabled": True, "strict_range_gate": True},
            # instruments list present but correlation config missing entirely:
            "instruments": [{"symbol": "XAU/USD"}, {"symbol": "WTI/USD"}],
            "correlation_guard": {"enabled": True, "enforce": True},
        }
        d = ra._apply_regime_and_correlation_gates(
            _decision(), cfg, {"market_regime": {"regime": "TREND_UP"}}, [], "XAU/USD"
        )
        assert d["decision"] == "BUY"  # correlation manager defaulted; never crashes
