# -*- coding: utf-8 -*-
"""R19-A (2026-08-27): ONE post-news card per EVENT, covering all pairs.

Operator report: one Unemployment Claims release produced SIX near-identical
Telegram cards. The forex cards spoke about GOLD and the USD/JPY card quoted
invented gold levels ($2335/$2315 while gold trades near 4600) because
non-gold payloads carry no gold price. Pinned now:
  * a multi-instrument config sends ONE digest (global symbol-free key);
  * the digest payload carries every instrument, oil macro on WTI, a fresh
    price ONLY for the calling symbol;
  * a later instrument's cycle for the same event is silent;
  * legacy per-symbol path survives for single-instrument configs and for
    notifications.post_news_digest=false;
  * the digest prompt forbids gold-speak for forex and invented levels;
  * the renderer covers every requested pair (N/A for missing) with ONE
    notice block and escapes model text.
"""
from __future__ import annotations

from pathlib import Path

import pytest

import scripts.run_analysis as ra
from services import post_news_digest as pd
from services import telegram_bot as tb
from services.llm_review import GeminiReviewService

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(autouse=True)
def _tracker_in_tmp(tmp_path, monkeypatch):
    monkeypatch.setattr(tb, "_POST_NEWS_TRACKER_FILE",
                        tmp_path / "post_news_tracker.json")
    yield


def _events(minute_offset=-20):
    from datetime import datetime, timedelta, timezone
    t0 = datetime(2026, 8, 27, 13, 45, tzinfo=timezone.utc)
    base = t0 + timedelta(minutes=minute_offset)
    return [{"event": "Unemployment Claims", "tier": "TIER_1",
             "time": base.strftime("%Y-%m-%dT%H:%M"),
             "minutes_until": minute_offset}]


SYMBOLS = ["XAU/USD", "WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"]


def _digest_config(**extra):
    cfg = {"symbol": "XAU/USD",
           "instruments": [{"symbol": s} for s in SYMBOLS]}
    cfg.update(extra)
    return cfg


def _fake_pairs():
    return [{"symbol": s, "impact": "NEUTRAL", "confidence": 75,
             "recommendation": "stay neutral on {0}".format(s),
             "key_insight": "range"} for s in SYMBOLS]


class _GemDigest:
    enabled = True

    def __init__(self):
        self.digest_payloads = []
        self.single_calls = []

    def interpret_post_news_digest(self, payloads):
        self.digest_payloads.append(payloads)
        return {"available": True, "suppressed": False,
                "event": payloads[0].get("event_name"),
                "surprise": "IN_LINE", "pairs": _fake_pairs(),
                "symbols": [p["symbol"] for p in payloads],
                "key_insight": "usd soft"}

    def interpret_post_news(self, payload):  # legacy must stay silent
        self.single_calls.append(payload)
        return {"available": False}


class _GemLegacyOnly:
    enabled = True

    def __init__(self):
        self.single_calls = []
        self.digest_calls = 0

    def interpret_post_news(self, payload):
        self.single_calls.append(payload)
        return {"available": True, "suppressed": False,
                "event": payload.get("event_name"), "surprise": "IN_LINE",
                "gold_impact": "BULLISH", "oil_impact": "BULLISH",
                "dxy_impact": "NEUTRAL", "confidence": 80,
                "recommendation": "watch", "key_insight": "range"}

    def interpret_post_news_digest(self, payloads):
        self.digest_calls += 1
        return {"available": False}


class _Tg:
    def __init__(self):
        self.digest_sent = []
        self.legacy_sent = []

    def send_post_news_digest(self, analysis, event_name):
        self.digest_sent.append((analysis, event_name))
        return True

    def send_post_news_analysis(self, analysis, event_name, symbol):
        self.legacy_sent.append((analysis, event_name, symbol))
        return True


# -- the global, symbol-free dedup key --------------------------------------
def test_digest_event_key_is_symbol_free():
    assert pd.digest_event_key("b1") == pd.digest_event_key("b1")
    assert pd.digest_event_key("b1").startswith("ALL::")
    assert "XAU" not in pd.digest_event_key("b1")


# -- the digest path: ONE call, ONE card, full coverage ---------------------
def test_one_digest_card_for_all_instruments():
    gem, tg = _GemDigest(), _Tg()
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events()}, "XAU/USD", 4600.0,
        _digest_config(), database=None)
    assert len(gem.digest_payloads) == 1
    assert len(gem.single_calls) == 0
    assert len(tg.digest_sent) == 1 and len(tg.legacy_sent) == 0
    payloads = gem.digest_payloads[0]
    assert [p["symbol"] for p in payloads] == SYMBOLS
    by = {p["symbol"]: p for p in payloads}
    assert by["XAU/USD"]["current_price"] == 4600.0
    assert by["EUR/USD"]["current_price"] is None
    assert by["USD/JPY"]["current_price"] is None
    # the card text covers every instrument and ONE notice
    text = tb.TelegramService.send_post_news_digest.__doc__  # method exists
    assert text


def test_later_symbol_same_event_is_silent():
    gem, tg = _GemDigest(), _Tg()
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events()}, "XAU/USD", 4600.0,
        _digest_config(), database=None)
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events()}, "WTI/USD", 86.0,
        _digest_config(), database=None)
    assert len(gem.digest_payloads) == 1
    assert len(tg.digest_sent) == 1


def test_wti_digest_payload_carries_oil_macro(monkeypatch):
    class _OilAgent:
        def __init__(self, cfg):
            pass

        def analyze(self, data):
            return {"direction": "SELL", "confidence": 44,
                    "bias": "BEARISH_OIL", "score": -0.5,
                    "summary": "cracks narrowing"}

    monkeypatch.setattr(ra, "OilMacroAgent", _OilAgent)
    gem, tg = _GemDigest(), _Tg()
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events()}, "EUR/USD", 1.16,
        _digest_config(), database=None)
    payloads = gem.digest_payloads[0]
    by = {p["symbol"]: p for p in payloads}
    assert by["WTI/USD"]["oil_macro"]["direction"] == "SELL"
    assert by["EUR/USD"]["oil_macro"] is None


# -- legacy path survives (single instrument / kill switch) -----------------
def test_single_instrument_config_keeps_legacy_path():
    gem, tg = _GemLegacyOnly(), _Tg()
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events()}, "XAU/USD", 4600.0,
        {"symbol": "XAU/USD"}, database=None)
    assert len(gem.single_calls) == 1 and gem.digest_calls == 0
    assert len(tg.legacy_sent) == 1 and len(tg.digest_sent) == 0


def test_kill_switch_disables_the_digest():
    gem, tg = _GemLegacyOnly(), _Tg()
    cfg = _digest_config(notifications={"post_news_digest": False})
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events()}, "XAU/USD", 4600.0,
        cfg, database=None)
    assert gem.digest_calls == 0
    assert len(gem.single_calls) == 1
    assert len(tg.legacy_sent) == 1


# -- the digest prompt laws (gold-speak ban + invented-level ban) -----------
def test_digest_prompt_laws_exist():
    src = (ROOT / "services" / "llm_review.py").read_text(encoding="utf-8")
    assert "def interpret_post_news_digest" in src
    assert "never describe a forex pair in gold terms" in src
    assert "NEVER invent price levels" in src
    assert "exact symbol from DATA" in src


def test_digest_method_echoes_symbol_order(monkeypatch):
    svc = GeminiReviewService.__new__(GeminiReviewService)
    svc.enabled = True
    captured = {}

    def _fake_generate(prompt, kind="generic"):
        captured["prompt"] = prompt
        captured["kind"] = kind
        return {"available": True, "pairs": []}

    monkeypatch.setattr(svc, "_generate_json", _fake_generate)
    result = svc.interpret_post_news_digest(
        [{"symbol": "EUR/USD", "event_name": "CPI", "current_price": None},
         {"symbol": "XAU/USD", "event_name": "CPI", "current_price": 4600.0}])
    assert captured["kind"] == "post_news_digest"
    assert "EUR/USD" in captured["prompt"]
    assert result["symbols"] == ["EUR/USD", "XAU/USD"]


# -- the renderer: full coverage, ONE notice, escaped model text ------------
def test_render_covers_all_pairs_with_single_notice():
    text = pd.render_post_news_digest(
        "Unemployment Claims", _fake_pairs(), SYMBOLS,
        global_insight="usd soft", surprise="IN_LINE")
    for s in SYMBOLS:
        assert s in text
    assert text.count("NOTICE") == 1
    assert text.count("Key Insight") == 1
    assert "Gold Impact" not in text
    assert "2335" not in text and "2315" not in text


def test_render_marks_missing_pairs_as_na():
    partial = _fake_pairs()[:2]
    text = pd.render_post_news_digest("CPI", partial, SYMBOLS)
    assert "XAU/USD" in text and "WTI/USD" in text
    assert "N/A" in text
    assert "USD/JPY" in text  # requested but missing -> still visible


def test_render_escapes_model_text():
    pairs = [{"symbol": "EUR/USD", "impact": "NEUTRAL", "confidence": 70,
              "recommendation": "<script>alert(1)</script>"}]
    text = pd.render_post_news_digest("CPI", pairs, ["EUR/USD"])
    assert "<script>" not in text
    assert "&lt;script&gt;" in text


def test_render_never_raises_on_garbage():
    text = pd.render_post_news_digest("", [None, "junk", {}], [])
    assert "Post-News Digest" in text
