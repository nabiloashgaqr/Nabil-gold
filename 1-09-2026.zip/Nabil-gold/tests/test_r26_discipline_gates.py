# -*- coding: utf-8 -*-
"""R26 (2026-08-31): admission-discipline gates + weekly per-path report."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services.admission_discipline_gates import (  # noqa: E402
    counter_macro_block, trend_family_only_block, stop_distance_band,
    rr_floor_block, discipline_violations, gate_config,
)

CFG = {
    "risk_settings": {"min_rr_ratio": 1.5},
    "discipline_gates": {
        "enabled": True,
        "macro_block_conf": 70.0,
        "enforce_stop_band": True,   # opt-in: only these tests exercise it
        "enforce_rr_floor": True,    # the live default keeps these false
        "stop_band_default": {"min_points": 230.0, "max_points": 400.0},
        "stop_band_by_symbol": {"XAU/USD": {"min_points": 270.0, "max_points": 400.0}},
        "thesis_exit_loss_cap_usd": 100.0,
    },
}


def _buy(symbol="USD/JPY", **over):
    d = {
        "decision": "BUY", "symbol": symbol,
        "current_price": 160.0,
        "signal": {"stop_loss": 159.70, "tp1": 160.30, "tp2": 160.55,
                   "entry": {"price": 160.0}},
        "market_context": {"macro_direction": {"bias": "BEARISH", "confidence": 74.0}},
        "execution_path_id": "PATH_1_THREE_AGENT_CONSENSUS",
    }
    d.update(over)
    return d


# ── counter-macro (R26.2: HARD veto, no tape/SMC overrule; Path 9/scalp exempt) ─
def test_counter_macro_against_confident_macro_is_blocked():
    # yen BUY, macro SELL 74 -> hard veto regardless of tape/SMC
    res = counter_macro_block(_buy(), CFG, {"auction_flow": {"state": "FOREIGN_FEED_REFUSED", "weight": 0.0}})
    assert res is not None and "MACRO VETO" in res


def test_counter_macro_hard_veto_is_not_overruled_by_live_tape_and_smc():
    # Operator order 2026-08-31: a live tape + qualified SMC must NOT rescue a
    # counter-macro consensus trade (this was the gold BUY defect).
    d = _buy()
    d["support_agents"] = ["smc", "technical"]
    results = {"auction_flow": {"state": "LIVE_TAPE_RESPONSIVE", "weight": 0.2,
                                "direction": "BUY", "confidence": 72.0},
               "smc": {"direction": "BUY", "confidence": 68.0}}
    assert counter_macro_block(d, CFG, results) is not None


def test_counter_macro_path9_and_scalp_are_exempt():
    d9 = _buy(); d9["execution_path_id"] = "PATH_9_LIQUIDITY_SWEEP_REVERSAL"
    assert counter_macro_block(d9, CFG, {}) is None
    ds = _buy(); ds["execution_path_id"] = "R25_SCALP_FADE"
    assert counter_macro_block(ds, CFG, {}) is None


def test_counter_macro_low_conf_or_aligned_passes():
    d = _buy()
    d["market_context"] = {"macro_direction": {"bias": "BEARISH", "confidence": 60.0}}
    assert counter_macro_block(d, CFG, {}) is None
    d2 = _buy()
    d2["market_context"] = {"macro_direction": {"bias": "BULLISH", "confidence": 90.0}}
    assert counter_macro_block(d2, CFG, {}) is None


# ── trend family only ───────────────────────────────────────────────────────
def test_all_trend_family_over_dead_tape_blocked():
    d = _buy()
    d["market_context"] = {}  # no macro opposition here; isolate this gate
    d["support_agents"] = ["technical", "mtf", "classical", "price_action"]
    results = {"auction_flow": {"state": "NO_TAPE_WEIGHT_0", "weight": 0.0}}
    res = trend_family_only_block(d, CFG, results)
    assert res is not None and "trend family" in res


def test_multi_family_or_live_tape_passes():
    d = _buy()
    d["market_context"] = {}
    d["support_agents"] = ["technical", "smc"]  # smc outside trend family
    results = {"auction_flow": {"state": "NO_TAPE", "weight": 0.0}}
    assert trend_family_only_block(d, CFG, results) is None
    d2 = _buy()
    d2["market_context"] = {}
    d2["support_agents"] = ["technical", "mtf", "classical"]
    assert trend_family_only_block(d2, CFG, {"auction_flow": {"state": "OK", "direction": "BUY"}}) is None


# ── stop band ───────────────────────────────────────────────────────────────
def test_stop_too_tight_for_oil_blocked():
    # WTI stop 116 points (the live loss) vs band min 230
    d = {"decision": "SELL", "symbol": "WTI/USD", "current_price": 82.23,
         "signal": {"stop_loss": 83.39, "tp1": 81.0, "tp2": 80.12,
                    "entry": {"price": 82.23}},
         "market_context": {}, "execution_path_id": "PATH_5_TWO_AGENT_AUCTION"}
    res = stop_distance_band(d, CFG)
    assert res is not None and "tighter" in res


def test_stop_within_band_passes():
    # JPY-like 300 points within [230,400]
    d = _buy()
    d["signal"] = {"stop_loss": 159.70, "tp2": 160.9, "tp1": 160.3,
                   "entry": {"price": 160.0}}  # 300 pts for JPY (point 0.001)
    # JPY point size: 0.001 => 0.30 price = 300 pts
    assert stop_distance_band(d, CFG) is None


def test_gold_band_applies():
    d = {"decision": "BUY", "symbol": "XAU/USD", "current_price": 4600.0,
         "signal": {"stop_loss": 4590.0, "tp2": 4660.0, "tp1": 4630.0,
                    "entry": {"price": 4600.0}},  # 100 pts < 270 min
         "market_context": {}, "execution_path_id": "PATH_1_THREE_AGENT_CONSENSUS"}
    res = stop_distance_band(d, CFG)
    assert res is not None and "270" in res


# ── RR floor ────────────────────────────────────────────────────────────────
def test_rr_below_floor_blocked():
    d = _buy()
    # risk 300 pts (0.30 @ 0.001), reward tp2 0.55 -> 550 pts => ~1.8 ok;
    # make tp2 160.42 -> 420 pts / 300 = 1.4 < 1.5
    d["signal"] = {"stop_loss": 159.70, "tp1": 160.2, "tp2": 160.42,
                   "entry": {"price": 160.0}}
    res = rr_floor_block(d, CFG)
    assert res is not None and "1.50" in res


def test_disabled_gates_fail_open():
    off = {"discipline_gates": {"enabled": False}, "risk_settings": {"min_rr_ratio": 1.5}}
    d = _buy()
    assert discipline_violations(d, off, {}) == []


# ── weekly report ───────────────────────────────────────────────────────────
def test_weekly_report_aggregates(monkeypatch, tmp_path):
    import scripts.weekly_path_report as rep
    from datetime import datetime, timezone, timedelta
    now = datetime.now(timezone.utc)
    recent = (now - timedelta(days=1)).isoformat()
    trades = [
        {"id": "w1", "status": "TP2_HIT", "execution_path_id": "PATH_5_TWO_AGENT_AUCTION",
         "final_pnl": 80.0, "closed_at": recent},
        {"id": "l1", "status": "SL_HIT", "execution_path_id": "PATH_5_TWO_AGENT_AUCTION",
         "final_pnl": -40.0, "closed_at": recent},
        {"id": "c1", "status": "CANCELLED", "execution_path_id": "PATH_6_TWO_AGENT_OTE",
         "mt5_ticket": None, "closed_at": recent},
    ]
    monkeypatch.setattr(rep, "ROOT", tmp_path)
    (tmp_path / "storage").mkdir()
    import json
    (tmp_path / "storage" / "trades.json").write_text(json.dumps(trades), encoding="utf-8")
    out = rep.build_report(7)
    p5 = next(r for r in out["paths"] if r["path"] == "PATH_5_TWO_AGENT_AUCTION")
    assert p5["wins"] == 1 and p5["losses"] == 1
    assert p5["profit_factor"] == 2.0
    assert p5["avg_win"] == 80.0 and p5["avg_loss"] == -40.0


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
