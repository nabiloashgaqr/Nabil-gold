"""Every saved trade row must name the route that opened it — at the top level.

TRADE_20260817_110616_156874_f4fa6668 was the first gold trade opened after
the unified-65 rollout: a session-plan ladder leg converted to market when
price reached the mapped area. When the operator queried the stored row:

    "entry_mode": null, "execution_path": null, "warnings": null

The ladder decision DID carry entry_mode="session_plan_ladder_market" and a
stamped execution path — but save_trade kept them only inside the
signal_snapshot blob. Any report, dashboard, or operator query that reads
trade rows directly (which is all of them) saw null and could not say which
of the five paths opened the trade without parsing nested JSON.

These fields are the provenance of real money decisions; they ride at the
top level of the row from now on, for every route (ladder, consensus,
two-agent, path 4/5).
"""

from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.database import DatabaseService
from services.execution_paths import stamp_execution_path
from utils.helpers import load_trades


def _db(tmp_path: Path) -> DatabaseService:
    db = DatabaseService({"database": {"url": None, "key": None,
                                       "local_fallback_file": str(tmp_path / "trades.json")}})
    db.local_path = tmp_path / "trades.json"
    return db


def _ladder_decision() -> dict:
    decision = {
        "decision": "BUY",
        "symbol": "XAU/USD",
        "confidence": 73,
        "current_price": 4400.42,
        "entry_mode": "session_plan_ladder_market",
        "warnings": ["Daily Bias (4H) advisory: bias=NEUTRAL"],
        "signal": {
            "type": "BUY",
            "entry": {"price": 4400.42, "kind": "MARKET", "order_type": "BUY_MARKET"},
            "stop_loss": 4373.0,
            "tp1": 4425.0,
            "tp2": 4450.0,
        },
    }
    # The ladder stamps its legs from the planner gate's shared admission
    # (run_analysis: `stamp_execution_path(ladder_decision, gate)`), and the
    # gate's path is one of the canonical admissions.
    stamp_execution_path(decision, {"path": "THREE_AGENT_CONSENSUS"})
    return decision


def test_ladder_trade_row_names_its_route(tmp_path: Path) -> None:
    db = _db(tmp_path)
    trade_id = db.save_trade(_ladder_decision())

    row = [t for t in load_trades(db.local_path) if t["id"] == trade_id][0]

    assert row["entry_mode"] == "session_plan_ladder_market"
    assert row.get("execution_path_id"), "execution_path_id missing from the row"
    assert row.get("execution_path_name"), "execution_path_name missing from the row"
    assert isinstance(row.get("warnings"), list)
    assert row["warnings"], "decision warnings were dropped from the row"


def test_two_agent_trade_row_names_its_confirmer(tmp_path: Path) -> None:
    db = _db(tmp_path)
    decision = _ladder_decision()
    decision["entry_mode"] = "two_agent_auction"
    decision["confirm_source"] = "auction"
    stamp_execution_path(decision, "TWO_AGENT_AUCTION")

    trade_id = db.save_trade(decision)
    row = [t for t in load_trades(db.local_path) if t["id"] == trade_id][0]

    assert row["entry_mode"] == "two_agent_auction"
    assert row["confirm_source"] == "auction"
    assert row["entry_path"] == decision["entry_path"]


def test_a_route_less_decision_stores_none_not_a_crash(tmp_path: Path) -> None:
    """Legacy/manual rows without provenance still save cleanly."""
    db = _db(tmp_path)
    bare = {
        "decision": "SELL",
        "symbol": "XAU/USD",
        "confidence": 70,
        "current_price": 4400.0,
        "signal": {"type": "SELL",
                   "entry": {"price": 4400.0, "kind": "MARKET"},
                   "stop_loss": 4420.0, "tp1": 4385.0, "tp2": 4360.0},
    }
    trade_id = db.save_trade(bare)
    row = [t for t in load_trades(db.local_path) if t["id"] == trade_id][0]

    assert row["entry_mode"] is None
    assert row["warnings"] == []


def test_provenance_survives_at_top_level_not_only_in_snapshot(tmp_path: Path) -> None:
    """The regression itself: reading the ROW (not the snapshot) must answer."""
    db = _db(tmp_path)
    trade_id = db.save_trade(_ladder_decision())
    row = [t for t in load_trades(db.local_path) if t["id"] == trade_id][0]

    surface = {k: row.get(k) for k in ("entry_mode", "execution_path_id", "warnings")}
    assert None not in (surface["entry_mode"], surface["execution_path_id"])
    # And the snapshot keeps its own full copy, unchanged.
    assert row["signal_snapshot"]["entry_mode"] == "session_plan_ladder_market"
