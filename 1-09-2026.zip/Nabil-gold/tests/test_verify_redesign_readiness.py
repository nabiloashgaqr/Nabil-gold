"""2026-08-19: redesign readiness gate - unit + end-to-end tests."""
from __future__ import annotations

import json
import subprocess
import sys
from datetime import date
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import scripts.verify_redesign_readiness as vr  # noqa: E402

PROP = vr._proposal({})


def _row(side="BUY", agents=None, macro=("BULLISH_GOLD", 60), smc=None, auction=("BUY", 70)):
    default_agents = {
        "technical": {"direction": side, "confidence": 74},
        "multitimeframe": {"direction": side, "confidence": 70},
        "smc": {"direction": side, "confidence": 71},
        "classical": {"direction": side, "confidence": 66},
        "price_action": {"direction": "SELL" if side == "BUY" else "BUY", "confidence": 40},
    }
    if agents is not None:
        default_agents = agents
    if auction is not None:
        default_agents["auction_flow"] = {"direction": auction[0], "confidence": auction[1]}
    return {
        "generated_at": "2026-08-19T10:00:00+00:00",
        "current_price": 4000.0,
        "agents": default_agents,
        "macro": {"bias": macro[0], "confidence": macro[1]} if macro else {},
        "smc_measurement": smc or {"setup_direction": "WAIT"},
        "admission": {
            "BUY": {"allow": side == "BUY"},
            "SELL": {"allow": side == "SELL"},
        },
    }


class TestNewPathA:
    def test_two_families_plus_macro_ok(self):
        row = _row("BUY")
        ok, info = vr.new_path_a(row, "BUY", PROP, auction_voter=True)
        assert ok is True
        assert set(info["families"]) >= {"trend", "structure", "tape"}
        assert "auction_flow" in info["supporters"]  # voter under the new design
        assert info["confirmer"] == "macro"

    def test_auction_confirms_when_macro_neutral(self):
        # default mode: auction is an allowed confirmer for mixed-family books
        row = _row("BUY", macro=("NEUTRAL", 30), auction=("BUY", 70))
        ok, info = vr.new_path_a(row, "BUY", PROP, auction_voter=False)
        assert ok is True
        assert info["confirmer"] == "auction"

    def test_no_confirmer_refused(self):
        row = _row("BUY", macro=("NEUTRAL", 30), auction=("WAIT", 50))
        ok, info = vr.new_path_a(row, "BUY", PROP, auction_voter=False)
        assert ok is False
        assert "no_confirmer" in info["why"]

    def test_single_family_refused(self):
        row = _row("BUY", agents={
            "technical": {"direction": "BUY", "confidence": 75},
            "multitimeframe": {"direction": "BUY", "confidence": 72},
            "classical": {"direction": "SELL", "confidence": 30},
            "smc": {"direction": "WAIT", "confidence": 10},
            "price_action": {"direction": "WAIT", "confidence": 10},
        }, auction=None)
        ok, info = vr.new_path_a(row, "BUY", PROP, auction_voter=True)
        assert ok is False
        assert info["why"] == "single_family"

    def test_no_macro_confirmation_refused_in_macro_only_mode(self):
        row = _row("BUY", macro=("NEUTRAL", 30), auction=("BUY", 70))
        ok, info = vr.new_path_a(row, "BUY", PROP, auction_voter=True, confirmer_mode="macro_only")
        assert ok is False
        assert "macro_confirmer" in info["why"]

    def test_macro_bearish_refuses_buy_in_macro_only_mode(self):
        row = _row("BUY", macro=("BEARISH_GOLD", 60), auction=("BUY", 70))
        ok, _ = vr.new_path_a(row, "BUY", PROP, auction_voter=True, confirmer_mode="macro_only")
        assert ok is False

    def test_auction_not_voter_cannot_carry(self):
        # two trend agents only + auction as external confirmer is NOT allowed
        # in the new path A (confirmer is macro-only by design)
        row = _row("BUY", agents={
            "technical": {"direction": "BUY", "confidence": 75},
            "multitimeframe": {"direction": "BUY", "confidence": 72},
            "classical": {"direction": "WAIT", "confidence": 10},
            "smc": {"direction": "WAIT", "confidence": 10},
            "price_action": {"direction": "WAIT", "confidence": 10},
        }, macro=("BULLISH_GOLD", 40), auction=("WAIT", 50))
        ok, _ = vr.new_path_a(row, "BUY", PROP, auction_voter=False)
        assert ok is False  # single family anyway
        ok2, _ = vr.new_path_a(row, "BUY", PROP, auction_voter=True)
        assert ok2 is False  # still single family + macro weak


class TestNewPathB:
    def _smc(self, **over):
        base = {"setup_direction": "BUY", "dominance": 78, "return_probability": 61,
                "quality": 76, "trigger_score": 72}
        base.update(over)
        return base

    def test_qualified_map_plus_auction_ok(self):
        row = _row("BUY", smc=self._smc(), auction=("BUY", 71))
        ok, info = vr.new_path_b(row, "BUY", PROP)
        assert ok is True

    def test_map_quality_below_floor_refused(self):
        row = _row("BUY", smc=self._smc(quality=55), auction=("BUY", 71))
        ok, info = vr.new_path_b(row, "BUY", PROP)
        assert ok is False
        assert "quality" in info["why"]

    def test_auction_weak_refused(self):
        row = _row("BUY", smc=self._smc(), auction=("BUY", 55))
        ok, info = vr.new_path_b(row, "BUY", PROP)
        assert ok is False
        assert "auction" in info["why"]

    def test_wrong_side_refused(self):
        row = _row("BUY", smc=self._smc(setup_direction="SELL"), auction=("BUY", 71))
        ok, _ = vr.new_path_b(row, "BUY", PROP)
        assert ok is False


class TestMacroNeutrality:
    def test_fraction(self):
        rows = [
            {"macro": {"bias": "BULLISH_GOLD", "confidence": 60}},
            {"macro": {"bias": "", "confidence": 0}},
            {"macro": {"bias": "NEUTRAL", "confidence": 30}},
            {"macro": {"bias": "BEARISH_GOLD", "confidence": 58}},
        ]
        m = vr.macro_neutral_fraction(rows, PROP)
        assert m["neutral_pct"] == 50.0
        assert m["verdict"] == "NO-GO"

    def test_empty_is_na(self):
        m = vr.macro_neutral_fraction([], PROP)
        assert m["verdict"] == "N/A"


class TestAuctionPromotion:
    def test_no_data_reports_gap_no_go(self, tmp_path):
        m = vr.auction_promotion_metrics(tmp_path, PROP, config={}, rows=[])
        assert m is not None
        assert m["verdict"] == "NO-GO"
        assert "no resolved trades" in m["detail"]

    def test_criteria_met_go(self, tmp_path):
        rows = []
        for i in range(10):
            rows.append({"status": "TP2_HIT", "final_pnl": 100.0,
                         "execution_path_id": "PATH_4_SMC_MAP_AUCTION"})
        for i in range(10):
            rows.append({"status": "SL_HIT", "final_pnl": -100.0,
                         "execution_path_id": "PATH_1_THREE_AGENT_CONSENSUS"})
        # rows= injection: isolated from any live local trade book
        m = vr.auction_promotion_metrics(tmp_path, PROP, config={}, rows=rows)
        assert m is not None
        assert m["auction_paths"]["resolved"] == 10
        assert m["auction_paths"]["hit_pct"] == 100.0
        assert m["verdict"] == "GO"

    def test_insufficient_sample_no_go(self, tmp_path):
        rows = [{"status": "TP2_HIT", "final_pnl": 50.0, "execution_path_id": "PATH_5_TWO_AGENT_AUCTION"}]
        m = vr.auction_promotion_metrics(tmp_path, PROP, config={}, rows=rows)
        assert m["verdict"] == "NO-GO"
        assert "resolved 1/8" in m["detail"]


class TestEndToEnd:
    def _fixture(self, root: Path) -> None:
        base = root / "storage" / "agent_measurements"
        base.mkdir(parents=True, exist_ok=True)
        rows = []
        for i in range(12):
            side = "BUY"
            rows.append({
                "generated_at": f"2026-08-19T{i:02d}:00:00+00:00",
                "current_price": 4000.0 + i * 1.5,
                "agents": {
                    "technical": {"direction": side, "confidence": 74},
                    "multitimeframe": {"direction": side, "confidence": 70},
                    "smc": {"direction": side, "confidence": 71},
                    "classical": {"direction": side, "confidence": 66},
                    "price_action": {"direction": "SELL", "confidence": 40},
                    "auction_flow": {"direction": side, "confidence": 69},
                },
                "macro": {"bias": "BULLISH_GOLD", "confidence": 60},
                "smc_measurement": {"setup_direction": "WAIT"},
                "admission": {
                    "BUY": {"allow": True, "path": "THREE_AGENT_CONSENSUS"},
                    "SELL": {"allow": False},
                },
            })
        (base / "agent_system_2026-08-19.jsonl").write_text(
            "\n".join(json.dumps(r) for r in rows), encoding="utf-8")

    def test_end_to_end_ascii_safe(self, tmp_path):
        self._fixture(tmp_path)
        script = Path(vr.__file__).resolve()
        out = subprocess.run(
            [sys.executable, str(script), "--root", str(tmp_path), "--days", "7"],
            capture_output=True, text=True, timeout=180,
        )
        assert out.returncode == 0, out.stderr
        assert "M1 AUCTION_PROMOTION" in out.stdout
        assert "M2 MACRO_NEUTRALITY" in out.stdout
        assert "M3 NEW_DESIGN_SURVIVAL" in out.stdout
        assert "M4 AUCTION_VOTER_IMPACT" in out.stdout
        assert "OVERALL:" in out.stdout
        json_path = tmp_path / "diagnostics" / f"redesign_readiness_{date.today().isoformat()}.json"
        assert json_path.exists()
        data = json.loads(json_path.read_text(encoding="utf-8"))
        assert data["rows"] == 12

    def test_no_data_graceful(self, tmp_path):
        (tmp_path / "storage").mkdir(parents=True, exist_ok=True)
        script = Path(vr.__file__).resolve()
        out = subprocess.run(
            [sys.executable, str(script), "--root", str(tmp_path), "--days", "7"],
            capture_output=True, text=True, timeout=180,
        )
        assert out.returncode == 0
        # no data at all -> M1 reports the gap as NO-GO, so OVERALL is BLOCKED
        assert "OVERALL: BLOCKED" in out.stdout
        assert "M1" in out.stdout
