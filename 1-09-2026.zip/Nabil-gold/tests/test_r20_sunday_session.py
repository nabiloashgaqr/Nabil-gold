# -*- coding: utf-8 -*-
"""BUILD31-R20 (2026-08-27): 24h trading Mon-Fri, NO daily break.

Operator directive (after correcting an earlier draft that wrongly added
Sunday): trade daily Monday-Friday, 24 hours a day; remove any nightly or
morning break. Market fact: in northern summer the FX/gold week runs
Sunday 21:00 UTC -> Friday 21:00 UTC = Monday 00:00 -> Saturday 00:00 in
Asia/Hebron, so the canonical Mon-Fri 00:00-24:00 Hebron session matches
the real market week hour-for-hour. Pinned here:
  * the shipped config holds exactly ONE full-day Mon-Fri session with
    signals allowed, and NO Friday cutoff, and no stale 02:00-22:00 text;
  * the session agent behaves accordingly (Mon/Fri evening allowed,
    Saturday blocked, Sunday daytime blocked, and the Sunday-evening open
    is covered by the Monday calendar day);
  * the R20 patch removes partial/break sessions from a production config
    and is idempotent, preserving unrelated user keys.
"""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from agents.trading_session_agent import TradingSessionAgent

DAYS = [0, 1, 2, 3, 4]  # Monday..Friday


def _find_patch_script():
    cand = os.path.join(ROOT, "config_patch", "APPLY_R20_SESSION_DAYS.py")
    return cand if os.path.exists(cand) else None


def _shipped_config():
    return json.loads(
        (Path(ROOT) / "config.json").read_text(encoding="utf-8"))


class TestShippedConfigContract(unittest.TestCase):
    def test_one_full_day_mon_fri_session_no_breaks(self):
        cfg = _shipped_config()
        hours = cfg["trading_hours"]
        self.assertTrue(hours["enabled"])
        sessions = hours["sessions"]
        self.assertEqual(len(sessions), 1, "any second session is a potential break")
        session = sessions[0]
        self.assertEqual(sorted(session["days"]), sorted(DAYS))
        self.assertEqual(session["start_hour"], 0)
        self.assertEqual(session["end_hour"], 24)
        self.assertTrue(session["allow_signals"])
        self.assertFalse(hours.get("enforce_friday_cutoff", False))

    def test_no_stale_break_window_text(self):
        cfg = _shipped_config()
        tm = cfg.get("trade_management") or {}
        self.assertNotIn("02:00-22:00",
                         str(tm.get("description_update_outside_trading_hours", "")))


class TestSessionAgentBehavior(unittest.TestCase):
    """Every case states its Hebron wall-clock meaning."""

    def setUp(self):
        self.agent = TradingSessionAgent(_shipped_config())

    def _check(self, y, m, d, h):
        return self.agent.check(now=datetime(y, m, d, h, 0, tzinfo=timezone.utc))

    def test_monday_allowed(self):
        self.assertTrue(self._check(2026, 8, 31, 12, ).get("trading_allowed"))

    def test_friday_evening_allowed(self):
        # Fri 20:00 UTC = Fri 23:00 Hebron - inside the session
        self.assertTrue(self._check(2026, 8, 28, 20).get("trading_allowed"))

    def test_saturday_blocked(self):
        self.assertFalse(self._check(2026, 8, 29, 12).get("trading_allowed"))

    def test_sunday_daytime_blocked(self):
        # Sun 12:00 UTC = Sun 15:00 Hebron: closed market, no session
        self.assertFalse(self._check(2026, 8, 30, 12).get("trading_allowed"))

    def test_sunday_evening_open_is_covered_by_monday(self):
        # Sun 21:30 UTC = Mon 00:30 Hebron in summer = the real weekly open
        self.assertTrue(self._check(2026, 8, 30, 21).get("trading_allowed"))


@unittest.skipIf(_find_patch_script() is None, "R20 patch script not shipped")
class TestR20Patch(unittest.TestCase):
    def test_patch_removes_break_and_is_idempotent(self):
        script = _find_patch_script()
        base = _shipped_config()
        # a production config carrying a nightly break (legacy 02:00-22:00)
        base["trading_hours"]["sessions"] = [{
            "name": "Legacy Day Session", "start_hour": 2, "start_minute": 0,
            "end_hour": 22, "end_minute": 0, "days": [0, 1, 2, 3, 4],
            "quality": "MEDIUM", "allow_signals": True, "allow_reports": True}]
        base["trading_hours"]["enforce_friday_cutoff"] = True
        base["user_custom_key"] = {"keep": "me"}
        with tempfile.TemporaryDirectory() as tmp:
            cfg_path = os.path.join(tmp, "config.json")
            with open(cfg_path, "w", encoding="utf-8") as fh:
                json.dump(base, fh, ensure_ascii=False)
            r1 = subprocess.run([sys.executable, script, "--root", tmp],
                                capture_output=True, text=True, timeout=60)
            self.assertEqual(r1.returncode, 0, r1.stdout + r1.stderr)
            self.assertIn("PATCHED", r1.stdout)
            merged = json.loads(Path(cfg_path).read_text(encoding="utf-8"))
            sessions = merged["trading_hours"]["sessions"]
            self.assertEqual(len(sessions), 1)
            self.assertEqual(sorted(sessions[0]["days"]), sorted(DAYS))
            self.assertEqual(sessions[0]["start_hour"], 0)
            self.assertEqual(sessions[0]["end_hour"], 24)
            self.assertFalse(merged["trading_hours"]["enforce_friday_cutoff"])
            self.assertEqual(merged["user_custom_key"], {"keep": "me"})
            # second run: idempotent
            r2 = subprocess.run([sys.executable, script, "--root", tmp],
                                capture_output=True, text=True, timeout=60)
            self.assertEqual(r2.returncode, 0)
            self.assertIn("already true", r2.stdout)

    def test_patch_fixes_stale_description(self):
        script = _find_patch_script()
        base = _shipped_config()
        base.setdefault("trade_management", {})[
            "description_update_outside_trading_hours"] = (
            "old text ... signal generation restricted to 02:00-22:00 ...")
        with tempfile.TemporaryDirectory() as tmp:
            cfg_path = os.path.join(tmp, "config.json")
            with open(cfg_path, "w", encoding="utf-8") as fh:
                json.dump(base, fh, ensure_ascii=False)
            r1 = subprocess.run([sys.executable, script, "--root", tmp],
                                capture_output=True, text=True, timeout=60)
            self.assertEqual(r1.returncode, 0, r1.stdout + r1.stderr)
            self.assertIn("FIXED", r1.stdout)
            merged = json.loads(Path(cfg_path).read_text(encoding="utf-8"))
            self.assertNotIn(
                "02:00-22:00",
                merged["trade_management"]["description_update_outside_trading_hours"])


if __name__ == "__main__":
    unittest.main()
