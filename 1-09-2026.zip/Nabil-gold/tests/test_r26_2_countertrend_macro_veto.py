# -*- coding: utf-8 -*-
"""R26.2 (2026-08-31): counter-trend gold BUY defect.

Fixes under test:
  * macro veto threshold lowered 70 -> 55 (config + code default).
  * setup/direction contradiction gate (CONTINUATION_BREAKDOWN must agree with
    the higher-timeframe trend).
  * macro opposition is a HARD veto on the unconfirmed Path-1 consensus (macro
    is not a core voter, so its opposition never reached the admission verdict).
  * macro reader sees nested news_context/market_context AND all_results books.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services.admission_discipline_gates import (  # noqa: E402
    counter_macro_block, setup_direction_contradiction_block,
    discipline_violations, gate_config,
)
from services.thesis_consensus import evaluate_directional_admission  # noqa: E402
from utils.helpers import load_config  # noqa: E402


CFG55 = {"discipline_gates": {"enabled": True, "macro_block_conf": 55.0}}


def _dec(side="BUY", macro_bias=None, macro_conf=58.0, **over):
    d = {"decision": side, "symbol": "XAU/USD",
         "execution_path_id": "PATH_1_THREE_AGENT_CONSENSUS",
         "signal": {"stop_loss": 4393, "tp1": 4449, "tp2": 4477,
                    "entry": {"price": 4421.9}}}
    if macro_bias:
        d["news_context"] = {"macro": {"macro_direction": {
            "bias": macro_bias, "confidence": macro_conf}}}
    d.update(over)
    return d


# ── 1) threshold 55 fires where 70 did not ──────────────────────────────────
def test_macro_veto_fires_at_58_percent_under_new_threshold():
    # SELL macro at 58% > 55 floor, dead tape, no SMC -> blocked.
    d = _dec("BUY", "BEARISH_GOLD", 58.0)
    res = counter_macro_block(d, CFG55, {"auction_flow": {"state": "FOREIGN_FEED_REFUSED", "weight": 0.0}})
    assert res is not None and ("HARD MACRO VETO" in res or "counter-macro" in res)


def test_macro_below_55_still_passes():
    d = _dec("BUY", "BEARISH_GOLD", 50.0)
    res = counter_macro_block(d, CFG55, {"auction_flow": {"state": "FOREIGN_FEED_REFUSED", "weight": 0.0}})
    assert res is None


def test_live_config_macro_block_conf_is_55():
    cfg = load_config()
    assert float(cfg["discipline_gates"]["macro_block_conf"]) == 55.0
    assert float(gate_config({}).get("macro_block_conf")) == 55.0


# ── 2) setup/direction contradiction ────────────────────────────────────────
def test_breakdown_setup_against_downtrend_buy_is_blocked():
    d = _dec("BUY", "BEARISH_GOLD", 74.0, setup_type="CONTINUATION_BREAKDOWN")
    results = {"multitimeframe": {"direction": "SELL", "confidence": 92.0},
               "macro_fundamental": {"direction": "SELL", "confidence": 74.0}}
    res = setup_direction_contradiction_block(d, CFG55, results)
    assert res is not None and "contradiction" in res


def test_breakdown_setup_with_downtrend_sell_passes():
    d = _dec("SELL", "BEARISH_GOLD", 74.0, setup_type="CONTINUATION_BREAKDOWN")
    results = {"multitimeframe": {"direction": "SELL", "confidence": 92.0}}
    assert setup_direction_contradiction_block(d, CFG55, results) is None


def test_reversal_setup_is_not_gated_by_contradiction():
    # A reversal is SUPPOSED to trade the turn; it must clear macro/smc instead.
    d = _dec("BUY", setup_type="LIQUIDITY_REVERSAL")
    results = {"multitimeframe": {"direction": "SELL", "confidence": 92.0}}
    assert setup_direction_contradiction_block(d, CFG55, results) is None


# ── 3) macro hard-veto on the unconfirmed Path-1 consensus ──────────────────
def _book():
    return {
        "technical": {"signal": "BUY", "confidence": 80.0},
        "multitimeframe": {"signal": "BUY", "confidence": 75.0},
        "classical": {"signal": "BUY", "confidence": 78.0},
        "smc": {"signal": "WAIT", "confidence": 30.0},
        "price_action": {"signal": "WAIT", "confidence": 40.0},
    }


_CFG = {
    "agent_weights": {"technical": 0.20, "multitimeframe": 0.15, "classical": 0.25,
                      "smc": 0.20, "price_action": 0.20},
    "signal_requirements": {
        "agent_min_confidence": 65, "min_agents_agree": 3, "min_consensus_confidence": 72,
        "two_agent_entry": {"enabled": True, "min_agents_agree": 2,
                            "min_consensus_confidence": 72,
                            "macro_confirmation": {"enabled": True, "min_confidence": 55},
                            "gemini_confirmation": {"enabled": True, "min_confidence": 70}}},
}


def test_path1_counter_trend_consensus_vetoed_by_macro():
    book = _book()
    book["news_context"] = {"macro": {"macro_direction": {"bias": "BEARISH_GOLD", "confidence": 74.0}}}
    r = evaluate_directional_admission("BUY", book, _CFG)
    assert r["allow"] is False
    assert r.get("macro_veto") is True


def test_path1_consensus_with_aligned_macro_admitted():
    book = _book()
    book["news_context"] = {"macro": {"macro_direction": {"bias": "BULLISH_GOLD", "confidence": 60.0}}}
    r = evaluate_directional_admission("BUY", book, _CFG)
    assert r["allow"] is True
    assert not r.get("macro_veto")


# ── 4) macro reader covers the all_results book ─────────────────────────────
def test_gate_reads_macro_from_all_results_book():
    d = {"decision": "BUY", "symbol": "XAU/USD",
         "execution_path_id": "PATH_1_THREE_AGENT_CONSENSUS", "signal": {}}
    results = {"macro_fundamental": {"direction": "SELL", "confidence": 74.0},
               "auction_flow": {"state": "FOREIGN_FEED_REFUSED", "weight": 0.0}}
    violations = discipline_violations(d, CFG55, results)
    assert any(("HARD MACRO VETO" in v or "counter-macro" in v) for v in violations)


# ── 5) HARD veto on every path EXCEPT Path 9 and the scalp ──────────────────
def test_hard_macro_veto_blocks_even_with_live_tape_and_smc():
    # The old overrule (live tape + qualified SMC) must NO LONGER rescue a
    # counter-macro consensus trade.
    d = _dec("BUY", "BEARISH_GOLD", 74.0)
    d["support_agents"] = ["smc", "technical"]
    results = {"auction_flow": {"state": "LIVE_TAPE_RESPONSIVE", "weight": 0.2,
                                "direction": "BUY", "confidence": 72.0},
               "smc": {"direction": "BUY", "confidence": 68.0},
               "macro_fundamental": {"direction": "SELL", "confidence": 74.0}}
    res = counter_macro_block(d, CFG55, results)
    assert res is not None and "HARD MACRO VETO" in res


def test_path9_reversal_is_exempt_from_the_hard_macro_veto():
    d = _dec("BUY", "BEARISH_GOLD", 74.0,
             execution_path_id="PATH_9_LIQUIDITY_SWEEP_REVERSAL")
    results = {"macro_fundamental": {"direction": "SELL", "confidence": 74.0}}
    assert counter_macro_block(d, CFG55, results) is None


def test_scalp_path_is_exempt_from_the_hard_macro_veto():
    d = _dec("BUY", "BEARISH_GOLD", 74.0, execution_path_id="R25_SCALP_FADE")
    results = {"macro_fundamental": {"direction": "SELL", "confidence": 74.0}}
    assert counter_macro_block(d, CFG55, results) is None


def test_aligned_macro_never_vetoed():
    d = _dec("SELL", "BEARISH_GOLD", 80.0, execution_path_id="PATH_2_TWO_AGENT_MACRO")
    assert counter_macro_block(d, CFG55, {}) is None
