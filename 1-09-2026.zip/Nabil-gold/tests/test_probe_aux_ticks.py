# -*- coding: utf-8 -*-
"""BUILD31-R15: the one-shot aux tick probe (scripts/probe_aux_ticks.py).

Rehearses the full probe against a FAKE MetaTrader5 module and a temporary
project tree: attach, symbol_select, one tick per aux symbol, record_tick +
mark_heartbeat, health re-read, JSON summary. Proves the VPS pipeline
verdict without touching the real storage files (uses --root).
"""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPT = os.path.join(ROOT, "scripts", "probe_aux_ticks.py")

FAKE_MT5 = '''
class _T:
    def __init__(self, bid, ask):
        self.bid, self.ask, self.time_msc = bid, ask, 0

def initialize():
    return True

def shutdown():
    return None

def last_error():
    return (0, "ok")

def symbol_select(sym, add):
    return True  # the unquotable symbol fails one layer deeper (no tick)

def symbol_info_tick(sym):
    if sym == "DEAD.s":
        return None  # subscribed but no quote: the layer the probe must name
    prices = {"WTI.s": (81.50, 81.54)}
    b, a = prices.get(sym, (1.10, 1.1002))
    return _T(b, a) if b else None
'''

CONFIG = json.dumps({
    "symbol": "XAU/USD",
    "symbols": [{"symbol": "XAU/USD", "enabled": True},
                {"symbol": "WTI/USD", "enabled": True},
                {"symbol": "EUR/USD", "enabled": True},
                {"symbol": "USD/JPY", "enabled": True}],
    "execution": {"demo": {"symbol_map": {"XAU/USD": "XAUUSD.s", "WTI/USD": "WTI.s",
                                          "EUR/USD": "EURUSD.s", "USD/JPY": "USDJPY.s"}}},
    "auction_flow": {"storage_path": "storage/auction_flow.sqlite3",
                     "session_timezone": "Asia/Hebron"},
    "instruments": [{"symbol": "XAU/USD", "point_size": 0.1},
                    {"symbol": "WTI/USD", "point_size": 0.01},
                    {"symbol": "EUR/USD", "point_size": 1e-05},
                    {"symbol": "USD/JPY", "point_size": 0.001}],
})


class TestAuxTickProbe(unittest.TestCase):
    def test_probe_records_ticks_and_marks_heartbeats(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            (tmp / "storage").mkdir()
            (tmp / "config.json").write_text(CONFIG, encoding="utf-8")
            stub_dir = tmp / "stub"
            stub_dir.mkdir()
            (stub_dir / "MetaTrader5.py").write_text(FAKE_MT5, encoding="utf-8")

            env = dict(os.environ)
            env["PYTHONPATH"] = str(stub_dir) + os.pathsep + env.get("PYTHONPATH", "")
            proc = subprocess.run([sys.executable, SCRIPT, "--root", str(tmp)],
                                  capture_output=True, text=True, timeout=120, env=env)
            self.assertEqual(proc.returncode, 0, proc.stderr[-800:])
            self.assertIn("Probing 3 aux symbols", proc.stdout)
            self.assertIn("WTI/USD  -> OK", proc.stdout)
            self.assertIn("EUR/USD  -> OK", proc.stdout)
            self.assertIn("USD/JPY  -> OK", proc.stdout)
            self.assertIn("heartbeat_age=", proc.stdout)

            payload = json.loads((tmp / "storage" / "aux_probe_result.json")
                                 .read_text(encoding="utf-8"))
            self.assertTrue(payload["results"]["WTI/USD"]["recorded"])

            import sqlite3
            # close the handle BEFORE the TemporaryDirectory cleanup:
            # on Windows an open sqlite connection locks the file (WinError 32)
            con = sqlite3.connect(str(tmp / "storage" / "auction_flow_eurusd.sqlite3"))
            try:
                meta = dict(con.execute("SELECT key,value FROM meta").fetchall())
            finally:
                con.close()
            self.assertIn("collector_heartbeat", meta)

    def test_probe_reports_unquotable_symbol_as_fail(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            (tmp / "storage").mkdir()
            cfg = json.loads(CONFIG)
            cfg["symbols"] = [{"symbol": "XAU/USD", "enabled": True},
                              {"symbol": "USD/JPY", "enabled": True}]
            cfg["execution"]["demo"]["symbol_map"] = {"XAU/USD": "XAUUSD.s",
                                                      "USD/JPY": "DEAD.s"}
            (tmp / "config.json").write_text(json.dumps(cfg), encoding="utf-8")
            stub_dir = tmp / "stub"
            stub_dir.mkdir()
            (stub_dir / "MetaTrader5.py").write_text(FAKE_MT5, encoding="utf-8")
            env = dict(os.environ)
            env["PYTHONPATH"] = str(stub_dir) + os.pathsep + env.get("PYTHONPATH", "")
            proc = subprocess.run([sys.executable, SCRIPT, "--root", str(tmp)],
                                  capture_output=True, text=True, timeout=120, env=env)
            self.assertEqual(proc.returncode, 0, proc.stderr[-800:])
            self.assertIn("FAIL", proc.stdout)
            self.assertIn("symbol_info_tick None", proc.stdout)


if __name__ == "__main__":
    unittest.main()
