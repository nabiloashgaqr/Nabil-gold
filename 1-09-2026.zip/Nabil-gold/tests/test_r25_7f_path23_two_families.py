"""R25.7-F (2026-08-28, operator order): paths 2/3 require TWO families.

"مسار ٢ والثالث يجب يكونان من عائلتين مع تأكيد خارجي ماكرو أو جيميناي"

The live 2026-08-28 cards proved the hole: PATH 2 admitted EUR/USD on the
same-family pair [technical, classical] (both trend) + macro 74%, and the
trend pair [technical, multitimeframe] + macro was admitted everywhere.
The pair itself is one thesis counted twice; the external confirmer was
supplying the ONLY independent voice in the book.

The law (thesis_consensus.evaluate_directional_admission, PATH 2/3 branch):
  * the qualified supporter set must span >= 2 families (the same family
    map as the Path 1 gate: trend vs structure);
  * the gate runs BEFORE the confirmer ladder, so macro/gemini can no
    longer rescue a single-family book on Paths 2/3 — Rule A's rescue and
    R25.6-G2's gemini addition are superseded there;
  * kill switch: signal_requirements.family_diversity.
    path23_require_two_families = false restores the old behaviour.
  * PATH 1 (its own two-family gate), PATH 4, PATH 5 (Rule B) untouched.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.thesis_consensus import evaluate_directional_admission  # noqa: E402

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def _base_cfg(**fd_overrides):
    cfg = {
        "agent_weights": {"classical": 0.25, "technical": 0.20, "smc": 0.20,
                          "price_action": 0.20, "multitimeframe": 0.15},
        "signal_requirements": {
            "min_agents_agree": 3,
            "min_consensus_confidence": 65,
            "agent_min_confidence": 65,
            "family_diversity": {
                "enabled": True,
                "families": {"trend": ["technical", "multitimeframe",
                                       "classical"],
                             "structure": ["smc", "price_action"]},
                "single_family_confirmers": ["macro", "gemini"],
            },
            "two_agent_entry": {
                "enabled": True, "min_agents_agree": 2,
                "min_consensus_confidence": 65,
                "macro_confirmation": {"enabled": True, "min_confidence": 55},
                "gemini_confirmation": {"enabled": True, "min_confidence": 70},
            },
        },
    }
    cfg["signal_requirements"]["family_diversity"].update(fd_overrides)
    return cfg


def _book(side="SELL", tech=65, klass=67):
    """The LIVE EUR/USD card book: technical + classical qualified, the
    rest of the core below 65 (exactly the screenshot's percentages)."""
    return {
        "technical": {"signal": side, "confidence": tech},
        "classical": {"signal": side, "confidence": klass},
        "multitimeframe": {"signal": side, "confidence": 57},
        "smc": {"signal": side, "confidence": 53},
        "price_action": {"signal": side, "confidence": 21},
    }


# ── 1. the live incident is now refused ─────────────────────────────────────

def test_eur_live_card_same_family_pair_plus_macro_is_refused():
    details = _book("SELL")
    details["macro_fundamental"] = {"direction": "SELL", "confidence": 74}
    adm = evaluate_directional_admission("SELL", details, _base_cfg())
    assert adm["allow"] is False
    assert adm["path23_single_family_refused"] == ["trend"]


def test_same_family_pair_plus_gemini_is_refused_too():
    details = _book("SELL")
    details["gemini"] = {"direction": "SELL", "confidence": 90,
                         "available": True}
    adm = evaluate_directional_admission("SELL", details, _base_cfg())
    assert adm["allow"] is False
    assert adm["path23_single_family_refused"] == ["trend"]


def test_all_trend_three_book_plus_macro_rule_a_rescue_is_closed():
    """Rule A (and R25.6-G2's gemini) may no longer rescue a single-family
    book on Paths 2/3 — the family law runs before the confirmer ladder."""
    details = {
        "technical": {"signal": "BUY", "confidence": 70},
        "multitimeframe": {"signal": "BUY", "confidence": 92},
        "classical": {"signal": "BUY", "confidence": 68},
        "smc": {"signal": "WAIT", "confidence": 30},
        "price_action": {"signal": "WAIT", "confidence": 45},
        "macro_fundamental": {"direction": "BUY", "confidence": 80},
    }
    adm = evaluate_directional_admission("BUY", details, _base_cfg())
    assert adm["allow"] is False
    assert adm["path23_single_family_refused"] == ["trend"]


# ── 2. the compliant shape still enters ─────────────────────────────────────

def test_mixed_family_pair_plus_macro_is_admitted():
    """The live CAD card shape: technical (trend) + price_action
    (structure) + macro 86 — two families, confirmed: still PATH 2."""
    details = {
        "technical": {"signal": "BUY", "confidence": 71},
        "price_action": {"signal": "BUY", "confidence": 66},
        "classical": {"signal": "WAIT", "confidence": 48},
        "multitimeframe": {"signal": "BUY", "confidence": 57},
        "smc": {"signal": "BUY", "confidence": 53},
        "macro_fundamental": {"direction": "BUY", "confidence": 86},
    }
    adm = evaluate_directional_admission("BUY", details, _base_cfg())
    assert adm["allow"] is True
    assert adm["path"] == "TWO_AGENT_MACRO"


def test_structure_plus_trend_pair_plus_gemini_is_admitted():
    """smc (structure) + classical (trend) + gemini >= 70: two families,
    external confirmation — PATH 3 exactly as the operator ordered it."""
    details = {
        "smc": {"signal": "SELL", "confidence": 72},
        "classical": {"signal": "SELL", "confidence": 70},
        "technical": {"signal": "WAIT", "confidence": 40},
        "price_action": {"signal": "WAIT", "confidence": 40},
        "multitimeframe": {"signal": "WAIT", "confidence": 40},
        "gemini": {"direction": "SELL", "confidence": 88, "available": True},
    }
    adm = evaluate_directional_admission("SELL", details, _base_cfg())
    assert adm["allow"] is True
    assert adm["path"] == "TWO_AGENT_GEMINI"


def test_path1_diverse_three_book_still_enters_direct():
    details = {
        "technical": {"signal": "BUY", "confidence": 70},
        "classical": {"signal": "BUY", "confidence": 68},
        "smc": {"signal": "BUY", "confidence": 72},
        "multitimeframe": {"signal": "WAIT", "confidence": 40},
        "price_action": {"signal": "WAIT", "confidence": 45},
    }
    adm = evaluate_directional_admission("BUY", details, _base_cfg())
    assert adm["allow"] is True
    assert adm["path"] == "THREE_AGENT_CONSENSUS"


# ── 3. the kill switch restores the old behaviour exactly ───────────────────

def test_kill_switch_false_restores_macro_rescue_of_trend_pair():
    details = _book("BUY", tech=75, klass=68)
    details["macro_fundamental"] = {"direction": "BUY", "confidence": 60}
    cfg = _base_cfg(path23_require_two_families=False)
    adm = evaluate_directional_admission("BUY", details, cfg)
    assert adm["allow"] is True
    assert adm["path"] == "TWO_AGENT_MACRO"


def test_kill_switch_false_restores_the_rule_a_gemini_rescue():
    details = {
        "technical": {"signal": "BUY", "confidence": 70},
        "multitimeframe": {"signal": "BUY", "confidence": 92},
        "classical": {"signal": "BUY", "confidence": 68},
        "smc": {"signal": "WAIT", "confidence": 30},
        "price_action": {"signal": "WAIT", "confidence": 45},
        "gemini": {"direction": "BUY", "confidence": 90, "available": True},
    }
    cfg = _base_cfg(path23_require_two_families=False)
    adm = evaluate_directional_admission("BUY", details, cfg)
    assert adm["allow"] is True
    assert adm["path"] == "TWO_AGENT_GEMINI"


# ── 4. shipped config carries the law; the order boundary obeys it ─────────

def test_shipped_config_carries_path23_two_families():
    fd = CONFIG["signal_requirements"]["family_diversity"]
    assert fd["path23_require_two_families"] is True


def test_planner_execution_gate_refuses_the_live_eur_shape():
    """The order boundary (_planner_execution_gate) uses the same evaluator:
    a single-family pair + macro stored on a decision is refused there."""
    from scripts.run_analysis import _planner_execution_gate
    decision = {
        "decision": "SELL",
        "confirm_source": "macro",
        "confirm_confidence": 74.0,
        "agent_details": _book("SELL"),
    }
    gate = _planner_execution_gate(decision, _base_cfg())
    assert gate["allow"] is False


def test_planner_execution_gate_admits_the_mixed_pair():
    from scripts.run_analysis import _planner_execution_gate
    decision = {
        "decision": "BUY",
        "confirm_source": "macro",
        "confirm_confidence": 86.0,
        "agent_details": {
            "technical": {"signal": "BUY", "confidence": 71},
            "price_action": {"signal": "BUY", "confidence": 66},
            "classical": {"signal": "WAIT", "confidence": 48},
            "multitimeframe": {"signal": "BUY", "confidence": 57},
            "smc": {"signal": "BUY", "confidence": 53},
        },
    }
    gate = _planner_execution_gate(decision, _base_cfg())
    assert gate["allow"] is True
