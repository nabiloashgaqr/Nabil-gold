"""2026-08-19: PATH 1 kill switch (data decision - PF 0.95 measured)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from services.thesis_consensus import evaluate_directional_admission  # noqa: E402


def _cfg(three_enabled=None, macro=("BULLISH_GOLD", 60), auction=("BUY", 70)):
    cfg = {
        "agent_weights": {"classical": 0.25, "technical": 0.20, "smc": 0.20,
                          "price_action": 0.20, "multitimeframe": 0.15},
        "risk_settings": {"min_confidence": 65},
        "signal_requirements": {
            "min_agents_agree": 3,
            "min_consensus_confidence": 72,
            "agent_min_confidence": 65,
            "two_agent_entry": {"enabled": True, "min_agents_agree": 2,
                                "min_consensus_confidence": 72},
            "path5_two_agent_auction": {"enabled": True, "min_agents_agree": 2,
                                        "min_consensus_confidence": 72,
                                        "min_auction_confidence": 65},
            "family_diversity": {
                "enabled": True,
                "families": {
                    "trend": ["technical", "multitimeframe", "classical"],
                    "structure": ["smc", "price_action"],
                },
                "single_family_confirmers": ["macro"],
            },
        },
    }
    if three_enabled is not None:
        cfg["signal_requirements"]["three_agent_entry"] = {"enabled": three_enabled}
    return cfg


def _details(side="BUY", three=True):
    details = {
        "technical": {"direction": side, "confidence": 78},
        "multitimeframe": {"direction": side, "confidence": 74},
        "smc": {"direction": side, "confidence": 72},
        "classical": {"direction": side, "confidence": 70},
        "price_action": {"direction": "SELL" if side == "BUY" else "BUY", "confidence": 40},
    }
    if not three:
        # two qualified mixed-family supporters only
        details = {
            "technical": {"direction": side, "confidence": 75},
            "smc": {"direction": side, "confidence": 71},
            "classical": {"direction": "WAIT", "confidence": 20},
            "multitimeframe": {"direction": "WAIT", "confidence": 20},
            "price_action": {"direction": "WAIT", "confidence": 20},
        }
    return details


class TestPath1KillSwitch:
    def test_default_enabled_backward_compatible(self):
        # no three_agent_entry key -> PATH 1 behaves exactly as before
        cfg = _cfg(three_enabled=None)
        r = evaluate_directional_admission("BUY", _details(), cfg)
        assert r.get("allow") is True
        assert r.get("path") == "THREE_AGENT_CONSENSUS"
        assert not r.get("path1_disabled")

    def test_disabled_marks_and_skips_path1(self):
        cfg = _cfg(three_enabled=False)
        r = evaluate_directional_admission("BUY", _details(), cfg)
        assert r.get("path1_disabled") is True
        assert r.get("path") != "THREE_AGENT_CONSENSUS"
        assert "PF 0.95" in r.get("path1_disable_reason", "")

    def test_disabled_book_falls_to_macro_path(self):
        # 3 qualified, 2 families, macro available -> TWO_AGENT_MACRO
        cfg = _cfg(three_enabled=False)
        cfg["signal_requirements"]["two_agent_entry"]["macro_confirmation"] = {"enabled": True, "min_confidence": 55}
        details = _details()
        details["macro_fundamental"] = {"direction": "BUY", "confidence": 60}
        r = evaluate_directional_admission("BUY", details, cfg)
        assert r.get("allow") is True
        assert r.get("path") == "TWO_AGENT_MACRO"

    def test_disabled_two_agent_needs_confirmer(self):
        # only 2 qualified (mixed families), no macro/auction confirmer ->
        # no unconfirmed admission of any kind
        cfg = _cfg(three_enabled=False)
        details = _details(three=False)
        details["auction_flow"] = {"direction": "WAIT", "confidence": 30}
        r = evaluate_directional_admission("BUY", details, cfg)
        assert r.get("allow") is False
        assert r.get("path1_disabled") is True
        # the only alive routes (macro/gemini/auction/map) all failed here
        assert r.get("path") is None

    def test_disabled_two_agent_auction_path5_intact(self):
        cfg = _cfg(three_enabled=False)
        details = _details(three=False)
        details["auction_flow"] = {"direction": "BUY", "confidence": 70}
        r = evaluate_directional_admission("BUY", details, cfg)
        assert r.get("allow") is True
        assert r.get("path") == "TWO_AGENT_AUCTION"

    def test_production_config_re_enabled(self):
        # 2026-08-19 (build 13, operator order): PATH 1 is back ON.
        import json
        from pathlib import Path as P

        cfg_path = P(__file__).resolve().parents[1] / "config.json"
        prod = json.loads(cfg_path.read_text(encoding="utf-8"))
        three = (prod.get("signal_requirements") or {}).get("three_agent_entry") or {}
        assert three.get("enabled") is True
