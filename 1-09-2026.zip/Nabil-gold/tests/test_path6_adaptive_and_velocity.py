from __future__ import annotations
import pytest
from services import pre_arm_ote as pa

def _candle(o, h, l, c):
    return {"open": o, "high": h, "low": l, "close": c}

def test_path6_adaptive_moderate_selects_618():
    cfg = {
        "adaptive_level": True,
        "max_moderate_displacement_atr": 3.0,
        "moderate_entry_pct": 0.618,
        "parabolic_entry_pct": 0.786,
    }
    # 20 pt leg with atr=10 -> 2.0x ATR (moderate)
    leg = {
        "direction": "BUY",
        "leg_origin": 4600.0,
        "leg_peak": 4620.0,
        "leg_size": 20.0,
        "atr": 10.0,
    }
    ote = pa.project_ote(leg, cfg)
    assert ote["level_mode"] == "MODERATE_618"
    assert ote["entry_pct"] == pytest.approx(0.618)
    assert ote["entry"] == pytest.approx(4620.0 - 20.0 * 0.618)

def test_path6_adaptive_parabolic_selects_786():
    cfg = {
        "adaptive_level": True,
        "max_moderate_displacement_atr": 3.0,
        "moderate_entry_pct": 0.618,
        "parabolic_entry_pct": 0.786,
    }
    # 80 pt leg with atr=10 -> 8.0x ATR (parabolic / overextended like today)
    leg = {
        "direction": "BUY",
        "leg_origin": 4600.0,
        "leg_peak": 4680.0,
        "leg_size": 80.0,
        "atr": 10.0,
    }
    ote = pa.project_ote(leg, cfg)
    assert ote["level_mode"] == "PARABOLIC_786"
    assert ote["entry_pct"] == pytest.approx(0.786)
    assert ote["entry"] == pytest.approx(4680.0 - 80.0 * 0.786)

def test_path6_velocity_guard_blocks_violent_drop():
    cfg = {
        "velocity_guard_enabled": True,
        "max_drop_candle_atr": 1.4,
    }
    # Giant bearish candle: open 4680, close 4655 (25 pts drop on ATR 10 -> 2.5x ATR)
    candles = [
        _candle(4600, 4650, 4600, 4650),
        _candle(4650, 4680, 4650, 4680),
        _candle(4680, 4680, 4655, 4655), # violent drop
    ]
    safe, reason = pa._check_pullback_velocity(candles, 10.0, "BUY", cfg)
    assert safe is False
    assert "violent_bearish_displacement" in reason
