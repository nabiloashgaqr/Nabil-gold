# -*- coding: utf-8 -*-
"""BUILD31-R13: per-symbol spread caps.

The single gold-calibrated global cap (max_spread_points=5, i.e. $0.50 on
gold) vetoed EVERY forex entry: on 5-digit pairs a point is 0.1 pip, so a
normal 0.6-1.5 pip spread is 6-15 points. Caps are now per-symbol with the
legacy global as fallback.
"""
import json
import os
import unittest
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys_path = ROOT
if sys_path not in __import__("sys").path:
    import sys
    sys.path.insert(0, ROOT)

from utils.instruments import (  # noqa: E402
    DEFAULT_MAX_SPREAD_POINTS_BY_SYMBOL,
    max_spread_points_for,
)

CONFIG = json.loads((Path(ROOT) / "config.json").read_text(encoding="utf-8"))


class TestSpreadCapHelper(unittest.TestCase):
    def test_per_symbol_map_wins(self):
        self.assertEqual(max_spread_points_for("EUR/USD", CONFIG), 25.0)
        self.assertEqual(max_spread_points_for("GBP/USD", CONFIG), 30.0)
        self.assertEqual(max_spread_points_for("USD/CAD", CONFIG), 30.0)
        self.assertEqual(max_spread_points_for("USD/JPY", CONFIG), 25.0)

    def test_gold_and_oil_keep_their_behaviour(self):
        self.assertEqual(max_spread_points_for("XAU/USD", CONFIG), 5.0)
        self.assertEqual(max_spread_points_for("WTI/USD", CONFIG), 8.0)

    def test_symbol_normalization_case_insensitive(self):
        self.assertEqual(max_spread_points_for("eurusd", CONFIG), 25.0)
        self.assertEqual(max_spread_points_for("USDJPY", CONFIG), 25.0)

    def test_fallback_order_unlisted_symbol(self):
        cfg = {"filters": {"max_spread_points": 7}}
        self.assertEqual(max_spread_points_for("AUD/USD", cfg), 7.0)  # legacy global
        self.assertEqual(
            max_spread_points_for("AUD/USD", {"filters": {}}),
            DEFAULT_MAX_SPREAD_POINTS_BY_SYMBOL.get("AUD/USD", 5.0),
        )

    def test_by_symbol_overrides_legacy_global(self):
        cfg = {"filters": {"max_spread_points": 5,
                           "max_spread_points_by_symbol": {"EUR/USD": 25}}}
        self.assertEqual(max_spread_points_for("EUR/USD", cfg), 25.0)
        self.assertEqual(max_spread_points_for("XAU/USD", cfg), 5.0)


class TestCallSitesUseTheHelper(unittest.TestCase):
    """Source-content assertions (immune to module-identity pollution)."""

    def test_auction_flow_agent_uses_per_symbol_cap(self):
        src = (Path(ROOT) / "agents" / "auction_flow_agent.py").read_text(encoding="utf-8")
        self.assertIn("max_spread_points_for", src)
        self.assertNotIn('self.config.get("filters", {}) or {}).get("max_spread_points", 5)', src)

    def test_risk_agent_uses_per_symbol_cap(self):
        src = (Path(ROOT) / "agents" / "risk_management_agent.py").read_text(encoding="utf-8")
        self.assertIn("max_spread_points_for", src)
        self.assertNotIn('self._f(self.filters.get("max_spread_points"), 5.0)', src)

    def test_config_carries_the_by_symbol_map(self):
        by_symbol = CONFIG.get("filters", {}).get("max_spread_points_by_symbol") or {}
        for symbol in ("XAU/USD", "WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"):
            self.assertIn(symbol, by_symbol, f"missing cap for {symbol}")
        self.assertIn("description", by_symbol)


if __name__ == "__main__":
    unittest.main()
