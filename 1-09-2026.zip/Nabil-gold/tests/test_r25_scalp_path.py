"""R25.1: PATH 7 - SCALP PREMIUM FADE is a registered execution path.

Operator order 2026-08-28 ("give the new path the name SCALP"): the scalp
carries formal path provenance like PATHS 1-6, its conditions name the
agents explicitly, and it is NOT part of the day-map thesis.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.execution_paths import (
    PATH_7, PATH_DEFINITIONS, path_id_from_admission, stamp_execution_path,
)
from scripts.run_analysis import _r25_scalp_execute

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))

RANGE = {"high": 4616.73, "low": 4588.83}
BUY_LEVEL = 4571.84


def test_path_7_is_registered():
    assert PATH_7 in PATH_DEFINITIONS
    d = PATH_DEFINITIONS[PATH_7]
    assert d["number"] == 7 and "SCALP" in d["name"]
    assert path_id_from_admission("R25_SCALP_FADE") == PATH_7


def test_stamp_carries_the_scalp_path():
    row = {}
    stamp_execution_path(row, "R25_SCALP_FADE")
    assert row["execution_path_id"] == PATH_7
    assert row["execution_path_number"] == 7
    assert "SCALP" in row["execution_path_name"]


def _armed_decision():
    return {
        "symbol": "XAU/USD", "current_price": 4612.56,
        "market_context": {"technical_regime": {"market_phase": "RANGING",
                                                "adx_value": 21.9}},
        "agent_details": {
            "classical": {"label": "Classical", "direction": "SELL",
                          "confidence": 73.0},
            "smc": {"label": "SMC", "direction": "SELL", "confidence": 70.0,
                    "conditional_map": {"details": {"dealing_range": RANGE}}},
            "multitimeframe": {"label": "Multi-Timeframe",
                               "direction": "NO_TRADE", "confidence": 0.0},
        },
        "session_plan": {"session_bias": "BUY",
                         "primary_poi": {"entry_price": BUY_LEVEL,
                                         "trigger_state":
                                             "REJECTION_CONFIRMED"}},
    }


def test_live_scalp_is_stamped_path_7_and_stands_outside_the_thesis(
        tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    import tests.test_session_plan_ladder as t
    from utils.helpers import load_trades
    import logging
    logging.disable(logging.INFO)
    try:
        _r25_scalp_execute(_armed_decision(), "XAU/USD", CONFIG,
                           t._db(tmp_path), t._Telegram(), [],
                           demo_execution=False)
    finally:
        logging.disable(logging.NOTSET)
    rows = load_trades(t._db(tmp_path).local_path)
    scalp = rows[0]["signal_snapshot"]
    assert scalp["execution_path_id"] == PATH_7
    assert scalp["execution_path_number"] == 7
    # thesis independence: the scalp never passed - nor altered - the
    # day-map consensus admission
    assert "planner_execution_gate" not in scalp
    assert "execution_admission" not in scalp
    assert "NOT part" in scalp["setup_context"]["thesis_source"]
    # the conditions name the agents explicitly
    reasons = " ".join(scalp["reasons"])
    assert "classical" in reasons and "smc" in reasons
    assert "multitimeframe" in reasons and "R24-0" in reasons


def test_scalp_runner_trails_by_its_own_contract_not_the_global_gap():
    """The scalp's trail contract travels with the row and wins when tighter."""
    from agents.open_trades_manager import OpenTradesManager
    cfg = json.loads(json.dumps(CONFIG))
    m = OpenTradesManager(cfg)
    eff = float(m.trailing_distance)
    row_trail = 97.65                 # the contract on the row (system pts)
    assert eff > row_trail            # global 150 pts is looser than 97.65
    effective = row_trail if 0 < row_trail < eff else eff
    assert effective == row_trail     # the row contract applies (tighter-only)


def test_scalp_row_never_widens_the_global_trail():
    from agents.open_trades_manager import OpenTradesManager
    cfg = json.loads(json.dumps(CONFIG))
    m = OpenTradesManager(cfg)
    eff = float(m.trailing_distance)
    assert eff == 150.0               # unchanged global law
    # a row WITHOUT the flag/contract keeps the global distance untouched
    row_trail = 0.0
    effective = row_trail if 0 < row_trail < eff else eff
    assert effective == eff


def test_scalp_rr_floors_are_its_own_and_the_global_law_stands():
    """The scalp validates under its own floors; paths 1-6 keep 0.8R/1.5R."""
    sc = CONFIG["r25_scalp"]["rr_floors"]
    assert sc["min_tp1_rr"] == 0.5 and sc["min_tp2_rr"] == 1.0
    import tests.test_session_plan_ladder as t
    from scripts.run_analysis import validate_signal_before_send
    db = t._db_tmp = None  # no db use in validate
    import tempfile
    from pathlib import Path as _P
    import tests.test_session_plan_ladder as _t
    scalp = {"symbol": "XAU/USD", "decision": "SELL",
             "signal": {"order_type": "SELL_LIMIT",
                        "entry": {"kind": "LIMIT", "price": 4611.15},
                        "stop_loss": 4646.15, "tp1": 4591.49, "tp2": 4571.84},
             "current_price": 4612.56, "setup_context": {"r25_scalp": True}}
    assert validate_signal_before_send(scalp, CONFIG, []) == []
    plain = dict(scalp)
    plain["setup_context"] = {}
    v = validate_signal_before_send(plain, CONFIG, [])
    assert any("0.80R" in x for x in v), "the global 0.8R floor must stand"
