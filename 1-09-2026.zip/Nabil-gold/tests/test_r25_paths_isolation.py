"""R25.6: PATH 8 (reinforcement) + the audit-record isolation.

C1: the production decision_audit.json must NEVER be written by pytest
(the 14-day report carried "unit-test veto" rows). The audit file now
follows the store root, the suite sets PYTEST_RUNNING=1, and the writer
refuses the code-tree audit file under that flag.

PATH 8: the ladder's STANDBY/ADD_ON leg ("مسار التعزيز") is a registered
execution path; legacy no-path rows with a reinforcement role resolve to
it instead of NOT RECORDED.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

import importlib.util  # noqa: E402
import tempfile  # noqa: E402

from services.database import DatabaseService  # noqa: E402
from services.execution_paths import (  # noqa: E402
    PATH_1, PATH_8, PATH_DEFINITIONS, path_id_from_admission,
    resolve_execution_path, stamp_execution_path,
)
from services.agent_book_store import book_path  # noqa: E402


def _db(tmp: Path) -> DatabaseService:
    db = DatabaseService({"database": {"url": None, "key": None,
                                       "local_fallback_file": str(tmp / "trades.json")}})
    db.local_path = tmp / "trades.json"
    return db


# ── the registry ─────────────────────────────────────────────────────────────

def test_path_8_reinforcement_is_registered():
    assert PATH_8 in PATH_DEFINITIONS
    d = PATH_DEFINITIONS[PATH_8]
    assert d["number"] == 8 and "REINFORCEMENT" in d["name"]
    assert path_id_from_admission("REINFORCEMENT_ADDON") == PATH_8


def test_legacy_reinforcement_rows_resolve_to_path_8():
    legacy = {"id": "T_OLD", "signal_snapshot": {"setup_context":
              {"pending_plan_role": "STANDBY"}}}
    assert resolve_execution_path(legacy)["id"] == PATH_8
    legacy2 = {"id": "T_OLD2", "setup_context": {"selection_role": "ADD_ON"}}
    assert resolve_execution_path(legacy2)["id"] == PATH_8


def test_primary_role_stays_unknown_when_no_path_recorded():
    row = {"id": "T_P", "signal_snapshot": {"setup_context":
           {"pending_plan_role": "PRIMARY"}}}
    assert resolve_execution_path(row)["id"] == "UNKNOWN_EXECUTION_PATH"


def test_stamp_via_reinforcement_admission():
    row = {}
    stamp_execution_path(row, "REINFORCEMENT_ADDON")
    assert row["execution_path_id"] == PATH_8
    assert row["execution_path_number"] == 8


def test_scalp_path_still_registered():
    assert "PATH_7_SCALP_PREMIUM_FADE" in PATH_DEFINITIONS


# ── the ladder stamps the reinforcement leg under PATH 8 ─────────────────────

def test_ladder_stamps_standby_leg_as_path_8_with_parent_provenance():
    import logging
    import tests.test_session_plan_ladder as t
    from utils.helpers import load_trades
    from scripts.run_analysis import _execute_session_plan_ladder
    logging.basicConfig(level=logging.CRITICAL)
    db = t._db(Path(tempfile.mkdtemp()))
    decision = t._base_decision()
    decision["current_price"] = 4086.89
    decision["session_plan"]["primary_poi"]["direction"] = "BUY"
    decision["session_plan"]["standby_poi"] = {
        **t._candidate("STANDBY", 4070.28, 4030.28, 4160.28),
        "direction": "BUY", "selection_role": "STANDBY",
        "expected_revisit_window": "LOW", "return_probability_score": 30.0,
        "quality_grade": "A+", "quality_score": 100.0,
        "trigger_ready": True, "trigger_state": "REJECTION_CONFIRMED"}
    decision["session_plan"]["primary_poi"] = {
        **t._candidate("PRIMARY", 4100.28, 4060.28, 4190.28),
        "direction": "BUY", "selection_role": "PRIMARY",
        "trigger_ready": True, "trigger_state": "REJECTION_CONFIRMED"}
    decision["session_plan"]["session_bias"] = "BUY"
    decision["decision"] = "BUY"
    decision["agent_details"] = {
        "technical": {"label": "Technical", "direction": "BUY", "confidence": 92},
        "classical": {"label": "Classical", "direction": "WAIT", "confidence": 27},
        "smc": {"label": "SMC", "direction": "BUY", "confidence": 76},
        "price_action": {"label": "Price Action", "direction": "BUY", "confidence": 84},
        "multitimeframe": {"label": "Multi-Timeframe", "direction": "BUY", "confidence": 67}}
    decision["news_context"] = {
        "rule_based": {"can_trade": True, "market_status": "SAFE"},
        "macro": {"macro_direction": {"bias": "BULLISH_GOLD", "confidence": 64}}}
    # R26.2: the base test decision carries a default BEARISH macro; a BUY
    # ladder must have the macro aligned or the counter-macro veto (now wired)
    # correctly refuses it.
    decision.setdefault("market_context", {})["macro_direction"] = {
        "bias": "BULLISH_GOLD", "confidence": 64}
    cfg = t._config()
    cfg.setdefault("split_execution", {})["convert_touched_zone_to_market"] = True
    logging.disable(logging.CRITICAL)
    try:
        created = _execute_session_plan_ladder(
            decision, {"symbol": "XAU/USD"}, [], db, t._Telegram(), cfg)
    finally:
        logging.disable(logging.NOTSET)
    assert created == 2, "both legs must exist for this probe"
    rows = load_trades(db.local_path)
    by_role = {str(((r.get("signal_snapshot") or {}).get("setup_context") or {})
                   .get("pending_plan_role")): r["signal_snapshot"] for r in rows}
    assert by_role["PRIMARY"]["execution_path_id"] == PATH_1
    assert by_role["STANDBY"]["execution_path_id"] == PATH_8
    assert by_role["STANDBY"]["execution_path_number"] == 8
    assert any("Reinforcement leg" in x for x in by_role["STANDBY"]["reasons"])
    assert any("parent admission" in x for x in by_role["STANDBY"]["reasons"])


# ── C1: the audit record isolation ───────────────────────────────────────────

def test_audit_follows_the_store_root(tmp_path):
    db = _db(tmp_path)
    db.save_decision_audit({"symbol": "XAU/USD", "stage": "r24 gate",
                            "outcome": "REFUSED", "reason": "probe row"})
    audit = tmp_path / "decision_audit.json"
    assert audit.exists(), "the audit must land next to the redirected store"
    rows = json.loads(audit.read_text(encoding="utf-8"))
    assert rows and rows[-1]["reason"] == "probe row"


def test_pytest_never_writes_the_production_audit(tmp_path, monkeypatch):
    """The belt: PYTEST_RUNNING=1 + code-tree audit path => refuse."""
    monkeypatch.setenv("PYTEST_RUNNING", "1")
    db = DatabaseService({"database": {"url": None, "key": None}})
    assert db.decision_audit_path == Path(__file__).resolve().parents[1] / "storage" / "decision_audit.json"
    assert db.save_decision_audit({"symbol": "XAU/USD", "stage": "x",
                                   "outcome": "REFUSED"}) == ""


# ── the scrub tool ───────────────────────────────────────────────────────────

def test_scrub_removes_only_unit_test_rows(tmp_path, monkeypatch):
    # R25.9: hermetic argv - an in-process CLI must never parse pytest's
    # (or any leaker's) argv; argparse falls back to sys.argv.
    monkeypatch.setattr(sys, "argv", ["scrub_audit_test_rows.py"])
    audit = tmp_path / "storage" / "decision_audit.json"
    audit.parent.mkdir(parents=True)
    rows = [
        {"reason": "R24-0: ... - unit-test veto"},
        {"reason": "planner ladder PRIMARY"},
        {"reason": None},
        {"reason": "UNIT-TEST veto (case-insensitive)"},
    ]
    audit.write_text(json.dumps(rows), encoding="utf-8")
    spec = importlib.util.spec_from_file_location(
        "scrub", ROOT / "scripts" / "scrub_audit_test_rows.py")
    scrub = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scrub)
    monkeypatch.setattr(scrub, "AUDIT", audit)
    assert scrub.main() == 0
    kept = json.loads(audit.read_text(encoding="utf-8"))
    assert len(kept) == 2 and any("planner" in str(x.get("reason")) for x in kept)
    backups = list(tmp_path.glob("storage") / "decision_audit.json.bak_scrub_0000") \
        if False else list((tmp_path / "storage").glob("decision_audit.json.bak_scrub_*"))
    assert backups, "a timestamped backup is mandatory"
    assert scrub.main() == 0 and "clean already" in capsys_text(scrub, audit, monkeypatch)


def capsys_text(scrub, audit, monkeypatch):
    import io
    import contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        scrub.main()
    return buf.getvalue()


# ── B1: the per-symbol book diagnosis ────────────────────────────────────────

def test_symbol_book_diagnosis_reports_why(tmp_path, monkeypatch):
    import time as _time
    import scripts.diagnose_symbol_books as diag
    (tmp_path / "storage" / "agent_books").mkdir(parents=True)
    (tmp_path / "config.json").write_text(
        json.dumps({"symbol": "XAU/USD",
                    "signal_requirements": {"agent_min_confidence": 65},
                    "symbols": ["XAU/USD", "EUR/USD"],
                    "instruments": [{"symbol": "XAU/USD", "enabled": True},
                                    {"symbol": "EUR/USD", "enabled": True}]}),
        encoding="utf-8")
    mk = lambda sym, agents, age_s=60: book_path(sym, root=tmp_path).write_text(
        json.dumps({"symbol": sym, "written_at": _time.time() - age_s,
                    "agents": agents}), encoding="utf-8")
    mk("XAU/USD", {"classical": {"direction": "SELL", "confidence": 73},
                   "smc": {"direction": "SELL", "confidence": 70},
                   "multitimeframe": {"direction": "NO_TRADE", "confidence": 0}})
    mk("EUR/USD", {"classical": {"direction": "WAIT", "confidence": 40}})
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("sys.argv", ["diagnose_symbol_books.py",
                                     "--root", str(tmp_path),
                                     "--out", "diagnose_symbol_books.txt"])
    assert diag.main() == 0
    txt = (tmp_path / "diagnose_symbol_books.txt").read_text(encoding="utf-8")
    assert "XAU/USD" in txt and "EUR/USD" in txt
    assert "*QUALIFIED*" in txt and "SELL:" in txt
    assert "refused" in txt or "ADMITTED" in txt
