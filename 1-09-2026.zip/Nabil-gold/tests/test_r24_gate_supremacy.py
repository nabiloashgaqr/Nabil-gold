# -*- coding: utf-8 -*-
"""R24 (2026-08-28): gate-supremacy laws - the 4612.56 incident, codified.

Live incident (all facts from trade_forensics_4612.txt): at 19:01 the
session-plan ladder executed BUY_MARKET 4612.56 while the SAME decision
carried:
  * risk.approved=false, trade_grade F (39/100), label "Reject",
    risk_multiplier 0.0, recommended_lots 0.0   -> R24-0
  * trigger_ready=false, trigger_state=TOUCH_NO_REJECTION while the
    strategy profile demands REJECTION_CONFIRMED               -> R24-1
  * split_execution.convert_touched_zone_to_market=true allowed the
    plan's LIMIT 4608.37 to be repriced to MARKET 4612.56       -> R24-2
  * market_phase RANGING, ADX 21.87, entry at 77% of the dealing range
    [4588.83-4616.73] (premium)                                 -> R24-3
  * a same-side BUY_LIMIT 4571.84 had been cancelled 2h15m earlier -
    the new entry was 40.7 pts WORSE with no memory of it       -> R24-4
Pinned here as executable law: every gate refuses the exact incident
numbers, and lets honest pullback entries through.
"""
import json
import os
import sys
import unittest
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import scripts.run_analysis as ra

CFG = {"r24_gates": {}}

INCIDENT_DECISION = {
    "risk": {
        "approved": False,
        "rejection_reason": "Trade grade too low",
        "risk_metrics": {"trade_grade": {"score": 39.0, "grade": "F",
                                         "label": "Reject"}},
    },
    "market_context": {"technical_regime": {"market_phase": "RANGING",
                                            "adx_value": 21.87}},
    "agent_details": {"smc": {"conditional_map": {"details": {"dealing_range": {
        "high": 4616.73, "low": 4588.83}}}}},
}

INCIDENT_CANDIDATE = {"trigger_ready": False,
                      "trigger_state": "TOUCH_NO_REJECTION",
                      "selection_role": "PRIMARY"}

CANCELLED_ROW = {"symbol": "XAU/USD", "order_type": "BUY_LIMIT",
                 "entry_price": 4571.84, "status": "CANCELLED",
                 "opened_at": "2026-08-27T16:46:20+00:00"}


class TestR24_0RiskVetoSupremacy(unittest.TestCase):
    def test_incident_is_refused(self):
        reason = ra.r24_risk_veto_reason(INCIDENT_DECISION, CFG)
        self.assertIsNotNone(reason)
        self.assertIn("R24-0", reason)
        self.assertIn("F 39", reason)

    def test_approved_trade_passes(self):
        d = {"risk": {"approved": True}}
        self.assertIsNone(ra.r24_risk_veto_reason(d, CFG))

    def test_decision_without_risk_block_passes(self):
        self.assertIsNone(ra.r24_risk_veto_reason({}, CFG))

    def test_kill_switch(self):
        cfg = {"r24_gates": {"risk_veto_supremacy": False}}
        self.assertIsNone(ra.r24_risk_veto_reason(INCIDENT_DECISION, cfg))


class TestR24_1TriggerSupremacy(unittest.TestCase):
    def test_touch_no_rejection_cannot_go_market(self):
        reason = ra.r24_trigger_market_reason(INCIDENT_CANDIDATE, CFG)
        self.assertIsNotNone(reason)
        self.assertIn("R24-1", reason)
        self.assertIn("TOUCH_NO_REJECTION", reason)

    def test_confirmed_rejection_may_go_market(self):
        cand = {"trigger_ready": False, "trigger_state": "REJECTION_CONFIRMED"}
        self.assertIsNone(ra.r24_trigger_market_reason(cand, CFG))

    def test_trigger_ready_true_passes(self):
        self.assertIsNone(ra.r24_trigger_market_reason(
            {"trigger_ready": True, "trigger_state": "TOUCH_NO_REJECTION"}, CFG))


class TestR24_2ConfigKill(unittest.TestCase):
    def test_shipped_config_disables_market_conversion(self):
        cfg = json.loads((Path(ROOT) / "config.json").read_text(encoding="utf-8"))
        self.assertFalse(cfg["split_execution"]["convert_touched_zone_to_market"])

    def test_source_honours_the_kill(self):
        src = (Path(ROOT) / "scripts" / "run_analysis.py").read_text(encoding="utf-8")
        self.assertIn('_split_execution_cfg(config).get("convert_touched_zone_to_market", True)', src)


class TestR24_3RangeGate(unittest.TestCase):
    def test_incident_buy_at_85pct_is_refused(self):
        # honest arithmetic on the recorded dealing range:
        # (4612.56-4588.83)/(4616.73-4588.83) = 85% - deep premium
        reason = ra.r24_range_chase_reason(
            INCIDENT_DECISION, INCIDENT_CANDIDATE, "BUY", 4612.56, CFG)
        self.assertIsNotNone(reason)
        self.assertIn("R24-3", reason)
        self.assertIn("85%", reason)

    def test_discount_buy_is_allowed(self):
        reason = ra.r24_range_chase_reason(
            INCIDENT_DECISION, INCIDENT_CANDIDATE, "BUY", 4595.0, CFG)
        self.assertIsNone(reason)

    def test_trending_market_is_exempt(self):
        d = {"market_context": {"technical_regime": {
            "market_phase": "TRENDING", "adx_value": 31.0}},
            "agent_details": INCIDENT_DECISION["agent_details"]}
        self.assertIsNone(ra.r24_range_chase_reason(
            d, INCIDENT_CANDIDATE, "BUY", 4612.56, CFG))

    def test_no_range_knowledge_abstains(self):
        d = {"market_context": INCIDENT_DECISION["market_context"]}
        self.assertIsNone(ra.r24_range_chase_reason(
            d, INCIDENT_CANDIDATE, "BUY", 4612.56, CFG))


class TestR24_4SnapshotLock(unittest.TestCase):
    NOW = 1787936478.0  # 2026-08-28 ~09:41 UTC (after the incident day)

    def test_chase_after_cancelled_limit_is_refused(self):
        reason = ra.r24_snapshot_lock_reason(
            [CANCELLED_ROW], "XAU/USD", "BUY", 4612.56, CFG,
            now=1787874078.0)  # 19:01, 2h15m after the cancel
        self.assertIsNotNone(reason)
        self.assertIn("R24-4", reason)
        self.assertIn("4571.84", reason)

    def test_returning_to_the_level_is_allowed(self):
        self.assertIsNone(ra.r24_snapshot_lock_reason(
            [CANCELLED_ROW], "XAU/USD", "BUY", 4575.0, CFG, now=1787874078.0))

    def test_lock_expires_after_12h(self):
        self.assertIsNone(ra.r24_snapshot_lock_reason(
            [CANCELLED_ROW], "XAU/USD", "BUY", 4612.56, CFG, now=self.NOW))

    def test_opposite_side_untouched(self):
        self.assertIsNone(ra.r24_snapshot_lock_reason(
            [CANCELLED_ROW], "XAU/USD", "SELL", 4550.0, CFG, now=1787874078.0))

    def test_wiring_exists_in_the_ladder_and_conversion(self):
        src = (Path(ROOT) / "scripts" / "run_analysis.py").read_text(encoding="utf-8")
        self.assertIn("r24_risk_veto_reason(base_decision, config)", src)
        self.assertIn("r24_trigger_market_reason(candidate, config)", src)
        self.assertIn("r24_range_chase_reason(", src)
        self.assertIn("r24_snapshot_lock_reason(", src)
        self.assertIn('stage="r24 gate", outcome="REFUSED"', src)

    def test_r24_gates_shipped(self):
        cfg = json.loads((Path(ROOT) / "config.json").read_text(encoding="utf-8"))
        g = cfg["r24_gates"]
        self.assertTrue(g["enabled"] and g["risk_veto_supremacy"]
                        and g["trigger_supremacy"])
        self.assertEqual(g["snapshot_lock"]["lock_points"], 30.0)
        self.assertEqual(g["snapshot_lock"]["lock_hours"], 12.0)
        self.assertEqual(g["range_gate"]["premium_pct"], 0.70)


if __name__ == "__main__":
    unittest.main()
