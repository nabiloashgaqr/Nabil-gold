# -*- coding: utf-8 -*-
"""R22 (2026-08-27): general symbol-isolation - the audit tool + the book stamp.

Completes the structural separation the operator ordered: every cross-symbol
storage channel is either symbol-stamped (verified by the new audit tool)
or explicitly documented as intentionally shared (macro/news). Pinned:
  * the shared market-data book meta carries a plain-text symbol field;
  * check_agents_now discloses which symbol the on-disk book belongs to;
  * the audit core: clean tree -> CLEAN; foreign-stamped store -> MIXED;
  * un-stamped legacy artifacts self-heal (WARN, never MIXED);
  * the audit CLI exits 1 only on MIXED.
"""
import json
import os
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from services.shared_market_data import publish_shared_market_data

sys.path.insert(0, os.path.join(ROOT, "scripts"))
import audit_symbol_isolation as asi  # noqa: E402

SYMBOLS = ["XAU/USD", "WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"]


def _base_config():
    return {"symbol": "XAU/USD",
            "instruments": [{"symbol": s} for s in SYMBOLS]}


def _book(symbol, price=1.1639):
    return {
        "symbol": symbol,
        "source": "mt5",
        "current_price": price,
        "timeframes": {
            tf: {"source": "mt5", "source_integrity": {},
                 "data": [{"time": 1787841300 + i, "open": price, "high": price,
                           "low": price, "close": price} for i in range(3)]}
            for tf in ("5m", "15m")
        },
    }


class TestSharedBookStamp(unittest.TestCase):
    def test_book_meta_carries_plain_text_symbol(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, "book.json")
            frozen = publish_shared_market_data(
                _book("EUR/USD"), _base_config(), path=out)
            meta = frozen["shared_market_data"]
            self.assertEqual(meta["symbol"], "EUR/USD")
            on_disk = json.loads(Path(out).read_text(encoding="utf-8"))
            self.assertEqual(on_disk["shared_market_data"]["symbol"], "EUR/USD")
            self.assertEqual(on_disk["symbol"], "EUR/USD")

    def test_overwrite_changes_the_stamp(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, "book.json")
            publish_shared_market_data(_book("EUR/USD"), _base_config(), path=out)
            frozen = publish_shared_market_data(
                _book("USD/JPY", price=159.4), _base_config(), path=out)
            self.assertEqual(frozen["shared_market_data"]["symbol"], "USD/JPY")


class TestCheckAgentsNowDisclosure(unittest.TestCase):
    def test_tool_names_the_book_symbol(self):
        src = (Path(ROOT) / "scripts" / "check_agents_now.py").read_text(encoding="utf-8")
        self.assertIn('book_symbol = str(data.get("symbol")', src)
        self.assertIn("Book symbol:", src)
        self.assertIn("STALE", src)


def _make_store(root, symbol, stamp=None):
    sys.path.insert(0, str(ROOT))
    from services.auction_flow_store import AuctionFlowStore
    store = AuctionFlowStore(str(root), symbol=symbol)
    store.mark_heartbeat()
    if stamp is not None:  # force a (wrong or empty) stamp afterwards
        con = sqlite3.connect(str(root))
        con.execute("INSERT INTO meta(key,value) VALUES('symbol',?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (stamp,))
        con.commit()
        con.close()


class TestAuditCore(unittest.TestCase):
    def _prep(self, tmp):
        root = Path(tmp)
        (root / "config.json").write_text(
            json.dumps(_base_config()), encoding="utf-8")
        return root

    def test_clean_tree_is_clean(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self._prep(tmp)
            (root / "storage").mkdir()
            for sym in SYMBOLS:
                stem = "" if sym == "XAU/USD" else "_" + sym.replace("/", "").lower()
                _make_store(root / "storage" / "auction_flow{0}.sqlite3".format(stem),
                            sym)
            publish_shared_market_data(_book("EUR/USD"), _base_config(),
                                       path=str(root / "storage" / "shared_market_data.json"))
            report = asi.audit_symbol_isolation(root, _base_config())
            self.assertEqual(report["overall"], "CLEAN")
            self.assertEqual(report["channels"]["auction stores"][0], "CLEAN")
            self.assertEqual(report["channels"]["shared book"][0], "CLEAN")

    def test_foreign_stamp_is_mixed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self._prep(tmp)
            (root / "storage").mkdir()
            _make_store(root / "storage" / "auction_flow_usdjpy.sqlite3",
                        "USD/JPY", stamp="XAU/USD")
            report = asi.audit_symbol_isolation(root, _base_config())
            self.assertEqual(report["overall"], "MIXED")
            self.assertEqual(report["channels"]["auction stores"][0], "MIXED")

    def test_unstamped_legacy_is_warn_not_mixed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self._prep(tmp)
            (root / "storage").mkdir()
            _make_store(root / "storage" / "auction_flow_usdjpy.sqlite3",
                        "USD/JPY", stamp="")
            report = asi.audit_symbol_isolation(root, _base_config())
            self.assertEqual(report["overall"], "WARN")
            self.assertEqual(report["channels"]["auction stores"][0], "WARN")

    def test_pre_r22_book_is_warn(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self._prep(tmp)
            (root / "storage").mkdir()
            (root / "storage" / "shared_market_data.json").write_text(
                json.dumps({"shared_market_data": {"snapshot_id": "MT5BOOK::x"}}),
                encoding="utf-8")
            report = asi.audit_symbol_isolation(root, _base_config())
            self.assertEqual(report["channels"]["shared book"][0], "WARN")

    def test_broker_suffixed_calibration_symbols_are_clean(self):
        # the exact first-live-run false alarm: files record the BROKER
        # symbol ("USDJPY.s"); the auditor must mirror the agent's shipped
        # validator (strip the suffix) or every correct file prints MIXED.
        with tempfile.TemporaryDirectory() as tmp:
            root = self._prep(tmp)
            cal = root / "storage" / "model_calibration"
            cal.mkdir(parents=True)
            (cal / "auction_flow_v1.json").write_text(
                json.dumps({"symbol": "XAUUSD.s", "version": "auction_flow_v1",
                            "sample_count": 300}), encoding="utf-8")
            (cal / "auction_flow_v1_usdjpy.json").write_text(
                json.dumps({"symbol": "USDJPY.s", "version": "auction_flow_v1",
                            "sample_count": 300}), encoding="utf-8")
            report = asi.audit_symbol_isolation(root, _base_config())
            self.assertEqual(report["channels"]["calibrations"][0], "CLEAN")

    def test_short_broker_form_wti_s_is_clean(self):
        # the SECOND live-run false alarm: the broker's WTI symbol is
        # "WTI.s" (short form) - the shipped validator compares with
        # bidirectional containment ("WTI" in "WTIUSD"), so must the audit.
        with tempfile.TemporaryDirectory() as tmp:
            root = self._prep(tmp)
            cal = root / "storage" / "model_calibration"
            cal.mkdir(parents=True)
            (cal / "auction_flow_v1_wtiusd.json").write_text(
                json.dumps({"symbol": "WTI.s", "version": "auction_flow_v1",
                            "sample_count": 300}), encoding="utf-8")
            report = asi.audit_symbol_isolation(root, _base_config())
            self.assertEqual(report["channels"]["calibrations"][0], "CLEAN")

    def test_wrong_symbol_calibration_is_still_mixed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self._prep(tmp)
            cal = root / "storage" / "model_calibration"
            cal.mkdir(parents=True)
            (cal / "auction_flow_v1.json").write_text(
                json.dumps({"symbol": "WTIUSD.s"}), encoding="utf-8")
            report = asi.audit_symbol_isolation(root, _base_config())
            self.assertEqual(report["channels"]["calibrations"][0], "MIXED")

    def test_cli_exit_code_only_on_mixed(self):
        self.assertEqual(asi.SEVERITY_ORDER["CLEAN"], 0)
        self.assertEqual(asi.SEVERITY_ORDER["WARN"], 1)
        self.assertEqual(asi.SEVERITY_ORDER["MIXED"], 2)


if __name__ == "__main__":
    unittest.main()
