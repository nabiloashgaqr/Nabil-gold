# -*- coding: utf-8 -*-
"""BUILD31-R18: terminal WAIT decisions write a named audit row.

Measured on the live VPS: all 6 symbols cycled and reached BOOK=WAIT with
named reasons ('No qualified agents (need >= 65%)', ...) while the funnel
reported 'ZERO decision-audit rows -> never cycled' because WAIT cycles
wrote nothing. Now every WAIT writes stage='book' with the vote's rejection
reason, and the audit cap grows to keep ~3.5 days of history.
"""
import os
import sys
import unittest
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


class TestWaitAuditRow(unittest.TestCase):
    def test_wait_branch_writes_the_named_row(self):
        src = (Path(ROOT) / "scripts" / "run_analysis.py").read_text(encoding="utf-8")
        self.assertIn('stage="book", outcome="WAIT", reason=_wait_reason', src)
        # the reason prefers the vote's rejection_reason, falls back to the
        # last safety warning, then to a constant
        self.assertIn('rejection_reason', src)
        self.assertIn("no qualified consensus", src)

    def test_audit_cap_keeps_three_and_a_half_days(self):
        src = (Path(ROOT) / "services" / "database.py").read_text(encoding="utf-8")
        self.assertIn("[:6000]", src)
        self.assertNotIn("reverse=True)[:2000]", src)

    def test_book_reject_reason_is_the_funnel_reason(self):
        # the BOOK line and the audit row must read the SAME field, so the
        # funnel text matches the log text exactly
        src = (Path(ROOT) / "scripts" / "run_analysis.py").read_text(encoding="utf-8")
        book_uses = 'decision.get("classic") or {}).get("rejection_reason"'
        self.assertIn(book_uses, src)
        self.assertGreaterEqual(src.count(book_uses), 2)


if __name__ == "__main__":
    unittest.main()
