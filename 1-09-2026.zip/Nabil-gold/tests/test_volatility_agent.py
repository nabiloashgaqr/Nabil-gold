"""2026-08-19 phase-2 tests: volatility regime agent (VIX/GVZ/OVX)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import agents.volatility_agent as va  # noqa: E402


def _series(end_value, n=40):
    return [end_value - (n - i) * 0.1 for i in range(n)]


def _feed(monkeypatch, mapping):
    def fake(symbol, *args, **kwargs):
        return mapping.get(symbol)

    monkeypatch.setattr(va, "yf_closes", fake)


class TestVolatilityAgent:
    def test_gold_extreme(self, monkeypatch):
        _feed(monkeypatch, {"^VIX": _series(35.0), "^GVZ": _series(22.0)})
        agent = va.VolatilityAgent({"volatility_agent": {"enabled": True}})
        r = agent.analyze({"symbol": "XAU/USD"})
        assert r["regime"] == "EXTREME"
        assert r["suggested_risk_multiplier"] == 0.5
        assert r["signal"] == "WAIT"  # never votes

    def test_gold_low(self, monkeypatch):
        _feed(monkeypatch, {"^VIX": _series(14.0), "^GVZ": _series(12.0)})
        r = va.VolatilityAgent({"volatility_agent": {"enabled": True}}).analyze({"symbol": "XAU/USD"})
        assert r["regime"] == "LOW"
        assert r["suggested_risk_multiplier"] == 1.0

    def test_wti_uses_ovx(self, monkeypatch):
        _feed(monkeypatch, {"^VIX": _series(15.0), "^OVX": _series(60.0)})
        r = va.VolatilityAgent({"volatility_agent": {"enabled": True}}).analyze({"symbol": "WTI/USD"})
        assert r["regime"] == "EXTREME"
        assert "OVX" in str(r["indices"])
        assert "^GVZ" not in str(r["indices"])

    def test_atr_percentile_escalates(self, monkeypatch):
        _feed(monkeypatch, {"^VIX": _series(16.0), "^GVZ": _series(15.0)})
        r = va.VolatilityAgent({"volatility_agent": {"enabled": True}}).analyze(
            {"symbol": "XAU/USD", "market_regime": {"vol_percentile": 0.95}}
        )
        assert r["regime"] == "HIGH"
        assert r["suggested_risk_multiplier"] == 0.75
        assert any("escalated" in s for s in [r["summary"]])

    def test_fail_open(self, monkeypatch):
        _feed(monkeypatch, {"^VIX": None, "^GVZ": None})
        r = va.VolatilityAgent({"volatility_agent": {"enabled": True}}).analyze({"symbol": "XAU/USD"})
        assert r["regime"] == "UNKNOWN"
        assert r["suggested_risk_multiplier"] == 1.0
        assert len(r["missing"]) == 2

    def test_disabled(self, monkeypatch):
        r = va.VolatilityAgent({"volatility_agent": {"enabled": False}}).analyze({"symbol": "XAU/USD"})
        assert r["enabled"] is False
        assert r["suggested_risk_multiplier"] == 1.0

    def test_apply_flag_is_off_by_default(self, monkeypatch):
        _feed(monkeypatch, {"^VIX": _series(35.0), "^GVZ": _series(22.0)})
        r = va.VolatilityAgent({"volatility_agent": {"enabled": True}}).analyze({"symbol": "XAU/USD"})
        assert r["apply_risk_multiplier"] is False
