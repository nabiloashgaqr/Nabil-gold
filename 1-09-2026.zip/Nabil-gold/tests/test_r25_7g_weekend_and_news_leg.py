"""R25.7-G v2 (2026-08-29, operator orders): WEEKEND TIME ACCOUNTING +
NEWS-LEG FAST RE-ARM.

v1 shipped a Friday sweep; the operator REVERSED it the same day: NO
pending is ever cancelled by a weekend policy — every pending completes
its configured life (pending_freshness.stale_after_hours, r25_scalp TTL)
and the age accounting EXCLUDES Saturday and Sunday (server calendar,
which is exactly the closed market window in both DST seasons).

Also pinned here:
  * the executor market-closed BACKOFF (journal 2026-08-29 01:01:54:
    "failed cancel ... [Market closed]" + 3x "failed modify ... [Invalid
    stops]") — a 10018 refusal arms a send backoff; actions are queued
    and retried on the caller's next natural cycle, never dropped;
  * NEWS LEG: a >=6x ATR displacement arm at the FIRST BOUNCE (entry 50%,
    zone 42-55%), velocity guard bypassed — SAME absolute stop band, same
    book+confirmation gates, same dollar law.
"""

from __future__ import annotations

import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from zoneinfo import ZoneInfo

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

import scripts.run_tick_manager as rtm  # noqa: E402
from services import pre_arm_ote as pa  # noqa: E402
from services.weekend_policy import (effective_pending_age_hours,  # noqa: E402
                                     weekend_excluded_seconds)

HEBRON = ZoneInfo("Asia/Hebron")
UTC = timezone.utc

# ── 1. the weekend-excluded clock ───────────────────────────────────────────

def test_weekday_span_excludes_nothing():
    """Wednesday 10:00 -> Wednesday 18:00 Hebron = plain 8h."""
    s = datetime(2026, 8, 26, 10, 0, tzinfo=HEBRON)   # Wed
    e = datetime(2026, 8, 26, 18, 0, tzinfo=HEBRON)
    assert weekend_excluded_seconds(s, e) == 0.0


def test_friday_to_monday_excludes_the_full_weekend():
    """Fri 21:00 -> Mon 21:00 Hebron = 72 raw hours - 48 weekend = 24h."""
    s = datetime(2026, 8, 28, 21, 0, tzinfo=HEBRON)   # Fri evening
    e = datetime(2026, 8, 31, 21, 0, tzinfo=HEBRON)   # Mon evening
    assert weekend_excluded_seconds(s, e) == pytest.approx(48 * 3600.0)
    assert effective_pending_age_hours(s, e) == pytest.approx(24.0)


def test_partial_saturday_is_pro_rated():
    s = datetime(2026, 8, 29, 10, 0, tzinfo=HEBRON)   # Sat 10:00
    e = datetime(2026, 8, 29, 16, 0, tzinfo=HEBRON)   # Sat 16:00
    assert weekend_excluded_seconds(s, e) == pytest.approx(6 * 3600.0)


def test_utc_inputs_land_on_the_same_server_calendar():
    """The market closes Fri 21:00 UTC (summer) = Sat 00:00 Hebron: a
    pending created Fri 20:59 UTC keeps 1 trade-hour before the weekend;
    from Fri 21:01 UTC the whole weekend is excluded."""
    s_before = datetime(2026, 8, 28, 20, 59, tzinfo=UTC)  # Fri 23:59 HBR
    s_after = datetime(2026, 8, 28, 21, 1, tzinfo=UTC)    # Sat 00:01 HBR
    monday = datetime(2026, 8, 31, 6, 0, tzinfo=UTC)      # Mon 09:00 HBR
    assert effective_pending_age_hours(s_before, monday) == pytest.approx(
        (1.0 / 60.0) + 9.0, abs=1e-6)   # 1 min Friday + Mon 00:00-09:00 HBR
    assert effective_pending_age_hours(s_after, monday) == pytest.approx(
        9.0, abs=1e-6)                  # pure Monday hours only


def test_older_created_than_now_is_zero():
    s = datetime(2026, 8, 30, 12, 0, tzinfo=HEBRON)
    e = datetime(2026, 8, 28, 12, 0, tzinfo=HEBRON)
    assert effective_pending_age_hours(s, e) == 0.0


# ── 2. _pending_stale integration: the pending completes its configured
#    life, with the weekend never counting ──────────────────────────────────

def _tm(stale_after_hours=6.0):
    tm = rtm.TickManager.__new__(rtm.TickManager)
    tm.config = {"pending_freshness": {"enabled": True,
                                       "stale_after_hours": stale_after_hours}}
    tm.database = SimpleNamespace(update_trade=lambda *a, **k: None)
    tm._notification_row = None
    return tm


def _pending_row(created_utc: datetime, entry=4506.45):
    return {"id": "T-PEND", "status": "PENDING", "symbol": "XAU/USD",
            "type": "SELL", "entry_price": entry,
            "created_at": created_utc.isoformat().replace("+00:00", "Z")}


def _tick(entry=4506.45):
    # live price still inside the plan (no invalidation breach)
    return SimpleNamespace(bid=entry - 1.0, ask=entry + 1.0)


def test_pending_created_friday_is_fresh_monday_morning():
    """THE operator case: pending from Friday evening wakes up Monday —
    its age only counts the live-market hours (Mon 00:00 -> 05:00 HBR
    inside this span), so the 6h staleness window has NOT run out."""
    tm = _tm(stale_after_hours=6.0)
    # Fri 20:30 UTC = Fri 23:30 SERVER time: half an hour of live Friday
    created = datetime(2026, 8, 28, 20, 30, tzinfo=UTC)
    monday = datetime(2026, 8, 30, 21, 30, tzinfo=UTC)    # Mon 00:30 HBR
    # effective age = 0.5h (Fri) + 0.5h (Mon) = 1.0h < 6 -> still alive
    row = _pending_row(created_utc=created)
    with pytest.MonkeyPatch.context() as mp:
        mp.setattr(rtm, "datetime", _FrozenNow(monday))
        assert tm._pending_stale(row, _tick()) is False
    # and the SAME wall-clock span WITHOUT the weekend exclusion = 49h:
    raw_h = (monday - created).total_seconds() / 3600.0
    assert raw_h > 6.0


def test_pending_expires_once_its_effective_age_reaches_the_limit():
    """Friday-evening pending, now Tuesday 03:00 UTC: effective age =
    Fri 21:30-24:00 (2.5h) + Tue 00:00-03:00 (3h) = 5.5h -> still alive;
    1h later (6.5h) -> stale. The weekend never consumed the window."""
    tm = _tm(stale_after_hours=6.0)
    created = datetime(2026, 8, 28, 20, 30, tzinfo=UTC)   # Fri 23:30 HBR
    # Monday dawn: the 6h window runs out in SERVER hours, not wall hours.
    mon_0130 = datetime(2026, 8, 31, 1, 30, tzinfo=UTC)   # Mon 04:30 HBR
    mon_0230 = datetime(2026, 8, 31, 2, 30, tzinfo=UTC)   # Mon 05:30 HBR
    with pytest.MonkeyPatch.context() as mp:
        mp.setattr(rtm, "datetime", _FrozenNow(mon_0130))
        # effective = 0.5h Fri + 4.5h Mon = 5.0h -> still alive
        assert tm._pending_stale(_pending_row(created), _tick()) is False
        mp.setattr(rtm, "datetime", _FrozenNow(mon_0230))
        # effective = 0.5h Fri + 5.5h Mon = 6.0h -> stale now
        assert tm._pending_stale(_pending_row(created), _tick()) is True


class _FrozenNow:
    """datetime replacement pinning datetime.now(utc) for the tick module."""

    def __init__(self, frozen: datetime):
        self._frozen = frozen

    def now(self, tz=None):
        return self._frozen

    def fromisoformat(self, raw):  # delegate the parser
        from datetime import datetime as _dt
        return _dt.fromisoformat(raw)

    def __getattr__(self, name):  # timezone etc. ride through
        from datetime import datetime as _dt
        return getattr(_dt, name)


# ── 3. the executor market-closed backoff ───────────────────────────────────

def _closed_executor(monkeypatch, tmp_path):
    import importlib
    from services.mt5_executor import Mt5DemoExecutor
    import tests.mt5_fake as mt5_fake
    m5 = importlib.import_module("services.mt5_executor")
    state = mt5_fake.FakeState()
    mod = mt5_fake.install(state)
    calls = {"n": 0}

    def closed_send(request):
        calls["n"] += 1
        return SimpleNamespace(retcode=10018, comment="Market closed")

    mod.order_send = closed_send
    monkeypatch.setitem(sys.modules, "MetaTrader5", mod)
    monkeypatch.setattr(m5, "HALT_FILE", str(tmp_path / ".demo_halt"))
    return Mt5DemoExecutor({"execution": {"demo": {}}}, telegram=None), calls


def test_market_closed_refusal_arms_the_backoff(monkeypatch, tmp_path):
    ex, calls = _closed_executor(monkeypatch, tmp_path)
    assert ex.cancel_order(57505888) is False
    assert calls["n"] == 1
    assert ex._market_closed_active() is True
    # queued, not hammered: every door refuses WITHOUT touching the broker
    assert ex.cancel_order(57505888) is False
    assert ex.apply_stop("T", 1.35000, 1.35186, "GBP/USD") is False
    assert ex.ensure_ticket("T", "SELL", "SELL_MARKET",
                            0.0, 1.16082, 1.13500, "EUR/USD") is None
    assert ex.close_position("T", "GBP/USD") is False
    assert calls["n"] == 1


def test_backoff_expiry_resumes_sending(monkeypatch, tmp_path):
    ex, calls = _closed_executor(monkeypatch, tmp_path)
    assert ex.cancel_order(1) is False and calls["n"] == 1
    ex.market_closed_until = 0.0                    # the window has passed
    assert ex.cancel_order(1) is False              # broker still closed
    assert calls["n"] == 2                          # ...but we asked again
    assert ex._market_closed_active() is True       # and backed off once more


# ── 4. NEWS-LEG fast re-arm (PATH 6) ────────────────────────────────────────

class _DB:
    def __init__(self):
        self.saved = []

    def new_trade_id(self):
        return "TRADE_PREARM_TEST"

    def save_trade(self, decision):
        self.saved.append(decision)
        return decision["trade_id"]


class _TG:
    def __init__(self):
        self.signals = []


def _candle(o, h, l, c):
    return {"time": "2026-08-28T13:45:00+00:00", "open": o, "high": h,
            "low": l, "close": c}


def _crash_then_bounce(crash_per_candle=20.0, n_crash=6, bounce=60.0,
                       base=4800.0):
    """Flat 4800, then a monster crash leg (the 2026-08-28 shape), then a
    first bounce back INTO the 42-55% zone."""
    candles = [_candle(base, base + 1, base - 1, base) for _ in range(8)]
    o = base
    for _ in range(n_crash):
        c = o - crash_per_candle
        candles.append(_candle(o, o + 0.5, c - 0.5, c))
        o = c
    low = o
    candles.append(_candle(low, low + bounce + 1, low - 0.5, low + bounce))
    candles.append(_candle(low + bounce, low + bounce + 2,
                           low + bounce - 3, low + bounce - 2))
    return candles, low


def _data(candles, current_price):
    return {"timeframes": {"15m": {"data": candles}},
            "current_price": current_price}


def _classic_book(direction="SELL", n_support=3, n_oppose=0, net=68.0):
    opposite = "BUY" if direction == "SELL" else "SELL"
    return {"consensus": {
        direction: {"supporters": ["smc", "technical", "classical"],
                    "opponents": [], "support_count": 3,
                    "opposition_count": 0, "edge": 1.5, "confidence": net},
        opposite: {"supporters": [], "opponents": ["smc", "technical",
                                                   "classical"],
                   "support_count": 0, "opposition_count": 3, "edge": -1.5,
                   "confidence": 40.0},
    }}


def _macro_ok(direction="SELL", conf=58.0):
    return {"macro_fundamental": {"macro_direction": {
        "bias": "BEARISH_GOLD" if direction == "SELL" else "BULLISH_GOLD",
        "confidence": conf}}}


def test_news_leg_arms_the_first_bounce_at_50pct(monkeypatch):
    """THE incident shape: 8 candles flat, a 15x-ATR crash, one bounce —
    the velocity guard would refuse monster candles forever, so the old
    code armed 7.5h late. The news law arms the bounce at 50% now."""
    monkeypatch.setattr(pa, "_news_blocks", lambda results: False)
    candles, low = _crash_then_bounce()            # 120pt crash, ATR 8
    leg = pa.detect_impulse_leg(candles, 8.0, pa._cfg({}), "SELL")
    assert leg is not None and leg["leg_size"] / 8.0 >= 6.0   # news class
    entry_expected = leg["leg_peak"] + leg["leg_size"] * 0.50
    cp = low + 58.0                                # bouncing under the zone
    db, tg = _DB(), _TG()
    side = pa.try_pre_arm(
        data=_data(candles, cp),
        all_results={"smc": {"trend": "BEARISH"}, "risk": {"approved": True},
                     **_macro_ok("SELL", 58.0)},
        config={}, symbol="XAU/USD",
        open_trades_snapshot=[], database=db, telegram=tg,
        current_price=cp,
        classic_book=_classic_book("SELL", 3, 0, 68.0))
    assert side == "SELL"
    d = db.saved[0]
    sig = d["signal"]
    assert d["pre_arm_info"]["news_leg"] is True
    assert d["pre_arm_info"]["entry_pct"] == pytest.approx(0.50)
    assert sig["entry"]["price"] == pytest.approx(round(entry_expected, 2),
                                                  abs=0.6)
    # the SAME absolute stop band applies: [270, 400] gold points
    dist_points = (sig["stop_loss"] - sig["entry"]["price"]) / 0.1
    assert 270.0 <= dist_points <= 400.0
    assert any("NEWS-LEG" in r for r in d["reasons"])


def test_normal_leg_keeps_the_static_70_arm(monkeypatch):
    """A ~5x ATR leg stays on the classic path: 70% OTE entry, velocity
    guard in force, no news flag."""
    monkeypatch.setattr(pa, "_news_blocks", lambda results: False)
    candles, low = _crash_then_bounce(crash_per_candle=2.0, n_crash=6,
                                      bounce=3.0)
    # the armer computes ATR from the candles themselves — mirror that
    atr_internal = pa.calculate_atr(candles, 14)[-1]
    leg = pa.detect_impulse_leg(candles, atr_internal, pa._cfg({}), "SELL")
    assert leg is not None and leg["leg_size"] / atr_internal < 6.0
    entry_expected = leg["leg_peak"] + leg["leg_size"] * 0.70
    cp = low + 2.0
    db, tg = _DB(), _TG()
    side = pa.try_pre_arm(
        data=_data(candles, cp),
        all_results={"smc": {"trend": "BEARISH"}, "risk": {"approved": True},
                     **_macro_ok("SELL", 58.0)},
        config={}, symbol="XAU/USD",
        open_trades_snapshot=[], database=db, telegram=tg,
        current_price=cp,
        classic_book=_classic_book("SELL", 3, 0, 68.0))
    assert side == "SELL"
    d = db.saved[0]
    assert "news_leg" not in d["pre_arm_info"]
    assert d["signal"]["entry"]["price"] == pytest.approx(
        round(entry_expected, 2), abs=0.6)


def test_news_leg_kill_switch_restores_the_velocity_guard(monkeypatch):
    monkeypatch.setattr(pa, "_news_blocks", lambda results: False)
    candles, low = _crash_then_bounce()
    cfg = {"pre_arm_ote": {"news_leg_enabled": False}}
    side = pa.try_pre_arm(
        data=_data(candles, low + 58.0),
        all_results={"smc": {"trend": "BEARISH"}, "risk": {"approved": True},
                     **_macro_ok("SELL", 58.0)},
        config=cfg, symbol="XAU/USD",
        open_trades_snapshot=[], database=_DB(), telegram=_TG(),
        current_price=low + 58.0,
        classic_book=_classic_book("SELL", 3, 0, 68.0))
    assert side is None    # the monster candles re-arm the velocity refusal
