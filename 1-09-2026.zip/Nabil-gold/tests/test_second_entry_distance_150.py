"""The second-entry distance family is 150 gold points — and ONLY distance.

Operator 2026-08-18: "اضافة صفقة ثانية على بعد 150 نقطة بدل 200 نقطة حد
ادنى... وطبعا الشرط كما هو لازم يكون توافق وكلاء ومؤهلين وليس عشوائي".

Three gates govern how far a second same-direction entry must sit from an
existing one, and they moved together so they cannot disagree:

  * two_agent_entry.cross_entry_distance_points   200 -> 150
  * order_execution.fixed_risk.scale_in_trigger_points 200 -> 150
  * duplicate_signal_filter.price_zone_points     200 -> 150
  * instruments: gold duplicate_zone 200 -> 150; BUILD 31 R3 (2026-08-24):
    oil = gold x 0.4 (duplicate_zone 60, cross_entry 60) — the 0.3-scale
    75/45 remnant and the 1:1 interpretation are both superseded

What did NOT change — and these tests enforce it — is qualification: the
closer distance never admits anything by itself. A second entry still
passes the full shared admission (family gate, agent bar 65, net floor 65,
risk agent) and the directional better-price rule (BUY lower / SELL
higher).
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


# ── the three gates carry the same number ───────────────────────────────────

def test_cross_entry_distance_is_150():
    tae = CONFIG["signal_requirements"]["two_agent_entry"]
    assert int(tae["cross_entry_distance_points"]) == 150


def test_scale_in_trigger_is_150():
    fr = CONFIG["order_execution"]["fixed_risk"]
    assert float(fr["scale_in_trigger_points"]) == 150


def test_duplicate_zone_is_150():
    assert float(CONFIG["duplicate_signal_filter"]["price_zone_points"]) == 150


def test_gold_instrument_spec_agrees():
    from utils.instruments import DEFAULT_INSTRUMENTS
    assert DEFAULT_INSTRUMENTS["XAU/USD"]["duplicate_zone_points"] == 150


def test_oil_family_is_gold_times_04():
    """BUILD 31 R3 (operator order '0.4 حسابيا للكل'): the distance
    family is gold x0.4 — 60 for oil, 150 for gold."""
    from utils.instruments import DEFAULT_INSTRUMENTS
    wti = DEFAULT_INSTRUMENTS["WTI/USD"]
    # R26.1: WTI distance family is gold x0.5 (75 for oil, 150 for gold).
    assert wti["duplicate_zone_points"] == 150 * 0.5 == 75
    assert wti["cross_entry_distance_points"] == 150 * 0.5 == 75


def test_code_fallbacks_match_the_config():
    import io
    src = io.open(ROOT / "scripts" / "run_analysis.py", encoding="utf-8").read()
    assert 'cross_entry_distance_points", 150)' in src
    assert 'scale_in_trigger_points", 150)' in src
    assert "cross_distance_points: int = 150" in src
    assert 'cross_entry_distance_points", 200)' not in src


# ── distance changed; qualification did not ─────────────────────────────────

def test_150_points_alone_admits_nothing():
    """A book that fails admission stays refused at ANY distance — the
    operator's 'ليس عشوائي' condition."""
    from services.thesis_consensus import evaluate_directional_admission
    weak_book = {
        "technical": {"signal": "BUY", "confidence": 64.9},  # below the 65 bar
        "multitimeframe": {"signal": "BUY", "confidence": 60},
        "classical": {"signal": "WAIT", "confidence": 40},
        "smc": {"signal": "WAIT", "confidence": 30},
        "price_action": {"signal": "WAIT", "confidence": 30},
    }
    admission = evaluate_directional_admission("BUY", weak_book, CONFIG)
    assert admission["allow"] is False


def test_scale_in_reads_the_book_for_the_opposition_veto():
    """UPDATED 2026-08-18b: the add no longer requires a fresh shared
    admission (the parent earned consensus at entry). The book is still
    read — through the same evaluator — but only to count qualified
    opponents for the hard >= 2 veto."""
    import io
    src = io.open(ROOT / "scripts" / "run_analysis.py", encoding="utf-8").read()
    scale_block = src.split("def _check_scale_in")[1][:14000] if "def _check_scale_in" in src else src
    assert "evaluate_directional_admission" in scale_block
    assert "oppose_count >= 2" in scale_block


def test_better_price_rule_survives():
    """BUY adds below, SELL adds above — direction of the dip is untouched."""
    import io
    src = io.open(ROOT / "scripts" / "run_analysis.py", encoding="utf-8").read()
    assert "buy the dip rule" in src
    assert "pullback_pts < trigger_points" in src
