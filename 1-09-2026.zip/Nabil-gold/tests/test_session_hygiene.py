# -*- coding: utf-8 -*-
"""R25.12: test-session hygiene lint (the R25.9 failure class, closed).

The VPS suite failure of R25.9 had one root cause: a test assigned
``sys.argv`` directly and never restored it, so the NEXT in-process CLI
(the argparse-based scrub tool) parsed a foreign ``--root`` and died.

Two structural guards now make that class impossible:

1. tests/conftest.py resets argv for every test (autouse, monkeypatched).
2. THIS lint: no test file may ASSIGN sys.argv directly - tests that need
   a specific argv use ``monkeypatch.setattr("sys.argv", ...)`` which
   restores automatically. Reading argv is unrestricted.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

#: Direct assignment to sys.argv (module-alias forms included).
_DIRECT_ARGV_ASSIGN = re.compile(r"^\s*[_A-Za-z][\w]*sys\.argv\s*=")


def test_no_test_assigns_sys_argv_directly():
    offenders = []
    for path in sorted((ROOT / "tests").glob("*.py")):
        for lineno, line in enumerate(
                path.read_text(encoding="utf-8", errors="ignore").splitlines(), start=1):
            if _DIRECT_ARGV_ASSIGN.match(line):
                offenders.append("%s:%d: %s" % (
                    path.relative_to(ROOT), lineno, line.strip()[:90]))
    assert not offenders, (
        "direct sys.argv assignment(s) in tests - use monkeypatch.setattr "
        "so argv is restored (%d):\n  %s" % (len(offenders), "\n  ".join(offenders)))


def test_conftest_resets_argv_for_every_test():
    text = (ROOT / "tests" / "conftest.py").read_text(encoding="utf-8")
    assert 'monkeypatch.setattr(sys, "argv"' in text, (
        "the conftest must keep the hermetic-argv fixture in place")
