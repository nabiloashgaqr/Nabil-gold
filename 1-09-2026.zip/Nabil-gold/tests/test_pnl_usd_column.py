"""R25.15 convoy step 3 — the pnl_usd column: real dollars in the book.

Sources of truth, in order:
  * tick manager broker close -> the broker deal's own profit;
  * 5m engine close           -> risk_usd.usd_pnl at the row's recorded lots;
  * a row without lots        -> NO pnl_usd (unknown stays unknown);
  * weekly report             -> sums stamped pnl_usd; the legacy pts/10
    gold-era estimate is shown only when nothing was stamped.
"""
from __future__ import annotations

from datetime import datetime, timezone

import pytest

from agents.open_trades_manager import OpenTradesManager
from services.risk_usd import usd_pnl
from services.weekly_report import WeeklyStats, WeeklyReportService

NOW = datetime.now(timezone.utc)


class _AuditDB:
    def __init__(self):
        self.rows = []

    def save_decision_audit(self, row):
        self.rows.append(dict(row))


def _sell_gbp_trade():
    return {"id": "T-USD", "symbol": "GBP/USD", "type": "SELL", "status": "OPEN",
            "entry_price": 1.35504, "stop_loss": 1.36504, "tp1": 1.35004,
            "tp2": 1.34504, "lots": 0.10, "sl_moved_to_entry": False,
            "updates_sent": []}


def test_usd_pnl_sign_follows_favorable_move():
    """The fixed-sign defect: a profitable SELL used to report NEGATIVE $.

    GBP point = 0.00001: 100 pts = 0.00100 price = $10 per 0.1 lot.
    """
    assert usd_pnl("GBP/USD", 0.1, 1.35504, 1.35404, "SELL") == pytest.approx(10.0)
    assert usd_pnl("GBP/USD", 0.1, 1.35504, 1.35604, "SELL") == pytest.approx(-10.0)
    assert usd_pnl("GBP/USD", 1.0, 1.33398, 1.33518, "BUY") == pytest.approx(120.0)
    assert usd_pnl("GBP/USD", 1.0, 1.33398, 1.33518, "SELL") == pytest.approx(-120.0)


def test_full_close_stamps_pnl_usd_from_row_lots():
    db = _AuditDB()
    mgr = OpenTradesManager({
        "trade_management": {"expire_after_hours": 0, "time_warning_hours": 999},
    })
    ev = mgr.evaluate_trade(_sell_gbp_trade(), 1.3440, candle_low=1.34504,
                            now=NOW, database=db)  # TP2 touched -> close
    assert ev["new_status"] == "TP2_HIT"
    # entry 1.35504 -> TP2 1.34504 = 1000 pts favourable at $0.10/pt = $100
    assert ev["updates"]["final_pnl_points"] == 1000.0
    assert ev["updates"]["pnl_usd"] == pytest.approx(100.0)


def test_row_without_lots_stays_honest_no_pnl_usd():
    db = _AuditDB()
    mgr = OpenTradesManager({
        "trade_management": {"expire_after_hours": 0, "time_warning_hours": 999},
    })
    trade = _sell_gbp_trade()
    trade.pop("lots")
    ev = mgr.evaluate_trade(trade, 1.3440, candle_low=1.34504,
                            now=NOW, database=db)
    assert ev["new_status"] == "TP2_HIT"
    assert "pnl_usd" not in ev["updates"]


def test_weekly_report_prefers_real_dollars_when_stamped():
    svc = WeeklyReportService.__new__(WeeklyReportService)
    svc.config = {}
    stats = WeeklyStats()
    stats.wins, stats.losses, stats.break_even = 2, 1, 0
    stats.win_rate = 66.7
    stats.net_pnl_points = 250.0
    stats.net_pnl_usd = 12.34
    stats.profit_factor = 2.0
    text = svc._fallback_message(stats)
    assert "$+12.34 real from stamped rows" in text
    assert "pts÷10 est" in text


def test_weekly_report_falls_back_to_legacy_estimate_without_stamps():
    svc = WeeklyReportService.__new__(WeeklyReportService)
    svc.config = {}
    stats = WeeklyStats()
    stats.wins, stats.losses, stats.break_even = 1, 1, 0
    stats.win_rate = 50.0
    stats.net_pnl_points = 100.0
    stats.net_pnl_usd = None
    stats.profit_factor = 1.5
    text = svc._fallback_message(stats)
    assert "real from stamped rows" not in text
    assert "$+10.0)" in text
