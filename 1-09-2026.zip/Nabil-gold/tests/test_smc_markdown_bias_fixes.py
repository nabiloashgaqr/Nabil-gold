"""Five structural long-biases in the SMC agent, exposed 2026-08-18.

The day: gold topped at 4399 (a buy-side raid the manual analyst read as
distribution), then walked down 45 dollars in an orderly markdown. SMC
read BUY 73% at 14:26 — the lone qualified supporter behind a chain of
losing adds — and never once produced a SELL candidate. Post-mortem found
five biases that all wake together in a falling market:

  1. every down-step that broke a prior low and closed back above it was
     scored "sell_side sweep -> bullish reversal" (+2.8/cycle);
  2. the first-match scan let each small new step HIDE the 4399 raid;
  3. price kept sliding INTO stale bullish order blocks (+ points), while
     bearish OBs sat far above, invisible to the proximity check;
  4. the reversal SELL path required zone == PREMIUM, so it closed the
     moment the reversal started working (30 points down = EQUILIBRIUM);
  5. confidence = 42 + |score|*8 started at 74% — above the 65 bar — so
     SMC had no quiet voice, only silence or a qualified shout.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from agents.smc_agent import SMCAgent

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
AGENT = SMCAgent(CONFIG)
TOL = 1.0


def _candle(o, h, l, c, t="2026-08-18T14:00:00"):
    return {"open": o, "high": h, "low": l, "close": c, "time": t}


def _stepping_markdown(start=4400.0, steps=24):
    """An orderly decline: the last candle wicks BELOW the lowest prior low
    (a stop-run tail) yet closes back above it — the exact shape the old
    detector kept calling a bullish 'sell_side sweep' on every cycle."""
    candles = []
    price = start
    for i in range(steps - 1):
        o = price
        c = price - 2.0
        candles.append(_candle(o, o + 0.5, c - 0.5, c,
                               f"2026-08-18T{10 + i // 12:02d}:{(i * 5) % 60:02d}:00"))
        price = c
    # Final step: dives 4 under the lowest prior low, closes back above it.
    prior_low = min(x["low"] for x in candles[-12:])
    candles.append(_candle(price, price + 0.3, prior_low - 4.0, prior_low + 1.0,
                           "2026-08-18T14:25:00"))
    return candles


def _raid_then_markdown():
    """The 4399 shape: flat base, spike through the highs that closes back
    under them (STRONG raid), then the markdown begins."""
    base = [_candle(4380 + (i % 3) * 0.5, 4384, 4378, 4381, f"2026-08-18T09:{(i*5)%60:02d}:00")
            for i in range(18)]
    raid = _candle(4382, 4399, 4381, 4383, "2026-08-18T14:00:00")  # takes highs, closes at lows
    down1 = _candle(4383, 4384, 4374, 4375, "2026-08-18T14:05:00")
    down2 = _candle(4375, 4376, 4366, 4368, "2026-08-18T14:10:00")
    return base + [raid, down1, down2]


# ── fix 1: with-trend sweeps are continuation, not reversal ─────────────────

def test_down_steps_are_tagged_with_trend():
    candles = _stepping_markdown()
    sweep = AGENT._recent_sweep(candles, TOL)
    assert sweep["occurred"] is True
    assert sweep["type"] == "sell_side"
    assert sweep["with_trend"] is True, (
        "a stepping markdown's low-breaks are the move itself, not a raid")


def test_with_trend_sweep_earns_a_quarter_of_the_points():
    candles = _stepping_markdown()
    sweep = AGENT._recent_sweep(candles, TOL)
    liquidity = {"recent_sweep": sweep}
    score, signals, comps = AGENT._score_smc(
        trend="RANGING", current_price=candles[-1]["close"],
        order_blocks=[], liquidity=liquidity, fvg=[], zone="DISCOUNT",
        atr=2.0, recent_displacement=-20.0)
    assert abs(comps["liquidity_sweep"]) <= 1.0, (
        f"with-trend sweep paid {comps['liquidity_sweep']} — the +2.8 knife bonus is back")
    assert any("continuation step" in s for s in signals)


def test_counter_trend_sweep_keeps_full_points():
    candles = _raid_then_markdown()
    sweep = AGENT._recent_sweep(candles, TOL)
    liquidity = {"recent_sweep": sweep}
    score, signals, comps = AGENT._score_smc(
        trend="RANGING", current_price=candles[-1]["close"],
        order_blocks=[], liquidity=liquidity, fvg=[], zone="EQUILIBRIUM",
        atr=2.0, recent_displacement=2.0)
    assert comps["liquidity_sweep"] <= -1.8, "a true raid must keep its reversal weight"


# ── fix 2: the strong raid outranks newer, weaker steps ─────────────────────

def test_the_4399_raid_is_not_hidden_by_later_down_steps():
    candles = _raid_then_markdown()
    sweep = AGENT._recent_sweep(candles, TOL)
    assert sweep["type"] == "buy_side", (
        f"the buy-side raid vanished behind a {sweep['type']} step again")
    assert sweep.get("with_trend") is not True


# ── fix 3: OBs met on hard opposing displacement lose their points ──────────

def _bullish_ob_at(price):
    return {"type": "bullish", "strength": "strong", "mitigation_status": "FRESH",
            "mitigated": False, "invalidated": False,
            "zone": {"top": price + 2.0, "bottom": price - 2.0},
            "displacement_quality": "STRONG"}


def test_bullish_ob_on_hard_fall_is_discounted():
    score, signals, comps = AGENT._score_smc(
        trend="RANGING", current_price=4370.0,
        order_blocks=[_bullish_ob_at(4370.0)],
        liquidity={"recent_sweep": {}}, fvg=[], zone="EQUILIBRIUM",
        atr=2.0, recent_displacement=-10.0)          # 5 ATR of fall
    assert comps["order_blocks"] <= 0.7, (
        f"a bullish OB met at -5 ATR displacement still paid {comps['order_blocks']}")
    assert any("run through" in s for s in signals)


def test_bullish_ob_on_calm_approach_keeps_points():
    score, signals, comps = AGENT._score_smc(
        trend="RANGING", current_price=4370.0,
        order_blocks=[_bullish_ob_at(4370.0)],
        liquidity={"recent_sweep": {}}, fvg=[], zone="EQUILIBRIUM",
        atr=2.0, recent_displacement=-1.0)           # gentle drift
    assert comps["order_blocks"] >= 2.0


# ── fix 4: a STRONG raid maps the reversal from EQUILIBRIUM too ─────────────

def test_strong_raid_maps_sell_from_equilibrium():
    direction = AGENT._reversal_direction(
        market_structure={"trend": "BULLISH"},
        liquidity={"recent_sweep": {"occurred": True, "type": "buy_side",
                                    "confirmation": "STRONG", "with_trend": False}},
        zone="EQUILIBRIUM")
    assert direction == "SELL", (
        "the reversal candidate still dies the moment it starts working")


def test_moderate_raid_still_needs_premium():
    direction = AGENT._reversal_direction(
        market_structure={"trend": "BULLISH"},
        liquidity={"recent_sweep": {"occurred": True, "type": "buy_side",
                                    "confirmation": "MODERATE", "with_trend": False}},
        zone="EQUILIBRIUM")
    assert direction is None


def test_with_trend_sweep_never_implies_reversal():
    direction = AGENT._reversal_direction(
        market_structure={"trend": "BEARISH"},
        liquidity={"recent_sweep": {"occurred": True, "type": "sell_side",
                                    "confirmation": "STRONG", "with_trend": True}},
        zone="DISCOUNT")
    assert direction is None


# ── fix 5: the confidence curve has a quiet zone under the bar ──────────────

def test_threshold_score_lands_under_the_qualification_bar():
    assert AGENT._confidence(4.0, True, "BUY") == 64, (
        "the minimum directional score must NOT auto-qualify at the 65 bar")


def test_stronger_evidence_still_qualifies():
    assert AGENT._confidence(5.0, True, "BUY") == 70
    assert AGENT._confidence(7.5, True, "BUY") == 85


def test_sweep_cap_still_rules():
    assert AGENT._confidence(10.0, False, "BUY") == 80   # no sweep -> cap 80
    assert AGENT._confidence(10.0, True, "BUY") == 90    # sweep -> cap 90
