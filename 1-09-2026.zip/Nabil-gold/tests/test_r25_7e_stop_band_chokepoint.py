"""R25.7-E (2026-08-28): the stop band is ABSOLUTE on every signal path.

Live incident (operator screenshot, gold pending): a PATH 6 pre-arm
SELL_LIMIT shipped SL 4651.47 on entry 4580.61 — a 708.6-pt stop against
the 400-pt cap — because project_ote anchored the stop to
leg_origin + 1.0xATR with no ceiling on a crash-day ATR. The same
screenshot's EUR market row shipped the config lot 0.1 because the tick
manager passes entry_price=0.0 for MARKET orders and _order_lot fell back
without a reference price.

The law now has THREE doors, all tested here:
  1. clamp_stop_price — the band law on a PRICE level, per symbol
     (gold [270,400] pts, WTI+FX [230,330] pts).
  2. pre_arm_ote._build_decision — the source door clamps before saving
     and recomputes rr from the clamped risk.
  3. mt5_executor.ensure_ticket — the chokepoint clamps whatever arrives
     (pendings at their own level, MARKET orders at the live tick) and
     solves the dollar-law lot from the FINAL reference/stop pair.
"""

from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from utils.instruments import config_for_instrument, get_instrument  # noqa: E402
from utils.trading_rules import clamp_stop_price  # noqa: E402

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
FIVE = ("WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")


# ── 1. the band law on a price level, per symbol ────────────────────────────

def test_gold_screenshot_stop_is_capped_to_400():
    """THE incident: SELL_LIMIT 4580.61 / SL 4651.47 (708.6 pts) -> the cap."""
    out = clamp_stop_price(direction="SELL", entry=4580.61, stop=4651.47,
                           cfg=CONFIG, symbol="XAU/USD")
    assert out == pytest.approx(4620.61)  # 4580.61 + 400 * 0.1


@pytest.mark.parametrize("symbol", ("XAU/USD",) + FIVE)
def test_band_floor_widens_noise_stops(symbol):
    """A stop tighter than the floor (min_liquidity + buffer) is widened."""
    from tests._band_table import FLOOR, REF_PRICE
    pv = 0.1 if symbol == "XAU/USD" else 0.01 if symbol == "WTI/USD" else (
        0.001 if symbol == "USD/JPY" else 0.00001)
    floor = 270.0 if symbol == "XAU/USD" else float(FLOOR[symbol])
    entry = REF_PRICE[symbol]
    noise = floor / 10.0  # one tenth of the floor -> clamps to the floor
    out = clamp_stop_price(direction="SELL" if symbol != "XAU/USD" else "SELL",
                           entry=entry,
                           stop=entry + noise * pv,
                           cfg=CONFIG, symbol=symbol)
    assert out == pytest.approx(round(entry + floor * pv, 8))


@pytest.mark.parametrize("symbol", ("XAU/USD",) + FIVE)
def test_band_cap_clamps_oversized_stops(symbol):
    from tests._band_table import CAP
    cap = 400.0 if symbol == "XAU/USD" else float(CAP[symbol])
    pv = 0.1 if symbol == "XAU/USD" else 0.01 if symbol == "WTI/USD" else (
        0.001 if symbol == "USD/JPY" else 0.00001)
    entry = 154.20 if symbol == "USD/JPY" else 4580.61 if symbol == "XAU/USD" \
        else 61.50 if symbol == "WTI/USD" else 1.15852
    out = clamp_stop_price(direction="SELL", entry=entry,
                           stop=entry + (cap + 100.0) * pv,
                           cfg=CONFIG, symbol=symbol)
    assert out == pytest.approx(round(entry + cap * pv, 8))


def test_in_band_stop_is_untouched_and_wrong_side_is_protected():
    # EUR row inside the NEW [600,900]-pt band (700 pts) -> untouched.
    assert clamp_stop_price(direction="SELL", entry=1.15852, stop=1.16552,
                            cfg=CONFIG, symbol="EUR/USD") == pytest.approx(1.16552)
    # A stop tighter than the floor on the protective side is widened to floor.
    assert clamp_stop_price(direction="SELL", entry=1.15852, stop=1.16082,
                            cfg=CONFIG, symbol="EUR/USD") == pytest.approx(1.16452, abs=1e-4)
    # Wrong-side stops (BE / trailing / protection) are never widened here.
    assert clamp_stop_price(direction="SELL", entry=1.35504, stop=1.35481,
                            cfg=CONFIG, symbol="GBP/USD") == pytest.approx(1.35481)
    assert clamp_stop_price(direction="BUY", entry=154.20, stop=154.23,
                            cfg=CONFIG, symbol="USD/JPY") == pytest.approx(154.23)
    # Rule disabled -> the clamp door is closed (base block AND the
    # per-symbol spec override, which takes precedence by design).
    off = json.loads(json.dumps(CONFIG))
    off["trading_rules"]["stop"]["enabled"] = False
    for inst in off.get("instruments", []):
        if inst.get("symbol") == "XAU/USD":
            inst.setdefault("trading_rules", {}).setdefault(
                "stop", {})["enabled"] = False
    assert clamp_stop_price(direction="SELL", entry=4580.61, stop=4651.47,
                            cfg=off, symbol="XAU/USD") == pytest.approx(4651.47)


# ── 2. the SOURCE door: pre-arm OTE clamps before saving ────────────────────

def _gold_incident_leg() -> dict:
    """The exact leg behind the screenshot: origin 4630.97, ATR 20.5,
    peak 4460.58 -> OTE entry 4580.61, raw stop 4651.47 (708.6 pts)."""
    return {"direction": "SELL", "leg_origin": 4630.97, "leg_peak": 4460.58,
            "leg_size": (4580.61 - 4460.58) / 0.70, "atr": 20.5}


def test_pre_arm_decision_clamps_the_screenshot_stop():
    from services.pre_arm_ote import _build_decision, project_ote
    leg = _gold_incident_leg()
    ote = project_ote(leg, {"adaptive_level": False, "entry_pct": 0.70,
                            "stop_buffer_atr": 1.0})
    assert ote["entry"] == pytest.approx(4580.61, abs=0.011)
    assert ote["stop"] == pytest.approx(4651.47, abs=0.011)  # the raw leak

    decision = _build_decision(config=CONFIG,
                               cfg={"adaptive_level": False,
                                    "entry_pct": 0.70,
                                    "stop_buffer_atr": 1.0},
                               symbol="XAU/USD", direction="SELL", ote=ote,
                               cp=4550.0, rr=1.69, atr=20.5, tp2=4460.58,
                               smc_trend="BULLISH", leg=leg, vote={})
    sig = decision["signal"]
    assert sig["stop_loss"] == pytest.approx(4620.61)  # the 400-pt cap
    # rr recomputed from the CLAMPED risk: 120.03 / 40.0
    assert sig["rr_ratio"] == pytest.approx(3.0)
    assert any("clamped" in r for r in decision["reasons"])


def test_pre_arm_decision_leaves_in_band_stop_alone():
    from services.pre_arm_ote import _build_decision, project_ote
    leg = {"direction": "SELL", "leg_origin": 4587.58, "leg_peak": 4460.58,
           "leg_size": 150.0, "atr": 8.0}  # stop 4595.58 -> 300 pts, in band
    ote = project_ote(leg, {"adaptive_level": False, "entry_pct": 0.70,
                            "stop_buffer_atr": 1.0})
    # 4658.0 - 4460.58*0.0 ... entry = 4460.58 + 105 = 4565.58; stop 4658.0
    dist = ote["stop"] - ote["entry"]
    assert 270.0 <= dist / 0.1 <= 400.0  # genuinely in band
    decision = _build_decision(config=CONFIG,
                               cfg={"adaptive_level": False,
                                    "entry_pct": 0.70,
                                    "stop_buffer_atr": 1.0},
                               symbol="XAU/USD", direction="SELL", ote=ote,
                               cp=4550.0, rr=1.5, atr=8.0,
                               tp2=ote["target"], smc_trend="BULLISH",
                               leg=leg, vote={})
    assert decision["signal"]["stop_loss"] == pytest.approx(
        round(ote["stop"], 2))
    assert not any("clamped" in r for r in decision["reasons"])


# ── 3. the CHOKEPOINT: the executor clamps whatever arrives ─────────────────

def _executor(monkeypatch, tmp_path, tick=None):
    from services.mt5_executor import Mt5DemoExecutor
    import tests.mt5_fake as mt5_fake
    m5 = importlib.import_module("services.mt5_executor")
    state = mt5_fake.FakeState()
    mod = mt5_fake.install(state)
    if tick is not None:
        mod.symbol_info_tick = lambda sym: SimpleNamespace(bid=tick[0],
                                                           ask=tick[1])
    monkeypatch.setitem(sys.modules, "MetaTrader5", mod)
    monkeypatch.setattr(m5, "HALT_FILE", str(tmp_path / ".demo_halt"))
    return Mt5DemoExecutor({"execution": {"demo": {}}}, telegram=None), state


def test_executor_clamps_a_pending_stop_above_the_cap(monkeypatch, tmp_path):
    """The same incident at the execution door: a pre-arm row (or any future
    path) arriving with SL 4651.47 is clamped to 4620.61 BEFORE the send,
    and the lot is solved from the clamped 400-pt distance."""
    ex, state = _executor(monkeypatch, tmp_path)
    ticket = ex.ensure_ticket("T-BAND", "SELL", "SELL_LIMIT",
                              4580.61, 4651.47, 4460.58, "XAU/USD")
    assert ticket is not None
    req = state.requests[0]
    assert req["sl"] == pytest.approx(4620.61)      # cap applied at send
    assert req["volume"] == pytest.approx(0.07)     # $270/$4000 -> ceil 0.07
    assert ex.last_order["sl_band_fixed"] is True
    assert ex.last_order["sl"] == pytest.approx(4620.61)


def test_executor_market_order_uses_the_live_tick_when_entry_is_zero(
        monkeypatch, tmp_path):
    """THE second live bug: the tick manager calls MARKET orders with
    entry_price=0.0 — the executor must use the live tick as the reference
    price, so the EUR row solves the dollar-law lot (1.18) instead of
    falling back to the config lot 0.1."""
    ex, state = _executor(monkeypatch, tmp_path, tick=(1.15852, 1.15854))
    # R26.1: EUR band is now [600,900] points (60-90 pips). A MARKET order
    # arrives with the old tight 230-pt stop (1.16082) and entry_price=0.0;
    # the executor must (a) use the live tick as reference and (b) widen the
    # stop to the 600-pt floor, then solve the dollar-law lot (~0.45, not the
    # old 1.18 that drove the live oversized 1.17-lot EUR position).
    ticket = ex.ensure_ticket("T-MKT", "SELL", "SELL_MARKET",
                              0.0, 1.16082, 1.13500, "EUR/USD")
    assert ticket is not None
    req = state.requests[0]
    assert req["sl"] == pytest.approx(1.16452, abs=1e-4)   # widened to ~600 pts
    assert req["volume"] == pytest.approx(0.45, abs=0.01)  # $270 over the wide stop
    assert ex.last_order["sl_band_fixed"] is True          # tight 230-pt stop was widened
    # (the old tight 230-pt stop IS widened under R26.1, so band_fixed is True)
