# -*- coding: utf-8 -*-
"""R23 (2026-08-27): storage maintenance - prune ALL stores + vacuum + audit.

Operator report: storage hit 1.5 GB. Code audit found the tick manager
pruned ONLY the gold store while the five forex/oil aux stores grew
unbounded, nothing ever vacuumed, logs had no rotation and daily
measurement files were never cleaned. Pinned here:
  * prune_all_stores services EVERY store (base + aux naming rule) and
    leaves ZERO rows older than the configured retention;
  * VACUUM runs gated by a 'last_vacuum' meta stamp (once/day) and the
    file actually shrinks after bulk deletion;
  * the audit tool flags a stale store as PRUNE-OVERDUE and reports it
    healthy after the fix;
  * measurement files older than 30 days are removed; newer ones stay;
  * oversize logs rotate to .1 (one generation); locked logs are
    reported, never forced.
"""
import json
import os
import sqlite3
import sys
import tempfile
import time
import json
import os
import sqlite3
import sys
import tempfile
import time
import unittest

# R25.2 (2026-08-28, VPS court record): the three failures were NEVER
# functional - the asserts PASSED on the VPS (stale_left=0, vacuum=True);
# only the tmp-dir CLEANUP crashed (WinError 32: a sqlite handle still
# open at rmtree). Root cause fixed in AuctionFlowStore.prune (explicit
# checkpoint close); this flag keeps Windows cleanup noise (AV/indexer/
# GC timing) from ever masking a green functional result again.
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from services.auction_flow_store import (AuctionFlowStore,
                                         auction_store_paths,
                                         prune_all_stores)

sys.path.insert(0, os.path.join(ROOT, "scripts"))
import storage_maintenance_audit as sma  # noqa: E402

SYMBOLS = ["WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"]


def _config(tmp_root, base="XAU/USD"):
    return {"symbol": base,
            "auction_flow": {"second_retention_days": 7,
                             "minute_retention_days": 90,
                             "storage_path": "storage/auction_flow.sqlite3"},
            "instruments": [{"symbol": base, "enabled": True}] +
                           [{"symbol": s, "enabled": True} for s in SYMBOLS],
            # the instrument registry reads config["symbols"] (the tick
            # manager's aux collectors use the same source)
            "symbols": [base] + SYMBOLS}


def _seed_store(path, with_old_rows=True):
    """Create a store schema and fill seconds rows: 10 fresh + 500 old."""
    store = AuctionFlowStore(str(path))
    store.mark_heartbeat()
    con = sqlite3.connect(str(path), timeout=10.0)
    now = int(time.time())
    rows = []
    for i in range(10):
        ts = now - i
        rows.append((ts, 1.0, 1.0, 1.0, 1.0, 1.0, 1, 0, 0, 0, 0.001, 0.001))
    if with_old_rows:
        for i in range(500):
            ts = now - 40 * 86400 - i  # 40 days old (retention is 7)
            rows.append((ts, 1.0, 1.0, 1.0, 1.0, 1.0, 1, 0, 0, 0, 0.001, 0.001))
    con.executemany(
        "INSERT INTO seconds(ts,open_mid,high_mid,low_mid,close_mid,sum_mid,"
        "tick_count,up_count,down_count,flat_count,sum_spread,max_spread) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", rows)
    con.commit()
    con.close()


def _prep_dir(tmp):
    """Module-level prep: config.json + storage dir. Used by both classes."""
    root = Path(tmp)
    (root / "storage").mkdir(parents=True, exist_ok=True)
    cfg = _config(root)
    (root / "config.json").write_text(json.dumps(cfg), encoding="utf-8")
    return root, cfg


class TestPruneAllStores(unittest.TestCase):
    def test_every_store_is_pruned_to_retention(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            root = Path(tmp)
            cfg = _config(root)
            paths = [root / "storage" / "auction_flow.sqlite3"]
            for sym in SYMBOLS:
                stem = sym.replace("/", "").lower()
                paths.append(root / "storage" /
                             "auction_flow_{0}.sqlite3".format(stem))
            for p in paths:
                _seed_store(p)
            report = prune_all_stores(root / "storage", cfg)
            self.assertEqual(len(report), len(paths))
            for path_str, e in report.items():
                self.assertEqual(e.get("stale_seconds_remaining"), 0,
                                 "{0}: {1}".format(path_str, e))
            # and the facts on disk agree: no row older than 7 days remains
            for p in paths:
                con = sqlite3.connect(str(p))
                oldest = con.execute("SELECT MIN(ts) FROM seconds").fetchone()[0]
                con.close()
                self.assertGreater(oldest, time.time() - 8 * 86400)

    def test_vacuum_is_gated_once_per_day(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            root = Path(tmp)
            cfg = _config(root)
            p = root / "storage" / "auction_flow.sqlite3"
            _seed_store(p)
            r1 = prune_all_stores(root / "storage", cfg)
            self.assertTrue(list(r1.values())[0]["vacuumed"])
            r2 = prune_all_stores(root / "storage", cfg)
            self.assertFalse(list(r2.values())[0]["vacuumed"])  # same day

    def test_missing_aux_stores_are_skipped_safely(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            root = Path(tmp)
            (root / "storage").mkdir(parents=True)
            cfg = _config(root)
            report = prune_all_stores(root / "storage", cfg)
            self.assertEqual(report, {})  # nothing exists yet, nothing raised


class TestR23_1Additions(unittest.TestCase):
    def _prep(self, tmp):
        return _prep_dir(tmp)

    def test_retention_edge_rows_are_edge_not_overdue(self):
        # minutes after a prune, rows written exactly 7 days ago trickle past
        # the boundary - a handful is healthy (EDGE), a flood is OVERDUE
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            root, cfg = self._prep(tmp)
            p = root / "storage" / "auction_flow.sqlite3"
            _seed_store(p, with_old_rows=False)
            con = sqlite3.connect(str(p))
            now = int(time.time())
            con.executemany(
                "INSERT INTO seconds(ts,open_mid,high_mid,low_mid,close_mid,"
                "sum_mid,tick_count,up_count,down_count,flat_count,sum_spread,"
                "max_spread) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                [(now - 7 * 86400 - i, 1.0, 1.0, 1.0, 1.0, 1.0, 1, 0, 0, 0,
                  0.001, 0.001) for i in range(5)])
            con.commit()
            con.close()
            rep = sma.inspect(root, cfg)
            status = list(rep["stores"].values())[0]["status"]
            self.assertTrue(status.startswith("EDGE"), status)
            self.assertEqual(rep["findings"], [])  # no wolf-crying

    def test_fix_removes_pytest_leftover_tree_and_stale_tmp_files(self):
        import shutil
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            root, cfg = self._prep(tmp)
            leftover = root / "storage" / "nabil_pytest_storage_abc123"
            (leftover / "backup_x").mkdir(parents=True)
            (leftover / "auction_flow.sqlite3").write_bytes(b"q" * 1024)
            tmp_new = root / "storage" / ".trades.json.fresh.tmp"
            tmp_old = root / "storage" / ".trades.json.crashed.tmp"
            tmp_new.write_bytes(b"n" * 10)
            tmp_old.write_bytes(b"o" * 2048)
            old_ts = time.time() - 2 * 86400
            os.utime(tmp_old, (old_ts, old_ts))
            sma._fix(root, cfg, log_max_mb=40)
            self.assertFalse(leftover.exists())
            self.assertTrue(tmp_new.exists())   # fresh write in progress
            self.assertFalse(tmp_old.exists())  # crashed write leftover

    def test_restart_script_rotates_logs_between_stop_and_start(self):
        src = (Path(ROOT) / "RESTART_ALL_SERVICES.ps1").read_text(encoding="utf-8")
        self.assertIn("rotating oversize logs", src)
        rot = src.find("Move-Item -Force")
        start = src.find("[4/5] Starting services")
        stop = src.find("Stopping old processes")
        self.assertGreater(rot, stop, "rotation must come AFTER the stop phase")
        self.assertLess(rot, start, "rotation must come BEFORE the start phase")


class TestAuditTool(unittest.TestCase):
    def _prep(self, tmp):
        return _prep_dir(tmp)

    def test_overdue_store_is_flagged_then_healthy_after_fix(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            root, cfg = self._prep(tmp)
            p = root / "storage" / "auction_flow_usdjpy.sqlite3"
            _seed_store(p, with_old_rows=False)
            con = sqlite3.connect(str(p))
            now = int(time.time())
            con.executemany(
                "INSERT INTO seconds(ts,open_mid,high_mid,low_mid,close_mid,"
                "sum_mid,tick_count,up_count,down_count,flat_count,sum_spread,"
                "max_spread) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                [(now - 40 * 86400 - i, 1.0, 1.0, 1.0, 1.0, 1.0, 1, 0, 0, 0,
                  0.001, 0.001) for i in range(60000)])
            con.commit()
            con.close()
            rep = sma.inspect(root, cfg)
            jpy_key = next(k for k in rep["stores"] if "usdjpy" in k)
            self.assertIn("PRUNE-OVERDUE", rep["stores"][jpy_key]["status"])
            sma._fix(root, cfg, log_max_mb=40)
            rep2 = sma.inspect(root, cfg)
            for e in rep2["stores"].values():
                self.assertEqual(e["status"], "OK")

    def test_measurement_trim_keeps_recent_drops_old(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            root, cfg = self._prep(tmp)
            meas = root / "storage" / "agent_measurements"
            meas.mkdir(parents=True)
            old = meas / "agent_system_2026-07-01.jsonl"
            new = meas / "agent_system_2026-08-27.jsonl"
            old.write_text("{}\n", encoding="utf-8")
            new.write_text("{}\n", encoding="utf-8")
            two_months_ago = time.time() - 60 * 86400
            os.utime(old, (two_months_ago, two_months_ago))
            sma._fix(root, cfg, log_max_mb=40)
            self.assertFalse(old.exists())
            self.assertTrue(new.exists())

    def test_oversize_log_rotates_one_generation(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            root, cfg = self._prep(tmp)
            logs = root / "logs"
            logs.mkdir(parents=True)
            big = logs / "tick_manager.log"
            big.write_text("x" * (2 * 1048576), encoding="utf-8")  # 2MB
            sma._fix(root, cfg, log_max_mb=1)  # 1MB threshold
            self.assertFalse(big.exists())
            self.assertTrue((logs / "tick_manager.log.1").exists())


if __name__ == "__main__":
    unittest.main()
