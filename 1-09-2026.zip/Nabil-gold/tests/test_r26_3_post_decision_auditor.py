# -*- coding: utf-8 -*-
"""R26.3: the post-decision auditor OBSERVES only (never blocks) and flags
admitted trades that violated a rule (macro coherence, stop band, R:R, path
mandates, ...)."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services.post_decision_auditor import audit_decision  # noqa: E402
from utils.helpers import load_config  # noqa: E402

CFG = {"discipline_gates": {"enabled": True, "macro_block_conf": 55.0}}
REAL_CFG = load_config()  # full instrument specs for $/point math


def _decision(**over):
    d = {"symbol": "XAU/USD", "decision": "BUY", "execution_path_id": "PATH_1_THREE_AGENT_CONSENSUS",
         "current_price": 4400.0,
         "signal": {"stop_loss": 4373.0, "tp1": 4427.0, "tp2": 4454.0,
                    "entry": {"price": 4400.0}, "lot": 0.10, "order_type": "BUY_LIMIT"}}
    d.update(over)
    return d


def _results(direction="SELL", conf=74.0, macro_dir=None):
    book = {"multitimeframe": {"direction": direction, "confidence": 92.0},
            "macro_fundamental": {"direction": macro_dir or direction, "confidence": conf}}
    return book


def test_clean_trade_has_no_warnings():
    # gold in-band 300-pt stop, tp1 ~0.9R / tp2 1.8R, aligned macro/MTF
    d = _decision(signal={"stop_loss": 4370.0, "tp1": 4427.0, "tp2": 4454.0,
                          "entry": {"price": 4400.0}, "lot": 0.10, "order_type": "BUY_LIMIT"})
    res = _results(direction="BUY", conf=60.0, macro_dir="BUY")
    verdict = audit_decision(d, REAL_CFG, res)
    assert verdict["warnings"] == 0, verdict["findings"]


def test_countertrend_gold_buy_is_flagged_but_not_raised():
    # exact live defect: BUY order, macro SELL 74, MTF SELL, CONTINUATION_BREAKDOWN
    d = _decision(setup_type="CONTINUATION_BREAKDOWN")
    verdict = audit_decision(d, CFG, _results("SELL", 74.0))
    codes = {f["code"] for f in verdict["findings"] if f["severity"] == "WARN"}
    assert "MACRO_OPPOSES" in codes
    assert "SETUP_DIRECTION_CONTRADICTION" in codes
    # auditor returns ok and never raises / returns a refusal
    assert verdict["ok"] is True


def test_path9_counter_macro_is_info_not_warning():
    d = _decision(execution_path_id="PATH_9_LIQUIDITY_SWEEP_REVERSAL")
    verdict = audit_decision(d, CFG, _results("SELL", 80.0))
    warn_codes = {f["code"] for f in verdict["findings"] if f["severity"] == "WARN"}
    assert "MACRO_OPPOSES" not in warn_codes


def test_out_of_band_stop_is_flagged():
    # XAU stop 1000 points, far wider than the 400 cap
    d = _decision(signal={"stop_loss": 4300.0, "tp1": 4490.0, "tp2": 4580.0,
                          "entry": {"price": 4400.0}, "lot": 0.02, "order_type": "BUY_LIMIT"})
    verdict = audit_decision(d, REAL_CFG, _results("BUY", 60.0, "BUY"))
    codes = {f["code"] for f in verdict["findings"] if f["severity"] == "WARN"}
    assert "STOP_OUT_OF_BAND" in codes


def test_missing_path_is_flagged():
    d = _decision(execution_path_id="")
    verdict = audit_decision(d, REAL_CFG, _results("BUY", 60.0, "BUY"))
    codes = {f["code"] for f in verdict["findings"] if f["severity"] == "WARN"}
    assert "PATH_MISSING" in codes


def test_auditor_never_raises_on_garbage():
    verdict = audit_decision({"decision": "WEIRD", "signal": "not-a-dict"}, None, None)  # type: ignore
    assert verdict["ok"] is True
    verdict2 = audit_decision(None, CFG, None)  # type: ignore
    assert verdict2["ok"] is True


def test_auction_in_book_but_not_supporter_is_not_flagged():
    # Regression: auction_flow being present in the book (normal evidence)
    # must NOT trigger AUCTION_AS_VOTER; only admission supporters count.
    d = _decision(execution_path_id="PATH_1_THREE_AGENT_CONSENSUS",
                  signal={"stop_loss": 4370.0, "tp1": 4427.0, "tp2": 4454.0,
                          "entry": {"price": 4400.0}, "lot": 0.10, "order_type": "BUY_LIMIT"})
    book = {"technical": {"direction": "BUY", "confidence": 80.0},
            "multitimeframe": {"direction": "BUY", "confidence": 78.0},
            "classical": {"direction": "BUY", "confidence": 76.0},
            "price_action": {"direction": "BUY", "confidence": 75.0},
            "macro_fundamental": {"direction": "BUY", "confidence": 60.0},
            "auction_flow": {"direction": "BUY", "confidence": 72.0, "weight": 0.0}}
    verdict = audit_decision(d, REAL_CFG, book)
    codes = {f["code"] for f in verdict["findings"] if f["severity"] == "WARN"}
    assert "AUCTION_AS_VOTER" not in codes, verdict["findings"]
