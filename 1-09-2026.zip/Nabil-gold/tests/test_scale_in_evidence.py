# -*- coding: utf-8 -*-
"""R25.14: the scale-in EVIDENCE law (operator 2026-08-28, "نفذ جولة الاثبات").

Every scale-in decision now writes a court-record row
(stage="scale_in") into storage/decision_audit naming its cause verbatim:

  - BLOCKED + the exact gate (distance short N pts < M, hard veto with
    every qualified opponent and its confidence, one-add-per-parent used,
    same-direction cap, post-loss cooldown, mechanical filters,
    entry_style/scale_in_enabled/news/max_scale_ins config gates)
  - ENTERED + the measured terms (pullback vs required, opponents < 2)

This is pure evidence: decisions themselves are UNCHANGED (the add law
stays exactly the 2026-08-18 consensus: distance >= trigger, better price
only, < 2 qualified opponents, one add per parent, the 2-open cap,
mechanical filters). These tests prove BOTH halves: the row always lands
with the right reason, and the trading behavior is byte-for-byte the same
law as before.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))


class _TG:
    def send_message(self, *a, **k):
        return True


def _run_scale_in(monkeypatch, db: _DB, results: dict, cfg: dict) -> None:
    """Call the REAL async entry point exactly like production does."""
    import asyncio
    import scripts.run_analysis as ra
    monkeypatch.setattr(ra, "database", db, raising=False)
    asyncio.run(ra._check_scale_in(cfg, results, db.open_trades, db, _TG(), demo_execution=True))


def _base_cfg(tmp_path: Path) -> dict:
    return {
        "order_execution": {
            "mode": "paper",
            "entry_style": "fixed_risk",
            "fixed_risk": {
                "scale_in_enabled": True,
                "scale_in_trigger_points": 120,
                "scale_in_max": 1,
                "scale_in_size_ratio": 0.5,
            },
        },
        "duplicate_signal_filter": {
            "open_trade": {"max_open_same_direction": 2},
            "cooldown": {"after_loss_minutes": 90},
        },
        "signal_requirements": {"agent_min_confidence": 65},
        "database": {"url": None, "key": None},
    }


class _DB:
    """Minimal store double: records audit rows + holds open trades."""

    def __init__(self, open_trades):
        self.open_trades = open_trades
        self.audit_rows = []

    def save_decision_audit(self, entry):
        self.audit_rows.append(entry)
        return "AUDIT_TEST"

    def get_recent_trades(self, limit=50):
        return []

    def new_trade_id(self):
        return "TRD_TEST_1"

    def save_trade(self, trade):
        pass


def _parent(side="SELL", entry=1.35504, sl=1.36000, tp1=1.35186, tp2=1.35000):
    # the manager reads direction from type/side/trade_type/decision
    # (_trade_direction) - mirror the live trade shape, not a wishful one.
    return {
        "id": "P1", "trade_id": "P1", "symbol": "GBP/USD",
        "type": side, "status": "OPEN", "entry_price": entry,
        "stop_loss": sl, "tp1": tp1, "tp2": tp2,
        "signal": {"direction": side},
    }


def _results(price: float, agents: dict | None = None) -> dict:
    """all_results double: price + symbol + agent book (defaults mirror the
    live GBP/USD book of 2026-08-28 15:18 UTC).

    The symbol MUST ride on the results (the manager reads
    all_results["symbol"] first) - without it the engine silently assumes
    gold and converts every distance in gold points (0.1/point)."""
    book = {
        "technical": {"direction": "SELL", "confidence": 82.8},
        "classical": {"direction": "SELL", "confidence": 72.2},
        "multitimeframe": {"direction": "SELL", "confidence": 57.0},
        "smc": {"direction": "SELL", "confidence": 59.5},
        "price_action": {"direction": "BUY", "confidence": 63.4},   # 1.6 under the bar
        "auction_flow": {"direction": "WAIT", "confidence": 57.9},
        "macro_fundamental": {"direction": "BUY", "confidence": 65.0},  # qualified opponent #1
        # resistance level for the SELL add's sizing path
        "classical_levels": {"resistance": [1.35750]},
    }
    if agents:
        book.update(agents)
    out = {"current_price": price, "symbol": "GBP/USD"}
    out.update(book)
    # classical section must carry both the vote AND the levels list
    out["classical"] = {**out["classical"], "resistance": [1.35750]}
    return out


def test_distance_short_writes_a_blocked_row_naming_the_gap(tmp_path, monkeypatch):
    """The operator's exact question: price moved but did NOT clear the
    trigger -> the row must name the measured distance vs required."""
    import scripts.run_analysis as ra
    db = _DB([_parent()])
    cfg = _base_cfg(tmp_path)
    rows = []
    captured = {}

    def fake_audit(cfg_, results_, open_trades):
        pass

    # drive the real function but capture audit rows through the DB double
    monkeypatch.setattr(ra, "database", db, raising=False)
    _run_scale_in(monkeypatch, db, _results(1.35590), cfg)  # 86 pts < 120
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    assert rows, "a scale-in decision must always leave a court row"
    row = rows[-1]
    assert row["outcome"] == "BLOCKED"
    assert row["symbol"] == "GBP/USD"
    assert "distance short" in row["reason"]
    assert "86" in row["reason"] and "120" in row["reason"]
    # NO trade was saved -> evidence changed nothing
    assert row.get("trade_id") == "P1"


def test_hard_veto_row_names_every_opponent_with_confidence(tmp_path, monkeypatch):
    """Two qualified opponents -> BLOCKED row lists each with its score."""
    import scripts.run_analysis as ra
    db = _DB([_parent()])
    cfg = _base_cfg(tmp_path)
    monkeypatch.setattr(ra, "database", db, raising=False)
    results = _results(1.35750, {  # 246 pts above entry: distance PASSES
        "price_action": {"direction": "BUY", "confidence": 68.0},  # opponent #2
    })
    _run_scale_in(monkeypatch, db, results, cfg)
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    assert rows and rows[-1]["outcome"] == "BLOCKED"
    reason = rows[-1]["reason"]
    assert "hard veto" in reason
    assert "macro_fundamental@65" in reason
    assert "price_action@68" in reason


def test_entered_row_is_written_with_the_terms(tmp_path, monkeypatch):
    """Success must never be silent: the ENTERED row carries pullback and
    the opposition count."""
    import scripts.run_analysis as ra
    db = _DB([_parent()])
    cfg = _base_cfg(tmp_path)
    monkeypatch.setattr(ra, "database", db, raising=False)
    # 150 pts above entry (>= 120), only macro opposes -> under the veto
    results = _results(1.35654)
    _run_scale_in(monkeypatch, db, results, cfg)
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    assert rows and rows[-1]["outcome"] == "ENTERED", rows
    reason = rows[-1]["reason"]
    assert "150 pts >= 120" in reason
    assert "1 qualified opponent(s) < 2" in reason


def test_one_add_per_parent_row_and_no_second_add(tmp_path, monkeypatch):
    import scripts.run_analysis as ra
    parent = _parent()
    db = _DB([parent, {
        "id": "ADD1", "trade_id": "ADD1", "symbol": "GBP/USD",
        "type": "SELL", "status": "OPEN", "entry_price": 1.35654,
        "stop_loss": 1.36000, "tp1": 1.35186, "tp2": 1.35000,
        "signal": {"direction": "SELL", "scale_in": True, "parent_trade_id": "P1"},
    }])
    cfg = _base_cfg(tmp_path)
    monkeypatch.setattr(ra, "database", db, raising=False)
    _run_scale_in(monkeypatch, db, _results(1.35750), cfg)
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    # BOTH refusals must be on the record, each naming its own gate: the
    # parent's add-seat is used, AND the add itself can never parent.
    reasons = [str(r.get("reason") or "") for r in rows if r.get("outcome") == "BLOCKED"]
    assert any("one add per parent" in r for r in reasons), reasons
    assert any("parent is itself a scale-in" in r for r in reasons), reasons
    assert not any(r.get("outcome") == "ENTERED" for r in rows)


def test_no_evidence_row_without_open_parents(tmp_path, monkeypatch):
    """No open trades -> the function exits before any decision: no row,
    and that is correct (nothing was judged)."""
    import scripts.run_analysis as ra
    db = _DB([])
    cfg = _base_cfg(tmp_path)
    monkeypatch.setattr(ra, "database", db, raising=False)
    _run_scale_in(monkeypatch, db, _results(1.35750), cfg)
    assert db.audit_rows == []


def test_disabled_scale_in_writes_its_config_gate_row(tmp_path, monkeypatch):
    import scripts.run_analysis as ra
    db = _DB([_parent()])
    cfg = _base_cfg(tmp_path)
    cfg["order_execution"]["fixed_risk"]["scale_in_enabled"] = False
    monkeypatch.setattr(ra, "database", db, raising=False)
    _run_scale_in(monkeypatch, db, _results(1.35750), cfg)
    rows = [r for r in db.audit_rows if r.get("stage") == "scale_in"]
    assert rows and rows[-1]["outcome"] == "BLOCKED"
    assert "scale_in_enabled=false" in rows[-1]["reason"]
