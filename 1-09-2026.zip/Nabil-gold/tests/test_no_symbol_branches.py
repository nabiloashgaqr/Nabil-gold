# -*- coding: utf-8 -*-
"""R25.12: the symbol-branch ratchet (freeze, then shrink).

Today production code hard-codes symbol literals in 236 places
(services/agents/utils): ``if "XAU/USD"`` style branches - a duplicated
law per pair. The single accessor is services/symbol_law.py and the store
is config.json.

THIS TEST FREEZES THE COUNT: any new hard-coded symbol literal in
production code FAILS the suite. Refactors that remove branches lower the
baseline below (a ratchet: it can only go down). The long-term target is
zero; each removal is an owner-by-owner refactor behind the full suite.
"""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

#: Frozen at R25.12 build time (2026-08-28). LOWER it when you remove
#: branches - never raise it.
BASELINE = {
    "XAU/USD": 137,
    "WTI/USD": 26,
    "EUR/USD": 16,
    "GBP/USD": 14,
    "USD/CAD": 29,
    "USD/JPY": 34,
}

#: Production code only (reports/scripts may quote symbols in output text).
SCAN_DIRS = ("services", "agents", "utils")


def _counts() -> dict:
    counts = {s: 0 for s in BASELINE}
    for d in SCAN_DIRS:
        for path in (ROOT / d).rglob("*.py"):
            if "__pycache__" in path.parts or ".bak" in path.name:
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
            for sym in BASELINE:
                counts[sym] += text.count(sym)
    return counts


def test_no_new_hard_coded_symbol_branches():
    now = _counts()
    grown = {s: (BASELINE[s], now[s]) for s in BASELINE if now[s] > BASELINE[s]}
    assert not grown, (
        "new hard-coded symbol literals in production code - ask "
        "services/symbol_law.py instead (symbol: baseline->now): %s" % grown)


def test_symbol_law_accessor_reads_the_config_store():
    from services.symbol_law import all_symbols, category_of, is_gold, macro_symbols
    assert set(all_symbols()) == set(BASELINE)
    assert is_gold("XAU/USD") and not is_gold("EUR/USD")
    assert category_of("XAU/USD") == "metal"
    assert category_of("WTI/USD") == "oil"
    assert category_of("EUR/USD") == "forex"
    assert category_of("NOPE/XYZ") == ""
    # the macro list comes from config, verbatim
    assert macro_symbols() == ["XAU/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"]
