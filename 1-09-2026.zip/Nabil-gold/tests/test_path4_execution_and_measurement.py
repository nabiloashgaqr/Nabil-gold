from __future__ import annotations

from copy import deepcopy

import pytest

from services.execution_paths import (
    PATH_1, PATH_2, PATH_3, PATH_4,
    path_header, resolve_execution_path, stamp_execution_path,
)
from services.path_performance import PathPerformanceTracker, summarize_paths
from services.session_planner import SessionPlannerService
from services.telegram_bot import TelegramService
from services.thesis_consensus import evaluate_directional_admission, path4_candidate_matches
from scripts.run_analysis import _build_plan_ladder_decision, validate_signal_before_send


CONFIG = {
    "agent_weights": {
        "technical": 0.20,
        "multitimeframe": 0.15,
        "classical": 0.25,
        "smc": 0.20,
        "price_action": 0.20,
    },
    "signal_requirements": {
        "agent_min_confidence": 67,
        "min_agents_agree": 3,
        "min_consensus_confidence": 72,
        "two_agent_entry": {
            "enabled": True,
            "min_agents_agree": 2,
            "min_consensus_confidence": 72,
            "macro_confirmation": {"enabled": True, "min_confidence": 55},
            "gemini_confirmation": {"enabled": True, "min_confidence": 70},
        },
        "path4_smc_map_auction": {
            "enabled": True,
            "min_map_quality": 60,
            "min_return_probability": 55,
            "min_dominance": 70,
            "min_trigger_score": 70,
            "min_structure_quality": "MODERATE",
            "min_auction_confidence": 72,
            "max_qualified_opposition": 0,
        },
    },
    "risk_settings": {"min_rr_ratio": 1.5, "min_tp1_rr": 0.8},
    "trade_management": {
        "auto_move_sl_to_entry_after_tp1": True,
        "min_breakeven_rr": 0.5,
    },
}


def _map(**changes) -> dict:
    base = {
        "id": "SMC::PATH4::PRIMARY",
        "state_key": "SMC_STATE::PATH4::PRIMARY",
        "selection_role": "PRIMARY",
        "direction": "SELL",
        "quality_score": 63.0,
        "return_probability_score": 70.2,
        "thesis_dominance_score": 77.1,
        "trigger_score": 76.0,
        "trigger_ready": True,
        "entry_price": 4401.19,
        "poi_zone": {"bottom": 4397.68, "top": 4404.71},
        "details": {"structure_quality": "STRONG"},
    }
    base.update(changes)
    return base


def _book(**map_changes) -> dict:
    return {
        "technical": {"signal": "WAIT", "confidence": 51.0},
        "multitimeframe": {"signal": "WAIT", "confidence": 52.0},
        "classical": {"signal": "WAIT", "confidence": 55.0},
        "smc": {
            "signal": "WAIT",
            "confidence": 52.0,
            "market_structure": {"structure_quality": "STRONG"},
            "setup_structure": _map(**map_changes),
        },
        "price_action": {"signal": "WAIT", "confidence": 50.0},
        "auction_flow": {"signal": "SELL", "confidence": 80.0},
    }


def test_path4_admits_map_plus_auction_without_faking_smc_vote() -> None:
    result = evaluate_directional_admission("SELL", _book(), CONFIG)

    assert result["allow"] is True
    assert result["path"] == "SMC_MAP_AUCTION_CONFIRMATION"
    # Auction Flow is standalone since 2026-08-14: it confirms the map but
    # never appears in the core vote book.
    assert result["supporters"] == []
    assert result["support_count"] == 0
    assert result["smc_map_counted_as_vote"] is False
    assert result["smc_dominance"] == 77.1
    assert result["auction_confidence"] == 80.0
    assert result["order_policy"] == "LIMIT_ONLY_AT_SMC_POI"
    assert path4_candidate_matches(result, _book()["smc"]["setup_structure"])


@pytest.mark.parametrize(
    ("map_change", "auction_change"),
    [
        ({"quality_score": 59.9}, {}),
        ({"return_probability_score": 54.9}, {}),
        ({"thesis_dominance_score": 69.9}, {}),
        ({"trigger_score": 69.9}, {}),
        ({"trigger_ready": False}, {}),
        ({"details": {"structure_quality": "WEAK"}}, {}),
        ({}, {"confidence": 71.9}),
        ({}, {"signal": "BUY"}),
    ],
)
def test_path4_fails_closed_when_any_approved_floor_is_missing(
    map_change: dict, auction_change: dict,
) -> None:
    book = _book(**map_change)
    book["auction_flow"].update(auction_change)
    result = evaluate_directional_admission("SELL", book, CONFIG)
    assert result["allow"] is False
    assert result.get("path") is None


def test_path4_is_not_a_market_thesis_exit_vote() -> None:
    # A conditional future LIMIT map must not close/defend a live position at
    # market before the POI order can be placed. Paths 1-3 still use this same
    # evaluator for Entry/Thesis parity.
    result = evaluate_directional_admission("SELL", _book(), CONFIG, allow_path4=False)
    assert result["allow"] is False
    assert result.get("path") is None


def test_any_qualified_core_opposition_blocks_path4() -> None:
    book = _book()
    book["price_action"] = {"signal": "BUY", "confidence": 67.0}
    result = evaluate_directional_admission("SELL", book, CONFIG)
    assert result["allow"] is False
    assert result["opponents"] == ["price_action"]


def test_existing_routes_keep_priority_over_path4() -> None:
    book = _book()
    book["technical"] = {"signal": "SELL", "confidence": 80.0}
    book["multitimeframe"] = {"signal": "SELL", "confidence": 80.0}
    book["classical"] = {"signal": "SELL", "confidence": 80.0}
    # Three qualified Core supporters = Path 1 (auction never counts).
    result = evaluate_directional_admission("SELL", book, CONFIG)
    assert result["path"] == "THREE_AGENT_CONSENSUS"


def test_planner_structural_floor_accepts_path4_without_counting_map_as_vote() -> None:
    config = deepcopy(CONFIG)
    config["session_planner"] = {
        "min_supporting_agents_for_ready": 2,
        "agent_alignment_min_confidence": 67,
        "min_zone_width_points": 0,
        "max_primary_zone_width_points": 450,
        "max_standby_zone_width_points": 450,
    }
    primary = _map(
        stop_loss=4441.19, target_price=4335.0, target_liquidity=4335.0,
        details={
            "structure_quality": "STRONG",
            "liquidity": {"sell_side": [4369.0, 4335.0], "buy_side": [4441.19]},
        },
    )
    book = _book()
    book["smc"]["setup_structure"] = primary
    ok, reason, diagnostics = SessionPlannerService(config)._plan_quality_guard(
        direction="SELL", primary=primary, standby=None,
        primary_execution={"rr_ratio": 1.8}, all_results=book, symbol="XAU/USD",
    )
    assert ok is True, reason
    assert diagnostics["support_count"] == 0
    assert diagnostics["path4_map_counted_as_vote"] is False
    assert diagnostics["path4_map_auction_admission"]["path"] == "SMC_MAP_AUCTION_CONFIRMATION"


def test_path4_builder_creates_limit_only_and_refuses_zone_chasing() -> None:
    config = deepcopy(CONFIG)
    config["order_execution"] = {"entry_style": "hybrid", "market_threshold_points": 80}
    candidate = {
        **_map(),
        "stop_loss": 4441.19,
        "target_price": 4335.0,
        "target_liquidity": 4335.0,
        "quality_grade": "C",
        "details": {
            "structure_quality": "STRONG",
            "liquidity": {"sell_side": [4369.0, 4335.0], "buy_side": [4441.19]},
        },
    }
    plan = {
        "session_bias": "SELL", "symbol": "XAU/USD", "scenario_type": "PATH4",
        "scenario_id": "PATH4::TEST", "primary_poi": candidate,
    }
    pending = _build_plan_ladder_decision(
        {"current_price": 4380.0}, plan, candidate, config, limit_only=True,
    )
    assert pending is not None
    assert pending["signal"]["order_type"] == "SELL_LIMIT"
    assert pending["signal"]["entry"]["price"] == 4401.19
    assert pending["entry_mode"] == "path4_smc_map_auction_limit"

    # Once price is close enough that normal planner logic would promote to
    # MARKET, Path 4 returns no order instead of chasing.
    chased = _build_plan_ladder_decision(
        {"current_price": 4400.0}, plan, candidate, config, limit_only=True,
    )
    assert chased is None


def test_path4_final_validator_forbids_market_and_wrong_poi() -> None:
    decision = {
        "decision": "SELL",
        "symbol": "XAU/USD",
        "current_price": 4390.0,
        "execution_path_id": PATH_4,
        "planner_execution_gate": {"smc_map_entry_price": 4401.19},
        "signal": {
            "entry": {"price": 4390.0, "kind": "MARKET", "order_type": "SELL_MARKET"},
            "entry_kind": "MARKET",
            "order_type": "SELL_MARKET",
            "stop_loss": 4430.0,
            "tp1": 4358.0,
            "tp2": 4330.0,
        },
    }
    violations = validate_signal_before_send(decision, CONFIG)
    assert any("LIMIT only" in item for item in violations)
    assert any("differs from admitted SMC POI" in item for item in violations)


def test_all_four_path_names_resolve_and_render_on_first_line() -> None:
    cases = [
        ("THREE_AGENT_CONSENSUS", PATH_1, "PATH 1"),
        ("TWO_AGENT_MACRO", PATH_2, "PATH 2"),
        ("TWO_AGENT_GEMINI", PATH_3, "PATH 3"),
        ("SMC_MAP_AUCTION_CONFIRMATION", PATH_4, "PATH 4"),
    ]
    for admission, expected_id, label in cases:
        decision: dict = {}
        stamp_execution_path(decision, admission)
        assert resolve_execution_path(decision)["id"] == expected_id
        assert path_header(decision).startswith("🛣️")
        assert label in path_header(decision)


def test_signal_and_trade_event_cards_put_path_on_top(monkeypatch) -> None:
    sent: list[str] = []
    service = TelegramService({})
    monkeypatch.setattr(service, "send_message", lambda text, **kwargs: sent.append(text) or True)
    decision = {
        "decision": "SELL", "symbol": "XAU/USD", "current_price": 4390.0,
        "confidence": 80, "entry_mode": "path4_smc_map_auction_limit",
        "session_plan": {"plan_ready": True},
        "signal": {
            "entry": {"price": 4401.19, "kind": "LIMIT"},
            "entry_kind": "LIMIT", "order_type": "SELL_LIMIT",
            "stop_loss": 4441.19, "tp1": 4369.19, "tp2": 4341.19,
            "tp1_rr": 0.8, "tp2_rr": 1.5,
        },
    }
    stamp_execution_path(decision, "SMC_MAP_AUCTION_CONFIRMATION")
    assert service.send_signal(decision)
    assert sent[-1].splitlines()[0].startswith("🛣️ <b>PATH 4")

    trade = {
        "id": "T1", "type": "SELL", "symbol": "XAU/USD", "status": "OPEN",
        "entry_price": 4401.19, "signal_snapshot": deepcopy(decision),
    }
    evaluation = {"old_status": "OPEN", "new_status": "OPEN", "updates": {"stop_loss": 4401.19}}
    assert service.send_trade_events(trade, ["MOVE_SL_TO_BE"], 4380.0, 211.9, evaluation)
    assert sent[-1].splitlines()[0].startswith("🛣️ <b>PATH 4")


def test_path_tracker_persists_lifecycle_without_touching_rules(tmp_path) -> None:
    snapshot: dict = {"decision": "SELL"}
    stamp_execution_path(snapshot, "SMC_MAP_AUCTION_CONFIRMATION")
    tracker = PathPerformanceTracker(tmp_path / "path_trades.json")
    tracker.record_trade({
        "id": "PATH4_TRACKED", "type": "SELL", "status": "PENDING",
        "entry_price": 4401.19, "stop_loss": 4441.19,
        "signal_snapshot": snapshot,
    })
    tracker.record_update("PATH4_TRACKED", {
        "status": "TP2_HIT", "mt5_ticket": 12345,
        "partial_close": True, "pnl_points": 320.0,
    })
    rows = tracker.rows()
    assert len(rows) == 1
    assert rows[0]["execution_path_id"] == PATH_4
    assert rows[0]["status"] == "TP2_HIT"
    assert rows[0]["pnl_points"] == 320.0
    assert summarize_paths(rows)["paths"][3]["success_rate_pct"] == 100.0


def test_path_performance_summary_keeps_paths_separate() -> None:
    rows = []
    for index, admission in enumerate((
        "THREE_AGENT_CONSENSUS", "TWO_AGENT_MACRO",
        "TWO_AGENT_GEMINI", "SMC_MAP_AUCTION_CONFIRMATION",
        "TWO_AGENT_AUCTION", "TWO_AGENT_OTE", "R25_SCALP_FADE",
        "REINFORCEMENT_ADDON", "LIQUIDITY_SWEEP_REVERSAL",
    ), start=1):
        snapshot: dict = {}
        stamp_execution_path(snapshot, admission)
        rows.append({
            "id": f"T{index}", "status": "TP2_HIT", "pnl_points": 100 * index,
            "partial_close": True, "mt5_ticket": index,
            "signal_snapshot": snapshot,
        })
    summary = summarize_paths(rows)
    # BUILD 31 R4 (operator order "احذف المسار 0 بالكامل"): the path-0
    # label is gone from the registry; rows stamped with it resolve to
    # PATH 6 (never hidden). R25.1 (operator 2026-08-28): PATH 7 -
    # SCALP PREMIUM FADE joins the registry, so exactly SEVEN paths,
    # each as its own separate sample.
    # R25.1: PATH 7 (SCALP). R25.6: PATH 8 (REINFORCEMENT ADD-ON). R25.8:
    # PATH 9 is reborn as LIQUIDITY SWEEP REVERSAL; the retired FX-4
    # STRONG_STRUCTURE_CONFIRMED survives as a separate LEGACY history bucket.
    assert len(summary["paths"]) == 10
    by_admission = {row["admission_path"]: row for row in summary["paths"]}
    assert set(by_admission) == {
        "THREE_AGENT_CONSENSUS", "TWO_AGENT_MACRO", "TWO_AGENT_GEMINI",
        "SMC_MAP_AUCTION_CONFIRMATION", "TWO_AGENT_AUCTION",
        "TWO_AGENT_OTE", "R25_SCALP_FADE", "REINFORCEMENT_ADDON",
        "LIQUIDITY_SWEEP_REVERSAL", "STRONG_STRUCTURE_CONFIRMED",
    }
    # The nine active paths each carry exactly one sample; the retired FX-4
    # legacy bucket carries none (nothing stamps it any more) but still reports.
    for admission, row in by_admission.items():
        if admission == "STRONG_STRUCTURE_CONFIRMED":
            assert row["trades_recorded"] == 0
            continue
        assert row["trades_recorded"] == 1
        assert row["success_rate_pct"] == 100.0
    # legacy id rows land in the PATH 6 bucket, not in an unknown bucket
    legacy_row = {"id": "T9", "status": "TP2_HIT", "pnl_points": 50.0,
                  "execution_path_id": "PATH_PREARM_OTE",
                  "signal_snapshot": {}}
    summary2 = summarize_paths([legacy_row])
    p6_row = [r for r in summary2["paths"] if r["admission_path"] == "TWO_AGENT_OTE"][0]
    assert p6_row["trades_recorded"] == 1
    assert summary["minimum_sample_for_comparison"] == 20
    assert all(row["sample_ready"] is False for row in summary["paths"])
