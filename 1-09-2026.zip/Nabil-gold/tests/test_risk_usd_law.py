# -*- coding: utf-8 -*-
"""R25.15: the DOLLAR risk law (operator 2026-08-28) + the lot solver.

Operator's principle, verbatim: "ذهب: ستوب 400 نقطة على 0.1 لوت = $400"
- risk is measured in DOLLARS, not points. The point value per 0.1 lot
differs per pair ($1.00 gold/oil, $0.10 EUR/GBP, $0.072 CAD, $0.062 JPY),
so the SAME 400-point stop is $400 on gold but $20 on EUR/USD. The fix:
the STOP stays structural (per-pair liquidity law, gold candle band
[270, 400]); the LOT is the derived variable, solved so the full-stop
loss lands inside the operator's band [$270, $400] per the pair's
liquidity (default target $270; the $400 cap is the ceiling).

One test scenario covers all five non-gold pairs + gold (the operator:
"علي كل الازواج الخمسة اختبار يكفي واحد") - one scenario, every pair.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.risk_usd import lot_for_stop, usd_loss, usd_pnl  # noqa: E402

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))

CONTRACT = {"XAU/USD": 100, "WTI/USD": 1000, "EUR/USD": 100000,
            "GBP/USD": 100000, "USD/CAD": 100000, "USD/JPY": 100000}
PX = {"XAU/USD": 4476.14, "WTI/USD": 82.65, "EUR/USD": 1.15883,
      "GBP/USD": 1.33398, "USD/CAD": 1.39022, "USD/JPY": 160.153}
QUOTE = {"USD/CAD": 1.39022, "USD/JPY": 160.153}

# (symbol, structural stop pts) - gold at both ends of its candle band,
# the other five across their R25.7-D liquidity band [230, 330]. ONE
# scenario, all pairs, both band edges.
SCENARIO = [
    ("XAU/USD", 400), ("XAU/USD", 270),
    ("WTI/USD", 230), ("WTI/USD", 330),
    ("EUR/USD", 230), ("EUR/USD", 330),
    ("GBP/USD", 230), ("GBP/USD", 330),
    ("USD/CAD", 230), ("USD/CAD", 330),
    ("USD/JPY", 230), ("USD/JPY", 330),
]


def _v01(sym: str) -> float:
    """$ per point per 0.1 lot."""
    c = CONTRACT[sym]
    pt = next(i for i in CONFIG["instruments"] if i["symbol"] == sym)["point_size"]
    return 0.1 * c * pt / QUOTE.get(sym, 1)


@pytest.mark.parametrize("sym,stop", SCENARIO)
def test_full_stop_loss_lands_inside_the_operator_band(sym, stop):
    lot = lot_for_stop(sym, stop, CONFIG)
    loss = usd_loss(sym, stop, lot)
    assert 270.0 - 1e-6 <= loss <= 400.0 + 1e-6, (
        "%s stop %d: lot %.2f gives $%.2f - outside [$270,$400]" % (sym, stop, lot, loss))


@pytest.mark.parametrize("sym,stop", SCENARIO)
def test_lot_respects_the_broker_volume_step(sym, stop):
    lot = lot_for_stop(sym, stop, CONFIG)
    assert lot >= 0.01
    assert abs(lot / 0.01 - round(lot / 0.01)) < 1e-6, "lot must snap to 0.01 steps"


def test_gold_keeps_the_operators_reference_lot_at_the_400_candle():
    # the operator's anchor: gold 400-pt stop on 0.10 = $400 (the band CAP)
    assert lot_for_stop("XAU/USD", 400, CONFIG, risk_usd=400.0) == pytest.approx(0.10, abs=0.005)
    # default band target $270 -> smaller lot, still inside the band
    lot = lot_for_stop("XAU/USD", 400, CONFIG)
    assert lot == pytest.approx(0.07, abs=0.005)
    assert 270.0 <= usd_loss("XAU/USD", 400, lot) <= 400.0
    # tighter candle stop (270) grows the lot, loss stays in the band
    lot270 = lot_for_stop("XAU/USD", 270, CONFIG)
    assert 270.0 <= usd_loss("XAU/USD", 270, lot270) <= 400.0


def test_pnl_usd_reads_the_direction_the_right_way():
    # GBP 1.0 lot, +120 points (0.0012) => +$120 (point value $1.00/lot)
    assert usd_pnl("GBP/USD", 1.0, entry=1.33398, now=1.33518, dirn="BUY") == pytest.approx(120.0)
    # the same move against a SELL is a loss
    assert usd_pnl("GBP/USD", 1.0, entry=1.33398, now=1.33518, dirn="SELL") == pytest.approx(-120.0)
    # gold: 40 pts on 0.1 lot = $40 (the operator's $1/point reference)
    assert usd_pnl("XAU/USD", 0.1, entry=4476.14, now=4480.14, dirn="BUY") == pytest.approx(40.0)


def test_margin_planning_leverage_option_is_honoured():
    # the operator's question: "اجعل الرافعة 1:100 كخيار" - the planner must
    # expose the lever and compute the expected margin with it.
    from services.risk_usd import expected_margin
    m1000 = expected_margin("GBP/USD", 1.60, px=PX["GBP/USD"], leverage=1000)
    m100 = expected_margin("GBP/USD", 1.60, px=PX["GBP/USD"], leverage=100)
    assert m1000 == pytest.approx(1.60 * 100000 * PX["GBP/USD"] / 1000)
    assert m100 == m1000 * 10
