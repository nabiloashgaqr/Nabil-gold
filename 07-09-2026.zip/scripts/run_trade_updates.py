"""سكريبت تحديث الصفقات المفتوحة.

يعمل كل 5 دقائق عبر GitHub Actions. يجلب السعر الحالي، يمرر الصفقات المفتوحة
إلى OpenTradesManager، ثم يتم تحديث Supabase وإرسال تحديثات Telegram.
أحداث نقل الستوب / trailing / TP / SL تُرسل فوراً عند تشغيل هذا السكريبت ولا
تنتظر رسالة الـ heartbeat/الساعة.
✏️ يتحقق من ساعات التداول ويخرج إذا كان خارج الجلسات إلا إذا كان التحديث خارج
الساعات مفعلاً في config.
"""

from __future__ import annotations

# --- VPS: load .env if present (real env vars ALWAYS win over .env) ---
try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv()  # override=False: task-wrapper vars take precedence
except Exception:
    pass

import logging
import os
import sys
from datetime import datetime, timezone

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.news_risk_agent import NewsRiskAgent
from agents.open_trades_manager import OpenTradesManager
from agents.trading_session_agent import TradingSessionAgent
from services.database import DatabaseService
from services.market_data import MarketDataService
from services.telegram_bot import TelegramService
from utils.helpers import calculate_pips, load_config, setup_logging
from utils.instruments import config_for_instrument, normalize_symbol, price_sanity_range, format_price

setup_logging()
logger = logging.getLogger(__name__)


def _payload_supports_signal_generation(payload) -> bool:
    if not payload:
        return False
    if isinstance(payload, dict) and payload.get("supports_signal_generation") is not None:
        return bool(payload.get("supports_signal_generation"))
    return str((payload or {}).get("source") or "") == "twelvedata"


def _payload_supports_pending_activation(payload) -> bool:
    if not payload:
        return False
    if isinstance(payload, dict) and payload.get("supports_pending_activation") is not None:
        return bool(payload.get("supports_pending_activation"))
    return str((payload or {}).get("source") or "") == "twelvedata"


def _short_id(trade_id: str) -> str:
    """Compact, readable trade id: keep the date + last hex chunk.

    TRADE_20260623_120035_726925_7cf3f415 -> #7cf3f415
    Falls back to the last 8 chars if the format differs.
    """
    s = str(trade_id or "")
    if not s:
        return "#?"
    parts = s.split("_")
    last = parts[-1]
    if len(parts) > 1 and len(last) >= 4:
        return f"#{last}"
    # Single chunk (or too-short tail): use the last 8 characters.
    return f"#{s[-8:]}"


def _build_status_message(open_trades, evaluations, current_price: float,
                          config: dict | None = None,
                          symbol_prices: dict | None = None) -> str:
    """Build a SHORT hourly status with live trades separated from pending orders.

    BUILD 22.2: USD conversion uses each ROW's point value (oil $0.01 vs
    gold $0.10) instead of the hardcoded gold /10.
    BUILD 31 (2026-08-24): each trade is priced with ITS OWN symbol's price
    (symbol_prices) - the old single current_price was the last symbol
    processed in the loop, so a two-symbol book could print oil's price on a
    gold line (same leak family as the tick-manager card incident)."""
    import html as _html

    symbol_prices = symbol_prices or {}
    _px_cache: dict = {}

    def _px_for(trade: dict) -> float:
        sym = normalize_symbol(trade.get("symbol") or "XAU/USD")
        if sym not in _px_cache:
            v = symbol_prices.get(sym, 0.0)
            try:
                v = float(v)
            except (TypeError, ValueError):
                v = 0.0
            _px_cache[sym] = v if v > 0 else current_price
        return _px_cache[sym]

    def _price_headline() -> str:
        seen = []
        for t in open_trades:
            sym = normalize_symbol(t.get("symbol") or "XAU/USD")
            if sym in symbol_prices:
                seen.append(sym)
        if len(set(seen)) <= 1:
            return f"Price {format_price(current_price, (config or {}).get('symbol') or 'XAU/USD', config or {})}"
        parts = []
        for sym in dict.fromkeys(seen):
            parts.append(f"{sym.split('/')[0]} {format_price(float(symbol_prices[sym]), sym, config or {})}")
        return " · ".join(parts)

    now_txt = datetime.now(timezone.utc).strftime("%H:%M UTC")
    if not open_trades:
        return (
            "🔄 <b>Trade Update</b> · " + now_txt + "\n"
            f"Price {format_price(current_price, (config or {}).get('symbol') or 'XAU/USD', config or {})}\n"
            "📭 No open trades."
        )

    by_id = {str(ev.get("trade_id")): ev for ev in (evaluations or [])}
    live_statuses = {"OPEN", "PARTIAL", "TP1_HIT"}
    pending_statuses = {"PENDING"}
    live_trades = [t for t in open_trades if str(t.get("status") or "OPEN").upper() in live_statuses]
    pending_trades = [t for t in open_trades if str(t.get("status") or "").upper() in pending_statuses]

    headline_parts = []
    if live_trades:
        headline_parts.append(f"{len(live_trades)} open")
    if pending_trades:
        headline_parts.append(f"{len(pending_trades)} pending")
    lines = [
        f"🔄 <b>Trade Update</b> · {now_txt}",
        f"{_price_headline()} · {' / '.join(headline_parts) if headline_parts else '0 active'}",
        "───────────────",
    ]

    from utils.instruments import point_size
    net_points = 0.0
    net_usd_sum = 0.0
    for t in live_trades[:20]:
        tid = str(t.get("id", ""))
        ev = by_id.get(tid, {})
        direction = str(t.get("type") or t.get("side") or "BUY").upper()
        pnl = float(ev.get("pnl_points", 0) or 0)
        net_points += pnl
        row_pv = point_size(str(t.get("symbol") or "XAU/USD"), config or {})
        usd = pnl * row_pv
        net_usd_sum += usd
        sign = "🟢" if pnl > 0 else "🔴" if pnl < 0 else "➖"
        prog = ev.get("progress_to_tp1")
        prog_txt = ""
        if prog is not None:
            try:
                prog_txt = f" · {float(prog) * 100:.0f}%➜TP1"
            except (TypeError, ValueError):
                prog_txt = ""
        status = str(ev.get("new_status") or t.get("status") or "OPEN")
        status_txt = "" if status == "OPEN" else f" [{_html.escape(status)}]"
        lines.append(
            f"{sign} {direction:<4} <code>{_short_id(tid)}</code>  "
            f"{pnl:+.0f} pts ({usd:+.1f}$){prog_txt}{status_txt}"
        )
    if len(live_trades) > 20:
        lines.append(f"… and {len(live_trades) - 20} more")
    if live_trades:
        net_emoji = "🟢" if net_points > 0 else "🔴" if net_points < 0 else "➖"
        lines.append("───────────────")
        lines.append(f"{net_emoji} <b>Net:</b> {net_points:+.0f} pts ({net_usd_sum:+.1f}$)")

    if pending_trades:
        if live_trades:
            lines.append("───────────────")
        lines.append(f"⏳ <b>Pending Orders ({len(pending_trades)})</b>")
        for t in pending_trades[:20]:
            tid = str(t.get("id", ""))
            ev = by_id.get(tid, {})
            direction = str(t.get("type") or t.get("side") or "BUY").upper()
            entry = float(t.get("entry_price") or 0)
            order_type = str(t.get("order_type") or t.get("order_kind") or "PENDING").upper()
            pts_to_fill = ev.get("pending_distance_points")
            if pts_to_fill is None:
                pts_to_fill = abs(calculate_pips(_px_for(t), entry, trade_type=direction, symbol=str(t.get("symbol") or "XAU/USD")))
            hours_open = ev.get("hours_open")
            if hours_open is None:
                try:
                    opened = datetime.fromisoformat(str(t.get("entry_time") or t.get("created_at") or "").replace("Z", "+00:00"))
                    if opened.tzinfo is None:
                        opened = opened.replace(tzinfo=timezone.utc)
                    hours_open = max(0.0, (datetime.now(timezone.utc) - opened.astimezone(timezone.utc)).total_seconds() / 3600.0)
                except Exception:
                    hours_open = None
            age_txt = f"waiting {float(hours_open):.1f}h" if hours_open is not None else "waiting"
            lines.append(f"🟡 {direction:<4} <code>{_short_id(tid)}</code>  @ {format_price(entry, str(t.get('symbol') or 'XAU/USD'), config or {})} [{_html.escape(order_type)}] · {float(pts_to_fill):.0f} pts to fill · {age_txt}")
        if len(pending_trades) > 20:
            lines.append(f"… and {len(pending_trades) - 20} more")
    return "\n".join(lines)




def _cap_refusal(last_error: str) -> bool:
    """2026-08-19: True when the executor refused because the daily order cap
    is reached. The retry loop must NOT leave these rows OPEN forever."""
    if not last_error:
        return False
    s = str(last_error).lower()
    return ("daily order cap" in s) or ("order cap reached" in s) or ("daily cap" in s)


def _is_market_entry(row: dict) -> bool:
    order = str(row.get("order_type") or row.get("order_kind") or "").upper()
    return bool(order) and "MARKET" in order


def _cancel_cap_phantom(database, tid: str, telegram) -> None:
    """Mark a market entry that the daily cap refused as CANCELLED.

    A market signal that could not be placed in its cycle is stale by the
    next cycle; retrying it would silently trade a different price. LIMIT
    rows are price-anchored and keep retrying (the cap resets at midnight).
    """
    try:
        database.update_trade(tid, {
            "status": "CANCELLED",
            "result": "CANCELLED",
            "exit_warning": "daily order cap reached - market signal expired (never placed)",
        })
        if telegram:
            try:
                telegram.send_error_alert(
                    f"Daily cap: market entry {tid} cancelled (never placed)"
                )
            except Exception:  # noqa: BLE001
                pass
    except Exception:  # noqa: BLE001
        logger.warning("cap-phantom cancel failed for %s", tid)


def _sync_demo_execution(config, symbol_config, symbol, symbol_trades,
                         symbol_evals, database, telegram) -> None:
    """demo/mt5 branch: transmit unified-law levels to MT5 demo — broker-first.

    Paper mode (default) returns immediately; the executor only TRANSMITS
    levels already decided by the management engine and the unified loader.

    R26.9.11 (operator 2026-09-03, FX stop audit — fixes F2/F3/F4):
    the return value of executor.apply_stop used to be ignored, so a stop the
    broker never accepted still looked "booked" (Telegram said حجز الربح while
    the DB stop kept reverting to the broker's truth — see
    TRADE_20260828_170231 / TRADE_20260902_000226). Ownership is now explicit:

      * The 5-min engine still DECIDES the level, but in demo mode its
        profit-lock announcements are withheld (OpenTradesManager defers
        MOVE_SL_TO_BE / TRAILING_SL_UPDATED / CLUTCH_STRUCTURE_TRAIL) and are
        sent HERE, only after apply_stop returns True.
      * On apply failure the DB stop fields are reverted to the pre-cycle
        values (broker truth), the row is marked stop_sync_pending, and the
        next cycle retries the apply — with an honest warning, escalating to
        an alarm after repeated failures (stop_sync_fail_count).
      * run_tick_manager's drift guard stays the final reconciliation net.
    """
    mode = str(os.environ.get("EXECUTION_MODE")
               or (config.get("execution") or {}).get("execution_mode") or "paper")
    if mode != "mt5_demo":
        return
    try:
        from services.mt5_executor import Mt5DemoExecutor
        executor = Mt5DemoExecutor(symbol_config, telegram=telegram)
        if not executor.alive() or executor.halted():
            # The engine wrote a new stop into the DB this cycle; with the
            # executor down it will never reach the broker. Flag it instead
            # of letting the row claim protection it does not have.
            for ev in symbol_evals or []:
                if (ev.get("updates") or {}).get("stop_loss"):
                    _mark_stop_sync_failed(database, telegram, symbol,
                                           str(ev.get("trade_id") or ""), row=None,
                                           err="MT5 executor unavailable/halted")
            return
        rows_by_id = {str(t.get("id")): t for t in symbol_trades}
        for ev in symbol_evals or []:
            tid = str(ev.get("trade_id") or "")
            row = rows_by_id.get(tid) or {}
            side = str(row.get("type") or row.get("side") or "")
            events = set(ev.get("events") or [])
            updates = ev.get("updates") or {}
            ticket = row.get("mt5_ticket")
            if not ticket and ev.get("new_status") in {"OPEN", "PENDING"}:
                ticket = executor.ensure_ticket(
                    tid, side, str(row.get("order_type") or "MARKET"),
                    float(row.get("entry_price") or 0),
                    float(updates.get("stop_loss") or row.get("stop_loss") or 0),
                    float(row.get("tp2") or row.get("tp1") or 0), symbol)
                if ticket and hasattr(database, "update_trade"):
                    try:
                        database.update_trade(tid, {"mt5_ticket": ticket})
                    except Exception:  # noqa: BLE001
                        pass
                elif ticket is None and _cap_refusal(executor.last_error) and _is_market_entry(row):
                    # 2026-08-19: the daily cap blocked a MARKET entry. It is
                    # stale by the next cycle - close it instead of leaving a
                    # phantom OPEN row that can never be placed today.
                    _cancel_cap_phantom(database, tid, telegram)
                    continue
            if not ticket:
                continue
            if "TP1_HIT" in events:
                # R26.9.12 (TP1 partial audit): the return value used to be
                # ignored, and TP1_HIT is a one-shot status transition — so a
                # refused partial was booked in the DB (partial_close=True +
                # paper realized PnL) while the broker kept the FULL position,
                # and the tick manager's retry gate (decide_tp1 reads
                # row.partial_close) skipped it forever. Same law as the stop:
                # success books + announces; failure reverts the paper partial
                # so the tick manager retries every tick, and tells the truth.
                partial_ok = bool(executor.partial_close_at_tp1(tid, 0.5, symbol))
                if partial_ok:
                    _clear_partial_sync_pending(database, tid)
                    _announce_broker_confirmed_tp1(telegram, row, updates,
                                                   executor, symbol)
                else:
                    _revert_partial_to_broker_truth(database, telegram, symbol,
                                                    tid, row, executor)
            new_sl = updates.get("stop_loss")
            if new_sl:
                # F2: the stop is only "moved" when the BROKER says so.
                applied = bool(executor.apply_stop(tid, float(new_sl),
                                                   float(row.get("tp2") or 0), symbol))
                if applied:
                    _clear_stop_sync_pending(database, tid)
                    _announce_broker_confirmed_stop(
                        telegram, row, updates, events, symbol)
                else:
                    _revert_stop_to_broker_truth(database, telegram, symbol,
                                                 tid, row, executor)
        open_rows = [t for t in (database.get_open_trades() or [])
                     if normalize_symbol(str(t.get("symbol") or "")) == normalize_symbol(symbol)]
        mism = executor.reconcile(open_rows)
        if mism:
            logger.error("Demo reconciliation mismatches: %s", mism)
    except Exception as exc:  # noqa: BLE001 - demo must never kill paper
        logger.warning("Demo sync skipped: %s", exc)


# ── R26.9.11 stop-sync truth helpers (F2/F3) ────────────────────────────────

_STOP_MOVE_EVENTS = ("MOVE_SL_TO_BE", "TRAILING_SL_UPDATED", "CLUTCH_STRUCTURE_TRAIL")


def _announce_broker_confirmed_stop(telegram, row, updates, events, symbol) -> None:
    """Send the profit-lock card ONLY now that the broker has the stop."""
    try:
        if not (telegram and hasattr(telegram, "send_trade_event")):
            return
        announced = dict(row)
        announced["stop_loss"] = updates.get("stop_loss")
        if "sl_moved_to_entry" in updates:
            announced["sl_moved_to_entry"] = updates.get("sl_moved_to_entry")
        price = float(updates.get("current_price") or row.get("current_price") or 0)
        pnl = float(updates.get("current_pnl") or 0)
        evaluation = {"updates": updates, "symbol": symbol,
                      "broker_confirmed": True}
        for event in _STOP_MOVE_EVENTS:
            if event in events:
                telegram.send_trade_event(announced, event, price, pnl, evaluation)
    except Exception as exc:  # noqa: BLE001 - a card must never break sync
        logger.warning("Broker-confirmed stop card failed for %s: %s", symbol, exc)


def _mark_stop_sync_failed(database, telegram, symbol, tid, row, err) -> int:
    """Stamp stop_sync_pending / stop_sync_fail_count and notify honestly.

    Returns the new failure count. row=None means the pre-cycle row snapshot
    is unavailable (executor down): only the flags are stamped, the stop
    fields are left for the drift guard to reconcile.
    """
    fail_count = 0
    try:
        if row is not None:
            fail_count = int(row.get("stop_sync_fail_count") or 0) + 1
            patch = {"stop_sync_pending": True, "stop_sync_fail_count": fail_count}
            if hasattr(database, "update_trade"):
                database.update_trade(tid, patch)
            row.update(patch)
        else:
            fail_count = 1
            if hasattr(database, "update_trade"):
                database.update_trade(tid, {"stop_sync_pending": True})
    except Exception as exc:  # noqa: BLE001
        logger.warning("stop-sync flag write failed for %s: %s", tid, exc)
    try:
        if telegram and hasattr(telegram, "send_message"):
            if fail_count >= 2:
                # F3: escalation — this is not a hiccup any more.
                telegram.send_message(
                    f"🚨 {symbol}: تعذّر تنفيذ تحديث الستوب لدى الوسيط للمرة "
                    f"{fail_count} ({err}) — تحقّق من محطة MT5/الاتصال. "
                    f"الصفقة {tid} تعمل بستوب غير محدَّث.")
            else:
                telegram.send_message(
                    f"⚠️ {symbol}: فشل نقل الستوب إلى الوسيط ({err}) — "
                    f"الحماية غير منفّذة لدى الوسيط وستُعاد المحاولة في "
                    f"الدورة القادمة. الصفقة {tid}.")
    except Exception as exc:  # noqa: BLE001
        logger.warning("stop-sync warning failed for %s: %s", tid, exc)
    return fail_count


def _revert_stop_to_broker_truth(database, telegram, symbol, tid, row, executor) -> None:
    """apply_stop failed: put the DB back to the pre-cycle stop and flag it.

    The broker still holds the OLD stop, so the row must not claim the new
    one (the tick manager's drift guard would revert it anyway — this way the
    revert is immediate, explicit and announced). Next cycle the engine
    re-arms and the apply is retried.
    """
    try:
        patch = {}
        if row.get("stop_loss") is not None:
            patch["stop_loss"] = row.get("stop_loss")
        if "sl_moved_to_entry" in row:
            patch["sl_moved_to_entry"] = bool(row.get("sl_moved_to_entry"))
        if hasattr(database, "update_trade") and patch:
            database.update_trade(tid, patch)
    except Exception as exc:  # noqa: BLE001
        logger.warning("stop revert failed for %s: %s", tid, exc)
    err = str(getattr(executor, "last_error", "") or "") or "apply_stop refused"
    _mark_stop_sync_failed(database, telegram, symbol, tid, row, err)


def _clear_stop_sync_pending(database, tid) -> None:
    try:
        if hasattr(database, "update_trade"):
            database.update_trade(tid, {"stop_sync_pending": False,
                                        "stop_sync_fail_count": 0})
    except Exception as exc:  # noqa: BLE001
        logger.warning("stop-sync clear failed for %s: %s", tid, exc)


# ── R26.9.12 TP1-partial truth helpers ──────────────────────────────────────

def _announce_broker_confirmed_tp1(telegram, row, updates, executor, symbol) -> None:
    """Send the TP1 card only now that the broker closed the half.

    Skipped when the executor merely restored an existing mirror from broker
    history (last_partial.existing) — the tick manager already announced that
    physical partial; a second card would be a duplicate.
    """
    try:
        lp = getattr(executor, "last_partial", None) or {}
        if lp.get("existing"):
            return
        if not (telegram and hasattr(telegram, "send_trade_event")):
            return
        announced = dict(row)
        announced.update({k: v for k, v in updates.items()
                          if k in ("stop_loss", "sl_moved_to_entry",
                                   "current_price", "current_pnl")})
        price = float(lp.get("price") or updates.get("current_price") or 0)
        pnl = float(updates.get("current_pnl") or 0)
        evaluation = {"updates": updates, "symbol": symbol,
                      "broker_confirmed": True, "partial": lp}
        telegram.send_trade_event(announced, "TP1_HIT", price, pnl, evaluation)
    except Exception as exc:  # noqa: BLE001 - a card must never break sync
        logger.warning("Broker-confirmed TP1 card failed for %s: %s", symbol, exc)


def _revert_partial_to_broker_truth(database, telegram, symbol, tid, row, executor) -> None:
    """Broker refused the half-close: un-book the paper partial and flag it.

    The broker still holds the FULL position, so the row must go back to its
    pre-cycle partial fields (row is the pre-update snapshot). With
    partial_close=False the tick manager's broker-first TP1 path retries the
    half on every tick and books it on real execution.
    """
    try:
        patch = {
            "partial_close": bool(row.get("partial_close")),
            "partial_sync_pending": True,
        }
        for field in ("status", "realized_pnl_points", "closed_fraction",
                      "scale_out_price", "remaining_target"):
            if field in row or field in ("status",):
                patch[field] = row.get(field)
        if hasattr(database, "update_trade"):
            database.update_trade(tid, patch)
    except Exception as exc:  # noqa: BLE001
        logger.warning("partial revert failed for %s: %s", tid, exc)
    err = str(getattr(executor, "last_error", "") or "") or "partial close refused"
    _fail_count = int(row.get("partial_sync_fail_count") or 0) + 1
    try:
        if hasattr(database, "update_trade"):
            database.update_trade(tid, {"partial_sync_fail_count": _fail_count})
        row["partial_sync_fail_count"] = _fail_count
    except Exception as exc:  # noqa: BLE001
        logger.warning("partial fail-count write failed for %s: %s", tid, exc)
    try:
        if telegram and hasattr(telegram, "send_message"):
            if _fail_count >= 2:
                telegram.send_message(
                    f"🚨 {symbol}: تعذّر تنفيذ إغلاق النصف عند TP1 لدى الوسيط "
                    f"للمرة {_fail_count} ({err}) — تحقّق من محطة MT5/الاتصال. "
                    f"الصفقة {tid} ما تزال بكامل حجمها لدى الوسيط.")
            else:
                telegram.send_message(
                    f"⚠️ {symbol}: فشل إغلاق النصف عند TP1 لدى الوسيط ({err}) — "
                    f"الحجم الكامل ما يزال مفتوحاً وستُعاد المحاولة مع كل تِك. "
                    f"الصفقة {tid}.")
    except Exception as exc:  # noqa: BLE001
        logger.warning("partial warning failed for %s: %s", tid, exc)


def _clear_partial_sync_pending(database, tid) -> None:
    try:
        if hasattr(database, "update_trade"):
            database.update_trade(tid, {"partial_sync_pending": False,
                                        "partial_sync_fail_count": 0})
    except Exception as exc:  # noqa: BLE001
        logger.warning("partial-sync clear failed for %s: %s", tid, exc)


def main() -> None:
    """تحديث الصفقات المفتوحة."""
    # Weekend hard gate (operator directive 2026-08-09): Sat/Sun = no updates.
    from utils.helpers import is_weekend_hebron
    if is_weekend_hebron():
        logger.info("Weekend (Sat/Sun Hebron) — trade updates skipped by operator directive.")
        return
    logger.info("Starting trade updates: %s", datetime.now(timezone.utc).isoformat())
    config = load_config()

    # ── فحص ساعات التداول ──
    session = TradingSessionAgent(config).check()
    logger.info(
        "🔍 Session: %s | Quality: %s | Allowed: %s",
        session.get("current_session") or "خارج Session",
        session.get("session_quality", "N/A"),
        session.get("trading_allowed"),
    )

    update_outside_hours = bool(config.get("trade_management", {}).get("update_outside_trading_hours", False))
    force_update = os.environ.get("FORCE_TRADE_UPDATE", "false").lower() in {"1", "true", "yes"}
    if not session.get("trading_allowed") and not update_outside_hours and not force_update:
        logger.info(
            "🚫 Outside trade update hours (%s) - No update. Reason: %s",
            session.get("current_session") or "غير محدد",
            session.get("reason", ""),
        )
        return  # ══ لا تحديث خارج الجلسات إلا عند FORCE_TRADE_UPDATE ══
    if not session.get("trading_allowed") and (update_outside_hours or force_update):
        logger.info(
            "ℹ️ Outside normal update hours, but continuing due to update_outside_trading_hours or FORCE_TRADE_UPDATE"
        )

    try:
        telegram = TelegramService(config)
        database = DatabaseService(config)

        # Critical quota/cost optimization: do not fetch market data, initialize
        # trade management, or consume Twelve Data calls when there is no active
        # trade/pending order to manage. This still starts a tiny GitHub workflow
        # when triggered externally, but the workflow pre-check should normally
        # skip the heavy steps before Python dependencies are installed.
        open_trades = database.get_open_trades()
        logger.info("Active/pending trades count: %s", len(open_trades))
        # R26.7: shadow mode removed — there is only the single live book.
        # An empty book means there is nothing to manage this cycle.
        if not open_trades:
            logger.info("لا توجد صفقات مفتوحة أو أوامر معلقة — skipping تحديث الصفقات بدون Telegram وبدون جلب سعر.")
            return

        # In the consolidated end-of-day digest, suppress this script's own
        # Telegram messages (trade events + confirmation). DB updates still run;
        # the daily report aggregates everything into one message. We achieve
        # this by passing telegram=None to the manager so it sends nothing.
        eod_quiet = os.environ.get("EOD_QUIET", "").lower() in {"1", "true", "yes"}
        telegram_for_events = None if eod_quiet else telegram

        # Group active trades by symbol and fetch each market price separately.
        # This is mandatory now that the bot supports Gold, FX pairs, and WTI.
        grouped: dict[str, list] = {}
        for trade in open_trades:
            symbol = normalize_symbol(trade.get("symbol") or config.get("symbol", "XAU/USD"))
            grouped.setdefault(symbol, []).append(trade)

        if (os.environ.get("EXECUTION_MODE") == "mt5_demo"
                and os.environ.get("TICK_MANAGER", "true").lower() in {"1", "true", "yes"}):
            logger.info("Tick manager owns MT5 execution; the 5m cycle keeps "
                        "bookkeeping/reporting only.")
            grouped = {}
        evaluations = []
        current_price = 0.0
        symbol_prices: dict = {}  # BUILD 31: per-symbol prices for the status
        for symbol, symbol_trades in grouped.items():
            symbol_config = config_for_instrument(config, {"symbol": symbol})
            market_data = MarketDataService(symbol_config)
            manager = OpenTradesManager(symbol_config)

            # Use the SAME base timeframe as analysis (5m) to benefit from
            # the 60-second cache. We intentionally fetch MORE than 6 candles
            # here because the trade manager now computes a rolling "recent 30m"
            # range from the last 6 x 5m candles. Requesting only 5 candles was
            # insufficient and could miss one candle from the intended window.
            base_tf = symbol_config.get("data_source", {}).get("base_timeframe", "5m")
            price_payload = market_data.get_ohlcv(base_tf, outputsize=12)
            allow_synthetic = bool(symbol_config.get("data_source", {}).get("allow_synthetic_in_production", False))
            if os.environ.get("GITHUB_ACTIONS") == "true" and not _payload_supports_signal_generation(price_payload) and price_payload.get("source") == "synthetic_demo" and not allow_synthetic:
                # For trade management only, try a live XAU/USD spot quote before
                # giving up. This does not provide historical candles for
                # analysis, but it is safer than stopping SL/TP management and
                # safer than using GC=F futures as a proxy.
                quote_payload = market_data.get_spot_quote_payload()
                if quote_payload:
                    logger.warning("Using Swissquote spot quote fallback for %s trade updates", symbol)
                    price_payload = quote_payload
                else:
                    logger.error("Trade updates stopped for %s: all real data sources failed", symbol)
                    telegram.send_error_alert(
                        "Trade updates stopped: all real data sources failed "
                        "(Twelve Data quota/key and Swissquote spot quote unavailable)"
                    )
                    continue
            symbol_price = price_payload.get("current_price")
            if not symbol_price:
                logger.error("Failed to fetch price for symbol %s", symbol)
                continue
            current_price = float(symbol_price)
            # Check news hard-block for pending-order activation logic.
            try:
                news_cfg = {**symbol_config, "macro_context": database.get_macro_context()} if hasattr(database, 'get_macro_context') else symbol_config
                news_result = NewsRiskAgent(news_cfg).check()
            except Exception:
                news_result = {}
            news_blocked = bool(news_result.get("can_trade") is False or str(news_result.get("market_status", "")).upper() in {"DANGER", "HIGH_VOLATILITY"})
            # ── Global price sanity: reject obviously corrupt ticks ──
            from utils.instruments import price_sanity_range
            _sane_min, _sane_max = price_sanity_range(symbol, config)
            symbol_prices[symbol] = current_price  # BUILD 31
            if current_price < _sane_min or current_price > _sane_max:
                logger.error(
                    "PRICE SANITY FAILED (global): %s current_price=%.5f outside range [%.2f-%.2f]. Skipping trade updates this cycle.",
                    symbol, current_price, _sane_min, _sane_max,
                )
                if not eod_quiet:
                    telegram.send_error_alert(
                        f"Trade updates skipped for {symbol}: corrupted price {current_price:.5f} "
                        f"(expected {_sane_min:.2f}-{_sane_max:.2f}). Data provider glitch."
                    )
                continue
            latest_candle = (price_payload.get("data") or [{}])[-1] or {}
            recent_candles = (price_payload.get("data") or [])[-6:]
            try:
                candle_high = float(latest_candle.get("high") or current_price)
                candle_low = float(latest_candle.get("low") or current_price)
            except (TypeError, ValueError):
                candle_high = current_price
                candle_low = current_price
            # The candle's own timestamp travels with its extremes: the manager
            # refuses fills/stop-outs from a bar older than the freshness
            # window, and never lets a bar that predates an order fill it.
            candle_time = str(latest_candle.get("time") or "") or None
            if not _payload_supports_pending_activation(price_payload) and any(str(t.get("status") or "").upper() == "PENDING" for t in symbol_trades):
                integrity = price_payload.get("source_integrity") or {}
                logger.warning(
                    "Pending touch detection degraded for %s: source=%s type=%s grade=%s. Pending orders will wait for a real candle source before activation.",
                    symbol,
                    integrity.get("source") or price_payload.get("source"),
                    integrity.get("source_type") or "unknown",
                    integrity.get("reliability_grade") or "UNKNOWN",
                )
            # Activation book gate (operator 2026-08-18): hand the manager
            # the freshest agent book so a pending that price touches is
            # checked against the CURRENT vote, not the one from placement
            # time. A missing/stale book passes None and the gate fails open.
            _activation_book = None
            try:
                from services.agent_book_store import load_agent_book
                _activation_book = load_agent_book(symbol)
            except Exception as _book_exc:  # noqa: BLE001
                logger.warning("Agent book load failed for %s (gate fails open): %s", symbol, _book_exc)
            _before_eval = len(evaluations)
            evaluations.extend(manager.update_trades(
                open_trades=symbol_trades,
                current_price=current_price,
                candle_high=candle_high,
                candle_low=candle_low,
                recent_candles=recent_candles,
                database=database,
                telegram=telegram_for_events,
                now=datetime.now(timezone.utc),
                news_blocked=news_blocked,
                news_context=news_result,
                market_data_source=str(price_payload.get("source") or ""),
                candle_time=candle_time,
                agent_details=_activation_book,
            ))
            _sync_demo_execution(
                config, symbol_config, symbol, symbol_trades,
                evaluations[_before_eval:], database, telegram_for_events)

        total_events = 0
        for evaluation in evaluations:
            if evaluation.get("events"):
                total_events += len(evaluation.get("events", []))
                logger.info(
                    "Trade update %s: %s | %s -> %s | PnL=%s",
                    evaluation.get("trade_id"),
                    ",".join(evaluation.get("events", [])),
                    evaluation.get("old_status"),
                    evaluation.get("new_status"),
                    evaluation.get("pnl_points"),
                )

        # ── Hourly heartbeat / status message ───────────────────────────────
        # CRITICAL FIX: We deliberately suppress the "Trades Update" heartbeat
        # when there are **zero open trades** on scheduled runs.
        #
        # Reason: It was sending useless "📭 No open trades." messages that
        # collided in time with the much more useful "Market Status" from
        # the analysis script (which already explains WAIT + reasons + Daily Bias).
        #
        # New rule:
        # - Always send on manual runs (workflow_dispatch)
        # - On scheduled runs: ONLY send if there is at least 1 open trade
        manual = os.environ.get("GITHUB_EVENT_NAME") == "workflow_dispatch" or force_update
        notif = config.get("notifications", {}) or {}
        heartbeat = bool(notif.get("heartbeat_on_trade_update", True))
        notify_updates = bool(notif.get("notify_on_trade_update", False))

        heartbeat_interval = int(notif.get("heartbeat_interval_minutes", 60) or 60)
        if manual:
            heartbeat_due = True
        elif heartbeat_interval <= 30:
            heartbeat_due = True
        else:
            heartbeat_due = datetime.now(timezone.utc).minute < 30

        has_open_trades = len(open_trades) > 0

        # Only send the optional "Trades Update" heartbeat when explicitly
        # enabled. It must NOT be forced by a manual run: the production rule is
        # "message only on real change" (SL moved / trailing moved / TP / SL / BE
        # / order fill). Those event messages are already sent above by
        # OpenTradesManager. With heartbeat_on_trade_update=false and
        # notify_on_trade_update=false, no Telegram message is sent when there is
        # no trade-state change.
        should_send = (
            (notify_updates or (heartbeat and has_open_trades))
            and heartbeat_due
            and total_events == 0
            and not eod_quiet
        )

        if should_send:
            telegram.send_message(
                _build_status_message(open_trades, evaluations, float(current_price),
                                      config, symbol_prices=symbol_prices)
            )

        logger.info("Trade update completed (events=%s, open=%s)", total_events, len(open_trades))
    except Exception as exc:  # noqa: BLE001
        logger.exception("Update error: %s", exc)


if __name__ == "__main__":
    main()
