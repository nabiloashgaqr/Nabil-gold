from __future__ import annotations
from pathlib import Path

from shadow_market_architect.models import Horizon, MarketState
from shadow_market_architect.regime import MarketStateEngine, extract_timeframes
from shadow_market_architect.store import ShadowStore


def bars(closes, ranges=None):
    ranges = ranges or [1.0] * len(closes)
    return [{"time": i, "open": c-0.1, "high": c+r/2, "low": c-r/2, "close": c}
            for i, (c, r) in enumerate(zip(closes, ranges))]


def market(**frames):
    return {"shared_market_data": {"timeframes": frames}}


def test_extracts_common_timeframe_aliases():
    data = extract_timeframes(market(**{"1m": bars([100+i for i in range(30)]), "1H": bars([100+i for i in range(30)])}))
    assert len(data["M1"]) == 30 and len(data["H1"]) == 30


def test_clean_directional_market_is_trend_continuation_all_horizons():
    rising = bars([100 + i for i in range(30)])
    states = MarketStateEngine().classify("XAU/USD", market(M1=rising, M5=rising, H1=rising), "2026-09-05T10:00:00Z")
    assert {x.state for x in states} == {MarketState.TREND_CONTINUATION}
    assert all(x.direction == "BUY" for x in states)


def test_choppy_market_is_range_rotation():
    closes = [100 + (1 if i % 2 else -1) for i in range(31)]
    result = MarketStateEngine().classify("WTI/USD", market(M1=bars(closes)), "2026-09-05T10:00:00Z")[0]
    assert result.horizon == Horizon.SCALP
    assert result.state == MarketState.RANGE_ROTATION
    assert result.direction == "NEUTRAL"


def test_latest_forming_bar_is_excluded_from_state():
    closed = bars([100 + (1 if i % 2 else -1) for i in range(30)])
    live_shock = {"open": 100, "high": 200, "low": 50, "close": 190, "time": 999}
    result = MarketStateEngine().classify("EUR/USD", market(M1=closed+[live_shock]), "2026-09-05T10:00:00Z")[0]
    assert result.state != MarketState.SHOCK_NEWS


def test_completed_large_bar_is_shock_state():
    base = bars([100 + i*0.05 for i in range(29)], [1]*29)
    shock = {"open":101,"high":110,"low":95,"close":108,"time":30}
    live = {"open":108,"high":109,"low":107,"close":108,"time":31}
    result = MarketStateEngine().classify("GBP/USD", market(M1=base+[shock,live]), "2026-09-05T10:00:00Z")[0]
    assert result.state == MarketState.SHOCK_NEWS


def test_missing_data_is_explicit_uncertain_not_invented():
    states = MarketStateEngine().classify("USD/CAD", {}, "2026-09-05T10:00:00Z")
    assert len(states) == 3
    assert all(x.state == MarketState.UNCERTAIN and x.strength == 0 for x in states)
    assert all("insufficient" in x.reasons[0] for x in states)


def test_each_horizon_uses_its_own_market_evidence():
    rising = bars([100+i for i in range(31)])
    falling = bars([200-i for i in range(31)])
    choppy = bars([150+(1 if i%2 else -1) for i in range(31)])
    states = MarketStateEngine().classify("USD/JPY", market(M1=rising, M5=falling, H1=choppy), "2026-09-05T10:00:00Z")
    by_h = {x.horizon:x for x in states}
    assert by_h[Horizon.SCALP].direction == "BUY"
    assert by_h[Horizon.INTRADAY].direction == "SELL"
    assert by_h[Horizon.STRUCTURAL].state == MarketState.RANGE_ROTATION


def test_market_state_snapshot_persists_in_shadow_store(tmp_path):
    rising = bars([100+i for i in range(31)])
    state = MarketStateEngine().classify("XAU/USD", market(M1=rising), "2026-09-05T10:00:00Z")[0]
    store = ShadowStore(tmp_path/"shadow_state.sqlite3"); store.initialize(); store.append_market_state(state)
    with store.connect() as c:
        row = c.execute("SELECT * FROM shadow_market_state_snapshots").fetchone()
    assert row["state"] == "TREND_CONTINUATION" and row["direction"] == "BUY"
