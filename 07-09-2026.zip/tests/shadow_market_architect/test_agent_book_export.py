import json
from services.shadow_evidence_export import publish_shadow_agent_book
from shadow_market_architect.evidence import EvidenceAdapter

def test_each_symbol_gets_atomic_agent_book_consumable_by_shadow(tmp_path):
 pattern=str(tmp_path/'books'/'{symbol}.json');cfg={'shadow_market_architect':{'evidence':{'shadow_agent_book_pattern':pattern}}}
 results={'smc':{'setup_candidates':[{'direction':'BUY','entry_zone':{'low':1.08,'high':1.09,'type':'DEMAND','quality':80}}]}}
 path=publish_shadow_agent_book('EUR/USD',results,cfg);assert path and path.name=='EURUSD.json'
 raw=json.loads(path.read_text(encoding='utf-8'));assert raw['symbol']=='EUR/USD'
 market=tmp_path/'EURUSD-market.json';market.write_text(json.dumps({'symbol':'EUR/USD','current_price':1.1}),encoding='utf-8')
 snap=EvidenceAdapter({'shared_market_data_pattern':str(tmp_path/'{symbol}-market.json'),'agent_book_pattern':pattern},root=tmp_path).capture('EUR/USD')
 assert snap.agents['symbol']=='EUR/USD' and snap.agents['agents']['smc']['setup_candidates']
