import json
from pathlib import Path
from shadow_market_architect.daily_integration import build_daily_shadow_comparison,_live_row
from shadow_market_architect.positions import VirtualPosition,VirtualPositionStatus
from shadow_market_architect.store import ShadowStore
ROOT=Path(__file__).resolve().parents[2];CFG=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
def test_live_row_derives_signed_r_from_realized_points_and_initial_risk():
 x=_live_row({'id':'x','symbol':'XAU/USD','type':'SELL','entry_price':4400,'initial_stop_loss':4430,'final_pnl_points':150},CFG)
 assert x['side']=='SELL' and x['pnl_r']==.5
def test_daily_comparison_reads_shadow_store_writes_report_and_compact_lines(tmp_path):
 db=tmp_path/'daily_shadow.sqlite3';store=ShadowStore(db);store.initialize()
 p=VirtualPosition('o','s','f','XAU/USD','BUY','2026-09-05T10:00:00Z',4400,4370,4415,4430,4460,4490,status=VirtualPositionStatus.CLOSED,remaining_fraction=0,closed_fraction=1,realized_points=525,realized_r=1.75,tp1_done=True,tp2_done=True,tp3_done=True,protected=True,best_price=4490,closed_at='2026-09-05T11:00:00Z',close_price=4490,exit_reason='TP3_FINAL',result='WIN')
 store.upsert_virtual_position(p)
 cfg={**CFG,'shadow_market_architect':{'storage_path':str(db),'daily_comparison':{'enabled':True,'report_directory':str(tmp_path/'reports')},'gap_intelligence':{},'reporting':{'min_sample_size':30}}}
 live=[{'id':'live1','symbol':'XAU/USD','type':'SELL','created_at':'2026-09-05T10:00:00Z','closed_at':'2026-09-05T11:00:00Z','entry_price':4400,'initial_stop_loss':4430,'final_pnl_points':-300,'status':'SL_HIT'}]
 lines,path=build_daily_shadow_comparison(cfg,live,'2026-09-05',ROOT)
 assert path and path.exists() and 'Shadow Market Architect' in path.read_text(encoding='utf-8')
 assert lines[0]=='🌑 <b>Live vs Shadow</b>' and any('avoided loss' in x for x in lines)
 with store.connect() as c:assert c.execute('select count(*) from shadow_gap_comparisons').fetchone()[0]>=2
def test_daily_comparison_disabled_is_noop(tmp_path):
 assert build_daily_shadow_comparison({'shadow_market_architect':{}},[],'2026-09-05',tmp_path)==([],None)
