from __future__ import annotations
import json, sqlite3
from pathlib import Path

from shadow_market_architect.evidence import (
    EvidenceAdapter, ReadOnlyAuctionReader, normalize_symbol, read_json_stable,
)
from shadow_market_architect.store import ShadowStore


def _auction(path: Path):
    with sqlite3.connect(path) as c:
        c.executescript("""
        CREATE TABLE seconds(ts INTEGER PRIMARY KEY, open_mid REAL, high_mid REAL,
          low_mid REAL, close_mid REAL, sum_mid REAL, tick_count INTEGER,
          up_count INTEGER, down_count INTEGER, flat_count INTEGER,
          sum_spread REAL, max_spread REAL);
        CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        INSERT INTO meta VALUES('symbol','XAU/USD');
        INSERT INTO seconds VALUES(100,1,2,1,2,3,4,2,1,1,0.8,0.3);
        """)


def test_symbol_normalization_covers_every_enabled_family():
    assert normalize_symbol("XAUUSD.s") == "XAU/USD"
    assert normalize_symbol("USOIL") == "WTI/USD"
    assert normalize_symbol("eurusd") == "EUR/USD"
    assert normalize_symbol("USDJPY") == "USD/JPY"


def test_stable_reader_never_mutates_source(tmp_path):
    p = tmp_path / "market.json"; p.write_text('{"symbol":"XAU/USD"}', encoding="utf-8")
    before = p.read_bytes(); data, digest, _ = read_json_stable(p)
    assert data["symbol"] == "XAU/USD" and len(digest) == 64
    assert p.read_bytes() == before


def test_adapter_rejects_cross_symbol_evidence_and_records_warning(tmp_path):
    (tmp_path / "agents").mkdir()
    (tmp_path / "market.json").write_text(json.dumps({"symbol":"WTI/USD","written_at":100}), encoding="utf-8")
    (tmp_path / "agents" / "XAUUSD.json").write_text(json.dumps({"symbol":"EUR/USD"}), encoding="utf-8")
    snap = EvidenceAdapter({"shared_market_data_path":"market.json",
        "agent_book_pattern":"agents/{symbol}.json"}, root=tmp_path).capture("XAU/USD")
    assert snap.symbol == "XAU/USD"
    assert snap.market == {} and snap.agents == {}
    assert any("mismatch" in w for w in snap.warnings)


def test_auction_reader_uses_existing_schema_without_writes(tmp_path):
    p = tmp_path / "auction.sqlite3"; _auction(p)
    before = p.read_bytes(); result = ReadOnlyAuctionReader(p).recent()
    assert result["available"] and result["row_count"] == 1
    assert result["seconds"][0]["close_mid"] == 2
    assert p.read_bytes() == before


def test_capture_combines_market_agents_auction_and_persists_only_shadow(tmp_path):
    (tmp_path / "agents").mkdir(); _auction(tmp_path / "auction.sqlite3")
    (tmp_path / "market.json").write_text(json.dumps({"symbol":"XAU/USD","written_at":101,"bid":4400}), encoding="utf-8")
    (tmp_path / "agents" / "XAUUSD.json").write_text(json.dumps({"symbol":"XAU/USD","generated_at":102,"agents":{"smc":{"direction":"BUY"}}}), encoding="utf-8")
    cfg = {"shared_market_data_path":"market.json", "agent_book_pattern":"agents/{symbol}.json",
           "auction_flow_paths":{"XAU/USD":"auction.sqlite3"}}
    snap = EvidenceAdapter(cfg, root=tmp_path).capture("XAUUSD")
    assert snap.market["bid"] == 4400
    assert snap.agents["agents"]["smc"]["direction"] == "BUY"
    assert snap.auction["available"]
    store = ShadowStore(tmp_path / "shadow_evidence.sqlite3"); store.initialize(); store.append_evidence(snap)
    with store.connect() as c:
        row = c.execute("SELECT symbol,market_json FROM shadow_evidence_snapshots").fetchone()
    assert row["symbol"] == "XAU/USD" and '4400' in row["market_json"]
