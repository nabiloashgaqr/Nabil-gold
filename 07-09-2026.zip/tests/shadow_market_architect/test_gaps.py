from shadow_market_architect.gaps import GapIntelligence,GapType

def sh(**kw):
 d={"scenario_id":"s1","family_id":"f1","symbol":"XAU/USD","side":"BUY","status":"CLOSED","opened_at":"2026-09-05T10:00:00Z","entry_price":4400,"realized_r":1.5,"exit_reason":"TP3_FINAL"};d.update(kw);return d
def orig(**kw):
 d={"trade_id":"o1","symbol":"XAU/USD","side":"BUY","opened_at":"2026-09-05T10:02:00Z","entry_price":4400,"point_size":.1,"pnl_r":.5,"exit_reason":"MANUAL"};d.update(kw);return d

def kinds(rows):return {x.gap_type for x in rows}
def test_matches_by_symbol_time_and_reports_outcome_and_exit_gap():
 r=GapIntelligence().compare([orig()],[sh()],compared_at='2026-09-05T12:00:00Z')
 assert kinds(r)=={GapType.OUTCOME_DIVERGENCE,GapType.EXIT_MANAGEMENT}
def test_direction_disagreement_and_avoided_loss_are_explicit():
 r=GapIntelligence().compare([orig(side='SELL',pnl_r=-1)],[sh()],compared_at='2026-09-05T12:00:00Z')
 assert {GapType.DIRECTION_DISAGREEMENT,GapType.AVOIDED_LOSS}<=kinds(r)
def test_profitable_unmatched_shadow_is_missed_opportunity():
 r=GapIntelligence().compare([], [sh()],compared_at='2026-09-05T12:00:00Z')
 assert len(r)==1 and r[0].gap_type==GapType.MISSED_OPPORTUNITY
def test_unmatched_original_is_original_only():
 r=GapIntelligence().compare([orig()],[],compared_at='2026-09-05T12:00:00Z')
 assert len(r)==1 and r[0].gap_type==GapType.ORIGINAL_ONLY
def test_family_dedup_prevents_measurement_inflation():
 shadows=[sh(scenario_id='a',realized_r=1),sh(scenario_id='b',realized_r=2)]
 r=GapIntelligence().compare([],shadows,compared_at='2026-09-05T12:00:00Z')
 assert len(r)==1 and r[0].details['shadow_r']==2
def test_open_shadow_is_not_scored_with_hindsight():
 assert GapIntelligence().compare([], [sh(status='OPEN')])==[]
def test_entry_timing_uses_points_and_ids_are_stable():
 g=GapIntelligence({"entry_tolerance_points":40});a=g.compare([orig(entry_price=4400)],[sh(entry_price=4405)],compared_at='2026-09-05T12:00:00Z');b=g.compare([orig(entry_price=4400)],[sh(entry_price=4405)],compared_at='2026-09-05T13:00:00Z')
 e=next(x for x in a if x.gap_type==GapType.ENTRY_TIMING);assert e.details['entry_gap_points']==50 and e.comparison_id==next(x for x in b if x.gap_type==GapType.ENTRY_TIMING).comparison_id
