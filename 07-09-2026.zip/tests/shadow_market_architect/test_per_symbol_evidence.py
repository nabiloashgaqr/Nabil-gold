import json
from pathlib import Path
from services.shared_market_data import publish_shared_market_data
from shadow_market_architect.evidence import EvidenceAdapter

def book(symbol,price):
 bars=[{'time':f'2026-09-07T{i:02d}:00:00Z','open':price+i,'high':price+i+1,'low':price+i-1,'close':price+i+.5} for i in range(25)]
 return {'symbol':symbol,'current_price':price,'source':'test','timeframes':{'M1':{'source':'test','data':bars},'M5':{'source':'test','data':bars},'M15':{'source':'test','data':bars},'H1':{'source':'test','data':bars},'H4':{'source':'test','data':bars}}}
def test_publisher_archives_each_symbol_and_adapter_reads_matching_book(tmp_path):
 pattern=str(tmp_path/'shared'/'{symbol}.json');legacy=tmp_path/'latest.json';cfg={'shared_market_data':{'per_symbol_storage_pattern':pattern}}
 publish_shared_market_data(book('EUR/USD',1.1),cfg,path=legacy);publish_shared_market_data(book('USD/JPY',150),cfg,path=legacy)
 assert json.loads(legacy.read_text(encoding='utf-8'))['symbol']=='USD/JPY'
 adapter=EvidenceAdapter({'shared_market_data_pattern':pattern,'agent_book_pattern':str(tmp_path/'missing'/'{symbol}.json')},root=tmp_path)
 eur=adapter.capture('EUR/USD');jpy=adapter.capture('USD/JPY')
 assert eur.market['symbol']=='EUR/USD' and jpy.market['symbol']=='USD/JPY'
 assert not any('symbol mismatch' in x for x in eur.warnings+jpy.warnings)
