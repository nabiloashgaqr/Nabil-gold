from pathlib import Path
import sqlite3
import pytest

from shadow_market_architect.models import (
    Horizon, ScenarioSide, ScenarioSnapshot, ScenarioStatus, ShadowEvent,
)
from shadow_market_architect.store import ShadowStore


def test_store_rejects_non_shadow_filename(tmp_path):
    with pytest.raises(ValueError):
        ShadowStore(tmp_path / "trades.sqlite3")


def test_store_initializes_only_shadow_tables(tmp_path):
    path = tmp_path / "shadow_test.sqlite3"
    store = ShadowStore(path); store.initialize()
    with store.connect() as conn:
        names = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
    assert "shadow_events" in names
    assert "shadow_scenario_snapshots" in names
    assert "trades" not in names and "trades_demo" not in names


def test_append_only_event_and_snapshot_round_trip(tmp_path):
    store = ShadowStore(tmp_path / "shadow_test.sqlite3"); store.initialize()
    event = ShadowEvent("MARKET_STATE_OBSERVED", "EUR/USD", "2026-09-05T10:00:00Z",
                        {"state": "UNCERTAIN"})
    store.append_event(event)
    snap = ScenarioSnapshot(
        symbol="EUR/USD", side=ScenarioSide.SELL, horizon=Horizon.SCALP,
        playbook="MICRO_BREAK_RETEST", status=ScenarioStatus.DISCOVERED,
        known_at="2026-09-05T10:00:01Z", evidence={"source": "test"},
        config_version="phase1",
    )
    store.append_snapshot(snap)
    assert list(store.events())[0]["event_id"] == event.event_id
    with store.connect() as conn:
        row = conn.execute("SELECT * FROM shadow_scenario_snapshots").fetchone()
    assert row["side"] == "SELL" and row["horizon"] == "SCALP"


def test_duplicate_snapshot_is_rejected_not_rewritten(tmp_path):
    store = ShadowStore(tmp_path / "shadow_test.sqlite3"); store.initialize()
    snap = ScenarioSnapshot(
        scenario_id="fixed", symbol="XAU/USD", side=ScenarioSide.BUY,
        horizon=Horizon.STRUCTURAL, playbook="EXTREME_REVERSAL",
        status=ScenarioStatus.WATCH, known_at="2026-09-05T10:00:00Z",
        evidence={}, config_version="phase1")
    store.append_snapshot(snap)
    with pytest.raises(sqlite3.IntegrityError):
        store.append_snapshot(snap)
