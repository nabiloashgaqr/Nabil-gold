"""Full deterministic phase-1 through phase-9 shadow lifecycle audit."""
import json
from pathlib import Path
from shadow_market_architect.safety import audit_package
from shadow_market_architect.store import ShadowStore
from shadow_market_architect.models import Horizon,ScenarioSide,ScenarioSnapshot,ScenarioStatus
from shadow_market_architect.entries import EntryArchitect,VirtualBroker,VirtualOrderStatus
from shadow_market_architect.positions import VirtualPositionManager,VirtualPositionStatus
from shadow_market_architect.gaps import GapIntelligence,GapType
from shadow_market_architect.reporting import ShadowMetrics,ShadowReporter
from shadow_market_architect.calibration import ShadowCalibrator,CalibrationAction,FinalReport
ROOT=Path(__file__).resolve().parents[2]
CFG=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))

def test_complete_shadow_lifecycle_is_isolated_traceable_and_persisted(tmp_path):
 audit_package()
 store=ShadowStore(tmp_path/'complete_shadow_audit.sqlite3');store.initialize()
 scenario=ScenarioSnapshot(symbol='XAU/USD',side=ScenarioSide.BUY,horizon=Horizon.INTRADAY,
  playbook='TREND_PULLBACK',status=ScenarioStatus.READY,known_at='2026-09-05T10:00:00Z',
  evidence={'audit':'deterministic'},config_version='phase9',family_id='audit-family',
  entry_low=4399,entry_high=4401,preferred_entry=4400)
 store.append_snapshot(scenario)
 architect=EntryArchitect({'gold_risk_points':300,'gold_min_risk_points':270,'gold_max_risk_points':400},CFG)
 plan=architect.plan(scenario);store.append_entry_plan(plan);order=architect.virtual_order(plan)
 assert VirtualBroker(CFG).on_tick(order,bid=4399.9,ask=4400,known_at='2026-09-05T10:00:01Z')
 assert order.status==VirtualOrderStatus.FILLED;store.append_virtual_order(order)
 manager=VirtualPositionManager(CFG,{'gold_be_lock_points':40,'scale_out_fractions':{'tp1':.5,'tp2':.25}})
 position=manager.open_from_order(order)
 assert manager.on_tick(position,bid=4430,ask=4430.2,known_at='2026-09-05T10:01:00Z')
 assert position.protected and position.remaining_fraction==.5
 manager.on_tick(position,bid=4460,ask=4460.2,known_at='2026-09-05T10:02:00Z')
 manager.on_tick(position,bid=4490,ask=4490.2,known_at='2026-09-05T10:03:00Z')
 assert position.status==VirtualPositionStatus.CLOSED and position.result=='WIN' and position.closed_fraction==1
 store.upsert_virtual_position(position)
 original={'trade_id':'original-loss','symbol':'XAU/USD','side':'SELL','opened_at':'2026-09-05T10:00:00Z','pnl_r':-1,'exit_reason':'STOP_LOSS'}
 gaps=GapIntelligence().compare([original],[position],compared_at='2026-09-05T12:00:00Z')
 assert {GapType.AVOIDED_LOSS,GapType.DIRECTION_DISAGREEMENT} <= {g.gap_type for g in gaps}
 for gap in gaps:store.append_gap_comparison(gap)
 enriched=store.virtual_positions();metrics=ShadowMetrics().calculate(enriched,calculated_at='2026-09-05T12:01:00Z')
 assert len(metrics)==1 and metrics[0].family_count==1 and metrics[0].sample_quality=='LOW_SAMPLE'
 for metric in metrics:store.upsert_daily_metric(metric)
 measurement=ShadowReporter().build(metrics,gaps,generated_at='2026-09-05T12:02:00Z')
 assert 'XAU/USD' in ShadowReporter().markdown(measurement)
 run=ShadowCalibrator().calibrate(metrics,gaps,generated_at='2026-09-05T12:03:00Z')
 assert run.recommendations[0].action==CalibrationAction.INSUFFICIENT_DATA
 assert 'NO AUTOMATIC CHANGES' in FinalReport().markdown(run,measurement);store.append_calibration_run(run)
 with store.connect() as c:
  assert c.execute('select count(*) from shadow_scenario_snapshots').fetchone()[0]==1
  assert c.execute('select count(*) from shadow_virtual_trades').fetchone()[0]==1
  assert c.execute('select count(*) from shadow_gap_comparisons').fetchone()[0]>=2
  assert c.execute('select count(*) from shadow_daily_metrics').fetchone()[0]==1
  assert c.execute('select count(*) from shadow_calibration_runs').fetchone()[0]==1
