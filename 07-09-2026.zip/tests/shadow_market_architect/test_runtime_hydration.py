from shadow_market_architect.entries import VirtualOrder, VirtualOrderStatus
from shadow_market_architect.positions import VirtualPosition, VirtualPositionStatus
from shadow_market_architect.store import ShadowStore


def order():
    return VirtualOrder(
        plan_id="plan", scenario_id="scenario", family_id="family",
        symbol="USD/CAD", side="BUY", method="LIMIT",
        status=VirtualOrderStatus.PENDING,
        created_at="2026-09-07T10:00:00Z", entry_price=1.38349,
        stop_loss=1.37899, tp1=1.38799, tp2=1.39249, tp3=1.39699,
        order_id="order-fixed",
    )


def position():
    return VirtualPosition(
        order_id="order-fixed", scenario_id="scenario", family_id="family",
        symbol="USD/CAD", side="BUY", opened_at="2026-09-07T10:01:00Z",
        entry_price=1.38256, initial_stop_loss=1.37899,
        stop_loss=1.37899, tp1=1.38799, tp2=1.39249, tp3=1.39699,
        position_id="position-fixed",
    )


def test_pending_order_is_hydrated_and_updated_in_place(tmp_path):
    store=ShadowStore(tmp_path/"shadow_runtime.sqlite3");store.initialize()
    original=order();store.upsert_virtual_order(original)
    hydrated=store.active_virtual_orders("USD/CAD")
    assert len(hydrated)==1
    assert hydrated[0].order_id==original.order_id
    assert hydrated[0].status is VirtualOrderStatus.PENDING
    hydrated[0].status=VirtualOrderStatus.FILLED
    hydrated[0].filled_at="2026-09-07T10:02:00Z"
    hydrated[0].fill_price=1.38256
    store.upsert_virtual_order(hydrated[0])
    assert store.active_virtual_orders("USD/CAD")==[]
    with store.connect() as conn:
        assert conn.execute("select count(*) from shadow_virtual_orders").fetchone()[0]==1


def test_open_position_is_hydrated_and_closed_in_place(tmp_path):
    store=ShadowStore(tmp_path/"shadow_runtime.sqlite3");store.initialize()
    original=position();store.upsert_virtual_position(original)
    hydrated=store.active_virtual_positions("USD/CAD")
    assert len(hydrated)==1
    assert hydrated[0].position_id==original.position_id
    assert hydrated[0].status is VirtualPositionStatus.OPEN
    hydrated[0].status=VirtualPositionStatus.CLOSED
    hydrated[0].closed_at="2026-09-07T11:00:00Z"
    hydrated[0].close_price=1.38799
    store.upsert_virtual_position(hydrated[0])
    assert store.active_virtual_positions("USD/CAD")==[]
    with store.connect() as conn:
        assert conn.execute("select count(*) from shadow_virtual_trades").fetchone()[0]==1
