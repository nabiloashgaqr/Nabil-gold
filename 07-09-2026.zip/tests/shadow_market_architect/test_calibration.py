from shadow_market_architect.calibration import ShadowCalibrator,CalibrationAction,FinalReport

def m(day,n,total,wins=0):return {'metric_date':day,'symbol':'XAU/USD','horizon':'INTRADAY','playbook':'TREND_PULLBACK','family_count':n,'total_r':total,'win_count':wins}
def test_low_sample_never_generates_parameter_change():
 r=ShadowCalibrator({'min_families':30,'min_trading_days':10}).calibrate([m('2026-09-01',29,20)],[]);x=r.recommendations[0]
 assert x.action==CalibrationAction.INSUFFICIENT_DATA and x.bounded_changes=={} and r.ready_groups==0
def test_negative_adequate_group_is_review_only_and_bounded():
 rows=[m(f'2026-09-{i:02d}',3,-1,1) for i in range(1,11)];x=ShadowCalibrator().calibrate(rows,[]).recommendations[0]
 assert x.action==CalibrationAction.REVIEW and x.bounded_changes['automatic_deployment'] is False and x.bounded_changes['maximum_single_parameter_adjustment_percent']==10
def test_adequate_nonnegative_group_is_kept():
 rows=[m(f'2026-09-{i:02d}',3,1,2) for i in range(1,11)];assert ShadowCalibrator().calibrate(rows,[]).recommendations[0].action==CalibrationAction.KEEP
def test_gap_priorities_are_counted_without_modifying_rules():
 gaps=[{'gap_type':'MISSED_OPPORTUNITY'}]*4+[{'gap_type':'ENTRY_TIMING'}]
 r=ShadowCalibrator().calibrate([],gaps);assert r.gap_priorities[0]=={'gap_type':'MISSED_OPPORTUNITY','count':4,'priority':'HIGH'}
def test_final_report_states_shadow_only_and_insufficient_evidence():
 run=ShadowCalibrator().calibrate([m('2026-09-01',1,1)],[],generated_at='now');text=FinalReport().markdown(run,{'summary':{'closed_families':1}})
 assert 'NO AUTOMATIC CHANGES' in text and 'INSUFFICIENT_DATA' in text and 'statistical evidence gap' in text
def test_run_id_is_auditable_and_payload_serializable():
 r=ShadowCalibrator().calibrate([],[],generated_at='now');assert len(r.run_id)==32 and r.to_dict()['safeguards']
