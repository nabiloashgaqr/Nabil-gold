from dataclasses import FrozenInstanceError
import pytest

from shadow_market_architect.models import (
    Horizon, ScenarioSide, ScenarioSnapshot, ScenarioStatus, ShadowEvent,
)


def test_scenario_snapshot_is_immutable_and_ex_ante_timestamped():
    snap = ScenarioSnapshot(
        symbol="XAU/USD", side=ScenarioSide.BUY, horizon=Horizon.INTRADAY,
        playbook="TREND_PULLBACK", status=ScenarioStatus.WATCH,
        known_at="2026-09-05T10:00:00Z", evidence={"score": 65},
        config_version="phase1",
    )
    with pytest.raises(FrozenInstanceError):
        snap.status = ScenarioStatus.READY
    assert snap.to_dict()["side"] == "BUY"


def test_event_has_stable_identity_and_separate_known_recorded_times():
    event = ShadowEvent("OBSERVED", "WTI/USD", "2026-09-05T10:00:00Z")
    assert event.event_id
    assert event.known_at != ""
    assert event.recorded_at.endswith("Z")
