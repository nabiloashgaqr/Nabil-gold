from pathlib import Path
import pytest

from shadow_market_architect.safety import audit_file, audit_package

ROOT = Path(__file__).resolve().parents[2]


def test_real_shadow_package_has_no_execution_capability():
    audit_package(ROOT / "shadow_market_architect")


def test_forbidden_broker_import_is_detected(tmp_path):
    bad = tmp_path / "bad.py"
    bad.write_text("from services.mt5_executor import Mt5DemoExecutor\n", encoding="utf-8")
    assert audit_file(bad)


def test_forbidden_order_call_is_detected(tmp_path):
    bad = tmp_path / "bad.py"
    bad.write_text("broker.order_send({})\n", encoding="utf-8")
    assert "forbidden call .order_send()" in audit_file(bad)


def test_runner_contains_no_broker_or_production_database_imports():
    text = (ROOT / "scripts/run_shadow_market_architect.py").read_text(encoding="utf-8")
    assert "MetaTrader5" not in text
    assert "mt5_executor" not in text
    assert "database" not in text.lower()
