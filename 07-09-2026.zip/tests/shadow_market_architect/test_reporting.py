from shadow_market_architect.reporting import ShadowMetrics,ShadowReporter

def p(fid,r,side='BUY',play='TREND_PULLBACK',closed=True):
 return {'scenario_id':fid+'s','family_id':fid,'symbol':'XAU/USD','side':side,'horizon':'INTRADAY','playbook':play,'status':'CLOSED' if closed else 'OPEN','opened_at':'2026-09-05T10:00:00Z','closed_at':'2026-09-05T11:00:00Z' if closed else None,'realized_r':r,'closed_fraction':1,'events':[{'event':'TP1_PARTIAL'}]}
def test_metrics_are_family_deduplicated_and_closed_only():
 rows=[p('f1',1),p('f1',9),p('f2',-1),p('f3',3,closed=False)]
 m=ShadowMetrics({'min_sample_size':3}).calculate(rows,calculated_at='2026-09-05T12:00:00Z')[0]
 assert m.family_count==2 and m.win_count==1 and m.loss_count==1 and m.total_r==0 and m.expectancy_r==0
 assert m.profit_factor==1 and m.sample_quality=='LOW_SAMPLE'
def test_instrument_horizon_playbook_groups_stay_separate():
 a=p('a',1);b=p('b',2,play='BREAKOUT_RETEST');b['symbol']='WTI/USD';b['horizon']='SCALP'
 out=ShadowMetrics().calculate([a,b]);assert len(out)==2
def test_positive_only_profit_factor_is_explicit_none_not_fake_number():
 m=ShadowMetrics().calculate([p('a',1)])[0];assert m.profit_factor is None
def test_report_includes_gap_counts_summary_and_cautions():
 ms=ShadowMetrics().calculate([p('a',1)]);r=ShadowReporter().build(ms,[{'gap_type':'MISSED_OPPORTUNITY'},{'gap_type':'MISSED_OPPORTUNITY'}],generated_at='now')
 assert r['summary']['closed_families']==1 and r['gap_counts']['MISSED_OPPORTUNITY']==2 and r['family_deduplicated']
 text=ShadowReporter().markdown(r);assert 'LOW_SAMPLE' in text and 'Observational shadow results' in text
def test_empty_report_is_valid():
 r=ShadowReporter().build([],[]);assert r['summary']=={'closed_families':0,'total_r':0,'low_sample_groups':0}
