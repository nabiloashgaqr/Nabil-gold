"""R36-B (operator adoption 2026-09-08): TOP -> PENDING-AT-LEVEL redirect.

Law text (operator, verbatim meaning): when the live price already travelled
most of the move the agents measured -- from THEIR level toward THEIR target
-- entering at market is chasing the top. The order does not chase: it rests
as a pending LIMIT at the agents' own SMC/POI level under the R35 pending
laws (TTL, activation gates, touch veto), or it stands down as a recorded
WAIT when the level cannot host a lawful pending (too close, stop would
loosen, stop crosses the wrong side).

Scope mirrors R36-A exactly: only DIRECT market admissions are redirected.
PATH-9 sweep reversal and the scalp lanes are exempt by law; session-plan
ladder legs are exempt because R24 already forbids their market chase and
the ladder's own zone laws govern them (a converted leg carries the zone as
its entry band -- redirecting it backwards would resurrect the "map
published, price traded through, nothing placed" failure the market
conversion killed on 2026-08).

Ratchet doctrine is honoured: the redirected stop carries the SAME distance
the entry moves (preserve_planned_risk), never looser. If the execution
band clamp would loosen it, the redirect is refused and the signal stands
down as WAIT.

Fail-open posture: any exception, any missing level, any missing target ->
None (the market order proceeds). The boundary never crashes the cycle.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from utils.instruments import price_to_points

TOP_REDIRECT_DEFAULTS: Dict[str, Any] = {
    "enabled": True,
    # The operator's law: target-progress > 60% means the top is known;
    # market chasing is refused from there upward.
    "progress_threshold": 0.60,
    # A resting LIMIT this close to the live price is noise, not a level.
    "min_redirect_distance_points": 20.0,
    "exempt_paths": [
        "PATH_9_LIQUIDITY_SWEEP_REVERSAL",
        "PATH_7_SCALP_PREMIUM_FADE",
        "R25_SCALP",
    ],
    "exempt_entry_mode_prefixes": [
        "session_plan_ladder",
        "path4_smc_map_auction",
        "path9",
        "scalp",
    ],
    "stamp": "TOP_REDIRECT_AT_ENTRY",
    "description": (
        "R36-B (operator adoption 2026-09-08): price already past 60% of "
        "the agent-level->target move never takes a market fill. The entry "
        "rests as a pending LIMIT at the agents' own SMC/POI level under "
        "R35 pending laws, or stands down as a recorded WAIT. Planned risk "
        "distance is preserved exactly; a stop that would loosen refuses "
        "the redirect. Fail-open everywhere else."
    ),
}


def _f(value: Any, default: float = 0.0) -> float:
    try:
        out = float(value)
    except (TypeError, ValueError):
        return default
    return out


def _first_number(*values: Any) -> Optional[float]:
    for value in values:
        out = _f(value, 0.0)
        if out > 0:
            return out
    return None


def _resolve_agent_level(decision: Dict[str, Any], side: str) -> Optional[float]:
    """The price the agents themselves marked as the entry area.

    BUY rests at the TOP of the zone (first touch on the way back down);
    SELL rests at the BOTTOM (first touch on the way back up). Only
    structural sources count -- a MARKET signal's own entry band holds the
    live price, not a level, so it is never accepted here.
    """
    setup = decision.get("setup_context") or {}
    if not isinstance(setup, dict):
        setup = {}
    zone = setup.get("poi_zone") or {}
    if not isinstance(zone, dict):
        zone = {}
    low = _first_number(zone.get("low"), zone.get("bottom"), setup.get("poi_low"))
    high = _first_number(zone.get("high"), zone.get("top"), setup.get("poi_high"))
    smc = (decision.get("smc") or {}) if isinstance(decision.get("smc"), dict) else {}
    if side == "BUY":
        level = high or low
    else:
        level = low or high
    if level:
        return level
    # Scalar fallbacks some consensus setups publish directly.
    return _first_number(
        smc.get("entry_price"),
        setup.get("entry_price"),
        (setup.get("details") or {}).get("entry_price")
        if isinstance(setup.get("details"), dict) else None,
    )


def _select_target(signal: Dict[str, Any], side: str, level: float) -> Optional[float]:
    """Progress is measured against the NEAREST lawful target the agents set."""
    candidates = []
    for key in ("tp1", "tp2"):
        value = _f(signal.get(key), 0.0)
        if value <= 0:
            continue
        if side == "BUY" and value > level:
            candidates.append(value)
        elif side == "SELL" and value < level:
            candidates.append(value)
    if not candidates:
        return None
    return min(candidates, key=lambda t: abs(t - level))


def _structural_level(candles, side: str, lookback: int):
    """R38-C fallback: the agents' level when no numeric POI travelled with
    the decision. BUY rests on the PRE-leg swing HIGH (the level price
    broke out of); SELL on the pre-leg swing LOW. The most recent half of
    the window -- the impulse leg itself -- never counts as a rest level.
    """
    try:
        if not candles or not isinstance(candles, (list, tuple)):
            return None
        window = [c for c in candles[-lookback:] if isinstance(c, dict)]
        if len(window) < max(6, lookback // 2):
            return None
        older = window[:len(window) // 2]
        if not older:
            return None
        if side == "BUY":
            vals = [float(c.get("high") or 0.0) for c in older]
            best = max(vals) if vals else 0.0
        else:
            vals = [float(c.get("low") or 0.0) for c in older
                    if float(c.get("low") or 0.0) > 0]
            best = min(vals) if vals else 0.0
        return best if best > 0 else None
    except Exception:  # noqa: BLE001 - failure stays fail-open
        return None


def _leg_origin(candles, side: str, lookback: int):
    """R38: where the last impulse leg started -- the deepest low of the
    window for a rallying BUY, the highest high for a dropping SELL."""
    try:
        if not candles or not isinstance(candles, (list, tuple)):
            return None
        window = [c for c in candles[-lookback:] if isinstance(c, dict)]
        if len(window) < 3:
            return None
        if side == "BUY":
            vals = [float(c.get("low") or 0.0) for c in window
                    if float(c.get("low") or 0.0) > 0]
            origin = min(vals) if vals else 0.0
        else:
            vals = [float(c.get("high") or 0.0) for c in window]
            origin = max(vals) if vals else 0.0
        return origin if origin > 0 else None
    except Exception:  # noqa: BLE001
        return None


def top_pending_redirect_plan(
    decision: Dict[str, Any],
    config: Dict[str, Any],
    candles=None,
) -> Optional[Dict[str, Any]]:
    """Return the R36-B action for a decision standing at the order boundary.

    None              -> no redirect applies; proceed untouched (fail-open).
    {"action": "REDIRECT", ...} -> rest as pending LIMIT at the agents' level.
    {"action": "WAIT", "reason": ...} -> stand down; the chase is still refused.
    """
    try:
        cfg = dict(TOP_REDIRECT_DEFAULTS)
        cfg.update((config or {}).get("top_pending_redirect") or {})
        if not bool(cfg.get("enabled", True)):
            return None
        decision = decision or {}
        path_id = str(decision.get("execution_path_id") or "").upper()
        if any(str(x).upper() == path_id for x in (cfg.get("exempt_paths") or ())):
            return None
        entry_mode = str(decision.get("entry_mode") or "").lower()
        if any(str(p).lower() in entry_mode
               for p in (cfg.get("exempt_entry_mode_prefixes") or ())):
            return None
        signal = decision.get("signal") or {}
        if not isinstance(signal, dict):
            return None
        if signal.get("scale_in") or decision.get("golden_dual_entry"):
            return None
        order_type = str(
            decision.get("order_type") or signal.get("order_type") or ""
        ).upper()
        if not order_type.endswith("MARKET"):
            return None
        side = str(decision.get("decision") or signal.get("type") or "").upper()
        if side not in {"BUY", "SELL"}:
            return None
        entry_info = signal.get("entry") or {}
        if not isinstance(entry_info, dict):
            entry_info = {}
        current_price = _first_number(
            decision.get("current_price"),
            entry_info.get("current_price"),
            entry_info.get("price"),
        )
        if not current_price:
            return None
        symbol = str(decision.get("symbol") or (config or {}).get("symbol") or "")
        level = _resolve_agent_level(decision, side)
        lookback = int(cfg.get("leg_lookback_candles", 24) or 24)
        if not level and bool(cfg.get("level_fallback_enabled", True)):
            # R38-C: no numeric POI travelled with the decision -> derive
            # the lawful retest level from the chart structure itself.
            level = _structural_level(candles, side, lookback) or 0.0
        if not level:
            # No level anywhere -> nothing proves the top; fail open.
            return None
        if side == "BUY" and level >= current_price:
            return None  # price has not run past the level; not a chase
        if side == "SELL" and level <= current_price:
            return None
        target = _select_target(signal, side, level)
        if not target:
            return None  # no agents' target -> progress unknowable; fail open
        full_move = abs(target - level)
        travelled = abs(current_price - level)
        progress = travelled / full_move if full_move > 0 else 0.0
        threshold = float(cfg.get("progress_threshold", 0.60) or 0.60)
        chase_note = None
        if bool(cfg.get("leg_chase_enabled", True)) and progress <= threshold:
            # R38 (operator order 2026-09-09, live GBP/EUR market buys on the
            # pulse top at 07:02/06:51 UTC): measuring travelled vs the
            # FAR agents' target let literal top buys slip through at
            # ~40-50% progress. The chase law measures against the LEG
            # itself: once price has travelled >= leg_chase_progress (50%)
            # of the impulse leg running from its origin to now, a market
            # fill IS a top chase -- no matter how far the target was set.
            origin = _leg_origin(candles, side, lookback)
            if origin and level:
                # Direction sanity: a rallying leg must have begun BELOW the
                # live price (a dip entry is never a "top" chase), mirrored
                # for SELL. Without this a level below the window's lows
                # would fabricate a chase from thin air.
                leg_sane = (side == "BUY" and origin < current_price) or \
                           (side == "SELL" and origin > current_price)
                leg_size = abs(current_price - origin) if leg_sane else 0.0
                leg_progress = travelled / leg_size if leg_size > 0 else 0.0
                need = float(cfg.get("leg_chase_progress", 0.50) or 0.50)
                if leg_size > 0 and leg_progress >= need:
                    chase_note = (
                        "top-of-leg chase: %.0f%% of the last impulse leg "
                        "already travelled (law %.0f%%)"
                        % (leg_progress * 100.0, need * 100.0))
        if progress <= threshold and chase_note is None:
            return None
        stamp = str(cfg.get("stamp") or "TOP_REDIRECT_AT_ENTRY")
        redirect_pts = abs(price_to_points(current_price - level, symbol))
        min_pts = float(cfg.get("min_redirect_distance_points", 20.0) or 20.0)
        head = (
            f"{stamp}: price {progress * 100:.0f}% into the agents' "
            f"{level:.2f}->{target:.2f} move (law {threshold * 100:.0f}%)"
        )
        if chase_note:
            head = f"{head} | {chase_note}"
        if redirect_pts < min_pts:
            return {
                "action": "WAIT",
                "reason": (
                    f"{head}; level only {redirect_pts:.0f} pts away "
                    f"(< {min_pts:.0f}) cannot host a pending, and chasing "
                    f"is forbidden"
                ),
                "progress": round(progress, 4),
                "level": level,
                "target": target,
            }
        old_stop = _f(signal.get("stop_loss"), 0.0)
        if old_stop <= 0:
            return {
                "action": "WAIT",
                "reason": f"{head}; market leg carries no mapped stop to "
                          f"preserve",
                "progress": round(progress, 4),
                "level": level,
                "target": target,
            }
        # preserve_planned_risk: the stop travels the same distance the entry
        # does, so the redirected leg risks EXACTLY what the market leg would.
        delta = abs(current_price - level)
        new_stop = old_stop - delta if side == "BUY" else old_stop + delta
        wrong_side = (new_stop >= level) if side == "BUY" else (new_stop <= level)
        if wrong_side:
            return {
                "action": "WAIT",
                "reason": (
                    f"{head}; preserved-risk stop {new_stop:.2f} crosses the "
                    f"level {level:.2f} - pending cannot rest protected"
                ),
                "progress": round(progress, 4),
                "level": level,
                "target": target,
            }
        planned_risk = abs(current_price - old_stop)
        return {
            "action": "REDIRECT",
            "order_type": f"{side}_LIMIT",
            "entry_price": level,
            "stop_loss": new_stop,
            "planned_risk_price": planned_risk,
            "distance_points": redirect_pts,
            "progress": round(progress, 4),
            "level": level,
            "target": target,
            "reason": (
                f"{head}; entry rests as {side}_LIMIT at the agents' level "
                f"{level:.2f} under R35 pending laws, planned risk "
                f"{planned_risk:.2f} preserved (stop {old_stop:.2f} -> "
                f"{new_stop:.2f})"
            ),
        }
    except Exception:  # noqa: BLE001 - the entry boundary never crashes
        return None
