# -*- coding: utf-8 -*-
"""services/regime_switcher.py — central market-environment ROUTER (R25.8).

Closes the structural gap the audit named: the tree had regime *signals*
scattered across agents (ADX inside the scalp gate, the D1 classify_regime
RANGE gate, ATR spike guards, news blackout windows) but no single switch that
looks at the market once per cycle and decides WHICH strategies are allowed to
fire. This is that switch — a routing layer, not another indicator.

Three environments:
  * TREND            — directional; continuation/consensus setups are allowed.
  * RANGE            — mean-reversion / fade only; trend-continuation gated.
  * HIGH_VOL_NEWS    — a news/explosion window (or an extreme ATR spike):
                       normal entries stand down; only the news-leg re-arm and
                       the sweep-raid reversal (PATH 9) are permitted.

Output contract
---------------
resolve_regime(signals, config) -> {
    "regime": "TREND" | "RANGE" | "HIGH_VOL_NEWS" | "INSUFFICIENT_DATA",
    "sub_state": "TREND_UP" | "TREND_DOWN" | None,
    "confidence": float,
    "admit_paths": [...], "block_paths": [...],
    "reasons": [...], "inputs": {...},
}

admit_paths / block_paths come from config["regime_switcher"].path_policy so the
operator can re-map them without code changes. The DEFAULTS below encode the
auditor's intended routing.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

REGIME_TREND = "TREND"
REGIME_RANGE = "RANGE"
REGIME_HIGH_VOL_NEWS = "HIGH_VOL_NEWS"
REGIME_UNKNOWN = "INSUFFICIENT_DATA"

#: Path ids (the PATH_* constants are imported lazily to avoid a cycle).
_DEFAULTS: Dict[str, Any] = {
    "enabled": True,
    "adx_trend_floor": 25.0,        # ADX at/above => directional
    "adx_range_ceiling": 20.0,      # ADX below => range (20-25 = hysteresis band)
    "news_blackout_active": True,   # an open news window forces HIGH_VOL_NEWS
    "atr_spike_multiple": 3.0,      # ATR >= 3x its recent baseline => high-vol
    "path_policy": {
        # Continuation / consensus / two-agent / OTE / reinforcement.
        REGIME_TREND: ["PATH_1", "PATH_2", "PATH_3", "PATH_5", "PATH_6",
                       "PATH_8", "PATH_9"],
        # Range: consensus, the SMC auction map, the premium-fade scalp and
        # the sweep-raid reversal (a fade). Two-agent continuation stands down.
        REGIME_RANGE: ["PATH_1", "PATH_4", "PATH_7", "PATH_9"],
        # News/explosion: only the news-leg re-arm (PATH 6 pre-arm) and the
        # sweep-raid reversal; market/limit trend entries stand down.
        REGIME_HIGH_VOL_NEWS: ["PATH_6", "PATH_9"],
    },
    "description": (
        "R25.8 (2026-08-29): المبدّل المركزي للبيئة. TREND يسمح بمسارات "
        "الاتجاه/الإجماع، RANGE يحصر التداول في الفايد (4/7/9)، ونافذة الخبر "
        "أو انفجار ATR ترفع HIGH_VOL_NEWS فلا يبقى إلا ساق-الخبر (6) والمسار 9."
    ),
}

ALL_PATHS = ["PATH_1", "PATH_2", "PATH_3", "PATH_4", "PATH_5",
             "PATH_6", "PATH_7", "PATH_8", "PATH_9"]


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def config_block(config: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    out = {k: (dict(v) if isinstance(v, dict) else v) for k, v in _DEFAULTS.items()}
    raw = ((config or {}).get("regime_switcher") or {})
    if isinstance(raw, dict):
        for key, val in raw.items():
            if key == "description":
                continue
            if key == "path_policy" and isinstance(val, dict):
                merged = dict(out["path_policy"])
                merged.update(val)
                out["path_policy"] = merged
            else:
                out[key] = val
    return out


def _normalise_path_prefixes(paths: List[str]) -> List[str]:
    """Accept either 'PATH_1' or a full path id; normalise to the PATH_n token."""
    out = set()
    for p in paths or []:
        token = str(p or "")
        for n in range(1, 10):
            if token.startswith(f"PATH_{n}") or token == f"PATH_{n}":
                out.add(f"PATH_{n}")
                break
    return sorted(out, key=lambda t: int(t.split("_")[1]))


def resolve_regime(signals: Optional[Dict[str, Any]],
                   config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Decide the environment from already-computed agent/feed signals.

    `signals` is a plain dict (pure, no I/O). Recognised keys, all optional:
      * d1_regime: the market_regime.classify_regime payload
        {"regime": "TREND_UP|TREND_DOWN|RANGE", "adx": .., "vol_label": ..}
      * intraday: {"adx": float, "market_phase": "RANGING|TRENDING"|".."}
      * atr: {"atr": float, "baseline": float}  (or "multiple")
      * news: {"blackout": bool, "event": str, "minutes_to_event": float}
      * volatility: {"regime": "HIGH|NORMAL|LOW"} (volatility_agent)
    """
    cfg = config_block(config)
    signals = signals or {}
    reasons: List[str] = []

    if not bool(cfg.get("enabled", True)):
        return {"regime": REGIME_UNKNOWN, "sub_state": None, "confidence": 0.0,
                "admit_paths": list(ALL_PATHS), "block_paths": [],
                "reasons": ["regime_switcher_disabled"], "inputs": signals}

    d1 = signals.get("d1_regime") or {}
    intra = signals.get("intraday") or {}
    atr = signals.get("atr") or {}
    news = signals.get("news") or {}
    vol = signals.get("volatility") or {}

    d1_label = str(d1.get("regime") or "").upper()
    d1_adx = _f(d1.get("adx"))
    intra_adx = _f(intra.get("adx"))
    phase = str(intra.get("market_phase") or "").upper()
    adx = max(d1_adx, intra_adx) if (d1_adx or intra_adx) else 0.0

    # ── 1) NEWS / high-volatility override (highest priority) ─────────────
    news_blackout = bool(news.get("blackout", False)) and bool(cfg.get("news_blackout_active", True))
    atr_multiple = _f(atr.get("multiple"))
    if atr_multiple <= 0 and _f(atr.get("atr")) > 0 and _f(atr.get("baseline")) > 0:
        atr_multiple = _f(atr.get("atr")) / _f(atr.get("baseline"))
    atr_spike = atr_multiple >= _f(cfg.get("atr_spike_multiple"), 3.0)
    vol_high = str(vol.get("regime") or "").upper() == "HIGH"

    if news_blackout:
        reasons.append(f"news_blackout:{news.get('event') or 'event'}")
    if atr_spike:
        reasons.append(f"atr_spike_x{atr_multiple:.1f}")
    if news_blackout or (atr_spike and vol_high):
        regime = REGIME_HIGH_VOL_NEWS
        confidence = 85.0 if news_blackout else 70.0
        sub = None
    else:
        # ── 2) trend vs range ─────────────────────────────────────────────
        floor = _f(cfg.get("adx_trend_floor"), 25.0)
        ceiling = _f(cfg.get("adx_range_ceiling"), 20.0)
        if d1_label.startswith("TREND") or adx >= floor or phase == "TRENDING":
            regime = REGIME_TREND
            sub = "TREND_UP" if ("UP" in d1_label or d1_adx == 0 and phase == "TRENDING") else (
                "TREND_DOWN" if "DOWN" in d1_label else None)
            confidence = round(min(90.0, max(adx, 25.0) * 1.4), 1)
            reasons.append(f"adx={adx:.0f}>={floor:.0f}" if adx else "phase=TRENDING")
        elif d1_label == "RANGE" or adx < ceiling or phase == "RANGING" or adx == 0:
            regime = REGIME_RANGE
            sub = None
            confidence = round(min(80.0, (ceiling - adx) * 2.0 + 45.0), 1) if adx else 40.0
            reasons.append(f"adx={adx:.0f}<{ceiling:.0f}" if adx else "phase=RANGING/weak")
        else:
            # Hysteresis band between ceiling and floor: defer to D1 label.
            regime = REGIME_TREND if d1_label.startswith("TREND") else REGIME_RANGE
            sub = "TREND_UP" if regime == REGIME_TREND and "UP" in d1_label else (
                "TREND_DOWN" if regime == REGIME_TREND and "DOWN" in d1_label else None)
            confidence = 45.0
            reasons.append(f"hysteresis_band adx={adx:.0f}")

    policy = cfg.get("path_policy") or {}
    admit = _normalise_path_prefixes(policy.get(regime, []))
    block = [p for p in ALL_PATHS if p not in admit]
    return {
        "regime": regime,
        "sub_state": sub,
        "confidence": confidence,
        "admit_paths": admit,
        "block_paths": block,
        "reasons": reasons,
        "inputs": {"adx": round(adx, 1), "d1": d1_label or None,
                   "phase": phase or None, "atr_multiple": round(atr_multiple, 2),
                   "news_blackout": news_blackout, "vol_high": vol_high},
    }


def path_admitted(decision: Dict[str, Any], regime_decision: Dict[str, Any]) -> bool:
    """True if the decision's stamped path is allowed by the regime."""
    pid = str(decision.get("execution_path_id")
              or (decision.get("execution_path") or {}).get("id") or "")
    for n in range(1, 10):
        if pid.startswith(f"PATH_{n}"):
            return f"PATH_{n}" in regime_decision.get("admit_paths", [])
    # No stamped path (legacy / WAIT): do not block on routing grounds.
    return True


def _enforce(config: Optional[Dict[str, Any]]) -> bool:
    """regime_switcher.enforce (default True). When False the switch is
    ADVISORY: it stamps the regime onto every decision (and Telegram shows it)
    but never downgrades a BUY/SELL - all nine paths stay live."""
    block = (config or {}).get("regime_switcher") or {}
    return bool(block.get("enforce", True))


def regime_opinion_line(regime_decision: Optional[Dict[str, Any]],
                        config: Optional[Dict[str, Any]] = None) -> str:
    """A single Telegram/card line describing the environment verdict.

    R36-D (operator order 2026-09-08): cards are for a fast eye. The default
    is now the compact ENGLISH form of ONE-TWO words, and only flips back
    to the old verbose Arabic when regime_switcher.opinion_style is set to
    "arabic_full". Advisory/enforced status stays OUT of the card (it is a
    system fact, not a signal verdict)."""
    if not regime_decision:
        return ""
    regime = str(regime_decision.get("regime") or "?")
    sub = regime_decision.get("sub_state")
    style = str(((config or {}).get("regime_switcher") or {})
                .get("opinion_style", "compact_en")).lower()
    if style == "compact_en":
        emoji = {"TREND": "\U0001F4C8", "RANGE": "\U0001F501",
                 "HIGH_VOL_NEWS": "\U0001F6A8",
                 "INSUFFICIENT_DATA": "\u26AA"}.get(regime, "\U0001F9ED")
        label = "NO-DATA" if regime == "INSUFFICIENT_DATA" else regime
        arrow = ""
        if regime == "TREND" and sub:
            arrow = "-UP" if str(sub).endswith("UP") else \
                    "-DOWN" if str(sub).endswith("DOWN") else ""
        return "%s %s%s" % (emoji, label, arrow)
    conf = regime_decision.get("confidence")
    admitted = regime_decision.get("admit_paths") or []
    emoji = {"TREND": "📈", "RANGE": "🔁", "HIGH_VOL_NEWS": "🚨",
             "INSUFFICIENT_DATA": "⚪"}.get(regime, "🧭")
    label = {"TREND": "اتجاهي", "RANGE": "عرضي/نطاق",
             "HIGH_VOL_NEWS": "خبر/تقلب عالٍ",
             "INSUFFICIENT_DATA": "بيانات غير كافية"}.get(regime, regime)
    sub_txt = ""
    if sub:
        sub_txt = " ↑" if str(sub).endswith("UP") else " ↓" if str(sub).endswith("DOWN") else ""
    enforced = _enforce(config)
    if enforced:
        paths = "،".join(p.replace("PATH_", "") for p in admitted) or "—"
        tail = f"المسارات المسموحة: {paths}"
    else:
        tail = "استشاري — لا يحجب أي مسار (تحت المراقبة)"
    conf_txt = f" ثقة {conf:.0f}%" if isinstance(conf, (int, float)) and conf else ""
    reasons = regime_decision.get("reasons") or []
    why = f" ({', '.join(str(r) for r in reasons[:2])})" if reasons else ""
    return f"{emoji} البيئة: {label}{sub_txt}{conf_txt}{why} — {tail}"


def apply_regime_switch(decision: Dict[str, Any],
                        regime_decision: Dict[str, Any],
                        config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Apply the central regime verdict to a finished decision.

    Always stamps ``regime_switch_state`` (the verdict + an advisory/enforced
    flag) so cards and Telegram can show the environment. When the switch is
    ENFORCED it downgrades a BUY/SELL whose path is not in the regime's admit
    set to WAIT; in ADVISORY mode (``regime_switcher.enforce=false``) it stamps
    and never downgrades - every path stays live. Post-decision, fail-open by
    contract (the caller wraps this in try/except).
    """
    signal = str(decision.get("decision") or decision.get("signal") or "").upper()
    decision = dict(decision)
    decision["regime_switch_state"] = {
        "regime": regime_decision.get("regime"),
        "sub_state": regime_decision.get("sub_state"),
        "confidence": regime_decision.get("confidence"),
        "admit_paths": regime_decision.get("admit_paths"),
        "enforced": _enforce(config),
        "reasons": regime_decision.get("reasons"),
        "opinion_line": regime_opinion_line(regime_decision, config),
    }
    if signal not in {"BUY", "SELL"}:
        return decision
    if not _enforce(config):
        return decision  # advisory: never downgrade
    if path_admitted(decision, regime_decision):
        return decision
    pid = str(decision.get("execution_path_id") or "UNSTAMPED")
    regime = regime_decision.get("regime")
    decision = dict(decision)
    decision["decision"] = "WAIT"
    decision["confidence"] = 0
    decision["signal"] = {}
    decision["regime_switch"] = {
        "applied": True,
        "regime": regime,
        "blocked_path": pid,
        "admit_paths": regime_decision.get("admit_paths"),
        "reason": f"{regime}: path {pid} not in the regime's admit set",
    }
    decision["warnings"] = list(decision.get("warnings") or []) + [
        f"REGIME_SWITCH: {pid} downgraded to WAIT in {regime}"
    ]
    return decision
