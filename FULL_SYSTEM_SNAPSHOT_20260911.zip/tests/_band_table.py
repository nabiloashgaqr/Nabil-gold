# -*- coding: utf-8 -*-
"""Final per-symbol stop-law table: XAU x1, WTI x0.5, FX x1.5."""
from __future__ import annotations
FLOOR={"XAU/USD":270,"WTI/USD":135,"EUR/USD":405,"GBP/USD":405,"USD/CAD":405,"USD/JPY":540}
CAP={"XAU/USD":400,"WTI/USD":200,"EUR/USD":600,"GBP/USD":600,"USD/CAD":600,"USD/JPY":800}
NOISE={"XAU/USD":200,"WTI/USD":100,"EUR/USD":300,"GBP/USD":300,"USD/CAD":300,"USD/JPY":400}
BUFFER={s:FLOOR[s]-NOISE[s] for s in FLOOR}
FIVE=("WTI/USD","EUR/USD","GBP/USD","USD/CAD","USD/JPY")
SIX=("XAU/USD",)+FIVE
REF_PRICE={"XAU/USD":4580.61,"WTI/USD":61.50,"EUR/USD":1.15852,"GBP/USD":1.35404,"USD/CAD":1.39022,"USD/JPY":154.20}
def floor_cap(symbol:str)->tuple[float,float]: return float(FLOOR[symbol]),float(CAP[symbol])
