@echo off
setlocal
echo ============================================================
echo  R43 - trailing card truthfulness + WTI zone 40 -^> 60
echo  Card:  "locking about +X" only when the stop is BLって
echo  the entry on the profit side; otherwise the card states
echo  the open risk honestly (SELL 4418.79 -^> SL 4443.79 will
echo  now read "still 249 pts of risk", not "+250 locking").
echo  Zone:  WTI/USD zone-touch watch = 60 WTI points from now
echo  on (gold stays 80; FX ratios untouched), one resolver at
echo  utils/trading_rules.py feeding both engine and cards.
echo ============================================================
cd /d "%~dp0"
if not exist tests\witnesses mkdir tests\witnesses
copy /y files\services\telegram_bot.py services\ >nul
copy /y files\scripts\run_tick_manager.py scripts\ >nul
copy /y files\utils\trading_rules.py utils\ >nul
copy /y files\apply_r43_wti_zone_60.py scripts\config_mergers\ >nul
copy /y files\tests\witnesses\test_r43_card_and_zone.py tests\witnesses\ >nul
copy /y files\tests\test_tick_zone_touch_conversion.py tests\ >nul
python scripts\config_mergers\apply_r43_wti_zone_60.py
python -m pytest tests\witnesses\test_r43_card_and_zone.py -q
echo.
echo [R43] Expected: 5 passed. Restart analysis + tick-manager services.
pause
