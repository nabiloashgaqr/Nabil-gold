# -*- coding: utf-8 -*-
"""R43 merger: WTI zone-touch watch width 40 -> 60 (operator order 2026-09-09).

The zone-touch law keeps its single source: gold base 80 x canonical ratio.
The operator overrides WTI to 60 points of ITS OWN (not a global width,
not the ratio shared with stops/clutches). Resolved at both consumers:
the tick-native converter (run_tick_manager) and the card mirror
(telegram_bot) via utils.trading_rules.zone_touch_width_points.
Backup first; idempotent.
"""
from __future__ import annotations

import io
import json
import shutil
from datetime import datetime, timezone

CFG = "config.json"


def main() -> None:
    cfg = json.load(io.open(CFG, encoding="utf-8"))
    zcfg = (cfg.setdefault("order_execution", {})
              .setdefault("zone_touch_activation", {}))
    ov = zcfg.setdefault("zone_width_points_overrides", {})
    if float(ov.get("WTI/USD", 0) or 0) == 60.0:
        print("[R43] WTI zone override already 60 - nothing to do")
        return
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup = f"config.backup_r43_{stamp}.json"
    shutil.copyfile(CFG, backup)
    ov["WTI/USD"] = 60.0
    zcfg["description_zone_width_points_overrides"] = (
        "R43 2026-09-09 operator order: WTI zone-touch watch 40 -> 60 WTI "
        "points; per-symbol overrides take precedence over the canonical "
        "base(80) x distance_ratio law at BOTH consumers")
    io.open(CFG, "w", encoding="utf-8").write(
        json.dumps(cfg, indent=2, ensure_ascii=False) + "\n")
    print(f"[R43] WTI override set (backup: {backup})")
    print("[R43] gold stays 80; every other ratio untouched")


if __name__ == "__main__":
    main()
