"""Tick-native, broker-first zone-touch LIMIT -> MARKET conversion."""
from __future__ import annotations
import json, types
from pathlib import Path

from scripts.run_tick_manager import TickManager, zone_touch_tick_decision, zone_rr_floor_decision
from services.mt5_executor import magic_for

ROOT = Path(__file__).resolve().parents[1]


def _cfg():
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    cfg.setdefault("auction_flow", {})["enabled"] = False
    return cfg


class DB:
    def __init__(self): self.updates = []
    def update_trade(self, tid, updates): self.updates.append((tid, updates))


class Executor:
    def __init__(self, tid, *, cancel_ok=True, send_ok=True):
        self.magic = magic_for(tid); self.cancel_ok = cancel_ok; self.send_ok = send_ok
        self.order = types.SimpleNamespace(ticket=629295075, magic=self.magic)
        self.pos = None; self.last_order = {}; self.calls = []; self.applied = None
    def _order_by_magic(self, magic): return self.order if magic == self.magic else None
    def _position_by_magic(self, magic): return self.pos if magic == self.magic else None
    def cancel_order(self, ticket):
        self.calls.append(("cancel", ticket))
        if self.cancel_ok: self.order = None
        return self.cancel_ok
    def ensure_ticket(self, tid, side, kind, entry, sl, tp, symbol):
        self.calls.append(("send", kind, sl, tp))
        if not self.send_ok: return None
        px = self.market_price
        self.pos = types.SimpleNamespace(ticket=7001, price_open=px, volume=0.1, sl=sl, tp=tp)
        self.last_order = {"price": px, "volume": 0.1}
        return 7001
    def apply_stop(self, tid, sl, tp, symbol):
        self.applied = (sl, tp); return True


def _row(side="SELL"):
    return {
        "id": "gold-4478", "status": "PENDING", "type": side,
        "symbol": "XAU/USD", "order_type": f"{side}_LIMIT",
        "entry_price": 4478.67, "stop_loss": 4508.67 if side == "SELL" else 4448.67,
        "tp1": 4448.67 if side == "SELL" else 4508.67,
        "tp2": 4418.67 if side == "SELL" else 4538.67,
        "tp3": 4388.67 if side == "SELL" else 4568.67,
        "mt5_ticket": 629295075, "signal_snapshot": {"pending_runtime": {}},
    }


def test_total_zone_is_80_points_and_near_miss_does_not_arm():
    d = zone_touch_tick_decision("SELL", 4474.60, 4478.67, .1, armed=False)
    assert round(d["zone_low"], 2) == 4474.67
    assert round(d["zone_high"], 2) == 4482.67
    assert not d["armed"] and not d["activate"]


def test_sell_arms_on_one_tick_and_converts_on_next_exit_tick():
    db, row = DB(), _row("SELL")
    tm, ex = TickManager(_cfg(), database=db), Executor(row["id"])
    ex.market_price = 4474.60
    assert not tm._zone_touch_convert(row, types.SimpleNamespace(bid=4475.00, ask=4475.20), ex, "SELL", ex.magic)
    assert row["signal_snapshot"]["pending_runtime"]["zone_touch_armed"] is True
    assert tm._zone_touch_convert(row, types.SimpleNamespace(bid=4474.60, ask=4474.80), ex, "SELL", ex.magic)
    assert [c[0] for c in ex.calls] == ["cancel", "send"]
    assert row["status"] == "OPEN" and row["entry_price"] == 4474.60
    assert row["stop_loss"] == 4504.60
    assert row["tp1"] == 4444.60 and row["tp2"] == 4414.60
    assert ex.applied == (4504.60, 4414.60)


def test_buy_is_direction_symmetric():
    d1 = zone_touch_tick_decision("BUY", 4481.0, 4478.67, .1)
    d2 = zone_touch_tick_decision("BUY", 4482.70, 4478.67, .1, armed=d1["armed"])
    assert d1["armed"] and not d1["activate"]
    assert d2["activate"]


def test_cancel_failure_never_sends_market_or_marks_open():
    db, row = DB(), _row("SELL")
    row["signal_snapshot"]["pending_runtime"]["zone_touch_armed"] = True
    tm, ex = TickManager(_cfg(), database=db), Executor(row["id"], cancel_ok=False)
    ex.market_price = 4474.60
    assert tm._zone_touch_convert(row, types.SimpleNamespace(bid=4474.60, ask=4474.80), ex, "SELL", ex.magic)
    assert [c[0] for c in ex.calls] == ["cancel"]
    assert row["status"] == "PENDING"
    assert row["signal_snapshot"]["pending_runtime"]["zone_conversion_blocked"] == "broker cancel failed"


def test_market_send_failure_stays_pending_after_confirmed_cancel():
    db, row = DB(), _row("SELL")
    row["signal_snapshot"]["pending_runtime"]["zone_touch_armed"] = True
    tm, ex = TickManager(_cfg(), database=db), Executor(row["id"], send_ok=False)
    ex.market_price = 4474.60
    tm._zone_touch_convert(row, types.SimpleNamespace(bid=4474.60, ask=4474.80), ex, "SELL", ex.magic)
    assert [c[0] for c in ex.calls] == ["cancel", "send"]
    assert row["status"] == "PENDING"
    assert row["signal_snapshot"]["pending_runtime"]["zone_pending_cancelled"] is True


def test_zone_width_scales_from_gold_base_per_instrument():
    cases = [
        ("XAU/USD", 4478.67, 4478.67, 80.0, 4474.67, 4482.67),
        # R43 (operator order 2026-09-09): WTI zone 40 -> 60 via the
        # per-symbol override (the canonical 80 x 0.5 ratio superseded
        # for WTI only, by operator order; all other instruments ride
        # the ratio unchanged).
        ("WTI/USD", 87.50, 87.50, 60.0, 87.20, 87.80),
        ("EUR/USD", 1.17500, 1.17500, 120.0, 1.17440, 1.17560),
        ("USD/JPY", 147.500, 147.500, 160.0, 147.420, 147.580),  # R33.5: zone = 80 x 2.0
    ]
    for symbol, entry, price, width, low, high in cases:
        db = DB()
        row = _row("SELL")
        row.update(symbol=symbol, entry_price=entry)
        tm, ex = TickManager(_cfg(), database=db), Executor(row["id"])
        tm._zone_touch_convert(
            row, types.SimpleNamespace(bid=price, ask=price), ex, "SELL", ex.magic)
        runtime = row["signal_snapshot"]["pending_runtime"]
        assert runtime["zone_touch_width_points"] == width
        assert runtime["zone_touch_low"] == low
        assert runtime["zone_touch_high"] == high


def test_live_xau_150r_rounding_does_not_block_tick_conversion():
    """Regression for ticket 641958276: 404.9/270 is the rounded 1.50R plan."""
    db = DB()
    row = {
        "id": "TRADE_20260907_121108_440632_c3a3bd1c",
        "status": "PENDING", "type": "SELL", "symbol": "XAU/USD",
        "order_type": "SELL_LIMIT", "entry_price": 4411.07,
        "stop_loss": 4438.07, "tp1": 4390.82, "tp2": 4370.58,
        "mt5_ticket": 641958276,
        "signal_snapshot": {"pending_runtime": {"zone_touch_armed": True}},
    }
    tm, ex = TickManager(_cfg(), database=db), Executor(row["id"])
    ex.order.ticket = 641958276
    ex.market_price = 4407.06

    assert tm._zone_touch_convert(
        row, types.SimpleNamespace(bid=4407.06, ask=4407.24),
        ex, "SELL", ex.magic)
    assert [c[0] for c in ex.calls] == ["cancel", "send"]
    assert row["status"] == "OPEN"
    runtime = row["signal_snapshot"]["pending_runtime"]
    assert runtime["zone_rr_raw"] < 1.5
    assert runtime["zone_rr_floor_passed"] is True
    assert runtime["zone_rr_rounding_tolerance_points"] == 1.0


def test_rr_tolerance_is_only_one_point_and_direction_symmetric():
    # 0.1 point short passes; 1.1 points short remains blocked.
    for stop, target_near, target_far in (
        (4438.07, 4370.58, 4370.68),  # SELL
        (4384.07, 4451.56, 4451.46),  # BUY
    ):
        assert zone_rr_floor_decision(4411.07, stop, target_near, .1, 1.5)["allow"]
        assert not zone_rr_floor_decision(4411.07, stop, target_far, .1, 1.5)["allow"]


def test_operator_zone_floor_is_one_r_without_relaxing_material_shortfall():
    exact = zone_rr_floor_decision(4411.07, 4438.07, 4384.07, .1, 1.0)
    below = zone_rr_floor_decision(4411.07, 4438.07, 4384.18, .1, 1.0)
    assert exact["allow"] is True
    assert below["allow"] is False


def test_config_records_canonical_zone_ratios_in_english():
    z = _cfg()["order_execution"]["zone_touch_activation"]
    assert z["zone_width_points"] == 80
    desc = z["description_zone_width_scaling"]
    assert "XAU x1.0" in desc and "WTI x0.5" in desc and "FX x1.5" in desc
