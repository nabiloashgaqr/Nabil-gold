# -*- coding: utf-8 -*-
"""R43 witnesses - TRAILING card truthfulness + WTI zone = 60 (2026-09-09).

1) The trailing card printed "locking about +250 pts" for a SELL whose new
   stop (4443.79) still sits 250 pts ABOVE the entry (4418.79) - pure risk.
   After R43 the card tells the truth: lock claims only on the protected
   side; otherwise it states the open risk.
2) Operator order: the WTI zone-touch watch widens from 40 (=80x0.5) to 60
   WTI points; a per-symbol override in ONE resolver feeds BOTH consumers
   (tick-native converter + card mirror).

Witness list:
  W1 SELL trailing card: stop above entry -> "still 249 pts of risk", and
     the word "locking" does NOT appear
  W2 BUY protected: stop above entry -> locking line still produced
  W3 resolver: WTI -> 60 after the merger; XAU -> 80; EURUSD -> 120
  W4 both consumers call the one resolver (source integrity)
  W5 live config carries the WTI/USD 60 override after the merger
"""
from __future__ import annotations

import json
import os


# ---------------------- W1/W2: the card's New SL line --------------------
def _trailing_card_lines(side: str, entry: float, stop: float) -> list[str]:
    """Run send_trade_events with a stubbed stream and capture the lines."""
    from services.telegram_bot import TelegramService
    import utils.helpers as uh

    bot = TelegramService(config={"telegram": {},
                                  "instruments": [{"symbol": "XAU/USD",
                                                   "point_size": 0.1}]})
    captured: list[str] = []
    bot.send_message = lambda text, urgent=False: (captured.append(text) or True)

    trade = {"id": "T", "symbol": "XAU/USD", "type": side,
             "entry_price": entry, "status": "OPEN"}
    evaluation = {"updates": {"stop_loss": stop}, "old_status": "OPEN",
                  "new_status": "OPEN"}
    bot.send_trade_events(trade, ["TRAILING_SL_UPDATED"], 4415.53, 32.6,
                          evaluation)
    return captured


def test_w1_sell_card_tells_risk_not_lock() -> None:
    msgs = _trailing_card_lines("SELL", 4418.79, 4443.79)
    joined = "\n".join(msgs)
    assert "New SL" in joined
    assert "locking" not in joined, (
        "R43: a stop ABOVE a SELL entry must not claim a profit lock")
    assert "249" in joined or "250" in joined, joined


def test_w2_buy_protected_card_still_locks() -> None:
    msgs = _trailing_card_lines("BUY", 4400.00, 4410.00)
    joined = "\n".join(msgs)
    assert "locking" not in joined.replace("unlocking", "x") or True
    assert "New SL" in joined
    # entry 4400, stop 4410 -> 100 xau pts locked
    assert ("locking about +100" in joined), joined


# ---------------------- W3: the resolver (single source) -----------------
def test_w3_resolver_values() -> None:
    from utils.trading_rules import zone_touch_width_points
    cfg = {"order_execution": {"zone_touch_activation": {
        "zone_width_points": 80,
        "zone_width_points_overrides": {"WTI/USD": 60.0}}}}
    assert zone_touch_width_points(cfg, "WTI/USD") == 60.0
    assert zone_touch_width_points(cfg, "WTIUSD") == 60.0
    assert zone_touch_width_points(cfg, "XAU/USD") == 80.0
    assert zone_touch_width_points(cfg, "EUR/USD") == 120.0


# ---------------------- W4: both consumers wired --------------------------
def test_w4_consumers_call_one_resolver() -> None:
    root = os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))))
    tm = open(os.path.join(root, "scripts", "run_tick_manager.py"),
              encoding="utf-8").read()
    tg = open(os.path.join(root, "services", "telegram_bot.py"),
              encoding="utf-8").read()
    assert "zone_touch_width_points" in tm, "engine must call the resolver (allow _zt_width alias)"
    assert "zone_touch_width_points(" in tg, "card must call the resolver"


# ---------------------- W5: artifact witness ------------------------------
def test_w5_live_config_has_wti_override_60() -> None:
    cfg = json.load(open(os.path.join(os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__)))), "config.json"),
        encoding="utf-8"))
    ov = (((cfg.get("order_execution") or {})
           .get("zone_touch_activation") or {})
          .get("zone_width_points_overrides") or {})
    assert float(ov.get("WTI/USD", 0) or 0) == 60.0, (
        "R43: run scripts/config_mergers/apply_r43_wti_zone_60.py")
