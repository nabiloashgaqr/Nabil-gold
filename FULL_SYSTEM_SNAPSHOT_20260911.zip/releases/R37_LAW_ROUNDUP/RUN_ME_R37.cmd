@echo off
setlocal
echo ============================================================
echo  R37 LAW ROUNDUP INSTALLER -- one double click, idempotent
echo  Syncs 4 law-repaired files + tests, then proves them.
echo  Touches: scripts/services/tests only. Never accounts/MT5/config.
echo ============================================================
cd /d "%~dp0"
echo [1/4] backup .bak.r37
for %%f in (scripts\run_tick_manager.py services\pre_arm_ote.py scripts\enrich_trade.py scripts\backfill_trade_enrichment.py) do (
  copy /y %%f %%f.bak.r37 >nul
)
echo [2/4] sync law files
copy /y files\scripts\run_tick_manager.py scripts\run_tick_manager.py >nul
copy /y files\scripts\enrich_trade.py scripts\enrich_trade.py >nul
copy /y files\scripts\backfill_trade_enrichment.py scripts\backfill_trade_enrichment.py >nul
copy /y files\services\pre_arm_ote.py services\pre_arm_ote.py >nul
copy /y files\tests\test_r37_law_roundup.py tests\test_r37_law_roundup.py >nul
copy /y files\tests\test_mt5_execution_correctness.py tests\test_mt5_execution_correctness.py >nul
echo [3/4] compile gate
python -m py_compile scripts\run_tick_manager.py scripts\enrich_trade.py scripts\backfill_trade_enrichment.py services\pre_arm_ote.py || (echo COMPILE FAIL & pause & exit /b 1)
echo [4/4] proof: the 13 R37 law tests + clutch/truthfulness families
python -m pytest tests\test_r37_law_roundup.py tests\test_r26_8_momentum_clutch.py tests\test_r26_9_2_tick_clutch_and_macro_verification.py tests\test_r26_9_10_clutch_ratio_law.py tests\test_mt5_execution_correctness.py -q || (echo TESTS FAIL - restore .bak.r37 & pause & exit /b 1)
echo.
echo R37 LAW APPLIED. Restart the bot/tick-manager to load the laws.
pause
