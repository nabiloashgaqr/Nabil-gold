"""Tick-level manager (VPS, mt5_demo only).

Analysis stays on the 5-minute cycle; EXECUTION management runs EVERY TICK:
pending activation, breakeven, TP1 partial, trailing, and broker-side closes
are detected and applied tick-by-tick through MT5, with DB writes and cards
only on state changes. MT5 is the execution authority; the DB mirrors it.

Pure decision helpers are unit-tested (tests/test_tick_manager_logic.py).
"""
from __future__ import annotations

# --- VPS: load .env if present (real env vars ALWAYS win over .env) ---
try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv()  # override=False: task-wrapper vars take precedence
except Exception:
    pass

import json
import logging
import os
import sys
import time
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.trading_rules import (stop_rule, trailing_params, momentum_clutch_params,
                                 breakeven_stop, is_protected, distance_ratio)  # noqa: E402
from utils.indicators import calculate_atr  # noqa: E402
from utils.instruments import (point_size, config_for_instrument,  # noqa: E402
                               normalize_symbol, round_price, format_price,
                               price_decimals)
# magic_for is needed inside _handle_row (module scope); mt5_executor keeps
# its MetaTrader5 import lazy, so this top-level import is safe on any OS.
from services.mt5_executor import magic_for  # noqa: E402
from services.weekend_policy import effective_pending_age_hours  # noqa: E402  # R25.7-G v2
from services.execution_paths import path_header  # noqa: E402

logger = logging.getLogger("tick_manager")
LOOP_SLEEP = float(os.environ.get("TICK_LOOP_SLEEP", 0.25))
ROWS_REFRESH_SECONDS = float(os.environ.get("TICK_ROWS_REFRESH", 3.0))


def _new_auction_store(cls, path, *, symbol=None, price_range=None):
    """Construct an AuctionFlowStore with the R25.9 write-side price gate.

    Tolerant by design: if the concrete class (e.g. a patched/fake store in
    tests, or an older deployed copy) does not accept ``price_range``, retry
    without it so collector init never collapses to an empty symbol list.
    """
    try:
        return cls(str(path), symbol=symbol, price_range=price_range)
    except TypeError:
        try:
            return cls(str(path), symbol=symbol)
        except TypeError:
            return cls(str(path))


# ── pure decisions (unit-tested) ────────────────────────────────────────────

def decide_be(
    side: str, entry: float, current: float, risk_points: float,
    be_points: float, min_be_rr: float, already: bool, point_value: float = 0.10,
) -> bool:
    """Arm breakeven once price travelled >= be_points AND >= min_be_rr
    (both in codebase points; fav converted from price)."""
    if already or entry <= 0 or risk_points <= 0:
        return False
    fav_points = ((entry - current) if side == "SELL" else (current - entry)) / point_value
    return fav_points >= be_points and fav_points >= min_be_rr * risk_points


def decide_trailing(
    side: str, entry: float, current_stop: float, favorable_extreme: float,
    gap_points: float, step_points: float, point_value: float,
    decimals: int = 2,
) -> Optional[float]:
    """Ratchet the stop behind the favorable extreme (gap), in steps."""
    if side == "BUY":
        candidate = favorable_extreme - gap_points * point_value
        if candidate > entry and candidate >= current_stop + step_points * point_value:
            return round(candidate, decimals)
    else:
        candidate = favorable_extreme + gap_points * point_value
        if candidate < entry and candidate <= current_stop - step_points * point_value:
            return round(candidate, decimals)
    return None


# ── R26.8 momentum clutch — tick-side port (R26.9.2, 2026-09-01) ─────────────
# The clutch was built inside the 5-minute manager only. On the mt5_demo VPS
# THIS tick manager is the only manager (BUILD 31 note at the TP1 arm), so
# the live demo kept chasing the tick with the fixed 150-pt trail during
# accelerated legs (live 2026-09-01: SELL gold, stop marched 4355.14 ->
# 4350.04 behind every new extreme while the leg ran +322 pts) — the exact
# shake-out the R26.8 law exists to prevent. Same law, same params source
# (utils.trading_rules.momentum_clutch_params), pure + unit-tested like the
# other decide_* helpers.
def clutch_state(
    params: Dict[str, Any], candles: List[Dict[str, Any]] | None,
    side: str, point_value: float,
) -> Dict[str, Any]:
    """Impulse detection on CLOSED M5 candles. {active, atr_pts, reason}.

    Fail-open: any missing/unreadable input -> active False (caller then
    uses the normal fixed-gap trail). Tests (manager parity): a closed
    directional candle whose body >= 3x the prior noise and >= 35 pts
    (early), or >= 2 ATR (late), or a 2-candle window >= 3 ATR (speed).
    """
    inactive = {"active": False, "atr_pts": 0.0, "reason": ""}
    try:
        if not bool(params.get("enabled", True)):
            return {**inactive, "reason": "clutch_disabled"}
        if not candles or len(candles) < max(5, int(params.get("speed_lookback", 2)) + 2):
            return {**inactive, "reason": "insufficient_candles"}
        pv = float(point_value or 0)
        if pv <= 0:
            return {**inactive, "reason": "no_point_value"}

        atr_list = calculate_atr(candles, int(params.get("atr_period", 14)))
        atr_price = 0.0
        for v in reversed(atr_list or []):
            if v:
                atr_price = float(v)
                break
        if atr_price <= 0:
            return {**inactive, "reason": "no_atr"}
        atr_pts = atr_price / pv

        def _f(c: Dict[str, Any], k: str) -> float:
            try:
                return float(c.get(k) or 0.0)
            except (TypeError, ValueError):
                return 0.0

        completed = candles[:-1] if len(candles) > 1 else candles
        last = completed[-1]
        body_pts = abs(_f(last, "close") - _f(last, "open")) / pv
        lookback = int(params.get("speed_lookback", 2))
        window = completed[-lookback:] if len(completed) >= lookback else completed
        window_range_pts = (max(_f(c, "high") for c in window)
                            - min(_f(c, "low") for c in window)) / pv
        # Baseline noise BEFORE the possible impulse (avg range of the
        # candles prior to the latest one) — the earliest accelerator cue.
        prior = completed[:-1][-int(params.get("atr_period", 14)):] or completed[:-1]
        if prior:
            prior_range_pts = sum(
                (_f(c, "high") - _f(c, "low")) / pv for c in prior) / len(prior)
        else:
            prior_range_pts = atr_pts
        if side == "BUY":
            directional = _f(last, "close") >= _f(last, "open")
        else:
            directional = _f(last, "close") <= _f(last, "open")
        burst_mult = float(params.get("burst_vs_noise_mult", 3.0))
        burst_early = (prior_range_pts > 0
                       and body_pts >= burst_mult * prior_range_pts
                       and body_pts >= float(params.get("burst_min_points", 35.0)))
        big_candle = body_pts >= float(params.get("candle_atr_mult", 2.0)) * atr_pts
        fast_window = window_range_pts >= float(params.get("speed_atr_mult", 3.0)) * atr_pts
        active = bool(directional and (big_candle or fast_window or burst_early))
        reason = ("impulse" if active else
                  f"no_impulse(big={big_candle},fast={fast_window},"
                  f"early={burst_early},dir={directional})")
        return {"active": active, "atr_pts": atr_pts, "reason": reason}
    except Exception:  # noqa: BLE001 - clutch is fail-open
        return {**inactive, "reason": "error"}


def clutch_stop(
    params: Dict[str, Any], side: str, current_stop: float, entry: float,
    candles: List[Dict[str, Any]] | None, point_value: float, atr_pts: float,
    decimals: int = 2,
) -> Optional[float]:
    """Structure-anchored stop during an impulse (manager parity).

    Anchor = the most recent adverse swing extreme (highest high for a
    SELL / lowest low for a BUY over the last anchor_lookback CLOSED
    candles). Margin = clamp(atr_k * ATR, min_gap, max_gap) in points.
    Ratchet-only: the stop merely tightens and never hands back locked
    profit. R37-A+C (2026-09-09): crossing INTO the entry line while the
    position is not law-protected is refused (the BE law owns that line);
    once protected, both sides may structure-trail through it, SELL
    included. None when no improvement is possible.
    """
    try:
        pv = float(point_value or 0)
        if pv <= 0 or entry <= 0:
            return None
        completed = (candles or [])[:-1] if candles and len(candles) > 1 else (candles or [])
        n = int(params.get("anchor_lookback", 5))
        window = completed[-n:] if len(completed) >= n else completed
        if not window:
            return None
        margin_pts = max(float(params.get("min_gap_points", 150.0)),
                         min(float(params.get("max_gap_points", 400.0)),
                             float(params.get("atr_k", 1.3)) * float(atr_pts)))
        margin = margin_pts * pv

        def _f(c: Dict[str, Any], k: str) -> float:
            try:
                return float(c.get(k) or 0.0)
            except (TypeError, ValueError):
                return 0.0

        # R37-A+C (operator order 2026-09-09): the ENTRY LINE belongs to the
        # breakeven LAW, not to the clutch. Before R37 the clutch clamped its
        # structure candidate AT entry (BUY max(..., entry) / SELL min(...,
        # entry)), so the very first 52.5-pt FX "impulse" candle wrote
        # stop == entry with no 225-pt early-breakeven and no 0.5R gate --
        # then the ratchet forbade retreat and an ordinary pullback paid
        # $0.00 (live rows 2026-09-08/09: GBP/USD and USD/CAD closed exactly
        # at entry). Now: the clutch tightens freely BELOW the entry line,
        # but writing AT or beyond entry is deferred to the BE law; only a
        # position the law already protects (stop at/beyond entry) may be
        # structure-trailed through the entry line. And the asymmetric SELL
        # cap `min(candidate, entry)` is RETIRED -- a protected SELL rides
        # the structure BELOW entry as a true profit lock, mirroring the
        # BUY side. Ratchet-only on both sides, as before.
        # Impulse NUMBERS stay per-instrument (burst/gap margins resolve
        # inside momentum_clutch_params: gold 35/150/400, WTI x0.5, FX x1.5
        # -- no cross-mixing anywhere); this gate is arithmetic, not a
        # threshold, so it is identical for every symbol.
        protected = (
            (side == "BUY" and current_stop >= entry)
            or (side == "SELL" and 0 < current_stop <= entry)
        )
        if side == "BUY":
            anchor = min(_f(c, "low") for c in window)
            candidate = anchor - margin
            if candidate >= entry and not protected:
                return None  # A: deferred to the BE law (225 FX / 150 gold + 0.5R)
            if candidate > current_stop:
                return round(candidate, decimals)
        else:
            anchor = max(_f(c, "high") for c in window)
            candidate = anchor + margin
            if candidate <= entry and not protected:
                return None  # A: deferred to the BE law (symmetric)
            if candidate < current_stop:
                return round(candidate, decimals)  # C: may pass below entry
        return None
    except Exception:  # noqa: BLE001 - fail-open to the normal trail
        return None


def zone_touch_tick_decision(
    side: str, price: float, entry: float, point_value: float,
    *, armed: bool = False, width_points: float = 80.0,
) -> Dict[str, Any]:
    """Arm on a real tick inside an 80-point zone; fire on the first tick out.

    The width is TOTAL (40 points either side by default). No candle or
    analysis-cycle confirmation is involved. A price that starts beyond the
    zone without a recorded touch is never chased.
    """
    if price <= 0 or entry <= 0 or point_value <= 0 or width_points <= 0:
        return {"armed": bool(armed), "activate": False}
    half = width_points * point_value / 2.0
    low, high = entry - half, entry + half
    inside = low <= price <= high
    now_armed = bool(armed or inside)
    side = str(side or "").upper()
    activate = now_armed and ((side == "BUY" and price > high) or
                              (side == "SELL" and price < low))
    return {"armed": now_armed, "activate": activate, "inside": inside,
            "zone_low": low, "zone_high": high}


def zone_rr_floor_decision(entry: float, stop: float, target: float,
                           point_value: float, min_rr: float,
                           tolerance_points: float = 1.0) -> Dict[str, Any]:
    """Evaluate the zone-conversion R floor in canonical point space.

    Published prices are rounded to broker precision.  That can leave a plan
    intended and recorded as exactly 1.50R a fraction of one point below the
    raw floating-point threshold (live XAU: 404.9 / 270 = 1.499629...).  Allow
    at most one canonical point of price-rounding error; this is not a general
    relaxation of the R floor and remains symmetric for BUY and SELL.
    """
    if point_value <= 0:
        return {"allow": False, "raw_rr": 0.0, "risk_points": 0.0,
                "reward_points": 0.0, "required_points": 0.0,
                "tolerance_points": tolerance_points}
    risk_points = abs(float(entry) - float(stop)) / float(point_value)
    reward_points = abs(float(target) - float(entry)) / float(point_value)
    required = float(min_rr) * risk_points
    allow = risk_points > 0 and reward_points + float(tolerance_points) >= required
    return {"allow": allow,
            "raw_rr": reward_points / risk_points if risk_points > 0 else 0.0,
            "risk_points": risk_points, "reward_points": reward_points,
            "required_points": required,
            "tolerance_points": float(tolerance_points)}


def decide_tp1(side: str, tp1: float, candle_low: float, candle_high: float,
               done: bool) -> bool:
    if done or tp1 <= 0:
        return False
    # BUY TP1 (above entry) is touched when the HIGH reaches it; SELL when
    # the LOW does. The old inverted form booked halves AT A LOSS the moment
    # price sat below an above-entry target (MT5 journal 2026-08-10 09:50).
    return (candle_high >= tp1) if side == "BUY" else (candle_low <= tp1)



def corrected_execution_stop(
    side: str,
    actual_entry: float,
    current_stop: float,
    planned_entry: float,
    planned_stop: float,
    *,
    min_liquidity_points: float = 200.0,
    safety_buffer_points: float = 70.0,
    cap_points: float = 400.0,
    point_value: float = 0.10,
    digits: int = 2,
) -> tuple[Optional[float], float, float]:
    """Normalize the initial broker stop after actual market fill.

    The liquidity law selects a planned stop in [200+70, 400] points. A better
    market fill can silently shrink that distance (live: 4392.63 -> 4368 =
    246.3 pts). Keep the structural stop when its actual distance is legal;
    otherwise move it to preserve the planned/floor distance, capped at 400.
    Returns (new_stop_or_None, required_points, actual_points).

    R25.15 (2026-08-28): the result is rounded to the SYMBOL's price digits,
    not a hardcoded 2. round(1.35904, 2) == 1.36 silently cancelled the whole
    correction on 5-digit FX rows (live GBPUSD: a 496-pt stop "corrected"
    back to the broker value). digits comes from price_decimals(symbol).
    """
    if point_value <= 0 or actual_entry <= 0 or current_stop <= 0:
        return None, 0.0, 0.0
    side = str(side or "").upper()
    risk_side = ((side == "BUY" and current_stop < actual_entry)
                 or (side == "SELL" and current_stop > actual_entry))
    if not risk_side:
        return None, 0.0, 0.0  # BE/trailing protection must never be widened
    floor_points = max(0.0, min_liquidity_points + safety_buffer_points)
    planned_points = (
        abs(planned_entry - planned_stop) / point_value
        if planned_entry > 0 and planned_stop > 0 else floor_points
    )
    required = min(max(planned_points, floor_points), cap_points)
    actual = abs(actual_entry - current_stop) / point_value
    target_points = required if actual < required - 0.5 else cap_points if actual > cap_points + 0.5 else None
    if target_points is None:
        return None, round(required, 1), round(actual, 1)
    new_stop = (actual_entry - target_points * point_value
                if side == "BUY" else actual_entry + target_points * point_value)
    return round(new_stop, digits), round(required, 1), round(actual, 1)


def _row_fresh(row: Dict[str, Any], max_age_minutes: float = 60.0) -> bool:
    """A row is placement-eligible only within max_age of created_at.
    Live incident 2026-08-10: a finished TP1_HIT row with no ticket was
    resurrected into fresh market orders every tick."""
    from datetime import datetime, timezone
    raw = str(row.get("created_at") or "")
    if not raw:
        return False
    try:
        created = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except Exception:  # noqa: BLE001
        return False
    if created.tzinfo is None:
        created = created.replace(tzinfo=timezone.utc)
    age = (datetime.now(timezone.utc) - created).total_seconds() / 60.0
    return 0 <= age <= max_age_minutes


def classify_broker_exit(side: str, deal_price: float, entry: float,
                         stop: float, tp2: float) -> str:
    """Map a broker-side exit price to our status labels.

    The broker only closes on SL/TP, so an exit between stop and TP2 means
    the (already moved) trailing/breakeven stop was the trigger. Pure +
    unit-tested (tests/test_mt5_execution_correctness.py).
    """
    eps = 1e-9
    if side == "BUY":
        if tp2 and deal_price >= tp2 - eps:
            return "TP2_HIT"
        if deal_price <= (stop or entry) + eps:
            return "SL_HIT"
        return "TRAILING_SL_HIT"
    if tp2 and deal_price <= tp2 + eps:
        return "TP2_HIT"
    if deal_price >= (stop or entry) - eps:
        return "SL_HIT"
    return "TRAILING_SL_HIT"


# ── live loop ───────────────────────────────────────────────────────────────

def _iso_from_epoch(ts: float | int | None) -> str | None:
    """UTC ISO stamp (Z) from a broker epoch; None when absent/invalid."""
    try:
        value = float(ts)
        if value <= 0:
            return None
        return datetime.fromtimestamp(value, tz=timezone.utc).isoformat().replace("+00:00", "Z")
    except (TypeError, ValueError, OSError):
        return None


def _now_iso_stamp() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _close_stamp(exit_info: Dict[str, Any] | None, now_ts: float | None = None) -> str:
    """BUILD 22 (2026-08-21): the REAL close time for a broker-closed trade.

    The live mirror wrote status/close_price but never closed_at, so every
    post-exit guard (post-TP2 2.5h block, WIN/LOSS cooldowns, the daily
    report) measured from the OPEN time - the 09:16 pending slipped through
    three minutes after a real 09:13 TP2. Prefer the broker deal's own time.

    BUILD 22.1: the broker clock runs ~3h AHEAD of the VPS clock (observed
    on the tick stores and on the 2026-08-21 backfill scan). A future stamp
    would make ``hours_since`` negative and the post-TP2 guard skips
    negative ages (fail-open). Future deal times are therefore clamped to
    the discovery moment - the live path detects a close within seconds, so
    the stamp stays within seconds of the truth and is never in the future.
    """
    if isinstance(exit_info, dict):
        try:
            deal_ts = float(exit_info.get("time") or 0)
        except (TypeError, ValueError):
            deal_ts = 0.0
        ref = float(now_ts if now_ts is not None else time.time())
        if deal_ts > 0 and deal_ts <= ref + 300:
            return _iso_from_epoch(deal_ts) or _now_iso_stamp()
        if deal_ts > ref + 300:
            logger.info(
                "broker deal time %.0fs ahead of the VPS clock - clamping "
                "the close stamp to the discovery moment", deal_ts - ref)
    return _now_iso_stamp()


class TickManager:
    def __init__(self, config: Dict[str, Any], telegram=None, database=None):
        self.config = config
        self.telegram = telegram
        self.database = database
        self._extremes: Dict[str, float] = {}
        self._trail = trailing_params(config)
        # BUILD 19 (2026-08-20): per-symbol law cache. The live loop used the
        # BASE (gold) trailing/stop for EVERY row - a live WTI position
        # shipped the gold stop band (270 pts = $2.70 on oil, live
        # 2026-08-20 21:37) and gold trailing 150/40. Each trade is now
        # managed with ITS OWN instrument's laws.
        self._symbol_law_cache: Dict[str, Dict[str, Any]] = {}
        self._partial_alerted: set = set()  # refused-partial reported once/trade
        self._drift_alerted: set = set()    # R37-2: one SL-drift WARN per trade
        # R26.9.2: M5 candle cache for the momentum clutch (symbol ->
        # (monotonic ts, candles)); refreshed every few seconds only.
        self._m5_cache: Dict[str, tuple] = {}
        self._m5_ttl = float(os.environ.get("TICK_M5_REFRESH_SECONDS", 5.0))
        self._placement_retry_at: Dict[str, float] = {}  # stop 4x/sec refusal/log floods
        # Broker conversion lock: one pending -> market transaction per trade.
        self._zone_conversion_locks: set[str] = set()
        self._auction_heartbeat_at = 0.0
        self._auction_prune_at = 0.0
        self._auction_store = None
        self._auction_last_msc = 0
        self._notification_row: Dict[str, Any] | None = None
        # BUILD 22: per-trade last prices so a rich card always reports ITS
        # own symbol's price (a gold card once showed the oil price because
        # _last_price was shared across rows).
        self._last_prices: Dict[str, float] = {}
        # BUILD 31: per-symbol OpenTradesManager for TP1-breakeven parity
        # (same resolved parameters as the 5-minute paper path).
        self._symbol_mgr_cache: Dict[str, Any] = {}
        auction_cfg = config.get("auction_flow", {}) or {}
        if bool(auction_cfg.get("enabled", False)):
            from services.auction_flow_store import AuctionFlowStore
            from utils.instruments import normalize_symbol as _norm0
            _base_sym = _norm0(str(config.get("symbol") or ""))
            # R25.9: write-side foreign-tick gate (reject out-of-symbol prices).
            _base_range = None
            try:
                from utils.instruments import price_sanity_range as _psr
                if _base_sym:
                    _base_range = _psr(_base_sym, config)
            except Exception:  # noqa: BLE001 - fail-open without a gate
                _base_range = None
            self._auction_store = _new_auction_store(
                AuctionFlowStore,
                str(auction_cfg.get("storage_path") or "storage/auction_flow.sqlite3"),
                symbol=_base_sym, price_range=_base_range)
            try:
                self._auction_store.ensure_writable_attribute()
                # Immediate startup write under the Scheduled Task identity.
                # A permission/ACL problem now fails with a clear traceback
                # instead of a silent stale heartbeat loop.
                self._auction_store.mark_heartbeat()
                self._auction_last_msc = int(
                    (self._auction_store.meta() or {}).get("last_tick_ts_ms", 0) or 0
                )
            except Exception as _hb_exc:
                # Production: a storage permission problem must be loud (the
                # Scheduled Task identity can always write; a failure means a
                # real ACL issue). Under pytest the TickManager is built against
                # a real read-only store for unrelated card/stop tests - those
                # never use the auction store, so a heartbeat failure must not
                # crash them (it surfaced as "attempt to write a readonly db").
                if os.environ.get("PYTEST_CURRENT_TEST"):
                    logger.warning("Auction store startup heartbeat skipped under test: %s", _hb_exc)
                else:
                    logger.exception("Auction Flow store startup write failed")
                    raise
        # Secondary tick collectors for every enabled non-base instrument
        # (operator 2026-08-17): each live symbol gets ITS OWN suffixed store
        # so the oil auction agent never reads gold ticks. Same loop, no
        # second process; failures here must never break gold execution.
        # BUILD 18 (2026-08-20): one collector feeds the live WTI/USD auction
        # store; without it Path 4/5 went silent for oil (auction_state
        # LIVE_TICK_FEED_STALE, 25h-old ticks). One collector, one source.
        self._aux_ticks: list[tuple[str, Any]] = []
        self._aux_last_msc: dict[str, int] = {}
        self._aux_selected: set[str] = set()      # symbols subscribed in Market Watch
        self._aux_warned_at: dict[str, float] = {}  # once-per-hour warnings
        try:
            from utils.instruments import (enabled_instruments as _en_insts,
                                           normalize_symbol as _norm,
                                           point_size, max_spread_points_for,
                                           price_sanity_range as _psr2)
            from services.auction_flow_store import AuctionFlowStore as _AFS
            from pathlib import Path as _P
            auction_cfg2 = config.get("auction_flow", {}) or {}
            base_path = _P(str(auction_cfg2.get("storage_path") or "storage/auction_flow.sqlite3"))
            _base_aux = _norm(str(config.get("symbol") or ""))
            for _inst in _en_insts(config):
                _sym = _norm(str(_inst.get("symbol") or ""))
                if not _sym or _sym == _base_aux:
                    continue
                _stem = _sym.replace("/", "").lower()
                _spath = base_path.with_name(f"{base_path.stem}_{_stem}{base_path.suffix}")
                # R25.9: per-symbol write-side price gate; fail-open if unavailable.
                try:
                    _range = _psr2(_sym, config)
                except Exception:  # noqa: BLE001
                    _range = None
                _store = _new_auction_store(_AFS, str(_spath), symbol=_sym, price_range=_range)
                _store.mark_heartbeat()
                self._aux_ticks.append((_sym, _store))
                self._aux_last_msc[_sym] = int((_store.meta() or {}).get("last_tick_ts_ms", 0) or 0)
            if self._aux_ticks:
                logger.info("Aux tick collectors (live non-base symbols): %s", [t[0] for t in self._aux_ticks])
        except Exception:
            logger.exception("Aux tick collector init failed (gold unaffected)")
            self._aux_ticks = []

    def _collect_aux_ticks(self, mt5, executor, now: float) -> None:
        """Record the latest tick for every non-base instrument's own store
        (every enabled non-base instrument, e.g. live WTI/USD). Execution
        paths stay untouched.

        BUILD 18.1: a symbol that is not selected in the terminal's Market
        Watch returns None or a stale/zero-price tick from symbol_info_tick -
        the store then shows a fresh heartbeat with ZERO new rows (exactly the
        VPS symptom). Each aux symbol is therefore selected explicitly, a
        zero-time tick falls back to the wall clock, and the first real tick
        is announced so the log proves the feed.
        """
        for _sym, _store in self._aux_ticks:
            try:
                broker_symbol = executor._sym(_sym)
                if _sym not in self._aux_selected:
                    try:
                        if hasattr(mt5, "symbol_select"):
                            mt5.symbol_select(broker_symbol, True)
                        self._aux_selected.add(_sym)
                    except Exception:  # noqa: BLE001
                        pass  # selection is best-effort; the tick read decides
                tick = mt5.symbol_info_tick(broker_symbol)
                if tick is None:
                    if now - self._aux_warned_at.get(_sym, 0.0) >= 3600.0:
                        self._aux_warned_at[_sym] = now
                        logger.warning(
                            "aux tick unavailable for %s (%s) - symbol not in "
                            "Market Watch?", _sym, broker_symbol)
                    continue
                msc = int(getattr(tick, "time_msc", 0) or 0)
                if msc <= 0:
                    # Broker gave no timestamp (non-subscribed symbols do this):
                    # use the wall clock so a real quote still records.
                    msc = int(time.time() * 1000)
                if msc >= self._aux_last_msc.get(_sym, 0):
                    if _store.record_tick(tick):
                        if not self._aux_last_msc.get(_sym):
                            logger.info("aux live tick feed started for %s (%s)",
                                        _sym, broker_symbol)
                        self._aux_last_msc[_sym] = msc
                        # R21: feed-scale anomaly - a recorded tick whose
                        # spread is many times the symbol's cap is almost
                        # always another symbol's prices landing in this
                        # store (the 170-pt JPY case). Warn loudly, hourly.
                        try:
                            _pv = float(point_size(_sym, config) or 0)
                            _cap = float(max_spread_points_for(_sym, config) or 0)
                            _tbid = float(getattr(tick, "bid", 0) or 0)
                            _task = float(getattr(tick, "ask", 0) or 0)
                            if _pv > 0 and _cap > 0 and _tbid > 0 and _task > _tbid:
                                _spts = (_task - _tbid) / _pv
                                if _spts > 5.0 * _cap:
                                    if now - self._aux_warned_at.get(_sym, 0.0) >= 3600.0:
                                        self._aux_warned_at[_sym] = now
                                        logger.warning(
                                            "aux feed SCALE ANOMALY for %s: tick spread %.1f pts "
                                            "is >5x cap %.1f - possible wrong-symbol feed "
                                            "(bid=%.5f ask=%.5f)", _sym, _spts, _cap, _tbid, _task)
                        except Exception:  # noqa: BLE001 - warn-only
                            pass
                if now - getattr(self, "_aux_hb_at", 0.0) >= 5.0:
                    _store.mark_heartbeat()
            except Exception:  # noqa: BLE001 - aux feed must not break gold
                logger.debug("aux tick collect failed for %s", _sym)
        if now - getattr(self, "_aux_hb_at", 0.0) >= 5.0:
            self._aux_hb_at = now

    def _collect_auction_tick(self, mt5, executor, now: float) -> None:
        """Collect the broker tick book even when no trade is open.

        The same scheduled Tick Manager owns both execution management and the
        Auction Flow feed. No second loop/process is permitted.
        """
        if self._auction_store is None:
            return
        symbol = str(self.config.get("symbol") or "XAU/USD")
        broker_symbol = executor._sym(symbol)
        newest = self._auction_last_msc
        loaded = 0
        if self._auction_last_msc > 0 and hasattr(mt5, "copy_ticks_from"):
            try:
                start = datetime.fromtimestamp(
                    self._auction_last_msc / 1000.0, tz=timezone.utc
                )
                batch = mt5.copy_ticks_from(
                    broker_symbol, start, 5000,
                    getattr(mt5, "COPY_TICKS_ALL", 0),
                )
                if batch is not None:
                    fresh = [
                        tick for tick in batch
                        if int(tick["time_msc"] or 0) > self._auction_last_msc
                    ]
                    if fresh:
                        loaded = self._auction_store.bulk_record_ticks(fresh)
                        newest = max(int(tick["time_msc"] or 0) for tick in fresh)
            except Exception as exc:  # noqa: BLE001
                logger.debug("auction incremental tick copy failed: %s", exc)
        if loaded == 0:
            tick = mt5.symbol_info_tick(broker_symbol)
            if tick is not None and int(getattr(tick, "time_msc", 0) or 0) >= self._auction_last_msc:
                if self._auction_store.record_tick(tick):
                    newest = int(getattr(tick, "time_msc", 0) or newest)
        self._auction_last_msc = max(self._auction_last_msc, newest)
        if now - self._auction_heartbeat_at >= 5.0:
            self._auction_store.mark_heartbeat()
            self._auction_heartbeat_at = now
        if now - self._auction_prune_at >= 3600.0:
            # R23 (2026-08-27): prune EVERY store (gold + the five aux
            # forex/oil stores). Only the gold store was pruned before - the
            # aux collectors kept writing seconds rows forever and the
            # storage tree ballooned (operator: 1.5 GB).
            try:
                from services.auction_flow_store import prune_all_stores
                report = prune_all_stores(
                    root="storage", config=self.config, now=now)
                for _path, _entry in report.items():
                    if _entry.get("error"):
                        logger.warning("prune failed for %s: %s", _path, _entry["error"])
            except Exception:  # noqa: BLE001 - maintenance must not kill ticks
                logger.exception("hourly prune-all failed (ticks unaffected)")
            self._auction_prune_at = now

    @staticmethod
    def _write_heartbeat(path: str = "tick_heartbeat.json") -> None:
        """Atomically publish a valid heartbeat; never expose an empty file."""
        tmp = f"{path}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"ts": datetime.now(timezone.utc).isoformat()}, fh)
            fh.flush()
            os.fsync(fh.fileno())
        try:
            os.replace(tmp, path)
        except PermissionError:
            # Windows reader lock; heartbeat is periodic — next beat rewrites.
            try:
                os.unlink(tmp)
            except OSError:
                pass

    def _placement_due(self, trade_id: str) -> bool:
        """Retry broker refusals every 5s, not four times per second."""
        now = time.monotonic()
        if now < self._placement_retry_at.get(trade_id, 0.0):
            return False
        self._placement_retry_at[trade_id] = now + 5.0
        return True

    def _flip_dependencies_open(self, row: Dict[str, Any], executor) -> List[str]:
        """Broker positions that must close before this opposite entry."""
        if not row.get("opposite_exit_required"):
            return []
        alive: List[str] = []
        for tid in row.get("opposite_trade_ids") or []:
            if executor._position_by_magic(magic_for(str(tid))) is not None:
                alive.append(str(tid))
        if not alive:
            updates = {"opposite_exit_required": False,
                       "opposite_exit_completed": True}
            self.database.update_trade(str(row.get("id")), updates)
            row.update(updates)
        return alive

    def _send_execution_signal(
        self, row: Dict[str, Any], *, actual_entry: float | None = None,
        actual_stop: float | None = None,
    ) -> None:  # pragma: no cover - VPS/Telegram integration
        """Deliver the rich signal only after an MT5 position/order exists.

        New demo rows carry ``telegram_signal_sent=False``. Old rows omit the
        field and are deliberately not re-announced during deployment.
        """
        if row.get("telegram_signal_sent") is not False or not self.telegram:
            return
        decision = deepcopy(row.get("signal_snapshot") or {})
        if not isinstance(decision, dict) or not decision:
            logger.error("cannot send execution signal for %s: no snapshot", row.get("id"))
            return
        decision["trade_id"] = str(row.get("id") or decision.get("trade_id") or "")
        # BUILD 31 R2 (2026-08-24): the row's arming column is authoritative
        # even if an old snapshot lacks the structured path fields — the
        # card header must never show NOT RECORDED for a pre-armed order.
        if str(row.get("armed_at") or "") == "pre_arm_ote":
            decision.setdefault("armed_at", "pre_arm_ote")
        signal = decision.setdefault("signal", {})
        if actual_entry and actual_entry > 0:
            entry = signal.setdefault("entry", {})
            entry["price"] = round_price(actual_entry, row.get("symbol"), self.config)
            decision["current_price"] = round_price(actual_entry, row.get("symbol"), self.config)
        if actual_stop and actual_stop > 0:
            signal["stop_loss"] = round_price(actual_stop, row.get("symbol"), self.config)
        # Broker/executor sizing is authoritative, not an upstream suggestion.
        # Carry the applied lot and its full-stop dollar risk into the card.
        lots = float(row.get("lots") or 0.0)
        stop_for_risk = float(actual_stop or row.get("stop_loss") or 0.0)
        entry_for_risk = float(actual_entry or row.get("entry_price") or 0.0)
        if lots > 0:
            decision["executed_lots"] = lots
            try:
                from services.risk_usd import usd_loss
                _pv = point_size(row.get("symbol") or "XAU/USD", self.config)
                _pts = abs(entry_for_risk - stop_for_risk) / _pv if _pv > 0 else 0.0
                decision["executed_stop_risk_usd"] = round(usd_loss(
                    row.get("symbol") or "XAU/USD", _pts, lots,
                    quote_price=entry_for_risk), 2)
            except Exception:  # noqa: BLE001 - card enrichment never blocks
                pass
        custom = decision.get("_telegram_pending_message")
        try:
            sent = bool(
                self.telegram.send_message(str(custom), urgent=True)
                if custom else self.telegram.send_signal(decision)
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("execution signal delivery crashed for %s: %s", row.get("id"), exc)
            return
        if not sent:
            logger.warning("execution signal delivery returned False for %s; retrying", row.get("id"))
            return
        sent_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        updates = {"telegram_signal_sent": True,
                   "telegram_signal_sent_at": sent_at}
        self.database.update_trade(str(row.get("id")), updates)
        row.update(updates)  # cached row must not resend before the 3s refresh

    def _normalize_execution_stop(self, row, pos, executor, side: str) -> float:
        """Broker-first enforcement of the 270..400 initial stop law.

        R25.15 (2026-08-28) — fill-truth reconciliation, once per row: a
        legacy live row can carry the PLANNED entry while the broker filled
        elsewhere (live GBPUSD: row 1.36000 vs fill 1.35504), which made the
        early-breakeven arm a stop at a phantom entry and hid the real
        496-pt risk. When pos.price_open disagrees with row entry_price by
        more than half a point, this pass (and only this pass):
          1. writes the broker fill into entry_price (entry_fill_reconciled),
          2. completes the interrupted normalization:
               - sl_moved_to_entry rows: BE stop moves to the TRUE entry
                 (tighten-only, never widened),
               - otherwise the liquidity/cap law re-derives the stop from
                 the true fill,
          bypassing the partial_close/sl_moved_to_entry protection exactly
          once (the flag pair keeps every later tick fully protected).
        """
        self._notification_row = row if isinstance(row, dict) else None
        symbol = row.get("symbol")
        pv = point_size(symbol or "XAU/USD", self.config)
        digits = price_decimals(symbol or "XAU/USD", self.config)
        current = float(row.get("stop_loss") or getattr(pos, "sl", 0) or 0)
        # New rows carry the flag; legacy live rows are eligible only when their
        # signal snapshot proves the original planned entry/stop.
        snapshot = row.get("signal_snapshot") or {}
        if isinstance(snapshot, str):
            try:
                snapshot = json.loads(snapshot)
            except Exception:
                snapshot = {}
        signal = (snapshot.get("signal") or {}) if isinstance(snapshot, dict) else {}
        # Fill truth: compare the RAW broker fill with the row entry at the
        # symbol's own scale (a fixed 0.01 tolerance is one gold cent but a
        # full pip on EUR/USD).
        raw_fill = float(getattr(pos, "price_open", 0) or 0)
        row_entry = float(row.get("entry_price") or 0)
        fill_mismatch = bool(
            raw_fill > 0 and row_entry > 0
            and pv > 0 and abs(raw_fill - row_entry) > 0.5 * pv)
        # A proven fill mismatch is itself eligibility evidence: a legacy row
        # with no signal snapshot and no normalization flag still deserves its
        # one-time reconciliation (the live GBPUSD row had no usable snapshot).
        eligible = (row.get("execution_stop_normalized") is False
                    or bool(signal) or fill_mismatch)
        once_bypass = bool(fill_mismatch and not row.get("entry_fill_reconciled"))
        protected = is_protected(side, row_entry, current, bool(row.get("sl_moved_to_entry") or row.get("partial_close")))
        if not eligible or (protected and not once_bypass):
            return current
        planned_entry = float(((signal.get("entry") or {}).get("price"))
                              or row.get("entry_price") or 0)
        planned_stop = float(signal.get("stop_loss") or row.get("initial_stop_loss")
                             or current or 0)
        rule = self._per_symbol_laws(row)["stop"]
        actual_entry = raw_fill if raw_fill > 0 else row_entry
        # Fill truth first: a reconciled row must carry the broker's fill
        # (rounded to the symbol's own digits, never gold's 2).
        _entry_updates: Dict[str, Any] = {}
        if fill_mismatch:
            _entry_updates["entry_price"] = round_price(raw_fill, symbol, self.config)
            _entry_updates["entry_fill_reconciled"] = True
            actual_entry = raw_fill
        be_completion = bool(once_bypass and row.get("sl_moved_to_entry"))
        if be_completion:
            # The stop was armed at a PHANTOM entry. Complete the breakeven at
            # the true fill — tighten-only: a SELL stop may only move down, a
            # BUY stop only up; the current stop always stays the floor.
            true_be = round_price(raw_fill, symbol, self.config)
            tighter = (true_be < current if side == "SELL" else true_be > current)
            corrected, required_pts, actual_pts = (
                (true_be, 0.0, abs(raw_fill - current) / pv if pv > 0 else 0.0)
                if tighter else (None, 0.0, 0.0))
        else:
            corrected, required_pts, actual_pts = corrected_execution_stop(
                side, actual_entry, current, planned_entry, planned_stop,
                min_liquidity_points=float(rule["min_liquidity_points"]),
                safety_buffer_points=float(rule["safety_buffer_points"]),
                cap_points=float(rule["max_stop_points"]),
                point_value=pv,
                digits=digits,
            )
        tid = str(row.get("id"))
        if corrected is None:
            updates: Dict[str, Any] = {"execution_stop_normalized": True,
                                       "execution_stop_points": actual_pts}
            updates.update(_entry_updates)
            self.database.update_trade(tid, updates)
            row.update(updates)
            return current
        if executor.apply_stop(tid, corrected, float(row.get("tp2") or 0),
                               row.get("symbol")):
            updates = {
                "stop_loss": corrected,
                "execution_stop_normalized": True,
                "execution_stop_points": required_pts,
            }
            if not be_completion:
                # Only the liquidity-law path re-derives the INITIAL stop; the
                # BE completion must keep the original structural stop as the
                # risk reference (min_breakeven_rr measures R against it).
                updates["initial_stop_loss"] = corrected
            updates.update(_entry_updates)
            self.database.update_trade(tid, updates)
            row.update(updates)
            _why = ("breakeven re-armed at TRUE fill"
                    if be_completion else "liquidity law")
            self._notify(
                f"🧪 DEMO: MT5 applied: execution stop corrected from "
                f"{format_price(current, symbol, self.config)} "
                f"({actual_pts:.1f} pts) to "
                f"{format_price(corrected, symbol, self.config)} "
                f"({required_pts:.1f} pts; {_why})"
                + (f" · entry reconciled to "
                   f"{format_price(raw_fill, symbol, self.config)}"
                   if fill_mismatch else ""))
            return corrected
        return current  # broker refusal: DB untouched, retry on the next tick

    def _per_symbol_laws(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """BUILD 19: the stop/trailing/breakeven laws for THIS trade's symbol.

        The tick manager is constructed with the base (gold) config. A WTI
        row is managed with the WTI instrument profile - which since BUILD 31
        (2026-08-24, operator order) carries the SAME law as gold in oil
        points (stop band [270, 400], trailing 150/40, breakeven +150).
        config_for_instrument merges the per-symbol DEFAULT_INSTRUMENTS
        profile into the base config; the result is
        cached per symbol so the hot loop never re-merges.
        """
        symbol = normalize_symbol(str(row.get("symbol") or self.config.get("symbol") or "XAU/USD"))
        laws = self._symbol_law_cache.get(symbol)
        if laws is not None:
            return laws
        try:
            if symbol == normalize_symbol(str(self.config.get("symbol") or "XAU/USD")):
                cfg = self.config
            else:
                cfg = config_for_instrument(self.config, {"symbol": symbol})
            # R26.9.2: the momentum clutch rides the same per-symbol law
            # block (utils.trading_rules is its single params source).
            laws = {"trailing": trailing_params(cfg),
                    "stop": stop_rule(cfg),
                    "clutch": momentum_clutch_params(cfg, symbol)}
        except Exception:  # noqa: BLE001 - fall back to the old base behaviour
            laws = {"trailing": self._trail, "stop": stop_rule(self.config),
                    "clutch": momentum_clutch_params(self.config, symbol)}
        self._symbol_law_cache[symbol] = laws
        return laws

    def _m5_candles(self, executor, symbol: str) -> List[Dict[str, Any]]:
        """Recent M5 candles (oldest -> newest, forming candle INCLUDED) for
        the clutch, cached for a few seconds — the impulse tests read CLOSED
        candles, so a 5s refresh is far fresher than the law needs while the
        0.25s loop never hammers copy_rates. Fail-open: any error -> []."""
        sym = str(symbol or "XAU/USD")
        now = time.monotonic()
        cached = self._m5_cache.get(sym)
        if cached and (now - cached[0]) < self._m5_ttl:
            return cached[1]
        candles: List[Dict[str, Any]] = []
        try:
            from services.mt5_executor import _mt5_ready
            mt5 = _mt5_ready()
            if mt5 is not None:
                broker_sym = executor._sym(sym)
                count = 30  # atr_period(14) + anchor(5) + speed(2) + margin
                rates = mt5.copy_rates_from_pos(
                    broker_sym, getattr(mt5, "TIMEFRAME_M5", 5), 0, count)
                if rates is not None and len(rates):
                    candles = [
                        {"open": float(r["open"]), "high": float(r["high"]),
                         "low": float(r["low"]), "close": float(r["close"]),
                         "time": float(r["time"])}
                        for r in rates
                    ]
        except Exception as exc:  # noqa: BLE001 - clutch is fail-open
            logger.debug("M5 candle fetch failed for %s: %s", sym, exc)
        self._m5_cache[sym] = (now, candles)
        return candles

    def _maybe_arm_tp1_breakeven(self, row, executor, tid, side, entry,
                                 stop, tp2, price) -> None:
        """BUILD 31 (2026-08-24, operator report): move the SL to entry once
        TP1 is booked - PAPER PARITY.

        The 5-minute OpenTradesManager applies
        ``auto_move_sl_to_entry_after_tp1`` (with the ``min_breakeven_rr``
        noise floor) when it books a TP1 partial. In mt5_demo that manager is
        bypassed - the tick manager OWNS execution - so the rule silently never
        ran: a TP1_HIT row kept its original structural stop (live WTI incident
        2026-08-24: SELL 85.36, TP1 tagged at ~84.73, half already secured,
        stop still far below). We resolve the SAME parameters through the SAME
        manager class, so demo and paper decide identically - including the
        deliberate deferral when TP1 is closer than min_breakeven_rr.
        """
        if row.get("sl_moved_to_entry") or entry <= 0 or price <= 0:
            return
        try:
            symbol = normalize_symbol(
                str(row.get("symbol") or self.config.get("symbol") or "XAU/USD"))
            mgr = self._symbol_mgr_cache.get(symbol)
            if mgr is None:
                from agents.open_trades_manager import OpenTradesManager
                if symbol == normalize_symbol(
                        str(self.config.get("symbol") or "XAU/USD")):
                    cfg = self.config
                else:
                    cfg = config_for_instrument(self.config, {"symbol": symbol})
                mgr = OpenTradesManager(cfg)
                self._symbol_mgr_cache[symbol] = mgr
            params = mgr._management_params(row, symbol)
        except Exception:  # noqa: BLE001 - never block the TP1 booking
            params = {"auto_be": True, "min_breakeven_rr": 0.5}
        if not bool(params.get("auto_be")):
            return
        pv = point_size(symbol, self.config)
        if pv <= 0:
            return
        risk_reference = float(row.get("initial_stop_loss") or stop or 0)
        risk_points = (abs(entry - risk_reference) / pv
                       if risk_reference > 0 else 0.0)
        travelled = ((price - entry) if side != "SELL"
                     else (entry - price)) / pv
        if travelled < 0:
            return  # never tighten a stop THROUGH live price
        travelled_rr = (travelled / risk_points) if risk_points > 0 else 0.0
        min_be_rr = float(params.get("min_breakeven_rr") or 0.0)
        if min_be_rr > 0 and risk_points > 0 and travelled_rr < min_be_rr:
            logger.info(
                "BUILD 31: TP1 breakeven deferred for %s: only %.2fR travelled "
                "(floor %.2fR) - keeping the structural stop so noise does not "
                "close a correct trade flat (same rule as the 5m cycle)",
                tid, travelled_rr, min_be_rr)
            return
        be_price = breakeven_stop(self.config, row.get("symbol"), side, entry)
        if executor.apply_stop(tid, be_price, float(tp2 or 0), row.get("symbol")):
            be_updates = {"sl_moved_to_entry": True, "stop_loss": be_price}
            self.database.update_trade(tid, be_updates)
            row.update(be_updates)
            self._notify(
                f"🧪 DEMO: MT5 applied: profit lock armed @ "
                f"{format_price(be_price, row.get('symbol'), self.config)} "
                f"after TP1 (entry {format_price(entry, row.get('symbol'), self.config)}; "
                f"confirmed at broker)")

    def _seed_extreme(self, executor, row: Dict[str, Any], pos, side: str) -> float:
        """Restart-lossless extreme: seed from the broker's M1 candles since
        the position opened (operator directive 2026-08-10: the trailing must
        respect the highest price reached, including gaps while we were down).
        """
        from services.mt5_executor import _mt5_ready
        mt5 = _mt5_ready()
        sym = executor._sym(str(row.get("symbol") or "XAU/USD"))
        seed = float(row.get("entry_price") or 0)
        try:
            open_time = int(getattr(pos, "time", 0) or 0)
            if open_time > 0:
                rates = mt5.copy_rates_range(
                    sym, getattr(mt5, "TIMEFRAME_M1", 1),
                    open_time, int(time.time()))
                if rates is not None and len(rates):
                    if side == "BUY":
                        seed = max(float(r["high"]) for r in rates)
                    else:
                        seed = min(float(r["low"]) for r in rates)
        except Exception as exc:  # noqa: BLE001
            logger.warning("extreme seeding failed (%s); using entry", exc)
        return seed

    def _pending_stale(self, row: Dict[str, Any], tick) -> bool:
        """Demo mirror of the paper pending_freshness rules (config-driven):
        cancel when older than stale_after_hours, OR the thesis is dead
        (plan invalidation breached), OR - only when the operator re-enables
        the legacy rule - when price ran away stale_after_excursion_points.

        2026-08-19 (build 12, operator order): the arbitrary excursion kill
        is OFF by default. A $25 drift used to cancel a pending whose thesis
        was intact and whose price later returned. The market-based kill is
        now ONLY the plan invalidation breach.
        """
        pf = (self.config.get("pending_freshness") or {})
        if not pf.get("enabled", True):
            return False
        raw = str(row.get("created_at") or "")
        try:
            created = datetime.fromisoformat(raw.replace("Z", "+00:00"))
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            # R25.7-G v2 (operator order 2026-08-29): the pending completes
            # its configured life, and the age NEVER counts Saturday or
            # Sunday — a Friday-evening pending checked Monday morning is
            # only as old as its live-market hours.
            age_h = effective_pending_age_hours(
                created, datetime.now(timezone.utc), self.config)
        except Exception:  # noqa: BLE001
            return False
        # R25-2 (2026-08-28): a resting SCALP carries its own short TTL -
        # the fade is only valid while the rejection is fresh. Rows flagged
        # r25_scalp expire at r25_scalp.ttl_minutes instead of the global
        # staleness window; the invalidation kill below still applies.
        _sctx = ((row.get("signal_snapshot") or {}).get("setup_context") or {})
        if _sctx.get("r25_scalp"):
            _ttl_min = float(((self.config.get("r25_scalp") or {})
                              .get("ttl_minutes")) or 45.0)
            if age_h * 60.0 >= _ttl_min:
                logger.info(
                    "R25-2 scalp TTL %.0f min reached - pending %s expires "
                    "(the fade died of old age, not of price)",
                    _ttl_min, row.get("id") or row.get("trade_id"))
                return True
        # R35 (operator 2026-09-08): pending lifetime obeys the SESSION
        # QUALITY the order was born in (HIGH 10h / MEDIUM 8h / LOW 6h),
        # not one flat number. Unknown quality uses the base value.
        from utils.helpers import pending_stale_ttl_hours as _pend_ttl
        if age_h >= _pend_ttl(row, self.config):
            return True
        side = str(row.get("type") or row.get("side") or "").upper()
        price = float(getattr(tick, "bid" if side == "BUY" else "ask", 0.0) or 0.0)
        entry = float(row.get("entry_price") or 0)
        if entry <= 0 or price <= 0:
            return False
        # thesis-death kill (operator order): plan invalidation breached
        if bool(pf.get("invalidation_kill_enabled", True)):
            inv = row.get("invalidation_level")
            if not isinstance(inv, (int, float)):
                snap = row.get("signal_snapshot") or {}
                plan = snap.get("session_plan") if isinstance(snap, dict) else None
                inv = (plan or {}).get("invalidation_level") if isinstance(plan, dict) else None
            if isinstance(inv, (int, float)) and float(inv) > 0:
                if side == "BUY" and price < float(inv):
                    return True
                if side == "SELL" and price > float(inv):
                    return True
        # legacy excursion rule - OFF unless the operator re-enables it
        if bool(pf.get("excursion_kill_enabled", False)):
            excursion = (price - entry) if side == "BUY" else (entry - price)
            return excursion >= float(pf.get("stale_after_excursion_points", 250)) * 0.10
        return False

    def _symbol_slot_taken(self, row) -> str | None:
        """R26.9.9 broker-boundary guard (operator 2026-09-01, the gold law):
        ONE open trade per symbol; the add engine owns the only legal second
        position. Every creation path funnels through ensure_ticket, so this
        single choke point physically enforces the law whatever upstream
        guards missed (live: THREE full GBP/USD entries filled within 5
        minutes because resting PENDING rows were invisible to the risk
        counts). An ADD row (signal.scale_in) is exempt -- it is governed by
        its own engine (one per parent, half size, loss-only by geometry).
        Returns the blocking row's id, or None when the slot is free. Fails
        OPEN: a DB read error must never break order placement."""
        try:
            rows = self.database.get_open_trades() or []
        except Exception:  # noqa: BLE001
            return None
        sig = row.get("signal") or ((row.get("signal_snapshot") or {}).get("signal") or {})
        if not isinstance(sig, dict):
            sig = {}
        if bool(sig.get("scale_in") or row.get("scale_in")):
            return None
        tid = str(row.get("id") or row.get("trade_id") or "")
        sym = normalize_symbol(row.get("symbol") or "")
        for other in rows:
            oid = str(other.get("id") or other.get("trade_id") or "")
            if not oid or oid == tid:
                continue
            if normalize_symbol(other.get("symbol") or "") != sym:
                continue
            if str(other.get("status") or "").upper() in {"OPEN", "PARTIAL", "TP1_HIT", "PENDING"}:
                return oid
        return None

    def _reconcile_pending(self, rows, executor) -> None:  # pragma: no cover
        """Broker pending orders whose DB row is gone (cancelled/replaced)
        must be cancelled at the broker too — otherwise ghost fills."""
        active = {magic_for(str(r.get("id"))) for r in rows}
        for o in executor.open_orders():
            mg = getattr(o, "magic", None)
            if mg is not None and mg not in active:
                if executor.cancel_order(int(o.ticket)):
                    self._notification_row = None
                    self._notify(
                        f"🧪 DEMO: stale pending #{int(o.ticket)} cancelled "
                        f"at broker (row no longer active)")

    def _reconcile_opposite_exposure(self, rows, executor) -> None:  # pragma: no cover - broker integration
        """Repair legacy BUY+SELL overlap: newest side survives, older exits."""
        groups: Dict[str, List[tuple[Dict[str, Any], Any, float]]] = {}
        for row in rows or []:
            if str(row.get("status") or "").upper() not in {"OPEN", "PARTIAL", "TP1_HIT"}:
                continue
            side = str(row.get("type") or row.get("side") or "").upper()
            if side not in {"BUY", "SELL"}:
                continue
            pos = executor._position_by_magic(magic_for(str(row.get("id"))))
            if pos is None:
                continue
            opened = float(getattr(pos, "time", 0) or 0)
            if opened <= 0:
                try:
                    opened = datetime.fromisoformat(
                        str(row.get("entry_time") or row.get("created_at") or "").replace("Z", "+00:00")
                    ).timestamp()
                except Exception:
                    opened = 0.0
            symbol = str(row.get("symbol") or "XAU/USD").upper()
            groups.setdefault(symbol, []).append((row, pos, opened))

        for symbol, items in groups.items():
            sides = {str(r.get("type") or r.get("side") or "").upper() for r, _, _ in items}
            if len(sides) < 2:
                continue
            newest = max(
                items,
                key=lambda item: (item[2], int(getattr(item[1], "ticket", 0) or 0)),
            )
            newest_side = str(newest[0].get("type") or newest[0].get("side") or "").upper()
            for row, _pos, _opened in items:
                side = str(row.get("type") or row.get("side") or "").upper()
                if side == newest_side:
                    continue
                tid = str(row.get("id"))
                if not executor.close_position(tid, row.get("symbol")):
                    continue
                lc = executor.last_close
                entry = float(row.get("entry_price") or 0)
                # BUILD 22.2: points in the ROW's symbol scale (oil = $0.01,
                # gold = $0.10). The hardcoded *10 printed "-12 pts" for a
                # -120-point oil close.
                pv = point_size(str(row.get("symbol") or "XAU/USD"), self.config)
                pnl = (float(lc.get("price") or 0) - entry) / pv
                if side == "SELL":
                    pnl = -pnl
                updates = {
                    "status": "THESIS_EXIT", "requested_exit": False,
                    "requested_exit_reason": "OPPOSITE_ENTRY_RECONCILIATION",
                    "close_price": lc.get("price"), "pnl_points": round(pnl, 1),
                    "reasons": [f"Closed older {side} because newer {newest_side} exposure exists"],
                }
                self.database.update_trade(tid, updates)
                row.update(updates)
                self._notification_row = row
                self._notify(
                    f"🧪 DEMO: MT5 applied: legacy opposite-exposure guard "
                    f"closed older {side} @ {format_price(float(lc.get('price') or 0), row.get('symbol'), self.config)} · "
                    f"kept newer {newest_side} · ticket {lc.get('ticket')}")

    def _magic_rows(self) -> List[Dict[str, Any]]:
        rows = self.database.get_open_trades() or []
        return [r for r in rows if str(r.get("status") or "") in
                {"PENDING", "OPEN", "TP1_HIT", "PARTIAL"}]

    def run_forever(self) -> None:  # pragma: no cover - VPS only
        from services.mt5_executor import Mt5DemoExecutor, magic_for, _mt5_ready
        mt5 = _mt5_ready()  # initialize ONCE — the terminal must be attached
        executor = Mt5DemoExecutor(self.config, telegram=self.telegram)
        # DB rows are throttled (Supabase free-tier protection — live incident:
        # usage-limit badge): ticks stay 0.25s via symbol_info_tick, while the
        # trade BOOK refreshes every ROWS_REFRESH_SECONDS. Row state changes
        # (new signal / status flip) are rare; 3s staleness is invisible.
        rows: List[Dict[str, Any]] = []
        rows_at = 0.0
        beat_at = 0.0
        while True:
            try:
                now = time.time()
                # Always feed Auction Flow first. The old loop requested a tick
                # only inside `for row in rows`, so a flat book meant no flow
                # data at all. This call is independent of open positions.
                self._collect_auction_tick(mt5, executor, now)
                self._collect_aux_ticks(mt5, executor, now)
                if now - rows_at >= ROWS_REFRESH_SECONDS:
                    rows = self._magic_rows()
                    rows_at = now
                    self._reconcile_opposite_exposure(rows, executor)
                    self._reconcile_pending(rows, executor)
                if now - beat_at >= 30:
                    try:
                        self._write_heartbeat()
                    except Exception as exc:  # noqa: BLE001
                        logger.warning("tick heartbeat write failed: %s", exc)
                    finally:
                        # Do not hammer the disk four times/second on failure.
                        beat_at = now
                for row in rows:
                    # Route through the broker symbol map (XAU/USD -> XAUUSD.s);
                    # a raw slash-strip goes blind on suffix brokers.
                    sym = executor._sym(str(row.get("symbol") or "XAU/USD"))
                    tick = mt5.symbol_info_tick(sym)
                    if tick is None:
                        continue
                    self._handle_row(row, tick, executor, mt5)
            except Exception as exc:  # noqa: BLE001 - loop must survive
                logger.warning("tick cycle error: %s", exc)
            time.sleep(LOOP_SLEEP)

    def _zone_runtime(self, row: Dict[str, Any]) -> tuple[Dict[str, Any], Dict[str, Any]]:
        snapshot = deepcopy(row.get("signal_snapshot") or {})
        if not isinstance(snapshot, dict):
            snapshot = {}
        runtime = snapshot.setdefault("pending_runtime", {})
        if not isinstance(runtime, dict):
            runtime = {}
            snapshot["pending_runtime"] = runtime
        return snapshot, runtime

    def _persist_zone_runtime(self, row: Dict[str, Any], **values: Any) -> None:
        snapshot, runtime = self._zone_runtime(row)
        runtime.update(values)
        updates = {"signal_snapshot": snapshot}
        self.database.update_trade(str(row.get("id")), updates)
        row.update(updates)

    def _zone_touch_convert(self, row, tick, executor, side: str, magic: int) -> bool:
        """Tick-native, broker-first LIMIT -> MARKET conversion.

        Returns True when this tick is fully handled. The DB is never marked
        OPEN until MT5 confirms a position. News is intentionally irrelevant
        here: this path is already armed by a real zone touch and exits on the
        first favourable tick.
        """
        cfg = ((self.config.get("order_execution") or {})
               .get("zone_touch_activation") or {})
        if not bool(cfg.get("enabled", False)):
            return False
        if not str(row.get("order_type") or "").upper().endswith("LIMIT"):
            return False
        entry = float(row.get("entry_price") or 0)
        symbol = row.get("symbol") or "XAU/USD"
        pv = float(point_size(symbol, self.config) or 0)
        price = float(tick.ask if side == "BUY" else tick.bid or 0)
        snapshot, runtime = self._zone_runtime(row)
        # zone_width_points is the GOLD base. Resolve this row through the
        # one canonical instrument ratio: XAU x1.0, WTI x0.5, FX x1.5.
        base_width = float(cfg.get("zone_width_points", 80) or 80)
        resolved_width = base_width * float(distance_ratio(self.config, symbol))
        decision = zone_touch_tick_decision(
            side, price, entry, pv, armed=bool(runtime.get("zone_touch_armed")),
            width_points=resolved_width)
        if decision.get("armed") and not runtime.get("zone_touch_armed"):
            self._persist_zone_runtime(
                row, zone_touch_armed=True,
                zone_touch_at=datetime.now(timezone.utc).isoformat(),
                zone_touch_low=round_price(decision["zone_low"], symbol, self.config),
                zone_touch_high=round_price(decision["zone_high"], symbol, self.config),
                zone_touch_width_points=resolved_width,
                zone_touch_distance_ratio=float(distance_ratio(self.config, symbol)))
        if not decision.get("activate"):
            return False
        tid = str(row.get("id"))
        # Reject a gap that skipped too far toward TP1, and reject plans whose
        # own geometry is already below the configured RR floor. These checks
        # happen BEFORE touching the broker pending order.
        stop0 = float(row.get("stop_loss") or 0)
        tp10 = float(row.get("tp1") or 0)
        tp20 = float(row.get("tp2") or 0)
        risk0 = abs(entry - stop0)
        min_rr = float(cfg.get("min_remaining_rr", 1.0) or 1.0)
        rr_gate = zone_rr_floor_decision(entry, stop0, tp20, pv, min_rr)
        self._persist_zone_runtime(
            row,
            zone_rr_raw=round(float(rr_gate["raw_rr"]), 8),
            zone_rr_floor=min_rr,
            zone_rr_risk_points=round(float(rr_gate["risk_points"]), 4),
            zone_rr_reward_points=round(float(rr_gate["reward_points"]), 4),
            zone_rr_rounding_tolerance_points=float(rr_gate["tolerance_points"]),
            zone_rr_floor_passed=bool(rr_gate["allow"]),
        )
        if not rr_gate["allow"]:
            self._persist_zone_runtime(row, zone_conversion_blocked="RR below minimum")
            return True
        edge = decision["zone_high"] if side == "BUY" else decision["zone_low"]
        target_span = abs(tp10 - edge)
        progress = (abs(price - edge) / target_span * 100.0) if target_span > 0 else 0.0
        if progress > float(cfg.get("max_target_progress_pct", 60) or 60):
            self._persist_zone_runtime(row, zone_conversion_blocked="target progress exceeded")
            return True
        if tid in self._zone_conversion_locks:
            return True
        self._zone_conversion_locks.add(tid)
        try:
            # Race check before cancellation: the LIMIT may have filled on
            # the same broker tick that made us decide to convert.
            if executor._position_by_magic(magic) is not None:
                return False
            order = executor._order_by_magic(magic)
            cancel_confirmed = bool(runtime.get("zone_pending_cancelled"))
            ticket = int(getattr(order, "ticket", row.get("mt5_ticket") or 0)) if order else int(row.get("mt5_ticket") or 0)
            if order is None and not cancel_confirmed:
                self._persist_zone_runtime(row, zone_conversion_blocked="broker pending not found")
                return True
            if order is not None:
                self._persist_zone_runtime(row, zone_conversion_state="CANCEL_REQUESTED",
                                           zone_conversion_blocked=None)
                if not ticket or not executor.cancel_order(ticket):
                    self._persist_zone_runtime(row, zone_conversion_state="CANCEL_FAILED",
                                               zone_conversion_blocked="broker cancel failed")
                    return True
                # Cancellation is not trusted until MT5 confirms both sides of
                # the race: no pending order and no position created by it.
                raced_pos = executor._position_by_magic(magic)
                if raced_pos is not None:
                    return False
                if executor._order_by_magic(magic) is not None:
                    self._persist_zone_runtime(row, zone_conversion_state="CANCEL_UNCONFIRMED",
                                               zone_conversion_blocked="broker cancel unconfirmed")
                    return True
                self._persist_zone_runtime(row, zone_conversion_state="CANCEL_CONFIRMED",
                                           zone_pending_cancelled=True,
                                           zone_pending_ticket_cancelled=ticket)

            planned_stop = float(row.get("stop_loss") or 0)
            delta = price - entry
            shifted_stop = planned_stop + delta if planned_stop else 0.0
            shifted_tp2 = float(row.get("tp2") or 0) + delta if row.get("tp2") else 0.0
            market_ticket = executor.ensure_ticket(
                tid, side, "MARKET", 0.0, shifted_stop, shifted_tp2, symbol)
            if not market_ticket:
                self._persist_zone_runtime(row, zone_conversion_blocked="market send failed",
                                           zone_pending_cancelled=True)
                return True
            pos = executor._position_by_magic(magic)
            if pos is None:
                # DEAL accepted but position not visible yet: persist the
                # recoverable state and wait for broker confirmation. Never
                # publish OPEN from an order_send response alone.
                self._persist_zone_runtime(
                    row, zone_conversion_state="MARKET_SENT",
                    zone_market_ticket=int(market_ticket),
                    zone_planned_entry=entry, zone_planned_stop=planned_stop,
                    zone_planned_tp1=row.get("tp1"), zone_planned_tp2=row.get("tp2"),
                    zone_planned_tp3=row.get("tp3"), zone_conversion_blocked=None)
                row["mt5_ticket"] = int(market_ticket)
                self.database.update_trade(tid, {"mt5_ticket": int(market_ticket)})
                return True
            actual = float(pos.price_open)
            actual_delta = actual - entry
            new_stop = planned_stop + actual_delta if planned_stop else 0.0
            targets = {}
            for key in ("tp1", "tp2", "tp3"):
                if row.get(key) not in (None, ""):
                    targets[key] = round_price(float(row[key]) + actual_delta, symbol, self.config)
            new_stop = round_price(new_stop, symbol, self.config) if new_stop else 0.0
            final_tp = float(targets.get("tp2") or shifted_tp2 or 0)
            if pos is not None and new_stop > 0:
                # The DEAL already carried an approximate shifted SL/TP; this
                # second call aligns them to the broker's exact fill price.
                executor.apply_stop(tid, new_stop, final_tp, symbol)
            updates = {"status": "OPEN", "entry_price": round_price(actual, symbol, self.config),
                       "stop_loss": new_stop, "mt5_ticket": int(getattr(pos, "ticket", market_ticket)),
                       "order_type": f"{side}_MARKET", "activation_reason": "ZONE_TOUCH_TICK_EXIT",
                       **targets}
            snapshot, runtime = self._zone_runtime(row)
            runtime.update({"zone_touch_activation": True, "zone_market_fill": updates["entry_price"],
                            "zone_pending_ticket_cancelled": ticket,
                            "zone_conversion_at": datetime.now(timezone.utc).isoformat(),
                            "zone_conversion_blocked": None})
            updates["signal_snapshot"] = snapshot
            self.database.update_trade(tid, updates)
            row.update(updates)
            self._send_execution_signal(row, actual_entry=actual, actual_stop=new_stop)
            self._notify(
                f"🧪 DEMO: zone touch converted tick-by-tick · pending #{ticket} cancelled "
                f"· {side} MARKET @ {format_price(actual, symbol, self.config)} "
                f"· SL/targets shifted to actual fill")
            return True
        finally:
            self._zone_conversion_locks.discard(tid)

    def _handle_row(self, row, tick, executor, mt5) -> None:  # pragma: no cover
        self._notification_row = row if isinstance(row, dict) else None
        tid = str(row.get("id"))
        side = str(row.get("type") or row.get("side") or "").upper()
        magic = magic_for(tid)
        pos = executor._position_by_magic(magic)
        status = str(row.get("status") or "")
        # Zombie guard: a terminal timestamp outranks a stale OPEN label.  A
        # closed row must never be placed again or managed as a live position.
        if row.get("closed_at"):
            logger.warning("zombie row ignored: %s is status=%s with closed_at=%s",
                           tid, status, row.get("closed_at"))
            return
        if status not in {"PENDING", "OPEN", "TP1_HIT", "PARTIAL"}:
            return  # cached row was closed/cancelled before the next DB refresh
        # BUILD 28 (2026-08-22): register THIS row's own tick price before any
        # card can be sent for it. The PENDING branch (pending fill / stale
        # cancel / placement) used to call _notify without ever storing its
        # row price, so the card fell back to the SHARED _last_price - the
        # last row processed in the loop. With WTI live that leaked the oil
        # price into a gold activation card (86.51 on XAU/USD, 2026-08-21).
        # The OPEN section below still re-registers the executable price
        # (bid/ask by side) used for BE/TP1/trailing.
        try:
            _px = float(tick.bid if side == "BUY" else tick.ask or 0.0)
        except (TypeError, ValueError):  # noqa: BLE001
            _px = 0.0
        if _px > 0:
            self._last_prices[tid] = _px
        if pos is None and row.get("close_price") is not None:
            return  # exit already booked; never manage/resurrect a closed row
        if pos is None and self._flip_dependencies_open(row, executor):
            return  # old opposite MT5 position must close broker-first

        if status == "PENDING":
            # Every tick: arm on entry into the fixed 80-point zone, then
            # broker-safely convert on the first favourable exit tick.
            if pos is None and row.get("mt5_ticket") and \
                    self._zone_touch_convert(row, tick, executor, side, magic):
                return
            if row.get("requested_exit"):
                _now_iso2 = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
                cancel_updates = {"status": "CANCELLED", "result": "CANCELLED",
                                  "requested_exit": False,
                                  "cancel_reason_code": "THESIS_EXIT_BEFORE_ACTIVATION",
                                  "cancel_reason": "thesis exit before activation",
                                  "reasons": ["thesis exit before activation"],
                                  "closed_at": _now_iso2, "close_time": _now_iso2}
                self.database.update_trade(tid, cancel_updates)
                row.update(cancel_updates)
                return
            if self._pending_stale(row, tick):
                # Stale pending (age / invalidation breach / legacy excursion):
                # cancel in the DB; _reconcile_pending cancels the broker order
                # and cards it. If it was never placed, card here instead.
                had_ticket = bool(row.get("mt5_ticket"))
                _now_iso = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
                stale_updates = {"status": "CANCELLED", "result": "CANCELLED",
                                 "cancel_reason_code": "TICK_STALE_RUNAWAY",
                                 "cancel_reason": "stale pending (freshness mirror)",
                                 "reasons": ["stale pending (freshness mirror)"],
                                 "closed_at": _now_iso, "close_time": _now_iso}
                self.database.update_trade(tid, stale_updates)
                row.update(stale_updates)
                if not had_ticket:
                    self._notify(
                        f"🧪 DEMO: MT5 applied: stale pending cancelled "
                        f"(age/excursion) — never placed")
                return
            if pos is not None:  # broker filled the pending / converted market
                # Complete a conversion whose DEAL was accepted one tick before
                # MT5 exposed the position. Rebuild SL and every target from the
                # actual broker fill before publishing OPEN.
                _snap_z, _rt_z = self._zone_runtime(row)
                if _rt_z.get("zone_conversion_state") == "MARKET_SENT":
                    _sym_z = row.get("symbol") or "XAU/USD"
                    _planned_entry_z = float(_rt_z.get("zone_planned_entry") or row.get("entry_price") or 0)
                    _delta_z = float(pos.price_open) - _planned_entry_z
                    _stop_z = float(_rt_z.get("zone_planned_stop") or row.get("stop_loss") or 0) + _delta_z
                    _target_z = {}
                    for _key_z in ("tp1", "tp2", "tp3"):
                        _raw_z = _rt_z.get(f"zone_planned_{_key_z}")
                        if _raw_z not in (None, ""):
                            _target_z[_key_z] = round_price(float(_raw_z) + _delta_z, _sym_z, self.config)
                    _stop_z = round_price(_stop_z, _sym_z, self.config)
                    executor.apply_stop(tid, _stop_z, float(_target_z.get("tp2") or 0), _sym_z)
                    _rt_z.update({"zone_conversion_state": "OPEN_CONFIRMED",
                                  "zone_market_fill": round_price(float(pos.price_open), _sym_z, self.config)})
                    _converted_updates = {"stop_loss": _stop_z, "order_type": f"{side}_MARKET",
                                          "activation_reason": "ZONE_TOUCH_TICK_EXIT",
                                          "signal_snapshot": _snap_z, **_target_z}
                    self.database.update_trade(tid, _converted_updates)
                    row.update(_converted_updates)
                # Book the ACTUAL fill price: PnL/BE/trailing must run on the
                # broker's execution, not our planned level. R25.15: rounded to
                # the SYMBOL's digits — round(x,2) destroyed 5-digit FX fills
                # (1.35504 -> 1.36 = the live GBPUSD entry defect).
                fill_updates = {"status": "OPEN",
                                "entry_price": round_price(float(pos.price_open), row.get("symbol"), self.config),
                                "lots": float(getattr(pos, "volume", 0) or 0),
                                "mt5_ticket": int(pos.ticket)}
                self.database.update_trade(tid, fill_updates)
                row.update(fill_updates)
                actual_stop = self._normalize_execution_stop(row, pos, executor, side)
                self._send_execution_signal(
                    row, actual_entry=float(pos.price_open), actual_stop=actual_stop)
                self._notify(
                    f"🧪 DEMO: MT5 applied: pending filled @ "
                    f"{format_price(pos.price_open, row.get('symbol'), self.config)} "
                    f"· ticket {int(pos.ticket)} "
                    f"(actual fill)")
            elif not row.get("mt5_ticket"):
                # The pending order has never been sent to MT5 — send it now.
                # ensure_ticket is idempotent (position + outstanding order).
                if not self._placement_due(tid):
                    return
                _blocker = self._symbol_slot_taken(row)
                if _blocker:
                    logger.info(
                        "R26.9.9 placement guard: %s %s stays unplaced — symbol already "
                        "committed by %s (one open trade per symbol; the add engine owns "
                        "the second)",
                        row.get("symbol"), tid, _blocker)
                    return
                kind = str(row.get("order_type") or "").upper()
                if not kind.endswith("LIMIT"):
                    kind = "BUY_LIMIT" if side == "BUY" else "SELL_LIMIT"
                ticket = executor.ensure_ticket(
                    tid, side, kind, float(row.get("entry_price") or 0),
                    float(row.get("stop_loss") or 0),
                    float(row.get("tp2") or 0), row.get("symbol"))
                if ticket:
                    self._placement_retry_at.pop(tid, None)
                    updates = {"mt5_ticket": ticket}
                    try:
                        if float((executor.last_order or {}).get("volume") or 0) > 0:
                            updates["lots"] = float(executor.last_order["volume"])
                    except (TypeError, ValueError):
                        pass
                    self.database.update_trade(tid, updates)
                    row.update(updates)
                    lo = executor.last_order
                    self._send_execution_signal(row)
                    if not lo.get("existing"):
                        self._notify(
                            f"🧪 DEMO: MT5 applied: {lo.get('kind', 'LIMIT')} "
                            f"order placed · vol {lo.get('volume')} @ "
                            f"{format_price(lo.get('price', float(row.get('entry_price') or 0)), row.get('symbol'), self.config)} "
                            f"· ticket {ticket}")
                    else:
                        logger.info("repaired missing DB ticket for existing pending %s -> %s",
                                    tid, ticket)
            # If Telegram was unavailable after broker placement, retry the
            # rich card on later ticks without touching the existing order.
            if row.get("mt5_ticket"):
                self._send_execution_signal(row)
            return
        if pos is None:
            # Never-placed OPEN rows (no ticket, no close) are ALWAYS
            # placement-eligible whatever their age — the card already went
            # to Telegram; silently starving them (old 60-min gate) is the
            # "card but no MT5 order" gap. Resurrection protection applies
            # only to rows that already have a close/ticket history.
            never_placed = (not row.get("mt5_ticket")) and \
                row.get("close_price") is None
            eligible = (status == "PENDING") or \
                (status == "OPEN" and (never_placed or _row_fresh(row)))
            if (not row.get("mt5_ticket")) and eligible:
                # PENDING rows stay placement-eligible for their whole life
                # (paper keeps pendings alive for hours; staleness cancella-
                # tion happens in the DB and _reconcile_pending mirrors it at
                # the broker). OPEN rows only while fresh — finished or stale
                # rows must NEVER be resurrected into new orders.
                if not self._placement_due(tid):
                    return
                _blocker = self._symbol_slot_taken(row)
                if _blocker:
                    logger.info(
                        "R26.9.9 placement guard: %s %s stays unplaced — symbol already "
                        "committed by %s (one open trade per symbol; the add engine owns "
                        "the second)",
                        row.get("symbol"), tid, _blocker)
                    return
                ticket = executor.ensure_ticket(
                    tid, side, "MARKET", 0.0,
                    float(row.get("stop_loss") or 0),
                    float(row.get("tp2") or 0), row.get("symbol"))
                if ticket:
                    self._placement_retry_at.pop(tid, None)
                    pos2 = executor._position_by_magic(magic)
                    upd: Dict[str, Any] = {"mt5_ticket": ticket}
                    if pos2 is not None:
                        upd["entry_price"] = round_price(float(pos2.price_open), row.get("symbol"), self.config)
                        upd["lots"] = float(getattr(pos2, "volume", 0) or 0)
                        upd["mt5_ticket"] = int(pos2.ticket)
                    elif float((executor.last_order or {}).get("price") or 0) > 0:
                        upd["entry_price"] = round_price(float(executor.last_order["price"]), row.get("symbol"), self.config)
                    self.database.update_trade(tid, upd)
                    row.update(upd)
                    actual_entry = float(upd.get("entry_price") or 0)
                    actual_stop = float(row.get("stop_loss") or 0)
                    if pos2 is not None:
                        actual_stop = self._normalize_execution_stop(
                            row, pos2, executor, side)
                        self._send_execution_signal(
                            row, actual_entry=actual_entry or None,
                            actual_stop=actual_stop or None)
                    # If positions_get needs another terminal tick, defer the
                    # rich card until the position exists and its stop is legal.
                    if not (executor.last_order or {}).get("existing"):
                        if actual_entry:
                            self._notify(
                                f"🧪 DEMO: MT5 applied: MARKET filled · vol "
                                f"{executor.lot} @ "
                                f"{format_price(actual_entry, row.get('symbol'), self.config)} · "
                                f"ticket {upd['mt5_ticket']}")
                        else:
                            self._notify(
                                f"🧪 DEMO: MT5 applied: MARKET order sent · "
                                f"ticket {ticket}")
                    else:
                        logger.info("repaired missing DB ticket for existing position %s -> %s",
                                    tid, upd["mt5_ticket"])
                return
            # broker closed it (SL / TP2 / trailing stop)
            # Mirror the REAL broker exit: deal price + realized P&L, not
            # the live tick at the moment we noticed the position was gone.
            exit_info = executor.last_exit(tid)
            entry = float(row.get("entry_price") or 0)
            stop = float(row.get("stop_loss") or 0)
            tp2 = float(row.get("tp2") or 0)
            if exit_info and exit_info["price"] > 0:
                close = exit_info["price"]
                status = classify_broker_exit(side, close, entry, stop, tp2)
                status = "TRAILING_SL_HIT" if status == "SL_HIT" and float(exit_info.get("profit", 0.0) or 0.0) > 0 else status
                # BUILD 22.2: points in the ROW's symbol scale. The hardcoded
                # *10 printed "-12 pts / -120.00$" for an oil close that was
                # actually -120 pts (the $ side comes from the broker deal).
                _pv_close = point_size(str(row.get("symbol") or "XAU/USD"), self.config)
                pnl_pts = (close - entry) / _pv_close
                if side == "SELL":
                    pnl_pts = -pnl_pts
                # BUILD 22: stamp the REAL close (broker deal time) so every
                # post-exit guard measures from the exit, not from the open.
                _closed = _close_stamp(exit_info)
                close_updates = {"status": status,
                                 "close_price": round_price(close, row.get("symbol"), self.config),
                                 "pnl_points": round(pnl_pts, 1),
                                 "closed_at": _closed, "close_time": _closed}
                # R25.15: the broker's deal profit IS the real USD PnL — stamp
                # it so the book and the weekly report carry dollars, not a
                # pts/10 gold-era estimate.
                try:
                    close_updates["pnl_usd"] = round(float(exit_info.get("profit", 0.0) or 0.0), 2)
                except (TypeError, ValueError):
                    pass
                self.database.update_trade(tid, close_updates)
                row.update(close_updates)
                self._notify(
                    f"🧪 DEMO: MT5 applied: position closed @ "
                    f"{format_price(close, row.get('symbol'), self.config)} "
                    f"({status}) · vol {exit_info.get('volume')} · "
                    f"ticket {exit_info.get('position')} "
                    f"{pnl_pts:+.0f} pts / {exit_info['profit']:+.2f}$")
            else:
                keep = status if status in {"TP1_HIT", "PARTIAL"} else "SL_HIT"
                close = tick.bid if side == "BUY" else tick.ask
                _closed = _now_iso_stamp()
                fallback_updates = {"status": keep,
                                    "close_price": round_price(close, row.get("symbol"), self.config),
                                    "closed_at": _closed, "close_time": _closed}
                self.database.update_trade(tid, fallback_updates)
                row.update(fallback_updates)
                self._notify(
                    f"🧪 DEMO: position closed by broker @ {format_price(close, row.get('symbol'), self.config)} "
                    f"(no exit deal found — labelled {keep}, verify)")
            return

        # A market DEAL can be accepted one terminal tick before positions_get
        # exposes it. Reconcile the broker's actual fill on every sight instead
        # of leaving the planned Telegram quote in the book forever.
        # R25.15: compare and store at the RAW fill — the old code rounded
        # pos.price_open to 2 decimals BEFORE comparing, so on 5-digit FX the
        # reconciler was blind by construction (1.35504 -> 1.36 == stored 1.36).
        _sym_rc = row.get("symbol")
        _pv_rc = point_size(_sym_rc or "XAU/USD", self.config)
        raw_entry = float(getattr(pos, "price_open", 0.0) or 0.0)
        actual_entry = round_price(raw_entry, _sym_rc, self.config) if raw_entry > 0 else 0.0
        actual_ticket = int(getattr(pos, "ticket", 0) or 0)
        mirror_updates: Dict[str, Any] = {}
        may_reconcile_entry = bool(row.get("mt5_ticket")) or \
            row.get("telegram_signal_sent") is False
        if (may_reconcile_entry and raw_entry > 0
                and abs(raw_entry - float(row.get("entry_price") or 0)) > 0.5 * _pv_rc):
            mirror_updates["entry_price"] = actual_entry
            mirror_updates["entry_fill_reconciled"] = True
        may_reconcile_ticket = bool(row.get("mt5_ticket")) or \
            row.get("telegram_signal_sent") is False
        if (may_reconcile_ticket and actual_ticket
                and int(row.get("mt5_ticket") or 0) != actual_ticket):
            mirror_updates["mt5_ticket"] = actual_ticket
        if mirror_updates:
            self.database.update_trade(tid, mirror_updates)
            row.update(mirror_updates)
            logger.info("reconciled broker fill for %s: %s", tid, mirror_updates)
        actual_stop = self._normalize_execution_stop(row, pos, executor, side)
        self._send_execution_signal(
            row, actual_entry=actual_entry or None,
            actual_stop=actual_stop or None)

        # thesis-exit handoff: analysis requested, broker executes first.
        if row.get("requested_exit"):
            if pos is None:
                self.database.update_trade(tid, {"requested_exit": False})
            elif executor.close_position(tid, row.get("symbol")):
                lc = executor.last_close
                _pv_thesis = point_size(str(row.get("symbol") or "XAU/USD"), self.config)
                pnl = (lc["price"] - float(row.get("entry_price") or 0)) / _pv_thesis
                if side == "SELL":
                    pnl = -pnl
                exit_reason = str(row.get("requested_exit_reason") or "THESIS_EXIT")
                _closed = _now_iso_stamp()
                thesis_updates = {"status": "THESIS_EXIT", "requested_exit": False,
                                  "requested_exit_reason": exit_reason,
                                  "close_price": lc["price"],
                                  "pnl_points": round(pnl, 1),
                                  "closed_at": _closed, "close_time": _closed,
                                  "reasons": [exit_reason]}
                # R25.15: dollars for the thesis exit — no broker deal profit
                # is exposed here, so derive it with risk_usd at the volume
                # the position actually held (unknown volume -> left absent,
                # never fabricated).
                try:
                    _t_lots = float(getattr(pos, "volume", 0)
                                    or (executor.last_close or {}).get("volume", 0)
                                    or row.get("lots") or 0)
                    if _t_lots > 0:
                        from services.risk_usd import usd_pnl as _usd_pnl
                        thesis_updates["pnl_usd"] = round(_usd_pnl(
                            row.get("symbol") or "XAU/USD", _t_lots,
                            float(row.get("entry_price") or 0), lc["price"],
                            side), 2)
                except Exception:  # noqa: BLE001 — money column never breaks exits
                    pass
                self.database.update_trade(tid, thesis_updates)
                row.update(thesis_updates)
                label = ("opposite-entry flip exit" if exit_reason == "OPPOSITE_ENTRY_FLIP"
                         else "entry-grade thesis exit")
                self._notify(
                    f"🧪 DEMO: MT5 applied: {label} closed @ "
                    f"{format_price(lc['price'], row.get('symbol'), self.config)} · vol {lc['volume']} · "
                    f"ticket {lc['ticket']} · {pnl:+.0f} pts")
            return
        if row.get("requested_partial") and pos is not None \
                and not row.get("partial_close"):
            if executor.partial_close_at_tp1(tid, 0.5, row.get("symbol")):
                lp = executor.last_partial
                scale_updates = {"requested_partial": False,
                                 "partial_close": True, "status": "PARTIAL"}
                self.database.update_trade(tid, scale_updates)
                row.update(scale_updates)
                if not lp.get("existing"):
                    self._notify(
                        f"🧪 DEMO: MT5 applied: thesis scale-out closed · vol "
                        f"{lp.get('volume')} @ {format_price(lp.get('price', 0), row.get('symbol'), self.config)} · "
                        f"remaining {lp.get('remaining')} · ticket "
                        f"{lp.get('ticket')}")

        entry = float(row.get("entry_price") or 0)
        stop = float(row.get("stop_loss") or 0)
        tp1 = float(row.get("tp1") or 0)
        risk = abs(entry - float(row.get("initial_stop_loss") or stop))
        # BUILD 19: per-symbol laws + per-symbol point value (oil = $0.01,
        # gold = $0.10). The hardcoded gold pv broke every oil distance math
        # in the live loop.
        _laws = self._per_symbol_laws(row)
        _trail = _laws["trailing"]
        pv = point_size(str(row.get("symbol") or "XAU/USD"), self.config)
        risk_points = risk / pv  # price delta -> codebase points
        # Use the price at which the position can actually be closed:
        # BUY closes on Bid; SELL closes on Ask. This keeps BE/TP1/trailing
        # aligned with MT5 rather than triggering one spread too early.
        price = tick.bid if side == "BUY" else tick.ask
        try:
            self._last_prices[str(row.get("id") or "")] = float(price or 0.0)
        except (TypeError, ValueError):  # noqa: BLE001
            pass
        if tid not in self._extremes:
            # first sight (fresh start/restart): seed from broker history so
            # peaks hit while we were down still ratchet the stop.
            self._extremes[tid] = self._seed_extreme(executor, row, pos, side)
        extreme = self._extremes[tid]
        extreme = max(extreme, price) if side == "BUY" else min(extreme, price)
        self._extremes[tid] = extreme

        # 0) SL drift guard: a manually/broker-moved stop that is WORSE than
        # the book's level is restored every tick (operator directive).
        broker_sl = float(getattr(pos, "sl", 0) or 0)
        db_stop = float(row.get("stop_loss") or 0)
        tp2 = float(row.get("tp2") or 0)
        # Instrument precision, not a gold-only $0.50 threshold. On FX the
        # old comparison could never detect a broker stop drifting backwards.
        drift_tolerance = max(pv * 0.5, 10 ** (-price_decimals(row.get("symbol"), self.config)) * 0.5)
        if broker_sl > 0 and db_stop > 0 and abs(broker_sl - db_stop) > drift_tolerance:
            worse = (broker_sl < db_stop) if side == "BUY" else \
                (broker_sl > db_stop)
            if worse:
                if executor.apply_stop(tid, db_stop, tp2, row.get("symbol")):
                    self._notify(
                        f"🧪 DEMO: MT5 applied: SL drift corrected back to "
                        f"{format_price(db_stop, row.get('symbol'), self.config)} (broker had {format_price(broker_sl, row.get('symbol'), self.config)})")
                elif tid not in self._drift_alerted:
                    # R37-2 (operator 2026-09-09): failure must not be silent
                    # either (SUCCESS IS NEVER SILENT, mirrored). The audited
                    # scale-in 35b38819 sat 15+ minutes with the ledger
                    # recording a trailed stop the broker never held -- MT5
                    # refused the modify and the trade finally paid the
                    # ORIGINAL stop (-$41.3) while the book showed a lock.
                    # One WARN per trade names the drift instead of hiding it.
                    self._drift_alerted.add(tid)
                    self._notify(
                        f"⚠️ DEMO WARN: MT5 REFUSED the SL drift restore for "
                        f"{tid} -- book stop {format_price(db_stop, row.get('symbol'), self.config)} "
                        f"vs broker {format_price(broker_sl, row.get('symbol'), self.config)}; "
                        f"ledger protection may not exist at the broker")

        # 1) breakeven
        if decide_be(side, entry, price, risk_points,
                     _trail["early_breakeven_points"], 0.5,
                     bool(row.get("sl_moved_to_entry"))):
            # Move FIRST at the broker; the card is sent ONLY when the
            # broker confirms. On refusal nothing is booked, so the next
            # tick retries (operator directive: truthful messages only).
            be_price = breakeven_stop(self.config, row.get("symbol"), side, entry)
            if executor.apply_stop(tid, be_price, float(row.get("tp2") or 0),
                                   row.get("symbol")):
                be_updates = {"sl_moved_to_entry": True, "stop_loss": be_price}
                self.database.update_trade(tid, be_updates)
                row.update(be_updates)
                stop = be_price
                self._notify(
                    f"🧪 DEMO: profit lock armed @ "
                    f"{format_price(be_price, row.get('symbol'), self.config)} "
                    f"(entry {format_price(entry, row.get('symbol'), self.config)}; "
                    f"confirmed at broker)")

        # 1b) Repair legacy/token protection. A pre-fix trail may already sit
        # one or a few points beyond entry, which prevents a fresh candidate
        # from clearing the normal trailing step. Upgrade that live stop to
        # the canonical profit-lock floor directly (ratchet-only).
        be_floor = breakeven_stop(self.config, row.get("symbol"), side, entry)
        token_protection = (
            (side == "BUY" and entry <= stop < be_floor) or
            (side == "SELL" and be_floor < stop <= entry)
        )
        if token_protection:
            executable_room = ((side == "BUY" and price > be_floor) or
                               (side == "SELL" and price < be_floor))
            if executable_room and executor.apply_stop(
                    tid, be_floor, float(row.get("tp2") or 0), row.get("symbol")):
                floor_updates = {"stop_loss": be_floor}
                self.database.update_trade(tid, floor_updates)
                row.update(floor_updates)
                stop = be_floor
                self._notify(
                    "🧪 DEMO: protected stop upgraded to canonical profit lock @ "
                    f"{format_price(be_floor, row.get('symbol'), self.config)} "
                    "(confirmed at broker)")

        # 2) TP1 partial — close ONLY the half (operator directive). Book it
        # only when the broker actually executed it. On refusal: keep
        # retrying every tick and report the broker's reason once per trade.
        # decide_tp1 expects candle low/high. On a live tick the executable
        # BUY high is Bid and the executable SELL low is Ask.
        if decide_tp1(side, tp1, tick.ask, tick.bid,
                      bool(row.get("partial_close"))):
            if executor.partial_close_at_tp1(tid, 0.5, row.get("symbol")):
                self._partial_alerted.discard(tid)
                lp = executor.last_partial
                # Persist the economics, not merely the PARTIAL label.  The
                # final settlement can now weight the TP1 slice correctly.
                closed_vol = float(lp.get("volume") or 0.0)
                remaining_vol = float(lp.get("remaining") or 0.0)
                total_vol = closed_vol + remaining_vol
                fraction = closed_vol / total_vol if total_vol > 0 else 0.5
                partial_price = float(lp.get("price") or tp1)
                partial_points = ((partial_price - entry) / pv) * (-1 if side == "SELL" else 1)
                partial_updates = {
                    "partial_close": True, "status": "TP1_HIT",
                    "closed_fraction": round(fraction, 4),
                    "realized_pnl_points": round(partial_points * fraction, 1),
                    "tp1_partial_price": round_price(partial_price, row.get("symbol"), self.config),
                }
                self.database.update_trade(tid, partial_updates)
                row.update(partial_updates)
                if not lp.get("existing"):
                    self._notify(
                        f"🧪 DEMO: MT5 applied: TP1 partial closed · vol "
                        f"{lp.get('volume')} @ {format_price(lp.get('price', tp1), row.get('symbol'), self.config)} · "
                        f"remaining {lp.get('remaining')} · ticket "
                        f"{lp.get('ticket')}")
                else:
                    logger.info("restored TP1 mirror from broker history for %s", tid)
                # BUILD 31: the paper path moves the stop to entry when TP1 is
                # booked (auto_be + min_breakeven_rr). In demo mode this tick
                # manager is the only manager - apply the same rule here.
                self._maybe_arm_tp1_breakeven(row, executor, tid, side, entry,
                                              stop, tp2, price)
            elif tid not in self._partial_alerted:
                self._partial_alerted.add(tid)
                self._notify(
                    f"🧪 DEMO: TP1 partial REJECTED for {tid}: "
                    f"{getattr(executor, 'last_error', 'unknown')} — "
                    f"retrying every tick")

        # 3) trailing ratchet — R26.9.2: the momentum clutch comes FIRST.
        # During an accelerated leg the fixed-gap trail (extreme ± 150 pts,
        # every 40 pts) chases the tick and gets shaken out by an ordinary
        # pullback. The clutch (R26.8 law, tick-side port) anchors the stop
        # to the last confirmed M5 swing structure with an ATR-scaled margin
        # and SUPPRESSES the tick chase while the impulse is live. Fail-open
        # on every error path: no candles / no ATR / disabled -> the normal
        # trail, exactly the pre-clutch behaviour.
        _clutch_params = _laws.get("clutch") or {}
        _clutch_hold = False
        _clutch_reason = ""
        new_stop = None
        if bool(_clutch_params.get("enabled", True)):
            _candles = self._m5_candles(executor, str(row.get("symbol") or "XAU/USD"))
            _st = clutch_state(_clutch_params, _candles, side, pv)
            if _st.get("active") and float(_st.get("atr_pts") or 0.0) > 0:
                _clutch_reason = str(_st.get("reason") or "impulse")
                new_stop = clutch_stop(
                    _clutch_params, side, stop, entry, _candles, pv,
                    float(_st["atr_pts"]),
                    price_decimals(row.get("symbol"), self.config))
                # None while the impulse is live = HOLD the current stop:
                # the tick trail must NOT run under an active clutch.
                _clutch_hold = new_stop is None
                if _clutch_hold:
                    logger.info(
                        "momentum clutch HOLD on %s (%s): impulse live, tick "
                        "trail suppressed (stop %.2f, extreme %.2f)",
                        tid, _clutch_reason, stop, extreme)
        if new_stop is None and not _clutch_hold:
            new_stop = decide_trailing(side, entry, stop, extreme,
                                       _trail["distance_points"],
                                       _trail["step_points"], pv,
                                       price_decimals(row.get("symbol"), self.config))
        if new_stop:
            # A trail crossing entry must honor the canonical BE profit lock,
            # never leave a token +1/+49-point stop while the configured lock
            # is +60 for FX. This only tightens; it can never move backwards.
            be_floor = breakeven_stop(self.config, row.get("symbol"), side, entry)
            if side == "BUY" and entry < new_stop < be_floor:
                new_stop = be_floor
            elif side == "SELL" and be_floor < new_stop < entry:
                new_stop = be_floor
            new_stop = round_price(new_stop, row.get("symbol"), self.config)
            if executor.apply_stop(tid, new_stop, float(row.get("tp2") or 0),
                                   row.get("symbol")):
                trail_updates = {"stop_loss": new_stop}
                # Keep the BE marker semantically pure: protection is also
                # recognized from stop geometry by is_protected().
                self.database.update_trade(tid, trail_updates)
                row.update(trail_updates)
                shown_stop = format_price(new_stop, row.get("symbol"), self.config)
                if _clutch_reason and not _clutch_hold:
                    self._notify(
                        f"🧪 DEMO: trailing stop moved to {shown_stop} "
                        f"(confirmed at broker) — momentum clutch: {_clutch_reason}; "
                        f"anchored on M5 structure +ATR margin instead of chasing the tick")
                else:
                    self._notify(f"🧪 DEMO: trailing stop moved to {shown_stop} "
                                 f"(confirmed at broker)")
            # refusal: apply_stop logged the retcode; DB untouched -> retried

    def _card_price_for(self, context: Dict[str, Any], event: str,
                        updates: Dict[str, Any]) -> float:
        """BUILD 31 (2026-08-24): the price a rich card may show for THIS row.

        Priority: this trade's own last tick -> (activation cards) the actual
        fill price -> the trade's own stored price -> 0. A card must NEVER
        fall back to another symbol's price: the old shared _last_price
        (last row processed in the loop) printed the oil price 85.33 on an
        XAU/USD activation card on 2026-08-24 (and 86.51 on 2026-08-21).
        """
        try:
            px = self._last_prices.get(str((context or {}).get("id") or ""), 0.0)
        except Exception:  # noqa: BLE001
            px = 0.0
        if px <= 0 and event == "ORDER_FILLED":
            try:
                px = float((updates or {}).get("entry_price") or 0.0)
            except (TypeError, ValueError):
                px = 0.0
        if px <= 0:
            try:
                px = float((context or {}).get("current_price") or 0.0)
            except (TypeError, ValueError):
                px = 0.0
        return px if px > 0 else 0.0

    def _notify(self, text: str, row: Dict[str, Any] | None = None) -> None:  # pragma: no cover
        """Send a broker lifecycle card with admission path on line one.

        BUILD 16 (2026-08-20): management events now ride the unified rich
        card builder (send_trade_events) so a trailing move / breakeven arm /
        protected close looks exactly like the 5-minute-cycle cards the
        operator approved. Only events we can map to a real trade event are
        upgraded; informational lines (drift corrections, retry notes) stay
        plain so no card ever claims a state the broker did not confirm.
        """
        context = row if isinstance(row, dict) and row else self._notification_row
        if (self.telegram and isinstance(context, dict) and context
                and hasattr(self.telegram, "send_trade_events")):
            parsed = self._rich_card_payload(text, context)
            if parsed:
                event, updates, new_status, pnl = parsed
                evaluation = {
                    "old_status": str(context.get("status") or "OPEN").upper(),
                    "new_status": new_status or str(context.get("status") or "OPEN").upper(),
                    "updates": updates,
                    "pnl_points": pnl,
                    "cancel_reason_code": str(context.get("cancel_reason_code") or ""),
                    "reasons": context.get("reasons") or [],
                }
                try:
                    _card_price = self._card_price_for(context, event, updates)
                    if _card_price > 0 and event not in {"TP2_HIT", "SL_HIT", "TRAILING_SL_HIT", "BE_HIT", "EXPIRED", "THESIS_EXIT", "MANUAL_CLOSE"}:
                        try:
                            _entry = float(updates.get("entry_price") or context.get("entry_price") or 0)
                            if _entry > 0:
                                from utils.instruments import price_to_points
                                _cside = str(context.get("type") or context.get("side") or "").upper()
                                _delta = (_card_price - _entry if _cside != "SELL" else _entry - _card_price)
                                pnl = price_to_points(_delta, symbol=str(context.get("symbol") or "XAU/USD"))
                                evaluation["pnl_points"] = pnl
                                updates["current_price"] = _card_price
                        except (TypeError, ValueError):
                            pass
                    # BUILD 28 (2026-08-22): the activation card carried a
                    # FLAT pnl=0.0 next to a live current price - a BUY card
                    # printing "Current Price" above entry with PnL +0.0 read
                    # as self-contradictory. Recompute against the fill price
                    # so the two lines always agree (0.0 at the fill instant,
                    # real drift a few ticks later).
                    if event == "ORDER_FILLED" and _card_price > 0:
                        try:
                            _entry = float(
                                updates.get("entry_price")
                                or context.get("entry_price") or 0)
                            if _entry > 0:
                                from utils.instruments import price_to_points

                                _cside = str(
                                    context.get("type")
                                    or context.get("side") or "").upper()
                                _delta = (_card_price - _entry
                                          if _cside != "SELL"
                                          else _entry - _card_price)
                                pnl = price_to_points(
                                    _delta,
                                    symbol=str(context.get("symbol")
                                                or "XAU/USD"))
                        except (TypeError, ValueError):  # noqa: BLE001
                            pass
                    # BUILD 28 R2 (2026-08-22, operator order): an ENTERING
                    # trade gets a FRESH Gemini opinion (forced, 5-min
                    # anti-hammer per symbol) so the card's display line -
                    # which reads the store - shows a current read. The
                    # hourly status update refreshes it too (30-min TTL);
                    # all other displays stay read-only. Fail-open.
                    if event == "ORDER_FILLED":
                        try:
                            from services import gemini_opinion_store as gos

                            _entry_px = float(
                                updates.get("entry_price")
                                or context.get("entry_price") or 0)
                            gos.refresh_opinion(
                                normalize_symbol(str(
                                    context.get("symbol") or "XAU/USD")),
                                self.config,
                                current_price=_entry_px, force=True)
                        except Exception:  # noqa: BLE001 - never block the card
                            pass
                    sent = bool(self.telegram.send_trade_events(
                        context, [event], _card_price, pnl, evaluation,
                    ))
                    if sent:
                        logger.info("[card] %s", text)
                        return
                except Exception:  # noqa: BLE001
                    pass  # fall through to the plain card
        header = (
            path_header(context)
            if isinstance(context, dict) and context
            else "🛣️ <b>NO EXECUTION PATH — BROKER RECONCILIATION</b>"
        )
        body = str(text or "")
        if not body.lstrip().startswith("🛣️"):
            body = f"{header}\n{body}"
        logger.info("[card] %s", body)  # visibility: cards hit the log too
        if self.telegram:
            try:
                self.telegram.send_message(body)
            except Exception:  # noqa: BLE001
                pass

    @staticmethod
    def _rich_card_payload(text: str, row: Dict[str, Any]) -> Any:
        """Map a tick-manager lifecycle line to (event, updates, new_status, pnl).

        Returns None when the line is informational-only (stays plain).
        """
        text = str(text or "")
        status = str(row.get("status") or "OPEN").upper()
        pnl = 0.0
        for key in ("pnl_points", "final_pnl", "current_pnl_points"):
            try:
                pnl = float(row.get(key))
                break
            except (TypeError, ValueError):
                continue
        import re as _re

        def _price_after(token: str) -> float | None:
            m = _re.search(token + r"\s+([0-9]+\.[0-9]+)", text)
            return float(m.group(1)) if m else None

        # trailing ratchet (broker-confirmed)
        m = _re.search(r"trailing stop moved to ([0-9]+\.[0-9]+)", text)
        if m:
            new_sl = float(m.group(1))
            return ("TRAILING_SL_UPDATED", {"stop_loss": new_sl}, status, pnl)
        # canonical profit lock (legacy "breakeven armed" still parseable)
        m = _re.search(r"(?:profit lock|breakeven) armed @ ([0-9]+\.[0-9]+)", text)
        if m:
            be_price = float(m.group(1))
            return ("MOVE_SL_TO_BE", {"stop_loss": be_price, "sl_moved_to_entry": True}, status, pnl)
        # protected/plain stop close written by the broker mirror
        m = _re.search(r"position closed @ ([0-9]+\.[0-9]+) \((\w+)\)", text)
        if m:
            close = float(m.group(1))
            closed_status = m.group(2).upper()
            event = closed_status if closed_status in {
                "SL_HIT", "TRAILING_SL_HIT", "TP2_HIT", "BE_HIT",
                "THESIS_EXIT", "MANUAL_CLOSE"} else "SL_HIT"
            # Legacy broker lines can still say SL_HIT after a protected stop.
            # Geometry must be direction-symmetric: BUY protects above entry;
            # SELL protects below entry. The old BUY-only `stop > entry` test
            # misclassified profitable SELL trailing exits.
            if event == "SL_HIT" and row.get("sl_moved_to_entry"):
                _side = str(row.get("type") or row.get("side") or "").upper()
                _stop = float(row.get("stop_loss") or 0)
                _entry = float(row.get("entry_price") or 0)
                _protected = ((_side == "BUY" and _stop > _entry) or
                              (_side == "SELL" and _stop < _entry) or
                              (_side not in {"BUY", "SELL"} and _stop != _entry))
                if _protected:
                    event = "TRAILING_SL_HIT"
            updates = {"close_price": close, "final_pnl": pnl, "pnl_points": pnl}
            # BUILD 22.2: carry the broker's REAL dollar profit from the
            # manager line ("+675 pts / +337.30$") so the rich card prints
            # the true realized USD next to the points.
            m_usd = _re.search(r"([+-][0-9]+\.[0-9]{2})\$", text)
            if m_usd:
                updates["realized_usd"] = float(m_usd.group(1))
            return (event, updates, closed_status, pnl)
        # broker closed without a deal found
        m = _re.search(r"position closed by broker @ ([0-9]+\.[0-9]+) \(no exit deal", text)
        if m:
            close = float(m.group(1))
            return ("SL_HIT", {"close_price": close, "final_pnl": pnl}, status, pnl)
        # thesis exits
        if "thesis exit" in text or "opposite-entry flip exit" in text or "legacy opposite-exposure guard" in text:
            close = _price_after("closed @")
            updates = {"close_price": close, "final_pnl": pnl, "pnl_points": pnl} if close else {}
            updates["reasons"] = [text]
            return ("THESIS_EXIT", updates, "THESIS_EXIT", pnl)
        # partial closes
        m = _re.search(r"TP1 partial closed", text)
        if m:
            px = _price_after("@")
            return ("TP1_HIT", {"partial_close": True, "close_price": px}, "TP1_HIT", pnl)
        m = _re.search(r"thesis scale-out closed", text)
        if m:
            px = _price_after("@")
            return ("THESIS_SCALE_OUT", {"partial_close": True, "scale_out_price": px}, "PARTIAL", pnl)
        # pending lifecycle
        if "stale pending cancelled" in text or "cancelled (row no longer active)" in text:
            return ("PENDING_CANCELLED", {
                "cancel_reason": text, "reasons": [text],
                "cancel_reason_code": row.get("cancel_reason_code") or "TICK_LIFECYCLE",
            }, "CANCELLED", pnl)
        # fills (only when the broker really filled; placement confirmations
        # stay plain - the rich activation card is sent by _send_execution_signal)
        m = _re.search(r"pending filled @ ([0-9]+\.[0-9]+)", text)
        if m:
            return ("ORDER_FILLED", {"entry_price": float(m.group(1))}, "OPEN", pnl)
        return None


def main() -> None:  # pragma: no cover - VPS only
    from services.database import DatabaseService
    from services.telegram_bot import TelegramService
    from utils.helpers import load_config
    from utils.single_instance import acquire_single_instance

    logging.basicConfig(level=logging.INFO)
    if not acquire_single_instance("tick_manager.pid", "run_tick_manager.py"):
        logger.info("tick manager already running; exiting duplicate instance")
        return
    cfg = load_config()
    if os.environ.get("EXECUTION_MODE") != "mt5_demo":
        logger.info("tick manager idle (EXECUTION_MODE != mt5_demo)")
        return
    TickManager(cfg, TelegramService(cfg), DatabaseService(cfg)).run_forever()


if __name__ == "__main__":
    main()
