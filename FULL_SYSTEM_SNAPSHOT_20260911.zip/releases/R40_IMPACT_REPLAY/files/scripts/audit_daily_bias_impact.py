# -*- coding: utf-8 -*-
"""DAILY-BIAS IMPACT REPLAY (READ ONLY) — operator request 2026-09-09.

Before re-enabling the daily-bias agent (daily_bias_filter.enabled=false in
config, discovered 2026-09-09), the operator demanded the exact impact:
which live trades WOULD have been refused, which were with-trend.

Method (read-only, writes nothing to MT5/ledger/telegram):
  1. Load every ledger trade (service loader).
  2. Fetch each symbol's 4H candles from MT5 (200+ bars).
  3. Slice history strictly BEFORE each entry_time (no future information).
  4. Run the REAL DailyBiasAgent on that slice -- its frozen formula
     (EMA 20/50, 12-bar slope, RSI 14, threshold 1.25).
  5. Replay the live gate verbatim (DecisionAgent contract):
       aligned / NEUTRAL               -> PASS
       contrarian & bias_conf >= 80    -> HARD BLOCK (would never ship)
       contrarian otherwise            -> SOFT GATE (needed 3 qualified
                                          supporters at >=80 signal conf --
                                          uncomputable retroactively, marked)
"""
from __future__ import annotations

import argparse
import json
import os
import sys

# VPS roots run this as `python scripts\audit_daily_bias_impact.py` -- the
# interpreter then puts scripts/ (not the repo root) on sys.path, so the
# project packages (agents/, utils/, services/) are invisible. Register the
# repo root FIRST, before any project import.
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from agents.daily_bias_agent import DailyBiasAgent
from utils.helpers import load_config, load_trades, setup_logging


def _ts(iso: str) -> Optional[float]:
    try:
        return datetime.fromisoformat(str(iso).replace("Z", "+00:00")).timestamp()
    except Exception:
        return None


def _side(t: Dict[str, Any]) -> str:
    for k in ("type", "trade_type", "side", "decision"):
        v = str(t.get(k) or "").upper()
        if v in {"BUY", "SELL"}:
            return v
    return ""


FETCH_NOTES: List[str] = []


def _resolve_mt5_symbol(mt5: Any, base: str) -> str:
    """Live VPS symbols carry a broker suffix (XAUUSD.s) -- the bare name
    returns zero bars, which starved every MT5 fetch in v5-v7."""
    candidates = [base, base + ".s", base + "_s", base + ".S"]
    for cand in candidates:
        try:
            if mt5.symbol_info(cand):
                mt5.symbol_select(cand, True)
                return cand
        except Exception:
            continue
    try:
        for s in mt5.symbols_get() or []:
            if base in getattr(s, "name", ""):
                mt5.symbol_select(s.name, True)
                return s.name
    except Exception:
        pass
    return base


def _fetch_4h_mt5(symbol: str, count: int = 400) -> List[Dict[str, Any]]:
    try:
        import MetaTrader5 as mt5
    except Exception as exc:  # noqa: BLE001
        FETCH_NOTES.append(f"MetaTrader5 import failed ({exc})")
        return []
    try:
        for _ in range(2):
            try:
                if mt5.terminal_info():
                    break
            except Exception:
                pass
            mt5.initialize()
        mt_sym = _resolve_mt5_symbol(mt5, symbol.replace("/", ""))
        rates = mt5.copy_rates_from_pos(mt_sym, mt5.TIMEFRAME_H4, 1, count)
        n = 0 if rates is None else len(rates)
        FETCH_NOTES.append(f"MT5 {symbol} ({mt_sym}): {n} H4 bars"
                           + (f" last_error={mt5.last_error()}" if n == 0 else ""))
        rows = [] if rates is None else list(rates)   # numpy array: truthiness ambiguous
        return [{"time": int(r["time"]), "open": float(r["open"]),
                 "high": float(r["high"]), "low": float(r["low"]),
                 "close": float(r["close"])} for r in rows]
    except Exception as exc:  # noqa: BLE001
        FETCH_NOTES.append(f"MT5 fetch crashed for {symbol}: {exc}")
        return []


def _fetch_4h_local_auction(symbol: str) -> List[Dict[str, Any]]:
    """Read-only fallback: resample the VPS's own auction-flow minute stores
    into 4H candles (the live DBs hold ~7 days per symbol)."""
    import sqlite3, os
    slug = symbol.replace("/", "").lower()
    path = f"storage/auction_flow_{slug}.sqlite3"
    if not os.path.exists(path):
        FETCH_NOTES.append(f"no local auction db for {symbol} ({path})")
        return []
    try:
        con = sqlite3.connect(path)
        try:
            rows = con.execute(
                "SELECT ts, open_mid, high_mid, low_mid, close_mid "
                "FROM minutes ORDER BY ts").fetchall()
            src = "minutes"
        except Exception:
            rows = con.execute(
                "SELECT ts, open_mid, high_mid, low_mid, close_mid "
                "FROM seconds ORDER BY ts").fetchall()
            src = "seconds"
        con.close()
    except Exception as exc:  # noqa: BLE001
        FETCH_NOTES.append(f"local auction db read failed {symbol}: {exc}")
        return []
    buckets: Dict[int, list] = {}
    for ts, o, h, l, c in rows:
        b = int(ts) - (int(ts) % 14400)
        buckets.setdefault(b, []).append((o, h, l, c))
    out = [{"time": b,
            "open": buckets[b][0][0],
            "high": max(x[1] for x in buckets[b]),
            "low": min(x[2] for x in buckets[b]),
            "close": buckets[b][-1][3]} for b in sorted(buckets)]
    FETCH_NOTES.append(f"LOCAL {symbol}: {len(out)} H4 bars from {path} ({src})")
    return out


def _fetch_4h(symbol: str, count: int = 400) -> List[Dict[str, Any]]:
    symbol = str(symbol or "").strip()
    rows = _fetch_4h_mt5(symbol, count)
    if not rows:
        rows = _fetch_4h_local_auction(symbol)
    return rows


def _entry_price_of(t: Dict[str, Any]) -> Any:
    ep = t.get("entry_price")
    if ep not in (None, "", 0):
        return ep
    sig = t.get("signal")
    if isinstance(sig, dict):
        e = sig.get("entry")
        if isinstance(e, dict) and e.get("price"):
            return e["price"]
        if sig.get("entry_price"):
            return sig["entry_price"]
    return ep


def replay(trades: List[Dict[str, Any]], config: Dict[str, Any]) -> Dict[str, Any]:
    db_cfg = (config.get("daily_bias_filter") or {})
    hard_min = float(db_cfg.get("block_strong_contrarian_below", 80) or 80)
    soft_agents = int(db_cfg.get("contrarian_min_agents_for_lower_confidence", 3) or 3)
    soft_conf = float(db_cfg.get("contrarian_min_confidence", 80) or 80)

    # Replay with the filter FORCE-ENABLED (read-only copy of config):
    # constructing the agent from the live config returned the famous
    # "Daily bias disabled" signature (NEUTRAL 0%) for every row -- the
    # exact bug being auditioned.
    replay_cfg = dict(config)
    _db = dict(replay_cfg.get("daily_bias_filter") or {})
    _db["enabled"] = True
    replay_cfg["daily_bias_filter"] = _db
    agent = DailyBiasAgent(replay_cfg)
    candle_cache: Dict[str, List[Dict[str, Any]]] = {}
    rows_out = []
    for t in trades:
        sym = str(t.get("symbol") or "?")
        side = _side(t)
        entry_iso = str(t.get("entry_time") or t.get("created_at") or "")
        ts = _ts(entry_iso)
        if sym not in candle_cache:
            candle_cache[sym] = _fetch_4h(sym)
        if not ts or side not in {"BUY", "SELL"}:
            rows_out.append({"trade_id": t.get("id"), "verdict": "SKIP",
                             "reason": "no entry_time/side"})
            continue
        candles = candle_cache.get(sym) or []
        pre = [c for c in candles
               if int(c.get("time") or 0) + 4 * 3600 <= int(ts)]
        if len(pre) < 50:
            rows_out.append({"trade_id": t.get("id"), "symbol": sym,
                             "type": side, "entry_time": entry_iso,
                             "verdict": "NO_DATA",
                             "candles_before_entry": len(pre)})
            continue
        verdict_agent = agent.analyze(
            {"symbol": sym, "timeframes": {"4H": {"data": pre}}})
        bias = str(verdict_agent.get("bias") or "NEUTRAL").upper()
        conf = float(verdict_agent.get("confidence") or 0.0)
        score = float(verdict_agent.get("score") or 0.0)
        npre = len(pre)
        contrarian = ((side == "SELL" and bias == "BULLISH")
                      or (side == "BUY" and bias == "BEARISH"))
        if not contrarian:
            gate = "PASS_WITH_TREND" if bias != "NEUTRAL" else "PASS_NEUTRAL"
        elif bias and conf >= hard_min:
            gate = "HARD_BLOCK"     # the 80% law kills it outright
        else:
            gate = "SOFT_GATE"      # would demand 3 qualified >=80 conf
        rows_out.append({
            "trade_id": str(t.get("id") or "")[-8:], "symbol": sym,
            "type": side,
            "path": str(t.get("execution_path_id") or "")[:28],
            "entry_price": _entry_price_of(t),
            "entry_time": entry_iso,
            "status": t.get("status"),
            "bias_4h": bias, "conf": conf, "score": round(score, 2),
            "ema_fast": verdict_agent.get("ema_fast"),
            "ema_slow": verdict_agent.get("ema_slow"),
            "verdict": gate,
            "candles_before_entry": npre,
            "detail": verdict_agent.get("summary", ""),
        })

    counts: Dict[str, int] = {}
    for r in rows_out:
        counts[r.get("verdict", "?")] = counts.get(r.get("verdict", "?"), 0) + 1
    return {
        "gate_thresholds": {
            "hard_block_bias_conf": hard_min,
            "soft_gate_min_qualified_agents": soft_agents,
            "soft_gate_min_signal_conf": soft_conf,
        },
        "counts": counts,
        "rows": rows_out,
    }


def fmt_lines(report: Dict[str, Any]) -> List[str]:
    lines = []
    gt = report["gate_thresholds"]
    lines.append("DAILY-BIAS IMPACT REPLAY (read only) — 2026-09-09")
    for note in FETCH_NOTES:
        lines.append(f"[fetch-diag] {note}")
    lines.append("Law replayed: contrarian & bias≥%.0f%% = HARD BLOCK; "
                 "contrarian otherwise = needs %d qualified agents & conf ≥%.0f"
                 % (gt["hard_block_bias_conf"],
                    gt["soft_gate_min_qualified_agents"],
                    gt["soft_gate_min_signal_conf"]))
    c = report.get("counts") or {}
    lines.append("Verdicts: " + " · ".join(f"{k}={v}" for k, v in sorted(c.items())))
    lines.append("-" * 100)
    for r in report.get("rows") or []:
        if r.get("verdict") in {"SKIP"}:
            continue
        mark = {"HARD_BLOCK": "BLOCKED ✗", "SOFT_GATE": "SOFT ?",
                "PASS_WITH_TREND": "pass ✓", "PASS_NEUTRAL": "pass -",
                "NO_DATA": "no-data"} .get(r.get("verdict"), r.get("verdict"))
        lines.append(
            f"{mark:9s} {(r.get('type') or ''):4s} {(r.get('symbol') or ''):8s} "
            f"@{str(r.get('entry_price')):10s} ({(r.get('entry_time') or '')[:16]}) "
            f"| 4H: {(r.get('bias_4h') or ''):8s} {r.get('conf')}% "
            f"score {r.get('score')} (n={r.get('candles_before_entry','?')}) "
            f"| {(r.get('status') or '')[:14]} | {(r.get('path') or '')} "
            f"| {(r.get('detail') or '')[:60]}")
    return lines


def main() -> None:
    parser = argparse.ArgumentParser(description="Daily bias impact replay (read only)")
    parser.add_argument("--trades", default=None,
                        help="optional trades json; default: project ledger via load_trades")
    args = parser.parse_args()
    setup_logging()
    if args.trades:
        with open(args.trades, "r", encoding="utf-8") as fh:
            payload = json.load(fh)
        trades = payload if isinstance(payload, list) else (payload.get("trades") or [])
    else:
        trades = load_trades() or []
    config = load_config() or {}
    report = replay(trades, config)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    txt_path = f"storage/daily_bias_impact_{stamp}.txt"
    with open(txt_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(fmt_lines(report)) + "\n")
    with open(f"storage/daily_bias_impact_{stamp}.json", "w", encoding="utf-8") as jf:
        json.dump(report, jf, ensure_ascii=False, indent=1)
    print("\n".join(fmt_lines(report)))
    print(f"\n[done] report: {txt_path}")


if __name__ == "__main__":
    main()
