@echo off
setlocal
echo ============================================================
echo  R40 DAILY-BIAS IMPACT REPLAY -- READ ONLY AUDIT
echo  No trading change. Answers: what would the daily agent have
echo  blocked / allowed for THIS ledger, per trade, on real 4H MT5.
echo  Requires MetaTrader5 terminal RUNNING with the demo symbols.
echo ============================================================
cd /d "%~dp0"
copy /y files\scripts\audit_daily_bias_impact.py scripts\audit_daily_bias_impact.py >nul
python scripts\audit_daily_bias_impact.py
echo.
echo Report written under storage\daily_bias_impact_*.txt
echo Upload that .txt (and .json) to the assistant for the verdict table.
pause
