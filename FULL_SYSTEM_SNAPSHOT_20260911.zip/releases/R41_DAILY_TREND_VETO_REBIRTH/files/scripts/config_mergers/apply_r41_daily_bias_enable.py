# -*- coding: utf-8 -*-
"""R41 merger: daily_bias_filter.enabled -> true (operator order 2026-09-09).

'Daily-trend veto rebirth' adopted after the R40 autopsy demonstrated the
disabled agent would have hard-blocked the -$318 WTI family and blocked no
winner except one small gold scalp-band trade. Frozen thresholds UNCHANGED:
hard block >=80% contrarian; soft gate = 3 qualified agents & signal
confidence >=80. PATH-7 (R25-2 scalp fade) and PATH-9 (sweep raid reversal)
stay exempt by architecture. Backup first; idempotent; writes an audit line.
"""
from __future__ import annotations

import io
import json
import shutil
from datetime import datetime, timezone

CFG = "config.json"


def main() -> None:
    cfg = json.load(io.open(CFG, encoding="utf-8"))
    db = cfg.get("daily_bias_filter") or {}
    if db.get("enabled") is True:
        print("[R41] already enabled - nothing to do")
        return
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup = f"config.backup_r41_{stamp}.json"
    shutil.copyfile(CFG, backup)
    db["enabled"] = True
    db.setdefault("hard_veto_operator_law",
                  "R41 2026-09-09: contrarian bias>=80% hard-blocks all paths; "
                  "PATH-7 scalp fade & PATH-9 sweep reversal exempt by lanes; "
                  "soft gate 3 qualified agents & conf>=80 unchanged")
    cfg["daily_bias_filter"] = db
    io.open(CFG, "w", encoding="utf-8").write(
        json.dumps(cfg, indent=2, ensure_ascii=False) + "\n")
    print(f"[R41] daily_bias_filter.enabled=false -> true (backup: {backup})")
    print("[R41] thresholds untouched: hard>=80, soft 3x80, ema20/50, slope12")


if __name__ == "__main__":
    main()
