# -*- coding: utf-8 -*-
"""R41 witnesses - the daily-trend veto rebirth (operator decision 2026-09-09).

The operator ordered: re-enable the daily bias agent; above 80% confidence
a contrarian entry is HARD BLOCKED on every path; the soft gate
(>=3 qualified agents & confidence >=80) governs the 38.5-80% band;
PATH-7 (R25-2 scalp fade) and PATH-9 (sweep raid reversal) stay exempt
by architecture (their lanes never pass this gate - witness W8 locks it).

Witness list:
  W1  live config.json carries daily_bias_filter.enabled == True
      (fails until the merger flips the switch - artifact witness)
  W2  SELL vs BULLISH 95%  -> WAIT + exact block reason (the -$318 family gate)
  W3  SELL vs BULLISH 84.6% -> WAIT (>=80 band; the gold CANCELLED band)
  W4  SELL vs BEARISH 95% -> untouched (with-trend never blocked)
  W5  contrarian 38.5% with only 2 qualified votes -> WAIT (soft gate)
  W6  contrarian 38.5% with 3 qualified votes & conf 92 -> passes
  W7  NEUTRAL daily -> untouched (neutral is a pass, not a brake)
  W8  scalp/PATH-9 lanes exempt by architecture: they never reach this
      gate (structural witness - documents the exemption contract)
"""
from __future__ import annotations

import json
import os

from agents.decision_agent import DecisionAgent


def _agent() -> DecisionAgent:
    agent = DecisionAgent({
        "daily_bias_filter": {
            "enabled": True,
            "contrarian_min_agents_for_lower_confidence": 3,
            "contrarian_min_confidence": 80,
            "block_strong_contrarian_below": 80,
        },
        "risk_management": {"allow_trading": True},
    })
    return agent


def _result(signal: str, votes: int = 0, conf: float = 70.0) -> dict:
    return {
        "signal": signal,
        "confidence": conf,
        "votes": {signal: [{"agent": f"a{i}", "qualified": True}
                           for i in range(votes)]} if votes else {},
        "warnings": [],
    }


def _apply(result: dict, daily: dict) -> dict:
    return _agent()._apply_safety_filters(
        dict(result), {"daily_bias": daily, "session": {"trading_allowed": True}})


# ---------- W1: artifact witness (the switch itself) -------------------
def test_w1_live_config_has_daily_bias_enabled() -> None:
    cfg_path = os.path.join(os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__)))), "config.json")
    cfg = json.load(open(cfg_path, encoding="utf-8"))
    assert (cfg.get("daily_bias_filter") or {}).get("enabled") is True, (
        "R41: operator ordered daily_bias_filter.enabled=true on 2026-09-09; "
        "run scripts/config_mergers/apply_r41_daily_bias_enable.py")


# ---------- W2: the -$318 family gate ---------------------------------
def test_w2_hard_block_oil_family_case() -> None:
    out = _apply(_result("SELL"), {"enabled": True, "bias": "BULLISH",
                                   "confidence": 95.0})
    assert out["signal"] == "WAIT"
    assert any("Daily Bias (4H) blocks counter-trend" in w
               for w in out["warnings"])


# ---------- W3: the suppressed band >=80 also dies ---------------------
def test_w3_hard_block_84_band() -> None:
    out = _apply(_result("BUY"), {"enabled": True, "bias": "BEARISH",
                                  "confidence": 84.6})
    assert out["signal"] == "WAIT"


# ---------- W4: with-trend never blocked -------------------------------
def test_w4_with_trend_passes() -> None:
    res = _result("SELL")
    out = _apply(res, {"enabled": True, "bias": "BEARISH",
                       "confidence": 95.0})
    assert out["signal"] == "SELL"


# ---------- W5/W6: the soft gate band ----------------------------------
def test_w5_soft_band_needs_three_votes() -> None:
    out = _apply(_result("BUY", votes=2, conf=90.0),
                 {"enabled": True, "bias": "BEARISH", "confidence": 38.5})
    assert out["signal"] == "WAIT"


def test_w6_soft_band_passes_with_three_qualified() -> None:
    res = _result("BUY", votes=3, conf=92.0)
    out = _apply(res, {"enabled": True, "bias": "BEARISH",
                       "confidence": 38.5})
    assert out["signal"] == "BUY"


# ---------- W7: neutral is a pass --------------------------------------
def test_w7_neutral_passes() -> None:
    res = _result("SELL")
    out = _apply(res, {"enabled": True, "bias": "NEUTRAL",
                       "confidence": 42.5})
    assert out["signal"] == "SELL"


# ---------- W8: scalp/PATH-9 lanes never reach the gate ----------------
def test_w8_scalp_and_path9_exempt_by_architecture() -> None:
    # The R25-2 scalp lane (stamped R25_SCALP_FADE -> PATH_7) and the
    # PATH_9 Sweep Raid lane build their own admission dicts in
    # scripts/run_analysis.py (L2278 / L631) and never call
    # DecisionAgent._apply_safety_filters; the daily veto therefore does
    # not exist in their flow. Witness: the two stamp sites stay lanes.
    src_path = os.path.join(os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__)))),
        "scripts", "run_analysis.py")
    src = open(src_path, encoding="utf-8").read()
    assert 'stamp_execution_path(scalp, "R25_SCALP_FADE")' in src
    assert "stamp_execution_path(path9_decision, PATH_9)" in src
