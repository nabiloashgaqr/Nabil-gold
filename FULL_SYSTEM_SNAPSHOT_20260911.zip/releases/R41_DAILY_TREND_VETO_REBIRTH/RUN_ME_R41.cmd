@echo off
setlocal
echo ============================================================
echo  R41 - DAILY TREND VETO REBIRTH (operator order 2026-09-09)
echo  daily_bias_filter.enabled false --^> true
echo  hard veto: contrarian 4H bias conf ^>=80 blocked on all paths
echo  PATH-7 scalp fade / PATH-9 sweep reversal: exempt by lanes
echo  soft gate (3 qualified agents ^& conf ^>=80): untouched
echo  stop rules (R10/R11, trail, ratios): untouched
echo ============================================================
cd /d "%~dp0"
copy /y files\scripts\config_mergers\apply_r41_daily_bias_enable.py scripts\config_mergers\ >nul
copy /y files\tests\witnesses\test_r41_daily_bias_veto.py tests\witnesses\test_r41_daily_bias_veto.py >nul
copy /y files\tests\test_operator_directives_24h_15m_weekend.py tests\ >nul
python scripts\config_mergers\apply_r41_daily_bias_enable.py
python -m pytest tests\witnesses\test_r41_daily_bias_veto.py -q
echo.
echo [R41] 8/8 witnesses green + config flipped = law live next cycle.
echo Restart the analysis service to pick up config.json.
pause
