# -*- coding: ascii -*-
r"""
SPACE_RECLAIM.py - Nabil-gold phase-2 disk space reclaim (2026-09-08)
====================================================================
Targets found by ORGANIZE v1.1 size report on the VPS (1.3GB total):
  * storage\                          591.9MB  (live DBs - protected)
  * _portable\                        525.3MB  (migration build duplicates)
  * logs\                             104.9MB
  * auction_parts\                     36.1MB
  * backups\                           32.8MB  (kept - levers of safety)
  * diagnostics\                       26.2MB

Evidence this tool bakes in (repo grep 2026-09-08):
  * auction_parts is referenced NOWHERE in agents/services/scripts/utils
    -> orphan shards from the old collector build.
  * storage\.setup_candidates.json.*.tmp are atomic-write crash orphans
    (live path written by services/database.py via same-dir tempfile +
    os.replace; survivors older 24h are abandoned by design).
  * account_archives / storage\backups hold demo-transition state used by
    scripts/reset_for_new_demo_account.py -> only zipped, never deleted.

Actions (scan prints projected reclaim; apply executes):
  A) DELETE   storage crashes-orphan *.tmp (age > 24h)
  B) DELETE   _portable\build_* dirs IF the sibling .zip exists
  C) MOVE     auction_parts\ -> _archive\space_reclaim\ (recoverable)
  D) COMPRESS logs: rotated *.log.N >5MB, demo_analysis.log >10MB&>24h,
              -> _archive\compressed_logs\ (zip lvl 9) then delete original
  E) [--zip-hist flag] zip account_archives / storage\backups older 7d,
              keep the zip in place, delete expanded folder

Hard guards: never touch *.sqlite3*, storage\setup_candidates.json itself,
backups\, anything modified < 24h (storage) or live writers.
Arabic output via \u escapes (ASCII-only source law).
"""
import argparse
import datetime as _dt
import json
import os
import shutil
import sys
import zipfile


def _a(s):
    return s.encode('ascii').decode('unicode_escape')


T = {
    "title": _a(r"\u0625\u0639\u0627\u062f\u0629 \u0627\u0644\u0645\u0633\u0627\u062d\u0629 - \u0627\u0644\u0645\u0631\u062d\u0644\u0629 \u0627\u0644\u062b\u0627\u0646\u064a\u0629 (\u062d\u0633\u0628 \u062a\u0642\u0631\u064a\u0631 ORGANIZE 1.1)"),
}

HOUR = 3600.0
DAY = 24 * HOUR


def _age(p, now):
    try:
        return now - os.path.getmtime(p)
    except OSError:
        return -1


def _mb(files):
    return sum(f['size'] for f in files) / (1024.0 * 1024.0)


def scan(root, now):
    plan = []

    # A) orphan atomic-write leftovers next to setup_candidates.json
    storage = os.path.join(root, 'storage')
    if os.path.isdir(storage):
        for f in os.listdir(storage):
            ap = os.path.join(storage, f)
            if not os.path.isfile(ap):
                continue
            if f.startswith('.setup_candidates.json.') and f.endswith('.tmp'):
                age = _age(ap, now)
                if age > DAY:
                    plan.append({'action': 'DEL_TMP', 'src': 'storage\\' + f,
                                 'size': os.path.getsize(ap),
                                 'extra': '%.0fh' % (age / HOUR)})

    # B) _portable build dirs whose sibling zip exists
    port = os.path.join(root, '_portable')
    if os.path.isdir(port):
        zips = {z for z in os.listdir(port) if z.lower().endswith('.zip')}
        for d in os.listdir(port):
            ap = os.path.join(port, d)
            if os.path.isdir(ap) and d.startswith('build_'):
                want = [z for z in zips if d.replace('build_', '') in z]
                if want:
                    size = 0
                    for dp, _, fns in os.walk(ap):
                        for fn in fns:
                            try:
                                size += os.path.getsize(os.path.join(dp, fn))
                            except OSError:
                                pass
                    plan.append({'action': 'DEL_PORTABLE_BUILD',
                                 'src': '_portable\\' + d, 'size': size,
                                 'extra': 'sibling zip kept: ' + want[0]})

    # C) orphan auction_parts shards at root
    parts_dir = os.path.join(root, 'auction_parts')
    if os.path.isdir(parts_dir):
        size = 0
        for dp, _, fns in os.walk(parts_dir):
            for fn in fns:
                try:
                    size += os.path.getsize(os.path.join(dp, fn))
                except OSError:
                    pass
        plan.append({'action': 'ZIP_PARTS', 'src': 'auction_parts',
                     'size': size,
                     'extra': 'unreferenced in code; zipped to '
                              '_archive\\space_reclaim'})

    # D) logs compress: rotated .log.N >5MB; demo_analysis.log >10MB & >24h
    logs = os.path.join(root, 'logs')
    if os.path.isdir(logs):
        for f in os.listdir(logs):
            ap = os.path.join(logs, f)
            if not os.path.isfile(ap):
                continue
            low = f.lower()
            size = os.path.getsize(ap)
            age = _age(ap, now)
            rotated = ('.log.' in low and low.rsplit('.', 1)[1].isdigit())
            if rotated and size > 5 * 1024 * 1024:
                plan.append({'action': 'ZIP_LOG', 'src': 'logs\\' + f,
                             'size': size, 'extra': 'rotated log'})
            elif low == 'demo_analysis.log' and size > 10 * 1024 * 1024 \
                    and age > DAY:
                plan.append({'action': 'ZIP_LOG', 'src': 'logs\\' + f,
                             'size': size, 'extra': 'demo log'})

    # E) optional deep history zipping (report only unless --zip-hist)
    for base in ('storage/account_archives', 'storage/backups'):
        bp = os.path.join(root, *base.split('/'))
        if os.path.isdir(bp):
            for d in os.listdir(bp):
                ap = os.path.join(bp, d)
                if not os.path.isdir(ap):
                    continue
                age = _age(ap, now)
                if age > 7 * DAY:
                    size = 0
                    for dp, _, fns in os.walk(ap):
                        for fn in fns:
                            try:
                                size += os.path.getsize(os.path.join(dp, fn))
                            except OSError:
                                pass
                    plan.append({'action': 'ZIP_HIST', 'src': base + '\\' + d,
                                 'size': size,
                                 'extra': '%.0fd old' % (age / DAY)})
    return plan


def apply(plan, root, args, log_f):
    done = {}
    for p in plan:
        act = p['action']
        src_rel = p['src'].replace('\\', os.sep)
        src = os.path.join(root, src_rel)
        try:
            if act == 'DEL_TMP':
                os.remove(src)
                log_f.write('DEL_TMP %s\n' % p['src'])
            elif act == 'DEL_PORTABLE_BUILD':
                shutil.rmtree(src)
                log_f.write('DEL_PORTABLE_BUILD %s\n' % p['src'])
            elif act == 'ZIP_PARTS':
                out = os.path.join(root, '_archive', 'space_reclaim')
                os.makedirs(out, exist_ok=True)
                zpath = os.path.join(out, 'auction_parts.zip')
                with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED,
                                     compresslevel=9) as z:
                    for dp, _, fns in os.walk(src):
                        for fn in fns:
                            fp = os.path.join(dp, fn)
                            z.write(fp, arcname=os.path.relpath(fp, src))
                shutil.rmtree(src)
                log_f.write('ZIP_PARTS auction_parts -> %s\n' % zpath)
            elif act == 'ZIP_LOG':
                out = os.path.join(root, '_archive', 'compressed_logs')
                os.makedirs(out, exist_ok=True)
                zpath = os.path.join(out, src_rel.replace(os.sep, '__')
                                     + '.zip')
                with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED,
                                     compresslevel=9) as z:
                    z.write(src, arcname=os.path.basename(src))
                os.remove(src)
                log_f.write('ZIP_LOG %s -> %s\n' % (p['src'], zpath))
            elif act == 'ZIP_HIST' and args.zip_hist:
                zpath = src.rstrip(os.sep) + '.zip'
                with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED,
                                     compresslevel=9) as z:
                    for dp, _, fns in os.walk(src):
                        for fn in fns:
                            fp = os.path.join(dp, fn)
                            z.write(fp, arcname=os.path.relpath(fp, src))
                shutil.rmtree(src)
                log_f.write('ZIP_HIST %s -> %s.zip\n' % (p['src'], p['src']))
            done[act] = done.get(act, 0) + (p.get('size', 0))
        except OSError as e:
            log_f.write('FAIL %s %s %r\n' % (act, p['src'], e))
    return done


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=r'C:\Nabil-gold')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--zip-hist', action='store_true',
                    help='also zip-pack account_archives/storage backups')
    ap.add_argument('--yes', action='store_true')
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    now = _dt.datetime.now().timestamp()
    ts = _dt.datetime.now().strftime('Y%Ym%md%d_H%HM%M')
    print(T['title'])
    print('root:', root)
    plan = scan(root, now)

    tot_by = {}
    for p in plan:
        key = p['action'] if p['action'] != 'ZIP_HIST' or args.zip_hist \
            else 'ZIP_HIST (report only - add --zip-hist)'
        tot_by.setdefault(key, []).append(p)
    total = 0.0
    for key in sorted(tot_by):
        items = tot_by[key]
        mb = _mb(items)
        total += mb if 'report only' not in key else 0.0
        print('[%s] %d item(s)  %.1fMB' % (key, len(items), mb))
        for p in items[:60]:
            print('    %10.1fMB  %s  (%s)'
                  % (p['size'] / 1048576.0, p['src'], p['extra']))
    print('-' * 60)
    print('PROJECTED RECLAIM: %.1fMB (ZIP packs count full size pessimistically)'
          % total)

    if not args.apply:
        print('SCAN-ONLY. To apply: --apply --yes [--zip-hist]')
        return
    if not args.yes:
        print('ABORT: apply needs --yes')
        return
    journal = os.path.join(root, '_archive', '_journal')
    os.makedirs(journal, exist_ok=True)
    with open(os.path.join(journal, 'space-%s.log' % ts), 'w',
              encoding='utf-8') as log_f:
        done = apply(plan, root, args, log_f)
    for k, v in sorted(done.items()):
        print('done %-s %d bytes' % (k, v))
    print('SPACE_RECLAIM DONE. Journal: _archive\\_journal\\space-%s.log' % ts)


if __name__ == '__main__':
    main()
