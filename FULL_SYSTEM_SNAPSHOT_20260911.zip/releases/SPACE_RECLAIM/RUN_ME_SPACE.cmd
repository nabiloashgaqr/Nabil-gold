@echo off
title SPACE RECLAIM - Nabil gold phase 2
cd /d C:\Nabil-gold
echo ==========================================================
echo  [1/2] SCAN (nothing changes)
echo ==========================================================
py -3 SPACE_RECLAIM.py --root C:\Nabil-gold || python SPACE_RECLAIM.py --root C:\Nabil-gold
echo.
set /p GO=Apply reclaim (portable build, tmp orphans, logs, auction_parts)? type YES:
if /I not "%GO%"=="YES" ( echo Stopped. Nothing changed. & pause & goto :eof )
echo ==========================================================
echo  [2/2] APPLY
echo ==========================================================
py -3 SPACE_RECLAIM.py --root C:\Nabil-gold --apply --yes
echo.
set /p HIST=Also zip-pack account_archives + storage\backups older than 7 days? type YES:
if /I "%HIST%"=="YES" py -3 SPACE_RECLAIM.py --root C:\Nabil-gold --apply --yes --zip-hist
echo.
echo Done. Journal: _archive\_journal ^| zips: _archive\compressed_logs, _archive\space_reclaim
pause
