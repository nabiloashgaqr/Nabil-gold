@echo off
setlocal
cd /d "C:\Nabil-gold"
echo ============================================================
echo  R41b - install R41 witness files + verify (config already flipped)
echo ============================================================
if not exist tests\witnesses mkdir tests\witnesses
copy /y "%~dp0files\tests\witnesses\test_r41_daily_bias_veto.py" tests\witnesses\ >nul
copy /y "%~dp0files\tests\test_operator_directives_24h_15m_weekend.py" tests\ >nul
python -m pytest tests\witnesses\test_r41_daily_bias_veto.py -q
echo.
echo [R41b] Expected: 8 passed. Config already shows enabled=true
echo from the successful R41 merge. Restart the analysis service
echo if not already done, so it picks up config.json.
pause
