@echo off
setlocal
echo ============================================================
echo  R37.1 BIRTH INTEGRITY -- one double click, idempotent
echo  Upgrades the PATH_6 door: midpoint law against hybrid births.
echo  Requires R37 installed first. Touches 2 files only.
echo ============================================================
cd /d "%~dp0"
copy /y services\pre_arm_ote.py services\pre_arm_ote.py.bak.r37_1 >nul
copy /y files\services\pre_arm_ote.py services\pre_arm_ote.py >nul
copy /y files\tests\test_r37_law_roundup.py tests\test_r37_law_roundup.py >nul
python -m py_compile services\pre_arm_ote.py || (echo COMPILE FAIL & pause & exit /b 1)
python -m pytest tests\test_r37_law_roundup.py -q || (echo TESTS FAIL - restore .bak.r37_1 & pause & exit /b 1)
echo.
echo R37.1 BIRTH INTEGRITY APPLIED. Restart the bot to load the law.
pause
