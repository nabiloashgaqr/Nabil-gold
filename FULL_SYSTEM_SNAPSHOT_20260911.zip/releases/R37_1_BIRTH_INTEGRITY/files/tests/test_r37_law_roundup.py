# -*- coding: utf-8 -*-
"""R37 (operator order 2026-09-09, one round): four law repairs, frozen.

1. CLUTCH A+C — the entry line belongs to the breakeven LAW. Before this
   round the momentum clutch clamped its structure candidate AT entry and
   wrote stop == entry on the first 52.5-pt FX "impulse" candle, with no
   225-pt early-breakeven and no 0.5R gate; the ratchet then forbade
   retreat and ordinary pullbacks paid $0.00 (live rows 2026-09-08/09:
   GBP/USD and USD/CAD closed exactly at entry). Now: unprotected trades
   are only tightened BELOW the entry line; touching it is deferred to
   the BE law; and the SELL asymmetry `min(candidate, entry)` -- which
   FORCED improvements straight down to entry -- is retired.

2. Clutch impulse NUMBERS stay per-instrument (gold 35/150/400, WTI x0.5,
   FX x1.5): no cross-mixing, asserted through the real params source.

3. PATH_6 pre-arm door geometry: a decided signal whose stop or target
   sits on the wrong side is refused before the ledger/broker, mirroring
   the reactive path's final validator.

4. Settlement units: final_pnl_points is always price-difference points;
   the DOLLAR cell (final_pnl) is written only when a manual dollar value
   is handed in -- never a points copy.
"""

from __future__ import annotations

import io
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from utils.helpers import load_config  # noqa: E402
from utils import trading_rules as TR  # noqa: E402
from scripts.run_tick_manager import clutch_stop  # noqa: E402
from services.pre_arm_ote import _geometry_refusal  # noqa: E402
from scripts.enrich_trade import _settlement_fields  # noqa: E402

_CFG_PATH = ROOT / "config.json"
CONFIG = load_config(_CFG_PATH) if _CFG_PATH.exists() else {}


def _candles(lows, highs):
    # closed-candle window for clutch_stop (last item kept open by caller)
    return [{"low": lo, "high": hi, "open": lo, "close": hi} for lo, hi in zip(lows, highs)] + [
        {"low": lows[-1], "high": highs[-1], "open": lows[-1], "close": highs[-1]}]


PARAMS = {"enabled": True, "atr_k": 1.3, "min_gap_points": 150.0,
          "max_gap_points": 400.0, "anchor_lookback": 5}


# ── 1. CLUTCH A+C ────────────────────────────────────────────────────

def test_A_unprotected_buy_never_writes_stop_at_entry():
    # entry 100, stop 99.0 (law not armed). Impulse lifts structure so the
    # candidate would sit AT/ABOVE entry: BEFORE R37 this wrote stop=entry
    # (the $0.00 trap). Now: None -- deferred to the BE law.
    candles = _candles(lows=[100.05, 100.10, 100.20, 100.25, 100.30],
                       highs=[100.30, 100.35, 100.45, 100.50, 100.60])
    out = clutch_stop(PARAMS, "BUY", 99.0, 100.0, candles, 0.01, 200.0, 4)
    assert out is None


def test_A_unprotected_buy_may_still_tighten_below_entry():
    # Structure candidate lands below entry: a normal trail improvement,
    # still lawful before the BE arm. (pv 0.001, atr 30 -> margin 150 pts
    # = 0.15 price; anchor = lowest low 99.35 -> candidate 99.20.)
    candles = _candles(lows=[99.35, 99.40, 99.45, 99.50, 99.55],
                       highs=[99.60, 99.62, 99.65, 99.70, 99.75])
    out = clutch_stop(PARAMS, "BUY", 98.50, 100.0, candles, 0.001, 30.0, 4)
    assert out is not None and 98.50 < out < 100.0


def test_protected_buy_structure_lock_above_entry_allowed():
    # Law already armed (stop == entry >= entry). Structure anchor 100.30
    # with margin 0.15 -> candidate 100.15, a lawful profit lock.
    candles = _candles(lows=[100.30, 100.35, 100.40, 100.45, 100.50],
                       highs=[100.60, 100.62, 100.65, 100.70, 100.72])
    out = clutch_stop(PARAMS, "BUY", 100.0, 100.0, candles, 0.001, 30.0, 4)
    assert out is not None and out >= 100.0


def test_A_unprotected_sell_never_writes_stop_at_entry():
    candles = _candles(lows=[99.40, 99.50, 99.55, 99.60, 99.70],
                       highs=[99.70, 99.80, 99.85, 99.90, 99.95])
    out = clutch_stop(PARAMS, "SELL", 101.0, 100.0, candles, 0.01, 200.0, 4)
    assert out is None


def test_C_unprotected_sell_improves_to_structure_not_forced_to_entry():
    # stop 101.5 (unprotected, above entry). Structure candidate 100.80 is
    # a legit tighten that is NOT the entry line. Old code FORCED it to
    # exactly 100.0 (min(candidate, entry)) -- the early BE lock. R37-C
    # returns the structure price itself.
    candles = _candles(lows=[99.60, 99.65, 99.70, 99.75, 99.80],
                       highs=[100.60, 100.62, 100.65, 100.70, 100.80])
    # margin floor 150 pts with pv 0.01 = 1.5 price? use pv 0.001 so the
    # margin lands where the test intends:
    out = clutch_stop({"enabled": True, "atr_k": 1.3, "min_gap_points": 20.0,
                       "max_gap_points": 30.0, "anchor_lookback": 5},
                      "SELL", 101.50, 100.0, candles, 0.01, 25.0, 4)
    # anchor = 100.80; margin = clamp(1.3*25, 20, 30)=30 pts = 0.30 -> 101.10
    assert out is not None and 100.0 < out < 101.50
    assert out != 100.0  # never silently the entry line again


def test_C_protected_sell_locks_profit_below_entry():
    # Law armed (stop == entry <= entry). Anchor 99.70 + margin 0.15 ->
    # candidate 99.85: BELOW entry, a true profit lock (old min clamp
    # could never hand a sell anything past entry, and on the other side
    # it FORCED entries). Same symmetry point as the BUY half.
    candles = _candles(lows=[99.20, 99.30, 99.40, 99.50, 99.60],
                       highs=[99.50, 99.55, 99.60, 99.65, 99.70])
    out = clutch_stop(PARAMS, "SELL", 100.0, 100.0, candles, 0.001, 30.0, 4)
    assert out is not None and out < 100.0


# ── 2. Per-instrument impulse numbers, never mixed ───────────────────

def test_clutch_numbers_gold_base():
    p = TR.momentum_clutch_params(CONFIG, "XAU/USD")
    assert p["burst_min_points"] == 35.0
    assert p["min_gap_points"] == 150.0
    assert p["max_gap_points"] == 400.0


def test_clutch_numbers_forex_scaled_x15():
    p = TR.momentum_clutch_params(CONFIG, "EUR/USD")
    assert p["burst_min_points"] == 35.0 * 1.5
    assert p["min_gap_points"] == 150.0 * 1.5
    assert p["max_gap_points"] == 400.0 * 1.5


def test_clutch_numbers_wti_scaled_x05():
    p = TR.momentum_clutch_params(CONFIG, "WTI/USD")
    assert p["burst_min_points"] == 35.0 * 0.5
    assert p["min_gap_points"] == 150.0 * 0.5
    assert p["max_gap_points"] == 400.0 * 0.5


# ── 3. PATH_6 door geometry ──────────────────────────────────────────

def _prearm(side, entry, stop, tp1, tp2):
    return {"decision": side, "signal": {
        "entry": {"price": entry, "kind": "LIMIT"},
        "stop_loss": stop, "tp1": tp1, "tp2": tp2}}


def test_gate_refuses_wrong_side_tp1_the_audit_rows():
    # Live 2026-09-08: BUY pending entry 4437.72 with tp1 4431.47.
    r = _geometry_refusal(_prearm("BUY", 4437.72, 4384.22, 4431.47, 4451.71))
    assert r and "tp1" in r
    # Live 2026-09-09: SELL pending entry 4353.75 with tp1 4370.76.
    r = _geometry_refusal(_prearm("SELL", 4353.75, 4418.0, 4370.76, 4350.51))
    assert r and "tp1" in r


def test_gate_refuses_wrong_side_stop():
    r = _geometry_refusal(_prearm("SELL", 100.0, 99.0, 98.0, 96.0))
    assert r and "not protective" in r


def test_gate_passes_lawful_arm():
    # Lawful arm = exact midpoint birth (how _build_decision ships tp1).
    assert _geometry_refusal(_prearm("BUY", 100.0, 98.0, 102.0, 104.0)) is None
    assert _geometry_refusal(_prearm("SELL", 100.0, 102.0, 98.0, 96.0)) is None


# ── 4. Settlement units ──────────────────────────────────────────────

def test_settlement_points_always_dollars_only_when_manual():
    auto = _settlement_fields(457.0, None)
    assert auto == {"final_pnl_points": 457.0}          # dollar cell untouched
    manual = _settlement_fields(457.0, 27.6)
    assert manual == {"final_pnl_points": 457.0, "final_pnl": 27.6}


# ── 5. Birth integrity: the 598bffed hybrid (R37.1) ──────────────────

def test_gate_refuses_hybrid_midpoint_birth():
    # The exact live row: SELL 4353.75 / stop 4418.0 / tp2 4350.51 with a
    # tp1 that was the midpoint of 4353.75->4387.77 (BUY-side numbers
    # spliced into a SELL row). Wrong-side catches tp1 first; a spliced
    # tp1 that happens to sit on the lawful side is caught by the midpoint
    # law instead.
    r = _geometry_refusal(_prearm("SELL", 4353.75, 4418.0, 4370.76, 4350.51))
    assert r and "tp1" in r
    r = _geometry_refusal(_prearm("SELL", 4353.75, 4418.0, 4352.90, 4350.51))
    assert r and "midpoint" in r


def test_gate_passes_exact_midpoint_arms():
    e, t2 = 4353.75, 4350.51
    assert _geometry_refusal(_prearm("SELL", e, 4418.0, (e + t2) / 2, t2)) is None
