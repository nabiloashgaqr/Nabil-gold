@echo off
setlocal
cd /d "C:\Nabil-gold"
echo ============================================================
echo  R43b - proof the trailing-card fix covers EVERY symbol
echo  W6 WTI SELL risk-side honest  W7 GBP protected locks
echo  W8 EUR risk-side honest      W9 JPY protected locks
echo ============================================================
if not exist tests\witnesses mkdir tests\witnesses
copy /y files\tests\witnesses\test_r43_card_and_zone.py tests\witnesses\ >nul
python -m pytest tests\witnesses\test_r43_card_and_zone.py -q
echo.
echo [R43b] Expected: 9 passed (all symbols proven symbol-blind).
pause
