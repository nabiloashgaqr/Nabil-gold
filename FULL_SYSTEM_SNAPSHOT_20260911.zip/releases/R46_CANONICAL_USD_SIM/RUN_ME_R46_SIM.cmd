@echo off
setlocal
echo ============================================================
echo  R46-b CANONICAL-USD SIMULATION -- READ ONLY REPLAY
echo  Builds the unified USD opinion (basket fast/slow + ex-EUR +
echo  FX-leg distillation tie-^>MIXED + gold mirror) from your
echo  LOCAL auction stores and replays EVERY ledger trade:
echo  which are USD-contrarian, and per veto bar 60/70/80:
echo  how many LOSERS it would catch vs WINNERS it would block.
echo  No trading change. No MT5 needed. No network.
echo ============================================================
cd /d "C:\Nabil-gold"
copy /y "%~dp0files\scripts\audit_canonical_usd_replay.py" scripts\ >nul
python scripts\audit_canonical_usd_replay.py
echo.
echo Report: storage\canonical_usd_replay_*.txt (+ .json)  [R46-e status-dictates outcome; stale-current_pnl never outvotes SL/TP2]
echo Upload the .txt to the assistant for the adopt/reject verdict.
pause
