# -*- coding: utf-8 -*-
"""R46 CANONICAL-USD SIMULATION (READ ONLY) — operator order 2026-09-10.

Not a shadow mode; a REPLAY. Answers his exact question, with data:
"غإذا كان الدولار الموحّد المركزي موجودًا، هل كان سيمنع الخلط
(ذهب بيع + يورو شراء) دون أن يمنع الصفقات الرابحة؟"

Method (zero trading impact, no MT5, no network):
  1. Resample each symbol's LOCAL auction-flow store into 4H candles.
  2. Build the canonical USD opinion per 4H slot, per R33-v2 doc:
       ch1 DXY-4legs basket (EUR .576 JPY .136 GBP .119 CAD .091),
           fast(8) vs slow(20) trend + ratio agreement
       ch2 ex-EUR basket (JPY/GBP/CAD renormalized)
       ch3 FX-leg distillation: each pair's own DailyBiasAgent 4H vote,
           mapped into USD terms with a TIE->MIXED rule (weighted 0.25)
       ch4 gold mirror (XAU 4H bias inverted), as doc's optional channel
       ch5 real yields/fed tone: NOT REPLAYABLE offline - excluded and the
           doc's weights are renormalized over the replayable channels.
  3. For EVERY ledger trade: USD-contrarian verdict (quote-side pairs:
     EUR/GBP/XAU buy-by-USDweak map; base-side: JPY/CAD; WTI decoupling
     treated in the same USD-quote-rule as its historic correlation, at the
     same threshold — clearly annotated).
  4. Verdict sweep at conf 60/70/80: for each threshold count
     losers-caught($) vs winners-blocked($) and per-trade table.
     The number is chosen AFTER the evidence, not before.
"""
from __future__ import annotations

import json
import math
import os
import sys
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from agents.daily_bias_agent import DailyBiasAgent  # noqa: E402
from utils.helpers import load_trades, setup_logging  # noqa: E402

DXY_W = {"EUR/USD": 0.576, "USD/JPY": 0.136, "GBP/USD": 0.119, "USD/CAD": 0.091}
USD_QUOTE_PAIRS = {"EUR/USD", "GBP/USD", "XAU/USD"}      # pair up == USD weak
USD_BASE_PAIRS = {"USD/JPY", "USD/CAD"}                  # pair up == USD strong
CH_W = {"basket": 0.30, "ex_eur": 0.15, "legs": 0.25, "gold_mirror": 0.20}
# gold_mirror weight = doc's 0.10 + yields/fed 0.20 re-norm'd over available,
# then renormalized exactly to 1.00 below.


def _min_read(path: str) -> List[tuple]:
    import sqlite3
    if not os.path.exists(path):
        return []
    try:
        con = sqlite3.connect(path)
        try:
            rows = con.execute(
                "SELECT ts, close_mid FROM minutes ORDER BY ts").fetchall()
        except Exception:
            rows = con.execute(
                "SELECT ts, close_mid FROM seconds ORDER BY ts").fetchall()
        con.close()
        return [(int(t), float(c)) for t, c in rows]
    except Exception:
        return []


def _h4_index(rows: List[tuple]) -> Dict[int, List[float]]:
    idx: Dict[int, List[float]] = {}
    for ts, close in rows:
        b = int(ts) - (int(ts) % 14400)
        idx.setdefault(b, []).append(close)
    return idx


def _series_close(idx: Dict[int, List[float]]) -> Dict[int, float]:
    return {b: v[-1] for b, v in idx.items() if v}


def _dxy_value(closes: Dict[str, float], base: Dict[str, float],
               pairs: List[str]) -> float:
    """DXY-style: geometric product of (current/base)_leg ^ weight."""
    acc = 0.0
    for p in pairs:
        w = DXY_W[p]
        cur = closes.get(p, 0.0)
        ref = base.get(p, 0.0)
        if cur <= 0 or ref <= 0:
            return 0.0
        if p in USD_BASE_PAIRS:
            r = cur / ref
        else:
            r = ref / cur
        acc += w * r * 100.0  # logless proxy: weighted move in pct points
    return acc


# R46-b: true ceiling of the weighted score with the four offline channels
_SCORE_CEILING = (0.8 * CH_W["basket"] + 0.6 * CH_W["ex_eur"]
                  + 0.9 * CH_W["legs"] + 0.5 * CH_W["gold_mirror"]) \
    / sum(CH_W.values())                                       # == 0.728


def _emotion(score: float) -> Tuple[str, float]:
    """confidence = score normalised against the TRUE ceiling -> 0..95.

    R46 bugfix: the old /3.25 divisor capped confidence at ~28 pct so
    veto bars 60/70/80 could never fire.  bars now mean: 60==score 0.437,
    70==0.51, 80==0.583 of a fully-agreeing USD stack."""
    a = abs(score)
    conf = min(95.0, a / _SCORE_CEILING * 100.0)
    if a < 0.35:
        return "MIXED", round(conf, 1)
    return ("STRONG" if score > 0 else "WEAK"), round(conf, 1)


def _channel_basket(series: Dict[int, float], now: int) -> Tuple[float, str]:
    """fast(8 bars) vs slow(20 bars): +fast>slow => STRONG else WEAK."""
    keys = sorted(k for k in series if k <= now)
    if len(keys) < 21:
        return 0.0, "insufficient"
    fast = sum(series[k] for k in keys[-8:]) / 8.0
    slow = sum(series[k] for k in keys[-20:]) / 20.0
    diff = fast - slow
    return (0.8 if diff > 0 else -0.8) if abs(diff) > 0.15 else 0.0, \
        "basket fast%slow %.2f" % (">" if diff > 0 else "<", diff)


def _canonical(agent: DailyBiasAgent, h4: Dict[str, Dict[int, List[float]]],
               now: int) -> Dict[str, Any]:
    closes_now = {p: (_series_close(v).get(b) or 0.0)
                  for p, v in h4.items() for b in [now]}
    closes_ref = {p: (_series_close(v).get(now - 20 * 14400) or 0.0)
                  for p, v in h4.items()}

    dxy_full = _dxy_value(closes_now, closes_ref, list(DXY_W))
    ex_eur = [p for p in DXY_W if p != "EUR/USD"]
    tot = sum(DXY_W[p] for p in ex_eur)
    ex = {p: DXY_W[p] / tot for p in ex_eur}
    dxy_ex = 0.0
    ok_ex = True
    for p in ex:
        w = ex[p]
        cur, ref = closes_now.get(p, 0), closes_ref.get(p, 0)
        if cur <= 0 or ref <= 0:
            ok_ex = False
            break
        r = (cur / ref) if p in USD_BASE_PAIRS else (ref / cur)
        dxy_ex += w * r * 100.0

    cs1, note1 = _channel_basket(
        {b: _dxy_value({p2: (_series_close(v).get(b) or 0.0) for p2, v in h4.items()},
                       closes_ref, list(DXY_W)) for b in sorted(_series_close(h4[p]))}
        if DXY_W else {}, now) if False else (0.0, "seq-lite")
    # simpler: compare current basket vs basket 8 bars and 20 bars back
    bc = []
    for back in (1, 8, 20):
        b = now - back * 14400
        cur = {p: (_series_close(v).get(b) or 0.0) for p, v in h4.items()}
        bc.append(_dxy_value(cur, closes_ref, list(DXY_W)))
    fast_slow = (bc[1] - bc[2]) if len(bc) == 3 else 0.0
    cs1 = 0.8 if fast_slow > 0.3 else (-0.8 if fast_slow < -0.3 else 0.0)

    cs2 = 0.6 if dxy_ex > bc[2] + 0.1 else (-0.6 if dxy_ex < bc[2] - 0.1 else 0.0)

    votes = []
    details = []
    for p in ("EUR/USD", "GBP/USD", "USD/JPY", "USD/CAD", "XAU/USD"):
        series = sorted(_series_close(h4.get(p, {})).items()) if p in h4 else []
        data = [c for b, c in series if b + 14400 <= now]
        if len(data) < 60:
            continue
        rows = [{"open": c, "high": c, "low": c, "close": c, "time": 0}
                for c in data]
        verdict = agent.analyze({"symbol": p, "timeframes": {"4H": {"data": rows}}})
        b = str(verdict.get("bias") or "NEUTRAL")
        usd = None
        if b == "BULLISH":
            usd = -1.0 if p in USD_QUOTE_PAIRS else +1.0
        elif b == "BEARISH":
            usd = +1.0 if p in USD_QUOTE_PAIRS else -1.0
        if usd is not None:
            votes.append(usd)
        details.append(f"{p}({b}->{usd})")
    cs3 = 0.0
    if votes:
        net = sum(votes)
        if abs(net) >= max(2, len(votes) - 1):
            cs3 = 0.9 if net > 0 else -0.9
        elif net != 0:
            cs3 = 0.4 if net > 0 else -0.4

    # gold mirror: gold 4H bias inverted
    cs4 = 0.0
    try:
        xrows = [{"open": c, "high": c, "low": c, "close": c, "time": 0}
                 for c in [v[-1] for _b, v in sorted(h4.get("XAU/USD", {}).items())][-80:]]
        if len(xrows) >= 60:
            verdict = agent.analyze({"symbol": "XAU/USD",
                                     "timeframes": {"4H": {"data": xrows}}})
            b = str(verdict.get("bias") or "NEUTRAL")
            cs4 = (-0.5 if b == "BULLISH" else 0.5) if b != "NEUTRAL" else 0.0
    except Exception:
        pass

    total_w = sum(CH_W.values())
    weighted = ((cs1 * CH_W["basket"]) + (cs2 * CH_W["ex_eur"])
                + (cs3 * CH_W["legs"]) + (cs4 * CH_W["gold_mirror"])) / total_w
    direction, confidence = _emotion(weighted)
    return {"direction": direction, "confidence": round(confidence, 1),
            "score": round(weighted, 3), "notes": {
                "basket_fastslow": cs1, "ex_eur": cs2, "legs": cs3,
                "mirror": cs4, "leg_votes": details}}


def _pair_usd_contrarian(symbol: str, side: str,
                         usd_dir: str) -> Optional[bool]:
    sym = str(symbol or "").upper()
    side = str(side or "").upper()
    if usd_dir not in {"STRONG", "WEAK"}:
        return None
    if sym in USD_QUOTE_PAIRS:                       # BUY == betting USD weak
        intent = "WEAK" if side == "BUY" else "STRONG"
    elif sym in USD_BASE_PAIRS:                      # BUY == betting USD strong
        intent = "STRONG" if side == "BUY" else "WEAK"
    elif sym in {"WTI/USD", "OIL/USD"}:              # quoted in USD: buy == USD weak
        intent = "WEAK" if side == "BUY" else "STRONG"
    else:
        return None
    return intent != usd_dir


def main() -> None:
    setup_logging()
    config: Dict[str, Any] = {}
    dbc = dict(config.get("daily_bias_filter") or {})
    dbc["enabled"] = True
    config["daily_bias_filter"] = dbc
    agent = DailyBiasAgent(config)

    symbols = list(DXY_W) + ["XAU/USD", "WTI/USD"]
    h4: Dict[str, Dict[int, List[float]]] = {}
    for sym in symbols:
        slug = sym.replace("/", "").lower()
        path = f"storage/auction_flow_{slug}.sqlite3"
        if sym == "XAU/USD":
            path = "storage/auction_flow.sqlite3"
            if not os.path.exists(path):
                path = f"storage/auction_flow_{slug}.sqlite3"
        rows = _min_read(path)
        h4[sym] = _h4_index(rows)
        print(f"[src] {sym}: {len(rows)} minute rows -> {len(h4[sym])} 4H slots ({path})")

    trades = load_trades() or []
    pick = []
    for t in trades:
        sym = str(t.get("symbol") or "")
        side = str(t.get("type") or t.get("side") or "").upper()
        ts_iso = str(t.get("entry_time") or t.get("created_at") or "")
        try:
            ts = int(datetime.fromisoformat(
                ts_iso.replace("Z", "+00:00")).timestamp())
        except Exception:
            continue
        if side not in {"BUY", "SELL"} or sym not in symbols:
            continue
        pick.append((t, sym, side, ts))

    canon_grid: List[Dict[str, Any]] = []
    results: List[Dict[str, Any]] = []
    for t, sym, side, ts in pick:
        slot = ts - (ts % 14400)
        canon = _canonical(agent, h4, slot)
        contra = _pair_usd_contrarian(sym, side, canon["direction"])
        status = str(t.get("status") or "?")
        # R46-d: explicit key priority (the R46-b generic scan picked a
        # 0.0 'pnl' column over the real 'current_pnl'); a zero with an
        # SL status is a ledger artefact, not a real print -> treat as None.
        pnl_usd = None
        points = None
        for _k in ("final_pnl_points", "final_pnl", "pnl_points",
                   "current_pnl", "pnl_usd", "pnl", "profit"):
            _v = t.get(_k)
            try:
                _f = float(_v)
            except (TypeError, ValueError):
                continue
            if _f == 0.0 and status.upper().endswith("SL_HIT"):
                continue                                    # artefact
            points = _f
            break

        st_u = status.upper()
        # R46-e: STATUS DICTATES. current_pnl is a STALE snapshot (an old
        # SL_HIT stores +11.5 from close-day) -- never let a field outvote
        # a terminal status; fields only resolve trailing/thesis signs.
        _final = t.get("final_pnl_points")
        try:
            _final = float(_final)
        except (TypeError, ValueError):
            _final = t.get("final_pnl")
            try:
                _final = float(_final)
            except (TypeError, ValueError):
                _final = None
        if st_u == "SL_HIT":
            outcome = ("LOSER", "STATUS")
            points = -abs(_final) if _final is not None else points if (
                points or 0) < 0 else None
        elif st_u == "TP2_HIT":
            outcome = ("WINNER", "STATUS")
            points = abs(_final) if _final is not None else points if (
                points or 0) > 0 else None
        elif st_u in {"TRAILING_SL_HIT", "THESIS_EXIT"}:
            if _final is not None and _final != 0:
                outcome = ("LOSER" if _final < 0 else "WINNER", "FIELD-final")
                points = _final
            elif points is not None and points != 0:
                outcome = ("LOSER" if points < 0 else "WINNER", "FIELD-stale")
            else:
                outcome = (None, "UNKNOWN")
        elif st_u in {"CANCELLED", "PENDING", "OPEN"}:
            outcome = (None, "OPEN/CANCELLED")
        else:
            outcome = (None, "UNKNOWN")

        # R46-d: trend agent replayed on the pair's OWN 4H at entry time
        trend_bias, trend_flag = "NEUTRAL", None
        try:
            series = sorted(_series_close(h4.get(sym, {})).items())
            data = [c for b, c in series if b < slot][-120:]
            if len(data) >= 60:
                rows_t = [{"open": c, "high": c, "low": c, "close": c,
                           "time": 0} for c in data]
                tb = str(agent.analyze({"symbol": sym, "timeframes":
                                        {"4H": {"data": rows_t}}})
                         .get("bias") or "NEUTRAL")
                trend_bias = tb
                if tb == "BULLISH":
                    trend_flag = "WITH" if side == "BUY" else "COUNTER"
                elif tb == "BEARISH":
                    trend_flag = "WITH" if side == "SELL" else "COUNTER"
        except Exception:
            pass

        results.append({"id": str(t.get("id"))[-8:], "symbol": sym, "side": side,
                        "entry_price": t.get("entry_price"), "status": status,
                        "time": str(t.get("entry_time"))[:16],
                        "canonical": canon["direction"],
                        "canon_conf": canon["confidence"],
                        "score": canon["score"], "notes": canon["notes"],
                        "contrarian": contra,
                        "trend_bias": trend_bias, "trend_flag": trend_flag,
                        "outcome": outcome[0], "outcome_basis": outcome[1],
                        "pnl_pts": points, "pnl_usd": pnl_usd})
        canon_grid.append({"slot": slot, "symbol": sym, **canon})

    report = {
        "law": ("canonical_usd = 0.30 basket fast/slow + 0.15 ex-EUR + "
                "0.25 FX-leg distillation (tie->MIXED) + 0.20 gold mirror; "
                "yields/fed voice & MACRO voice: NO per-timestamp snapshots in the "
                "local stores -> macro CANNOT be replayed for historic trades "
                "(limitation, stated honestly); canonical uses the 4 price "
                "channels only. contrarian = entry betting against the "
                "canonical stance."),
        "results": results,
    }
    def _economics(rows):
        caught = [r for r in rows if r["outcome"] == "LOSER"]
        blocked = [r for r in rows if r["outcome"] == "WINNER"]
        def _trusted(rs):
            return round(sum(r["pnl_pts"] for r in rs
                             if r["pnl_pts"] is not None
                             and r["outcome_basis"] != "FIELD-stale"), 1)
        return {"losers_caught": caught, "winners_blocked": blocked,
                "unknown": [r["id"] for r in rows if r["outcome"] is None],
                "losers_caught_pts": _trusted(caught),
                "winners_blocked_pts": _trusted(blocked)}

    closed = [r for r in results
              if str(r["status"]).upper() not in {"CANCELLED", "PENDING", "OPEN"}]
    for bar in (60.0, 70.0, 80.0):
        canon_fired = [r for r in closed
                       if r["contrarian"] is True and r["canon_conf"] >= bar]
        trend_fired = [r for r in closed if r["trend_flag"] == "COUNTER"]
        both_fired = [r for r in closed
                      if r["contrarian"] is True and r["canon_conf"] >= bar
                      and r["trend_flag"] == "COUNTER"]
        report[f"bar_{int(bar)}"] = {
            "canonical_veto": _economics(canon_fired),
            "trend_veto": _economics(trend_fired),          # bar-independent
            "both_veto": _economics(both_fired),
        }
    report["debug_row_keys"] = sorted(results[0].keys()) if results else []

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    out_path = f"storage/canonical_usd_replay_{stamp}.json"
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=1)

    def _fmt(rows):
        if not rows:
            return "  (none)"
        lines_ = []
        for r in rows:
            mark = f"{r['canon_conf']}% {r['canonical']}"
            lines_.append(
                f"  {r['id']} {r['side']:4s} {r['symbol']:8s} "
                f"(USD {mark}) {str(r['entry_price'])[:10]} "
                f"{str(r['status'])[:16]} pts={r['pnl_pts']}")
        return "\n".join(lines_)

    lines = ["=" * 88,
             "R46 CANONICAL-USD REPLAY (read only) — verdict table per trade",
             "=" * 88]
    for r in results:
        contra = ("CONTRA" if r["contrarian"] is True
                  else ("aligned" if r["contrarian"] is False else "n/a"))
        tr = r["trend_flag"] or "-"
        outc = r["outcome"] or "?"
        lines.append(
            f"{contra:8s} {r['side']:4s} {r['symbol']:8s} @{str(r['entry_price'])[:10]} "
            f"| USD: {r['canonical']:7s}({r['canon_conf']}% score {r['score']}) "
            f"| trend {r['trend_bias']:8s}->{tr:7s} "
            f"| {str(r['status'])[:16]:16s} {outc:6s}/{r['outcome_basis']:12s}"
            f" pts={r['pnl_pts']}")
    lines.append("=" * 88)
    for bar in (60.0, 70.0, 80.0):
        sb = report[f"bar_{int(bar)}"]
        lines.append(f"\n=== VETO BAR {int(bar)}%+ ===")
        for lane, title in (("canonical_veto", "CANONICAL-USD VETO"),
                            ("trend_veto", "TREND-AGENT VETO (counter-trend)"),
                            ("both_veto", "BOTH (canonical + counter-trend)")):
            eco = sb[lane]
            lines.append(f"-- {title}: "
                         f"losers caught {len(eco['losers_caught'])} "
                         f"({eco['losers_caught_pts']} pts) | "
                         f"winners blocked {len(eco['winners_blocked'])} "
                         f"({eco['winners_blocked_pts']} pts) | "
                         f"unknown {len(eco['unknown'])}")
            lines.append("  LOSERS: " + _fmt(eco["losers_caught"]))
            lines.append("  BLOCKED: " + _fmt(eco["winners_blocked"]))
    lines.append(f"\n[report saved] {out_path}")
    txt_path = f"storage/canonical_usd_replay_{stamp}.txt"
    with open(txt_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print("\n".join(lines))
    print(f"\n[done] textual: {txt_path} | json: {out_path}")


if __name__ == "__main__":
    main()
