@echo off
setlocal
echo ============================================================
echo  SHADOW PULSE INSTALLER -- one double click, idempotent
echo  Registers a 10-minute scheduled heartbeat for the Shadow
echo  Market Architect engine, then proves it on the spot.
echo  Touches: Task Scheduler only. Never accounts/MT5/config.
echo ============================================================
cd /d "%~dp0"
set TASK=NabilShadowPulse

rem 0) Preconditions: the engine + an ENABLED shadow block must exist.
python scripts\check_and_start_shadow.py > storage\shadow_precheck.txt 2>&1
if errorlevel 2 (
  echo FAIL: shadow engine or its config block is missing here.
  echo See storage\shadow_precheck.txt -- run the phase mergers first.
  type storage\shadow_precheck.txt | findstr /C:"enabled" /C:"FAIL"
  pause
  exit /b 2
)
findstr /C:"enabled: True" storage\shadow_precheck.txt >nul
if errorlevel 1 (
  echo FAIL: shadow block exists but enabled is not True.
  echo Fix: python scripts\check_and_start_shadow.py --enable
  pause
  exit /b 1
)

rem 1) Register / re-register the heartbeat (idempotent: /f overwrites).
schtasks /create /f /tn "%TASK%" /sc minute /mo 10 /tr "\"%~dp0SHADOW_PULSE_TICK.cmd\"" >nul
if errorlevel 1 (
  echo FAIL: Task Scheduler refused the registration (need admin shell?).
  pause
  exit /b 1
)
echo Task registered: %TASK% (every 10 minutes)

rem 2) Proof on the spot: fire one heartbeat immediately and re-read counts.
echo.
echo --- ledger counts BEFORE this proof tick ---
type storage\shadow_precheck.txt | findstr /R /C:"shadow_evidence_snapshots" /C:"shadow_virtual_trades" /C:"OPEN_" /C:"CLOSED"
call SHADOW_PULSE_TICK.cmd
echo.
echo --- ledger counts AFTER this proof tick ---
python scripts\check_and_start_shadow.py > storage\shadow_postcheck.txt 2>&1
type storage\shadow_postcheck.txt | findstr /R /C:"shadow_evidence_snapshots" /C:"shadow_virtual_trades" /C:"OPEN_" /C:"CLOSED"
echo.
echo If evidence_snapshots grew: the pulse writes. Watch the same numbers
echo tomorrow -- CLOSED must start filling as positions meet SL/TP/horizon.
echo Engine log: storage\shadow_pulse.log
echo Undo anytime: REMOVE_SHADOW_PULSE.cmd
pause
