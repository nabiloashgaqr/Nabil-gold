@echo off
rem SHADOW PULSE TICK -- one engine heartbeat. Keep this file ASCII-only.
rem Everything it needs is resolved from its own folder, so the scheduled
rem task survives restarts, drive letters and working-directory drift.
cd /d "%~dp0"
if not exist storage mkdir storage
echo [%DATE% %TIME%] pulse tick begin >> storage\shadow_pulse.log
python scripts\run_shadow_market_architect.py --positions-once >> storage\shadow_pulse.log 2>&1
echo [%DATE% %TIME%] pulse tick end   >> storage\shadow_pulse.log
