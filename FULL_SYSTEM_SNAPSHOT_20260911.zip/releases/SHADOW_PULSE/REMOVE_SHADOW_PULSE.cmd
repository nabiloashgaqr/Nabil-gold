@echo off
schtasks /delete /f /tn "NabilShadowPulse"
if errorlevel 1 (echo Nothing to remove or already gone.) else (echo Heartbeat removed; the ledger and its history stay untouched.)
pause
