"""APPLY R32 — TP1 zombie-trade fix (2026-09-07).

Incident: a USD/JPY SELL (#...44638c89, entry 156.152) was closed at the
broker (fill 155.818, +229.20 USD — visible in the MT5 History tab), yet the
hourly Telegram "Market Status" card kept listing it as an open trade with a
[TP1_HIT] label and live-tracking P&L for hours.

Root cause (scripts/run_tick_manager.py, broker-close fallback):
    keep = status if status in {"TP1_HIT", "PARTIAL"} else "SL_HIT"
    fallback_updates = {"status": keep, ..., "closed_at": ...}
When the position vanished but `executor.last_exit()` found no OUT deal
(manual close whose deal did not carry the magic, or a one-off
history_deals_get hiccup), the fallback stamped `closed_at` while KEEPING
the live status TP1_HIT. From then on:
  * the zombie guard (`if row.get("closed_at"): return`) froze the row —
    last_exit was never retried;
  * every reader keyed on status alone still counted it as LIVE:
      - Telegram status card (`run_analysis._build_market_status_message`)
      - `database.get_open_trades_count` / risk gates
      - the R26.9.9 one-trade-per-symbol slot guard (blocks new USD/JPY
        entries while the zombie sits in the book).

R32 fixes:
  1. tick manager fallback: a vanished position with no visible exit deal is
     booked TERMINAL (SL_HIT / TRAILING_SL_HIT from the price signal), never
     TP1_HIT. Optional grace window (probe history for the real deal first):
     EXIT_PROBE_GRACE_SECONDS / execution.demo.exit_probe_grace_seconds.
  2. run_analysis status card: a row carrying `closed_at` is never rendered
     as open/pending, whatever its status label says.
  3. dashboard/app.js: TRAILING_SL_HIT added to the frontend OUTCOME set —
     trailing exits vanish from the closed-trades view without it (shipped
     whole in the package; the installer backs it up and restarts the API).

R32.1 (post-install test feedback): the grace default is 0 (immediate
terminal booking) so the resurrection-incident contract asserted by
tests/test_mt5_execution_correctness.py::test_finished_row_is_never_resurrected
stays green; the 90s probe stays opt-in via the config knob merged on the VPS.

Idempotent: re-running is a no-op. Compile-checks every patched file.
"""

from __future__ import annotations

import py_compile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TICK = ROOT / "scripts" / "run_tick_manager.py"
ANALYSIS = ROOT / "scripts" / "run_analysis.py"
DASH_API = ROOT / "services" / "dashboard_local_api.py"

MARKER = "EXIT_PROBE_GRACE_SECONDS"


def _patch(path: Path, replacements: list, name: str) -> bool:
    """Apply (old, new[, required]) hunks.

    - new already present        -> skip (idempotent)
    - old present                -> replace once
    - old missing & required     -> FAIL (broken anchor, stop the run)
    - old missing & not required -> quiet skip (state-dependent repair hunks)
    """
    text = path.read_text(encoding="utf-8")
    changed = False
    for hunk in replacements:
        old, new = hunk[0], hunk[1]
        required = hunk[2] if len(hunk) > 2 else True
        if new.strip() in text:
            print(f"  [skip] {name}: hunk already patched")
            continue
        if old in text:
            text = text.replace(old, new, 1)
            changed = True
            print(f"  [ok]   {name}: applied hunk")
            continue
        if required:
            print(f"  [FAIL] {name}: anchor not found:\n{old[:200]}...")
            return False
        print(f"  [skip] {name}: repair hunk not applicable (state not present)")
    if changed:
        backup = path.with_suffix(path.suffix + ".bak_r32")
        backup.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
        path.write_text(text, encoding="utf-8")
        print(f"  [ok]   {name}: written (backup -> {backup.name})")
    return True


def main() -> int:
    ok = True

    # Final block after ROWS_REFRESH_SECONDS (identical from all paths so
    # idempotency detection works on fresh AND v1-patched repos alike).
    FINAL_GRACE_BLOCK = (
        '# R32/R32.1 (2026-09-07): seconds to keep probing history for the broker\n'
        '# exit deal after a position vanishes. 0 = book the terminal label\n'
        '# IMMEDIATELY (the 2026-08-10 resurrection-incident contract locked by\n'
        '# tests/test_mt5_execution_correctness.py). >0 opts into a grace window\n'
        '# (VPS knob: execution.demo.exit_probe_grace_seconds=90 / env var).\n'
        'EXIT_PROBE_GRACE_SECONDS = float(os.environ.get("EXIT_PROBE_GRACE_SECONDS", 0.0))\n'
    )

    # ── 1. scripts/run_tick_manager.py ───────────────────────────────────
    tick_hunks = [
        # 1a0. REPAIR hunk: R32 v1 shipped default 90.0, which broke the
        # first-sight booking contract asserted by test_mt5_execution_correctness
        # ::test_finished_row_is_never_resurrected. Flip to the 0.0 default.
        # Optional: absent on fresh repos.
        (
            '# R32 (2026-09-07): seconds to keep probing history for the broker exit\n'
            '# deal after a position vanishes, before a terminal label is forced.\n'
            'EXIT_PROBE_GRACE_SECONDS = float(os.environ.get("EXIT_PROBE_GRACE_SECONDS", 90.0))\n',
            FINAL_GRACE_BLOCK,
            False,
        ),
        # 1a. module constant next to LOOP_SLEEP (fresh repos)
        (
            'LOOP_SLEEP = float(os.environ.get("TICK_LOOP_SLEEP", 0.25))\n'
            'ROWS_REFRESH_SECONDS = float(os.environ.get("TICK_ROWS_REFRESH", 3.0))\n',
            'LOOP_SLEEP = float(os.environ.get("TICK_LOOP_SLEEP", 0.25))\n'
            'ROWS_REFRESH_SECONDS = float(os.environ.get("TICK_ROWS_REFRESH", 3.0))\n'
            + FINAL_GRACE_BLOCK,
        ),
        # 1b. __init__ state for the grace window
        (
            '        self._placement_retry_at: Dict[str, float] = {}  # stop 4x/sec refusal/log floods\n',
            '        self._placement_retry_at: Dict[str, float] = {}  # stop 4x/sec refusal/log floods\n'
            '        # R32: first-miss monotonic stamp per trade whose position vanished\n'
            '        # while no exit deal is visible yet (grace before terminal label).\n'
            '        self._exit_probe_first_miss: Dict[str, float] = {}\n'
            '        # R32 grace: config knob wins (execution.demo.exit_probe_grace_seconds,\n'
            '        # merged by scripts/config_mergers/apply_r32_exit_probe_grace.py),\n'
            '        # else the env var / module default.\n'
            '        self._exit_probe_grace: float = float(\n'
            '            ((((config or {}).get("execution") or {}).get("demo") or {})\n'
            '             .get("exit_probe_grace_seconds", EXIT_PROBE_GRACE_SECONDS)) or EXIT_PROBE_GRACE_SECONDS)\n',
        ),
        # 1c. success branch: clear any pending probe
        (
            '            if exit_info and exit_info["price"] > 0:\n'
            '                close = exit_info["price"]\n',
            '            if exit_info and exit_info["price"] > 0:\n'
            '                self._exit_probe_first_miss.pop(tid, None)  # R32\n'
            '                close = exit_info["price"]\n',
        ),
        # 1d. the buggy fallback itself
        (
            '            else:\n'
            '                keep = status if status in {"TP1_HIT", "PARTIAL"} else "SL_HIT"\n'
            '                close = tick.bid if side == "BUY" else tick.ask\n'
            '                _closed = _now_iso_stamp()\n'
            '                fallback_updates = {"status": keep,\n'
            '                                    "close_price": round_price(close, row.get("symbol"), self.config),\n'
            '                                    "closed_at": _closed, "close_time": _closed}\n'
            '                self.database.update_trade(tid, fallback_updates)\n'
            '                row.update(fallback_updates)\n'
            '                self._notify(\n'
            '                    f"🧪 DEMO: position closed by broker @ {format_price(close, row.get(\'symbol\'), self.config)} "\n'
            '                    f"(no exit deal found — labelled {keep}, verify)")\n',
            '            else:\n'
            '                # R32 (2026-09-07 — closed USD/JPY 44638c89 printed as OPEN for\n'
            '                # hours): the old fallback stamped closed_at yet KEPT the live\n'
            '                # status TP1_HIT/PARTIAL. The zombie guard then froze the row\n'
            '                # (every later tick returned on closed_at) while every reader\n'
            '                # keyed on status alone — Telegram card, risk count, R26.9.9\n'
            '                # symbol slot — still saw it as live. Now: (1) history can lag\n'
            '                # the position vanish; probe last_exit again for a grace\n'
            '                # window instead of booking a blind close on the first miss;\n'
            '                # (2) once the grace expires the label is TERMINAL, never the\n'
            '                # live status.\n'
            '                close = tick.bid if side == "BUY" else tick.ask\n'
            '                now_mono = time.monotonic()\n'
            '                first_miss = self._exit_probe_first_miss.setdefault(tid, now_mono)\n'
            '                if now_mono - first_miss < self._exit_probe_grace:\n'
            '                    if self._placement_due(f"exit-probe:{tid}"):\n'
            '                        logger.warning(\n'
            '                            "R32: position for %s gone but no exit deal in "\n'
            '                            "history yet (%.0fs) — probing for %.0fs before "\n'
            '                            "terminal labelling",\n'
            '                            tid, now_mono - first_miss, self._exit_probe_grace)\n'
            '                    return\n'
            '                entry_fb = float(row.get("entry_price") or 0)\n'
            '                favorable = (close - entry_fb) if side == "BUY" else (entry_fb - close)\n'
            '                # A trade that banked TP1 and exits beyond the entry trail is\n'
            '                # a protected/trailing exit, never a fresh stop-loss.\n'
            '                if status in {"TP1_HIT", "PARTIAL"} and favorable > 0:\n'
            '                    terminal = "TRAILING_SL_HIT"\n'
            '                else:\n'
            '                    terminal = "TRAILING_SL_HIT" if favorable > 1e-9 else "SL_HIT"\n'
            '                _closed = _now_iso_stamp()\n'
            '                _pv_fb = point_size(str(row.get("symbol") or "XAU/USD"), self.config)\n'
            '                pnl_fb = ((close - entry_fb) / _pv_fb) if _pv_fb > 0 else 0.0\n'
            '                if side == "SELL":\n'
            '                    pnl_fb = -pnl_fb\n'
            '                fallback_updates = {"status": terminal, "result": terminal,\n'
            '                                    "close_price": round_price(close, row.get("symbol"), self.config),\n'
            '                                    "pnl_points": round(pnl_fb, 1),\n'
            '                                    "closed_at": _closed, "close_time": _closed,\n'
            '                                    "reasons": ["broker exit deal not found within grace; "\n'
            '                                                "terminal label from price signal (R32)"]}\n'
            '                self.database.update_trade(tid, fallback_updates)\n'
            '                row.update(fallback_updates)\n'
            '                self._exit_probe_first_miss.pop(tid, None)\n'
            '                self._notify(\n'
            '                    f"🧪 DEMO: position closed by broker @ {format_price(close, row.get(\'symbol\'), self.config)} "\n'
            '                    f"(no exit deal found after {self._exit_probe_grace:.0f}s — terminal {terminal}, verify)")\n',
        ),
    ]
    ok &= _patch(TICK, tick_hunks, "run_tick_manager")

    # ── 2. scripts/run_analysis.py — status card display filter ──────────
    analysis_hunks = [
        (
            '        live_trades = [t for t in tracked_trades if str(t.get("status") or "OPEN").upper() in live_statuses]\n'
            '        pending_trades = [t for t in tracked_trades if str(t.get("status") or "").upper() in pending_statuses]\n',
            '        # R32 (2026-09-07): closed_at outranks any live status label. A\n'
            '        # TP1_HIT zombie (closed at the broker, deal never matched) must\n'
            '        # never print as an open trade again.\n'
            '        live_trades = [t for t in tracked_trades\n'
            '                       if str(t.get("status") or "OPEN").upper() in live_statuses\n'
            '                       and not t.get("closed_at")]\n'
            '        pending_trades = [t for t in tracked_trades\n'
            '                          if str(t.get("status") or "").upper() in pending_statuses\n'
            '                          and not t.get("closed_at")]\n',
        ),
    ]
    ok &= _patch(ANALYSIS, analysis_hunks, "run_analysis")

    # ── 3. services/dashboard_local_api.py — carry realized USD (R32.1) ──
    # The book stamps pnl_usd on every broker close (R25.15); the dashboard
    # whitelist dropped it, so the panel API lost the true dollar figure.
    dash_hunks = [
        (
            '    "final_pnl", "final_pnl_points", "pnl_points", "close_price",\n',
            '    "final_pnl", "final_pnl_points", "pnl_points", "pnl_usd", "close_price",\n',
        ),
    ]
    ok &= _patch(DASH_API, dash_hunks, "dashboard_local_api")

    # ── compile check ────────────────────────────────────────────────────
    for path in (TICK, ANALYSIS, DASH_API):
        try:
            py_compile.compile(str(path), doraise=True)
            print(f"  [ok]   py_compile: {path.name}")
        except py_compile.PyCompileError as exc:
            print(f"  [FAIL] compile: {path.name}: {exc}")
            ok = False

    print("\n" + ("R32 applied cleanly." if ok else "R32 FAILED — see anchors above."))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
