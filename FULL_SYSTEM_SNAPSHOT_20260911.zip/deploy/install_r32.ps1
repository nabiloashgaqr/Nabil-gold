#Requires -Version 5.1
<#
.SYNOPSIS
    R32 (TP1 zombie-trade fix) installer - the SINGLE command.
.DESCRIPTION
    Idempotent. Safe to re-run. Steps:
      1) locate the R32 package zip (repo root or Downloads) and extract it
         OVER the repo root (paths inside the zip are repo-relative)
      2) python APPLY_R32_TP1_ZOMBIE_FIX.py   (patches the two runtime files,
         timestamped .bak_r32 backups, idempotent)
      3) python scripts\config_mergers\apply_r32_exit_probe_grace.py
         (merges execution.demo.exit_probe_grace_seconds into config.json)
      4) python scripts\CLOSE_ZOMBIE_44638c89.py --sweep
         (closes the stuck USD/JPY #44638c89 in the book + any frozen zombie)
      5) py_compile the patched files
      6) restart the SS_TickManager task so the patched code is live
      6b) restart SS_DashboardAPI so the R32.1 dashboard/app.js (TRAILING_SL_HIT
          visibility fix) is served
      7) full pytest suite (report only)
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File C:\Nabil-gold\deploy\install_r32.ps1
#>
param(
    [switch]$SkipRepair,   # skip step 4 (book repair) - patch only
    [switch]$SkipTests     # skip step 7 (pytest)
)
$ErrorActionPreference = "Continue"

$RepoRoot = Split-Path $PSScriptRoot -Parent
if (-not (Test-Path (Join-Path $RepoRoot "config.json"))) { $RepoRoot = "C:\Nabil-gold" }
if (-not (Test-Path (Join-Path $RepoRoot "config.json"))) { throw "config.json not found (is the repo at C:\Nabil-gold?)" }
Set-Location $RepoRoot
Write-Host "==> Repo root: $RepoRoot" -ForegroundColor Cyan

# 1) locate + extract the package
$zip = $null
$cands = @((Join-Path $RepoRoot "Nabil-gold-R32-TP1-ZOMBIE-FIX*.zip"),
          (Join-Path $env:USERPROFILE "Downloads\Nabil-gold-R32-TP1-ZOMBIE-FIX*.zip"))
foreach ($pattern in $cands) {
    $hit = @(Get-ChildItem $pattern -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    if ($hit.Count -gt 0) { $zip = $hit[0]; break }
}
if ($zip) {
    Write-Host "==> Extracting package: $($zip.FullName)" -ForegroundColor Cyan
    # R32.1: back up the dashboard frontend BEFORE the package overwrites it.
    $appJs = Join-Path $RepoRoot "dashboard\app.js"
    if (Test-Path $appJs) {
        Copy-Item $appJs "$appJs.bak_r32" -Force
        Write-Host "[OK] dashboard\app.js backed up -> app.js.bak_r32" -ForegroundColor Green
    }
    Expand-Archive $zip.FullName -DestinationPath $RepoRoot -Force
    Write-Host "[OK] files extracted over the repo root." -ForegroundColor Green
} else {
    Write-Host "[SKIP] no Nabil-gold-R32-TP1-ZOMBIE-FIX*.zip found - assuming files were copied already." -ForegroundColor Yellow
}

# 2) apply the code patch (idempotent; .bak_r32 backups)
Write-Host "==> Patching runtime files (APPLY_R32_TP1_ZOMBIE_FIX)..." -ForegroundColor Cyan
python APPLY_R32_TP1_ZOMBIE_FIX.py
$patch = $LASTEXITCODE

# 3) merge the config knob (idempotent; timestamped backup)
Write-Host "==> Merging config knob (exit_probe_grace_seconds)..." -ForegroundColor Cyan
python scripts\config_mergers\apply_r32_exit_probe_grace.py config.json
$merge = $LASTEXITCODE

# 4) close the stuck trade(s) in the book
if (-not $SkipRepair) {
    Write-Host "==> Book repair: closing zombie trade(s)..." -ForegroundColor Cyan
    python scripts\CLOSE_ZOMBIE_44638c89.py --dry-run --sweep
    python scripts\CLOSE_ZOMBIE_44638c89.py --sweep
    $repair = $LASTEXITCODE
} else {
    Write-Host "[SKIP] book repair (-SkipRepair)." -ForegroundColor Yellow
    $repair = 0
}

# 5) compile check
Write-Host "==> py_compile checks..." -ForegroundColor Cyan
python -c "import py_compile; py_compile.compile('scripts/run_tick_manager.py', doraise=True); py_compile.compile('scripts/run_analysis.py', doraise=True); print('[OK] py_compile clean')"
$compile = $LASTEXITCODE

# 6) restart tick manager so the patched code is live
Write-Host "==> Restarting SS_TickManager..." -ForegroundColor Cyan
schtasks /End /TN "SS_TickManager" 2>$null | Out-Null
Start-Sleep -Seconds 2
schtasks /Run /TN "SS_TickManager" 2>$null | Out-Null
if ($LASTEXITCODE -eq 0) { Write-Host "[OK] SS_TickManager restarted." -ForegroundColor Green }
else { Write-Host "[WARN] could not restart SS_TickManager - the watchdog will revive/reload it within a minute." -ForegroundColor Yellow }

# 6b) restart the dashboard API so the patched app.js is served (R32.1)
Write-Host "==> Restarting SS_DashboardAPI (serves dashboard\app.js)..." -ForegroundColor Cyan
schtasks /End /TN "SS_DashboardAPI" 2>$null | Out-Null
Start-Sleep -Seconds 2
schtasks /Run /TN "SS_DashboardAPI" 2>$null | Out-Null
if ($LASTEXITCODE -eq 0) { Write-Host "[OK] SS_DashboardAPI restarted - hard-refresh the panel (Ctrl+F5)." -ForegroundColor Green }
else { Write-Host "[WARN] could not restart SS_DashboardAPI - restart it manually to serve the new app.js." -ForegroundColor Yellow }

# 7) full test suite (report only)
if (-not $SkipTests) {
    Write-Host "==> Running the FULL pytest suite..." -ForegroundColor Cyan
    python -m pytest tests -q --tb=short -p no:cacheprovider
    $tests = $LASTEXITCODE
} else {
    $tests = 0
}

Write-Host "=================================================================="
if ($patch -eq 0 -and $merge -eq 0 -and $compile -eq 0 -and $repair -eq 0) {
    Write-Host "[DONE] R32 installed: zombie closed, fallback hardened, card filter active. tests=$tests" -ForegroundColor Green
} else {
    Write-Host "[ATTENTION] patch=$patch merge=$merge compile=$compile repair=$repair tests=$tests - read the output above." -ForegroundColor Yellow
}
Write-Host "=================================================================="
