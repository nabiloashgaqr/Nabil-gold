r"""CLOSE_ZOMBIE_44638c89 — one-off book repair (R32 companion).

Closes the USD/JPY SELL trade #...44638c89 in the trades table: it was closed
at the broker (MT5 History: 1.07 lots, 156.152 -> 155.818, +229.20 USD) but
its row kept status TP1_HIT, so the Telegram status card still lists it as
open and the one-trade-per-symbol guard blocks fresh USD/JPY entries.

What it does:
  1. Finds the zombie row(s):
       - id ending with the TARGET_SUFFIX (44638c89), and/or
       - any row with status in {OPEN, TP1_HIT, PARTIAL} that already carries
         closed_at (a frozen zombie) — with --sweep.
  2. Tries `Mt5DemoExecutor.last_exit()` to mirror the REAL broker exit
     (price / profit / deal time). Falls back to the verified constants from
     the MT5 History screenshot when the terminal is not attached here.
  3. Writes a TERMINAL update: status=result=TRAILING_SL_HIT (profit side of
     a protected trail), close_price, pnl_points, pnl_usd, closed_at.

Usage (on the VPS, from the repo root):
    python scripts\CLOSE_ZOMBIE_44638c89.py            # repair #44638c89
    python scripts\CLOSE_ZOMBIE_44638c89.py --sweep    # every frozen zombie
    python scripts\CLOSE_ZOMBIE_44638c89.py --dry-run  # print only

Idempotent: a row that already has a terminal status is skipped.
"""

from __future__ import annotations

import os
import sys

# repo root on sys.path (same bootstrapping as the other scripts)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:  # noqa: BLE001
    pass

TARGET_SUFFIX = "44638c89"

# Verified from the operator's MT5 History (2026-09-07) — used only when the
# broker's exit deal cannot be pulled from the terminal on this machine.
FALLBACK_EXIT = {
    "price": 155.818,
    "profit": 229.20,
    "time": None,          # unknown epoch; closed_at falls back to now
    "volume": 1.07,
    "position": None,
}

TERMINAL_STATUSES = {
    "SL_HIT", "TRAILING_SL_HIT", "TP2_HIT", "BE_HIT", "THESIS_EXIT",
    "CANCELLED", "CLOSED", "MANUAL_CLOSE", "EXPIRED",
}


def _iso_from_epoch(ts) -> str | None:
    if not ts:
        return None
    from datetime import datetime, timezone
    try:
        return datetime.fromtimestamp(float(ts), tz=timezone.utc).isoformat()
    except Exception:  # noqa: BLE001
        return None


def _now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


def _try_broker_exit(tid: str) -> dict | None:
    """Real exit deal for this magic, if the MT5 terminal is attached."""
    try:
        from services.mt5_executor import Mt5DemoExecutor, _mt5_ready
        from utils.helpers import load_config
        mt5 = _mt5_ready()
        info = Mt5DemoExecutor(load_config()).last_exit(tid)
        if info and float(info.get("price") or 0) > 0:
            return info
    except Exception as exc:  # noqa: BLE001 - repair tool must never crash
        print(f"  [info] broker exit lookup unavailable for {tid}: {exc}")
    return None


def _terminal_label(row: dict, close_price: float) -> str:
    side = str(row.get("type") or row.get("side") or "SELL").upper()
    entry = float(row.get("entry_price") or 0)
    favorable = (close_price - entry) if side == "BUY" else (entry - close_price)
    status = str(row.get("status") or "").upper()
    if status in {"TP1_HIT", "PARTIAL"} and favorable > 0:
        return "TRAILING_SL_HIT"
    return "TRAILING_SL_HIT" if favorable > 1e-9 else "SL_HIT"


def _repair_row(db, row: dict, *, dry_run: bool) -> bool:
    tid = str(row.get("id") or "")
    status = str(row.get("status") or "").upper()
    if status in TERMINAL_STATUSES:
        print(f"  [skip] {tid}: already terminal ({status})")
        return False
    if status not in {"OPEN", "TP1_HIT", "PARTIAL", "PENDING"}:
        print(f"  [skip] {tid}: unexpected status {status!r}")
        return False

    exit_info = _try_broker_exit(tid)
    source = "broker deal"
    if not exit_info:
        if tid.endswith(TARGET_SUFFIX):
            exit_info = FALLBACK_EXIT
            source = "MT5 History screenshot constants"
        else:
            print(f"  [skip] {tid}: no broker exit deal and no fallback constants")
            return False

    close = float(exit_info["price"])
    profit = float(exit_info.get("profit") or 0.0)
    # Prefer the real broker deal time; then the detection-time stamp the tick
    # manager already wrote (usually seconds after the actual close); never
    # backfill a fake "now" over an existing truthful stamp.
    closed_at = (_iso_from_epoch(exit_info.get("time"))
                 or str(row.get("closed_at") or "")
                 or _now_iso())
    terminal = _terminal_label(row, close)

    entry = float(row.get("entry_price") or 0)
    symbol = str(row.get("symbol") or "USD/JPY")
    try:
        from utils.instruments import point_size
        from utils.helpers import load_config
        pv = point_size(symbol, load_config())
    except Exception:  # noqa: BLE001
        pv = 0.001 if "JPY" in symbol else 0.0001
    pnl_pts = ((close - entry) / pv) if pv > 0 else 0.0
    if str(row.get("type") or row.get("side") or "").upper() == "SELL":
        pnl_pts = -pnl_pts

    updates = {
        "status": terminal,
        "result": terminal,
        "close_price": round(close, 3),
        "pnl_points": round(pnl_pts, 1),
        "pnl_usd": round(profit, 2),
        "closed_at": closed_at,
        "close_time": closed_at,
        "reasons": [f"R32 book repair: broker exit mirrored from {source}"],
    }

    print(f"  row       : {tid} ({symbol} {row.get('type') or row.get('side')}) "
          f"status={status} closed_at={row.get('closed_at')}")
    print(f"  exit ({source}): price={close} profit={profit:+.2f}$ -> {terminal}")
    if dry_run:
        print("  [dry-run] no write")
        return True
    db.update_trade(tid, updates)
    print(f"  [ok] {tid} -> {terminal} @ {close} ({profit:+.2f}$)")
    return True


def main() -> int:
    args = set(sys.argv[1:])
    dry_run = "--dry-run" in args
    sweep = "--sweep" in args

    from services.database import DatabaseService
    from utils.helpers import load_config

    db = DatabaseService(load_config())
    rows = db.get_open_trades() or []
    print(f"open rows in book: {len(rows)}")

    targets = []
    for row in rows:
        tid = str(row.get("id") or "")
        status = str(row.get("status") or "").upper()
        if tid.endswith(TARGET_SUFFIX):
            targets.append(row)
        elif sweep and row.get("closed_at") and status in {"OPEN", "TP1_HIT", "PARTIAL"}:
            targets.append(row)

    if not targets:
        print("no zombie rows matched (book already clean)")
        return 0

    fixed = 0
    for row in targets:
        fixed += 1 if _repair_row(db, row, dry_run=dry_run) else 0
    print(f"\nrepaired {fixed}/{len(targets)} row(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
