#!/usr/bin/env python3
"""Apply R33.5 to a LIVE config.json: USD/JPY leaves the FX x1.5 class and
runs its own x2.0 law (operator order 2026-09-08: «اجعل نسبته 2.0 بدل 1.5»).

Idempotent: re-running produces the same numbers. Creates a timestamped
backup next to config.json before the atomic write. Only the USD/JPY
instrument row is touched; every other symbol keeps its law byte-for-byte.

Law applied (all = gold x2.0, single-source so the derived distance_ratio
= stop cap / gold cap = 800/400 reports 2.0):
  stop band  [540, 800] pts (400/140/800)   trailing 300/80 @ BREAKEVEN
  early-BE 300 pts   BE lock 80 pts   duplicate zone 300   cross entry 300
  min SL 800   post-TP2 500 pts   targets max-beyond 400 pts
  planner zones: fallback half-width 240, standby 300, max primary/standby
  width 900, min zone width 12, min entry width 120, min thesis objective 60
Unchanged: tp1_rr 0.8 / tp2_multiple 2.0 (ratios, not distances),
scale_in_trigger_points 150 (gold base — the engine scales it by 2.0),
spread filter, point_size, session windows, window_hours.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

R33_5_JPY = {
    "min_sl_distance_points": 800,
    "trailing_distance": 300,
    "trailing_step": 80,
    "early_breakeven_points": 300,
    "duplicate_zone_points": 300,
    "distance_ratio": 2.0,
    "trading_rules": {
        "stop": {"enabled": True, "min_liquidity_points": 400,
                 "safety_buffer_points": 140, "max_stop_points": 800},
        "targets": {"min_tp1_rr": 0.8, "tp2_multiple": 2.0,
                    "max_beyond_points": 400},
        "trailing": {"enabled": True, "distance_points": 300,
                     "step_points": 80, "activation_at": "BREAKEVEN",
                     "early_breakeven_points": 300},
        "protection": {"be_lock_points": 80},
        "post_tp2": {"enabled": True, "min_distance_points": 500,
                     "window_hours": 2.5},
    },
    "session_planner": {
        "fallback_zone_half_width_points": 240,
        "standby_min_distance_points": 300,
        "max_primary_zone_width_points": 900,
        "max_standby_zone_width_points": 900,
        "min_zone_width_points": 12.0,
        "min_entry_zone_width_points": 120,
        "min_thesis_objective_points": 60,
    },
    "cross_entry_distance_points": 300,
    # 150 intentionally: gold base; the engine scales it by the ratio.
    "scale_in_trigger_points": 150,
}


def apply(path: Path) -> tuple[Path, bool]:
    data = json.loads(path.read_text(encoding="utf-8"))
    instruments = data.setdefault("instruments", [])
    row = next((r for r in instruments
                if str(r.get("symbol") or "").upper() in {"USD/JPY", "USDJPY"}), None)
    if row is None:
        row = {"symbol": "USD/JPY"}
        instruments.append(row)
    before = json.dumps(row, sort_keys=True, ensure_ascii=False)
    row.update(R33_5_JPY)
    changed = json.dumps(row, sort_keys=True, ensure_ascii=False) != before

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = path.with_name(f"{path.name}.bak.r33_5.{stamp}")
    shutil.copy2(path, backup)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n",
                   encoding="utf-8")
    os.replace(tmp, path)
    return backup, changed


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply R33.5 USD/JPY x2.0 law")
    parser.add_argument("--config", default="config.json",
                        help="path to the live config.json (default: ./config.json)")
    args = parser.parse_args()
    path = Path(args.config)
    if not path.exists():
        raise SystemExit(f"config not found: {path}")
    backup, changed = apply(path)
    print(f"backup: {backup}")
    print("R33.5 USD/JPY x2.0 law:" + (" applied" if changed else " already present (no-op)"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
