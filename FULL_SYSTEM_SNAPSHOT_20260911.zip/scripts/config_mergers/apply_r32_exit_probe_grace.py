"""Safely merge the R32 exit-probe grace knob into config.json.

Adds ``execution.demo.exit_probe_grace_seconds`` (default 90) — the grace
window (seconds) during which the tick manager keeps probing broker history
for the exit deal of a vanished position before stamping a TERMINAL label.
Set-default semantics: an operator-chosen value already present is kept.

Companion of APPLY_R32_TP1_ZOMBIE_FIX.py. Idempotent, atomic write,
timestamped backup (same convention as the other config mergers).
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

KNOB = {"exit_probe_grace_seconds": 90}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("config", nargs="?", default="config.json")
    args = ap.parse_args()
    path = Path(args.config).resolve()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = path.with_name(f"{path.name}.bak.r32.{stamp}")
    shutil.copy2(path, backup)
    data = json.loads(path.read_text(encoding="utf-8"))

    execution = data.get("execution")
    if not isinstance(execution, dict):
        execution = {}
        data["execution"] = execution
    demo = execution.get("demo")
    if not isinstance(demo, dict):
        demo = {}
        execution["demo"] = demo
    for key, value in KNOB.items():
        demo.setdefault(key, value)  # never override an operator choice

    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with tmp.open("r+", encoding="utf-8") as fh:
        os.fsync(fh.fileno())
    os.replace(tmp, path)
    print(f"Updated: {path}  (exit_probe_grace_seconds={demo.get('exit_probe_grace_seconds')})")
    print(f"Backup:  {backup}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
