﻿<#
.SYNOPSIS
    SETUP_MACRO_30MIN.ps1 (v2) - switch the EXISTING macro task to 30 minutes.

.DESCRIPTION
    2026-08-19 (build 11 operator order): macro refresh every 30 minutes.

    v2 fixes the v1 mistake: v1 looked for a task named SS_MacroUpdate that
    never existed and surfaced a harmless delete error. The REAL task on this
    VPS is SS_MacroContext (created by vps_setup.ps1, running macro_demo.bat).

    v2 VERIFIES WHAT EXISTS FIRST:
      1) discovers any scheduled task whose name contains "acro"
      2) reads its CURRENT "Task To Run" command
      3) deletes and recreates it with the SAME name and the SAME command,
         only changing the schedule to every 30 minutes
    Nothing else changes - the working command is preserved byte for byte.

.PARAMETER RepoRoot
    Project root (used only to verify the macro script exists).

.EXAMPLE
    cd C:\Nabil-gold
    powershell -ExecutionPolicy Bypass -File SETUP_MACRO_30MIN.ps1
#>
param(
    [string]$RepoRoot = "C:\Nabil-gold"
)

$ErrorActionPreference = "Stop"
if (-not (Test-Path (Join-Path $RepoRoot "scripts\update_macro_context.py"))) {
    throw "scripts\update_macro_context.py not found under $RepoRoot"
}

# ?? 1) discover what exists ????????????????????????????????????????????????
Write-Host "==> 1) Discovering existing macro tasks ..."
$raw = & schtasks /Query /FO CSV 2>$null
$names = @()
foreach ($line in $raw) {
    if ($line -match "acro") {
        $field = ($line -split '","')[0] -replace '"', '' -replace '\\', ''
        if ($field -and $field -notmatch "TaskName") {
            $names += $field
        }
    }
}
$names = @($names | Sort-Object -Unique)

if (-not $names) {
    Write-Warn "No macro task found - creating a new one (SS_MacroContext)."
    $taskName = "SS_MacroContext"
    $tr = "cmd /c `"$RepoRoot\macro_demo.bat`""
} else {
    $taskName = $names[0]
    if ($names.Count -gt 1) {
        Write-Warn "Multiple macro tasks found: $($names -join ', ') - using $taskName"
    }
    Write-Host "    found: $taskName"
}

# ?? 2) read the CURRENT command ????????????????????????????????????????????
Write-Host "==> 2) Reading the current command ..."
$currentTr = ""
if ($names) {
    $detail = & schtasks /Query /TN $taskName /V /FO LIST 2>$null
    foreach ($line in $detail) {
        if ($line -match "^Task To Run") {
            $currentTr = ($line -split ":\s*", 2)[1]
        }
    }
}
if (-not $currentTr) {
    Write-Warn "Could not read the current command - falling back to macro_demo.bat"
    $currentTr = "cmd /c `"$RepoRoot\macro_demo.bat`""
}
Write-Host "    command: $currentTr"

# ?? 3) recreate with the SAME name and command, 30-minute schedule ????????
Write-Host "==> 3) Recreating the task (same name, same command, 30 min) ..."
$prevEA = $ErrorActionPreference
$ErrorActionPreference = "SilentlyContinue"
& schtasks /Delete /TN $taskName /F 2>$null | Out-Null
$ErrorActionPreference = $prevEA

$trArg = $currentTr
if ($trArg -notmatch '^\s*"') {
    $trArg = '"' + $trArg + '"'
}
$rc = & schtasks /Create /TN $taskName /TR $trArg /SC MINUTE /MO 30 /F 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "schtasks /Create failed: $rc"
}

# ?? 4) verify ?????????????????????????????????????????????????????????????
Write-Host "==> 4) Verify ..."
$verify = & schtasks /Query /TN $taskName /V /FO LIST 2>$null
$verify | Where-Object { $_ -match "TaskName|Task To Run|Schedule Type|Repeat: Every|Next Run Time" } |
    ForEach-Object { Write-Host "    $_" }

Write-Host ""
Write-Host "DONE. The macro context now refreshes every 30 minutes."
Write-Host "The analysis cycle reads it every 5 minutes, so the file stays warm."
Write-Host ""
Write-Host "Check anytime:"
Write-Host "  schtasks /Query /TN `"$taskName`" /V /FO LIST"
Write-Host "  python scripts\macro_feed_check.py"
