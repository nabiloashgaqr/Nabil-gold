﻿<#
.SYNOPSIS
    RUN_DIAGNOSTICS.ps1 - run the full read-only diagnostics suite and save
    one timestamped log in diagnostics\.

.DESCRIPTION
    Runs five READ-ONLY checks (nothing is changed, nothing is sent):
      1) SYSTEM    python scripts\system_healthcheck.py
      2) MAPS      python scripts\map_support_report.py
      3) MEASURES  python scripts\verify_redesign_readiness.py --days N
      4) PATHS     python scripts\summarize_execution_paths.py
      5) AGENTS    python scripts\agent_correlation_report.py --days N
    Output: diagnostics\all_checks_<stamp>.log
    Each check is captured via Start-Process output redirect (PS 5.1 and 7).

.PARAMETER Days
    Trailing window (days) for the measurements/agent reports. Default 7.

.PARAMETER RepoRoot
    Project root. Default: C:\Nabil-gold.

.EXAMPLE
    cd C:\Nabil-gold
    powershell -ExecutionPolicy Bypass -File RUN_DIAGNOSTICS.ps1
    powershell -ExecutionPolicy Bypass -File RUN_DIAGNOSTICS.ps1 -Days 14
#>
param(
    [int]$Days = 7,
    [string]$RepoRoot = "C:\Nabil-gold",
    [switch]$MacroProbe
)

$ErrorActionPreference = "Continue"
if (-not (Test-Path (Join-Path $RepoRoot "config.json"))) {
    throw "config.json not found under $RepoRoot - pass -RepoRoot <folder>"
}
Push-Location $RepoRoot
try {
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $log = Join-Path $RepoRoot ("diagnostics\all_checks_" + $stamp + ".log")
    New-Item -ItemType Directory -Path (Split-Path -Parent $log) -Force | Out-Null
    Write-Host "==> Running diagnostics - log: $log"

    $checks = @(
        @("MODES",    @("scripts/inspect_running_modes.py")),
        @("SYSTEM",   @("scripts/system_healthcheck.py")),
        @("MAPS",     @("scripts/map_support_report.py")),
        @("MEASURES", @("scripts/verify_redesign_readiness.py", "--days", "$Days")),
        @("MACRO",    @("scripts/macro_feed_check.py") + $(if ($MacroProbe) { @("--probe") } else { @() })),
        @("PATHS",    @("scripts/summarize_execution_paths.py")),
        @("AGENTS",   @("scripts/agent_correlation_report.py", "--days", "$Days"))
    )
    foreach ($c in $checks) {
        Write-Host "    -> $($c[0]) ..."
        Add-Content -Path $log -Value ("`n===== " + $c[0] + " " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + " =====")
        $tmpOut = [System.IO.Path]::GetTempFileName()
        $tmpErr = [System.IO.Path]::GetTempFileName()
        $p = Start-Process -FilePath "python" -ArgumentList $c[1] -NoNewWindow -Wait -PassThru `
            -RedirectStandardOutput $tmpOut -RedirectStandardError $tmpErr
        Add-Content -Path $log -Value ("[exit code: " + $p.ExitCode + "]")
        Get-Content $tmpOut -Raw -ErrorAction SilentlyContinue | Add-Content -Path $log
        Get-Content $tmpErr -Raw -ErrorAction SilentlyContinue | Add-Content -Path $log
        Remove-Item $tmpOut, $tmpErr -Force -ErrorAction SilentlyContinue
        Write-Host "        done (exit $($p.ExitCode))"
    }
    Write-Host "==> DONE. Full log: $log"
} finally {
    Pop-Location
}
