"""Measure how correlated the five voting agents really are — with outcomes.

Why this tool exists (operator 2026-08-17): the 11:06 gold BUY was admitted
by exactly technical + multitimeframe + classical — the whole trend family
and nobody else — at the top of a buyside-liquidity sweep that a manual SMC
analyst (and our own smc agent, at 29.5% WAIT) read as distribution. The
operator had previously merged two agents because "they agree on the same
mistakes". This report puts numbers on that intuition, from the same stored
measurements threshold_whatif replays (storage/agent_measurements/*.jsonl):

  1. PAIRWISE AGREEMENT — of the cycles where both agents voted a
     direction, how often did they vote the same way? Within-family vs
     cross-family averages tell us how much independence a vote adds.
  2. BOOK COMPOSITION vs OUTCOME — for every cycle with >= min-agents
     qualified supporters on one side: was the book single-family or mixed,
     and did price at +2h/+4h vindicate it? This is the direct measurement
     of the family-diversity gate's premise.
  3. FAMILY-VS-FAMILY CONFLICTS — cycles where trend and structure
     families qualified on OPPOSITE sides: who was right?
  4. FAMILY-GATE REPLAY — every single-family book the diversity gate
     would block: how many are rescued by an external confirmer
     (macro / auction, replayed from the same stored row), what happened
     to the rescued ones, and what happened to the ones that died. This
     is the Thursday question: is the gate discarding profit or dodging
     losses?

Usage (ordinary PowerShell, safe to run live — read-only):
    python scripts\\agent_correlation_report.py            # all stored days
    python scripts\\agent_correlation_report.py --days 7
    python scripts\\agent_correlation_report.py --bar 65   # qualification bar
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from itertools import combinations
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services.thesis_consensus import DEFAULT_AGENT_FAMILIES, VOTING_AGENTS  # noqa: E402

HORIZONS = {"2h": 2.0, "4h": 4.0}


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _load_rows(days: int) -> List[Dict[str, Any]]:
    base = ROOT / "storage" / "agent_measurements"
    if not base.exists():
        return []
    rows: List[Dict[str, Any]] = []
    for path in sorted(base.glob("agent_system_*.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if isinstance(row, dict) and row.get("agents"):
                rows.append(row)

    def stamp(row: Dict[str, Any]) -> datetime:
        raw = str(row.get("generated_at") or "").replace("Z", "+00:00")
        try:
            return datetime.fromisoformat(raw).astimezone(timezone.utc)
        except ValueError:
            return datetime.fromtimestamp(0, tz=timezone.utc)

    rows.sort(key=stamp)
    for row in rows:
        row["_ts"] = stamp(row)
    if days > 0 and rows:
        cutoff = rows[-1]["_ts"] - timedelta(days=days)
        rows = [r for r in rows if r["_ts"] >= cutoff]
    return rows


def _forward_moves(rows: List[Dict[str, Any]]) -> None:
    for i, row in enumerate(rows):
        price = _f(row.get("current_price"))
        row["_fwd"] = {}
        if price <= 0:
            continue
        for label, hours in HORIZONS.items():
            target = row["_ts"] + timedelta(hours=hours)
            for later in rows[i + 1:]:
                later_price = _f(later.get("current_price"))
                if later["_ts"] >= target and later_price > 0:
                    row["_fwd"][label] = later_price - price
                    break


def _votes(row: Dict[str, Any], bar: float) -> Dict[str, tuple]:
    """agent -> (side, confidence) for qualified directional votes only."""
    out: Dict[str, tuple] = {}
    for name in VOTING_AGENTS:
        info = (row.get("agents") or {}).get(name)
        if not isinstance(info, dict):
            continue
        side = str(info.get("direction") or "WAIT").upper()
        conf = _f(info.get("confidence"))
        if side in {"BUY", "SELL"} and conf >= bar:
            out[name] = (side, conf)
    return out


def _hit(side: str, move: float | None) -> bool | None:
    if move is None:
        return None
    return (move > 0) if side == "BUY" else (move < 0)


def _rescue_source(row: Dict[str, Any], side: str,
                   macro_min: float, auction_min: float,
                   allowed: list | None = None) -> str | None:
    """Which external confirmer would admit this blocked book — if any?

    Mirrors the live Path-2/5 order: macro first (gold verdict, no API
    cost), then the standalone auction read stored on the same row. Gemini
    cannot be replayed from history (it is an API call, not a measurement)
    so this replay is CONSERVATIVE: real rescues can only be >= these.

    ``allowed`` mirrors Rule A's single_family_confirmers: when given, only
    those sources may rescue (live default for all-trend books: macro).
    Pass None to replay the pre-Rule-A policy.
    """
    def _ok(source: str) -> bool:
        return allowed is None or source in allowed

    macro = row.get("macro") or {}
    macro_bias = str(macro.get("bias") or "").upper()
    expected = "BULLISH_GOLD" if side == "BUY" else "BEARISH_GOLD"
    if _ok("macro") and macro_bias == expected and _f(macro.get("confidence")) >= macro_min:
        return "macro"
    auction = (row.get("agents") or {}).get("auction_flow") or {}
    a_side = str(auction.get("direction") or "WAIT").upper()
    if _ok("auction") and a_side == side and _f(auction.get("confidence")) >= auction_min:
        return "auction"
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--days", type=int, default=0, help="lookback window (0 = all)")
    parser.add_argument("--bar", type=float, default=65.0, help="qualification bar (default 65)")
    parser.add_argument("--min-agents", type=int, default=3, help="book size for section 2 (default 3)")
    args = parser.parse_args()

    rows = _load_rows(args.days)
    if len(rows) < 20:
        print(f"Only {len(rows)} measurement rows in storage/agent_measurements/ — need more history.")
        return 1
    _forward_moves(rows)
    fam = DEFAULT_AGENT_FAMILIES

    print("=" * 74)
    print(f"AGENT CORRELATION REPORT — {len(rows)} cycles, bar={args.bar:.0f}%, "
          f"{rows[0]['_ts']:%Y-%m-%d %H:%M} .. {rows[-1]['_ts']:%Y-%m-%d %H:%M} UTC")
    print("=" * 74)

    # ── 1. pairwise agreement ────────────────────────────────────────────
    print("\n1) PAIRWISE AGREEMENT (both qualified & directional)")
    within, cross = [], []
    for a, b in combinations(VOTING_AGENTS, 2):
        both = agree = 0
        for row in rows:
            v = _votes(row, args.bar)
            if a in v and b in v:
                both += 1
                agree += int(v[a][0] == v[b][0])
        if both == 0:
            print(f"   {a:<15} vs {b:<15}  (never co-qualified)")
            continue
        pct = agree / both * 100
        same_family = fam.get(a) == fam.get(b)
        (within if same_family else cross).append(pct)
        tag = "SAME family " if same_family else "cross-family"
        print(f"   {a:<15} vs {b:<15} {tag}  agree {pct:5.1f}%  (n={both})")
    if within:
        print(f"   -> within-family average : {sum(within)/len(within):5.1f}%")
    if cross:
        print(f"   -> cross-family average  : {sum(cross)/len(cross):5.1f}%")

    # ── 2. book composition vs outcome ───────────────────────────────────
    print(f"\n2) BOOKS WITH >= {args.min_agents} QUALIFIED SUPPORTERS — single-family vs mixed")
    buckets = {"single": {"n": 0, "hits": {h: [0, 0] for h in HORIZONS}},
               "mixed": {"n": 0, "hits": {h: [0, 0] for h in HORIZONS}}}
    for row in rows:
        v = _votes(row, args.bar)
        for side in ("BUY", "SELL"):
            sup = [n for n, (s, _) in v.items() if s == side]
            opp = [n for n, (s, _) in v.items() if s != side]
            if len(sup) < args.min_agents or opp:
                continue
            kind = "single" if len({fam[n] for n in sup}) == 1 else "mixed"
            buckets[kind]["n"] += 1
            for h in HORIZONS:
                hit = _hit(side, row["_fwd"].get(h))
                if hit is not None:
                    buckets[kind]["hits"][h][0] += int(hit)
                    buckets[kind]["hits"][h][1] += 1
    for kind, label in (("single", "SINGLE-family books"), ("mixed", "MIXED-family books")):
        b = buckets[kind]
        parts = []
        for h in HORIZONS:
            hits, total = b["hits"][h]
            parts.append(f"{h}: {hits}/{total} ({hits/total*100:.0f}%)" if total else f"{h}: n/a")
        print(f"   {label:<22} n={b['n']:<4} hit-rate {' | '.join(parts)}")
    print("   (the family gate's premise is confirmed if SINGLE trails MIXED)")

    # ── 3. family-vs-family conflicts ────────────────────────────────────
    print("\n3) TREND vs STRUCTURE CONFLICTS (families qualified on OPPOSITE sides)")
    conflicts = {h: {"trend": 0, "structure": 0, "n": 0} for h in HORIZONS}
    total_conflicts = 0
    for row in rows:
        v = _votes(row, args.bar)
        sides = {}
        for name, (side, _) in v.items():
            sides.setdefault(fam[name], set()).add(side)
        t, s = sides.get("trend", set()), sides.get("structure", set())
        if len(t) == 1 and len(s) == 1 and t != s:
            total_conflicts += 1
            t_side = next(iter(t))
            for h in HORIZONS:
                hit_t = _hit(t_side, row["_fwd"].get(h))
                if hit_t is not None:
                    conflicts[h]["n"] += 1
                    conflicts[h]["trend" if hit_t else "structure"] += 1
    if total_conflicts == 0:
        print("   none found in this window")
    else:
        print(f"   {total_conflicts} conflicting cycles")
        for h in HORIZONS:
            c = conflicts[h]
            if c["n"]:
                print(f"   at +{h}: trend right {c['trend']}/{c['n']} "
                      f"({c['trend']/c['n']*100:.0f}%) | structure right "
                      f"{c['structure']}/{c['n']} ({c['structure']/c['n']*100:.0f}%)")

    # ── 4. family-gate replay: blocked books and their rescues ──────────
    print("\n4) FAMILY-GATE REPLAY — single-family books >= 3 supporters (gate blocks direct entry)")
    macro_min = 55.0
    auction_min = 65.0
    try:
        from utils.helpers import load_config  # noqa: PLC0415
        live_cfg = load_config()
        sig = live_cfg.get("signal_requirements") or {}
        macro_min = _f(((sig.get("two_agent_entry") or {}).get("macro_confirmation") or {}).get("min_confidence"), 55.0)
        auction_min = _f((sig.get("path5_two_agent_auction") or {}).get("min_auction_confidence"), 65.0)
    except Exception:
        pass

    # Rule A: replay with the LIVE confirmer policy so Thursday's verdict
    # judges the shipped behaviour, and also track what the refused
    # confirmers would have done (the rule's own report card).
    allowed_confirmers = ["macro"]
    try:
        fd_cfg = (sig.get("family_diversity") or {})
        raw_allowed = fd_cfg.get("single_family_confirmers", ["macro"])
        if isinstance(raw_allowed, (list, tuple)):
            allowed_confirmers = [str(x).lower() for x in raw_allowed]
    except Exception:
        pass

    rescued = {"n": 0, "hits": {h: [0, 0] for h in HORIZONS}, "sources": {}}
    lost = {"n": 0, "hits": {h: [0, 0] for h in HORIZONS}}
    refused_rescues = {"n": 0, "hits": {h: [0, 0] for h in HORIZONS}, "sources": {}}
    unknown_confirmers = 0
    for row in rows:
        v = _votes(row, args.bar)
        for side in ("BUY", "SELL"):
            sup = [n for n, (s, _) in v.items() if s == side]
            opp = [n for n, (s, _) in v.items() if s != side]
            if len(sup) < args.min_agents or opp:
                continue
            if len({fam[n] for n in sup}) != 1:
                continue  # mixed books pass the gate; section 2 covers them
            # Replay the external confirmers stored on the same row,
            # honouring Rule A's allowed list (live policy).
            source = _rescue_source(row, side, macro_min, auction_min,
                                    allowed=allowed_confirmers)
            if not str((row.get("macro") or {}).get("bias") or "") and source is None:
                unknown_confirmers += 1  # row predates the macro field
            # What WOULD a now-refused confirmer have done? (Rule A audit.)
            if source is None:
                would_be = _rescue_source(row, side, macro_min, auction_min, allowed=None)
                if would_be is not None:
                    refused_rescues["n"] += 1
                    refused_rescues["sources"][would_be] = refused_rescues["sources"].get(would_be, 0) + 1
                    for h in HORIZONS:
                        hit = _hit(side, row["_fwd"].get(h))
                        if hit is not None:
                            refused_rescues["hits"][h][0] += int(hit)
                            refused_rescues["hits"][h][1] += 1
            bucket = rescued if source else lost
            bucket["n"] += 1
            if source:
                rescued["sources"][source] = rescued["sources"].get(source, 0) + 1
            for h in HORIZONS:
                hit = _hit(side, row["_fwd"].get(h))
                if hit is not None:
                    bucket["hits"][h][0] += int(hit)
                    bucket["hits"][h][1] += 1

    total_blocked = rescued["n"] + lost["n"]
    if total_blocked == 0:
        print("   no single-family books in this window")
    else:
        def _fmt(bucket):
            parts = []
            for h in HORIZONS:
                hits, n = bucket["hits"][h]
                parts.append(f"{h}: {hits}/{n} ({hits/n*100:.0f}%)" if n else f"{h}: n/a")
            return " | ".join(parts)
        src = ", ".join(f"{k}×{n}" for k, n in sorted(rescued["sources"].items())) or "-"
        print(f"   allowed confirmers (Rule A): {','.join(allowed_confirmers) or 'none'}")
        print(f"   blocked from direct entry : {total_blocked}")
        print(f"   RESCUED by a confirmer    : {rescued['n']:<4} ({src})  hit-rate {_fmt(rescued)}")
        print(f"   LOST (no confirmer)       : {lost['n']:<4} hit-rate {_fmt(lost)}")
        if refused_rescues["n"]:
            rsrc = ", ".join(f"{k}×{n}" for k, n in sorted(refused_rescues["sources"].items()))
            print(f"   Rule-A refused rescues    : {refused_rescues['n']:<4} ({rsrc})  "
                  f"would-have hit-rate {_fmt(refused_rescues)}")
            print("   (if this line's hit-rate climbs well above LOST, Rule A is")
            print("   refusing profitable rescues — widen single_family_confirmers)")
        if unknown_confirmers:
            print(f"   note: {unknown_confirmers} older row(s) lack the macro field; "
                  "their macro rescue could not be replayed (auction still was)")
        print("   VERDICT KEY: LOST hit-rate well under 50% = the gate dodges losses.")
        print("   LOST hit-rate at/above the MIXED books of section 2 = the gate is")
        print("   discarding profit and the confirmers need work, not the gate.")

    # ── 5. armed maps that died waiting for auction ──────────────────────
    # Operator 2026-08-19 (the 4399 case): a Path-4-grade SMC map can clear
    # every floor and still die because auction never reached its bar. This
    # section replays the stored smc_measurement + auction_measurement rows:
    # how often was a qualifying map left waiting, and what did price do?
    # A high would-have hit-rate here = the auction bar (not the maps) is
    # the bottleneck, and min_auction_confidence deserves a measured debate.
    print("\n5) ARMED MAPS THAT WAITED ON AUCTION (Path-4 floors passed, flow silent)")
    p4 = {}
    try:
        p4 = (sig.get("path4_smc_map_auction") or {})
    except Exception:
        pass
    q_min = _f(p4.get("min_map_quality"), 60.0)
    r_min = _f(p4.get("min_return_probability"), 55.0)
    d_min = _f(p4.get("min_dominance"), 70.0)
    t_min = _f(p4.get("min_trigger_score"), 70.0)
    a_min = _f(p4.get("min_auction_confidence"), 65.0)
    waited = {"n": 0, "hits": {h: [0, 0] for h in HORIZONS}}
    confirmed = {"n": 0, "hits": {h: [0, 0] for h in HORIZONS}}
    for row in rows:
        smc_m = row.get("smc_measurement") or {}
        side = str(smc_m.get("setup_direction") or "").upper()
        if side not in {"BUY", "SELL"}:
            continue
        if not (_f(smc_m.get("quality")) >= q_min
                and _f(smc_m.get("return_probability")) >= r_min
                and _f(smc_m.get("dominance")) >= d_min
                and _f(smc_m.get("trigger_score")) >= t_min):
            continue
        auction_m = row.get("auction_measurement") or {}
        a_conf = _f(auction_m.get("confidence"))
        a_dir = str((row.get("agents") or {}).get("auction_flow", {}).get("direction") or "WAIT").upper()
        bucket = confirmed if (a_dir == side and a_conf >= a_min) else waited
        bucket["n"] += 1
        for h in HORIZONS:
            hit = _hit(side, row["_fwd"].get(h))
            if hit is not None:
                bucket["hits"][h][0] += int(hit)
                bucket["hits"][h][1] += 1
    if waited["n"] + confirmed["n"] == 0:
        print("   no Path-4-grade maps in this window")
    else:
        def _fmt5(b):
            parts = []
            for h in HORIZONS:
                hits, n = b["hits"][h]
                parts.append(f"{h}: {hits}/{n} ({hits/n*100:.0f}%)" if n else f"{h}: n/a")
            return " | ".join(parts)
        print(f"   auction bar: {a_min:.0f}%")
        print(f"   WAITED (auction silent) : {waited['n']:<4} would-have hit-rate {_fmt5(waited)}")
        print(f"   CONFIRMED (Path 4 live) : {confirmed['n']:<4} hit-rate {_fmt5(confirmed)}")
        print("   WAITED hit-rate well above 50% and above CONFIRMED = the auction")
        print("   bar is starving good maps — debate min_auction_confidence with")
        print("   these numbers. WAITED below 50% = the bar is doing its job.")

    print("\nHOW TO READ: within-family agreement far above cross-family means the")
    print("families are real. If single-family hit-rates trail mixed books, the")
    print("diversity gate is earning its keep; revisit with --days 7 each week.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
