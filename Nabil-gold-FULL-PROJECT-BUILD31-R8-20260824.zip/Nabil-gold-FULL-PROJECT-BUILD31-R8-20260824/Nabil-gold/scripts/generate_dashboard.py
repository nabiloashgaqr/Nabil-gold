"""Generate Gold AI Signals HTML dashboard."""

from __future__ import annotations

import logging
import os
import sys
from typing import Any, Dict, List

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.dashboard import format_dashboard_telegram, render_dashboard, save_dashboard, summarize_trades
from services import performance_stats
from services.database import DatabaseService
from services.telegram_bot import TelegramService
from utils.helpers import load_config, setup_logging

setup_logging()
logger = logging.getLogger(__name__)

def main() -> None:
    config = load_config()
    db = DatabaseService(config)
    telegram = TelegramService(config)

    # 150 mirrors the web API's default (dashboard/api/dashboard.js), so both
    # surfaces summarise the same set of trades.
    #
    # This used to pull 80 rows with get_recent_trades and let the summary
    # filter them. Ordering by created_at meant pending, cancelled and open
    # rows consumed the window before the filter ran: the card reported 52
    # closed trades while the website, which queries closed rows directly,
    # reported 85. Identical maths over different samples cannot agree.
    limit = int(os.environ.get("DASHBOARD_TRADE_LIMIT", "150"))
    output = os.environ.get("DASHBOARD_OUTPUT", "storage/dashboard.html")

    def _collect(service) -> List[Dict[str, Any]]:
        rows = service.get_recent_closed_trades(limit=limit)
        rows += [t for t in (service.get_open_trades() or [])
                 if str(t.get("status") or "").upper() in performance_stats.OPEN_STATUSES]
        return rows

    trades = _collect(db)
    # BUILD 16 (2026-08-20, operator order): the Telegram dashboard must show
    # DEMO data only, matching the MT5 history table. The continuous-history
    # paper merge is off by default and re-enabled only explicitly via
    # dashboard.merge_paper_history=true (or MERGE_PAPER_HISTORY=true env).
    # BUILD 16.1: on the VPS the local fallback keeps paper-era rows in the
    # SAME file, so demo-only means filtering those rows out (demo_only_rows),
    # not just skipping the table merge.
    from services.dashboard import dashboard_demo_only, demo_only_rows
    _merge_enabled = os.environ.get("MERGE_PAPER_HISTORY", "").lower() in {"1", "true", "yes"}
    _merge_cfg = (config.get("dashboard") or {}).get("merge_paper_history")
    if isinstance(_merge_cfg, bool):
        _merge_enabled = _merge_enabled or _merge_cfg
    if os.environ.get("TRADES_TABLE", "").strip() == "trades_demo" and _merge_enabled:
        paper_db = DatabaseService(config)
        paper_db.trades_table = "trades"
        from services.dashboard import merge_trade_rows
        trades = merge_trade_rows(trades, _collect(paper_db))
    if dashboard_demo_only(config):
        trades = demo_only_rows(trades)

    # Open positions are shown separately on the card and never folded into
    # the realised figures; see services/performance_stats.py.
    html_text = render_dashboard(trades)
    output_path = save_dashboard(html_text, output)
    summary = summarize_trades(trades)

    logger.info("Dashboard generated: %s | trades=%s", output_path, len(trades))
    print(f"Dashboard generated: {output_path}")
    print(summary)

    # BUILD 16: today's DEMO numbers get their own section on the card so the
    # operator sees today's activity next to the all-time figures.
    today_summary = None
    try:
        today_rows = db.get_today_trades()
        if dashboard_demo_only(config):
            today_rows = demo_only_rows(today_rows)
        today_summary = summarize_trades(today_rows)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Today summary unavailable for dashboard card: %s", exc)

    if os.environ.get("SEND_TELEGRAM", "true").lower() in {"1", "true", "yes"}:
        telegram.send_message(format_dashboard_telegram(summary, today_summary=today_summary))

if __name__ == "__main__":
    main()
