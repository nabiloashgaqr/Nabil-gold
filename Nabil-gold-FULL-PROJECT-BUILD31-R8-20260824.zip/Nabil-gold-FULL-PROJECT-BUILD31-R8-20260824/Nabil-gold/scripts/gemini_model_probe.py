"""GEMINI MODEL PROBE (2026-08-21, read-only, cp1252-safe).

The operator's key accepts gemini-flash-latest but refused the 2.5 family
with 404, and flash-latest's daily free quota ran out. This tool probes ONE
tiny request against every candidate model with the key from .env and prints
the truth per model:

    OK        - the model answered (with the text snippet)
    404       - this key cannot use the model
    429 RPD   - daily quota exhausted (resets at midnight Pacific)
    429 RPM   - per-minute limit (retry in a moment)
    401/403   - the KEY itself is refused

One probe per model (cheapest possible call). Nothing is written.

Usage:
  python scripts\\gemini_model_probe.py
  python scripts\\gemini_model_probe.py --models gemini-flash-latest,gemini-flash
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv()
except Exception:  # noqa: BLE001
    pass

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

import requests  # noqa: E402

API_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

DEFAULT_CANDIDATES = (
    "gemini-2.5-flash-lite",
    "gemini-2.5-flash",
    "gemini-2.5-pro",
    "gemini-flash-latest",
    "gemini-flash",
    "gemini-flash-lite",
)


def probe_model(api_key: str, model: str, timeout: int = 15) -> Tuple[str, str]:
    """One tiny generateContent call. Returns (status, detail)."""
    try:
        resp = requests.post(
            API_URL.format(model=model),
            params={"key": api_key},
            json={"contents": [{"parts": [{"text": "ping"}]}],
                  "generationConfig": {"maxOutputTokens": 8}},
            timeout=timeout,
        )
    except Exception as exc:  # noqa: BLE001
        return "NETWORK", f"request failed: {exc}"
    if resp.status_code == 200:
        try:
            body = resp.json()
            text = ((((body.get("candidates") or [{}])[0].get("content") or {})
                     .get("parts") or [{}])[0].get("text") or "")
            snippet = text.strip()[:60].replace("\n", " ")
            return "OK", f"answered: {snippet!r}"
        except Exception:  # noqa: BLE001
            return "OK", f"answered (unparsable body): {(resp.text or '')[:60]}"
    if resp.status_code in (401, 403):
        return "AUTH", f"the KEY itself is refused (HTTP {resp.status_code})"
    if resp.status_code == 404:
        return "404", "this key cannot use this model id"
    if resp.status_code == 429:
        text = resp.text or ""
        if "PerDay" in text or "per day" in text.lower():
            return "429-RPD", "daily quota exhausted (resets at midnight Pacific)"
        if "PerMinute" in text or "per minute" in text.lower():
            return "429-RPM", "per-minute limit - retry in a moment"
        return "429", f"rate limited: {(text or '')[:80]}"
    return f"HTTP{resp.status_code}", f"{(resp.text or '')[:80]}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", default=None,
                        help="comma-separated model list (default: the full candidate set)")
    args = parser.parse_args()

    api_key = os.environ.get("GEMINI_API_KEY") or ""
    if not api_key:
        print("GEMINI_API_KEY not found in .env - nothing to probe.")
        return 1
    candidates = ([m.strip() for m in (args.models or "").split(",") if m.strip()]
                  or list(DEFAULT_CANDIDATES))
    print(f"GEMINI MODEL PROBE - key length {len(api_key)} - {len(candidates)} models")
    print("=" * 64)
    for model in candidates:
        status, detail = probe_model(api_key, model)
        print(f"  {status:10s} {model:26s} {detail}")
    print("=" * 64)
    print("OK = usable now. 404 = unusable for this key (remembered + skipped).")
    print("429-RPD = quota dead today; the service now fails over to the next")
    print("          model instead of stopping (BUILD 23).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
