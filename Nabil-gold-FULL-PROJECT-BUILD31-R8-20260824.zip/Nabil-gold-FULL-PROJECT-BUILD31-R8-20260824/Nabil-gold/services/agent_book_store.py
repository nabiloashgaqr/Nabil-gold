"""Freshest per-symbol agent book, persisted for the activation gate.

Why this store exists (operator 2026-08-18): consensus is checked when a
pending order is PLACED, but nobody consulted the agents again at the
moment of ACTIVATION — 'الصفقة المعلقة لا تنتظر توافق الوكلاء'. The
analysis cycle is the only process that runs the agents; the trade-update
and tick processes are the ones that activate pendings. This file is the
bridge: analysis writes the compact book each cycle, activation reads it.

Freshness is part of the contract: a stale book (older than
max_age_minutes) reads as NO book, and the gate fails open — an outdated
opinion must never veto a live order.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict

ROOT = Path(__file__).resolve().parents[1]

DEFAULT_MAX_AGE_MINUTES = 10.0


def _safe_symbol(symbol: str) -> str:
    return str(symbol or "unknown").upper().replace("/", "").replace(".", "_")


def book_path(symbol: str, root: Path | None = None) -> Path:
    base = root or ROOT
    return base / "storage" / "agent_books" / f"{_safe_symbol(symbol)}.json"


def save_agent_book(symbol: str, agent_details: Dict[str, Any],
                    root: Path | None = None) -> None:
    """Persist the compact book; failure is logged by the caller, never raised."""
    if not isinstance(agent_details, dict) or not agent_details:
        return
    path = book_path(symbol, root)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "symbol": str(symbol),
        "written_at": time.time(),
        "agents": {
            str(name): {
                "direction": str((detail or {}).get("direction") or (detail or {}).get("signal") or "WAIT"),
                "confidence": float((detail or {}).get("confidence") or 0.0),
            }
            for name, detail in agent_details.items()
            if isinstance(detail, dict)
        },
    }
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def load_agent_book(symbol: str, *, max_age_minutes: float = DEFAULT_MAX_AGE_MINUTES,
                    root: Path | None = None, now: float | None = None) -> Dict[str, Any] | None:
    """Return {agent: {direction, confidence}} or None when absent/stale.

    None means "no opinion available" — the activation gate fails open.
    """
    path = book_path(symbol, root)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001 - missing/corrupt book is "no book"
        return None
    if not isinstance(payload, dict):
        return None
    now = time.time() if now is None else now
    written = float(payload.get("written_at") or 0.0)
    if max_age_minutes > 0 and (now - written) > max_age_minutes * 60.0:
        return None
    agents = payload.get("agents")
    return agents if isinstance(agents, dict) and agents else None
