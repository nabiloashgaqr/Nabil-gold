"""
services/margin_guard.py — MT5 account equity/margin circuit breaker before order sends.
(2026-08-19 upgrade)

Problem (evidence):
  - services/mt5_executor.py has a HALT flag, deviation control and filling-mode
    fallbacks, but NO account-level guard: no margin-level check, no max-exposure
    cap, no equity-floor veto. On a demo account a stuck grid of pendings is an
    annoyance; on a live account it is a margin call.

Solution: pre-send veto hook + post-fill equity monitor:
  pre_send_veto() -> returns (allow: bool, reason: str):
    * margin_level < floor (default 300%)  -> veto
    * open exposure > max_exposure_pct of equity (default 40%) -> veto
    * equity < equity_floor (default 70% of peak recorded) -> veto + alert
  Wire into _send_deal() and ensure_ticket() in services/mt5_executor.py
  (both already funnel through `self.halted()` — add the veto there).

Integration:
  from upgrades.margin_guard import pre_send_veto
  if not self.halted():
      allow, reason = pre_send_veto(self._mt5(), self.config)
      if not allow:
          self._halt(reason); return None

Tests: see upgrades/test_upgrades.py::TestMarginGuard (fake account_info objects)
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Tuple


def _cfg(guard: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "margin_level_floor_pct": float(guard.get("margin_level_floor_pct", 300.0)),
        "max_exposure_pct": float(guard.get("max_exposure_pct", 40.0)),
        "equity_drawdown_floor_pct": float(guard.get("equity_drawdown_floor_pct", 30.0)),
        "peak_file": str(guard.get("peak_file", "storage/margin_guard_peak.json")),
    }


def _record_peak(equity: float, peak_file: str) -> float:
    path = Path(peak_file)
    peak = equity
    if path.exists():
        try:
            payload = json.loads(path.read_text(encoding="utf-8")) or {}
            peak = max(float(payload.get("peak", 0.0)), equity)
        except Exception:  # noqa: BLE001
            peak = equity
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"peak": peak}), encoding="utf-8")
    return peak


def pre_send_veto(account_info: Any, config: Dict[str, Any]) -> Tuple[bool, str]:
    """account_info: MT5 account_info() namedtuple (or dict/fake with the fields)."""
    try:
        equity = float(getattr(account_info, "equity", 0) or 0)
        margin = float(getattr(account_info, "margin", 0) or 0)
        margin_level = float(getattr(account_info, "margin_level", 0) or 0)
        balance = float(getattr(account_info, "balance", 0) or 0)
    except Exception:  # noqa: BLE001
        return True, "account_info unavailable — fail open (demo)"

    guard = _cfg(config.get("margin_guard", {}) or {})
    if equity <= 0 or balance <= 0:
        return True, "account_info zero values — fail open (demo)"

    if margin_level > 0 and margin_level < guard["margin_level_floor_pct"]:
        return False, (
            f"VETO: margin level {margin_level:.0f}% below floor "
            f"{guard['margin_level_floor_pct']:.0f}%"
        )

    exposure_pct = (margin / equity) * 100.0 if equity > 0 else 0.0
    if exposure_pct > guard["max_exposure_pct"]:
        return False, (
            f"VETO: exposure {exposure_pct:.1f}% of equity exceeds cap "
            f"{guard['max_exposure_pct']:.1f}%"
        )

    peak = _record_peak(equity, guard["peak_file"])
    dd_pct = (1.0 - equity / peak) * 100.0 if peak > 0 else 0.0
    if dd_pct >= guard["equity_drawdown_floor_pct"]:
        return False, (
            f"VETO: equity drawdown {dd_pct:.1f}% from peak {peak:.0f} "
            f"(floor {guard['equity_drawdown_floor_pct']:.1f}%)"
        )

    return True, (
        f"OK margin_level={margin_level:.0f}% exposure={exposure_pct:.1f}% "
        f"dd_from_peak={dd_pct:.1f}%"
    )
