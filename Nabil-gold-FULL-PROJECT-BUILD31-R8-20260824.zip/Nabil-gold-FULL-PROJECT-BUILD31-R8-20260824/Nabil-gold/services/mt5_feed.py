"""MT5 price feed (demo branch, phase 1).

Returns payloads with the EXACT contract of
services.market_data.MarketDataService payloads:
    {"data": [{"time","open","high","low","close"}, ...], "source": "mt5", ...}

MetaTrader5 is imported LAZILY so paper mode and the test suite run without
the terminal installed. Candle times are normalised from MT5 server time to
UTC by a snapped offset (mt5.time() vs epoch, snapped to 900 s).
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

_SNAP_SECONDS = 900
_offset_cache: Dict[str, int] = {}


def _mt5():
    import MetaTrader5 as mt5  # noqa: WPS113 (lazy on purpose)
    return mt5


def connected() -> bool:
    try:
        return bool(_mt5().terminal_info() is not None)
    except Exception:  # noqa: BLE001 - module missing / terminal down
        return False


def initialize() -> bool:
    mt5 = _mt5()
    for attempt in range(3):
        try:
            path = os.environ.get("MT5_PATH") or None
            if not mt5.initialize(path=path) if path else mt5.initialize():
                raise RuntimeError(mt5.last_error())
            login = int(os.environ.get("MT5_LOGIN") or 0)
            if login:
                ok = mt5.login(
                    login,
                    password=os.environ.get("MT5_PASSWORD") or "",
                    server=os.environ.get("MT5_SERVER") or "",
                )
                if not ok:
                    raise RuntimeError(mt5.last_error())
            return True
        except Exception as exc:  # noqa: BLE001
            logger.warning("MT5 init attempt %d failed: %s", attempt + 1, exc)
            time.sleep(2 ** attempt)
    return False


def time_offset_seconds() -> int:
    """MT5 server time minus UTC epoch, snapped to 15-minute steps."""
    key = "off"
    if key in _offset_cache:
        return _offset_cache[key]
    try:
        raw = _mt5().time() - int(time.time())
        off = int(round(raw / _SNAP_SECONDS) * _SNAP_SECONDS)
    except Exception:  # noqa: BLE001
        off = 0
    _offset_cache[key] = off
    return off


def _timeframe_const(mt5, timeframe_min: int):
    # 2026-08-19: D1/W1 added for the market-regime layer. getattr keeps the
    # mapping safe for fakes/stubs that only define the four intraday frames.
    mapping = {
        5: getattr(mt5, "TIMEFRAME_M5", None),
        15: getattr(mt5, "TIMEFRAME_M15", None),
        60: getattr(mt5, "TIMEFRAME_H1", None),
        240: getattr(mt5, "TIMEFRAME_H4", None),
        1440: getattr(mt5, "TIMEFRAME_D1", None),
        10080: getattr(mt5, "TIMEFRAME_W1", None),
    }
    return mapping.get(timeframe_min)


def _tf_minutes(timeframe: str) -> int:
    tf = str(timeframe).lower()
    if tf in {"d1", "1d"}:
        return 1440
    if tf in {"w1", "1w"}:
        return 10080
    if tf.endswith("m"):
        return int(tf[:-1])
    if tf.endswith("h"):
        return int(tf[:-1]) * 60
    return 5


def get_candles(
    symbol: str,
    timeframe: str = "5m",
    count: int = 220,
    symbol_map: Optional[Dict[str, str]] = None,
) -> Optional[Dict[str, Any]]:
    """None on any failure so the caller falls back to TwelveData."""
    if not connected() and not initialize():
        return None
    mt5 = _mt5()
    mt5_symbol = (symbol_map or {}).get(symbol, symbol.replace("/", ""))
    tf_const = _timeframe_const(mt5, _tf_minutes(timeframe))
    if tf_const is None:
        return None
    try:
        # Position 0 is the still-forming broker candle. Core agents must read
        # only closed native candles; otherwise the same live move is counted
        # again by M5/M15/H1/H4 and can masquerade as four confirmations.
        rates = mt5.copy_rates_from_pos(mt5_symbol, tf_const, 1, count)
    except Exception as exc:  # noqa: BLE001
        logger.warning("MT5 copy_rates failed for %s: %s", mt5_symbol, exc)
        return None
    if rates is None or len(rates) == 0:
        return None
    off = time_offset_seconds()
    data = [
        {
            "time": int(r["time"]) - off,
            "open": float(r["open"]),
            "high": float(r["high"]),
            "low": float(r["low"]),
            "close": float(r["close"]),
        }
        for r in rates
    ]
    # Price remains live even though analysis candles are closed.
    live_price = data[-1]["close"]
    try:
        tick = mt5.symbol_info_tick(mt5_symbol)
        bid = float(getattr(tick, "bid", 0) or 0)
        ask = float(getattr(tick, "ask", 0) or 0)
        if bid > 0 and ask >= bid:
            live_price = (bid + ask) / 2.0
    except Exception:  # noqa: BLE001 - closed-candle book remains usable
        pass
    tf_min = _tf_minutes(timeframe)
    fresh = (int(time.time()) - data[-1]["time"]) <= 2 * tf_min * 60
    return {
        "data": data,
        "source": "mt5",
        "current_price": live_price,
        "last_updated": data[-1]["time"],
        "source_integrity": {
            "source": "mt5",
            "source_type": "historical_ohlc",
            "reliability_grade": "HIGH" if (len(data) >= count and fresh) else "MEDIUM",
            "supports_signal_generation": fresh,
            "supports_pending_activation": fresh,
            "supports_intrabar_levels": True,
            "uses_closed_candles": True,
            "forming_bar_excluded": True,
            "current_price_source": "live_tick_mid",
            "timeframe": timeframe,
        },
    }
