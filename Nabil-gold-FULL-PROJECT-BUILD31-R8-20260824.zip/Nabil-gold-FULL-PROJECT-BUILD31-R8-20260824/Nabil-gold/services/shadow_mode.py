"""Shadow-mode instruments: the FULL gold pipeline, zero execution.

Operator decision 2026-08-16: WTI/USD joins the system as a *shadow*
instrument. A shadow instrument runs every stage the gold stream runs —
the six agents, the shared admission (all five paths), the session planner,
the risk agent's entry/stop/target construction, trade lifecycle management
(trailing 70/25, early breakeven, TP1 partials, thesis exits) — but is
physically incapable of reaching MT5 or the live trade book:

* its trades, plans, audits and path-performance rows live in an isolated
  ``storage/shadow/<sym>/`` tree that the tick manager never reads;
* Supabase is disabled for the shadow book regardless of environment;
* ``demo_execution`` is forced off for shadow cycles, so nothing is ever
  queued for broker placement;
* every Telegram card is prefixed with an unmistakable shadow banner.

After the measurement window, ``scripts/shadow_report.py`` compares the
shadow book's hit rate / profit factor against gold over the same days and
the operator decides whether to promote the instrument to execution
(one-line config change: mode "shadow" -> removed).
"""
from __future__ import annotations

import os
from typing import Any, Dict, List

from pathlib import Path

from services.database import DatabaseService
from services.path_performance import PathPerformanceTracker
from services.telegram_bot import TelegramService
from utils.instruments import enabled_instruments, normalize_symbol

ROOT = Path(__file__).resolve().parents[1]


def is_shadow_config(config: Dict[str, Any] | None) -> bool:
    """True when this per-instrument config carries mode=shadow."""
    if not isinstance(config, dict):
        return False
    return str(((config.get("instrument") or {}).get("mode")) or "").lower() == "shadow"


def shadow_instruments(config: Dict[str, Any]) -> List[Dict[str, Any]]:
    """All enabled instruments flagged shadow."""
    return [
        inst for inst in enabled_instruments(config)
        if str(inst.get("mode") or "").lower() == "shadow"
    ]


def shadow_paths(symbol: Any, base_dir: str | os.PathLike | None = None) -> Dict[str, Path]:
    """Isolated storage tree for one shadow instrument."""
    stem = normalize_symbol(symbol).replace("/", "").lower()
    root = Path(base_dir) if base_dir else Path(
        os.environ.get("NABIL_SHADOW_DIR") or (ROOT / "storage" / "shadow")
    )
    base = root / stem
    return {
        "base": base,
        "trades": base / "trades.json",
        "session_plans": base / "session_plans.json",
        "setup_candidates": base / "setup_candidates.json",
        "setup_state_events": base / "setup_state_events.json",
        "decision_audit": base / "decision_audit.json",
        "path_performance": base / "path_performance" / "trades.json",
    }


class ShadowDatabase(DatabaseService):
    """DatabaseService whose every byte lands in the shadow tree.

    The live book, session plans, decision audit, setup memory and path
    performance of the REAL system are untouched by construction: all the
    parent's path attributes are re-pointed before first use, and Supabase
    is disabled no matter what the environment provides.
    """

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        symbol = normalize_symbol(config.get("symbol") or "WTI/USD")
        paths = shadow_paths(symbol)
        for key, path in paths.items():
            if key != "base":
                path.parent.mkdir(parents=True, exist_ok=True)
        # Hard isolation: a shadow book may never write to Supabase / the
        # demo trades table, even when credentials exist in the environment.
        self.client = None
        self.use_supabase = False
        self.local_path = paths["trades"]
        self.session_plans_path = paths["session_plans"]
        self.setup_candidates_path = paths["setup_candidates"]
        self.setup_state_events_path = paths["setup_state_events"]
        self.decision_audit_path = paths["decision_audit"]
        self.path_performance = PathPerformanceTracker(paths["path_performance"])


class ShadowTelegram(TelegramService):
    """TelegramService that stamps every outgoing message as SHADOW.

    All rich senders (signal card, session plan, trade events, error alert)
    funnel through ``send_message``, so one override brands everything.
    """

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        sym = normalize_symbol(config.get("symbol") or "WTI/USD")
        self._shadow_banner = (
            f"\U0001F9EA SHADOW {sym} \u2014 \u062a\u062d\u0644\u064a\u0644 "
            f"\u063a\u064a\u0631 \u062a\u0646\u0641\u064a\u0630\u064a "
            f"(\u0644\u0627 \u0623\u0648\u0627\u0645\u0631)"
        )

    def send_message(self, text: str, urgent: bool = False, chat_id: str | None = None) -> bool:
        branded = f"{self._shadow_banner}\n{text}"
        # Shadow observations never page anyone: urgency is stripped.
        return super().send_message(branded, urgent=False, chat_id=chat_id)


def shadow_database(config: Dict[str, Any]) -> ShadowDatabase:
    return ShadowDatabase(config)


def shadow_telegram(config: Dict[str, Any]) -> ShadowTelegram:
    return ShadowTelegram(config)


def shadow_open_trades(config: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    """symbol -> open/pending shadow trades, for the update cycle's gate."""
    result: Dict[str, List[Dict[str, Any]]] = {}
    for inst in shadow_instruments(config):
        symbol = normalize_symbol(inst.get("symbol"))
        try:
            from utils.instruments import config_for_instrument
            db = ShadowDatabase(config_for_instrument(config, inst))
            rows = db.get_open_trades() or []
        except Exception:  # noqa: BLE001 - a broken shadow book must not gate gold
            rows = []
        if rows:
            result[symbol] = rows
    return result
