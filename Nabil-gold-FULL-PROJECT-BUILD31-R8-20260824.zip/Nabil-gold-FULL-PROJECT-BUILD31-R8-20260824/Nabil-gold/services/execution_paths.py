"""Canonical names and propagation helpers for the four execution paths.

An execution path is admission provenance, not an extra vote and not a setup
quality score.  It is stamped on the decision before persistence and then
travels with the trade for every Telegram lifecycle card and performance
measurement.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict

PATH_1 = "PATH_1_THREE_AGENT_CONSENSUS"
PATH_2 = "PATH_2_TWO_AGENT_MACRO"
PATH_3 = "PATH_3_TWO_AGENT_GEMINI"
PATH_4 = "PATH_4_SMC_MAP_AUCTION"
PATH_5 = "PATH_5_TWO_AGENT_AUCTION"
# BUILD 30 legacy label (operator order 2026-08-24 R4: "احذف المسار 0
# بالكامل" — path 0 is DELETED from the registry; exactly 6 paths remain,
# 1-6). The constant survives ONLY so legacy rows stamped with the old id
# are remapped to PATH 6 in resolve_execution_path instead of degrading to
# NOT RECORDED (a pre-armed order must never be hidden).
PATH_PREARM_OTE = "PATH_PREARM_OTE"
# BUILD 31 R3 (2026-08-24, operator order): the OTE pre-arm is PATH 6 —
# it enters with the SAME admission as the two-agent paths (2 qualified
# agents, weighted opponents deducted, net >= 65, macro-or-gemini
# confirmation, risk agent approved), aimed at the projected OTE. It is a
# numbered path now, counted in the weekly Execution Paths report like any
# other. PATH_PREARM_OTE is kept ONLY as a legacy label for rows armed
# before the vote gate existed (those were not confirmed).
PATH_6 = "PATH_6_TWO_AGENT_OTE"
UNKNOWN_PATH = "UNKNOWN_EXECUTION_PATH"

PATH_DEFINITIONS: Dict[str, Dict[str, Any]] = {
    PATH_1: {
        "id": PATH_1,
        "number": 1,
        "name": "PATH 1 — THREE-AGENT CONSENSUS",
        "admission_path": "THREE_AGENT_CONSENSUS",
    },
    PATH_2: {
        "id": PATH_2,
        "number": 2,
        "name": "PATH 2 — TWO-AGENT + MACRO",
        "admission_path": "TWO_AGENT_MACRO",
    },
    PATH_3: {
        "id": PATH_3,
        "number": 3,
        "name": "PATH 3 — TWO-AGENT + GEMINI",
        "admission_path": "TWO_AGENT_GEMINI",
    },
    PATH_4: {
        "id": PATH_4,
        "number": 4,
        "name": "PATH 4 — SMC CONDITIONAL MAP + AUCTION FLOW",
        "admission_path": "SMC_MAP_AUCTION_CONFIRMATION",
    },
    PATH_5: {
        "id": PATH_5,
        "number": 5,
        "name": "PATH 5 — TWO-AGENT + AUCTION FLOW",
        "admission_path": "TWO_AGENT_AUCTION",
    },
    PATH_6: {
        "id": PATH_6,
        "number": 6,
        "name": "PATH 6 — TWO-AGENT CONFIRMED OTE (PRE-ARM)",
        "admission_path": "TWO_AGENT_OTE",
    },
}

ADMISSION_TO_PATH = {
    definition["admission_path"]: path_id
    for path_id, definition in PATH_DEFINITIONS.items()
}


def path_id_from_admission(admission_path: Any) -> str | None:
    raw = str(admission_path or "").strip().upper()
    if not raw:
        return None
    return ADMISSION_TO_PATH.get(raw)


def _explicit_path_id(payload: Dict[str, Any]) -> str | None:
    raw = str(payload.get("execution_path_id") or "").strip().upper()
    if raw in PATH_DEFINITIONS:
        return raw
    if raw == PATH_PREARM_OTE:
        return PATH_6  # legacy path-0 label -> the OTE path is PATH 6
    structured = payload.get("execution_path") or {}
    if isinstance(structured, dict):
        raw = str(structured.get("id") or "").strip().upper()
        if raw in PATH_DEFINITIONS:
            return raw
        if raw == PATH_PREARM_OTE:
            return PATH_6  # legacy path-0 label -> the OTE path is PATH 6
        mapped = path_id_from_admission(structured.get("admission_path"))
        if mapped:
            return mapped
    return None


def resolve_execution_path(payload: Dict[str, Any] | None) -> Dict[str, Any]:
    """Resolve path metadata from a decision, trade row, or legacy snapshot."""
    data = payload if isinstance(payload, dict) else {}
    path_id = _explicit_path_id(data)
    # BUILD 31 R4: the legacy path-0 label no longer exists in the registry
    # — the OTE path is PATH 6. Remap so legacy pre-armed rows resolve to
    # PATH 6 instead of degrading to NOT RECORDED.
    if path_id == PATH_PREARM_OTE:
        path_id = PATH_6

    # BUILD 31 R2 (2026-08-24, operator order "name every path"): arming
    # provenance is authoritative. A row/decision stamped
    # armed_at="pre_arm_ote" IS the pre-arm path even when the structured
    # path fields were dropped (old tick-manager process in memory, trimmed
    # snapshot). UNKNOWN must never be able to hide a pre-armed order.
    if not path_id and str(data.get("armed_at") or "") == "pre_arm_ote":
        return deepcopy(PATH_DEFINITIONS[PATH_6])

    snapshot = data.get("signal_snapshot")
    if not path_id and isinstance(snapshot, dict) and snapshot is not data:
        nested = resolve_execution_path(snapshot)
        if nested.get("id") in PATH_DEFINITIONS:
            return nested

    if not path_id:
        for admission in (
            data.get("planner_execution_gate"),
            data.get("execution_admission"),
            (data.get("session_plan") or {}).get("execution_admission")
            if isinstance(data.get("session_plan"), dict) else None,
            (data.get("session_plan") or {}).get("execution_readiness", {}).get("execution_admission")
            if isinstance((data.get("session_plan") or {}).get("execution_readiness"), dict) else None,
        ):
            if isinstance(admission, dict):
                path_id = path_id_from_admission(
                    admission.get("path") or admission.get("admission_path")
                )
                if path_id:
                    break

    mode = str(data.get("entry_mode") or "").lower()
    source = str(data.get("confirm_source") or "").lower()
    if not path_id and (source == "macro" or "two_agent_macro" in mode):
        path_id = PATH_2
    if not path_id and (source == "gemini" or "two_agent_gemini" in mode):
        path_id = PATH_3
    if not path_id and (source == "auction" or "two_agent_auction" in mode):
        path_id = PATH_5
    if not path_id and "smc" in mode and "auction" in mode:
        path_id = PATH_4

    # Legacy numeric entry_path=3 meant "session plan", not current Path 3.
    # It is intentionally not guessed.  A planner gate/snapshot above must
    # establish whether that old trade was Path 1, 2, 3, or 4.
    try:
        legacy_number = int(data.get("entry_path", 0) or 0)
    except (TypeError, ValueError):
        legacy_number = 0
    if not path_id and legacy_number == 1:
        path_id = PATH_1
    if not path_id and legacy_number == 2:
        path_id = PATH_2 if source != "gemini" else PATH_3

    if path_id in PATH_DEFINITIONS:
        return deepcopy(PATH_DEFINITIONS[path_id])
    return {
        "id": UNKNOWN_PATH,
        "number": 0,
        "name": "EXECUTION PATH — NOT RECORDED (LEGACY DECISION)",
        "admission_path": None,
    }


def stamp_execution_path(
    payload: Dict[str, Any], admission_or_path: Any,
) -> Dict[str, Any]:
    """Mutate and return ``payload`` with one canonical execution path."""
    if not isinstance(payload, dict):
        return payload
    if isinstance(admission_or_path, dict):
        raw = (
            admission_or_path.get("path")
            or admission_or_path.get("admission_path")
            or admission_or_path.get("id")
        )
    else:
        raw = admission_or_path
    raw_upper = str(raw or "").strip().upper()
    path_id = raw_upper if raw_upper in PATH_DEFINITIONS else path_id_from_admission(raw_upper)
    if not path_id:
        resolved = resolve_execution_path(payload)
        path_id = resolved.get("id") if resolved.get("id") in PATH_DEFINITIONS else None
    if not path_id:
        return payload
    definition = deepcopy(PATH_DEFINITIONS[path_id])
    payload["execution_path"] = definition
    payload["execution_path_id"] = definition["id"]
    payload["execution_path_number"] = definition["number"]
    payload["execution_path_name"] = definition["name"]
    # Keep the old numeric field readable, but from now on its meaning is the
    # canonical four-path number rather than the retired "planner=3" code.
    payload["entry_path"] = definition["number"]
    return payload


def path_header(payload: Dict[str, Any] | None, *, html: bool = True) -> str:
    """Return the first-line path label for a Telegram trade card."""
    name = str(resolve_execution_path(payload).get("name") or "EXECUTION PATH — NOT RECORDED (LEGACY DECISION)")
    return f"🛣️ <b>{name}</b>" if html else f"🛣️ {name}"
