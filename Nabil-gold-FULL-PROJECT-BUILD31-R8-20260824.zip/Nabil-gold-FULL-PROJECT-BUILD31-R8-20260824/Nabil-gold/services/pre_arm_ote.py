"""BUILD 30 (2026-08-22, operator order): PRE-ARM OTE — live, measurable.

BUILD 31 R3 (2026-08-24, operator order): the OTE arming is now PATH 6 —
"TWO-AGENT CONFIRMED OTE (PRE-ARM)". It enters with the SAME admission as
the two-agent paths (paths 2/3, left untouched): a two-agent book for the
direction (>= 2 qualified supporters, weighted opponents deducted via
edge > 0, net weighted confidence >= 65) + external confirmation (macro
first — gold macro for XAU, oil macro for WTI — gemini fallback, same
thresholds 55/70 and the same 15-minute cache) + the risk agent
approved. Fail closed: no readable book or no confirmation = no arm.
The order is still aimed at the projected OTE (that is what makes it
pre-arm): earlier in price and in time than the reactive paths.

Operator decision 2026-08-22 ("طبق كامل ويكون حي وقابل للقياس لا ظل"):
an open trade's entry was perceived as LATE because the current five
execution paths only admit a trade AFTER the pullback has formed, and the
decision then rides the 5-minute analysis cycle. The operator chose to arm
the order BEFORE the pullback arrives.

What this module does
---------------------
When the SMC structure shows a FRESH confirmed impulse leg, we PROJECT the
Optimal Trade Entry (OTE) retracement of that leg and place a PENDING order
at the projected level while the market is still at the top/bottom of the
impulse. The order then fills on touch — earlier in price and in time than
waiting for the pullback to complete.

Design principles (kept on purpose)
-----------------------------------
* ADDITIVE + SAFE: this is a parallel armer, not a new admission path. It
  reuses the existing PENDING machinery (activation on touch, 24h expiry,
  news block, staleness). If it does not fire, the system behaves 100% as
  before. Every gate is conservative; ANY failure anywhere -> no pre-arm,
  the reactive paths proceed untouched.
* NO NEW AGENT, NO LLM: the impulse/OTE projection is pure local
  candle/ATR math. Zero extra Gemini quota.
* SAME GATES as a live entry: SMC trend must align, news must not block,
  no existing open/pending on the symbol, OTE on the correct side and
  within max pending distance, RR >= min_rr.
* MEASURABLE: every pre-armed trade carries ``armed_at = "pre_arm_ote"``,
  path ``PATH 6 — TWO-AGENT CONFIRMED OTE (PRE-ARM)``, and the full
  ``vote_at_arm`` (book + confirmer) so the weekly execution-quality /
  path-performance sections report it separately from the five paths.
* KILL SWITCH: ``pre_arm_ote.enabled`` (default True per the operator's
  "live" order). Set False to revert to today's behaviour with no code
  change.

BUILD 31 R6 (2026-08-24, operator order: "fix it + measure 3 levels
50/60/70 + shadow only, stop the execution")
--------------------------------------------
* The OTE formula was FIXED: retracements are now measured from the
  extreme being pulled back from (the original code measured from the
  leg origin, so the "70% OTE" order sat at the 30% fib).
* SHADOW MODE: ``pre_arm_ote.shadow`` (config merge sets it True). When
  on, every gate still runs, but a would-be arm is only MEASURED — three
  candidate levels (``measure_levels``, default 50/60/70 retracement)
  sharing the leg-anchored stop, each tracked to resolution (touch /
  SL / TP1 / TP2 / 24h expiry) in ``pre_arm_ote_shadow_arms.jsonl``. NO
  order is placed, the reactive paths are never suppressed, and the
  weekly report publishes the per-level results. Promotion to live is a
  config decision (``shadow: false`` + ``entry_pct: <level>``); note
  that live promotion also requires the same-cycle suppression fix for
  the two-agent book state (documented, not shipped with R6).
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from utils.indicators import calculate_atr
from utils.instruments import price_to_points, points_to_price, price_decimals

logger = logging.getLogger(__name__)

ARMED_AT = "pre_arm_ote"
ENTRY_MODE = "two_agent_ote"
PATH_LABEL = "PATH 6 — TWO-AGENT CONFIRMED OTE (PRE-ARM)"
from services.execution_paths import PATH_6  # noqa: E402

# Defaults (all overridable under config["pre_arm_ote"]).
DEFAULTS: Dict[str, Any] = {
    "enabled": True,
    "timeframe": "15m",          # impulse leg measured on the primary frame
    "entry_pct": 0.70,           # OTE entry: 70% retracement of the leg
    "zone_low_pct": 0.62,        # OTE zone bounds (confluence window)
    "zone_high_pct": 0.79,
    "min_displacement_atr": 1.2, # impulse must clear >= 1.2 * ATR
    "leg_peak_recent_candles": 3,  # impulse peak must be within the last N closed bars
    "lookback_candles": 15,       # search window for the leg origin
    "stop_buffer_atr": 1.0,       # stop = leg origin +/- 1.0 * ATR
    "min_rr_ratio": 1.5,          # reject if projected RR < min_rr
    "max_pending_distance_points": 0.0,  # 0 = use the shared system cap
    "require_smc_trend": True,    # SMC primary trend must align (hard gate)
    # BUILD 31 R3 (2026-08-24, operator order: the OTE arm is PATH 6 and
    # enters with the SAME admission as the two-agent paths, untouched):
    # a two-agent book for the direction (>= min_supporters qualified,
    # weighted opponents deducted via edge > 0, net >= min_net_confidence)
    # PLUS external confirmation (macro first, gemini fallback — same
    # chain/thresholds/cache as paths 2/3) PLUS the risk agent approved.
    # Fail CLOSED on anything unreadable: no readable book or no
    # confirmation means no arm.
    "vote_gate": {"enabled": True, "min_supporters": 2,
                  "min_net_confidence": 65.0,
                  "require_confirmation": True},
    # BUILD 31 R6 (2026-08-24, operator order: "fix it + measure 3 levels
    # 50/60/70 + shadow only, stop the execution"): when True, ALL gates
    # still run, but a would-be arm is only MEASURED — THREE candidate
    # entry levels (measure_levels: 50/60/70 retracement) with the same
    # leg-anchored stop, each tracked to resolution (touch / SL / TP1 /
    # TP2 / 24h expiry). NO order is ever placed and the reactive paths
    # are never suppressed. The weekly report aggregates per-level
    # results so the operator decides with data: promote the best level
    # to live (shadow=false + entry_pct=<level>), or retire the path.
    # Code default is False (execution) so an old config never silently
    # changes behaviour; the config merge sets it True on install.
    "shadow": False,
    # the retracement levels measured side by side (fractions of the leg)
    "measure_levels": [0.50, 0.60, 0.70],
    # shadow bookkeeping
    "shadow_expire_after_hours": 24.0,   # an untouched level expires
    "shadow_keep_days": 14,              # resolved events pruned after
}


def _cfg(config: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(DEFAULTS)
    raw = (config or {}).get("pre_arm_ote") or {}
    if isinstance(raw, dict):
        for k in DEFAULTS:
            if k in raw and raw[k] is not None:
                out[k] = raw[k]
        # vote_gate merges shallowly so a partial config override keeps
        # the other defaults.
        if isinstance(raw.get("vote_gate"), dict):
            merged = dict(DEFAULTS["vote_gate"])
            merged.update(raw["vote_gate"])
            out["vote_gate"] = merged
    return out


def _f(v: Any, d: float = 0.0) -> float:
    try:
        x = float(v)
        return x if x == x else d  # NaN guard
    except (TypeError, ValueError):
        return d


def _candle_f(c: Dict[str, Any], key: str, d: float = 0.0) -> float:
    return _f(c.get(key), d)


def detect_impulse_leg(candles: List[Dict[str, Any]], atr: float,
                       cfg: Dict[str, Any],
                       direction: str) -> Optional[Dict[str, Any]]:
    """Return the most recent confirmed impulse leg for ``direction``.

    A bullish impulse: a strong UP move whose PEAK is recent (within
    ``leg_peak_recent_candles`` closed bars) and whose origin (trough) is
    within ``lookback_candles``. The leg size must clear
    ``min_displacement_atr * atr``. Returns None when no fresh valid leg
    exists (the common case — the market is mid-pullback or chopping).
    """
    if atr <= 0 or len(candles) < 8:
        return None
    peak_recent = int(cfg.get("leg_peak_recent_candles", 3))
    lookback = int(cfg.get("lookback_candles", 15))
    min_size = float(cfg.get("min_displacement_atr", 1.2)) * atr
    # Only consider CLOSED candles (the last one may be forming).
    closed = candles[:-1] if len(candles) > 2 else candles
    n = len(closed)
    if n < 8:
        return None
    # The peak must sit in the most recent `peak_recent` closed bars.
    peak_start = max(0, n - peak_recent)
    if direction == "BUY":
        peak_idx = peak_start
        for i in range(peak_start, n):
            if _candle_f(closed[i], "high") >= _candle_f(closed[peak_idx], "high"):
                peak_idx = i
        peak = _candle_f(closed[peak_idx], "high")
        origin_start = max(0, peak_idx - lookback)
        trough_idx = peak_idx
        for i in range(origin_start, peak_idx + 1):
            if _candle_f(closed[i], "low") <= _candle_f(closed[trough_idx], "low"):
                trough_idx = i
        trough = _candle_f(closed[trough_idx], "low")
        size = peak - trough
        if size < min_size:
            return None
        return {"direction": "BUY", "leg_origin": trough, "leg_peak": peak,
                "leg_size": size, "peak_idx": peak_idx, "atr": atr}
    # SELL
    peak_idx = peak_start
    for i in range(peak_start, n):
        if _candle_f(closed[i], "low") <= _candle_f(closed[peak_idx], "low"):
            peak_idx = i
    peak = _candle_f(closed[peak_idx], "low")
    origin_start = max(0, peak_idx - lookback)
    trough_idx = peak_idx
    for i in range(origin_start, peak_idx + 1):
        if _candle_f(closed[i], "high") >= _candle_f(closed[trough_idx], "high"):
            trough_idx = i
    trough = _candle_f(closed[trough_idx], "high")
    size = trough - peak
    if size < min_size:
        return None
    return {"direction": "SELL", "leg_origin": trough, "leg_peak": peak,
            "leg_size": size, "peak_idx": peak_idx, "atr": atr}


def project_ote(leg: Dict[str, Any], cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Project the OTE retracement zone/entry/stop for a detected leg.

    BUILD 31 R6 FIX (2026-08-24, operator review of the 15:31 incident):
    the original formula measured the percentage FROM THE LEG ORIGIN
    (entry = origin + size*pct), which is a (100-pct)% retracement — the
    "70% OTE" order actually sat at the 30% fib, far too shallow. A
    retracement is measured from the EXTREME being pulled back from:
    BUY entry = peak - size*pct ; SELL entry = peak + size*pct.
    """
    entry_pct = float(cfg.get("entry_pct", 0.70))
    z_low = float(cfg.get("zone_low_pct", 0.62))
    z_high = float(cfg.get("zone_high_pct", 0.79))
    origin = float(leg["leg_origin"])
    peak = float(leg["leg_peak"])
    size = float(leg["leg_size"])
    atr = float(leg["atr"])
    d = leg["direction"]
    if d == "BUY":
        # pullback DOWN from the peak: 62-79% zone = [peak-0.79*size, peak-0.62*size]
        entry = peak - size * entry_pct
        zone_low = peak - size * z_high    # 79% (the deeper edge)
        zone_high = peak - size * z_low    # 62% (the shallower edge)
        stop = origin - float(cfg.get("stop_buffer_atr", 1.0)) * atr
        target = peak
    else:
        # pullback UP from the trough: 62-79% zone = [peak+0.62*size, peak+0.79*size]
        entry = peak + size * entry_pct
        zone_low = peak + size * z_low     # 62% (the lower price)
        zone_high = peak + size * z_high   # 79% (the higher price)
        stop = origin + float(cfg.get("stop_buffer_atr", 1.0)) * atr
        target = peak
    return {"entry": entry, "zone_low": min(zone_low, zone_high),
            "zone_high": max(zone_low, zone_high), "stop": stop,
            "target": target, "direction": d}


def _smc_trend(all_results: Dict[str, Any]) -> str:
    smc = (all_results or {}).get("smc") or {}
    trend = str(smc.get("trend") or "").upper()
    if not trend:
        # Fused payload may nest the primary-frame structure.
        for key in ("structure", "market_structure", "primary"):
            sub = smc.get(key)
            if isinstance(sub, dict) and sub.get("trend"):
                return str(sub.get("trend")).upper()
    return trend


def _news_blocks(all_results: Dict[str, Any]) -> bool:
    news = (all_results or {}).get("news") or {}
    if news.get("can_trade") is False:
        return True
    if str(news.get("market_status", "")).upper() in {"DANGER", "HIGH_VOLATILITY"}:
        return True
    return False


def _auction_allows(all_results: Dict[str, Any], direction: str) -> bool:
    """Soft gate: block only when auction flow is CLEARLY against."""
    af = (all_results or {}).get("auction_flow") or {}
    if not isinstance(af, dict) or not af:
        return True  # no data -> do not block
    regime = str(af.get("regime") or af.get("profile") or "").upper()
    bias = str(af.get("bias") or "").upper()
    against = (direction == "BUY" and bias == "BEARISH") or \
              (direction == "SELL" and bias == "BULLISH")
    if against:
        return False
    return True


def _path6_book_check(classic_book: Optional[Dict[str, Any]], direction: str,
                      min_supporters: int,
                      min_net: float):
    """The two-agent book condition, EXACTLY the numbers paths 2/3 use
    (same builder output, same thresholds): support_count >= 2 qualified,
    weighted opponents deducted (edge = support_score - opposition_score
    must be > 0), net weighted confidence >= 65. A book with 3+ supporters
    passing these same conditions is STRONGER, not weaker — it passes
    (path 2's upper cap only separates it from path 1's territory; path 6
    has no such rival). Returns (book, None) or (None, reason)."""
    m = ((classic_book or {}).get("consensus") or {}).get(direction) or {}
    support = int(m.get("support_count", 0) or 0)
    edge = _f(m.get("edge"))
    conf = _f(m.get("confidence"))
    supporters = [str(x) for x in (m.get("supporters") or [])]
    opponents = [str(x) for x in (m.get("opponents") or [])]
    if support < min_supporters:
        return None, "thin_book"
    if edge <= 0:
        return None, "edge_le_zero"
    if conf < min_net:
        return None, "low_net"
    return {"supporters": supporters, "opponents": opponents,
            "edge": round(edge, 3), "net_confidence": round(conf, 1)}, None


def _macro_confirms(all_results: Dict[str, Any], config: Dict[str, Any],
                    symbol: str, direction: str):
    """Step A of the two-agent chain, same routing/thresholds as paths 2/3:
    XAU -> the gold macro (BULLISH_GOLD/BEARISH_GOLD, >= 55%); WTI -> the
    OIL macro (EIA/OPEC/Brent-WTI spread, >= 55%) — the gold macro must
    never confirm an oil entry."""
    tae_cfg = (((config or {}).get("signal_requirements") or {})
               .get("two_agent_entry") or {})
    if "WTI" in str(symbol).upper():
        oil_min = float((tae_cfg.get("oil_macro_confirmation") or {})
                        .get("min_confidence", 55) or 55)
        src = (all_results or {}).get("oil_macro") or {}
        side = str(src.get("direction") or src.get("bias") or "").upper()
        if side.startswith("BEARISH"):
            side = "SELL"
        elif side.startswith("BULLISH"):
            side = "BUY"
        conf = _f(src.get("confidence"))
        if side == direction and conf >= oil_min:
            return True, "oil_macro", conf
        return False, None, conf
    macro_min = float((tae_cfg.get("macro_confirmation") or {})
                      .get("min_confidence", 55) or 55)
    macro = (all_results or {}).get("macro_fundamental") or {}
    mdir = macro.get("macro_direction") or {}
    bias = str(mdir.get("bias") or "").upper()
    conf = _f(mdir.get("confidence"))
    expected = "BULLISH_GOLD" if direction == "BUY" else "BEARISH_GOLD"
    if bias == expected and conf >= macro_min:
        return True, "macro", conf
    return False, None, conf


def _gemini_confirms(config: Dict[str, Any], symbol: str, direction: str,
                     all_results: Dict[str, Any]):
    """Step B of the two-agent chain: gemini verdict == direction at >=
    70%, reusing the SAME 15-minute confirmation cache as paths 2/3 (a
    verdict already fetched this cycle is free; unavailable results are
    never cached)."""
    tae_cfg = (((config or {}).get("signal_requirements") or {})
               .get("two_agent_entry") or {})
    g_cfg = tae_cfg.get("gemini_confirmation") or {}
    if not bool(g_cfg.get("enabled", True)):
        return False, None, 0.0
    try:
        from services.gemini_confirm_cache import (load_confirmation,
                                                   store_confirmation)
        from services.llm_review import get_gemini_review_service

        svc = get_gemini_review_service(config)
        if not svc.enabled:
            return False, None, 0.0
        g_min = float(g_cfg.get("min_confidence", 70) or 70)
        ttl = _f(((config or {}).get("llm_review") or {})
                 .get("confirmation_cache_minutes"), 15.0)
        atr_sig = _f(((all_results or {}).get("technical") or {}).get("atr"), 0.0)
        vol_inv = _f(((config or {}).get("llm_review") or {})
                     .get("cache_vol_invalidation_pct"), 25.0)
        review = load_confirmation(
            symbol, direction, max_age_minutes=ttl,
            vol_signature=atr_sig if atr_sig > 0 else None,
            vol_invalidation_pct=vol_inv)
        if review is None:
            review = svc.review_signal(
                {"symbol": symbol, "decision": direction,
                 "all_results": all_results})
            if isinstance(review, dict) and atr_sig > 0:
                review = dict(review)
                review["_vol_signature_hint"] = atr_sig
            store_confirmation(symbol, direction, review)
        verdict = str((review or {}).get("verdict", "")).upper()
        conf = _f((review or {}).get("confidence"))
        if verdict == direction and conf >= g_min:
            return True, "gemini", conf
        return False, None, conf
    except Exception:  # noqa: BLE001 - no confirmation, never a crash
        return False, None, 0.0


def _log_vote_rejection(symbol: str, direction: str,
                        vote: Dict[str, Any], reason: str) -> None:
    """Measurability (Plan A): every vote-rejected arm lands in a JSONL
    audit file in the process CWD so the weekly review can count
    'pre-arms rejected by vote' (the price of the no-solo-entry rule)."""
    try:
        event = {"ts": datetime.now(timezone.utc).isoformat(),
                 "symbol": symbol, "direction": direction,
                 "reason": reason,
                 "supporters": list(vote.get("supporters") or []),
                 "opponents": list(vote.get("opponents") or []),
                 "min_supporters": vote.get("min_supporters"),
                 "max_opponents": vote.get("max_opponents")}
        with open("pre_arm_vote_rejections.jsonl", "a", encoding="utf-8") as fh:
            fh.write(json.dumps(event, ensure_ascii=False) + "\n")
    except Exception:  # noqa: BLE001 - audit never blocks the decision
        pass


# ══════════════════════════════════════════════════════════════════════════
# BUILD 31 R6: SHADOW MODE — measure, never execute (operator order 2026-08-24)
# ══════════════════════════════════════════════════════════════════════════
# A would-be arm is recorded with THREE candidate entry levels (50/60/70
# retracement, all measured from the extreme being pulled back from) that
# share the same leg-anchored stop and target. Each level is then tracked
# on CLOSED M15 bars + the live price, conservatively (within one bar the
# stop wins over a target), until touch->SL/TP1/TP2 or 24h expiry. The
# weekly report aggregates the per-level results; the operator decides
# with data whether to promote a level to live or retire the path.
# Nothing here can reach MT5 or the trade book: there is no
# database.save_trade, no broker call, no suppression of reactive paths.

SHADOW_FILE = "pre_arm_ote_shadow_arms.jsonl"
SHADOW_BANNER = ("\U0001F47B PATH 6 SHADOW \u2014 \u062a\u0642\u064a\u064a\u0633 \u0641\u0642\u0637 "
                 "(\u0644\u0627 \u0623\u0648\u0627\u0645\u0631 \u062a\u0646\u0641\u064a\u0630\u064a)")


def _load_shadow_arms() -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    try:
        with open(SHADOW_FILE, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except Exception:  # noqa: BLE001 - skip a torn line
                    continue
    except FileNotFoundError:
        pass
    except Exception:  # noqa: BLE001 - a broken book never blocks the cycle
        pass
    return out


def _save_shadow_arms(arms: List[Dict[str, Any]]) -> None:
    try:
        tmp = SHADOW_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            for arm in arms:
                fh.write(json.dumps(arm, ensure_ascii=False) + "\n")
        import os as _os
        _os.replace(tmp, SHADOW_FILE)
    except Exception as exc:  # noqa: BLE001 - measurement never breaks the cycle
        logger.warning("PATH 6 shadow save failed: %s", exc)


def _level_entry(side: str, origin: float, peak: float, size: float,
                 pct: float) -> float:
    """A TRUE retracement measured from the extreme being pulled back
    from: BUY levels come DOWN from the peak, SELL levels come UP from
    the trough. (50% is the symmetric midpoint of the leg.)"""
    if side == "BUY":
        return peak - size * pct
    return peak + size * pct


def _build_level_state(side: str, origin: float, peak: float, size: float,
                       stop: float, target: float, cp: float,
                       pct: float, cfg: Dict[str, Any],
                       symbol: str) -> Dict[str, Any]:
    """One measured candidate level: entry at `pct` retracement, the
    SAME leg-anchored stop for every level, tp1 = midpoint to tp2,
    tp2 = the leg peak extended to the minimum R:R when the peak alone
    is thin (identical rule to the live armer)."""
    entry = _level_entry(side, origin, peak, size, pct)
    min_rr = float(cfg.get("min_rr_ratio", 1.5))
    tp2 = target
    if side == "BUY":
        risk = entry - stop
        rr = (tp2 - entry) / risk if risk > 0 else 0.0
        if rr < min_rr and risk > 0:
            tp2 = entry + min_rr * risk
        rr = (tp2 - entry) / risk if risk > 0 else 0.0
        tp1 = entry + (tp2 - entry) * 0.5
        distance = abs(price_to_points(cp - entry, symbol=symbol))
    else:
        risk = stop - entry
        rr = (entry - tp2) / risk if risk > 0 else 0.0
        if rr < min_rr and risk > 0:
            tp2 = entry - min_rr * risk
        rr = (entry - tp2) / risk if risk > 0 else 0.0
        tp1 = entry - (entry - tp2) * 0.5
        distance = abs(price_to_points(cp - entry, symbol=symbol))
    return {
        "entry": round(entry, 8), "stop": round(stop, 8),
        "tp1": round(tp1, 8), "tp2": round(tp2, 8),
        "rr": round(rr, 3), "risk_points": round(risk, 2),
        "distance_points": round(distance, 2),
        "status": "OPEN", "touched_at": None, "outcome": None,
        "pnl_points": None, "resolved_at": None,
    }


def _record_shadow_arm(*, decision: Dict[str, Any], leg: Dict[str, Any],
                       cp: float, symbol: str, cfg: Dict[str, Any],
                       telegram: Any = None) -> None:
    """Record ONE would-be arm with its measured levels. NO order is
    placed; the reactive paths are left untouched (the caller returns
    None so the run_analysis suppression block never fires)."""
    now = datetime.now(timezone.utc)
    side = str(decision.get("decision", "")).upper()
    origin = float(leg["leg_origin"])
    peak = float(leg["leg_peak"])
    size = float(leg["leg_size"])
    sig = decision.get("signal") or {}
    stop = float(sig.get("stop_loss") or leg_origin_stop(leg, cfg))
    pcts = [float(p) for p in (cfg.get("measure_levels")
                               or DEFAULTS["measure_levels"])]
    pcts = sorted(set(pcts))
    levels: Dict[str, Dict[str, Any]] = {}
    for pct in pcts:
        key = f"{pct * 100:.0f}"
        levels[key] = _build_level_state(
            side=side, origin=origin, peak=peak, size=size, stop=stop,
            target=float(sig.get("tp2") or peak), cp=cp, pct=pct,
            cfg=cfg, symbol=symbol)
    vote = decision.get("vote_at_arm") or {}
    arm = {
        "id": f"SHADOWARM_{now.strftime('%Y%m%d_%H%M%S')}_"
              f"{str(symbol).replace('/', '').lower()}_{side.lower()}",
        "ts": now.isoformat(),
        "symbol": symbol, "side": side,
        "current_price": round(float(cp), 8),
        "smc_trend": (decision.get("pre_arm_info") or {}).get("smc_trend"),
        "leg": {"origin": round(origin, 8), "peak": round(peak, 8),
                "size": round(size, 8),
                "atr_multiple": (decision.get("pre_arm_info") or {}).get("impulse_leg_atr")},
        "vote": {"supporters": vote.get("supporters"),
                 "opponents": vote.get("opponents"),
                 "edge": vote.get("edge"),
                 "net_confidence": vote.get("net_confidence"),
                 "confirm_source": vote.get("confirm_source"),
                 "confirm_confidence": vote.get("confirm_confidence")},
        "levels": levels,
        "status": "OPEN",
    }
    arms = _load_shadow_arms()
    arms.append(arm)
    _save_shadow_arms(arms)
    logger.info(
        "PATH 6 SHADOW would-arm %s %s: levels=%s stop=%.2f (NO order "
        "placed; measurement only)", side, symbol,
        {k: v["entry"] for k, v in levels.items()}, stop)
    # Visibility for the operator: a clearly branded, NON-urgent notice
    # (never a trade card — there is no order).
    try:
        if telegram is not None and hasattr(telegram, "send_message"):
            lvl_lines = " · ".join(
                f"{k}% @ {v['entry']}" for k, v in levels.items())
            text = (
                f"{SHADOW_BANNER}\n"
                f"Would have armed: {side} {symbol}\n"
                f"Measured levels: {lvl_lines}\n"
                f"SL {stop:.2f} · target peak {peak:.2f} · "
                f"leg {size / float(leg.get('atr') or 1):.1f}x ATR\n"
                f"Book: {len(vote.get('supporters') or [])}\u2705 "
                f"- {len(vote.get('opponents') or [])}\u274c "
                f"· net {vote.get('net_confidence')}% "
                f"· {vote.get('confirm_source')} {vote.get('confirm_confidence')}%\n"
                f"Tracking 50/60/70 to resolution (touch / SL / TP / 24h) "
                f"— results in the weekly report. No order was placed."
            )
            telegram.send_message(text, urgent=False)
    except Exception as exc:  # noqa: BLE001 - the record is what matters
        logger.warning("PATH 6 shadow notice failed: %s", exc)


def leg_origin_stop(leg: Dict[str, Any], cfg: Dict[str, Any]) -> float:
    """The leg-anchored stop (origin +/- stop_buffer_atr * ATR), shared
    by every measured level of the arm."""
    buffer = float(cfg.get("stop_buffer_atr", 1.0)) * float(leg.get("atr") or 0.0)
    origin = float(leg["leg_origin"])
    if leg.get("direction") == "BUY":
        return origin - buffer
    return origin + buffer


def _update_shadow_arms(*, symbol: str, candles: List[Dict[str, Any]],
                        current_price: float,
                        expire_hours: float = 24.0,
                        keep_days: float = 14.0) -> None:
    """Advance every open arm for this symbol on the latest CLOSED bar +
    the live price. Conservative within one bar: if the bar's range
    covers both a stop and a target, the STOP wins. Pure measurement —
    writes only to the shadow JSONL."""
    arms = _load_shadow_arms()
    if not arms:
        return
    closed = candles[:-1] if len(candles) > 1 else []
    bar = closed[-1] if closed else None
    bar_high = _candle_f(bar, "high") if bar else 0.0
    bar_low = _candle_f(bar, "low") if bar else float("inf")
    cp = float(current_price or 0.0)
    now = datetime.now(timezone.utc)
    changed = False

    for arm in arms:
        if str(arm.get("symbol", "")).upper() != str(symbol).upper():
            continue
        if arm.get("status") == "CLOSED":
            continue
        try:
            armed_at = datetime.fromisoformat(str(arm["ts"]))
        except Exception:  # noqa: BLE001
            continue
        side = str(arm.get("side", "")).upper()
        expired = (now - armed_at).total_seconds() > expire_hours * 3600.0
        arm_closed = True
        for lv in (arm.get("levels") or {}).values():
            st = str(lv.get("status") or "OPEN")
            entry = _f(lv.get("entry"))
            stop = _f(lv.get("stop"))
            tp1 = _f(lv.get("tp1"))
            tp2 = _f(lv.get("tp2"))
            if side == "BUY":
                touched = st == "TOUCHED" or cp <= entry or bar_low <= entry
                hit_sl = cp <= stop or bar_low <= stop
                hit_tp2 = cp >= tp2 or bar_high >= tp2
                hit_tp1 = cp >= tp1 or bar_high >= tp1
            else:
                touched = st == "TOUCHED" or cp >= entry or bar_high >= entry
                hit_sl = cp >= stop or bar_high >= stop
                hit_tp2 = cp <= tp2 or bar_low <= tp2
                hit_tp1 = cp <= tp1 or bar_low <= tp1
            if st == "OPEN":
                if touched:
                    lv["status"] = "TOUCHED"
                    lv["touched_at"] = now.isoformat()
                    arm_closed = False  # a touched level is still running
                    changed = True
                elif expired:
                    lv["status"] = "CLOSED"
                    lv["outcome"] = "EXPIRED_NEVER_TOUCHED"
                    lv["pnl_points"] = 0.0
                    lv["resolved_at"] = now.isoformat()
                    changed = True
                else:
                    arm_closed = False
                continue
            # st == TOUCHED: resolve, stop-first (conservative)
            outcome = None
            if hit_sl:
                outcome = "SL"
            elif hit_tp2:
                outcome = "TP2"
            elif hit_tp1:
                outcome = "TP1"
            elif expired:
                outcome = "EXPIRED_AFTER_TOUCH"
            if outcome:
                lv["status"] = "CLOSED"
                lv["outcome"] = outcome
                if side == "BUY":
                    ref = {"SL": stop, "TP1": tp1, "TP2": tp2}.get(outcome)
                    lv["pnl_points"] = round((ref - entry), 2) if ref else 0.0
                else:
                    ref = {"SL": stop, "TP1": tp1, "TP2": tp2}.get(outcome)
                    lv["pnl_points"] = round((entry - ref), 2) if ref else 0.0
                lv["resolved_at"] = now.isoformat()
                changed = True
            else:
                arm_closed = False
        if arm_closed and arm.get("status") != "CLOSED":
            arm["status"] = "CLOSED"
            arm["resolved_at"] = now.isoformat()
            changed = True

    if changed:
        # prune long-resolved events (the file stays small by design)
        cutoff = now - timedelta(days=float(keep_days))
        kept = []
        for arm in arms:
            if arm.get("status") == "CLOSED":
                try:
                    res = datetime.fromisoformat(str(arm.get("resolved_at") or arm["ts"]))
                    if res < cutoff:
                        continue
                except Exception:  # noqa: BLE001
                    pass
            kept.append(arm)
        _save_shadow_arms(kept)


def try_pre_arm(*, data: Dict[str, Any], all_results: Dict[str, Any],
                config: Dict[str, Any], symbol: str,
                open_trades_snapshot: Optional[List[Dict[str, Any]]] = None,
                database: Any = None, telegram: Any = None,
                current_price: Optional[float] = None,
                demo_execution: bool = False,
                classic_book: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """Attempt to arm a PENDING order at the projected OTE level.

    Returns the armed side ("BUY"/"SELL") on success, else None. NEVER
    raises — any internal problem means "no pre-arm, continue normally".
    """
    try:
        return _try_pre_arm_impl(data=data, all_results=all_results,
                                 config=config, symbol=symbol,
                                 open_trades_snapshot=open_trades_snapshot,
                                 database=database, telegram=telegram,
                                 current_price=current_price,
                                 demo_execution=demo_execution,
                                 classic_book=classic_book)
    except Exception as exc:  # noqa: BLE001 - pre-arm must never break the cycle
        logger.warning("PATH 6 pre-arm skipped (non-fatal): %s", exc)
        return None


def _try_pre_arm_impl(*, data, all_results, config, symbol,
                      open_trades_snapshot, database, telegram,
                      current_price, demo_execution=False,
                      classic_book=None) -> Optional[str]:
    cfg = _cfg(config)
    if not bool(cfg.get("enabled", True)):
        return None
    if database is None:
        return None
    tf = str(cfg.get("timeframe", "15m"))
    candles = (((data.get("timeframes", {}) or {}).get(tf) or {}).get("data")
               or data.get("data") or [])
    if len(candles) < 10:
        return None
    atr_list = calculate_atr(candles, 14)
    atr = _f(atr_list[-1], 0.0) if atr_list else 0.0
    if atr <= 0:
        return None
    cp = _f(current_price, 0.0) or _f(data.get("current_price"), 0.0)
    if cp <= 0:
        return None

    # BUILD 31 R6: advance any OPEN shadow arms (measurement only). Runs
    # BEFORE the gates so tracking continues even when a new arm is
    # blocked this cycle. Never executes anything.
    if bool(cfg.get("shadow", False)):
        try:
            _update_shadow_arms(
                symbol=symbol, candles=candles, current_price=cp,
                expire_hours=float(cfg.get("shadow_expire_after_hours", 24.0)),
                keep_days=float(cfg.get("shadow_keep_days", 14)))
        except Exception as exc:  # noqa: BLE001 - never break the cycle
            logger.warning("PATH 6 shadow tracking failed (non-fatal): %s", exc)

    # No existing open/pending on this symbol -> never stack a pre-arm.
    for t in (open_trades_snapshot or []):
        if str(t.get("symbol", "")).upper() == str(symbol).upper():
            status = str(t.get("status", "")).upper()
            if status in {"OPEN", "PARTIAL", "TP1_HIT", "PENDING"}:
                return None

    if _news_blocks(all_results):
        return None

    # SMC trend (hard gate when required) decides the candidate direction.
    trend = _smc_trend(all_results)
    candidate = None
    if trend == "BULLISH":
        candidate = "BUY"
    elif trend == "BEARISH":
        candidate = "SELL"
    else:
        return None
    if not _auction_allows(all_results, candidate):
        return None

    leg = detect_impulse_leg(candles, atr, cfg, candidate)
    if not leg:
        return None
    ote = project_ote(leg, cfg)

    # OTE must be on the correct side of price (waiting for the pullback).
    if candidate == "BUY" and ote["entry"] >= cp:
        return None  # pullback already went through/below -> consumed
    if candidate == "SELL" and ote["entry"] <= cp:
        return None
    # Distance cap.
    max_dist = float(cfg.get("max_pending_distance_points", 0.0))
    if max_dist <= 0:
        risk_cfg = (config.get("risk_settings") or {}) if isinstance(config, dict) else {}
        max_dist = _f(risk_cfg.get("max_pending_distance_points"), 0.0)
    if max_dist > 0:
        dist = abs(price_to_points(cp - ote["entry"], symbol=symbol))
        if dist > max_dist:
            return None

    # Risk / RR gate. The first objective is the leg peak (the reclaim);
    # a short leg vs ATR gives a thin reclaim, so the objective is EXTENDED
    # to the minimum RR (leg extension) rather than the arm being rejected.
    risk = abs(ote["entry"] - ote["stop"])
    if risk <= 0:
        return None
    tp2 = ote["target"]
    rr = abs(tp2 - ote["entry"]) / risk
    min_rr = float(cfg.get("min_rr_ratio", 1.5))
    if rr < min_rr:
        tp2 = (ote["entry"] + min_rr * risk) if candidate == "BUY" \
            else (ote["entry"] - min_rr * risk)
        rr = min_rr

    # ── BUILD 31 R3: PATH 6 (operator order 2026-08-24) ─────────────────
    # The OTE arm enters with the SAME admission as the two-agent paths
    # (paths 2/3, left untouched): (1) risk agent approved, (2) a
    # two-agent book for the direction — >= 2 qualified supporters,
    # weighted opponents deducted (edge > 0), net >= 65 — (3) external
    # confirmation: macro first, gemini fallback, same chain/thresholds/
    # 15-min cache. Fail CLOSED on anything unreadable: no readable book
    # or no confirmation means no arm.
    gate = cfg.get("vote_gate") or {}
    tae_cfg = (((config or {}).get("signal_requirements") or {})
               .get("two_agent_entry") or {})
    min_supporters = int(gate.get("min_supporters", 2))
    min_net = _f(gate.get("min_net_confidence"),
                 _f(tae_cfg.get("min_consensus_confidence"), 65.0))
    vote: Dict[str, Any] = {
        "supporters": [], "opponents": [], "edge": None,
        "net_confidence": None, "confirm_source": None,
        "confirm_confidence": None,
        "min_supporters": min_supporters,
        "min_net_confidence": round(min_net, 1),
    }
    if bool(gate.get("enabled", True)):
        # (1) the risk agent's verdict is not advisory (as on paths 2/3)
        if not ((all_results or {}).get("risk", {}) or {}).get("approved", True):
            _log_vote_rejection(symbol, candidate, vote, "risk_refused")
            logger.info("PATH 6 %s %s NOT armed: risk agent refused the plan",
                        candidate, symbol)
            return None
        # (2) the two-agent book (weighted opponents deducted: edge > 0)
        book, book_reason = _path6_book_check(
            classic_book, candidate, min_supporters, min_net)
        if book is None:
            _log_vote_rejection(symbol, candidate, vote, book_reason)
            logger.info("PATH 6 %s %s NOT armed: %s",
                        candidate, symbol, book_reason)
            return None
        vote.update(book)
        # (3) confirmation chain: macro first, gemini fallback (same as 2/3)
        if bool(gate.get("require_confirmation", True)):
            ok, source, conf = _macro_confirms(
                all_results, config, symbol, candidate)
            if not ok:
                ok, source, conf = _gemini_confirms(
                    config, symbol, candidate, all_results)
            if not ok:
                _log_vote_rejection(symbol, candidate, vote, "no_confirmation")
                logger.info(
                    "PATH 6 %s %s NOT armed: no macro/gemini confirmation",
                    candidate, symbol)
                return None
            vote["confirm_source"] = source
            vote["confirm_confidence"] = round(conf, 1)

    decision = _build_decision(config=config, cfg=cfg, symbol=symbol,
                               direction=candidate, ote=ote, cp=cp, rr=rr,
                               atr=atr, tp2=tp2, smc_trend=trend, leg=leg,
                               vote=vote)
    if not decision:
        return None
    # BUILD 31 R6: SHADOW MODE — measure, never execute. Record the
    # would-be arm with the 50/60/70 levels and return None: NO order is
    # saved, nothing reaches the broker, and the reactive paths are NOT
    # suppressed (the caller's same-direction block never fires).
    if bool(cfg.get("shadow", False)):
        try:
            _record_shadow_arm(decision=decision, leg=leg, cp=cp,
                               symbol=symbol, cfg=cfg, telegram=telegram)
        except Exception as exc:  # noqa: BLE001 - measurement never blocks
            logger.warning("PATH 6 shadow record failed (non-fatal): %s", exc)
        return None
    # Persist (PENDING LIMIT) and notify, mirroring the reactive save path.
    trade_id = database.new_trade_id()
    decision["trade_id"] = trade_id
    decision["_telegram_signal_sent"] = False  # rich card after broker accepts
    try:
        database.save_trade(decision)
    except Exception as exc:  # noqa: BLE001
        logger.warning("PRE-ARM OTE save failed for %s %s: %s", direction, symbol, exc)
        return None
    # Demo/mt5 execution: the rich card is sent by the tick manager ONLY
    # after the broker accepts the order (same contract as the reactive
    # path). Paper mode announces immediately, like the reactive save flow.
    if not demo_execution:
        try:
            if telegram is not None and hasattr(telegram, "send_signal"):
                telegram.send_signal(decision)
        except Exception as exc:  # noqa: BLE001 - save succeeded; card best-effort
            logger.warning("PRE-ARM OTE signal delivery failed for %s: %s", symbol, exc)
    logger.info(
        "PRE-ARM OTE armed %s PENDING for %s: entry=%.2f zone=[%.2f-%.2f] "
        "stop=%.2f tp2=%.2f rr=%.2f (current=%.2f) path=%s",
        candidate, symbol, ote["entry"], ote["zone_low"], ote["zone_high"],
        ote["stop"], tp2, rr, cp, PATH_LABEL,
    )
    return candidate


def _build_decision(*, config, cfg, symbol, direction, ote, cp, rr, atr,
                    tp2=None, smc_trend: str = "",
                    leg: Optional[Dict[str, Any]] = None,
                    vote: Optional[Dict[str, Any]] = None
                    ) -> Optional[Dict[str, Any]]:
    decimals = price_decimals(symbol)
    pct = f"{float(cfg.get('entry_pct', 0.70)) * 100:.0f}"
    entry = round(ote["entry"], decimals)
    stop = round(ote["stop"], decimals)
    tp2 = round(float(tp2 if tp2 is not None else ote["target"]), decimals)
    tp1 = round(entry + (tp2 - entry) * 0.5, decimals)
    risk_cfg = (config.get("risk_settings") or {}) if isinstance(config, dict) else {}
    confidence = int(_f(risk_cfg.get("pre_arm_confidence"), 70))
    # Distance to activation in the symbol's points (card line "N pts to
    # activation" used to read 0 because this field was never set).
    try:
        distance_points = abs(price_to_points(cp - ote["entry"], symbol=symbol))
    except Exception:  # noqa: BLE001 - display-only field
        distance_points = 0.0
    # BUILD 31 R2 (2026-08-24, operator order "name every path / show who
    # decided"): pre-arm takes NO 5-agent vote — the card must say so
    # explicitly and publish the gates that actually decided, so the
    # operator can audit WHY the order was armed.
    leg_size = _f((leg or {}).get("leg_size"), 0.0)
    leg_atr = round(leg_size / float(atr), 2) if float(atr) > 0 and leg_size > 0 else None
    decision: Dict[str, Any] = {
        "symbol": symbol,
        "decision": direction,
        "confidence": confidence,
        "current_price": round(cp, decimals),
        "armed_at": ARMED_AT,
        # BUILD 31 R3: the OTE arm is PATH 6 — the two-agent admission
        # with macro/gemini confirmation, aimed at the projected OTE.
        "execution_path_id": PATH_6,
        "execution_path_name": "PATH 6 — TWO-AGENT CONFIRMED OTE (PRE-ARM)",
        "execution_path": PATH_LABEL,
        "entry_mode": ENTRY_MODE,
        "confirm_source": (vote or {}).get("confirm_source"),
        "confirm_confidence": (vote or {}).get("confirm_confidence"),
        "trading_mode": config.get("trading_mode", "demo"),
        # The two-agent book + confirmation that authorized this arm —
        # travels with the trade for every card + the weekly review.
        "vote_at_arm": dict(vote or {}),
        "pre_arm_info": {
            "smc_trend": str(smc_trend or ""),
            "timeframe": str(cfg.get("timeframe", "15m")),
            "impulse_leg_atr": leg_atr,
            "entry_pct": float(cfg.get("entry_pct", 0.70)),
            "ote_zone": [round(ote["zone_low"], decimals),
                         round(ote["zone_high"], decimals)],
            "atr": round(float(atr), decimals),
        },
        "reasons": [
            f"PRE-ARM OTE: armed at {pct}% retracement of a "
            f"confirmed impulse leg (path {PATH_LABEL}); fills on touch, "
            f"runs to TP/stop/thesis like any other trade."
        ],
        "signal": {
            "symbol": symbol,
            "type": direction,
            "entry_kind": "LIMIT",
            "order_type": "BUY_LIMIT" if direction == "BUY" else "SELL_LIMIT",
            "entry": {
                "price": entry,
                "low": round(ote["zone_low"], decimals),
                "high": round(ote["zone_high"], decimals),
                "kind": "LIMIT",
                "current_price": round(cp, decimals),
                "distance_points": round(distance_points, 1),
            },
            "stop_loss": stop,
            "tp1": tp1,
            "tp2": tp2,
            "rr_ratio": round(float(rr), 2),
        },
    }
    if float(tp2) != round(float(ote["target"]), decimals):
        decision["reasons"].append(
            f"Objective extended to the {pct}% minimum R:R "
            f"(leg peak alone was thin); tp2 is the leg extension."
        )
    return decision
