"""BUILD 23 (2026-08-21): Gemini per-model quota state across processes.

The old v1 state (one global daily latch, UTC-day scoped) froze the WHOLE
service when ONE model's daily quota died, kept the block up to 8 extra
morning hours (Pacific midnight vs UTC midnight), and forgot it up to 7
hours early. v2 tracks exhaustion PER MODEL with a Pacific-midnight expiry,
fails over to the next live candidate, and persists everything so every new
5-minute analysis process re-applies the same truth.
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

import pytest

import services.llm_review as llm


def _cfg(tmp_path) -> dict:
    return {"llm_review": {"quota_state_path": str(tmp_path / "gemini_quota_state.json")}}


@pytest.fixture(autouse=True)
def _clean(monkeypatch):
    llm.GeminiReviewService.reset_quota_state()
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    yield
    llm.GeminiReviewService.reset_quota_state()


def _svc(tmp_path):
    return llm.GeminiReviewService(_cfg(tmp_path))


# ── Pacific midnight expiry (the 8-hour false block fix) ───────────────────
def test_next_pacific_midnight_summer():
    # 2026-08-21 11:00 UTC = 04:00 PDT -> next reset 2026-08-22 07:00 UTC
    now = datetime(2026, 8, 21, 11, 0, tzinfo=timezone.utc).timestamp()
    assert llm.GeminiReviewService._next_pacific_midnight(now) == "2026-08-22T07:00:00Z"


def test_next_pacific_midnight_early_utc():
    # 2026-08-21 06:00 UTC = 23:00 PDT (previous day) -> reset in ONE hour
    now = datetime(2026, 8, 21, 6, 0, tzinfo=timezone.utc).timestamp()
    assert llm.GeminiReviewService._next_pacific_midnight(now) == "2026-08-21T07:00:00Z"


# ── v2 persistence round-trips ──────────────────────────────────────────────
def test_exhausted_models_survive_new_instance(tmp_path):
    svc = _svc(tmp_path)
    llm.GeminiReviewService._per_model_exhausted = {"gemini-flash-latest"}
    llm.GeminiReviewService._quota_expiry_utc = svc._next_pacific_midnight()
    svc._persist_state()
    llm.GeminiReviewService.reset_quota_state()
    svc2 = _svc(tmp_path)
    assert "gemini-flash-latest" in llm.GeminiReviewService._per_model_exhausted
    assert llm.GeminiReviewService._quota_expiry_utc.endswith("Z")
    # one dead model must NOT stop the service: a live candidate is picked
    live = svc2._select_model()
    assert live is not None
    assert live != "gemini-flash-latest"


def test_expired_quota_state_is_ignored(tmp_path):
    marker = tmp_path / "gemini_quota_state.json"
    expired = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat().replace("+00:00", "Z")
    marker.write_text(json.dumps({
        "version": 2,
        "quota_expiry_utc": expired,
        "exhausted_models": ["gemini-flash-latest"],
        "unavailable_models": [],
        "resolved_model": "gemini-flash-latest",
    }), encoding="utf-8")
    _svc(tmp_path)
    assert llm.GeminiReviewService._per_model_exhausted == set()


def test_all_models_exhausted_latches_globally(tmp_path):
    svc = _svc(tmp_path)
    llm.GeminiReviewService._per_model_exhausted = set(svc._candidate_models())
    llm.GeminiReviewService._quota_expiry_utc = svc._next_pacific_midnight()
    llm.GeminiReviewService._daily_quota_exhausted = True
    llm.GeminiReviewService._daily_quota_reason = "all candidate models exhausted"
    svc._persist_state()
    llm.GeminiReviewService.reset_quota_state()
    svc2 = _svc(tmp_path)
    # every candidate is exhausted -> the call short-circuits without HTTP
    out = svc2._generate_json("prompt", kind="test")
    assert out.get("available") is False
    assert "exhausted" in str(out.get("reason") or "")


def test_v1_state_file_is_ignored(tmp_path):
    marker = tmp_path / "gemini_quota_state.json"
    marker.write_text(json.dumps({
        "date": datetime.now(timezone.utc).date().isoformat(),
        "daily_quota_exhausted": True,
        "reason": "old global latch",
    }), encoding="utf-8")
    svc = _svc(tmp_path)
    assert llm.GeminiReviewService._daily_quota_exhausted is False
    assert llm.GeminiReviewService._per_model_exhausted == set()


def test_unavailable_and_resolved_survive(tmp_path):
    svc = _svc(tmp_path)
    llm.GeminiReviewService._per_model_unavailable = {"gemini-2.5-flash-lite", "gemini-2.5-flash"}
    llm.GeminiReviewService._resolved_model = "gemini-flash-latest"
    svc._persist_state()
    llm.GeminiReviewService.reset_quota_state()
    svc2 = _svc(tmp_path)
    assert llm.GeminiReviewService._per_model_unavailable == {"gemini-2.5-flash-lite", "gemini-2.5-flash"}
    assert llm.GeminiReviewService._resolved_model == "gemini-flash-latest"
    # 404'd models are skipped when selecting a live model
    assert svc2._select_model() == "gemini-flash-latest"


def test_auth_rejection_still_persists(tmp_path):
    svc = _svc(tmp_path)
    llm.GeminiReviewService._auth_rejected = True
    llm.GeminiReviewService._auth_rejected_reason = "API key rejected (HTTP 401)"
    svc._persist_state()
    llm.GeminiReviewService.reset_quota_state()
    _svc(tmp_path)
    assert llm.GeminiReviewService._auth_rejected is True
    assert "401" in llm.GeminiReviewService._auth_rejected_reason


def test_corrupt_marker_is_a_noop(tmp_path):
    marker = tmp_path / "gemini_quota_state.json"
    marker.write_text("{not json", encoding="utf-8")
    _svc(tmp_path)
    assert llm.GeminiReviewService._per_model_exhausted == set()


def test_default_path_stays_inside_storage(tmp_path, monkeypatch):
    svc = llm.GeminiReviewService({"llm_review": {}})
    p = svc._quota_state_path()
    assert "storage" in p.parts


# ── live failover inside one call ───────────────────────────────────────────
class _Resp:
    def __init__(self, status, body, headers=None):
        self.status_code = status
        self.text = body
        self.headers = headers or {}

    def json(self):
        return json.loads(self.text)


def test_rpd_on_one_model_fails_over_to_the_next(tmp_path, monkeypatch):
    svc = _svc(tmp_path)
    svc.fallback_models = ["gemini-flash-latest", "gemini-flash"]
    svc.model = "gemini-flash-latest"
    svc._attempted_models = [svc.model]
    rpd = json.dumps({
        "error": {"code": 429, "status": "RESOURCE_EXHAUSTED",
                  "details": [{"@type": "type.googleapis.com/google.rpc.QuotaFailure",
                               "violations": [{"quotaId": "GenerateRequestsPerDayPerProjectPerModel-FreeTier"}]}]}
    })
    ok = json.dumps({"candidates": [{"content": {"parts": [{"text": json.dumps(
        {"verdict": "BUY", "confidence": 80})}]}}]})

    def fake_post(url, params=None, json=None, timeout=None):
        model = url.split("/")[-1].split(":")[0]
        return _Resp(429, rpd) if model == "gemini-flash-latest" else _Resp(200, ok)

    monkeypatch.setattr(svc.session, "post", fake_post)
    out = svc._generate_json("prompt", kind="test")
    assert out.get("available") is True
    assert out.get("verdict") == "BUY"
    assert "gemini-flash-latest" in llm.GeminiReviewService._per_model_exhausted
    assert llm.GeminiReviewService._resolved_model == "gemini-flash"
    # persisted: the marker records the exhausted model + expiry
    marker = json.loads((tmp_path / "gemini_quota_state.json").read_text(encoding="utf-8"))
    assert marker["version"] == 2
    assert "gemini-flash-latest" in marker["exhausted_models"]
    assert marker["quota_expiry_utc"].endswith("Z")


def test_rpd_on_every_model_stops_the_service(tmp_path, monkeypatch):
    svc = _svc(tmp_path)
    svc.fallback_models = ["gemini-flash-latest", "gemini-flash"]
    svc.model = "gemini-flash-latest"
    svc._attempted_models = [svc.model]
    rpd = json.dumps({
        "error": {"code": 429, "status": "RESOURCE_EXHAUSTED",
                  "details": [{"@type": "type.googleapis.com/google.rpc.QuotaFailure",
                               "violations": [{"quotaId": "GenerateRequestsPerDayPerProjectPerModel-FreeTier"}]}]}
    })
    monkeypatch.setattr(svc.session, "post",
                        lambda *a, **k: _Resp(429, rpd))
    out = svc._generate_json("prompt", kind="test")
    assert out.get("available") is False
    assert llm.GeminiReviewService._daily_quota_exhausted is True
    assert "all candidate models exhausted" in llm.GeminiReviewService._daily_quota_reason
    # and the next call in the same process short-circuits
    out2 = svc._generate_json("prompt", kind="test")
    assert out2.get("available") is False


def test_404_fails_over_and_is_remembered(tmp_path, monkeypatch):
    svc = _svc(tmp_path)
    svc.fallback_models = ["gemini-2.5-flash", "gemini-flash-latest"]
    svc.model = "gemini-2.5-flash"
    svc._attempted_models = [svc.model]
    ok = json.dumps({"candidates": [{"content": {"parts": [{"text": json.dumps(
        {"verdict": "BUY", "confidence": 80})}]}}]})

    def fake_post(url, params=None, json=None, timeout=None):
        model = url.split("/")[-1].split(":")[0]
        return _Resp(404, "{}") if model == "gemini-2.5-flash" else _Resp(200, ok)

    monkeypatch.setattr(svc.session, "post", fake_post)
    out = svc._generate_json("prompt", kind="test")
    assert out.get("available") is True
    assert "gemini-2.5-flash" in llm.GeminiReviewService._per_model_unavailable
    assert llm.GeminiReviewService._resolved_model == "gemini-flash-latest"


# ── BUILD 25: the operator's explicit primary wins over memory ─────────────
def test_explicit_config_model_wins_over_resolved_memory(tmp_path):
    llm.GeminiReviewService._resolved_model = "gemini-flash-latest"
    cfg = _cfg(tmp_path)
    cfg["llm_review"]["model"] = "gemini-3.5-flash-lite"
    svc = llm.GeminiReviewService(cfg)
    assert svc.model == "gemini-3.5-flash-lite"
    chain = svc._candidate_models()
    assert chain[0] == "gemini-3.5-flash-lite"
    assert "gemini-flash-latest" in chain


def test_explicit_env_model_wins_over_resolved_memory(tmp_path, monkeypatch):
    llm.GeminiReviewService._resolved_model = "gemini-flash-latest"
    monkeypatch.setenv("GEMINI_MODEL", "gemini-3.1-flash-lite")
    svc = llm.GeminiReviewService(_cfg(tmp_path))
    assert svc.model == "gemini-3.1-flash-lite"


def test_resolved_memory_still_applies_without_explicit_model(tmp_path):
    llm.GeminiReviewService._resolved_model = "gemini-flash-latest"
    svc = llm.GeminiReviewService(_cfg(tmp_path))  # no model in cfg
    assert svc.model == "gemini-flash-latest"
