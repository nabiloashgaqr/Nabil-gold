"""BUILD 20 (2026-08-20): the REAL WTI auction calibration.

Operator order: build the oil curve now (option 1) instead of leaving the
auction on the linear fallback. These tests pin:
  * the build script's path derivation == the agent's own derivation,
  * production config demands the WTI curve (calibration_required=true),
  * the flag flip / revert helpers work on a config copy,
  * a written curve is loaded and a corrupt one is refused.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from utils.helpers import load_config
from utils.instruments import config_for_instrument

import scripts.build_oil_auction_calibration as boc


# ── path derivation parity ──────────────────────────────────────────────────
def test_oil_paths_match_agent_derivation():
    from agents.auction_flow_agent import AuctionFlowAgent
    base = load_config()
    wti_cfg, store_path, cal_path = boc.oil_paths(base)
    agent = AuctionFlowAgent(config_for_instrument(base, {"symbol": "WTI/USD"}))
    # the agent resolves the store path but keeps the calibration path raw;
    # compare resolved forms so the parity holds either way
    assert Path(str(store_path)).resolve() == Path(str(agent.store.path)).resolve()
    assert Path(str(cal_path)).resolve() == Path(str(agent.calibration_path)).resolve()
    assert "wtiusd" in str(store_path)
    assert "wtiusd" in str(cal_path)
    # gold paths stay untouched
    assert "auction_flow.sqlite3" != str(store_path)
    assert "auction_flow_v1.json" != str(cal_path)


# ── production config flag ──────────────────────────────────────────────────
def test_production_config_keeps_wti_calibration_off_by_default():
    # BUILD 20.1: the flag locks true ONLY after a HEALTHY curve (span>=2pp).
    cfg = load_config()
    wti = [i for i in cfg.get("instruments") or [] if "WTI" in str(i.get("symbol") or "")]
    assert wti, "WTI/USD instrument entry missing"
    assert wti[0].get("auction_flow", {}).get("calibration_required") is False


def test_config_for_instrument_merges_the_flag():
    base = load_config()
    wti_cfg = config_for_instrument(base, {"symbol": "WTI/USD"})
    assert wti_cfg.get("auction_flow", {}).get("calibration_required") is False


# ── flag flip / revert on a config copy ─────────────────────────────────────
def _config_copy(tmp_path):
    cfg = json.loads((Path(__file__).resolve().parents[1] / "config.json").read_text(encoding="utf-8"))
    out = tmp_path / "config.json"
    out.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def test_set_config_flag_true_and_revert(tmp_path):
    cfg_path = _config_copy(tmp_path)
    assert boc.set_config_flag(cfg_path, True) is True
    data = json.loads(cfg_path.read_text(encoding="utf-8"))
    wti = [i for i in data["instruments"] if "WTI" in str(i.get("symbol") or "")]
    assert wti[0]["auction_flow"]["calibration_required"] is True
    assert boc.set_config_flag(cfg_path, False) is True
    data = json.loads(cfg_path.read_text(encoding="utf-8"))
    wti = [i for i in data["instruments"] if "WTI" in str(i.get("symbol") or "")]
    assert wti[0]["auction_flow"]["calibration_required"] is False


def test_set_config_flag_fails_without_wti_entry(tmp_path):
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps({"instruments": [{"symbol": "XAU/USD"}]}), encoding="utf-8")
    with pytest.raises(RuntimeError):
        boc.set_config_flag(cfg_path, True)


# ── the agent loads a valid curve and refuses a corrupt one ─────────────────
def _write_curve(path: Path, payload: dict):
    raw = dict(payload)
    canonical = json.dumps(raw, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    raw["checksum"] = hashlib.sha256(canonical).hexdigest()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")


def _minimal_curve() -> dict:
    return {
        "version": "auction_flow_v1",
        "generated_at": "2026-08-20T00:00:00+00:00",
        "source": "test",
        "symbol": "WTI.s",
        "sample_count": 300,
        "correct_count": 180,
        "base_accuracy": 60.0,
        "outcome": {},
        "logistic": {"a": -0.2, "b": 2.5},
        "curve_health": {"span_points": 30.0, "tercile_lift_points": 12.0},
        "horizon_sweep": [],
        "edge_definition": "extension_mean",
        "edge_definition_sweep": [],
    }


def test_agent_loads_valid_wti_curve(monkeypatch, tmp_path):
    from agents.auction_flow_agent import AuctionFlowAgent
    base = load_config()
    wti_cfg = config_for_instrument(base, {"symbol": "WTI/USD"})
    # the agent appends '_wtiusd' to the configured stem for non-gold symbols
    _write_curve(tmp_path / "curve_wtiusd.json", _minimal_curve())
    wti_cfg["auction_flow"]["calibration_path"] = str(tmp_path / "curve.json")
    agent = AuctionFlowAgent(wti_cfg)
    # BUILD 20.1: required stays off until a healthy build locks it, but a
    # VALID curve file is still loaded and used when present.
    assert agent.calibration is not None
    assert agent.calibration_required is False


def test_agent_refuses_corrupt_curve(monkeypatch, tmp_path):
    from agents.auction_flow_agent import AuctionFlowAgent
    base = load_config()
    wti_cfg = config_for_instrument(base, {"symbol": "WTI/USD"})
    bad = tmp_path / "bad_wtiusd.json"
    bad.write_text(json.dumps({**_minimal_curve(), "checksum": "0" * 64}), encoding="utf-8")
    wti_cfg["auction_flow"]["calibration_path"] = str(tmp_path / "bad.json")
    agent = AuctionFlowAgent(wti_cfg)
    assert agent.calibration is None  # checksum guard fires


# ── BUILD 20.1: curve-health gate (span < 2pp must never lock the flag) ─────
def _weak_payload() -> dict:
    p = _minimal_curve()
    p["curve_health"] = {"span_points": 0.0, "tercile_lift_points": -0.69}
    return p


def _healthy_payload() -> dict:
    p = _minimal_curve()
    p["curve_health"] = {"span_points": 5.0, "tercile_lift_points": 6.0}
    return p


def test_curve_accepted_threshold():
    assert boc._curve_accepted(_healthy_payload()) is True
    assert boc._curve_accepted(_weak_payload()) is False
    assert boc._curve_accepted({}) is False
    assert boc._curve_accepted({"curve_health": {"span_points": 1.99}}) is False
    assert boc._curve_accepted({"curve_health": {"span_points": 2.0}}) is True


def test_finalize_weak_curve_keeps_flag_off_and_moves_file(tmp_path):
    cfg_path = _config_copy(tmp_path)
    cal_path = tmp_path / "auction_flow_v1_wtiusd.json"
    cal_path.write_text("{}", encoding="utf-8")
    status = boc._finalize_build(_weak_payload(), cfg_path, cal_path, {})
    assert status == 2
    data = json.loads(cfg_path.read_text(encoding="utf-8"))
    wti = [i for i in data["instruments"] if "WTI" in str(i.get("symbol") or "")]
    assert wti[0]["auction_flow"]["calibration_required"] is False
    assert not cal_path.exists()  # moved aside -> linear fallback can engage
    moved = list(tmp_path.glob("auction_flow_v1_wtiusd.weak*.json"))
    assert len(moved) == 1


def test_finalize_healthy_curve_locks_flag_and_persists_overrides(tmp_path):
    cfg_path = _config_copy(tmp_path)
    cal_path = tmp_path / "auction_flow_v1_wtiusd.json"
    overrides = {"edge_definition": "value_only",
                 "calibration_horizon_15m_bars": 16,
                 "calibration_barrier_atr": 1.0}
    status = boc._finalize_build(_healthy_payload(), cfg_path, cal_path, overrides)
    assert status == 0
    data = json.loads(cfg_path.read_text(encoding="utf-8"))
    wti = [i for i in data["instruments"] if "WTI" in str(i.get("symbol") or "")]
    auc = wti[0]["auction_flow"]
    assert auc["calibration_required"] is True
    assert auc["edge_definition"] == "value_only"
    assert auc["calibration_horizon_15m_bars"] == 16
    assert auc["calibration_barrier_atr"] == 1.0


def test_apply_overrides_merges_into_auction_flow():
    from utils.helpers import load_config
    base = load_config()
    wti_cfg = config_for_instrument(base, {"symbol": "WTI/USD"})
    overrides = boc._apply_overrides(wti_cfg, "value_only", 16, 1.0)
    auc = wti_cfg["auction_flow"]
    assert overrides == {"edge_definition": "value_only",
                         "calibration_horizon_15m_bars": 16,
                         "calibration_barrier_atr": 1.0}
    assert auc["edge_definition"] == "value_only"
    assert boc._apply_overrides(wti_cfg, None, None, None) == {}


def test_revert_moves_curve_aside(tmp_path):
    cfg_path = _config_copy(tmp_path)
    cal_path = tmp_path / "auction_flow_v1_wtiusd.json"
    cal_path.write_text("{}", encoding="utf-8")
    # simulate the revert branch body: flag off + file aside
    assert boc.set_config_flag(cfg_path, False) is True
    boc._move_curve_aside(cal_path, "reverted")
    assert not cal_path.exists()
    assert list(tmp_path.glob("auction_flow_v1_wtiusd.reverted*.json"))
    data = json.loads(cfg_path.read_text(encoding="utf-8"))
    wti = [i for i in data["instruments"] if "WTI" in str(i.get("symbol") or "")]
    assert wti[0]["auction_flow"]["calibration_required"] is False


# ── BUILD 20.2: the weak curve must never poison the linear fallback ────────
def _write_curve_span(path: Path, span: float):
    p = _minimal_curve()
    if span < 2.0:
        # span comes from the logistic params: b=0 gives span 0 -> invalid
        p["logistic"] = {"a": -0.2, "b": 0.0}
    p["curve_health"] = {"span_points": span, "tercile_lift_points": 0.0}
    _write_curve(path, p)


def test_agent_bypasses_weak_curve_when_optional(tmp_path):
    from agents.auction_flow_agent import AuctionFlowAgent
    base = load_config()
    wti_cfg = config_for_instrument(base, {"symbol": "WTI/USD"})
    _write_curve_span(tmp_path / "c_wtiusd.json", 0.0)  # span 0 -> invalid
    wti_cfg["auction_flow"]["calibration_path"] = str(tmp_path / "c.json")
    agent = AuctionFlowAgent(wti_cfg)
    assert agent.calibration is not None
    assert agent.calibration_required is False
    curve = agent._confidence_curve(0.5)
    assert curve.get("valid") is True
    assert curve.get("mode") == "linear_edge_fallback"
    assert curve.get("weak_curve_bypassed") is True
    # linear fallback: 50 + 45*0.5 = 72.5
    assert abs(curve["score"] - 72.5) < 0.01


def test_agent_still_refuses_weak_curve_when_required(tmp_path):
    from agents.auction_flow_agent import AuctionFlowAgent
    base = load_config()
    wti_cfg = config_for_instrument(base, {"symbol": "WTI/USD"})
    _write_curve_span(tmp_path / "c_wtiusd.json", 0.0)
    wti_cfg["auction_flow"]["calibration_path"] = str(tmp_path / "c.json")
    wti_cfg["auction_flow"]["calibration_required"] = True
    agent = AuctionFlowAgent(wti_cfg)
    assert agent.calibration_required is True
    curve = agent._confidence_curve(0.5)
    assert curve.get("valid") is False  # required -> weak curve is refused


def test_agent_uses_healthy_curve_normally(tmp_path):
    from agents.auction_flow_agent import AuctionFlowAgent
    base = load_config()
    wti_cfg = config_for_instrument(base, {"symbol": "WTI/USD"})
    _write_curve_span(tmp_path / "c_wtiusd.json", 20.0)
    wti_cfg["auction_flow"]["calibration_path"] = str(tmp_path / "c.json")
    agent = AuctionFlowAgent(wti_cfg)
    curve = agent._confidence_curve(0.5)
    assert curve.get("valid") is True
    assert not curve.get("weak_curve_bypassed")
    assert curve.get("mode") == "normalized_logistic_evidence"


def test_suggested_retry_parameters():
    assert boc.SUGGESTED_RETRY["edge_definition"] == "value_only"
    assert boc.SUGGESTED_RETRY["calibration_horizon_15m_bars"] == 16
    assert boc.SUGGESTED_RETRY["calibration_barrier_atr"] == 1.0
