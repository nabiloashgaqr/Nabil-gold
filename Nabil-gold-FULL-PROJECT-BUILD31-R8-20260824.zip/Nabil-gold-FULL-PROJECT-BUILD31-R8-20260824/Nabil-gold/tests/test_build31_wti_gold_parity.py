"""BUILD 31 R3 (2026-08-24, operator order "0.4 حسابيا للكل"): oil carries
the SAME law as gold at a FIXED SCALE FACTOR k = 0.4 — every absolute gold
number x0.4:

    stop  = 200x0.4 / 70x0.4 / 400x0.4 = 80/28/160  -> band [108, 160]
    TP1   = 0.8R of the stop  (84.8 pts at the 108-pt floor)
    BE    = stop moves to entry at 150x0.4 = 60 pts
    trail = 150x0.4 / 40x0.4 = 60 / 16 from breakeven
    pool band = 200x0.4 = 80 pts · post-TP2 = 250x0.4 = 100 pts / 2.5h
    second-entry family = 150x0.4 = 60 each · planner geometry = x0.4

R-based rules (0.8R, 2x, 0.5R, 1.5R), percent thresholds and ATR
multipliers are scale-invariant (unchanged). The old 0.3-scale profile and
the 1:1 (R2) interpretation are both superseded. Gold is UNTOUCHED.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.helpers import load_config
from utils.instruments import config_for_instrument
import utils.trading_rules as tr

K = 0.4


def _wti():
    return config_for_instrument(load_config(), {"symbol": "WTI/USD"})


def _gold():
    return config_for_instrument(load_config(), {"symbol": "XAU/USD"})


def test_wti_stop_rule_is_gold_times_04():
    ws, gs = tr.stop_rule(_wti()), tr.stop_rule(_gold())
    assert ws["min_liquidity_points"] == 200 * K == 80.0
    assert ws["safety_buffer_points"] == 70 * K == 28.0
    assert ws["max_stop_points"] == 400 * K == 160.0
    assert (gs["min_liquidity_points"], gs["safety_buffer_points"],
            gs["max_stop_points"]) == (200.0, 70.0, 400.0)


def test_wti_stop_band_is_108_to_160_points():
    cfg = _wti()
    # No eligible liquidity -> the cap ships directly.
    assert tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00, liquidity_map={}, cfg=cfg,
        symbol="WTI/USD") == 160
    # A 90-pt level -> +28 buffer = 118 (just above the floor).
    lvl = tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00,
        liquidity_map={"sell_side": [83.10]}, cfg=cfg, symbol="WTI/USD")
    assert abs(lvl - 118) < 0.01, f"90-pt level + 28 buffer = 118, got {lvl}"
    # Level closer than 80 is swept noise -> ignored, cap ships.
    lvl2 = tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00,
        liquidity_map={"sell_side": [83.40]}, cfg=cfg, symbol="WTI/USD")
    assert lvl2 == 160  # cap is exact
    # Level at 120 -> 148 (inside the band).
    lvl3 = tr.stop_from_liquidity_points(
        direction="BUY", entry=84.00,
        liquidity_map={"sell_side": [84.00 - 1.20, 84.00 - 0.50]},
        cfg=cfg, symbol="WTI/USD")
    assert abs(lvl3 - 148) < 0.01


def test_wti_tp1_is_the_08r_rung_and_84p8_at_the_floor():
    cfg = _wti()
    ratios = tr.target_ratios(cfg)
    assert ratios["min_tp1_rr"] == 0.8
    assert ratios["tp2_multiple"] == 2.0
    assert ratios["max_beyond_points"] == 200 * K == 80.0
    # No pools: TP1 = 0.8R. Stop at the 108-pt floor ($1.08) ->
    # TP1 = 0.8 x $1.08 = $0.864 (84.8 pts), TP2 = 2x.
    tp1, tp2, _ = tr.targets_law(
        direction="SELL", entry=85.36, risk_price=1.08, levels=[],
        cfg=cfg, symbol="WTI/USD")
    assert abs(tp1 - 84.496) < 0.011, "TP1 must be the 0.8R rung (84.8 pts)"
    assert abs(tp2 - 83.632) < 0.011, "TP2 must be 2x TP1 distance"


def test_wti_target_caps_are_gone():
    """No BUILD 18 caps at any scale: a 0.8R rung on the floor stop is
    84.8 pts (216 x0.4) — caps would contradict the law. Gold parity =
    no caps; far pools may win inside the 80-pt (200x0.4) band."""
    cfg = _wti()
    tgt = (cfg.get("trading_rules") or {}).get("targets") or {}
    assert tgt.get("max_tp1_points", 0) == 0
    assert tgt.get("max_tp2_points", 0) == 0
    # A pool within the band still wins over the 2x rung:
    # risk 1.08 -> TP2 rung = 85.36 - 1.696 = 83.664; pool at 83.13
    # (50 pts beyond the rung, inside the 80-pt band) wins.
    tp1, tp2, used = tr.targets_law(
        direction="SELL", entry=85.36, risk_price=1.08,
        levels=[83.13], cfg=cfg, symbol="WTI/USD")
    assert used
    assert abs(tp2 - 83.13) < 1e-9  # the pool, not the 1.696 rung


def test_wti_trailing_and_breakeven_are_gold_times_04():
    cfg = _wti()
    t = tr.trailing_params(cfg)
    assert t["distance_points"] == 150 * K == 60.0
    assert t["step_points"] == 40 * K == 16.0
    assert t["early_breakeven_points"] == 150 * K == 60.0
    assert t["activation_at"] == "BREAKEVEN"
    assert cfg["trailing_stop"]["early_breakeven_points"] == 60
    assert cfg["risk_settings"]["min_sl_distance_points"] == 400 * K == 160


def test_wti_second_entry_family_and_planner_are_gold_times_04():
    """The whole distance family + planner geometry at x0.4 (gold: 150)."""
    cfg = _wti()
    gold = _gold()
    assert (cfg["signal_requirements"]["two_agent_entry"]
            ["cross_entry_distance_points"]) == 60
    assert (cfg["order_execution"]["fixed_risk"]
            ["scale_in_trigger_points"]) == 60
    from utils.instruments import DEFAULT_INSTRUMENTS
    assert DEFAULT_INSTRUMENTS["WTI/USD"]["duplicate_zone_points"] == 60
    assert DEFAULT_INSTRUMENTS["XAU/USD"]["duplicate_zone_points"] == 150
    pl_w, pl_g = cfg["session_planner"], gold["session_planner"]
    assert pl_w["standby_min_distance_points"] == 150 * K == 60
    assert pl_w["max_primary_zone_width_points"] == 450 * K == 180
    assert pl_w["min_entry_zone_width_points"] == 60 * K == 24
    assert pl_w["min_thesis_objective_points"] == 30 * K == 12


def test_wti_post_tp2_is_gold_times_04():
    cfg = _wti()
    p = (cfg.get("trading_rules") or {}).get("post_tp2") or {}
    assert p.get("min_distance_points") == 250 * K == 100
    assert p.get("window_hours") == 2.5  # time is not scaled


def test_gold_unchanged():
    cfg = _gold()
    s = tr.stop_rule(cfg)
    assert (s["min_liquidity_points"], s["safety_buffer_points"], s["max_stop_points"]) == (200, 70, 400)
    t = tr.trailing_params(cfg)
    assert (t["distance_points"], t["step_points"], t["early_breakeven_points"]) == (150, 40, 150)
