"""BUILD 28 (2026-08-22): card prices, report integrity, Gemini store,
learning report.

Live incidents pinned here:
  1. the XAU/USD activation card printed the WTI price (86.51) + a flat
     PnL +0.0 next to a live price - the PENDING branch of the tick manager
     sent its card before storing the row's own tick price, so the lookup
     fell back to the SHARED last price (whatever row ran last);
  2. the weekly report printed "22 closed" up top and "23 closed" in the
     Execution Quality section (different window, no demo filter);
  3. "Total trades: 51 · 22 closed · 1 open" left 28 rows unexplained;
  4. Expectancy used a wr-weighted formula that double-counts breakevens
     (printed 26.5, true per-trade average 34.2);
  5. literal <b> tags in two weekly sections (double-escaped headers);
  6. "Trades: 4 (…5)" - the daily total did not equal its breakdown;
  7. "PATH UNKNOWN_EXECUTION_PATH" raw sentinel + "1 trades";
  8. the head-to-head declared "System ahead by 850" against an analyst
     side with NO labels at all;
  9. the learning report said "No learning history yet" daily forever -
     history was in-memory only and empty runs messaged the operator;
  10. Gemini's stored per-symbol verdict (hourly status store) never
      appeared on signal/plan/trade cards.
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from services import execution_metrics as em
from services import learning_service as ls
from services.analyst_scoreboard import AnalystScoreboardService
from services.weekly_report import WeeklyReportService


# ── 1) tick manager: a card always carries ITS OWN symbol's price ─────────

def _tick_manager_for_card():
    """TickManager with a poisoned shared price: WTI 86.51, per-trade empty."""
    from scripts.run_tick_manager import TickManager

    tm = TickManager.__new__(TickManager)
    tm._last_price = 86.51          # poison: the WTI price
    tm._last_prices = {}
    tm._notification_row = None
    tm._placement_retry_at = {}
    tm._extremes = {}
    tm._partial_alerted = set()
    captured = {}

    class _Tg:
        def send_trade_events(self, trade, events, current_price, pnl, evaluation):
            captured["trade"] = trade
            captured["events"] = list(events)
            captured["price"] = current_price
            captured["pnl"] = pnl
            return True

        def send_message(self, text, **k):
            captured.setdefault("plain", []).append(text)
            return True

    tm.telegram = _Tg()
    tm.database = MagicMock()
    # isolate the lifecycle helpers we are not testing here
    tm._pending_stale = lambda row, tick: False
    tm._normalize_execution_stop = lambda *a: 0.0
    tm._send_execution_signal = lambda *a, **k: None
    return tm, captured


def test_pending_fill_card_uses_own_symbol_price():
    """The 2026-08-21 incident: gold activation card showed 86.51 (WTI)."""
    tm, captured = _tick_manager_for_card()
    tick = SimpleNamespace(bid=4612.40, ask=4612.70, time_msc=1)
    pos = SimpleNamespace(price_open=4612.54, ticket=1234)
    executor = SimpleNamespace(_position_by_magic=lambda magic: pos)
    row = {"id": "T1", "type": "BUY", "symbol": "XAU/USD",
           "status": "PENDING", "entry_price": 4612.50}

    tm._handle_row(row, tick, executor, None)

    assert captured["price"] == 4612.40, "card must carry the row's own tick"
    assert captured["price"] != 86.51
    assert captured["events"] == ["ORDER_FILLED"]
    # PnL must agree with the printed entry/current prices: BUY, price below
    # fill -> negative points (gold 1 pt = 0.10$), never a blind 0.0 drift.
    assert captured["pnl"] == pytest.approx(-1.4, abs=0.05)
    assert tm._last_prices["T1"] == 4612.40


def test_wti_pending_fill_card_uses_oil_price():
    """Mirror case: the shared poison is now the gold price."""
    tm, captured = _tick_manager_for_card()
    tm._last_price = 4612.00        # poison: the XAU price
    tick = SimpleNamespace(bid=86.50, ask=86.52, time_msc=1)
    pos = SimpleNamespace(price_open=86.55, ticket=77)
    executor = SimpleNamespace(_position_by_magic=lambda magic: pos)
    row = {"id": "T2", "type": "SELL", "symbol": "WTI/USD",
           "status": "PENDING", "entry_price": 86.55}

    tm._handle_row(row, tick, executor, None)

    # SELL executable price = ask
    assert captured["price"] == 86.52
    assert captured["price"] < 200  # never a gold-range number on oil


# ── 2) daily report: the total equals its own breakdown ───────────────────

def test_daily_trades_line_total_matches_breakdown(monkeypatch):
    import scripts.run_daily_report as rd

    today = [
        {"type": "BUY", "status": "TP2_HIT", "final_pnl": 651.0, "signal_snapshot": {}, "trading_mode": "mt5_demo"},
        {"type": "BUY", "status": "SL_HIT", "final_pnl": 51.0, "signal_snapshot": {}, "trading_mode": "mt5_demo"},
        {"type": "BUY", "status": "SL_HIT", "final_pnl": 8.0, "signal_snapshot": {}, "trading_mode": "mt5_demo"},
        {"type": "BUY", "status": "SL_HIT", "final_pnl": -30.0, "signal_snapshot": {}, "trading_mode": "mt5_demo"},
    ]
    open_t = [{"type": "BUY", "status": "OPEN", "entry_price": 4612.54,
               "current_price": 4608.31, "trading_mode": "mt5_demo"}]
    # the daily report derives its open list from the day's rows, so the
    # open trade rides in `today` too (same trick as the format tests).
    today = list(today) + open_t
    cap = {}

    class _Tg:
        def send_message(self, text, **k):
            cap["t"] = text
            return True

        def send_error_alert(self, *a, **k):
            return True

    db = MagicMock()
    db.get_today_trades.return_value = today
    db.get_trades_for_date.return_value = today
    db.get_open_trades.return_value = open_t
    db.get_recent_trades.return_value = today
    monkeypatch.setattr(rd, "TelegramService", lambda *a, **k: _Tg())
    monkeypatch.setattr(rd, "DatabaseService", lambda *a, **k: db)
    monkeypatch.setattr(rd, "_read_eod_section", lambda name: "")
    monkeypatch.setattr(rd, "_cleanup_eod_sections", lambda: None)
    rd.main()

    # incident shape: 4 closed + 1 open -> "Trades: 5", breakdown sums to 5
    assert "Trades: 5 (closed: ✅ 3 · ❌ 1 · ➖ 0 | open 1 · pending 0" in cap["t"]
    assert "Trades: 4 (" not in cap["t"]


# ── 3) weekly report: integrity of the printed numbers ────────────────────

def _weekly_cfg(**over) -> dict:
    base = {"weekly_report": {"enabled": True, "lookback_days": 7,
                              "min_trades_for_report": 0, "max_chars": 3500,
                              "send_telegram": False,
                              "storage_path": "storage/test_weekly_report.json",
                              "timezone": "UTC"}}
    base["weekly_report"].update(over)
    return base


def _trade(**kw) -> dict:
    base = {"id": kw.get("id", "t1"),
            "created_at": kw.get("created_at", "2026-06-20T10:00:00+00:00"),
            "status": kw.get("status", "TP2_HIT"),
            "final_pnl": kw.get("final_pnl", 5.0),
            "agents": kw.get("agents", ["technical"]),
            "session": kw.get("session", "London"),
            "type": "BUY"}
    base.update(kw)
    return base


def _report_text(trades, now) -> str:
    db = MagicMock()
    db.get_recent_trades.return_value = trades
    db.use_supabase = False
    db.client = None
    svc = WeeklyReportService(_weekly_cfg(), db, telegram=None)
    stats = svc.collect_stats(now=now)
    return svc._fallback_message(stats)


def test_weekly_total_breaks_out_cancelled():
    now = datetime(2026, 6, 21, 12, 0, tzinfo=timezone.utc)
    trades = [
        _trade(id="t1", status="TP2_HIT", final_pnl=8.0, created_at="2026-06-20T10:00:00+00:00"),
        _trade(id="t2", status="SL_HIT", final_pnl=-4.0, created_at="2026-06-19T11:00:00+00:00"),
        _trade(id="t3", status="OPEN", final_pnl=0.0, created_at="2026-06-21T09:00:00+00:00"),
        _trade(id="t4", status="CANCELLED", final_pnl=0.0, created_at="2026-06-18T09:00:00+00:00"),
    ]
    text = _report_text(trades, now)
    assert "Total trades: 4 (2 closed · 1 open · 1 cancelled/expired)" in text


def test_weekly_expectancy_is_net_over_closed():
    # 1 win +10, 1 loss -6, 1 BE +0.2 -> net 4.2 over 3 closed = 1.4.
    # The old wr-weighted formula printed -0.7 for this set.
    now = datetime(2026, 6, 21, 12, 0, tzinfo=timezone.utc)
    trades = [
        _trade(id="t1", status="TP2_HIT", final_pnl=10.0, created_at="2026-06-20T10:00:00+00:00"),
        _trade(id="t2", status="SL_HIT", final_pnl=-6.0, created_at="2026-06-19T11:00:00+00:00"),
        _trade(id="t3", status="BE_HIT", final_pnl=0.2, created_at="2026-06-18T12:00:00+00:00"),
    ]
    text = _report_text(trades, now)
    assert "Expectancy +1.4 pts" in text
    assert "Expectancy -0" not in text


def test_weekly_unmapped_path_label():
    # none of the rows carries an execution path -> "Unmapped", never the
    # raw sentinel.
    now = datetime(2026, 6, 21, 12, 0, tzinfo=timezone.utc)
    trades = [
        _trade(id="t1", status="TP2_HIT", final_pnl=8.0, created_at="2026-06-20T10:00:00+00:00"),
    ]
    text = _report_text(trades, now)
    assert "PATH Unmapped" in text
    assert "UNKNOWN_EXECUTION_PATH" not in text


def test_weekly_worst_day_detail_included():
    # six days; the worst day is NOT in the top-5 -> its W/L detail must be
    # appended (the section is called BEST/WORST DAYS).
    now = datetime(2026, 6, 21, 12, 0, tzinfo=timezone.utc)
    pnls = [100, 90, 80, 70, 60, -500]
    trades = []
    for i, pnl in enumerate(pnls):
        trades.append(_trade(id=f"d{i}", status="TP2_HIT" if pnl > 0 else "SL_HIT",
                             final_pnl=pnl,
                             created_at=f"2026-06-{15 + i:02d}T10:00:00+00:00"))
    text = _report_text(trades, now)
    assert "(worst)" in text
    assert "W 0 / L 1" in text


def test_weekly_headers_without_html_tags():
    """The weekly send path html-escapes the whole text: headers must be
    plain or they render as literal <b> in the message."""
    from services.execution_metrics import format_execution_metrics
    lines = format_execution_metrics({"decisions_recorded": 10, "signals_sent": 9,
                                      "signals_blocked": 1,
                                      "plan_to_order_rate_pct": 90.0,
                                      "median_tp1_rr": None, "weak_tp1_count": 0,
                                      "opposed_signal_rate_pct": 0.0,
                                      "closed_trades": 3,
                                      "breakeven_exit_rate_pct": 0.0,
                                      "median_entry_slippage_points": None,
                                      "blocks_by_stage": {}})
    assert all("<b>" not in l for l in lines)
    assert lines[0] == "📐 Execution Quality"


# ── 4) execution metrics: same window + demo filter as the report body ────

def test_metrics_respect_since_and_demo_filter():
    db = MagicMock()
    db.get_recent_decision_audits.return_value = []
    db.get_recent_trades.return_value = [
        {"id": "d1", "status": "TP2_HIT", "trading_mode": "mt5_demo",
         "closed_at": "2026-08-20T10:00:00+00:00"},
        {"id": "d2", "status": "SL_HIT", "trading_mode": "mt5_demo",
         "closed_at": "2026-08-13T10:00:00+00:00"},  # before since
        {"id": "p1", "status": "TP2_HIT", "trading_mode": "paper",
         "closed_at": "2026-08-20T11:00:00+00:00"},  # not demo
    ]
    m = em.build_execution_metrics(
        db, since="2026-08-14T00:00:00+00:00", demo_only=True)
    assert m["closed_trades"] == 1  # only d1
    m_all = em.build_execution_metrics(
        db, since="2026-08-14T00:00:00+00:00")  # no demo filter
    assert m_all["closed_trades"] == 2  # d1 + p1


# ── 5) head-to-head: no labels is not a verdict ───────────────────────────

def test_head_to_head_no_labels_not_a_verdict():
    svc = AnalystScoreboardService({"symbol": "XAU/USD"})
    lines = svc.build_report_lines({
        "symbol": "XAU/USD", "analyst_labeled": False,
        "analyst_points": 0.0, "analyst_traded": False,
        "system_points": 850.0, "system_traded": True,
        "gap_points": 850.0, "verdict": "SYSTEM_AHEAD",
    })
    text = "\n".join(lines)
    assert "no analyst labels" in text
    assert "ahead" not in text
    # legacy boards without the flag keep the old rendering
    lines2 = svc.build_report_lines({
        "symbol": "XAU/USD", "analyst_points": 100.0,
        "system_points": 200.0, "gap_points": 100.0,
        "verdict": "SYSTEM_AHEAD", "system_traded": True,
    })
    assert any("System ahead" in l for l in lines2)


def test_score_day_flags_missing_labels():
    svc = AnalystScoreboardService({"symbol": "XAU/USD"})
    board = svc.score_day(labels=[], trades=[], market_high=4620.0,
                          market_low=4600.0, symbol="XAU/USD")
    assert board["analyst_labeled"] is False


# ── 6) learning: persistent history + silent empty runs ───────────────────

def _mk_report(date="2026-08-21T23:00:00+00:00") -> ls.LearningReport:
    rec = ls.AgentPerformanceRecord(
        agent_name="technical", win_rate=62.0, trend="IMPROVING",
        consecutive_wins=2, current_weight=0.2, adjusted_weight=0.25)
    return ls.LearningReport(
        report_date=date, agents_performance={"technical": rec},
        adjusted_weights={}, total_trades_analyzed=5, overall_win_rate=60.0,
        recommendations=["keep watching"], previous_weights={},
        changes_summary="ok", top_performers=["technical"])


def test_learning_history_persists_across_runs(tmp_path):
    hp = tmp_path / "learning_history.json"
    cfg = {"learning": {"history_path": str(hp)}}
    svc = ls.LearningService(None, cfg)
    assert svc.get_learning_summary() == "📊 No learning history yet"
    svc.learning_history.append(_mk_report())
    svc._save_history()

    svc2 = ls.LearningService(None, cfg)  # fresh process
    assert len(svc2.learning_history) == 1
    summary = svc2.get_learning_summary()
    assert "No learning history" not in summary
    assert "60.0%" in summary
    assert "IMPROVING" in summary or "technical" in summary


def test_learning_corrupt_history_fail_open(tmp_path):
    hp = tmp_path / "learning_history.json"
    hp.write_text("{not json", encoding="utf-8")
    svc = ls.LearningService(None, {"learning": {"history_path": str(hp)}})
    assert svc.learning_history == []
    assert svc.get_learning_summary() == "📊 No learning history yet"


def test_learning_empty_run_sends_nothing(monkeypatch):
    import scripts.run_learning as rl

    sent = []

    class _Tg:
        def send_message(self, t, *a, **k):
            sent.append(t)
            return True

        def send_error_alert(self, t):
            sent.append(t)
            return True

    class _Svc:
        current_weights = {}

        async def analyze_and_update_weights(self):
            return _mk_report()

        def get_learning_summary(self):
            return "📊 No learning history yet"

    monkeypatch.setattr(rl, "load_config", lambda: {"learning": {"enabled": True}})
    monkeypatch.setattr(rl, "DatabaseService", lambda *a, **k: None)
    monkeypatch.setattr(rl, "TelegramService", lambda *a, **k: _Tg())
    monkeypatch.setattr(rl, "get_learning_service", lambda *a, **k: _Svc())
    monkeypatch.delenv("EOD_QUIET", raising=False)

    assert rl.main() is None
    assert sent == [], "an empty learning run must not message the operator"


# ── 7) Gemini: the stored per-symbol verdict rides entry messages ─────────

def _tg_capture():
    from services.telegram_bot import TelegramService

    svc = TelegramService.__new__(TelegramService)
    sent = []
    svc.send_message = lambda text, **k: (sent.append(text), True)[1]
    svc.config = {}
    return svc, sent


def _write_gemini_store(path, symbol="XAU/USD", bias="BULLISH"):
    now = datetime.now(timezone.utc)
    path.write_text(json.dumps({
        symbol: {"verdict": {"bias": bias, "action": "HOLD",
                             "reason": "dxy softening"},
                "generated_at": (now - timedelta(hours=1)).isoformat()}
    }), encoding="utf-8")


def test_signal_shows_stored_gemini_when_no_live_review(tmp_path):
    store = tmp_path / "gem.json"
    _write_gemini_store(store)
    svc, sent = _tg_capture()
    svc.config = {"llm_review": {"status_cache_path": str(store)}}
    svc.send_signal({"symbol": "XAU/USD", "decision": "BUY",
                     "signal": {"entry": {}}, "ai": {}, "risk": {},
                     "dynamic_risk": {}, "quality": {}})
    assert sent, "signal not sent"
    assert "Gemini XAU/USD (stored)" in sent[0]
    assert "BULLISH" in sent[0]


def test_signal_no_stored_line_when_live_review_present(tmp_path):
    store = tmp_path / "gem.json"
    _write_gemini_store(store)
    svc, sent = _tg_capture()
    svc.config = {"llm_review": {"status_cache_path": str(store)}}
    svc.send_signal({"symbol": "XAU/USD", "decision": "BUY",
                     "signal": {"entry": {}}, "ai": {}, "risk": {},
                     "dynamic_risk": {}, "quality": {},
                     "gemini_macro_review": {"available": True,
                                             "macro_verdict": "BULLISH"}})
    assert "(stored)" not in sent[0]


def test_trade_card_shows_stored_gemini(tmp_path):
    store = tmp_path / "gem.json"
    _write_gemini_store(store)
    svc, sent = _tg_capture()
    svc.config = {"llm_review": {"status_cache_path": str(store)}}
    svc.send_trade_events(
        {"id": "T1", "type": "BUY", "symbol": "XAU/USD", "status": "OPEN",
         "entry_price": 4612.54, "tp1": 0, "tp2": 0},
        ["ORDER_FILLED"], 4612.40, -1.4,
        {"old_status": "PENDING", "new_status": "OPEN",
         "updates": {"entry_price": 4612.54}})
    assert sent
    assert "Gemini XAU/USD (stored)" in sent[0]


def test_no_store_no_gemini_line_no_crash(tmp_path):
    """A store path that does not exist (anywhere: dev tree, VPS with data,
    VPS without) -> no line, no crash."""
    svc, sent = _tg_capture()
    svc.config = {"llm_review": {"status_cache_path":
                                 str(tmp_path / "does_not_exist.json")}}
    svc.send_signal({"symbol": "XAU/USD", "decision": "BUY",
                     "signal": {"entry": {}}, "ai": {}, "risk": {},
                     "dynamic_risk": {}, "quality": {}})
    assert sent
    assert "(stored)" not in sent[0]


# ── 8) BUILD 28 R2: the 30-minute stored opinion store ────────────────────

def _store_cfg(tmp_path) -> dict:
    return {"llm_review": {"status_cache_path":
                           str(tmp_path / "gemini_status_cache.json")}}


def _write_store(tmp_path, symbol="XAU/USD", age_minutes=0.0,
                 verdict=("BULLISH", "BUY", "dxy soft"),
                 attempt_age_minutes=None):
    now = datetime.now(timezone.utc)
    gen = now - timedelta(minutes=age_minutes)
    att = (now - timedelta(minutes=attempt_age_minutes)
           if attempt_age_minutes is not None else gen)
    (tmp_path / "gemini_status_cache.json").write_text(json.dumps({
        symbol: {"verdict": {"bias": verdict[0], "action": verdict[1],
                             "reason": verdict[2], "model": "m"},
                 "generated_at": gen.isoformat(),
                 "last_attempt_at": att.isoformat()}}), encoding="utf-8")


class _FakeGemini:
    def __init__(self, available=True):
        self.enabled = True
        self.available = available
        self.model = "gemini-3.5-flash-lite"
        self.calls = []

    def analyze_market_context(self, payload):
        self.calls.append(payload)
        if not self.available:
            return {"available": False, "reason": "quota"}
        return {"available": True, "suppressed": False,
                "market_bias": "NEUTRAL", "action": "WAIT",
                "reason": "fresh read"}


def test_store_fresh_within_30min_no_call(tmp_path, monkeypatch):
    from services import gemini_opinion_store as gos
    from services import llm_review as lr
    _write_store(tmp_path, age_minutes=10)
    gem = _FakeGemini()
    monkeypatch.setattr(lr, "get_gemini_review_service", lambda cfg: gem)
    v, refreshed, age_h = gos.refresh_opinion(
        "XAU/USD", _store_cfg(tmp_path), now=datetime.now(timezone.utc))
    assert refreshed is False
    assert gem.calls == []
    assert v["bias"] == "BULLISH"
    assert age_h is not None and 0 <= age_h <= 0.5


def test_store_stale_after_30min_refreshes(tmp_path, monkeypatch):
    from services import gemini_opinion_store as gos
    from services import llm_review as lr
    _write_store(tmp_path, age_minutes=40)
    gem = _FakeGemini()
    monkeypatch.setattr(lr, "get_gemini_review_service", lambda cfg: gem)
    v, refreshed, age_h = gos.refresh_opinion(
        "XAU/USD", _store_cfg(tmp_path), now=datetime.now(timezone.utc))
    assert refreshed is True
    assert len(gem.calls) == 1
    assert v["bias"] == "NEUTRAL"
    # the new verdict is persisted for the display consumers
    data = json.loads((tmp_path / "gemini_status_cache.json").read_text())
    assert data["XAU/USD"]["verdict"]["bias"] == "NEUTRAL"


def test_entry_forces_fresh_opinion_even_with_fresh_store(tmp_path, monkeypatch):
    """A trade ENTERING gets a current read even 5 minutes after the last
    refresh (force=True bypasses the 30-min TTL)."""
    from services import gemini_opinion_store as gos
    from services import llm_review as lr
    _write_store(tmp_path, age_minutes=5)
    gem = _FakeGemini()
    monkeypatch.setattr(lr, "get_gemini_review_service", lambda cfg: gem)
    v, refreshed, _ = gos.refresh_opinion(
        "XAU/USD", _store_cfg(tmp_path), current_price=4612.5, force=True,
        now=datetime.now(timezone.utc))
    assert refreshed is True
    assert len(gem.calls) == 1
    assert gem.calls[0]["current_price"] == 4612.5
    assert v["bias"] == "NEUTRAL"


def test_entry_force_has_5min_anti_hammer(tmp_path, monkeypatch):
    """Two entries 4 minutes apart must not double-bill the quota."""
    from services import gemini_opinion_store as gos
    from services import llm_review as lr
    _write_store(tmp_path, age_minutes=5, attempt_age_minutes=4)
    gem = _FakeGemini()
    monkeypatch.setattr(lr, "get_gemini_review_service", lambda cfg: gem)
    v, refreshed, _ = gos.refresh_opinion(
        "XAU/USD", _store_cfg(tmp_path), force=True,
        now=datetime.now(timezone.utc))
    assert refreshed is False
    assert gem.calls == []
    assert v["bias"] == "BULLISH"


def test_failed_refresh_never_caches_verdict(tmp_path, monkeypatch):
    """A failed call keeps the old verdict and marks the attempt only -
    the next window (not every cycle) retries."""
    from services import gemini_opinion_store as gos
    from services import llm_review as lr
    _write_store(tmp_path, age_minutes=40, attempt_age_minutes=60)
    gem = _FakeGemini(available=False)
    monkeypatch.setattr(lr, "get_gemini_review_service", lambda cfg: gem)
    v, refreshed, _ = gos.refresh_opinion(
        "XAU/USD", _store_cfg(tmp_path), now=datetime.now(timezone.utc))
    assert refreshed is False
    assert v["bias"] == "BULLISH"  # old verdict kept
    data = json.loads((tmp_path / "gemini_status_cache.json").read_text())
    assert data["XAU/USD"]["verdict"]["bias"] == "BULLISH"
    # inside the window: no second attempt
    v2, refreshed2, _ = gos.refresh_opinion(
        "XAU/USD", _store_cfg(tmp_path), now=datetime.now(timezone.utc))
    assert len(gem.calls) == 1


def test_tick_manager_entry_forces_fresh_opinion(monkeypatch):
    """ORDER_FILLED (trade entry) must force a store refresh before the
    card is sent; the card's display line then reads the fresh store."""
    tm, captured = _tick_manager_for_card()
    tm.config = {}
    seen = {}

    def _fake_refresh(symbol, config, *, current_price=0.0, force=False, **k):
        seen["symbol"] = symbol
        seen["force"] = force
        seen["price"] = current_price
        return {"bias": "NEUTRAL"}, True, 0.0

    from services import gemini_opinion_store as gos
    monkeypatch.setattr(gos, "refresh_opinion", _fake_refresh)
    tick = SimpleNamespace(bid=4612.40, ask=4612.70, time_msc=1)
    pos = SimpleNamespace(price_open=4612.54, ticket=1234)
    executor = SimpleNamespace(_position_by_magic=lambda magic: pos)
    row = {"id": "T1", "type": "BUY", "symbol": "XAU/USD",
           "status": "PENDING", "entry_price": 4612.50}
    tm._handle_row(row, tick, executor, None)
    assert seen["force"] is True
    assert seen["symbol"] == "XAU/USD"
    assert seen["price"] == pytest.approx(4612.54)
    assert captured["events"] == ["ORDER_FILLED"]
