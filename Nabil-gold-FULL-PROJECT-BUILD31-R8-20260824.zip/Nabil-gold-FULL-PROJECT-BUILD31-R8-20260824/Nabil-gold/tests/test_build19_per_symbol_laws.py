"""BUILD 19 (2026-08-20): the tick manager must manage each trade with ITS
OWN instrument laws.

Live regression: the first WTI trade (BUY @86.82, SL 84.12) shipped the GOLD
stop band (270 pts = $2.70) because the live loop read trailing/stop/pv from
the base (gold) config for every row. These tests pin the per-symbol fix.
"""
from __future__ import annotations

import json
from copy import deepcopy
from types import SimpleNamespace

import scripts.run_tick_manager as rtm
from utils.helpers import load_config


def _base_cfg():
    cfg = deepcopy(load_config())
    # keep the tick manager constructor quiet in tests
    cfg["auction_flow"] = {"enabled": False,
                           "storage_path": "storage/auction_flow.sqlite3"}
    return cfg


def _tm(cfg):
    db = SimpleNamespace(update_trade=lambda *a, **k: None)
    return rtm.TickManager(cfg, telegram=None, database=db)


# ── per-symbol laws ─────────────────────────────────────────────────────────
def test_laws_for_gold_row_are_gold():
    tm = _tm(_base_cfg())
    laws = tm._per_symbol_laws({"symbol": "XAU/USD"})
    t, s = laws["trailing"], laws["stop"]
    assert (t["distance_points"], t["step_points"], t["early_breakeven_points"]) == (150, 40, 150)
    assert (s["min_liquidity_points"], s["safety_buffer_points"], s["max_stop_points"]) == (200, 70, 400)


def test_laws_for_wti_row_are_gold_times_04():
    # BUILD 31 R3 (2026-08-24, operator order "0.4 حسابيا للكل"): oil is
    # managed by the SAME law as gold at a FIXED scale factor k = 0.4 —
    # stop 80/28/160 (band [108, 160]), trailing 60/16, BE move 60.
    tm = _tm(_base_cfg())
    laws = tm._per_symbol_laws({"symbol": "WTI/USD"})
    t, s = laws["trailing"], laws["stop"]
    assert (t["distance_points"], t["step_points"], t["early_breakeven_points"]) == (60, 16, 60)
    assert (s["min_liquidity_points"], s["safety_buffer_points"], s["max_stop_points"]) == (80, 28, 160)


def test_laws_are_cached_per_symbol(monkeypatch):
    import utils.instruments as inst
    calls = []

    def _counting(base, instrument):
        calls.append(instrument.get("symbol"))
        return inst.config_for_instrument(base, instrument)

    monkeypatch.setattr(rtm, "config_for_instrument", _counting)
    tm = _tm(_base_cfg())
    tm._per_symbol_laws({"symbol": "WTI/USD"})
    tm._per_symbol_laws({"symbol": "WTI/USD"})
    tm._per_symbol_laws({"symbol": "WTI/USD"})
    assert calls == ["WTI/USD"]  # merged exactly once, then cached


def test_laws_fall_back_to_base_on_error(monkeypatch):
    tm = _tm(_base_cfg())

    def _boom(base, instrument):
        raise RuntimeError("merge failed")

    monkeypatch.setattr(rtm, "config_for_instrument", _boom)
    laws = tm._per_symbol_laws({"symbol": "WTI/USD"})
    assert laws["stop"]["max_stop_points"] == 400  # old base behaviour


# ── the live-regression repair path ─────────────────────────────────────────
class _Pos:
    price_open = 86.82
    sl = 84.12
    time = 0


class _Exec:
    def __init__(self):
        self.applied = []

    def apply_stop(self, tid, sl, tp2, symbol):
        self.applied.append((tid, round(sl, 2), round(tp2, 2), symbol))
        return True


def _wti_row(**overrides):
    row = {
        "id": "TRADE_LIVE_WTI_1",
        "symbol": "WTI/USD",
        "type": "BUY",
        "status": "OPEN",
        "entry_price": 86.82,
        # BUILD 31 R3 geometry: 108-pt stop (the k=0.4 floor) = 85.74
        "stop_loss": 85.74,
        "initial_stop_loss": 85.74,
        "tp1": 87.39,
        "tp2": 90.00,
        "mt5_ticket": 489284781,
        "execution_stop_normalized": True,
        "sl_moved_to_entry": False,
        "partial_close": False,
        "signal_snapshot": json.dumps({
            "signal": {"entry": {"price": 86.82}, "stop_loss": 85.74},
        }),
    }
    row.update(overrides)
    return row


def test_normalize_stop_keeps_legal_oil_stop_108():
    # BUILD 31 R3: a 108-pt stop is the floor of the k=0.4 band [108, 160]
    # -> legal, kept untouched.
    tm = _tm(_base_cfg())
    exec = _Exec()
    row = _wti_row()
    corrected = tm._normalize_execution_stop(row, _Pos(), exec, "BUY")
    assert corrected == 85.74  # 108 pts - legal, never moved
    assert exec.applied == []


def test_normalize_stop_widens_stop_below_oil_floor():
    # BUILD 31 R3: 92 pts is BELOW the 108-pt floor of the k=0.4 band
    # -> widened back to the floor (86.82 - 1.08 = 85.74).
    tm = _tm(_base_cfg())
    exec = _Exec()
    row = _wti_row(stop_loss=85.90,
                   signal_snapshot=json.dumps({
                       "signal": {"entry": {"price": 86.82}, "stop_loss": 85.90}}))
    corrected = tm._normalize_execution_stop(row, _Pos(), exec, "BUY")
    assert corrected == 85.74  # 86.82 - 1.08
    assert exec.applied[0][1] == 85.74


def test_normalize_stop_gold_row_untouched():
    tm = _tm(_base_cfg())
    exec = _Exec()
    row = {
        "id": "T_G", "symbol": "XAU/USD", "type": "BUY", "status": "OPEN",
        "entry_price": 4520.0, "stop_loss": 4493.0, "initial_stop_loss": 4493.0,
        "execution_stop_normalized": True,
        "signal_snapshot": json.dumps({"signal": {"entry": {"price": 4520.0}, "stop_loss": 4493.0}}),
    }
    corrected = tm._normalize_execution_stop(row, _Pos(), exec, "BUY")
    # 270 pts on gold is legal -> kept
    assert corrected == 4493.0
    assert exec.applied == []


# ── per-symbol pv in the live math ──────────────────────────────────────────
def test_per_symbol_point_value_in_handle_row_math():
    from utils.instruments import point_size
    tm = _tm(_base_cfg())
    pv_wti = point_size("WTI/USD", tm.config)
    pv_gold = point_size("XAU/USD", tm.config)
    assert pv_wti == 0.01
    assert pv_gold == 0.10
    # the live loop now derives pv per row symbol - pin the source call
    import inspect
    src = inspect.getsource(rtm.TickManager._handle_row)
    assert 'point_size(str(row.get("symbol") or "XAU/USD"), self.config)' in src
    assert "pv = 0.10" not in src


# ── the repair script's arithmetic (live geometry) ──────────────────────────
def test_repair_keeps_legal_stop_and_recomputes_targets():
    # BUILD 31 R3 (k=0.4): the live row's stop (108 pts, the floor) is
    # legal under the band [108, 160] -> kept; the far old targets
    # (87.39 / 90.00) are recomputed from the 108-pt risk: TP1 = 0.8R =
    # 86.4 pts (87.68), TP2 = 2x TP1 (88.55).
    from scripts.fix_live_wti_trade import plan_repair
    from utils.helpers import load_config
    from utils.instruments import config_for_instrument
    wti_cfg = config_for_instrument(load_config(), {"symbol": "WTI/USD"})
    row = _wti_row()
    plan = plan_repair(row, wti_cfg)
    assert plan is not None
    assert abs(plan["stop_new"] - 85.74) < 0.01   # 108 pts - legal, kept
    assert "stop already legal" in plan["stop_basis"]
    assert abs(plan["tp1_new"] - 87.68) < 0.02    # 0.8R of 108 pts
    assert abs(plan["tp2_new"] - 88.55) < 0.02    # 2x TP1 distance
    assert abs(plan["rr_new"] - 1.6) < 0.01       # law-compliant 2R


def test_repair_widens_stop_below_floor_when_no_planned_stop():
    # BUILD 31 R3 (k=0.4): no planned stop in the snapshot and the live
    # stop (92 pts) is below the 108-pt floor -> widened to the floor
    # (86.82 - 1.08 = 85.74).
    from scripts.fix_live_wti_trade import plan_repair
    from utils.helpers import load_config
    from utils.instruments import config_for_instrument
    wti_cfg = config_for_instrument(load_config(), {"symbol": "WTI/USD"})
    row = _wti_row(stop_loss=85.90,
                   signal_snapshot=json.dumps({"signal": {"entry": {"price": 86.82}}}))
    plan = plan_repair(row, wti_cfg)
    assert plan is not None
    assert abs(plan["stop_new"] - 85.74) < 0.01   # 108-pt floor
    assert abs(plan["tp1_new"] - 87.68) < 0.02    # 0.8R of 108 pts
    assert abs(plan["tp2_new"] - 88.55) < 0.02
    assert abs(plan["rr_new"] - 1.6) < 0.01


def test_repair_recomputes_targets_when_stop_already_legal():
    # BUILD 31 R3 (k=0.4): a legal 108-pt stop (85.74) with old near
    # targets -> the repair keeps the stop and recomputes targets.
    from scripts.fix_live_wti_trade import plan_repair
    from utils.helpers import load_config
    from utils.instruments import config_for_instrument
    wti_cfg = config_for_instrument(load_config(), {"symbol": "WTI/USD"})
    row = _wti_row(stop_loss=85.74, tp1=87.10, tp2=87.90)
    plan = plan_repair(row, wti_cfg)
    assert plan is not None
    assert abs(plan["stop_new"] - 85.74) < 0.01   # kept
    assert abs(plan["tp1_new"] - 87.68) < 0.02
    assert abs(plan["tp2_new"] - 88.55) < 0.02


def test_repair_noop_when_all_conform():
    from scripts.fix_live_wti_trade import plan_repair
    from utils.helpers import load_config
    from utils.instruments import config_for_instrument
    wti_cfg = config_for_instrument(load_config(), {"symbol": "WTI/USD"})
    row = _wti_row(stop_loss=85.74, tp1=87.68, tp2=88.55)
    assert plan_repair(row, wti_cfg) is None
