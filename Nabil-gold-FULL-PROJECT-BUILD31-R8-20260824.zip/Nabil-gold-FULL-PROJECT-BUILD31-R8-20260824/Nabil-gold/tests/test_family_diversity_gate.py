"""Path 1 must not be carried by one correlated agent family alone.

The live case (2026-08-17 11:06 UTC): BUY admitted via THREE_AGENT_CONSENSUS
by exactly technical + multitimeframe + classical — the complete trend
family — at the top of a buyside-liquidity sweep. Both structure agents
refused (smc 29.5, price_action 45.7) and macro read SELL 68. A manual SMC
analyst called the same top distribution. Three trend readers share EMA/
ADX/timeframe-alignment inputs; their agreement is one thesis counted three
times, not three confirmations.

The gate: a full-consensus book whose qualified supporters all belong to
one family loses the UNCONFIRMED direct entry and falls through to Paths
2/3/5, where Macro/Gemini/Auction must supply the independent voice. A
mixed book behaves exactly as before. Kill switch:
signal_requirements.family_diversity.enabled.
"""

from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from agents.decision_agent import DecisionAgent
from services.thesis_consensus import evaluate_directional_admission


def _config(enabled: bool = True, **extra):
    cfg = {
        "agent_weights": {
            "classical": 0.25, "technical": 0.20, "smc": 0.20,
            "price_action": 0.20, "multitimeframe": 0.15,
        },
        "signal_requirements": {
            "min_agents_agree": 3,
            "min_consensus_confidence": 65,
            "agent_min_confidence": 65,
            "family_diversity": {
                "enabled": enabled,
                "families": {
                    "trend": ["technical", "multitimeframe", "classical"],
                    "structure": ["smc", "price_action"],
                },
            },
            "two_agent_entry": {
                "enabled": True,
                "min_agents_agree": 2,
                "min_consensus_confidence": 65,
                "macro_confirmation": {"enabled": True, "min_confidence": 55},
                "gemini_confirmation": {"enabled": True, "min_confidence": 70},
            },
            "path5_two_agent_auction": {
                "enabled": True, "min_agents_agree": 2,
                "min_consensus_confidence": 65, "min_auction_confidence": 65,
            },
        },
    }
    cfg["signal_requirements"].update(extra)
    return cfg


def _trend_only_book(side="BUY"):
    """The exact 11:06 shape: whole trend family, structure refusing."""
    return {
        "technical": {"signal": side, "confidence": 70},
        "multitimeframe": {"signal": side, "confidence": 92},
        "classical": {"signal": side, "confidence": 68},
        "smc": {"signal": "WAIT", "confidence": 29.5},
        "price_action": {"signal": "WAIT", "confidence": 45.7},
    }


def _mixed_book(side="BUY"):
    return {
        "technical": {"signal": side, "confidence": 70},
        "multitimeframe": {"signal": side, "confidence": 92},
        "smc": {"signal": side, "confidence": 68},
        "classical": {"signal": "WAIT", "confidence": 40},
        "price_action": {"signal": "WAIT", "confidence": 45},
    }


# ── shared admission (Path 1 / planner / scale-ins / watch maps) ────────────

def test_single_family_book_is_refused_direct_entry():
    admission = evaluate_directional_admission("BUY", _trend_only_book(), _config())
    assert admission["allow"] is False
    assert admission.get("family_diversity_blocked") is True
    assert "family" in str(admission.get("reason", "")).lower()


def test_mixed_family_book_is_admitted_unchanged():
    admission = evaluate_directional_admission("BUY", _mixed_book(), _config())
    assert admission["allow"] is True
    assert admission["path"] == "THREE_AGENT_CONSENSUS"
    assert sorted(admission.get("supporter_families", [])) == ["structure", "trend"]


def test_structure_pair_plus_one_trend_is_diverse():
    details = {
        "smc": {"signal": "SELL", "confidence": 75},
        "price_action": {"signal": "SELL", "confidence": 70},
        "classical": {"signal": "SELL", "confidence": 68},
        "technical": {"signal": "WAIT", "confidence": 30},
        "multitimeframe": {"signal": "WAIT", "confidence": 35},
    }
    admission = evaluate_directional_admission("SELL", details, _config())
    assert admission["allow"] is True


def test_single_family_book_still_enters_with_external_confirmation():
    """The demotion is to Paths 2/3/5, not to oblivion: macro agreement
    supplies the independent voice and the book enters as TWO_AGENT_MACRO."""
    details = _trend_only_book("BUY")
    details["macro_fundamental"] = {"direction": "BUY", "confidence": 60}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is True
    assert admission["path"] == "TWO_AGENT_MACRO"


def test_single_family_book_is_NOT_rescued_by_auction_since_rule_b():
    """UPDATED 2026-08-17 (Rules A/B): auction rescues of pure-trend books
    measured 0/4 at both horizons — momentum confirming momentum. The
    auction escape hatch this test originally pinned is now closed; macro
    (and any confirmer added to single_family_confirmers) remains open.
    See tests/test_family_confirmer_rules.py for the full matrix."""
    details = _trend_only_book("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 80}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is False


def test_kill_switch_restores_the_old_behaviour():
    admission = evaluate_directional_admission("BUY", _trend_only_book(), _config(enabled=False))
    assert admission["allow"] is True
    assert admission["path"] == "THREE_AGENT_CONSENSUS"


def test_gate_defaults_off_for_bare_test_configs():
    """Configs that never mention family_diversity keep legacy behaviour —
    the fleet of existing tests and any stripped-down config must not
    silently change meaning."""
    cfg = _config()
    del cfg["signal_requirements"]["family_diversity"]
    admission = evaluate_directional_admission("BUY", _trend_only_book(), cfg)
    assert admission["allow"] is True


# ── decision agent (the voted book itself) ──────────────────────────────────

def test_decision_agent_demotes_single_family_to_two_agent_candidate():
    agent = DecisionAgent(_config())
    votes = agent._collect_votes(_trend_only_book("BUY"))
    classic = agent._classic_decision(votes)

    assert classic["decision"] == "WAIT"
    assert "family" in str(classic.get("rejection_reason", "")).lower()
    two = classic.get("two_agent")
    assert isinstance(two, dict) and two.get("side") == "BUY", (
        "a demoted book must surface as a Path-2/5 candidate for external confirmation"
    )


def test_decision_agent_mixed_book_unaffected():
    agent = DecisionAgent(_config())
    votes = agent._collect_votes(_mixed_book("BUY"))
    classic = agent._classic_decision(votes)
    assert classic["decision"] == "BUY"


def test_decision_agent_kill_switch():
    agent = DecisionAgent(_config(enabled=False))
    votes = agent._collect_votes(_trend_only_book("BUY"))
    classic = agent._classic_decision(votes)
    assert classic["decision"] == "BUY"
