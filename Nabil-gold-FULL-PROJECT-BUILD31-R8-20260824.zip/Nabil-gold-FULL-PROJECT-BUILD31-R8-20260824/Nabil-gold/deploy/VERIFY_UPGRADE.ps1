﻿?# ============================================================================
# VERIFY_UPGRADE.ps1
# Nabil-gold - fast post-apply verification for the 2026-08-19 upgrade.
# Runs ONLY the upgrade tests (seconds) + compiles the changed files.
# The full suite runs inside APPLY_20260819_UPGRADES.ps1 already; this script
# is the quick re-check for later audits or manual copies.
# ============================================================================
param(
    [string]$RepoRoot = "C:\Nabil-gold"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path (Join-Path $RepoRoot "config.json"))) { throw "Repo root not found: $RepoRoot" }

Write-Host "==> Verifying upgrade 2026-08-19 in $RepoRoot" -ForegroundColor Cyan

$Files = @(
    "utils\indicators.py",
    "agents\technical_agent.py",
    "services\market_regime.py",
    "services\correlation_exposure.py",
    "services\risk_analytics.py",
    "services\margin_guard.py",
    "services\mt5_feed.py",
    "services\dynamic_risk.py",
    "services\telegram_bot.py",
    "services\gemini_confirm_cache.py",
    "services\mt5_executor.py",
    "scripts\run_analysis.py",
    "scripts\run_daily_report.py",
    "scripts\run_risk_analytics.py",
    "scripts\run_walk_forward_report.py",
    "scripts\map_support_report.py",
    "scripts\verify_redesign_readiness.py",
    "scripts\system_healthcheck.py",
    "tests\mt5_fake.py"
)

foreach ($f in $Files) {
    $path = Join-Path $RepoRoot $f
    if (-not (Test-Path $path)) { throw "MISSING: $f - upgrade not fully applied" }
    & python -m py_compile $path
    if ($LASTEXITCODE -ne 0) { throw "py_compile failed: $f" }
}
Write-Host "    [OK] All 14 changed files present and compiling" -ForegroundColor Green

# config.json must carry the new sections and the fixed filter value
$cfg = Get-Content (Join-Path $RepoRoot "config.json") -Raw | ConvertFrom-Json
foreach ($key in @("market_regime", "correlation_guard", "margin_guard")) {
    if (-not ($cfg.PSObject.Properties.Name -contains $key)) { throw "config.json missing section: $key" }
}
if ($cfg.filters.max_consecutive_losses -ne 3) {
    throw "config.json still carries max_consecutive_losses=$($cfg.filters.max_consecutive_losses) (expected 3)"
}
if ([double]$cfg.risk_settings.max_daily_loss_percent -le 0) {
    throw "config.json missing max_daily_loss_percent"
}
Write-Host "    [OK] config.json sections and fixes verified" -ForegroundColor Green

Push-Location $RepoRoot
try {
    & python -m pytest tests\test_market_regime_service.py tests\test_correlation_exposure_service.py tests\test_margin_guard_service.py tests\test_dollar_daily_limit.py tests\test_calculate_adx_indicators.py tests\test_regime_gate_in_analysis.py tests\test_mt5_margin_veto.py tests\test_sentiment_agent.py tests\test_volatility_agent.py tests\test_oil_macro_agent.py tests\test_auction_promotion.py tests\test_agent_fixes_20260819.py tests\test_remaining_fixes_20260819.py tests\test_map_support_report.py tests\test_verify_redesign_readiness.py -q
    $exit = $LASTEXITCODE
} finally {
    Pop-Location
}
if ($exit -ne 0) { throw "Upgrade tests FAILED (exit $exit)" }
Write-Host "    [OK] 43 upgrade tests passed" -ForegroundColor Green
Write-Host "==> VERIFICATION PASSED" -ForegroundColor Green
