﻿<#
.SYNOPSIS
    CHECK_EVERYTHING.ps1 - one command to verify EVERYTHING is alive and
    working: system health, maps, oil chain, macro chain, measurements.

.DESCRIPTION
    Runs, in order (all read-only):
      1) SYSTEM    python scripts\system_healthcheck.py
      2) MODES     python scripts\inspect_running_modes.py
      3) OIL       python scripts\oil_macro_check.py
      4) MACRO     python scripts\macro_feed_check.py --probe
      5) MAPS      python scripts\map_support_report.py
    One log per run: diagnostics\all_alive_<stamp>.log

.PARAMETER RepoRoot
    Project root. Default: C:\Nabil-gold.

.EXAMPLE
    cd C:\Nabil-gold
    powershell -ExecutionPolicy Bypass -File CHECK_EVERYTHING.ps1
#>
param(
    [string]$RepoRoot = "C:\Nabil-gold"
)

$ErrorActionPreference = "Continue"
if (-not (Test-Path (Join-Path $RepoRoot "config.json"))) {
    throw "config.json not found under $RepoRoot - pass -RepoRoot <folder>"
}
Push-Location $RepoRoot
try {
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $log = Join-Path $RepoRoot ("diagnostics\all_alive_" + $stamp + ".log")
    New-Item -ItemType Directory -Path (Split-Path -Parent $log) -Force | Out-Null
    Write-Host "==> EVERYTHING CHECK - log: $log"

    $checks = @(
        @("SYSTEM", @("scripts/system_healthcheck.py")),
        @("MODES",  @("scripts/inspect_running_modes.py")),
        @("OIL",    @("scripts/oil_macro_check.py")),
        @("MACRO",  @("scripts/macro_feed_check.py", "--probe")),
        @("MAPS",   @("scripts/map_support_report.py"))
    )
    foreach ($c in $checks) {
        Write-Host "    -> $($c[0]) ..."
        Add-Content -Path $log -Value ("`n===== " + $c[0] + " " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + " =====")
        $tmpOut = [System.IO.Path]::GetTempFileName()
        $tmpErr = [System.IO.Path]::GetTempFileName()
        $p = Start-Process -FilePath "python" -ArgumentList $c[1] -NoNewWindow -Wait -PassThru `
            -RedirectStandardOutput $tmpOut -RedirectStandardError $tmpErr
        Add-Content -Path $log -Value ("[exit code: " + $p.ExitCode + "]")
        Get-Content $tmpOut -Raw -ErrorAction SilentlyContinue | Add-Content -Path $log
        Get-Content $tmpErr -Raw -ErrorAction SilentlyContinue | Add-Content -Path $log
        Remove-Item $tmpOut, $tmpErr -Force -ErrorAction SilentlyContinue
        Write-Host "        done (exit $($p.ExitCode))"
    }
    Write-Host "==> DONE. Full log: $log"
} finally {
    Pop-Location
}
