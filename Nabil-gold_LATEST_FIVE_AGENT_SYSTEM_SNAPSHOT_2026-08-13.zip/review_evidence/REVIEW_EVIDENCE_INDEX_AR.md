# فهرس أدلة المراجعة

## تدقيق خرائط اليوم

- `today_maps_audit_20260813_062646.txt/json`
  - 18 snapshot.
  - فصل MAP READY عن EXECUTION ADMITTED.
  - يكشف mismatch تاريخياً قبل الإصلاح.

## تطور الثقة الموحدة

- `agents_now_20260813_070838.txt/json`
- `agents_now_20260813_071348.txt/json`
  - بعد تطبيع ثقة Unified/Auction إلى 50..95.

## قبل وبعد graded_auction_v2

- `agents_now_20260813_084551.txt/json`
  - Auction قبل النموذج المتدرج، قرابة 79 مع acceptance ثنائي.
- `agents_now_20260813_090655.txt/json`
- `agents_now_20260813_091710.txt/json`
  - Auction المتدرج مع raw pressure وduration/depth/continuation.

## آخر حالة عند الاقتراب من منطقة العرض

- `agents_now_20260813_103917.txt/json`
  - السعر 4388.655.
  - Auction انتقل إلى BALANCED_AUCTION وWAIT 64.6.
  - SMC structure BULLISH/WEAK وconditional BUY setup ضعيف.

## مرجع المحلل اليدوي

- `manual_analyst_supply_map_20260813.jpg`
  - منطقة بيع يدوية تقريبية 4390.569–4408.902 وأهداف سفلية.

استخدم JSON للحسابات، وTXT فقط للقراءة البشرية.
