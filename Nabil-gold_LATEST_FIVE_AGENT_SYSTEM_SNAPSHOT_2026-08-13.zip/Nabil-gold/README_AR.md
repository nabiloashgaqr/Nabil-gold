# Auction Flow متدرج مباشرة دون Replay — 2026-08-13

بموافقة المشغّل، فُعّل نموذج `graded_auction_v2` مباشرة دون Replay ودون إعادة
تنزيل Tick أو إعادة بناء calibration.

التغيير داخل مكونات Auction فقط:

1. `flow_pressure`: يتحول من imbalance خام صغير مثل `-0.05` إلى دليل سلس
   متدرج بواسطة `tanh(raw/0.12)`، فيتحرك مع قوة الضغط بدلاً من البقاء قريباً
   من الصفر.
2. `value_location`: أُلغي hard clip عند `±1 ATR` واستُبدل بتحويل ATR ناعم
   `tanh(distance/2)`؛ فيظل محصوراً `-1..+1` لكنه يتغير عند الاقتراب والابتعاد.
3. `acceptance_rejection`: لم يعد `-1/0/+1`. القبول يوزن مدة البقاء خارج
   القيمة `35%`، العمق `30%`، ضغط التكات `25%`، والاستمرار `10%`. الرفض يوزن
   excursion `40%`، عمق العودة `35%`، والضغط `25%`.
4. أضيفت إلى فحص `agents_now` القيم الخام ومكونات القبول ليمكن إثبات الحركة
   رقمياً في كل لقطة.

لا تغيير في رقم الثقة الواحد أو سقف `95` أو الأوزان أو `67/72` أو Entry/Thesis
أو الستوب والأهداف. ملف calibration الحالي يبقى مستخدماً، وأصبح builder
المستقبلي يقرأ الدوال المتدرجة نفسها لضمان التطابق إن أُعيد بناؤه لاحقاً.

نتيجة الاختبارات:

```text
1827 collected
1824 passed
3 skipped
1 warning قديم عن datetime.utcnow()
```

---

# فصل مراجع السيولة في Telegram دون لمس الستوب أو الأهداف — 2026-08-13

بموافقة المشغّل، عُدّل عرض `L1/L2` فقط. لم تتغير دوال الستوب أو `TP1/TP2`
أو الأوامر أو إدارة الصفقة.

القانون المعروض:

```text
L1 = أول سيولة صالحة بعد أرضية TP1 الحالية (0.8R)
Minimum independent L2 gap = max(100 points, 0.5R)
```

أي مستوى أقرب من هذه المسافة إلى L1 يُضم إلى `L1 zone` ولا يظهر كـL2
مستقلة. إن لم توجد سيولة ثانية مستقلة، تعرض البطاقة:

```text
L2 -- no independent pool
```

وتكتب البطاقة صراحة:

```text
L1/L2 are liquidity references; TP1/TP2 above are the execution targets.
```

مثال الاختبار:

```text
Entry 4400 · Stop 4430 · R=300 points
Pools 4375, 4370, 4350
Required independent gap=max(100,150)=150 points
L1 zone=4370–4375
L2=4350
```

تم تثبيت قانون الأهداف قبل وبعد تشغيل مجمّع العرض وإثبات تطابق الناتج؛ أي أن
التغيير لا يستطيع تعديل الأسعار التنفيذية.

نتيجة الاختبارات الكاملة:

```text
1822 collected
1819 passed
3 skipped
1 warning قديم عن datetime.utcnow()
```

ظهر في أول اختبار تطويري ثلاثة إخفاقات ولم تُخفَ: تنسيق السعر المتوقع، اختبار
قديم كان يتوقع إخفاء L2 كلياً، وحارس المصدر الواحد. صُححت التوقعات واستُخدم
`utils.trading_rules` مباشرة، ثم نجحت الجولة الكاملة أعلاه.

---

# خريطة مراقبة بوكيلين مع المنطقة والستوب والأهداف والسيولة — 2026-08-13

بموافقة المشغّل، أصبحت الخريطة الهيكلية المكتملة تُرسل إلى Telegram للمراقبة
عندما يتوفر وكيلان Core مؤهلان وصافي `>=72%`، حتى لو بقي shared execution
admission محجوباً لغياب الوكيل الثالث أو Macro/Gemini بنفس الاتجاه.

شروط العرض فقط:

```text
plan_ready structurally       = true
qualified core supporters     >= 2
net confidence                >= 72
qualified opposition          <= 1
zone/entry/stop/targets        complete
mapped-side liquidity          present
execution_admission.allow      = false
```

تظهر البطاقة بوضوح:

```text
WATCH MAP — MONITORING ONLY
NOT EXECUTION-ADMITTED
No Market, Pending or revived-plan order can be created from this card.
```

وتعرض:

- منطقة BUY/SELL الرئيسية وسعر الدخول المرجعي.
- Stop/Invalidation.
- TP1 وTP2.
- L1 وL2 من سيولة الاتجاه.
- عدد المؤيدين والمعارضين والمنتظرين وأسماء المحتسبين.
- رأي الوكلاء الخمسة ووزن وتأهل كل واحد.
- خريطة SMC الشرطية عندما يكون صوته الحالي WAIT، مع المنطقة والدخول والستوب
  والهدف والحالة والجودة واحتمال العودة، وتكتب صراحة أنها ليست صوتاً محتسباً.

لا تغيير في أي قاعدة تنفيذ. `_planner_execution_gate` يبقى محرك Entry/Thesis
المشترك نفسه، واختبار الأمان يثبت في الحالة نفسها:

```text
MONITORING DISPLAY ALLOWED
REAL EXECUTION BLOCKED
```

منع الإغراق يبقى فعالاً: أول خريطة في الجلسة ثم التغييرات المادية فقط، وبفاصل
`25` دقيقة وفق الإعداد الحالي.

نتيجة الاختبارات:

```text
1816 collected
1813 passed
3 skipped
1 warning قديم عن datetime.utcnow()
```

---

# رقم ثقة واحد منطقي للوكيلين الجديدين — 2026-08-13

بموافقة المشغّل، تم استبدال إخراج احتمال Logistic الخام للوكيلين
`unified_trend` و`auction_flow` بدرجة ثقة تصويت واحدة على المجال القانوني
`50..95`. لا يظهر رقم احتمال ثانٍ.

المعادلة:

```text
Strength = abs(FinalEdge)
P0 = Logistic(0)
P1 = Logistic(1)
P  = Logistic(Strength)
Confidence = 50 + 45 * ((P - P0) / (P1 - P0))
```

تبقى كل مراحل النقاط كما هي:

```text
families -> BaseEdge -> Coherence -> Coverage/DataQuality -> FinalEdge
```

ولا تتغير الأوزان أو عتبات `67/72` أو قواعد ثلاثة وكلاء/وكيلين مع التأكيد
الخارجي. Entry وThesis Exit يقرآن الرقم نفسه.

على القراءة الحية التي أدت إلى القرار:

```text
Unified Trend: edge 0.1789 -> confidence 58.1 -> WAIT
Auction Flow : edge 0.6400 -> confidence 79.0 -> SELL qualified
```

إذا كان منحنى المعايرة نفسه يميّز بأقل من نقطتين مئويتين بين Strength 0 و1،
يُحجب الوكيل عند `WAIT 50` مع
`CALIBRATION_HAS_NO_DISCRIMINATING_POWER` بدلاً من تضخيم منحنى مسطح.

لا إعادة تنزيل Tick ولا إعادة بناء calibration. المعايرات الحالية تُستخدم
كشكل monotonic بعد تطبيع مجالها إلى مقياس الثقة الموحد.

نتيجة الاختبارات:

```text
1811 collected
1808 passed
3 skipped
1 warning قديم عن datetime.utcnow()
```

---

# تصحيح Installer V3 — اختبارات VPS في Sandbox نظيف

أظهرت محاولة V2 أن تشغيل الاختبارات الكاملة داخل `C:\Nabil-gold` نفسه يخلط
بيئة التشغيل الحية مع بيئة pytest:

1. حذف متغيرات Telegram/Supabase من Process لم يكن كافياً، لأن
   `load_dotenv(override=False)` أعاد تحميل القيم الحقيقية من `.env` أثناء
   استيراد الاختبارات. لذلك تصرفت اختبارات Telegram كأن الإرسال الحي مفعّل،
   وظهرت أخطاء `MagicMock is not JSON serializable`.
2. اختبار THESIS_EXIT يمسح كل ملفات Python تحت جذر المشروع. دخل إلى
   `storage\deployment_backups\...\files\tests` واعتبر نسخة Backup قديمة
   ملف مصدر حي، فظهر offender كاذب.

توقف V2 عند الاختبارات ونفّذ `ROLLBACK COMPLETE`؛ لم تُفعّل نسخة جزئية.

يعالج V3 ذلك دون تعطيل أي اختبار:

- ينشئ نسخة اختبار مؤقتة خارج `C:\Nabil-gold` داخل Windows TEMP.
- يستبعد `.env` و`storage/deployment_backups` وبيانات التشغيل وSQLite
  والمعايرات من نسخة الاختبار.
- ينسخ فقط analyst-label fixtures المطلوبة للاختبار.
- يجعل كل أسماء المتغيرات الموجودة في `.env` فارغة داخل عملية pytest دون
  قراءة أو طباعة قيمها.
- يشغّل **كامل 1803 اختبار** ثم يحذف Sandbox في `finally`.

تمت محاكاة الـSandbox النظيف وتشغيل الجولة كاملة:

```text
1803 collected
1800 passed
3 skipped
1 warning قديم عن datetime.utcnow()
```

---

# تصحيح Installer V2 — مسار Python على VPS

أظهرت محاولة V1 أن ملف التحقق المؤقت وُضع داخل
`storage\deployment_backups\...`؛ وعند تشغيل Python لملف بمسار مطلق يصبح
مجلد الملف هو `sys.path[0]`، لذلك لم يجد package باسم `services` رغم أن
PowerShell كان داخل `C:\Nabil-gold`. توقف المثبت قبل الاختبارات ونفّذ
`ROLLBACK COMPLETE`، ولذلك لم تُفعّل نسخة جزئية ولم يُمس Tick Manager.

في V2 يوضع verifier المؤقت في جذر `C:\Nabil-gold`، ويُحذف في `finally` سواء
نجح أو فشل. تم تشغيل الحالة نفسها محلياً ونجحت:

```text
EXACT 06:02 CASE OK: WATCH_EXECUTION
BUY admission failed: support=2, opposition=0, net=73.3%
```

---

# صدق جاهزية التنفيذ وتحليل خرائط 2026-08-13

## الخلاصة التشغيلية

تم تحليل الملفات الحية الأربعة المرفوعة من VPS:

```text
today_maps_audit_20260813_055513.txt/json
agents_now_20260813_055611.txt/json
```

النتيجة الصحيحة ليست «صفقة ضائعة»، بل:

```text
11 snapshots
1 structurally valid map
0 execution-admitted maps
10 structurally rejected maps
0 trades admitted
```

الخريطة الوحيدة التي اجتازت بناء الخريطة كانت BUY الساعة `06:02:11`:

```text
Map quality       87.2/100 (quality, not probability)
SMC               BUY 73.1%
Price Action      BUY 73.5%
Net               73.3%
Macro             SELL 84% (opposite)
Gemini confirmer  unavailable/not stored
Shared admission  BLOCKED
```

وجود وكيلين وبلوغ صافي 73.3% لا يكفي وحده. المسار الثنائي يحتاج Macro بنفس
الاتجاه >=55% أو Gemini بنفس الاتجاه >=70%. لذلك لم يكن هناك قبول تنفيذ، ولم
تكن هناك صفقة يجب فتحها.

## الخلل الذي كشفه التقرير

أبقت بوابة الأوامر وبوابة Telegram الصفقة محجوبة بصورة سليمة، لكن الحقل
الداخلي `execution_readiness` سمّى الخريطة نفسها:

```text
MARKET_EXECUTION_READY
```

والسبب أن طبقة الجاهزية القديمة اعتبرت وجود SMC ضمن الوكيلين بديلاً عن
التأكيد الخارجي. هذا لا يفتح أمراً لأن بوابة التنفيذ النهائية تستخدم المحرك
المشترك الصحيح، لكنه تناقض تشخيصي خطير: تقرير واحد يقول READY بينما shared
admission يقول BLOCKED.

أُصلح ذلك دون تغيير أي وزن أو عتبة أو قاعدة تداول:

- `SessionPlannerService._execution_readiness` يستخدم الآن
  `evaluate_directional_admission` نفسه المستخدم في Entry وThesis Exit.
- SMC يبقى صوتاً من الخمسة ولا يُعامل كتأكيد خارجي سادس.
- الخريطة الهيكلية السليمة يمكن أن تبقى محفوظة لإعادة التقييم لاحقاً، لكن
  حالتها التنفيذية تكون `WATCH_EXECUTION` حتى ينجح أحد المسارات الثلاثة.
- تم إصلاح جسر الأسماء التاريخية عند إحياء خريطة قديمة حتى يقرأ
  `technical -> unified_trend` و`multitimeframe -> auction_flow` كـ aliases
  للقراءة فقط، ولا تضيع أصوات تاريخية سليمة.

## تصحيح تقرير خرائط اليوم

كان السطر:

```text
10x qualified_support 0 < 2
```

مضللاً تشخيصياً. ثماني خرائط كانت `WAIT` بلا اتجاه خريطة أصلاً، فلا يوجد هدف
BUY/SELL يمكن حساب supporters له. أربع منها كان لديها وكيل اتجاهي مؤهل فعلاً.
التقرير الجديد:

- يفصل `MAP READY` عن `EXECUTION ADMITTED`.
- لا يحسب support shortfall لخريطة WAIT بلا جانب.
- يعرض `map_ready_but_execution_blocked`.
- يقارن readiness المخزنة بالـshared admission ويكشف أي mismatch تاريخي.
- يعرض توزيع عدد الوكلاء المؤهلين ومرات ظهور كل وكيل مؤهل.

## كل خرائط اليوم بالأرقام

| الوقت Asia/Hebron | الخريطة | الوكلاء المؤهلون | السبب الحقيقي |
|---|---|---|---|
| 00:02 | WAIT | Price Action BUY 73.5 | dominance 46.8 أقل من 50؛ return 75.3 سليم |
| 01:02 | WAIT | Price Action SELL 72.2 | setup quality 46 أقل من 70 |
| 02:02 | SELL / NOT_READY | لا أحد | Macro وحده؛ authority WEAK وstructure WEAK |
| 03:02 | SELL / NOT_READY | Classical BUY 68.2 (معارض) | لا مؤيد SELL؛ authority WEAK |
| 04:02 | WAIT | Price Action BUY 77.8 | dominance 41.8 أقل من 50 وreturn 36.9 أقل من 42 |
| 05:02 | WAIT | لا أحد | structure WEAK؛ SMC BUY 65 وPA SELL 64.2 تحت 67 |
| 06:02 | BUY / map ready | SMC BUY 73.1 + PA BUY 73.5 | net 73.3 لكن Macro SELL 84؛ لا تأكيد خارجي BUY، لذا التنفيذ محجوب |
| 07:02 | WAIT | Price Action SELL 69.6 | quality 51 أقل من 70 وstructure WEAK |
| 08:02 | WAIT | لا أحد | quality 41 أقل من 70 |
| 08:54:40 | WAIT | لا أحد | return 39.2 أقل من 42 وstructure WEAK؛ dominance 66.7 سليم |
| 08:54:57 | WAIT | لا أحد | quality 63 أقل من 70 |

توزيع التأهل خلال 11 snapshot:

```text
0 qualified core agents: 5 maps
1 qualified core agent : 5 maps
2 qualified core agents: 1 map

Price Action qualified appearances: 5
Classical qualified appearances   : 1
SMC qualified appearances         : 1
Unified Trend                     : 0
Auction Flow                      : 0
```

## القراءة الحية عند 08:56

مصدر البيانات والحسابات سليمان:

```text
Shared snapshot: MT5BOOK::f8cd6219f9bdf496
Native frames  : M5/M15/H1/H4, 220 candles each
Weights sum    : 1.0
Arithmetic     : PASS for all five agents
Auction health : tick 0.02s, heartbeat 0.81s, 27,119 unique ticks/5m
Calibrations   : Unified 2642 valid, Auction 5836 valid
```

أسباب WAIT الحالية:

1. **Unified Trend 50.3%**: EMA `+0.23` وStructure `+0.55` يعارضان Momentum
   `-0.54` وMACD `-0.56` وRSI `-0.30`. coherence فقط `28.6%`، فالحافة
   `-0.0355` شبه صفرية.
2. **Classical 29.0%**: لا فريم تجاوز `+2.5/-2.5`. الدرجات:
   `-0.9, -0.9, -1.0, +0.6`.
3. **SMC 30.2%**: لا فريم تجاوز `+4/-4`. الدرجات:
   `+1.3, -1.5, +2.3, -0.3`. اكتُشفت خمسة setup candidates، لكن التصويت
   الحالي متعادل لأن structure والسحوبات متعارضة، ونقاط OB/FVG/مراجع الجلسة
   الحالية صفر.
4. **Price Action SELL 55.2%**: فريم 1H وحده SELL 68%. تغطية `1/4` تعطي
   participation `0.8125`، لذلك `68 × 0.8125 = 55.25`؛ الحساب صحيح.
5. **Auction Flow 54.3%**: raw SELL وحافة `-0.6218`، لكن tick pressure فقط
   `-0.043` رغم أن location `-0.823` وacceptance `-1.0`. المعايرة أبقته دون
   67؛ البيانات ليست stale.

## ما لم يتغير

```text
Weights: 20/25/20/20/15
Agent bar: 67
Net consensus: 72
Path 1: 3 core agents
Path 2: 2 core + Macro >=55 same side
Path 3: 2 core + Gemini >=70 same side
```

لا إعادة تحميل Tick، لا إعادة معايرة، لا تعديل config، ولا تغيير في SL/TP أو
إدارة المخاطر. التشغيل يبقى Demo فقط.

## الاختبارات

الجولة الكاملة بعد الإصلاح:

```text
1803 collected
1800 passed
3 skipped
1 old datetime.utcnow() deprecation warning
```

ظهر فشل واحد في أول تشغيل كامل وكُشف ولم يُخفَ: اختبار إحياء خريطة تاريخية
فقد اسم `technical` القديم عند تحويله إلى `unified_trend`. تم إصلاح جسر alias
ثم أُعيد كامل الاختبار ونجح كما هو موضح أعلاه.

## التثبيت

فك ZIP في مجلد مستقل على VPS، ثم افتح PowerShell كمسؤول وشغّل:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\INSTALL.ps1"
```

المثبت لا يوقف Tick Manager ولا يبني قاعدة Auction أو المعايرات. يوقف مهمة
التحليل مؤقتاً فقط، يأخذ Backup، ينسخ الملفات، يشغّل اختبارات regression،
يشغّل تقرير خرائط اليوم المصحح، ثم يعيد حالات المهام. عند الفشل يعيد الملفات
تلقائياً.

بعد النجاح ارفع أحدث ملفين فقط:

```text
diagnostics\today_maps_audit_*.txt
diagnostics\today_maps_audit_*.json
```

---

# إصلاح المصدر المشترك وصدق الخريطة — 2026-08-12

## ما أُصلح بعد التشغيل

- تُجلب شموع MT5 الأصلية مرة واحدة فقط في دورة التحليل.
- تُخزن اللقطة نفسها ذرياً في `storage/shared_market_data.json`.
- يستلم الوكلاء الخمسة الكائن نفسه و`snapshot_id` نفسه؛ لا وكيل يجلب الشموع منفرداً.
- مسار Auction SQLite أصبح مطلقاً من جذر المشروع، فلا يعتمد على working directory.
- أُغلق خلل Planner الذي اعتبر خمسة وكلاء دون 67% كأن بيانات الوكلاء غائبة،
  وسمح بخريطة READY عند `0/5` مؤهلين.
- بوابة تنفيذ المخطط تستخدم الآن محرك Entry/Thesis المشترك نفسه، وأُلغي override
  الخاص الذي كان يسمح لوكيلين بلا Macro/Gemini.
- Telegram يعرض وزن كل وكيل وحالة `QUALIFIED/NOT QUALIFIED`، ويفصل بوضوح بين:
  Map quality وAuthority وExecution admission.
- مصدر البيانات المشترك يظهر مرة واحدة في البطاقة، ولا تُكرر أسماء الفريمات
  بجانب Unified Trend أو أي وكيل آخر.
- خريطة Telegram تُحجب في التشغيل الفعلي إذا لم ينجح shared execution admission.
- لا تُعاد المعايرة في هذا الإصلاح؛ ملفات المعايرة وقاعدة Auction الحالية تُستخدم كما هي.

## الاختبارات

```text
1800 collected
1797 passed
3 skipped
1 warning قديم عن datetime.utcnow()
```

---

# التحويل الكامل إلى Unified Trend + Auction Flow — 2026-08-12

## الحالة

هذه جولة تنفيذ واحدة تحوّل نظام `Nabil-gold` على `demo/mt5` مباشرة إلى خمسة
وكلاء أساسيين. لا يوجد Shadow ولا تشغيل متوازٍ للوكيلين القديمين.

## كتاب الوكلاء النهائي

| المفتاح | الاسم | الوزن |
|---|---|---:|
| `unified_trend` | Unified Trend / وكيل أدلة الاتجاه الموحد | 20% |
| `classical` | Classical / الوكيل الكلاسيكي | 25% |
| `smc` | SMC / وكيل الأموال الذكية | 20% |
| `price_action` | Price Action / وكيل حركة السعر | 20% |
| `auction_flow` | Auction Flow / وكيل تدفق المزاد | 15% |

المجموع `100%`. أُزيل `technical` و`multitimeframe` من التشغيل والتصويت، لكن
تبقى أسماؤهما قابلة للقراءة فقط عند Replay لسجلات تاريخية قديمة.

## كل الوكلاء يقرأون الفريمات الأربعة

تجلب `MarketDataService` كتاباً واحداً مجمداً من MT5 مرة واحدة في الدورة:

```text
M5  → MT5 TIMEFRAME_M5
M15 → MT5 TIMEFRAME_M15
H1  → MT5 TIMEFRAME_H1
H4  → MT5 TIMEFRAME_H4
```

- كل فريم يُجلب أصلياً بصورة مستقلة.
- لا يُشتق M15/H1/H4 من M5.
- كل واحد من الوكلاء الخمسة يقرأ `5m/15m/1H/4H`.
- كل وكيل يصدر اتجاهاً واحداً وثقة واحدة وصوتاً واحداً.
- لا يقوم كل وكيل باتصال API منفصل؛ الجميع يقرأون اللقطة نفسها، لمنع اختلاف
  الأسعار واستهلاك الحصة.
- إذا نقص فريم أصلي في تشغيل VPS، يفشل الوكيل إلى `WAIT 0` ولا يصنع فريماً.

## Unified Trend

يحسب مباشرة، على كل فريم:

- EMA family.
- Swing structure.
- Price momentum.
- MACD histogram/slope.
- RSI14/RSI7/divergence.

تُطبع المسافات بوحدة ATR، ثم تُوحّد كل Feature إلى `-1..+1` بواسطة Signed
Historical Percentile. تُدمج العائلات بالتساوي، ويُحسب:

```text
UnifiedEdge = BaseEdge × Coherence × Coverage
```

ثم تُحوّل قوة Edge إلى ثقة واحدة بواسطة معايرة Logistic تاريخية monotonic.
لا توجد ثقة Technical ولا ثقة MTF ولا متوسط 57/43.

## Classical وSMC وPrice Action

كل وكيل يشغّل منطقه الأصلي بصورة مستقلة على M5/M15/H1/H4، ثم يدمج اتجاهات
الفريمات إلى صوت واحد بتساوٍ، مع عقوبة تلقائية عند اختلاف الفريمات. التفاصيل
التنفيذية الغنية (المناطق والأنماط والـPOI) تبقى من M15، بينما الاتجاه والثقة
النهائيان يعكسان الكتاب الكامل.

## Auction Flow

Tick Manager المجدول نفسه يجمع Tick من `XAUUSD.s` حتى عندما لا توجد صفقة
مفتوحة؛ لا توجد عملية Tick ثانية.

يستخدم الوكيل:

- Up/Down Tick imbalance لآخر 60 ثانية و5 دقائق.
- Tick arrival/activity.
- السبريد كحارس جودة فقط.
- Session VWAP.
- POC / VAH / VAL.
- Initiative acceptance.
- Responsive rejection.
- موقع إغلاق كل فريم أصلي M5/M15/H1/H4 بالنسبة إلى VWAP/POC.

التخزين:

```text
storage/auction_flow.sqlite3
SQLite/WAL
ثوانٍ: 7 أيام
دقائق: 90 يوماً
```

لا توجد فترة انتظار بعد التثبيت. أمر التثبيت يجلب 30 يوماً من Tick history،
يبني الجلسة الحالية والمعايرة، ثم يفعّل النظام. إذا لم يوفر MT5 البيانات
الكافية يفشل التثبيت ويعيد النسخة السابقة.

## الثقة والمعايرة

يبني المثبت ملفين محليين:

```text
storage/model_calibration/unified_trend_v1.json
storage/model_calibration/auction_flow_v1.json
```

المعايرة تستخدم حواجز متناظرة:

```text
±1 ATR على M15
أفق 16 شمعة M15 = 4 ساعات
```

الحد الأدنى:

```text
Unified Trend: 500 نتيجة محسومة
Auction Flow:  300 نتيجة محسومة
```

ملفات المعايرة لها checksum. عند فقدها أو تلفها يكون الوكيل `WAIT 0`، ولا
يُستخدم رقم ثقة يدوي بديل في التشغيل الفعلي.

## قواعد القبول التي لم تتغير

```text
Path 1: ثلاثة وكلاء مؤهلين + net weighted confidence >=72%
Path 2: وكيلان مؤهلان + Macro بنفس الاتجاه >=55%
Path 3: وكيلان مؤهلان + Gemini بنفس الاتجاه >=70%
agent_min_confidence = 67%
```

- نفس الكتاب والأوزان والعتبات تُستخدم في Entry وThesis Exit.
- Macro وGemini تأكيدان خارجيان، وليسا من الوكلاء الخمسة.
- News وRisk حارسان، وليسا صوتين.
- Opposite Entry يبقى Broker-first: تُغلق الصفقة القديمة على MT5 قبل الجديدة.
- SL/TP/BE/Trailing/TP1 partial وقانون actual-fill stop لا تتغير.
- REAL account مرفوض.

## Telegram

تظهر الأسماء الجديدة فقط في الرسائل الجديدة:

```text
🧭 Unified Trend
Classical
SMC
Price Action
🌊 Auction Flow
```

وتظهر لـUnified Trend قيمة Edge وCoherence، ولـAuction Flow حالته مثل
`Initiative Acceptance` أو `Responsive Rejection`. تبقى:

- البادئة `🧪 DEMO ·`.
- Broker-first delivery.
- actual fill.
- SQLite dedup.
- خرائط READY فقط.

## اللوحة المحلية

تعرض اللوحة الوكلاء الخمسة والأوزان الجديدة، وتشرح Unified Trend وAuction
Flow. تبقى الواجهة GET-only، ولا تعرض Tick خاماً أو `.env` أو أسرار MT5 أو
Telegram.

## التثبيت — ZIP واحد وأمر واحد

1. انسخ ZIP النهائي إلى VPS وفكّه في مجلد مستقل.
2. افتح PowerShell كمسؤول داخل المجلد المفكوك.
3. نفّذ فقط:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File ".\INSTALL.ps1"
```

السكريبت:

- يكتشف تلقائياً محاولة v1 غير مكتملة (ملفات جديدة بلا معايرة)، ويستعيد آخر
  Backup وحالات المهام أولاً قبل إعادة المحاولة.
- يعزل اختبارات VPS عن `.env` ومتغيرات Telegram/MT5 الحية، ثم يعيد بيئة Demo
  قبل بناء المعايرة؛ فلا تدخل الاختبارات مسار Broker-first ولا تكتب MagicMock
  في سجل الصفقات.
- يرفض أي حساب غير Demo.
- يحفظ Backup وTask state.
- يوقف Scheduled writers مؤقتاً.
- ينسخ الدفعة كاملة.
- يشغّل الاختبارات.
- يجلب M5/M15/H1/H4 الأصلية وTick history.
- يبني المعايرتين قبل التفعيل.
- يشغّل Tick Manager من Task Scheduler فقط.
- يشغّل Dashboard API ودورة Analysis مجدولة.
- يتحقق من Entry/Exit وTelegram واللوحة.
- يتراجع تلقائياً عند أي فشل.

لا يحتاج Restart للـVPS في الحالة الطبيعية.

## نتائج الاختبار المحلي قبل الحزمة

```text
1800 collected
1797 passed
3 skipped
1 warning قديم عن datetime.utcnow()
```
