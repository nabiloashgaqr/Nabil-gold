# Nabil-gold — أحدث Snapshot آمنة لمراجعة الوكلاء الخمسة

تاريخ الإنشاء: 2026-08-13

هذه نسخة Source كاملة من حالة العمل الأحدث على فرع `demo/mt5`، مبنية فوق commit:

```text
e1c6743 Add files via upload
```

تشمل أحدث تعديلات:

- الكتاب الموحد لخمسة وكلاء.
- Shared native MT5 snapshot لـM5/M15/H1/H4.
- Unified Trend وAuction Flow والثقة الواحدة 50..95.
- `graded_auction_v2`.
- Entry/Thesis Exit parity.
- Planner execution admission truth.
- خرائط `MONITORING ONLY` بوكيلين دون صلاحية تنفيذ.
- SMC conditional-map display.
- فصل L1/L2 كمراجع سيولة عن TP1/TP2 التنفيذية.
- اختبارات الأمان والتدقيق الحسابي.

آخر تشغيل اختبارات كامل قبل Snapshot:

```text
1827 collected
1824 passed
3 skipped
1 warning قديم عن datetime.utcnow()
```

## بنية الملف

```text
Nabil-gold/       المصدر والإعدادات والاختبارات وملفات النشر
review_evidence/  تقارير تشغيل حقيقية وصورة المحلل اليدوي
SNAPSHOT_METADATA.json
SHA256SUMS.json
README_SNAPSHOT_AR.md
```

## ما تم استبعاده أمنياً وتشغيلياً

- `.env` وأي credentials.
- `.git`.
- `storage/auction_flow.sqlite3` وقواعد SQLite/WAL/SHM.
- الصفقات وسجلات التشغيل وheartbeat وPID.
- ملفات calibration الفعلية الخاصة بالـVPS (غير متاحة في Source المحلي).
- `rounds/` والحزم السابقة.
- `logs/`, `reports/`, `diagnostics/` runtime.
- caches و`__pycache__` و`.pyc`.

أُبقيت فقط analyst-label fixtures الآمنة اللازمة لتشغيل الاختبارات تحت `storage/`.

## ملاحظة مهمة للمراجع

ملفات `review_evidence/*.json` هي المرجع الرقمي للتشغيل الفعلي. لا تفترض أن
وجود source أو test يعني صحة السلوك؛ أعد الحساب بصورة مستقلة واذكر أي شيء لا
يمكن إثباته بسبب استبعاد Runtime DB أو calibration coefficients.
