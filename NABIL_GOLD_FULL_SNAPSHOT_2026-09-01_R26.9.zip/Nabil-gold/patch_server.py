import os
import sys

# 1. PriceActionAgent _r scope fix
pa_file = os.path.join("agents", "price_action_agent.py")
if os.path.exists(pa_file):
    txt = open(pa_file, "r", encoding="utf-8").read()
    txt = txt.replace('"level": _r(level) if level else None,', '"level": self._rp(level) if level else None,')
    open(pa_file, "w", encoding="utf-8").write(txt)
    print("✅ Fixed PriceActionAgent _r scope.")

# 2. conftest.py root & tests/conftest.py
open("conftest.py", "w", encoding="utf-8").write(
    "import os, sys\n_ROOT = os.path.dirname(os.path.abspath(__file__))\nif _ROOT not in sys.path:\n    sys.path.insert(0, _ROOT)\n"
)
tc_file = os.path.join("tests", "conftest.py")
if os.path.exists(tc_file):
    tc_txt = open(tc_file, "r", encoding="utf-8").read()
    if "_ROOT" not in tc_txt:
        inject = "import os, sys\n_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))\nif _ROOT not in sys.path:\n    sys.path.insert(0, _ROOT)\n"
        tc_txt = inject + tc_txt
        open(tc_file, "w", encoding="utf-8").write(tc_txt)
print("✅ Fixed pytest Windows path imports (conftest.py).")

# 3. test_multi_instrument_forex_parity.py
p1 = os.path.join("tests", "test_multi_instrument_forex_parity.py")
if os.path.exists(p1):
    t1 = open(p1, "r", encoding="utf-8").read()
    if "_ROOT" not in t1 and "sys.path.insert" not in t1:
        patch = "import os, sys\nsys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))\n"
        t1 = patch + t1
        open(p1, "w", encoding="utf-8").write(t1)
    print("✅ Fixed test_multi_instrument_forex_parity.py imports.")

# 4. test_gemini_signal_visibility.py
p2 = os.path.join("tests", "test_gemini_signal_visibility.py")
if os.path.exists(p2):
    t2 = open(p2, "r", encoding="utf-8").read()
    t2 = t2.replace(
        'service = TelegramService({"telegram": {"bot_token": None, "chat_id": None}})',
        'service = TelegramService({"telegram": {"bot_token": None, "chat_id": None}, "llm_review": {"status_cache_path": "storage/llm/non_existent_cache_test.json"}})'
    )
    open(p2, "w", encoding="utf-8").write(t2)
    print("✅ Fixed test_gemini_signal_visibility.py cache isolation.")

print("\n🎉 All patches applied successfully!")
