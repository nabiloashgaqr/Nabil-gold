#Requires -Version 5.1
<#
.SYNOPSIS
    BUILD 31 R11 LOCAL-ONLY - one paste-and-run patch for C:\Nabil-gold.
.DESCRIPTION
    Needs NOTHING else (no zip, no download). Copy this file into
    C:\Nabil-gold next to APPLY_R11_PATCH.py and run:

        powershell -NoProfile -ExecutionPolicy Bypass -File .\APPLY_R11_LOCAL_ONLY.ps1

    It: deletes every GitHub/Supabase/Vercel artifact, switches config.json
    to the local database, BACKS UP and sanitizes the live .env (stale
    SUPABASE_ keys would still route storage to the cloud!), fixes the two
    R10 tests that failed on a live checkout, auto-migrates storage\shadow,
    then runs compile sanity + the FULL pytest suite. Idempotent.
#>
$ErrorActionPreference = "Continue"

$Repo = "C:\Nabil-gold"
if (-not (Test-Path (Join-Path $Repo "config.json"))) { $Repo = (Get-Location).Path }
if (-not (Test-Path (Join-Path $Repo "config.json"))) {
    Write-Host "[FAIL] config.json not found - run from C:\Nabil-gold." -ForegroundColor Red
    Exit 1
}
Set-Location $Repo
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host " BUILD 31 R11 - LOCAL-ONLY PATCH  (repo: $Repo)" -ForegroundColor Cyan
Write-Host "==============================================================" -ForegroundColor Cyan

# ---- 1) delete cloud-era artifacts ------------------------------------------
$dirs  = @(".github", "api", "dashboard\api")
$files = @(
  "deploy\GITHUB_SHUTDOWN_AR.md",
  "INSTALL_AUTO_UPDATER.bat", "deploy\install_auto_updater.ps1", "deploy\tasks\auto_update.bat",
  "scripts\migrate_supabase_to_local.py", "tests\test_local_migration.py",
  "tests\test_dashboard_api_leak.py",
  "SUPABASE_VERIFICATION_CHECKLIST.sql", "FIX_BACKFILL_CLOSED_AT.sql",
  "FIX_EXIT_WARNING_COLUMN_TYPE.sql", "PHASE6_ANALYST_DISTILLATION_MIGRATION.sql",
  "VERIFY_ALL_COLUMNS.sql", "supabase_schema_unified.sql", "deploy\trades_demo.sql",
  "tests\test_exit_warning_column_is_text.py", "tests\test_schema_has_partial_booking_columns.py",
  "subscription_bot\supabase_schema.sql"
)
$removed = 0
foreach ($d in $dirs) {
  $p = Join-Path $Repo $d
  if (Test-Path $p) { Remove-Item $p -Recurse -Force -ErrorAction SilentlyContinue; $removed++ }
}
foreach ($f in $files) {
  $p = Join-Path $Repo $f
  if (Test-Path $p) { Remove-Item $p -Force -ErrorAction SilentlyContinue; $removed++ }
}
Write-Host "[OK] step 1: cloud artifacts deleted ($removed items)." -ForegroundColor Green

# ---- 2) surgical patches ------------------------------------------------------
$patcher = Join-Path $Repo "APPLY_R11_PATCH.py"
if (-not (Test-Path $patcher)) {
    Write-Host "[FAIL] APPLY_R11_PATCH.py not found next to this script." -ForegroundColor Red
    Exit 1
}
python $patcher
$patchRc = $LASTEXITCODE

# ---- 3) compile sanity + FULL test suite --------------------------------------
Write-Host ""
Write-Host "==> compile sanity..." -ForegroundColor Cyan
python -m compileall -q . 2>$null
Write-Host "==> FULL pytest suite..." -ForegroundColor Cyan
python -m pytest tests -q --tb=short -p no:cacheprovider
$tests = $LASTEXITCODE

Write-Host ""
Write-Host "==============================================================" -ForegroundColor Cyan
if ($patchRc -eq 0 -and $tests -eq 0) {
    Write-Host "[DONE] R11 LOCAL-ONLY applied. Patches OK + full suite green." -ForegroundColor Green
} else {
    Write-Host "[ATTENTION] patches=$patchRc tests=$tests - read the output above." -ForegroundColor Yellow
}
Write-Host "==============================================================" -ForegroundColor Cyan
