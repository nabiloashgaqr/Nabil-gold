@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ============================================================
echo   R26 - Bawwabat al-indibaat + taqrir al-masarat
echo ============================================================
echo.
set "PY="
where py >nul 2>nul && set "PY=py"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo [X] Python unavailable. Run manually: py APPLY_R26_DISCIPLINE_GATES.py --apply
  echo.
  pause
  exit /b 1
)
%PY% APPLY_R26_DISCIPLINE_GATES.py --apply
echo.
pause
