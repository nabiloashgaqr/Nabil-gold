# BUILD 31 R10 - run the full test suite from PowerShell:  .\RUN_ALL_TESTS.ps1
& powershell -NoProfile -ExecutionPolicy Bypass -File "$PSScriptRoot\scripts\run_all_tests.ps1"
