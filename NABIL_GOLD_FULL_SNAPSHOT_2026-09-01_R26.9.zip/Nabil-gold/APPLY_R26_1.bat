@echo off
setlocal enableextensions
title R26.1 Harmonization
cd /d "%~dp0"

REM TARGET keeps its trailing backslash for path joins; TGTDIR strips it so a
REM quoted argument never ends with a backslash (which would escape the quote).
set "TARGET=%~dp0"
set "TGTDIR=%TARGET:~0,-1%"

echo ============================================================
echo   R26.1 per-symbol stop harmonization
echo   Target: %TARGET%
echo   config.json is PATCHED in place - never replaced.
echo ============================================================
echo.

REM ---- locate a Python interpreter ----
set "PYEXE="
where py >nul 2>nul
if not errorlevel 1 set "PYEXE=py -3"
if not defined PYEXE (
    where python >nul 2>nul
    if not errorlevel 1 set "PYEXE=python"
)
if not defined PYEXE goto :nopython

echo Using Python: %PYEXE%
echo.

REM ---- stage in TEMP so the payload folder is not scanned by
REM      the on-tree integrity tests ----
set "STG=%TEMP%\r26_1_stage"
if exist "%STG%" rmdir /s /q "%STG%"
mkdir "%STG%"
copy /y "%TARGET%APPLY_R26_1_harmonization.py" "%STG%" >nul
xcopy /e /i /q /y "%TARGET%R26_1_HARMONIZATION" "%STG%\R26_1_HARMONIZATION" >nul

%PYEXE% "%STG%\APPLY_R26_1_harmonization.py" --target "%TGTDIR%" --payload "%STG%\R26_1_HARMONIZATION"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (goto :success) else (goto :failed)

:success
echo ============================================================
echo   [OK] Applied and verified. Cleaning payload folder...
echo ============================================================
if exist "%TARGET%R26_1_HARMONIZATION" rmdir /s /q "%TARGET%R26_1_HARMONIZATION"
echo Done. Restart the analysis bot.
echo.
echo Optional full test:   python -m pytest tests/ -q
goto :end

:failed
echo ============================================================
echo   [FAILED] exit code %RC% - no files were deleted.
echo   Look at the backup folder:  %TARGET%_backup_R26_1
echo ============================================================
goto :end

:nopython
echo [ERROR] Python was not found.
echo Install Python from python.org, or run manually in this folder:
echo     python APPLY_R26_1_harmonization.py
set "RC=2"

:end
echo.
pause
endlocal & exit /b %RC%
