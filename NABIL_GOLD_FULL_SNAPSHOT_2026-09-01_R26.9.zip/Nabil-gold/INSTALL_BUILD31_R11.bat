@echo off
REM BUILD 31 R11 LOCAL-ONLY one-click installer (extract + clean cloud artifacts + patch + full tests).
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy\install_build31_r11.ps1"
pause
