# -*- coding: utf-8 -*-
"""BUILD31-R13: merge the per-symbol spread caps into an EXISTING config.json.

The operator's production config.json may carry local tweaks (telegram ids,
risk numbers) - it must NEVER be overwritten wholesale. This merge only adds
filters.max_spread_points_by_symbol (with description) when absent, and
otherwise leaves every existing key untouched. Idempotent: safe to re-run.
"""
import argparse
import json
import sys
from collections import OrderedDict
from pathlib import Path

# Default target: a project tree one level above this script. The R12+R13
# COMPLETE installer passes --root explicitly (the script may live inside an
# extracted package folder, not inside C:\Nabil-gold).
ROOT = Path(__file__).resolve().parents[1]

DESCRIPTION = (
    "BUILD31-R13 (2026-08-27): per-symbol spread caps in CONFIG POINTS. "
    "The single global max_spread_points=5 was gold-calibrated ($0.50) but on "
    "5-digit forex a point is 0.1 pip, so a normal 0.6-1.5 pip spread = 6-15 "
    "points and SPREAD_GUARD vetoed every forex entry (zero forex trades while "
    "gold/oil traded). Values here are ceilings ~2.5-3 pips on forex: they only "
    "block genuinely abnormal spreads. Unlisted symbols fall back to the legacy "
    "global max_spread_points."
)

CAPS = OrderedDict([
    ("XAU/USD", 5.0),
    ("WTI/USD", 8.0),
    ("EUR/USD", 25.0),
    ("GBP/USD", 30.0),
    ("USD/CAD", 30.0),
    ("USD/JPY", 25.0),
])


def main():
    ap = argparse.ArgumentParser(description="Merge R13 per-symbol spread caps into config.json")
    ap.add_argument("--root", default=None,
                    help="project root containing config.json (default: parent of this script)")
    args = ap.parse_args()
    root = Path(args.root) if args.root else ROOT
    path = root / "config.json"
    if not path.exists():
        print("FAIL: config.json not found at %s" % path)
        return 1
    cfg = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=OrderedDict)
    filters = cfg.get("filters")
    if not isinstance(filters, dict):
        filters = OrderedDict()
        cfg["filters"] = filters
    if "max_spread_points_by_symbol" in filters:
        print("SKIP: filters.max_spread_points_by_symbol already present - nothing changed.")
        return 0
    merged = OrderedDict()
    for symbol, cap in CAPS.items():
        merged[symbol] = cap
    merged["description"] = DESCRIPTION
    filters["max_spread_points_by_symbol"] = merged
    path.write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("OK: added filters.max_spread_points_by_symbol ->")
    for symbol, cap in CAPS.items():
        print("      %s = %s" % (symbol, cap))
    return 0


if __name__ == "__main__":
    sys.exit(main())
