# -*- coding: utf-8 -*-
"""
APPLY_R26_DISCIPLINE_GATES.py — تطبيق بوابات الانضباط + تقرير المسارات الأسبوعي.

الملفات:
  services/admission_discipline_gates.py   (جديد) بوابات نقية قابلة للاختبار
  scripts/run_analysis.py                  (معدّل) ربط البوابات بمدقّق الإشارة
  scripts/weekly_path_report.py            (جديد) تقرير أداء أسبوعي لكل مسار
  tests/test_r26_discipline_gates.py       (جديد) اختبارات

إضافة الإعدادات: تُدمج كتلة discipline_gates في config.json الحي (دمجًا على
مستوى المفاتيح، لا استبدال للملف) حتى تُحفظ قيم المشغّل الأخرى كلها.

البوابات fail-open ويمكن إطفاؤها كلها بـ discipline_gates.enabled=false.
آمن لإعادة التشغيل (المطابق لا يُنسخ، والمختلف يُؤخذ له نسخ احتياطي).

    python APPLY_R26_DISCIPLINE_GATES.py            # معاينة
    python APPLY_R26_DISCIPLINE_GATES.py --apply     # تطبيق + اختبارات
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent

NEW_FILES = [
    "services/admission_discipline_gates.py",
    "scripts/weekly_path_report.py",
    "tests/test_r26_discipline_gates.py",
]
EDITED_FILES = [
    "scripts/run_analysis.py",
    # R25.9 engine files, re-shipped with the read-only-DB test fix so a
    # single apply brings the tick manager + auction store fully current.
    "scripts/run_tick_manager.py",
    "services/auction_flow_store.py",
]
ALL_FILES = NEW_FILES + EDITED_FILES

DISCIPLINE_BLOCK = {
    "enabled": True,
    "macro_block_conf": 70.0,
    "trend_family_keys": ["technical", "mtf", "classical", "price_action"],
    # stop-band / hard-R:R vetoes stay OFF by default (the liquidity planning
    # law sets the stop and the final validator enforces R:R with scalp floors).
    "enforce_stop_band": False,
    "enforce_rr_floor": False,
    "stop_band_default": {"min_points": 230.0, "max_points": 400.0},
    "stop_band_by_symbol": {
        "XAU/USD": {"min_points": 270.0, "max_points": 400.0}
    },
    "thesis_exit_loss_cap_usd": 100.0,
}


def _sha(p: Path) -> str | None:
    try:
        return hashlib.sha256(p.read_bytes()).hexdigest()
    except OSError:
        return None


def resolve_target(cli_target: str | None) -> Path:
    candidates = []
    if cli_target:
        candidates.append(Path(cli_target))
    import os
    if os.environ.get("NABIL_GOLD_ROOT"):
        candidates.append(Path(os.environ["NABIL_GOLD_ROOT"]))
    candidates.append(SCRIPT_DIR)
    for drive in ("C:", "D:", "E:"):
        candidates.append(Path(rf"{drive}\Nabil-gold"))
    for c in candidates:
        try:
            if c and (c / "config.json").exists() and (c / "services").is_dir():
                return c.resolve()
        except OSError:
            continue
    return SCRIPT_DIR


def merge_discipline_config(dst_root: Path, apply: bool) -> str:
    cfg_path = dst_root / "config.json"
    if not cfg_path.exists():
        return "تعذّر العثور على config.json — أُضيفت كتلة الإعدادات يدويًا لاحقًا."
    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return f"تعذّر قراءة config.json ({exc}) — راجع الملف."
    existing = cfg.get("discipline_gates")
    if isinstance(existing, dict) and existing.get("enabled") is not None:
        # keep operator values; only fill missing keys
        merged = dict(DISCIPLINE_BLOCK)
        merged.update(existing)
        if merged == existing:
            return "كتلة discipline_gates موجودة بالفعل — لم تُمسّ."
        if apply:
            cfg["discipline_gates"] = merged
            cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2),
                                encoding="utf-8")
        return "حُدّثت مفاتيح ناقصة داخل discipline_gates (قيمك محفوظة)."
    if apply:
        cfg["discipline_gates"] = DISCIPLINE_BLOCK
        cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2),
                            encoding="utf-8")
    return "أُضيفت كتلة discipline_gates إلى config.json (دمج، لا استبدال)."


def run_project_tests(dst_root: Path) -> int:
    test_file = dst_root / "tests" / "test_r26_discipline_gates.py"
    if not test_file.exists():
        print("⚠️  ملف الاختبار غير موجود — تخطّي.")
        return 0
    print("=" * 70)
    print("   تشغيل اختبارات R26 من داخل المشروع ...")
    print("=" * 70)
    try:
        proc = subprocess.run([sys.executable, "-m", "pytest",
                               "tests/test_r26_discipline_gates.py", "-q"],
                              cwd=str(dst_root))
        return proc.returncode
    except FileNotFoundError:
        print("⚠️  تعذّر تشغيل pytest. شغّل يدويًا من C:\\Nabil-gold:")
        print("   python -m pytest tests/test_r26_discipline_gates.py -q")
        return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="R26 discipline gates applier")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--target", default=None)
    ap.add_argument("--no-test", action="store_true")
    args = ap.parse_args()

    dst_root = resolve_target(args.target)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = dst_root / "backup" / f"r26_{stamp}"

    print("=" * 70)
    print("R26 — بوابات الانضباط + تقرير المسارات الأسبوعي")
    print("=" * 70)
    print(f"المصدر: {SCRIPT_DIR}\nالوجهة: {dst_root}")
    print(f"الوضع: {'تطبيق فعلي' if args.apply else 'معاينة جافة'}")
    print()

    missing, copied, replaced, already = [], 0, 0, 0
    for rel in ALL_FILES:
        src, dst = SCRIPT_DIR / rel, dst_root / rel
        if not src.exists():
            missing.append(rel)
            print(f"  [MISSING] {rel}")
            continue
        if dst.exists() and _sha(src) == _sha(dst):
            already += 1
            print(f"  [مطابق]   {rel}")
            continue
        state = "استبدال" if dst.exists() else "جديد  "
        if args.apply:
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists():
                backup_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, backup_dir / Path(rel).name)
            shutil.copy2(src, dst)
            if dst.exists() and state == "استبدال":
                replaced += 1
            else:
                copied += 1
        print(f"  [{state}] {rel}")

    cfg_msg = merge_discipline_config(dst_root, args.apply)
    print(f"\n  الإعدادات: {cfg_msg}")

    if missing:
        print(f"\n⚠️  نواقص: {missing}")
    if args.apply:
        print(f"\n✅ الجديد: {copied} | المستبدَل: {replaced} | المطابق: {already}")
        if replaced:
            print(f"   النسخ الاحتياطي: {backup_dir}")
        if not args.no_test and (dst_root / "config.json").exists():
            print()
            rc = run_project_tests(dst_root)
            print("\n✅ الاختبارات ناجحة." if rc == 0 else "\n⚠️  اختبارات فاشلة — أرسل المخرجات.")
        print("\n   بعدها:")
        print("   - أعد تشغيل خدمة التحليل/المُجمِّع.")
        print("   - تقرير أسبوعي:  python scripts/weekly_path_report.py --days 7 --save")
    else:
        print("\nمعاينة فقط. للتطبيق: انقر APPLY_R26.bat أو:")
        print("   python APPLY_R26_DISCIPLINE_GATES.py --apply")
    return 1 if missing else 0


if __name__ == "__main__":
    sys.exit(main())
