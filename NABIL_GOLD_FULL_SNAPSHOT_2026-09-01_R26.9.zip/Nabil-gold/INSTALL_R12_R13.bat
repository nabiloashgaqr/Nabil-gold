@echo off
REM Nabil-gold R12+R13 COMPLETE installer - double-click entry point.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_R12_R13.ps1"
echo.
pause
