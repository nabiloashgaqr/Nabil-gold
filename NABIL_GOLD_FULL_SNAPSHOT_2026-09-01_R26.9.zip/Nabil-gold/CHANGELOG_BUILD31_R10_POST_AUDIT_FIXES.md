# 📄 سجل إصلاحات ما بعد التدقيق المستقل (BUILD 31 - R10)
**SmartSignal Trading System — Post-Forensic-Audit Fix Release**
*تاريخ الإصدار: 2026-08-27 | مبني فوق BUILD 31 - R9*

---

## 🎯 ملخص الإصدار
بعد مراجعة جنائية مستقلة شاملة لإصدار R9 (قراءة كود + تشغيل حزمة الاختبارات 2,584 اختباراً في بيئة معزولة)، طُبّقت كافة التصويبات التالية بدقة. كل بند هنا مرتبط بملاحظة من تقرير المراجعة، وكل إصلاح مُثبَّت باختبار في `tests/test_build31_r10_post_audit_fixes.py` (20 اختباراً) وبأداة تدقيق ذاتي `scripts/verify_r10_fixes.py` (14 فحصاً).

---

## 🛠️ الإصلاحات المطبقة كاملة

### 1️⃣ إعادة قابلية استنساخ حزمة الاختبارات (توثيق R9 كان يفشل):
- **المشكلة:** اختبار `test_subscription_cron_every_4_hours` يقرأ `.github/workflows/subscription_cron.yml` المحذوف من المشروع (مع إيقاف تكامل GitHub) ⇒ فشل واحد لا يُستنسخ من الحزمة المشحونة رغم وعد "0 failures".
- **الإصلاح:** الاختبار يتخطى الآن بـ `pytest.skip` موثق عند غياب شجرة GitHub، مع بقاء فحص الجدولة على مصادر config/deploy.
- **الملفات:** `tests/test_build16_telegram_polish.py`

### 2️⃣ حارس الساعات الهادئة — الساعة هي مصدر الحقيقة الوحيد:
- **المشكلة:** الحارس (21:00–06:30 UTC) كان يقرأ تسمية الجلسة أولاً، فتسمية "London" الخاطئة من وكيل الجلسات كانت تعطّل الحارس بصمت أثناء النافذة الهادئة الفعلية.
- **الإصلاح:** نافذة الهادئة تُحسب من ساعة UTC دائماً (مع تحويل واعٍ للمنطقة الزمنية)، وتسميات الجلسات (Asia/quiet/night/rollover) لا تُوسّع الحظر إلا ولا تُضيّقه أبداً.
- **الملفات:** `agents/decision_agent.py`

### 3️⃣ رفع عتبة حارس التدفق المؤسسي (Fito المؤشر المنفرد) 55% → 65%:
- **المشكلة:** "التأكيد الهيكلي" للاختراقات كان بـ 55% فقط — أضعف من عتبة عضو التصويت العادي (67/65%).
- **الإصلاح:** العتبة أصبحت `institutional_flow_min_confidence = 65` في `config.json`، والكود يقرأها (ويسقط افتراضياً إلى `agent_min_confidence`)، ورسالة الرفض تعرض العتبة صراحة (`>= 65%`).
- **الملفات:** `agents/decision_agent.py`، `config.json`

### 4️⃣ مفتاح إيقاف وضع الظل على مستوى الكود (Shadow Kill-Switch):
- **المشكلة:** ادعاء R9 "إزالة وضع الظل بالكامل" كان تعطيلاً إعدادياً فقط؛ خطأ config واحد يُعيد الظل لأي أصل.
- **الإصلاح:** `services/shadow_mode.py` يعيد الآن "لا ظل" إلزامياً (`is_shadow_config` → False و`shadow_instruments` → []) ما لم يُصدِّر المشغل `NABIL_ENABLE_SHADOW=1` صراحة. آليات الظل الداخلية (ShadowDatabase/Telegram) تبقى قابلة للاختبار تحت المفتاح نفسه.
- **أرشفة البيانات:** شجرة `storage/shadow/{eurusd,gbpusd,usdcad,usdjpy}` القديمة نُقلت إلى `storage/archive/shadow_20260827/` — الشجرة الحية نظيفة.
- **الملفات:** `services/shadow_mode.py`، `tests/test_shadow_mode_wti.py`، أرشفة بيانات

### 5️⃣ قفل ساعة التعلم الذاتي على Asia/Hebron:
- **المشكلة:** خدمة التعلم كانت تختم وتستعلم داخلياً بـ UTC بينما التقارير والجدولة على توقيت الخليل — ازدواجية حدود "اليوم".
- **الإصلاح:** مساعد `hebron_now()` موحّد (ZoneInfo) حلّ محل كل `datetime.now(timezone.utc)` الأربعة، و`timezone` أُزيل من الواردات، و`tzdata` أُضيف لـ requirements (قاعدة IANA لويندوز).
- **الملفات:** `services/learning_service.py`، `requirements.txt`

### 6️⃣ توحيد توثيق التوقيت والقضاء على بقايا "23:00 UTC / GitHub Actions":
- **المشكلة:** نسخة BAT الجذرية للتقرير اليومي كانت ما زالت تكتب "23:00 UTC"، وdocstring التقرير اليومي ما زال يقول "يعمل عبر GitHub Actions" الموقوف.
- **الإصلاح:** التوثيق محدّث إلى "SS_DailyReport عبر Windows Task Scheduler الساعة 23:50 Asia/Hebron".
- **الملفات:** `scripts/run_daily_report.py`

### 7️⃣ مصدر حقيقة واحد لملفات BAT (إلغاء الانزياح البنيوي):
- **المشكلة:** 11 نسخة جذرية من BAT انحرفت عن نسخ `deploy/tasks` (تعليقات قديمة، وفقدان `FORCE_WEEKLY_REPORT=true` في الأسبوعي — عيب تشغيلي حقيقي).
- **الإصلاح:** كل نسخة جذرية صارت **مفوِّضة** (`call "%~dp0deploy\tasks\..."`) — لا منطق مكرر بعد اليوم، وأي تشغيل من الجذر يطابق مجدول المهام حرفياً.
- **الملفات:** `daily_report_demo.bat`، `weekly_report_demo.bat`، `macro_demo.bat`، `demo_analysis.bat`، `demo_loop.bat`، `demo_smoke.bat`، `demo_watchdog.bat`، `dashboard_demo.bat`، `market_status.bat`، `subscription_bot.bat`، `tick_manager.bat`

### 8️⃣ جدولة آمنة ضد التوقيت الصيفي (DST):
- **المشكلة:** `fix_daily_report_timezone.ps1` كان يسقط إلى منطقة UTC+3 **ثابتة** تضل ساعة كاملة كل شتاء (الخليل UTC+2 شتاءً).
- **الإصلاح:** حذف البديل الثابت كلياً؛ المحاولة الأولى `Jordan Standard Time` (الأقرب لقواعد الخليل) ثم `Middle East Standard Time`، وفشل صاخب (Exit 1) برسالة واضحة إن لم توجد أي منهما — لا جدولة صامتة خاطئة.
- **الملفات:** `scripts/fix_daily_report_timezone.ps1`

### 9️⃣ لوحة التحكم — اكتمال محرك الدقة للأزواج الستة:
- **المشكلة:** لوحة تفاصيل اليوم المنبثقة كانت تعرض الأسعار بـ `toFixed(2)` ثابت وأعمدة SL/TP1 خاماً (اليورو يظهر 1.09 بدل 1.08543)، والنصوص التسويقية ما زالت "يركّز حالياً على الذهب".
- **الإصلاح:** الدرج كله يستخدم `formatTradePrice` (JPY=3، FX=5، золото/نفط=2) لكل الأعمدة، والنصوص محدّثة للغة الأصول الستة (عربي/إنجليزي) في العنوان والمزايا وقائمة الاشتراك.
- **الملفات:** `dashboard/app.js`، `dashboard/index.html`

### 🔟 إصلاح رسائل حارس الشراء-من-القيعان للفوركس:
- **المشكلة:** رسائل الرفض كانت تنسق بـ `.2f` ثابت.
- **الإصلاح:** مساعد `_fmt` يستخدم محرك الدقة لكل زوج (`format_price`) داخل `_cross_path_distance_check`.
- **الملفات:** `scripts/run_analysis.py`

### 1️⃣1️⃣ تحويل النسخ الجذرية الميتة إلى Shims مفوِّضة:
- **المشكلة:** `run_analysis.py` الجذري (نسخة قديمة تنقصها ميزات R9) و`mt5_executor.py` الجذري — ميتان لكنهما فخ انزياح.
- **الإصلاح:** شيم رقيق: الجذري ينفّذ `scripts/run_analysis.py` الكنسي (`runpy`)، و`mt5_executor` يعيد تصدير `services.mt5_executor` — تنفيذ واحد قابل للصيانة، ونقطة الدخول القديمة تعمل.
- **الملفات:** `run_analysis.py`، `mt5_executor.py`

### 1️⃣2️⃣ تصويب الأخطاء التوثيقية في سجل R9 نفسه:
- **تصويب 1:** "ذهب 400 نقطة ($4.00)" ← الصحيح **400 نقطة = $40.00** (1 نقطة = $0.10).
- **تصويب 2:** "منع الشراء عند القمم >85% / البيع <15%" ← الكود ينفذ **≥80% / ≤20%** (أكثر تحفظاً) مع حارس إضافي غير موثق: **VWAP ± 1.2×ATR**.
- **تصويب 3:** كتلة "نتائج الاختبارات" المنسقة يدوياً استُبدلت بأمر تشغيل حرفي قابل للاستنساخ ونتائج حقيقية.
- **الملف:** `CHANGELOG_BUILD31_R9_FORENSIC_FIXES.md`

---

## 🧪 التحقق (أمر حرفي قابل للاستنساخ)
```text
$ python -m pytest tests -q --tb=short -p no:cacheprovider

# نتائج ما بعد الإصلاحات (بيئة لينكس معزولة، Python 3.13):
# 2600 passed, 4 skipped, 0 failed
#   - 2580 اختباراً موروثاً ناجحاً (فشل R9 الوحيد أصبح skip موثقاً)
#   - +20 اختبار R10 الجديد (tests/test_build31_r10_post_audit_fixes.py)
#   - 3 skipped (كما في R9)

$ python scripts/verify_r10_fixes.py
# RESULT: 14/14 checks passed
```

## 🚀 التفعيل على الـ VPS
```text
RUN_ALL_TESTS.bat                          # حزمة الاختبارات كاملة بضغطة واحدة
python scripts\verify_r10_fixes.py --run-tests   # تدقيق الإصلاحات + الاختبارات معاً
```
> ملاحظة ترقية: انسخ الملفات المعدلة فوق `C:\Nabil-gold` ثم شغّل `RUN_ALL_TESTS.bat`.
> لإحياء وضع الظل لأي سبب قياسي: `set NABIL_ENABLE_SHADOW=1` (وعكسه بحذف المتغير).

---

## 🔁 إضافة R10a (بعد أول تشغيل حقيقي على الـ VPS — 2026-08-27)

أول تشغيل للفحص على سيرفر المشغل كشف أن اختبارين من R10 حصرا حالة **حزمة الشحن** (غياب `.github`، وغياب `storage/shadow`) واعتبراها قاعدة عامة، بينما مستودع السيرفر الحي مختلف ببنية عنه. التصويب:

### 1️⃣ اختبار/فحص الـ cron يتقبل الحالتين:
- إذا وُجدت `.github/workflows/subscription_cron.yml` (مستودع git حي): يُؤكَّد جدول `0 */4 * * *`.
- إذا غابت (الحزمة المشحونة): يُؤكَّد وجود منطق `pytest.skip` في اختبار build16.
- **الملفات:** `tests/test_build31_r10_post_audit_fixes.py`، `scripts/verify_r10_fixes.py`

### 2️⃣ ترحيل بيانات الظل أصبح ذاتي الإصلاح (Self-Healing):
- `verify_r10_fixes.py` (الفحص 05) يكتشف مجلدات `storage/shadow` القديمة و**يرحّلها بنفسه** إلى `storage/archive/shadow_20260827` أثناء الفحص، مع دمج ذكي عند تصادم الأسماء (ملف متطابق يحذف، مختلف يُحفظ بلاقة `_legacy_shadow`)، ثم `--no-fix` لمن أراد التدقيق الجاف فقط.
- اختبار pytest المرافق يتخطى (skip موثق) على آلة لم تُرحَّل بعد — حالة آلة ليست عيباً برمجياً — ويعود تأكيداً صارماً بعد الترحيل.
- **الملفات:** `scripts/verify_r10_fixes.py`، `tests/test_build31_r10_post_audit_fixes.py`

### 3️⃣ مثبّت بأمر واحد + نظام تحديث ذاتي بدون دخول السيرفر:
- `INSTALL_BUILD31_R10.bat` → `deploy/install_build31_r10.ps1`: يستخرج الحزمة، يثبّت tzdata، يرحّل الظل ذاتياً، يشغّل التدقيق والحزمة الكاملة — قابل لإعادة التشغيل بأمان (idempotent).
- `INSTALL_AUTO_UPDATER.bat` → `deploy/install_auto_updater.ps1` + `deploy/tasks/auto_update.bat`: مهمة `SS_AutoUpdate` كل 15 دقيقة تسحب `origin demo/mt5` بأمان (`--rebase --autostash`، فشل السحب يُسجَّل فقط ولا يمس دورة التداول أبداً). بعد تفعيلها مرة واحدة: كل تحديث مستقبلي = رفع الملفات إلى GitHub من أي مكان (حتى من هاتفك) وينزل السيرفر تلقائياً.
- `RUN_ALL_TESTS.ps1`: مدخل PowerShell لفحص الاختبارات (في PowerShell استخدم `.\RUN_ALL_TESTS.bat` أو `.\RUN_ALL_TESTS.ps1` — PowerShell لا ينفذ من المجلد الحالي بدون `.\`).
- **نتائج التحقق بعد R10a (كلتا الحالتين محاكاتان فعلياً):** حالة مستودع git حي: 14/14 + 53 اختبار منطقة اللمس خضراء؛ الحزمة المشحونة: 14/14 + **2600 passed / 4 skipped / 0 failed**.
- **الملفات:** `deploy/install_build31_r10.ps1`، `INSTALL_BUILD31_R10.bat`، `deploy/install_auto_updater.ps1`، `deploy/tasks/auto_update.bat`، `INSTALL_AUTO_UPDATER.bat`، `RUN_ALL_TESTS.ps1`

---

## 🏠 BUILD 31 R11 — الانتقال الكامل إلى المحلي (Local-Only) — 2026-08-27

**قرار المشغّل:** النظام يعمل الآن على السيرفر المحلي حصراً — تخزين محلي ولوحة تحكم محلية. لا GitHub ولا Supabase ولا Vercel. هذا البند يقضي على كل بقايا عصر السحابة بحيث لا تؤثر على عمل السيرفر، ويصلح نهائياً إخفاقَي التشغيل الحقيقي على الـ VPS.

### 1️⃣ السبب الجذري لتكرار الفشل عندك (تشخيص):
- مثبّت R10 يبحث عن النمط `Nabil-gold-R10-FIXED-FILES-ONLY*` بينما حزمة R10a سُميت `Nabil-gold-R10a-...` ⇒ **المثبّت لم يستخرج شيئاً** وشغّل ملفات R10 القديمة. مثبّت R11 الجديد يستخدم نمطاً موحداً `Nabil-gold-R11*`.

### 2️⃣ حذف كل مخلفات السحابة (17 ملفاً/مجلداً):
`.github/` · `api/` (عميل Vercel) · `dashboard/api/` (عميل Vercel) · `deploy/GITHUB_SHUTDOWN_AR.md` · `INSTALL_AUTO_UPDATER.bat` + `deploy/install_auto_updater.ps1` + `deploy/tasks/auto_update.bat` (قناة سحب من GitHub لم تعد موجودة) · `scripts/migrate_supabase_to_local.py` + `tests/test_local_migration.py` (الهجرة انتهت) · `tests/test_dashboard_api_leak.py` (حرس واجهة Vercel) · `tests/test_exit_warning_column_is_text.py` + `tests/test_schema_has_partial_booking_columns.py` (حراس مخطط Postgres) · `SUPABASE_VERIFICATION_CHECKLIST.sql` · `VERIFY_ALL_COLUMNS.sql` · `FIX_BACKFILL_CLOSED_AT.sql` · `FIX_EXIT_WARNING_COLUMN_TYPE.sql` · `PHASE6_ANALYST_DISTILLATION_MIGRATION.sql` · `supabase_schema_unified.sql` · `subscription_bot/supabase_schema.sql` · `deploy/trades_demo.sql`

### 3️⃣ تعقيم التشغيل الفعلي (الأهم):
- `config.json` → `database.provider = "local"` (بلا مفاتيح سحابية).
- **ملف `.env` الحي على السيرفر:** يُنسخ احتياطياً (`.env.backup_R11_<وقت>`) ثم تُحذف منه سطور `SUPABASE_* / GITHUB_TOKEN / VERCEL_*` — بقاء مفاتيح Supabase في `.env` كان سيوجّه التخزين للسحابة الميتة بصمت.
- `requirements.txt` → مكتبة supabase اختيارية معلّقة؛ `.env.template` قالب محلي خالص.
- كود `services/database.py` يبقى بح paтh مه dormant: لا يتفعل إلا بمفاتيح سحابية، وحذف مساره كان سيكسر ~15 ملف اختبار دون فائدة تشغيلية.

### 4️⃣ إصلاح الاختبارات المرتبطة بالقديم:
- `test_build16`: حذف اختبار cron الخاص بـ GitHub نهائياً.
- ملف اختبارات R10/R11: اختبار غياب GitHub استُبدل باختبار **LOCAL-ONLY** (لا `.github` ولا `api/` ولا مخلفات SQL وprovider=local)، واختبار الظل أصبح شرطياً (تخطٍ موثق حتى ترحيل البيانات).
- `test_thesis_exit_status_naming`: اختبار مخطط Postgres استُبدل بمرجع محلي (`services/database.py` + `services/dashboard_local_api.py`).
- `tests/test_dashboard_numbers_agree`: تخطى ذاتياً لاختبارَي JS (ملفات Vercel حُذفت) — النسخة المحلية `services/dashboard_local_api.py` هي المرجع.

### 5️⃣ كود التطبيق المباشر (طلب المشغّل):
- `APPLY_R11_LOCAL_ONLY.ps1` + `APPLY_R11_PATCH.py`: **سكربت مستقل يُنسخ إلى `C:\Nabil-gold` ويُشغّل مباشرة في PowerShell — بلا حزمة ولا إنترنت**: حذف المخلفات → تعقيم `.env` مع نسخة احتياطية → ترقيع الاختبارات → ترحيل الظل ذاتياً → compileall → حزمة الاختبارات كاملة. Idempotent.
- `deploy/install_build31_r11.ps1` + `INSTALL_BUILD31_R11.bat`: المسار البديل عبر الحزمة `Nabil-gold-R11*.zip`.

### 🧪 التحقق (محاكاة كاملة لحالة السيرفر المعطوبة + الإصلاح):
```text
حالة VPS معطوبة أُعيد بناؤها حرفياً (.github موجود + provider=supabase + مفتاحا
SUPABASE في .env + اختبارات R10 القديمة + مجلدات ظل + SQL قديم):
  python APPLY_R11_PATCH.py  -> 10/10 [OK]
  python -m pytest tests -q  -> 2582 passed, 6 skipped, 0 FAILED  (66.5s)
  verify_r10_fixes.py        -> 14/14 checks passed
```

---

## BUILD31-R13 — الأدلة الظلية + سقوف السبريد لكل زوج (2026-08-27، محلي بالكامل)

### السبب الجذري: لغز "صفر صفقات على أزواج الفوركس الأربعة"
- سقف السبريد كان **عالمياً واحداً**: `filters.max_spread_points = 5` — مُعاير على الذهب
  (النقطة = $0.10 ⟸ سقف $0.50).
- على أزواج الفوركس الخماسية النقطة = 0.1 pip، فالسبريد الطبيعي 0.6–1.5 pip = **6–15 نقطة** ⟸
  **كل** دخول فوركس كان يُصطاد:
  - `agents/auction_flow_agent.py::_data_problem` ⟸ `SPREAD_GUARD` (الوكيل كله WAIT)
  - `agents/risk_management_agent.py::_run_filters` ⟸ `spread_filter` (فيتو "Spread too high")
- النتيجة: ذهب ونفط يتداولان وفوركس صفر — مطابق تماماً لسجل الصفقات الحقيقي.
- **الإصلاح**: `utils/instruments.py::max_spread_points_for()` — خريطة لكل زوج في
  `config.json` (تُدمج ولا تُستبدل أبداً): XAU=5، WTI=8، EUR/USD=25، GBP/USD=30،
  USD/CAD=30، USD/JPY=25 (سقوف ≈ 2.5–3 pips تمنع فقط السبريد الشاذ فعلاً).
  الوكيلان يستخدمان المساعد الجديد. القاعدة القديمة تبقى احتياطاً للرموز غير المدرجة.

### إصلاح إضافي اكتشفته الاختبارات: تجميع أيام Hebron
- `hebron_day()` القديمة كانت تطرح ثانية واحدة بدل إزاحة 3 ساعات ⟸ صفقات
  00:00–02:59 بتوقيت Hebron تُجمَّع في اليوم الخطأ. صُحّحت في
  `services/guard_replay.py` وثبّتها اختبارات مخصصة.

### الوحدة المرجعية الواحدة + الوضع الظلي (الخيار ب)
- `services/guard_replay.py` (جديد): محرك إعادة تشغيل الحواجز **الأوحد** —
  يستهلكه تقرير التدقيق اليدوي وحقل الظل معاً فلا يحدث انحراف بينهما أبداً.
- `services/database.py::save_trade` يسجل الآن لكل صفقة جديدة:
  - `entry_vwap / entry_atr / range_high / range_low` على مستوى الصف
    (البحث الهيكلي أولاً ثم العميق بمفاتيح محددة — لا التقاط شموع بالخطأ)،
  - `would_block`: أي حواجز R10/R11 كانت ستمنع الدخول — **تسجيل فقط، لا يمنع
    شيئاً ولا يكسر الحفظ أبداً**.
- النتيجة القياسية القادمة: ملاحظة "5/5 missing evidence" ستصبح أرقاماً كاملة،
  وكلفة الحواجز تُقاس آلياً على كل صفقة قادمة.

### التشخيص الدائم: `scripts/diagnose_symbol_funnel.py`
- يفرّق بدقة بين الحالات الثلاث لكل زوج: يتداول / يُقتل بحاجز مُسمّى (السبب
  يظهر) / **لا يُشغَّل أصلاً** (صفر صفوف تدقيق = مشكلة جدولة/مجمّع بيانات).
- الملفات الناقصة تُعلَّم MISSING — لا تخمين.

### الأدلة المقاسة
- المجموعة الكاملة على الشجرة الحقيقية: **2616 passed / 6 skipped / 0 FAILED (65.46s)**
- اختبارات R13 الجديدة: 25 (guard_replay 11 + spread 8 + database 4 + funnel 3 — ضمن 2616)
- `py_compile`: سليم لكل الملفات السبعة المتغيرة · `APPLY_R13_CONFIG_MERGE.py` لا يُبطل مفاتيح الإعدادات
- الحزمة: `Nabil-gold-R13-SHADOW-EVIDENCE-20260827.zip` (14 ملفاً) + `APPLY_R13_EVIDENCE_SHADOW.ps1`

---

## R15b (2026-08-27) — إصلاح أداة تشخيص المزاد: لافة مسار مزدوجة
- `scripts/diagnose_auction_agent.py` كانت تمرر مسار مخزن ملاحقاً مسبقاً
  فيلحق الوكيل اللاقة ثانية (`*_eurusd_eurusd.sqlite3`) فتقرأ مخزناً فارغاً
  وتعلن "heartbeat NEVER written" كذباً عن مخازن حية.
- الإصلاح: تمرير المسار الأساس (الوكيل يلحق اللاقة) + اختبار انحدار يزرع
  تيكات ونبضاً في المخزن الحقيقي ويطالب بأعمار محدودة.
- إثبات: المجموعة الكاملة 2624 passed / 6 skipped / 0 FAILED.
