import os
import sys

tc_file = os.path.join("tests", "conftest.py")
if os.path.exists(tc_file):
    txt = open(tc_file, "r", encoding="utf-8").read()
    # Strip any misplaced imports before __future__
    lines = txt.splitlines()
    clean_lines = [
        l for l in lines
        if not l.startswith("import os, sys")
        and not l.startswith("_ROOT =")
        and not l.startswith("if _ROOT not in sys.path:")
        and not l.startswith("    sys.path.insert(0, _ROOT)")
    ]
    new_txt = "\n".join(clean_lines)
    if "from __future__ import annotations" in new_txt:
        new_txt = new_txt.replace(
            "from __future__ import annotations",
            "from __future__ import annotations\n\nimport os\nimport sys\n_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))\nif _ROOT not in sys.path:\n    sys.path.insert(0, _ROOT)"
        )
    open(tc_file, "w", encoding="utf-8").write(new_txt)
    print("✅ Fixed tests/conftest.py (__future__ order).")
