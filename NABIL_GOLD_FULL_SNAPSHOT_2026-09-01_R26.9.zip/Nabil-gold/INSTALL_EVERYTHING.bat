@echo off
REM Nabil-gold FINAL installer - installs EVERYTHING in this package.
REM Step 1: double-click this file. Step 2: RESTART_ALL_SERVICES.bat (admin).
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_EVERYTHING.ps1"
echo.
pause
