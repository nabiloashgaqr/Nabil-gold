"""Multi-Instrument Macro / Fundamental Agent.

Provides institutional directional macro context for:
- Gold (XAU/USD)
- WTI Crude Oil (WTI/USD)
- Euro / US Dollar (EUR/USD)
- British Pound / US Dollar (GBP/USD)
- US Dollar / Canadian Dollar (USD/CAD)
- US Dollar / Japanese Yen (USD/JPY)

Respects currency hierarchy (Base vs Quote currency), interest rate differentials,
central bank tones (Fed, ECB, BOE, BOC, BOJ), commodity links (Oil/CAD), and
risk sentiment regimes (Safe-haven JPY/Gold vs Pro-cyclical FX).
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

from agents.base_agent import BaseAgent
from utils.helpers import load_config, sanitize_prompt_text
from utils.instruments import normalize_symbol


class MacroFundamentalAgent(BaseAgent):
    """Directional macro read across configured asset classes."""

    name = "macro_fundamental"

    def __init__(self, config: Dict[str, Any] | None = None, **_kwargs: Any) -> None:
        super().__init__(config or load_config())
        self.context_path = Path(__file__).resolve().parents[1] / "storage" / "macro_context.json"
        self.symbol = normalize_symbol(self.config.get("symbol") or "XAU/USD")

    def analyze(self, data: Dict[str, Any] | None = None) -> Dict[str, Any]:
        data = data or {}
        context = self._load_context(data)
        macro_direction = self.macro_direction(context)
        trade_bias = macro_direction.get("trade_bias", "WAIT")
        signal = trade_bias if macro_direction.get("confidence", 0) >= 55 else "WAIT"
        return {
            "agent": self.name,
            "symbol": self.symbol,
            "signal": signal,
            "direction": signal if signal in {"BUY", "SELL"} else "NEUTRAL",
            "confidence": macro_direction.get("confidence", 0),
            "macro_direction": macro_direction,
            "trade_bias": trade_bias,
            "summary": macro_direction.get("summary", "Macro context unavailable"),
            "reason_codes": macro_direction.get("reason_codes", []),
            "evidence": macro_direction.get("evidence", []),
            "invalidations": macro_direction.get("invalidations", []),
            "data_quality": macro_direction.get("data_quality", {}),
            "confidence_breakdown": macro_direction.get("confidence_breakdown", {}),
            "warnings": macro_direction.get("warnings", []),
            "timestamp": self.now_iso(),
        }

    async def analyze_async(self, data: Dict[str, Any] | None = None) -> Dict[str, Any]:
        return self.analyze(data or {})

    def macro_direction(self, context: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """Return directional macro bias for the configured symbol."""
        context = context or {}
        if not context:
            return self._neutral(f"{self.symbol} Macro: inputs not connected yet", missing=["macro_context"])

        # Check for symbol-specific nested context (e.g. context["EUR/USD"] or context["EURUSD"])
        sym_key = self.symbol
        alt_key = self.symbol.replace("/", "")
        sym_context = {}
        if isinstance(context.get(sym_key), dict):
            sym_context = dict(context.get(sym_key))
        elif isinstance(context.get(alt_key), dict):
            sym_context = dict(context.get(alt_key))

        merged_context = {**context, **sym_context}

        score = 0.0
        max_abs = 0.0
        drivers: List[str] = []
        evidence: List[Dict[str, Any]] = []
        codes: List[str] = []
        warnings: List[str] = []
        breakdown = {
            "dxy": 0.0,
            "yields": 0.0,
            "central_banks": 0.0,
            "inflation_growth": 0.0,
            "risk": 0.0,
            "commodity": 0.0,
            "events": 0.0,
        }

        def add(component: str, points: float, label: str, code: str, value: Any = None) -> None:
            nonlocal score, max_abs
            score += points
            max_abs += abs(points) if points != 0 else 0.3
            breakdown[component] = round(breakdown.get(component, 0.0) + points, 2)
            drivers.append(label)
            codes.append(code)
            evidence.append({
                "name": component,
                "value": value if value is not None else label,
                "bias": "BULLISH" if points > 0 else "BEARISH" if points < 0 else "NEUTRAL",
            })

        dxy = self._norm(merged_context.get("dxy_trend") or merged_context.get("dollar_trend") or merged_context.get("usd_trend"))
        yields = self._norm(merged_context.get("us10y_trend") or merged_context.get("real_yields_trend") or merged_context.get("yields_trend"))
        fed = self._norm(merged_context.get("fed_tone") or merged_context.get("fed_policy") or merged_context.get("rate_expectations"))
        inflation = self._norm(merged_context.get("inflation_surprise") or merged_context.get("cpi_surprise") or merged_context.get("pce_surprise"))
        growth = self._norm(merged_context.get("growth_surprise") or merged_context.get("recession_risk") or merged_context.get("labor_market"))
        risk = self._norm(merged_context.get("risk_sentiment") or merged_context.get("risk_regime") or merged_context.get("geopolitical_risk"))
        oil = self._norm(merged_context.get("oil_trend") or merged_context.get("commodity_inflation"))
        vix = merged_context.get("vix_level")

        # ── SYMBOL-SPECIFIC MACRO RULES ───────────────────────────────────────
        if self.symbol == "XAU/USD":
            # Gold
            if dxy in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("dxy", -2.2, "Stronger USD pressures gold", "MACRO_DXY_BEARISH_GOLD", dxy)
            elif dxy in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("dxy", 2.2, "Weaker USD supports gold", "MACRO_DXY_BULLISH_GOLD", dxy)

            if yields in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("yields", -2.0, "Rising US yields pressure non-yielding gold", "MACRO_YIELDS_BEARISH_GOLD", yields)
            elif yields in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("yields", 2.0, "Falling US yields support gold", "MACRO_YIELDS_BULLISH_GOLD", yields)

            if fed in {"HAWKISH", "HIGHER_FOR_LONGER", "RATE_HIKES", "TIGHTENING"}:
                add("central_banks", -1.8, "Hawkish Fed tone is bearish for gold", "MACRO_FED_HAWKISH", fed)
            elif fed in {"DOVISH", "CUTS", "RATE_CUTS", "EASING"}:
                add("central_banks", 1.8, "Dovish Fed / cuts expectations support gold", "MACRO_FED_DOVISH", fed)

            if inflation in {"HOT", "ABOVE", "HIGHER", "UPSIDE"}:
                add("inflation_growth", 0.8, "Hot inflation supports hedging demand", "MACRO_INFLATION_HOT", inflation)
            elif inflation in {"COOL", "BELOW", "LOWER", "DOWNSIDE"}:
                add("inflation_growth", 0.7, "Cooling inflation lowers rate expectations", "MACRO_INFLATION_COOLING", inflation)

            if growth in {"WEAK", "RECESSION", "RISK", "SOFTENING", "COOLING"}:
                add("inflation_growth", 1.3, "Growth weakness supports defensive gold demand", "MACRO_GROWTH_WEAK", growth)
            elif growth in {"STRONG", "HOT", "RESILIENT"}:
                add("inflation_growth", -0.9, "Strong growth reduces defensive gold demand", "MACRO_GROWTH_STRONG", growth)

            if risk in {"RISK_OFF", "HIGH", "STRESS", "GEOPOLITICAL", "SAFE_HAVEN"}:
                add("risk", 2.0, "Risk-off / safe-haven supports gold", "MACRO_RISK_OFF_BULLISH_GOLD", risk)
            elif risk in {"RISK_ON", "LOW", "CALM"}:
                add("risk", -0.9, "Risk-on sentiment reduces safe-haven demand", "MACRO_RISK_ON_BEARISH_GOLD", risk)

            if oil in {"UP", "RISING", "STRONG"}:
                add("commodity", 0.5, "Higher oil lifts inflation-hedge demand", "MACRO_OIL_UP_SUPPORTS_GOLD", oil)
            elif oil in {"DOWN", "FALLING", "WEAK"}:
                add("commodity", -0.3, "Softer oil reduces inflation-hedge demand", "MACRO_OIL_DOWN_SOFT_GOLD", oil)

            if isinstance(vix, (int, float)):
                if vix >= 30: add("risk", 1.5, f"VIX at {vix:.0f} — extreme fear supports gold", "MACRO_VIX_EXTREME_FEAR", vix)
                elif vix >= 25: add("risk", 1.0, f"VIX at {vix:.0f} — elevated fear supports gold", "MACRO_VIX_ELEVATED", vix)
                elif vix <= 13: add("risk", -0.5, f"VIX at {vix:.0f} — complacency", "MACRO_VIX_COMPLACENCY", vix)

        elif self.symbol in {"EUR/USD", "GBP/USD"}:
            # European Majors (USD is quote currency)
            peer = "EUR" if "EUR" in self.symbol else "GBP"
            cb_peer = "ECB" if "EUR" in self.symbol else "BOE"
            cb_peer_tone = self._norm(merged_context.get(f"{cb_peer.lower()}_tone") or merged_context.get(f"{cb_peer.lower()}_policy"))

            if dxy in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("dxy", -2.2, f"Stronger USD pressures {self.symbol}", f"MACRO_DXY_BEARISH_{peer}", dxy)
            elif dxy in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("dxy", 2.2, f"Weaker USD supports {self.symbol}", f"MACRO_DXY_BULLISH_{peer}", dxy)

            if yields in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("yields", -2.0, f"Widening US yield advantage pressures {peer}", f"MACRO_YIELDS_BEARISH_{peer}", yields)
            elif yields in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("yields", 2.0, f"Narrowing US yield advantage supports {peer}", f"MACRO_YIELDS_BULLISH_{peer}", yields)

            if fed in {"HAWKISH", "HIGHER_FOR_LONGER", "RATE_HIKES"}:
                add("central_banks", -1.8, f"Hawkish Fed pressures {self.symbol}", "MACRO_FED_HAWKISH", fed)
            elif fed in {"DOVISH", "CUTS", "RATE_CUTS", "EASING"}:
                add("central_banks", 1.8, f"Dovish Fed supports {self.symbol}", "MACRO_FED_DOVISH", fed)

            if cb_peer_tone in {"HAWKISH", "TIGHTENING", "RATE_HIKES"}:
                add("central_banks", 1.8, f"Hawkish {cb_peer} lifts {peer}", f"MACRO_{cb_peer}_HAWKISH", cb_peer_tone)
            elif cb_peer_tone in {"DOVISH", "EASING", "RATE_CUTS"}:
                add("central_banks", -1.8, f"Dovish {cb_peer} weakens {peer}", f"MACRO_{cb_peer}_DOVISH", cb_peer_tone)

            if risk in {"RISK_OFF", "HIGH", "STRESS"}:
                add("risk", -1.4, f"Risk-off safe-haven USD flows pressure {self.symbol}", f"MACRO_RISK_OFF_BEARISH_{peer}", risk)
            elif risk in {"RISK_ON", "LOW", "CALM"}:
                add("risk", 1.2, f"Risk-on sentiment supports pro-cyclical {peer}", f"MACRO_RISK_ON_BULLISH_{peer}", risk)

        elif self.symbol == "USD/CAD":
            # USD/CAD (USD is base currency, CAD is petrodollar)
            boc = self._norm(merged_context.get("boc_tone") or merged_context.get("boc_policy"))
            if dxy in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("dxy", 2.2, "Stronger USD lifts USD/CAD", "MACRO_DXY_BULLISH_USDCAD", dxy)
            elif dxy in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("dxy", -2.2, "Weaker USD pressures USD/CAD", "MACRO_DXY_BEARISH_USDCAD", dxy)

            if yields in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("yields", 2.0, "Rising US yields support USD/CAD", "MACRO_YIELDS_BULLISH_USDCAD", yields)
            elif yields in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("yields", -2.0, "Falling US yields pressure USD/CAD", "MACRO_YIELDS_BEARISH_USDCAD", yields)

            if fed in {"HAWKISH", "HIGHER_FOR_LONGER"}:
                add("central_banks", 1.8, "Hawkish Fed supports USD/CAD", "MACRO_FED_HAWKISH", fed)
            elif fed in {"DOVISH", "CUTS"}:
                add("central_banks", -1.8, "Dovish Fed pressures USD/CAD", "MACRO_FED_DOVISH", fed)

            if boc in {"HAWKISH", "TIGHTENING"}:
                add("central_banks", -1.8, "Hawkish BOC strengthens CAD (pressures USD/CAD)", "MACRO_BOC_HAWKISH", boc)
            elif boc in {"DOVISH", "EASING"}:
                add("central_banks", 1.8, "Dovish BOC weakens CAD (lifts USD/CAD)", "MACRO_BOC_DOVISH", boc)

            # Crude Oil Petrodollar Link: Oil UP -> CAD UP -> USD/CAD DOWN
            if oil in {"UP", "RISING", "STRONG"}:
                add("commodity", -2.0, "Higher oil strengthens petrodollar CAD (pressures USD/CAD)", "MACRO_OIL_UP_CAD_STRONG", oil)
            elif oil in {"DOWN", "FALLING", "WEAK"}:
                add("commodity", 2.0, "Softer oil weakens CAD (supports USD/CAD)", "MACRO_OIL_DOWN_CAD_WEAK", oil)

            if risk in {"RISK_OFF", "HIGH", "STRESS"}:
                add("risk", 1.3, "Risk-off safe-haven USD flows support USD/CAD", "MACRO_RISK_OFF_BULLISH_USDCAD", risk)

        elif self.symbol == "USD/JPY":
            # USD/JPY (USD is base currency, JPY is safe haven)
            boj = self._norm(merged_context.get("boj_tone") or merged_context.get("boj_policy"))
            if dxy in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("dxy", 2.2, "Stronger USD lifts USD/JPY", "MACRO_DXY_BULLISH_USDJPY", dxy)
            elif dxy in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("dxy", -2.2, "Weaker USD pressures USD/JPY", "MACRO_DXY_BEARISH_USDJPY", dxy)

            # US-Japan Yield Spread is the primary driver
            if yields in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("yields", 2.5, "Widening US-Japan yield differential lifts USD/JPY carry", "MACRO_YIELDS_BULLISH_USDJPY", yields)
            elif yields in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("yields", -2.5, "Narrowing US-Japan yield differential pressures USD/JPY", "MACRO_YIELDS_BEARISH_USDJPY", yields)

            if fed in {"HAWKISH", "HIGHER_FOR_LONGER"}:
                add("central_banks", 1.8, "Hawkish Fed widens policy gap with BOJ (supports USD/JPY)", "MACRO_FED_HAWKISH", fed)
            elif fed in {"DOVISH", "CUTS"}:
                add("central_banks", -1.8, "Dovish Fed narrows policy gap (pressures USD/JPY)", "MACRO_FED_DOVISH", fed)

            if boj in {"HAWKISH", "HIKE", "RATE_HIKES", "TIGHTENING"}:
                add("central_banks", -2.5, "Hawkish BOJ / rate hike strengthens JPY (pressures USD/JPY)", "MACRO_BOJ_HAWKISH", boj)
            elif boj in {"DOVISH", "YCC", "EASING"}:
                add("central_banks", 2.0, "Dovish BOJ keeps JPY weak (supports USD/JPY)", "MACRO_BOJ_DOVISH", boj)

            # JPY Safe Haven: Risk-Off -> JPY Inflows -> USD/JPY DOWN
            if risk in {"RISK_OFF", "HIGH", "STRESS", "GEOPOLITICAL"}:
                add("risk", -2.2, "Risk-off safe-haven flows into JPY pressure USD/JPY", "MACRO_RISK_OFF_BEARISH_USDJPY", risk)
            elif risk in {"RISK_ON", "LOW", "CALM"}:
                add("risk", 1.5, "Risk-on carry appetite supports USD/JPY", "MACRO_RISK_ON_BULLISH_USDJPY", risk)

            if isinstance(vix, (int, float)):
                if vix >= 28: add("risk", -1.8, f"VIX at {vix:.0f} — fear triggers JPY repatriation (pressures USD/JPY)", "MACRO_VIX_HIGH_JPY_STRENGTH", vix)

        elif self.symbol == "WTI/USD":
            # WTI Crude Oil
            if dxy in {"UP", "RISING", "STRONG", "BULLISH"}:
                add("dxy", -2.0, "Stronger USD pressures dollar-denominated oil", "MACRO_DXY_BEARISH_WTI", dxy)
            elif dxy in {"DOWN", "FALLING", "WEAK", "BEARISH"}:
                add("dxy", 2.0, "Weaker USD supports oil", "MACRO_DXY_BULLISH_WTI", dxy)

            if growth in {"STRONG", "HOT", "RESILIENT"}:
                add("inflation_growth", 2.2, "Strong global growth supports oil demand", "MACRO_GROWTH_BULLISH_WTI", growth)
            elif growth in {"WEAK", "RECESSION", "RISK"}:
                add("inflation_growth", -2.2, "Growth slowdown weakens oil demand", "MACRO_GROWTH_BEARISH_WTI", growth)

            if risk in {"GEOPOLITICAL", "HIGH", "STRESS"}:
                add("risk", 1.8, "Geopolitical tensions / supply risk support oil", "MACRO_GEOPOLITICAL_BULLISH_WTI", risk)

        # Economic releases
        events_score = 0.0
        for event in self._load_economic_events():
            points = self._economic_event_points(event)
            if points == 0: continue
            if abs(events_score + points) > 2.0:
                points = (2.0 - abs(events_score)) * (1 if points > 0 else -1)
                if points == 0: continue
            events_score += points
            add("events", points, self._economic_event_label(event, points), "MACRO_EVENT_SURPRISE", event.get("event"))

        confidence = self._confidence(score, max_abs, len(evidence))
        sym_tag = self.symbol.replace("/", "")
        if score >= 1.5 and confidence >= 45:
            bias = f"BULLISH_{sym_tag}" if self.symbol != "XAU/USD" else "BULLISH_GOLD"
            trade_bias = "BUY"
        elif score <= -1.5 and confidence >= 45:
            bias = f"BEARISH_{sym_tag}" if self.symbol != "XAU/USD" else "BEARISH_GOLD"
            trade_bias = "SELL"
        else:
            bias = "NEUTRAL"
            trade_bias = "WAIT"
            codes.append("MACRO_NEUTRAL_MIXED")

        summary = self._summary(self.symbol, bias, confidence, drivers)
        data_quality = {
            "source": self._source_label(merged_context),
            "freshness": str(merged_context.get("freshness") or merged_context.get("data_quality") or "OPERATOR_SUPPLIED").upper(),
            "missing_fields": self._missing_fields(merged_context),
            "inputs": len(evidence),
        }
        return {
            "symbol": self.symbol,
            "bias": bias,
            "trade_bias": trade_bias,
            "confidence": confidence,
            "score": round(score, 2),
            "drivers": drivers[:8],
            "summary": summary,
            "reason_codes": self._dedupe(codes)[:12],
            "evidence": evidence[:10],
            "invalidations": self._invalidations(bias, self.symbol),
            "data_quality": data_quality,
            "confidence_breakdown": {k: round(v, 2) for k, v in breakdown.items()},
            "warnings": warnings[:4],
        }

    def _load_economic_events(self) -> List[Dict[str, Any]]:
        cfg = self.config.get("macro_economic_events") or {}
        if not bool(cfg.get("enabled", False)):
            return []
        try:
            path = Path(str(cfg.get("path", "storage/macro/economic_events.json")))
            if not path.exists():
                return []
            raw = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                return []
            max_age_days = float(cfg.get("max_age_days", 7) or 7)
            cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
            events = []
            for row in raw:
                if not isinstance(row, dict): continue
                try:
                    when = datetime.fromisoformat(str(row.get("date") or "").replace("Z", "+00:00"))
                    if when.tzinfo is None: when = when.replace(tzinfo=timezone.utc)
                except (TypeError, ValueError): continue
                if when < cutoff: continue
                events.append(row)
            return events
        except Exception:
            return []

    def _economic_event_points(self, event: Dict[str, Any]) -> float:
        try:
            forecast = float(event.get("forecast"))
            actual = float(event.get("actual"))
        except (TypeError, ValueError):
            return 0.0
        surprise = actual - forecast
        name = str(event.get("event") or "").upper()
        norm = "".join(ch for ch in name if ch.isalnum())
        mult = 1.0
        if self.symbol in {"EUR/USD", "GBP/USD"}: mult = -1.0
        elif self.symbol in {"USD/CAD", "USD/JPY"}: mult = 1.0
        elif self.symbol == "XAU/USD": mult = 1.0

        if any(k in norm for k in ("CPI", "PCE", "PPI", "INFLATION")):
            return (0.8 if surprise > 0 else 0.7 if surprise < 0 else 0.0) * mult
        if any(k in norm for k in ("NFP", "NONFARM", "PAYROLL", "UNEMPLOYMENT", "JOBS")):
            base_pts = -0.9 if surprise > 0 else 1.3 if surprise < 0 else 0.0
            return base_pts if self.symbol == "XAU/USD" else (-1.2 if surprise > 0 else 1.2) * mult
        if any(k in norm for k in ("FOMC", "FED", "RATE", "INTEREST")):
            base_pts = -1.8 if surprise > 0 else 1.8 if surprise < 0 else 0.0
            return base_pts if self.symbol == "XAU/USD" else (1.8 if surprise > 0 else -1.8) * mult
        return 0.0

    def _economic_event_label(self, event: Dict[str, Any], points: float) -> str:
        name = str(event.get("event") or "EVENT")
        direction = "supportive" if points > 0 else "pressure"
        return f"{name}: actual {event.get('actual')} vs forecast {event.get('forecast')} ({self.symbol} {direction})"

    def _load_context(self, data: Dict[str, Any]) -> Dict[str, Any]:
        for source in (data.get("macro_context"), self.config.get("macro_context")):
            if isinstance(source, dict) and source:
                return dict(source)
        env_context = os.environ.get("MACRO_CONTEXT_JSON")
        if env_context:
            try:
                parsed = json.loads(env_context)
                if isinstance(parsed, dict): return parsed
            except json.JSONDecodeError as exc:
                self.logger.warning("Invalid MACRO_CONTEXT_JSON: %s", exc)
        if self.context_path.exists():
            try:
                with self.context_path.open("r", encoding="utf-8") as file:
                    parsed = json.load(file)
                if isinstance(parsed, dict): return parsed
            except json.JSONDecodeError as exc:
                self.logger.warning("Invalid macro context file: %s", exc)
        return {}

    def _neutral(self, summary: str, missing: List[str] | None = None) -> Dict[str, Any]:
        return {
            "symbol": self.symbol,
            "bias": "NEUTRAL",
            "trade_bias": "WAIT",
            "confidence": 0,
            "score": 0.0,
            "drivers": [],
            "summary": summary,
            "reason_codes": ["MACRO_DATA_UNAVAILABLE"],
            "evidence": [],
            "invalidations": [],
            "data_quality": {"source": "none", "freshness": "UNKNOWN", "missing_fields": missing or ["macro_context"], "inputs": 0},
            "confidence_breakdown": {"dxy": 0, "yields": 0, "central_banks": 0, "inflation_growth": 0, "risk": 0, "commodity": 0},
            "warnings": [summary],
        }

    @staticmethod
    def _norm(value: Any) -> str:
        return str(value or "").strip().upper().replace(" ", "_").replace("-", "_")

    @staticmethod
    def _dedupe(items: List[str]) -> List[str]:
        seen: List[str] = []
        for item in items:
            if item and item not in seen:
                seen.append(item)
        return seen

    @staticmethod
    def _confidence(score: float, max_abs: float, inputs: int) -> int:
        if inputs <= 0: return 0
        if max_abs <= 0: return int(round(max(0.0, min(30.0, 10 + inputs * 4))))
        conviction = min(abs(score) / max_abs, 1.0)
        breadth = min(inputs / 5.0, 1.0)
        return int(round(max(0.0, min(90.0, 35 + conviction * 35 + breadth * 20))))

    @staticmethod
    def _invalidations(bias: str, symbol: str) -> List[str]:
        if "BULLISH" in bias:
            return [f"USD / Yield trend reverses against {symbol}", "Macro risk regime shifts abruptly"]
        if "BEARISH" in bias:
            return [f"USD / Yield trend reverses in favor of {symbol}", "Macro risk regime shifts abruptly"]
        return ["Wait for clearer macro alignment"]

    @staticmethod
    def _missing_fields(context: Dict[str, Any]) -> List[str]:
        groups = {
            "dxy_trend": ("dxy_trend", "dollar_trend", "usd_trend"),
            "yields_trend": ("us10y_trend", "real_yields_trend", "yields_trend"),
            "fed_tone": ("fed_tone", "fed_policy", "rate_expectations"),
            "risk_sentiment": ("risk_sentiment", "risk_regime", "geopolitical_risk"),
            "oil_trend": ("oil_trend", "commodity_inflation"),
            "inflation_surprise": ("inflation_surprise", "cpi_surprise", "pce_surprise"),
        }
        missing = []
        for label, keys in groups.items():
            val = None
            for k in keys:
                v = context.get(k)
                if v and str(v).lower() not in {"unknown", "none", ""}:
                    val = v
                    break
            if not val:
                missing.append(label)
        return missing

    @staticmethod
    def _source_label(context: Dict[str, Any]) -> str:
        source = context.get("source") or context.get("provider") or "operator_macro_context"
        return sanitize_prompt_text(str(source), max_len=80)

    @staticmethod
    def _summary(symbol: str, bias: str, confidence: int, drivers: List[str]) -> str:
        if not drivers:
            return f"{symbol} Macro: context unavailable"
        lead = "; ".join(drivers[:3])
        if len(drivers) > 3:
            lead += f"; +{len(drivers) - 3} more"
        bias_label = bias.replace("_", " ").title()
        if bias == "NEUTRAL" and confidence > 0:
            return f"{symbol} Macro: Neutral ({confidence}%) — {lead}"
        return f"{symbol} Macro: {bias_label} ({confidence}%) — {lead}"
