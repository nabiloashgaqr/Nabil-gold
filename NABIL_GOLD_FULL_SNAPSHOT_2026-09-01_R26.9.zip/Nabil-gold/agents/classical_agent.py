"""Classical Analysis Agent.

يرصد الدعوم والمقاومات والفيبوناتشي والسيناريوهات الكلاسيكية الأساسية. هذه
نسخة مرحلة أولى قابلة للتوسع للنماذج السعرية الأكثر تعقيداً لاحقاً.
"""

from __future__ import annotations

from statistics import mean
from typing import Any, Dict, List

from agents.base_agent import BaseAgent
from services.timeframe_fusion import (
    CANONICAL_TIMEFRAMES, fuse_timeframe_results, missing_required_timeframes,
    native_timeframe_failure, native_timeframe_payloads,
)
from services.market_snapshot import build_market_snapshot
from utils.indicators import calculate_fibonacci_levels, calculate_pivot_points, detect_support_resistance, detect_swing_points
from utils.instruments import price_decimals, normalize_symbol, point_size


class ClassicalAgent(BaseAgent):
    """Analyze support/resistance, pivots, Fibonacci and simple trendlines."""

    name = "classical"

    def analyze(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze every native 5m/15m/1H/4H payload and emit one vote."""
        cfg = self.config.get("all_agents_timeframes", {}) or {}
        tf_book = market_data.get("timeframes") or {}
        if not market_data.get("data") and not tf_book:
            return self._empty_result("No candle data supplied")
        # Backward compatibility for focused unit tests/manual callers. VPS
        # production sets require_all=true and therefore never takes this path.
        if not tf_book and not bool(cfg.get("require_all", False)):
            return self._analyze_single(market_data)
        missing = missing_required_timeframes(market_data, self.config)
        # Legacy/manual single-payload callers carry no verified source. VPS
        # production is source=mt5 and always fails closed on a missing native
        # frame. This keeps focused indicator tests callable without weakening
        # the live contract.
        verified_runtime = bool(market_data.get("source"))
        if bool(cfg.get("require_all", False)) and missing:
            if not verified_runtime and market_data.get("data"):
                return self._analyze_single(market_data)
            return native_timeframe_failure(self.name, missing)
        payloads = native_timeframe_payloads(market_data, self.config)
        results = {tf: self._analyze_single(payload) for tf, payload in payloads.items()}
        if not results:
            return native_timeframe_failure(self.name, CANONICAL_TIMEFRAMES)
        return fuse_timeframe_results(
            self.name, results, required_timeframes=CANONICAL_TIMEFRAMES,
            primary_timeframe=str(self.config.get("primary_timeframe", "15m")),
        )

    def _analyze_single(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            candles = market_data.get("data", [])
            if len(candles) < 30:
                return self._empty_result("Not enough data for classical analysis")

            sym = normalize_symbol(market_data.get("symbol") or self.config.get("symbol") or "XAU/USD")
            dec = price_decimals(sym, self.config)
            _r = lambda v: round(float(v), dec)

            current_price = float(candles[-1]["close"])
            snapshot = build_market_snapshot(market_data, self.config)
            recent = candles[-80:] if len(candles) >= 80 else candles
            levels = detect_support_resistance(recent, lookback=len(recent))
            supports = sorted(set(_r(level) for level in levels.get("supports", [])))
            resistances = sorted(set(_r(level) for level in levels.get("resistances", [])))

            # Ensure levels around current price are useful.
            support_levels = sorted([x for x in supports if x < current_price], reverse=True)[:3]
            resistance_levels = sorted([x for x in resistances if x > current_price])[:3]
            if not support_levels:
                support_levels = sorted([_r(c["low"]) for c in recent])[:3]
            if not resistance_levels:
                resistance_levels = sorted([_r(c["high"]) for c in recent], reverse=True)[:3]

            recent_high = max(float(c["high"]) for c in recent)
            recent_low = min(float(c["low"]) for c in recent)
            prev = recent[-2] if len(recent) > 1 else recent[-1]
            pivot_points = calculate_pivot_points(float(prev["high"]), float(prev["low"]), float(prev["close"]))
            fib = calculate_fibonacci_levels(recent_high, recent_low)
            swings = detect_swing_points(recent, lookback=3)
            trendline = self._build_trendline(swings, current_price, dec=dec)

            level_strength = self._level_strength(recent, support_levels, resistance_levels, sym=sym, dec=dec)
            nearest_support = support_levels[0] if support_levels else recent_low
            nearest_resistance = resistance_levels[0] if resistance_levels else recent_high
            distance_to_support = abs(current_price - nearest_support)
            distance_to_resistance = abs(nearest_resistance - current_price)
            range_size = max(recent_high - recent_low, point_size(sym, self.config) * 10)

            score = 0
            reasons: List[str] = []
            if trendline["direction"] == "ASCENDING" and trendline["respected"]:
                score += 2
                reasons.append("Ascending trendline respected")
            elif trendline["direction"] == "DESCENDING" and trendline["respected"]:
                score -= 2
                reasons.append("Descending trendline respected")
            trendline_score = score

            ascending_trend = trendline["direction"] == "ASCENDING" and trendline["respected"]
            descending_trend = trendline["direction"] == "DESCENDING" and trendline["respected"]
            if distance_to_support / range_size < 0.18:
                if not descending_trend:
                    score += 1.5
                    reasons.append("Price near support")
                else:
                    reasons.append("Price near support (discounted: respected downtrend)")
            if distance_to_resistance / range_size < 0.18:
                if not ascending_trend:
                    score -= 1.5
                    reasons.append("Price near resistance")
                else:
                    reasons.append("Price near resistance (discounted: respected uptrend)")
            if current_price > pivot_points["pivot"]:
                score += 1
                reasons.append("Price above pivot")
            elif current_price < pivot_points["pivot"]:
                score -= 1
                reasons.append("Price below pivot")
            levels_and_pivot_score = score - trendline_score
            before_patterns = score

            # Classical pattern hints with completion and validation.
            patterns = self._detect_classical_patterns(recent, swings, current_price, nearest_support, nearest_resistance, range_size, dec=dec)
            clear_patterns = [p for p in patterns if p.get("pattern") != "NO_CLEAR_PATTERN"]
            pattern_quality = self._pattern_quality(clear_patterns, current_price, nearest_support, nearest_resistance, range_size)
            breakout_quality = self._breakout_quality(candles, current_price, nearest_support, nearest_resistance, range_size)
            retest_state = self._retest_state(current_price, nearest_support, nearest_resistance, range_size)
            for pattern in clear_patterns:
                completion = float(pattern.get("completion", 0))
                if completion < 75:
                    continue
                weight = 1.6 if pattern.get("confidence") == "high" else 1.0
                if pattern.get("type") == "bullish":
                    score += weight
                elif pattern.get("type") == "bearish":
                    score -= weight
            quality_score = float(pattern_quality.get("score", 0) or 0)
            if clear_patterns and quality_score >= 75:
                score += 0.4 if pattern_quality.get("bias") == "bullish" else -0.4 if pattern_quality.get("bias") == "bearish" else 0
            elif clear_patterns and quality_score < 45:
                score *= 0.9
            pattern_score_total = score - before_patterns

            if not clear_patterns:
                reasons.append("NO_CLEAR_PATTERN - no forced classical setup")

            direction = "BUY" if score >= 2.5 else "SELL" if score <= -2.5 else "NEUTRAL"
            confidence = min(82, int(45 + abs(score) * 8)) if direction != "NEUTRAL" else int(25 + abs(score) * 5)
            bullish_probability = max(10, min(90, int(50 + score * 8)))
            bearish_probability = 100 - bullish_probability
            reason_codes = self._reason_codes(direction, trendline, current_price, nearest_support, nearest_resistance, pivot_points, clear_patterns)
            evidence = [
                {"name": "nearest_support", "value": _r(nearest_support), "bias": "BULLISH" if distance_to_support < distance_to_resistance else "NEUTRAL"},
                {"name": "nearest_resistance", "value": _r(nearest_resistance), "bias": "BEARISH" if distance_to_resistance < distance_to_support else "NEUTRAL"},
                {"name": "pivot", "value": _r(pivot_points["pivot"]), "bias": "BULLISH" if current_price > pivot_points["pivot"] else "BEARISH"},
                {"name": "trendline", "value": trendline.get("direction"), "bias": "BULLISH" if trendline.get("direction") == "ASCENDING" else "BEARISH" if trendline.get("direction") == "DESCENDING" else "NEUTRAL"},
            ]
            for pattern in clear_patterns[:2]:
                evidence.append({
                    "name": f"pattern_{pattern.get('pattern', 'classic').lower().replace(' ', '_')}",
                    "value": f"{pattern.get('pattern')} ({pattern.get('completion', 0):.0f}%)",
                    "bias": "BULLISH" if pattern.get("type") == "bullish" else "BEARISH" if pattern.get("type") == "bearish" else "NEUTRAL",
                })
            invalidations = [
                "Break below nearest support invalidates bullish classical read" if direction == "BUY" else "Break above nearest resistance invalidates bearish classical read",
                "Reversal through pivot point cancels classical momentum bias",
            ] if direction != "NEUTRAL" else []

            return {
                "agent": self.name,
                "direction": direction,
                "confidence": confidence,
                "directional_score": round(float(score), 4),
                "score_components": {
                    "trendline": round(float(trendline_score), 4),
                    "levels_and_pivot": round(float(levels_and_pivot_score), 4),
                    "patterns_and_quality": round(float(pattern_score_total), 4),
                    "total": round(float(score), 4),
                },
                "support_levels": [_r(x) for x in support_levels[:3]],
                "resistance_levels": [_r(x) for x in resistance_levels[:3]],
                "fibonacci_levels": {key: _r(value) for key, value in fib.items()},
                "pivot_points": {key: _r(value) for key, value in pivot_points.items()},
                "trendline": trendline,
                "level_strength": level_strength,
                "patterns_detected": patterns,
                "pattern_quality": pattern_quality,
                "breakout_quality": breakout_quality,
                "retest_state": retest_state,
                "no_clear_pattern": not bool(clear_patterns),
                "scenarios": {
                    "bullish": {
                        "probability": bullish_probability,
                        "trigger": f"Break above {_r(nearest_resistance)}",
                        "target": _r(nearest_resistance + (nearest_resistance - nearest_support)),
                    },
                    "bearish": {
                        "probability": bearish_probability,
                        "trigger": f"Break below {_r(nearest_support)}",
                        "target": _r(nearest_support - (nearest_resistance - nearest_support)),
                    },
                },
                "signals": [{"type": direction, "confidence": confidence}] if direction != "NEUTRAL" else [],
                "reasons": reasons,
                "reason_codes": reason_codes,
                "evidence": evidence,
                "invalidations": invalidations,
                "key_levels": {"nearest_support": _r(nearest_support), "nearest_resistance": _r(nearest_resistance), "pivot": _r(pivot_points["pivot"])},
                "data_quality": snapshot.get("data_quality", {}),
                "verified_snapshot": snapshot,
                "confidence_breakdown": {"structure": round(abs(score) * 8, 1), "levels": round(min(20, (1 - min(distance_to_support, distance_to_resistance) / range_size) * 20), 1), "patterns": round(float(pattern_quality.get("score", 0)) / 5, 1), "breakout": round(float(breakout_quality.get("score", 0)) / 5, 1), "penalties": -5 if pattern_quality.get("score", 0) < 45 and clear_patterns else 0},
                "warnings": [f"Low pattern quality ({pattern_quality.get('score')}%)"] if clear_patterns and quality_score < 45 else None,
                "summary": f"Classical: {direction} ({confidence}%) - {', '.join(reasons[:3]) if reasons else 'No strong structural bias'}",
            }
        except Exception as exc:  # noqa: BLE001
            self.logger.exception("Classical analysis failed")
            return self._empty_result(f"Classical analysis error: {exc}")

    def _pattern_quality(self, patterns: List[Dict[str, Any]], current_price: float, support: float, resistance: float, range_size: float) -> Dict[str, Any]:
        if not patterns:
            return {"score": 0, "grade": "NONE", "bias": "neutral", "touches": 0, "completion": 0, "drivers": ["no classical pattern"]}
        best = max(patterns, key=lambda p: float(p.get("completion", 0)))
        completion = float(best.get("completion", 0))
        touches = int(best.get("touches", 3))
        breakout_level = float(best.get("breakout_level", current_price))
        proximity = max(0.0, 1.0 - abs(current_price - breakout_level) / range_size)
        symmetry = 0.85 if touches >= 3 else 0.65
        score = min(100.0, completion * 0.45 + touches * 8 + proximity * 25 + symmetry * 10)
        grade = "A" if score >= 80 else "B" if score >= 65 else "C" if score >= 45 else "D"
        return {"score": round(score, 1), "grade": grade, "best_pattern": best.get("pattern"), "bias": best.get("type", "neutral"), "touches": touches, "completion": completion, "drivers": [f"completion {completion:.0f}%", f"touches {touches}", f"breakout proximity {proximity:.1f}"]}

    def _breakout_quality(self, candles: List[Dict[str, Any]], current_price: float, support: float, resistance: float, range_size: float) -> Dict[str, Any]:
        if len(candles) < 5:
            return {"score": 0, "state": "UNKNOWN"}
        last_body = abs(float(candles[-1]["close"]) - float(candles[-1]["open"]))
        prev_bodies = [abs(float(c["close"]) - float(c["open"])) for c in candles[-5:-1]]
        avg_body = mean(prev_bodies) if prev_bodies else last_body
        expansion = last_body / max(avg_body, 0.0001)
        broke_res = current_price > resistance
        broke_sup = current_price < support
        score = 50.0
        state = "RANGE_BOUND"
        if broke_res or broke_sup:
            score = 65.0 + min(25.0, expansion * 10.0)
            state = "BREAKOUT_EXPANDING" if expansion >= 1.5 else "BREAKOUT_MODEST"
        return {"score": round(min(score, 100), 1), "state": state, "atr_expansion_proxy": round(expansion, 2)}

    def _retest_state(self, current_price: float, support: float, resistance: float, range_size: float) -> str:
        if abs(current_price - resistance) / range_size <= 0.05:
            return "RETESTING_RESISTANCE"
        if abs(current_price - support) / range_size <= 0.05:
            return "RETESTING_SUPPORT"
        return "NO_RETEST"

    def _build_trendline(self, swings: Dict[str, Any], current_price: float, dec: int = 2) -> Dict[str, Any]:
        highs = swings.get("highs", [])
        lows = swings.get("lows", [])
        if len(lows) >= 2 and lows[-1]["price"] > lows[-2]["price"]:
            level = float(lows[-1]["price"])
            return {"direction": "ASCENDING", "respected": current_price >= level * 0.998, "current_level": round(level, dec)}
        if len(highs) >= 2 and highs[-1]["price"] < highs[-2]["price"]:
            level = float(highs[-1]["price"])
            return {"direction": "DESCENDING", "respected": current_price <= level * 1.002, "current_level": round(level, dec)}
        return {"direction": "SIDEWAYS", "respected": True, "current_level": round(current_price, dec)}

    def _detect_classical_patterns(self, candles: List[Dict[str, Any]], swings: Dict[str, Any], current_price: float, support: float, resistance: float, range_size: float, dec: int = 2) -> List[Dict[str, Any]]:
        patterns: List[Dict[str, Any]] = []
        highs = swings.get("highs", [])
        lows = swings.get("lows", [])
        tolerance = range_size * 0.04
        _r = lambda v: round(float(v), dec)

        patterns.extend(self._flag_patterns(candles, current_price, range_size, dec=dec))
        patterns.extend(self._head_and_shoulders_patterns(highs, lows, current_price, support, resistance, tolerance, dec=dec))
        patterns.extend(self._double_triple_patterns(highs, lows, current_price, support, resistance, tolerance, range_size, dec=dec))
        patterns.extend(self._triangle_patterns(candles, highs, lows, support, resistance, tolerance, range_size, dec=dec))
        patterns.extend(self._channel_wedge_patterns(highs, lows, current_price, support, resistance, range_size, dec=dec))

        if not patterns:
            patterns.append({
                "pattern": "NO_CLEAR_PATTERN",
                "status": "FORMING",
                "completion": 0,
                "breakout_level": _r(resistance if current_price >= (support + resistance) / 2 else support),
                "target": _r(resistance if current_price >= (support + resistance) / 2 else support),
                "type": "neutral",
                "confidence": "low",
            })
        return patterns

    def _head_and_shoulders_patterns(
        self, highs: List[Dict[str, Any]], lows: List[Dict[str, Any]],
        current_price: float, support: float, resistance: float, tolerance: float, dec: int = 2,
    ) -> List[Dict[str, Any]]:
        patterns: List[Dict[str, Any]] = []
        _r = lambda v: round(float(v), dec)

        def _build(points: List[Dict[str, Any]], inverse: bool = False) -> Dict[str, Any] | None:
            if len(points) < 3:
                return None
            p1, p2, p3 = points[-3:]
            v1, v2, v3 = float(p1["price"]), float(p2["price"]), float(p3["price"])
            head_valid = (v2 > max(v1, v3)) if not inverse else (v2 < min(v1, v3))
            shoulders_level = abs(v1 - v3) <= tolerance * 2.0
            if not (head_valid and shoulders_level):
                return None
            if not inverse:
                neckline = min(float(p["price"]) for p in lows) if lows else ((float(p1["price"]) + float(p3["price"])) / 2.0 - (float(p2["price"]) - float(p1["price"])) * 0.833)
            else:
                neckline = max(float(p["price"]) for p in highs) if highs else ((float(p1["price"]) + float(p3["price"])) / 2.0 + (float(p1["price"]) - float(p2["price"])) * 0.833)
            target = neckline - abs(v2 - neckline) if not inverse else neckline + abs(v2 - neckline)
            broke = current_price < neckline if not inverse else current_price > neckline
            completion = 100 if broke else 75
            return {
                "pattern": "Inverse Head and Shoulders" if inverse else "Head and Shoulders",
                "type": "bullish" if inverse else "bearish",
                "status": "COMPLETE" if broke else "FORMING",
                "neckline": _r(neckline),
                "head": _r(v2),
                "target": _r(target),
                "breakout_level": _r(neckline),
                "completion": completion,
                "touches": 3,
                "confidence": "high" if completion >= 100 else "medium",
            }

        h = _build(highs[-5:], inverse=False)
        if h: patterns.append(h)
        inv = _build(lows[-5:], inverse=True)
        if inv: patterns.append(inv)
        return patterns

    def _head_shoulders_patterns(
        self, highs: List[Dict[str, Any]], lows: List[Dict[str, Any]],
        current_price: float, tolerance: float, range_size: float,
        support: float | None = None, resistance: float | None = None, dec: int = 2,
    ) -> List[Dict[str, Any]]:
        sup = support if support is not None else (min(float(p["price"]) for p in lows) if lows else current_price)
        res = resistance if resistance is not None else (max(float(p["price"]) for p in highs) if highs else current_price)
        return self._head_and_shoulders_patterns(highs, lows, current_price, sup, res, tolerance, dec=dec)

    def _flag_patterns(
        self, candles: List[Dict[str, Any]], current_price: float, range_size: float, dec: int = 2,
    ) -> List[Dict[str, Any]]:
        patterns: List[Dict[str, Any]] = []
        if len(candles) < 12:
            return patterns
        _r = lambda v: round(float(v), dec)
        window = candles[-12:]
        highs = [self._f(c["high"]) for c in window]
        lows = [self._f(c["low"]) for c in window]
        closes = [self._f(c["close"]) for c in window]
        pole = abs(closes[-1] - closes[0])
        if pole < range_size * 0.45:
            return patterns
        direction = "bull" if closes[-1] > closes[0] else "bear"
        cons = candles[-4:]
        c_highs = [self._f(c["high"]) for c in cons]
        c_lows = [self._f(c["low"]) for c in cons]
        if direction == "bull":
            consolidating = c_highs[-1] < c_highs[0] and c_lows[-1] < c_lows[0]
            breakout = current_price > c_highs[0]
        else:
            consolidating = c_highs[-1] > c_highs[0] and c_lows[-1] > c_lows[0]
            breakout = current_price < c_lows[0]
        if not consolidating:
            return patterns
        patterns.append({
            "pattern": "Bull Flag" if direction == "bull" else "Bear Flag",
            "type": "bullish" if direction == "bull" else "bearish",
            "status": "COMPLETE" if breakout else "FORMING",
            "completion": 100 if breakout else 65,
            "pole_size": _r(pole),
            "breakout_level": _r(c_highs[0] if direction == "bull" else c_lows[0]),
            "target": _r((c_highs[0] + pole) if direction == "bull" else (c_lows[0] - pole)),
            "touches": 4,
            "confidence": "high" if breakout else "medium",
        })
        return patterns

    def _double_triple_patterns(self, highs: List[Dict[str, Any]], lows: List[Dict[str, Any]], current_price: float, support: float, resistance: float, tolerance: float, range_size: float, dec: int = 2) -> List[Dict[str, Any]]:
        patterns: List[Dict[str, Any]] = []
        last_highs = highs[-5:]
        last_lows = lows[-5:]
        high_prices = [float(p["price"]) for p in last_highs]
        low_prices = [float(p["price"]) for p in last_lows]
        eq_highs = self._near_equal_points(high_prices, tolerance)
        eq_lows = self._near_equal_points(low_prices, tolerance)
        _r = lambda v: round(float(v), dec)
        if len(eq_highs) >= 2:
            neckline = min(low_prices) if low_prices else support
            completion = 100 if current_price < neckline else 72
            touches = len(eq_highs)
            patterns.append({"pattern": "Triple Top" if touches >= 3 else "Double Top", "status": "COMPLETE" if completion >= 100 else "FORMING", "completion": completion, "touches": touches, "neckline": _r(neckline), "breakout_level": _r(neckline), "target": _r(neckline - (mean(eq_highs) - neckline)), "type": "bearish", "confidence": "high" if touches >= 3 else "medium"})
        if len(eq_lows) >= 2:
            neckline = max(high_prices) if high_prices else resistance
            completion = 100 if current_price > neckline else 72
            touches = len(eq_lows)
            patterns.append({"pattern": "Triple Bottom" if touches >= 3 else "Double Bottom", "status": "COMPLETE" if completion >= 100 else "FORMING", "completion": completion, "touches": touches, "neckline": _r(neckline), "breakout_level": _r(neckline), "target": _r(neckline + (neckline - mean(eq_lows))), "type": "bullish", "confidence": "high" if touches >= 3 else "medium"})
        return patterns

    def _triangle_patterns(self, candles: List[Dict[str, Any]], highs: List[Dict[str, Any]], lows: List[Dict[str, Any]], support: float, resistance: float, tolerance: float, range_size: float, dec: int = 2) -> List[Dict[str, Any]]:
        patterns: List[Dict[str, Any]] = []
        if len(highs) < 2 or len(lows) < 2:
            return patterns
        h1, h2 = float(highs[-2]["price"]), float(highs[-1]["price"])
        l1, l2 = float(lows[-2]["price"]), float(lows[-1]["price"])
        high_slope = h2 - h1
        low_slope = l2 - l1
        flat_high = abs(high_slope) <= tolerance
        flat_low = abs(low_slope) <= tolerance
        completion = self._pattern_completion(candles, support, resistance)
        height = max(resistance - support, range_size * 0.2)
        _r = lambda v: round(float(v), dec)
        if flat_high and low_slope > tolerance:
            patterns.append({"pattern": "Ascending Triangle", "status": "COMPLETE" if completion >= 75 else "FORMING", "completion": completion, "touches": 3, "breakout_level": _r(resistance), "target": _r(resistance + height), "type": "bullish", "confidence": "medium"})
        elif flat_low and high_slope < -tolerance:
            patterns.append({"pattern": "Descending Triangle", "status": "COMPLETE" if completion >= 75 else "FORMING", "completion": completion, "touches": 3, "breakout_level": _r(support), "target": _r(support - height), "type": "bearish", "confidence": "medium"})
        elif high_slope < -tolerance and low_slope > tolerance:
            direction = "bullish" if candles[-1]["close"] > (support + resistance) / 2 else "bearish"
            patterns.append({"pattern": "Symmetrical Triangle", "status": "COMPLETE" if completion >= 75 else "FORMING", "completion": completion, "touches": 4, "breakout_level": _r(resistance if direction == "bullish" else support), "target": _r((resistance + height) if direction == "bullish" else (support - height)), "type": direction, "confidence": "medium"})
        return patterns

    def _channel_wedge_patterns(self, highs: List[Dict[str, Any]], lows: List[Dict[str, Any]], current_price: float, support: float, resistance: float, range_size: float, dec: int = 2) -> List[Dict[str, Any]]:
        patterns: List[Dict[str, Any]] = []
        if len(highs) < 3 or len(lows) < 3:
            return patterns
        hs = [float(p["price"]) for p in highs[-3:]]
        ls = [float(p["price"]) for p in lows[-3:]]
        high_slope = hs[-1] - hs[0]
        low_slope = ls[-1] - ls[0]
        width_start = hs[0] - ls[0]
        width_end = hs[-1] - ls[-1]
        narrowing = width_end < width_start * 0.75
        _r = lambda v: round(float(v), dec)
        if high_slope > 0 and low_slope > 0 and narrowing:
            patterns.append({"pattern": "Rising Wedge", "status": "FORMING", "completion": 72, "touches": 6, "breakout_level": _r(support), "target": _r(support - max(width_end, range_size * 0.15)), "type": "bearish", "confidence": "medium"})
        elif high_slope < 0 and low_slope < 0 and narrowing:
            patterns.append({"pattern": "Falling Wedge", "status": "FORMING", "completion": 72, "touches": 6, "breakout_level": _r(resistance), "target": _r(resistance + max(width_end, range_size * 0.15)), "type": "bullish", "confidence": "medium"})
        elif abs(high_slope - low_slope) <= range_size * 0.08:
            direction = "bullish" if high_slope > 0 else "bearish" if high_slope < 0 else "neutral"
            if direction != "neutral":
                patterns.append({"pattern": "Ascending Channel" if direction == "bullish" else "Descending Channel", "status": "FORMING", "completion": 68, "touches": 6, "breakout_level": _r(resistance if direction == "bullish" else support), "target": _r(resistance if direction == "bullish" else support), "type": direction, "confidence": "low"})
        return patterns

    def _near_equal_points(self, prices: List[float], tolerance: float) -> List[float]:
        if not prices:
            return []
        clusters: List[List[float]] = []
        for price in sorted(prices):
            if not clusters or abs(price - mean(clusters[-1])) > tolerance:
                clusters.append([price])
            else:
                clusters[-1].append(price)
        best = max(clusters, key=len) if clusters else []
        return best if len(best) >= 2 else []

    def _pattern_completion(self, candles: List[Dict[str, Any]], support: float, resistance: float) -> int:
        current = float(candles[-1]["close"])
        width = max(resistance - support, 0.00001)
        distance_to_edge = min(abs(resistance - current), abs(current - support))
        return int(max(50, min(100, 100 - (distance_to_edge / width) * 100)))

    def _level_strength(self, candles: List[Dict[str, Any]], supports: List[float], resistances: List[float], sym: str = "XAU/USD", dec: int = 2) -> Dict[str, Any]:
        range_span = max(float(c["high"]) for c in candles) - min(float(c["low"]) for c in candles)
        min_tol = point_size(sym, self.config) * 5
        tolerance = max(range_span * 0.04, min_tol)
        _r = lambda v: round(float(v), dec)
        def touches(level: float) -> int:
            return sum(1 for c in candles if abs(float(c["high"]) - level) <= tolerance or abs(float(c["low"]) - level) <= tolerance)
        return {
            "supports": [{"level": _r(x), "touches": touches(x), "valid": touches(x) >= 2} for x in supports[:5]],
            "resistances": [{"level": _r(x), "touches": touches(x), "valid": touches(x) >= 2} for x in resistances[:5]],
        }

    def _reason_codes(self, direction: str, trendline: Dict[str, Any], current_price: float, support: float, resistance: float, pivot_points: Dict[str, Any], patterns: List[Dict[str, Any]]) -> List[str]:
        codes = [f"CLASSICAL_{direction}"]
        if trendline.get("respected"):
            codes.append(f"CLASSICAL_TRENDLINE_{trendline.get('direction')}")
        if current_price > pivot_points.get("pivot", current_price):
            codes.append("CLASSICAL_ABOVE_PIVOT")
        elif current_price < pivot_points.get("pivot", current_price):
            codes.append("CLASSICAL_BELOW_PIVOT")
        for p in patterns[:2]:
            pname = p.get("pattern", "CLASSIC").upper().replace(" ", "_")
            codes.append(f"CLASSICAL_PATTERN_{pname}")
        return codes

    def _empty_result(self, summary: str) -> Dict[str, Any]:
        return {
            "agent": self.name,
            "direction": "NEUTRAL",
            "confidence": 0,
            "support_levels": [],
            "resistance_levels": [],
            "fibonacci_levels": {},
            "trendline": {"direction": "SIDEWAYS", "respected": True, "current_level": 0.0},
            "level_strength": {"supports": [], "resistances": []},
            "patterns_detected": [],
            "pattern_quality": {"score": 0, "grade": "NONE", "bias": "neutral"},
            "breakout_quality": {"score": 0, "state": "UNKNOWN"},
            "retest_state": "UNKNOWN",
            "no_clear_pattern": True,
            "scenarios": {},
            "signals": [],
            "summary": summary,
        }

    @staticmethod
    def _f(value: Any) -> float:
        try:
            return float(value or 0.0)
        except (TypeError, ValueError):
            return 0.0
