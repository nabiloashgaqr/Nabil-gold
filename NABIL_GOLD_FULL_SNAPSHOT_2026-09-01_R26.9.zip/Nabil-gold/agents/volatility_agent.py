"""
agents/volatility_agent.py — cross-asset volatility regime + risk multiplier hint.
(2026-08-19 upgrade, phase 2 - new agent)

Fills the volatility gap measured in the architecture review: no VIX/OVX/GVZ
anywhere. This agent reads the three fear gauges via yfinance (cached, free):

  ^VIX  equity fear (cross-asset risk appetite)          LOW <15  <20  <30  EXTREME
  ^GVZ  gold volatility index                             LOW <14  <20  <28  EXTREME
  ^OVX  oil volatility index                              LOW <30  <40  <55  EXTREME

For a gold run: ^VIX + ^GVZ; for a WTI run: ^VIX + ^OVX. The worst label wins.
A high ATR percentile from services/market_regime escalates the regime by one
level (both signals together mark real vol expansion, not index noise).

Voting policy: NEVER votes (signal="WAIT" always). Outputs:
  * regime (LOW/NORMAL/HIGH/EXTREME) for the active commodity
  * suggested_risk_multiplier (EXTREME 0.5 / HIGH 0.75 / else 1.0)
  * apply_risk_multiplier: config flag — when false the suggestion is
    informational only and never touches position sizing.

Fail-open: any missing index degrades to UNKNOWN / multiplier 1.0.
"""
from __future__ import annotations

from typing import Any, Dict, List

from .base_agent import BaseAgent
from services.aux_market_data import yf_closes

LEVELS = ["LOW", "NORMAL", "HIGH", "EXTREME", "UNKNOWN"]
_MULTIPLIER = {"EXTREME": 0.5, "HIGH": 0.75, "NORMAL": 1.0, "LOW": 1.0, "UNKNOWN": 1.0}


class VolatilityAgent(BaseAgent):
    name = "volatility"

    def __init__(self, config: Dict[str, Any] | None = None, **_kwargs: Any):
        super().__init__(config)
        cfg = self.config.get("volatility_agent") or {}
        self.enabled = bool(cfg.get("enabled", True))
        self.ttl_hours = float(cfg.get("ttl_hours", 24) or 24)
        self.apply_risk_multiplier = bool(cfg.get("apply_risk_multiplier", False))
        self.atr_escalation = float(cfg.get("atr_escalation_percentile", 0.9) or 0.9)
        self.thresholds = {
            # (low, high, extreme)
            "^VIX": (
                float(cfg.get("vix_low", 15) or 15),
                float(cfg.get("vix_high", 20) or 20),
                float(cfg.get("vix_extreme", 30) or 30),
            ),
            "^GVZ": (
                float(cfg.get("gvz_low", 14) or 14),
                float(cfg.get("gvz_high", 20) or 20),
                float(cfg.get("gvz_extreme", 28) or 28),
            ),
            "^OVX": (
                float(cfg.get("ovx_low", 30) or 30),
                float(cfg.get("ovx_high", 40) or 40),
                float(cfg.get("ovx_extreme", 55) or 55),
            ),
        }

    def _classify(self, value: float, symbol: str) -> str:
        low, high, extreme = self.thresholds.get(symbol, (15.0, 20.0, 30.0))
        if value >= extreme:
            return "EXTREME"
        if value >= high:
            return "HIGH"
        if value < low:
            return "LOW"
        return "NORMAL"

    def _index(self, symbol: str, path: str) -> Dict[str, Any] | None:
        closes = yf_closes(symbol, days=120, cache_path=path, ttl_hours=self.ttl_hours)
        if not closes or len(closes) < 10:
            return None
        latest = float(closes[-1])
        pctl = round(sum(1 for v in closes if v < latest) / len(closes) * 100.0, 1)
        return {
            "symbol": symbol,
            "latest": round(latest, 2),
            "percentile": pctl,
            "label": self._classify(latest, symbol),
        }

    def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self.enabled:
            return {"agent": self.name, "enabled": False, "signal": "WAIT",
                    "regime": "UNKNOWN", "suggested_risk_multiplier": 1.0,
                    "summary": "Volatility agent disabled"}

        symbol = str(data.get("symbol") or self.config.get("symbol", "XAU/USD"))
        commodity = "WTI" if "WTI" in symbol.upper() else "GOLD"
        indices: Dict[str, Any] = {}
        missing: List[str] = []

        vix = self._index("^VIX", "storage/aux_cache/IDX_VIX.json")
        if vix:
            indices["^VIX"] = vix
        else:
            missing.append("^VIX")
        if commodity == "GOLD":
            gvz = self._index("^GVZ", "storage/aux_cache/IDX_GVZ.json")
            if gvz:
                indices["^GVZ"] = gvz
            else:
                missing.append("^GVZ")
        else:
            ovx = self._index("^OVX", "storage/aux_cache/IDX_OVX.json")
            if ovx:
                indices["^OVX"] = ovx
            else:
                missing.append("^OVX")

        labels = [i["label"] for i in indices.values() if i.get("label")]
        regime = max(labels, key=lambda x: LEVELS.index(x)) if labels else "UNKNOWN"
        reasons: List[str] = [
            f"{i['symbol']} {i['latest']} ({i['label']}, {i['percentile']}th pctile)"
            for i in indices.values()
        ]

        # ATR-percentile escalation (market_regime layer, MT5 D1)
        market_regime = data.get("market_regime") or {}
        atr_pctl = None
        try:
            atr_pctl = float(market_regime.get("vol_percentile"))
        except (TypeError, ValueError):
            atr_pctl = None
        if regime != "UNKNOWN" and atr_pctl is not None and atr_pctl >= self.atr_escalation:
            idx = LEVELS.index(regime)
            if idx < LEVELS.index("EXTREME"):
                regime = LEVELS[idx + 1]
                reasons.append(f"ATR percentile {atr_pctl:.2f} escalated regime to {regime}")

        multiplier = _MULTIPLIER.get(regime, 1.0)
        return {
            "agent": self.name,
            "signal": "WAIT",  # never votes
            "commodity": commodity,
            "regime": regime,
            "indices": indices,
            "missing": missing,
            "suggested_risk_multiplier": multiplier,
            "apply_risk_multiplier": self.apply_risk_multiplier,
            "atr_percentile": atr_pctl,
            "summary": "; ".join(reasons) if reasons else "No volatility inputs available",
            "reason_codes": [i["symbol"] for i in indices.values()],
            "timestamp": self.now_iso(),
        }
