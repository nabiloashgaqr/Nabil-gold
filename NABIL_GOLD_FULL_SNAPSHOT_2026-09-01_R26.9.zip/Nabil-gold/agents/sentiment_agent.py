"""
agents/sentiment_agent.py — COT positioning + ETF flow sentiment (non-voting).
(2026-08-19 upgrade, phase 2 - new agent)

Fills the sentiment gap measured in the architecture review (2/10):
  * CFTC disaggregated COT: Money-Manager net positioning (gold + WTI),
    weekly, contrarian at extremes — the classic crowded-longs/crowded-shorts
    signal. Percentile measured against the operator's own accumulated
    history (>= min_history_weeks points required before any score is applied).
  * ETF demand proxy (gold only): 21-day GLD + IAU momentum.

Voting policy: this agent NEVER votes. It returns signal="WAIT" always; the
directional verdict lives in `direction`/`bias` and is exposed as context and,
later, as a possible external confirmer (macro-style, threshold 55).

Fail-open: missing COT or ETF data degrades to WAIT/0 confidence with the
missing inputs listed — the analysis cycle never breaks.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base_agent import BaseAgent
from services.aux_market_data import append_cot_history, fetch_cot, yf_closes


class SentimentAgent(BaseAgent):
    name = "sentiment"

    def __init__(self, config: Dict[str, Any] | None = None, **_kwargs: Any):
        super().__init__(config)
        cfg = self.config.get("sentiment_agent") or {}
        self.enabled = bool(cfg.get("enabled", True))
        self.min_history = int(cfg.get("min_history_weeks", 8) or 8)
        self.pctl_hi = float(cfg.get("extreme_high_pctile", 90) or 90)
        self.pctl_hi_mild = float(cfg.get("mild_high_pctile", 75) or 75)
        self.pctl_lo_mild = float(cfg.get("mild_low_pctile", 25) or 25)
        self.pctl_lo = float(cfg.get("extreme_low_pctile", 10) or 10)
        self.etf_symbols = [str(s) for s in (cfg.get("etf_symbols") or ["GLD", "IAU"])]
        self.etf_lookback = int(cfg.get("etf_lookback_days", 21) or 21)
        self.etf_threshold = float(cfg.get("etf_threshold_pct", 3.0) or 3.0)
        self.etf_cache_ttl_hours = float(cfg.get("etf_ttl_hours", 24) or 24)

    def _commodity(self, data: Dict[str, Any]) -> str:
        symbol = str(data.get("symbol") or self.config.get("symbol", "XAU/USD"))
        return "wti" if "WTI" in symbol.upper() else "gold"

    def _etf_momentum(self) -> Optional[Dict[str, Any]]:
        rets: List[float] = []
        details: Dict[str, Any] = {}
        for sym in self.etf_symbols:
            closes = yf_closes(
                sym,
                days=max(60, self.etf_lookback * 3),
                cache_path=f"storage/aux_cache/{sym}.json",
                ttl_hours=self.etf_cache_ttl_hours,
            )
            if not closes or len(closes) <= self.etf_lookback:
                return None
            ret = (closes[-1] / closes[-(self.etf_lookback + 1)] - 1.0) * 100.0
            rets.append(float(ret))
            details[sym] = round(float(ret), 2)
        return {"valid": True, "avg_ret": sum(rets) / len(rets), "per_symbol": details}

    def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self.enabled:
            return {"agent": self.name, "enabled": False, "signal": "WAIT",
                    "direction": "WAIT", "confidence": 0, "summary": "Sentiment agent disabled"}

        commodity = self._commodity(data)
        score = 0.0
        reasons: List[str] = []
        missing: List[str] = []
        evidence: List[Dict[str, Any]] = []

        cot = fetch_cot(self.config)
        hist = append_cot_history(self.config, cot)
        row = (cot or {}).get(commodity)
        pctl = None
        mm_net_pct = None

        if row:
            net = int(row["mm_long"]) - int(row["mm_short"])
            mm_net_pct = round(net / max(int(row["oi"]), 1) * 100.0, 3)
            series = [float(e["mm_net_pct"]) for e in hist if e.get("commodity") == commodity]
            evidence.append({
                "cot_report_date": row["report_date"],
                "oi": row["oi"],
                "mm_long": row["mm_long"],
                "mm_short": row["mm_short"],
                "mm_net_pct": mm_net_pct,
                "history_weeks": len(series),
            })
            if len(series) >= self.min_history:
                pctl = round(sum(1 for v in series if v < mm_net_pct) / len(series) * 100.0, 1)
                evidence[-1]["percentile"] = pctl
                if pctl >= self.pctl_hi:
                    score -= 2.5
                    reasons.append(f"COT crowded longs: MM net {mm_net_pct}% of OI at {pctl}th pctile (contrarian bearish)")
                elif pctl <= self.pctl_lo:
                    score += 2.5
                    reasons.append(f"COT crowded shorts: MM net {mm_net_pct}% of OI at {pctl}th pctile (contrarian bullish)")
                elif pctl >= self.pctl_hi_mild:
                    score -= 1.0
                    reasons.append(f"COT leaning long: {pctl}th pctile (mild contrarian bearish)")
                elif pctl <= self.pctl_lo_mild:
                    score += 1.0
                    reasons.append(f"COT leaning short: {pctl}th pctile (mild contrarian bullish)")
                else:
                    reasons.append(f"COT positioning neutral at {pctl}th pctile")
            else:
                reasons.append(
                    f"COT history {len(series)}/{self.min_history} weeks - informational only"
                )
        else:
            missing.append("cot")

        if commodity == "gold":
            etf = self._etf_momentum()
            if etf is None:
                missing.append("etf_flow")
            elif etf.get("valid"):
                evidence.append({"etf_momentum": etf})
                avg = float(etf["avg_ret"])
                if avg >= self.etf_threshold:
                    score += 1.5
                    reasons.append(f"ETF demand: GLD/IAU {avg:+.1f}% over {self.etf_lookback}d")
                elif avg <= -self.etf_threshold:
                    score -= 1.5
                    reasons.append(f"ETF outflow: GLD/IAU {avg:+.1f}% over {self.etf_lookback}d")
                else:
                    reasons.append(f"ETF flows neutral: {avg:+.1f}% over {self.etf_lookback}d")

        direction = "BUY" if score > 0 else "SELL" if score < 0 else "WAIT"
        side = "BULLISH" if score > 0 else "BEARISH" if score < 0 else "NEUTRAL"
        bias = f"{side}_{commodity.upper()}"
        confidence = min(80, round(40.0 + abs(score) * 10.0)) if direction != "WAIT" else 0

        return {
            "agent": self.name,
            "signal": "WAIT",  # never votes
            "direction": direction,
            "confidence": confidence,
            "bias": bias,
            "commodity": commodity,
            "cot_percentile": pctl,
            "mm_net_pct": mm_net_pct,
            "score": round(score, 2),
            "summary": "; ".join(reasons) if reasons else "No sentiment inputs available",
            "reason_codes": [r.split(":")[0][:24] for r in reasons],
            "evidence": evidence,
            "missing": missing,
            "source": "cftc_deacom + etf_proxy",
            "timestamp": self.now_iso(),
        }
