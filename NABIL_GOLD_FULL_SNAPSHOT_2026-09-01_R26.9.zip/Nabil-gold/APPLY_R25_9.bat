@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ============================================================
echo   R25.9 - Tatbeq islahat ma ba3d al-tashkhis
echo   (yarfa3 al-nusakh ila C:\Nabil-gold wa yajri al-ikhtibarat hunak)
echo ============================================================
echo.

REM --- locate python ---
set "PY="
where py >nul 2>nul && set "PY=py"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo [X] lam yatawaffar Python. thabbit Python aw shaghel yadawiyan:
  echo     py APPLY_R25_9_HARDENING.py --apply
  echo.
  pause
  exit /b 1
)

REM --- apply AND run the unit tests from inside the real project root ---
%PY% APPLY_R25_9_HARDENING.py --apply
echo.
echo ------------------------------------------------------------
echo Tam. A3id tashgheel khidmat run_tick_manager li-tafa33ul
echo al-bawwaba al-jadida.
echo ------------------------------------------------------------
echo.
pause
