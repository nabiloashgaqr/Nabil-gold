"""DEPRECATED root shim - BUILD 31 R11 (local-only, 2026-08-27).

The canonical DatabaseService lives in ``services/database.py`` (the copy
every module and test imports). This root copy was a stale duplicate from an
early phase and drifted silently. It now re-exports the canonical module -
one implementation, zero drift. Storage is LOCAL JSON only (no Supabase).
"""
from __future__ import annotations

import os
import sys

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from services.database import *  # noqa: F401,F403
from services.database import DatabaseService  # noqa: F401
