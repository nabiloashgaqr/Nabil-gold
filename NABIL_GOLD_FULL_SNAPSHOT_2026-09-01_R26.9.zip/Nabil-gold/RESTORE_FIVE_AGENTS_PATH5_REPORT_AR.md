# تقرير: استعادة الوكلاء الخمسة + المسار الخامس — 2026-08-14

## ملخص القرار (بموافقة المشغّل)

| البند | القرار |
|---|---|
| كتاب التصويت | استعادة الخمسة الأصليين: Classical / Technical / SMC / Price Action / Multi-Timeframe |
| Auction Flow | وكيل مستقل **غير مصوّت** — يؤكد المسارين 4 و5 فقط |
| UnifiedTrend | **حذف كامل بلا أي أثر** (الملف + المعايرة + كل الإشارات في الكود) |
| المسار 5 الجديد | وكيلان مؤهلان + تأكيد Auction Flow ≥72% |
| معارضة المسار 5 | مسموحة مع خصم الثقة (مثل المسارين 2 و3) — لا فيتو تلقائي |

## نتيجة الاختبارات

**1853 ناجح، 0 فاشل، 3 متخطاة** — وصفر إشارات متبقية لـ`unified_trend` في أي ملف بايثون.

---

## 1) أوزان الوكلاء المستعادة (`config.json` + `utils/helpers.py`)

| الوكيل | الوزن |
|---|---|
| classical | 0.25 |
| technical | 0.20 |
| smc | 0.20 |
| price_action | 0.20 |
| multitimeframe | 0.15 |
| **المجموع** | **1.00** |

`auction_flow` خرج من `agent_weights` نهائياً وأضيف عليه `"voting": false` في كتلة `auction_flow` بالإعدادات.

## 2) المسار الخامس — PATH 5: TWO-AGENT + AUCTION FLOW

**التعريف في `config.json`:**
```json
"path5_two_agent_auction": {
  "enabled": true,
  "min_agents_agree": 2,
  "min_consensus_confidence": 72,
  "agent_min_confidence": 67,
  "min_auction_confidence": 72
}
```

**قاعدة القبول:** وكيلان أساسيان مؤهلان (≥67% لكل منهما) بصافي ثقة موزونة ≥72% بعد خصم المعارضة القياسي، + Auction Flow بنفس الاتجاه بثقة ≥72%.

**ترتيب الفحص:** المسار 1 (إجماع ثلاثي) ← المسار 2 (Macro) ← المسار 3 (Gemini) ← **المسار 5 (Auction)** ← المسار 4 (خريطة SMC — طريق خاص LIMIT فقط).

**أين نُفّذ:**
- `services/thesis_consensus.py` — كتلة القبول المشتركة (المصدر الوحيد للحقيقة؛ يمر منها المخطط وscale-in وthesis exits تلقائياً)
- `scripts/run_analysis.py` — Step C في فرع الدخول المباشر (بعد فشل Macro وGemini)، مع احترام رفض وكيل المخاطر وفحص المسافة بين المسارات كما في المسار 2
- `services/execution_paths.py` — تسجيل `PATH_5_TWO_AGENT_AUCTION` رسمياً: يظهر في بطاقات تيليجرام (🛣️ PATH 5) وقياسات `path_performance` كعينة مستقلة خامسة

## 3) حذف UnifiedTrend الكامل

**ملفات حُذفت:**
- `agents/unified_trend_agent.py`
- `scripts/verify_unified_five_agents.py`
- `tests/test_unified_five_agent_system.py`
- `tests/test_unified_trend_calibration_parity.py`
- `storage/model_calibration/unified_trend_v1.json`

**ملفات نُظّفت من إشاراته (21 ملف كود):**
`run_analysis.py`، `decision_agent.py`، `risk_management_agent.py`، `open_trades_manager.py`، `thesis_consensus.py`، `directional_authority.py`، `session_planner.py`، `telegram_bot.py`، `strategy_profiles.py`، `learning_service.py`، `llm_review.py`، `moment_quality.py`، `agent_measurement.py`، `agent_confidence_audit.py`، `dashboard_local_api.py`، `check_agents_now.py`، `build_agent_calibrations.py`، `summarize_agent_measurements.py`، `audit_today_maps_and_agents.py`، `utils/helpers.py`، + 8 ملفات اختبار حُدّثت.

**تغييرات مرافقة:**
- `run_analysis.py` يشغّل الآن `TechnicalAgent` و`MultiTimeframeAgent` في كل دورة (الكتاب الرئيسي وكتاب ما قبل الخروج)
- `lead_agent` لبروفايل `trend_pullback` عاد إلى `multitimeframe`
- `operation_mode` أصبح `five_agent_consensus`
- مدرّب المعايرة `build_agent_calibrations.py` يدرّب Auction Flow فقط
- خرائط legacy aliases القديمة (`unified_trend→technical`) أزيلت بالكامل — لا قراءة له حتى من اللقطات القديمة (حسب اختيارك «حذف كامل بلا أثر»)

## 4) اختبارات جديدة

`tests/test_path5_two_agent_auction.py` — 12 اختباراً تغطي:
- القبول الكامل (وكيلان + auction ≥72)
- الرفض: ثقة auction تحت 72 / اتجاه معاكس / WAIT / مسار معطّل / مؤيد واحد فقط
- المعارضة المؤهلة تُخصم ولا تمنع، لكن كثرتها تُسقط الصفقة تحت 72 فتُرفض
- أولوية Macro على Auction عند تأكيد كليهما
- Auction لا يدخل قائمة المؤيدين أبداً
- تسجيل المسار في `execution_paths` وحلّه من `entry_mode`

`tests/test_canonical_agent_policy.py` أعيدت كتابته لسياسة 2026-08-14 (الأوزان القانونية الخمسة + استقلالية auction + إعلان المسار 5).

## ⚠️ خطوات تشغيلية متبقية عليك (خارج الكود)

1. **المعايرة:** شغّل `python scripts/build_agent_calibrations.py` على VPS (يحتاج MT5) لتجديد معايرة Auction Flow — لم يعد يبني معايرة unified_trend.
2. اللقطات القديمة المخزنة في Supabase باسم `unified_trend` لن تُقرأ بعد الآن (اخترت الحذف الكامل) — القياسات التاريخية لهذا الوكيل تبقى في الجداول لكنها لن تُعرض.
3. مفاتيح `.env` ما زالت بحاجة إلى تدوير كما نبّهت سابقاً.
