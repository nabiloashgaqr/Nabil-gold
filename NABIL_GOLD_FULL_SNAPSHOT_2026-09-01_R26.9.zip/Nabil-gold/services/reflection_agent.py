# -*- coding: utf-8 -*-
"""services/reflection_agent.py — short-term REFLECTION MEMORY (R25.8).

Closes the "memory-based reasoning" gap: when a POI / setup fails because the
market SWEPT it and ran stops (a stop hunt / raid that did NOT reverse, or a
fade that got run over), the system should remember that exact trap for a few
hours and not walk straight back into the same level. This is deliberately
SIMPLE and non-mathematical — it does NOT fit weights, retrain thresholds, or
touch agent calibration. It is a short, symbol+zone-scoped cooldown veto with
an auditable reason, exactly like a trader who says "they just raided that
level and kept going — leave it alone for a couple of hours."

Storage: storage/reflection_memory.json (a list of reflection records). It is
runtime state, never shipped in the snapshot and never read by admission math
beyond the time-boxed veto below.

Lifecycle of a record:
    ARMED (the level failed) -> ACTIVE veto until cooldown_hours elapse ->
    EXPIRED (kept for the weekly reflection digest, no longer vetoes).

The veto is ZONE-SCOPED: only a fresh setup whose entry POI overlaps the
burned zone (within cooldown_band_points) is blocked; unrelated levels trade
normally. It never vetoes a protective action (closing / moving a stop).
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from utils.instruments import points_to_price

logger = logging.getLogger(__name__)

DEFAULTS: Dict[str, Any] = {
    "enabled": True,
    # How long a burned level stays a hard cooldown after the failure.
    "cooldown_hours": 3.0,
    # How long records are retained for the reflection digest before pruning.
    "retain_hours": 72.0,
    # A fresh POI within this many points of a burned level is considered the
    # SAME trap (system points, same unit as the stop law).
    "cooldown_band_points": 120.0,
    # Max consecutive burn records kept per symbol (bloat guard).
    "max_records_per_symbol": 50,
    "description": (
        "R25.8 (2026-08-29): ذاكرة التأمل قصيرة المدى. عندما يُمسح مستوى "
        "ويُهاجَم ستوبه دون ارتداد (فخ سيولة)، يُسجَّل المستوى وتُمنع إعادة "
        "الدخول إليه لـ cooldown_hours ساعات ضمن نطاق cooldown_band_points — "
        "فيتو مؤقت قابل للتدقيق، بلا أي إعادة ملاءمة أوزان أو عتبات."
    ),
}

STORAGE_PATH = "storage/reflection_memory.json"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _parse_dt(value: Any) -> Optional[datetime]:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except (ValueError, TypeError):
        return None


def config_block(config: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    out = dict(DEFAULTS)
    raw = ((config or {}).get("reflection_agent") or {})
    if isinstance(raw, dict):
        for k, v in raw.items():
            if k != "description":
                out[k] = v
    return out


class ReflectionAgent:
    """File-backed, fail-open reflection memory."""

    def __init__(self, config: Optional[Dict[str, Any]] = None,
                 path: Optional[str] = None) -> None:
        self.config = config or {}
        self.cfg = config_block(config)
        self.path = Path(path) if path else (
            Path(__file__).resolve().parents[1] / STORAGE_PATH)

    # ── persistence (fail-open) ───────────────────────────────────────────
    def _load(self) -> List[Dict[str, Any]]:
        try:
            if self.path.exists():
                data = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(data, list):
                    return data
                if isinstance(data, dict) and isinstance(data.get("records"), list):
                    return data["records"]
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("reflection memory unreadable (fail-open): %s", exc)
        return []

    def _save(self, records: List[Dict[str, Any]]) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(
                {"updated_at": _now().replace(microsecond=0).isoformat(),
                 "records": records}, ensure_ascii=False, indent=0),
                encoding="utf-8")
            os.replace(tmp, self.path)
        except OSError as exc:
            logger.warning("reflection memory write failed (fail-open): %s", exc)

    # ── recording ─────────────────────────────────────────────────────────
    def record_burn(self, *, symbol: str, level: float, direction: str,
                    burn_type: str = "stop_hunt_sweep",
                    trade_id: Optional[str] = None,
                    extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Record a level that failed via a sweep/stop-hunt.

        Called when a setup/trade at `level` (a POI) was invalidated by price
        sweeping through it and continuing — the trap signature. Idempotent for
        the same symbol+level+cooldown window (it refreshes the timestamp).
        """
        if not bool(self.cfg.get("enabled", True)):
            return {"recorded": False, "reason": "disabled"}
        level = float(level or 0.0)
        if level <= 0:
            return {"recorded": False, "reason": "no_level"}
        records = self._load()
        now = _now()
        band_price = points_to_price(float(self.cfg["cooldown_band_points"]), symbol)
        # Refresh an existing active record for the same trap instead of dup.
        for rec in records:
            if (str(rec.get("symbol")) == str(symbol)
                    and str(rec.get("direction") or "").upper() == str(direction).upper()
                    and abs(float(rec.get("level") or 0) - level) <= band_price
                    and rec.get("state") == "ACTIVE"):
                rec["burned_at"] = now.replace(microsecond=0).isoformat()
                rec["burn_count"] = int(rec.get("burn_count", 1)) + 1
                rec["level"] = level
                self._save(self._prune(records))
                return {"recorded": True, "refreshed": True, "level": level,
                        "burn_count": rec["burn_count"]}
        record = {
            "id": f"refl-{symbol.replace('/', '')}-{int(level*100)}-{int(now.timestamp())}",
            "symbol": str(symbol),
            "level": round(level, 5),
            "direction": str(direction or "").upper(),
            "burn_type": str(burn_type),
            "trade_id": trade_id,
            "burned_at": now.replace(microsecond=0).isoformat(),
            "state": "ACTIVE",
            "burn_count": 1,
            "extra": extra or {},
        }
        records.append(record)
        self._save(self._prune(records))
        return {"recorded": True, "refreshed": False, "level": level}

    # ── the time-boxed veto ───────────────────────────────────────────────
    def review(self, *, symbol: str, poi_level: float,
               direction: str = "", at: Optional[datetime] = None) -> Dict[str, Any]:
        """Return a veto verdict for a proposed new entry at `poi_level`.

        {"veto": bool, "reason": str|None, "burn": record|None,
         "remaining_minutes": float|None}
        Fail-open: any problem returns veto=False.
        """
        if not bool(self.cfg.get("enabled", True)):
            return {"veto": False, "reason": None}
        poi_level = float(poi_level or 0.0)
        if poi_level <= 0:
            return {"veto": False, "reason": None}
        now = at or _now()
        cooldown_h = float(self.cfg["cooldown_hours"])
        band_price = points_to_price(float(self.cfg["cooldown_band_points"]), symbol)
        for rec in self._load():
            if rec.get("state") != "ACTIVE" or str(rec.get("symbol")) != str(symbol):
                continue
            burned_at = _parse_dt(rec.get("burned_at"))
            if not burned_at:
                continue
            age_h = (now - burned_at).total_seconds() / 3600.0
            if age_h >= cooldown_h:
                continue  # expired — left for the digest, no longer vetoes
            if direction and str(rec.get("direction") or "").upper() != str(direction).upper():
                continue
            if abs(float(rec.get("level") or 0) - poi_level) > band_price:
                continue
            remaining = max(0.0, (cooldown_h - age_h) * 60.0)
            return {
                "veto": True,
                "reason": (f"reflection_cooldown: {symbol} {rec.get('direction')} "
                           f"level {rec.get('level')} burned by "
                           f"{rec.get('burn_type')} {age_h*60:.0f}m ago "
                           f"({remaining:.0f}m cooldown left)"),
                "burn": {"level": rec.get("level"), "burn_type": rec.get("burn_type"),
                         "burn_count": rec.get("burn_count"),
                         "burned_at": rec.get("burned_at")},
                "remaining_minutes": round(remaining, 1),
            }
        return {"veto": False, "reason": None}

    # ── housekeeping ──────────────────────────────────────────────────────
    def _prune(self, records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        now = _now()
        retain_h = float(self.cfg["retain_hours"])
        cooldown_h = float(self.cfg["cooldown_hours"])
        per_symbol: Dict[str, int] = {}
        kept: List[Dict[str, Any]] = []
        for rec in sorted(records, key=lambda r: str(r.get("burned_at") or ""),
                          reverse=True):
            sym = str(rec.get("symbol"))
            burned_at = _parse_dt(rec.get("burned_at"))
            if burned_at and (now - burned_at).total_seconds() / 3600.0 > retain_h:
                continue  # drop ancient
            if per_symbol.get(sym, 0) >= int(self.cfg["max_records_per_symbol"]):
                continue
            # Flip ACTIVE -> EXPIRED once the cooldown has elapsed (digest keeps).
            if rec.get("state") == "ACTIVE" and burned_at and \
                    (now - burned_at).total_seconds() / 3600.0 >= cooldown_h:
                rec = dict(rec)
                rec["state"] = "EXPIRED"
            kept.append(rec)
            per_symbol[sym] = per_symbol.get(sym, 0) + 1
        return kept

    def active_burns(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """Currently-vetoing records (for cards / diagnostics)."""
        now = _now()
        cooldown_h = float(self.cfg["cooldown_hours"])
        out = []
        for rec in self._load():
            if rec.get("state") != "ACTIVE":
                continue
            if symbol and str(rec.get("symbol")) != str(symbol):
                continue
            burned_at = _parse_dt(rec.get("burned_at"))
            if burned_at and (now - burned_at).total_seconds() / 3600.0 < cooldown_h:
                out.append(rec)
        return out

    def reflection_note(self, symbol: Optional[str] = None) -> str:
        """One-line card/diagnostic string summarising active cooldowns."""
        burns = self.active_burns(symbol)
        if not burns:
            return ""
        parts = [f"{b.get('symbol')}@{b.get('level')} ({b.get('burn_type')})"
                 for b in burns[:4]]
        more = f" +{len(burns)-4} more" if len(burns) > 4 else ""
        return "🧠 reflection cooldown: " + ", ".join(parts) + more
