"""Pure graded Auction Flow evidence transforms.

These functions keep pressure, value location and acceptance/rejection on a
continuous -1..+1 scale. They contain no voting threshold, weight, order or
risk logic and can be shared by live analysis and future calibration builds.
"""
from __future__ import annotations

import math
from typing import Any, Dict, Iterable, Mapping, Tuple


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def clip(value: float) -> float:
    return max(-1.0, min(1.0, float(value)))


def normalized_flow_pressure(raw_imbalance: float, *, scale: float = 0.12) -> float:
    """Expand small tick imbalances smoothly without hard clipping.

    ``scale`` is the raw imbalance producing tanh(1) ~= 0.76 evidence. The
    transform is monotonic, symmetric and remains bounded in -1..+1.
    """
    scale = max(1e-6, abs(_f(scale, 0.12)))
    return clip(math.tanh(_f(raw_imbalance) / scale))


def soft_value_score(raw_atr_distance: float, *, scale_atr: float = 2.0) -> float:
    """Convert signed ATR distance to bounded value evidence without a ±1 wall."""
    scale_atr = max(1e-6, abs(_f(scale_atr, 2.0)))
    return clip(math.tanh(_f(raw_atr_distance) / scale_atr))


def value_location_score(
    price: float, vwap: float, poc: float, atr: float, *, scale_atr: float = 2.0,
) -> float:
    atr = max(abs(_f(atr)), 1e-9)
    raw = ((_f(price) - _f(vwap)) / atr + (_f(price) - _f(poc)) / atr) / 2.0
    return soft_value_score(raw, scale_atr=scale_atr)


#: Candidate composite-edge definitions. ``extension_mean`` is the historical
#: formula. The others exist so the calibration builder can MEASURE which
#: combination of the three families actually ranks next-bar outcomes,
#: instead of guessing. Live agent and trainer must share this function so
#: the calibration curve is always trained on the exact quantity the live
#: agent computes (parity by construction).
EDGE_DEFINITIONS = (
    "extension_mean",            # mean(p,v,r) * coherence * quality (historical)
    "mean_no_coherence",         # mean(p,v,r) * quality
    "acceptance_only",           # r * quality
    "pressure_only",             # p * quality
    "value_only",                # v * quality
    "flow_confirmed_acceptance", # sqrt(|r|*|p|) when signs agree, else 0
)


def composite_auction_edge(
    pressure: float, value_location: float, response: float, quality: float,
    *, definition: str = "extension_mean",
) -> float:
    """One shared composite edge for the live agent AND the trainer."""
    p = clip(pressure)
    v = clip(value_location)
    r = clip(response)
    q = max(0.0, min(1.0, _f(quality, 0.0)))
    d = str(definition or "extension_mean")
    if d == "acceptance_only":
        return clip(r * q)
    if d == "pressure_only":
        return clip(p * q)
    if d == "value_only":
        return clip(v * q)
    if d == "mean_no_coherence":
        return clip((p + v + r) / 3.0 * q)
    if d == "flow_confirmed_acceptance":
        # Order-flow must CONFIRM the acceptance/rejection read. Extension
        # without flow is not conviction; flow without a value event is not
        # a location. Geometric mean rewards both being present.
        if r == 0.0 or p == 0.0 or (r > 0.0) != (p > 0.0):
            return 0.0
        return clip(math.copysign(math.sqrt(abs(r) * abs(p)) * q, r))
    base = (p + v + r) / 3.0
    absolute = abs(p) + abs(v) + abs(r)
    coherence = abs(p + v + r) / absolute if absolute else 0.0
    return clip(base * coherence * q)


def _trailing_streak(values: list[float], predicate) -> list[float]:
    streak: list[float] = []
    for value in reversed(values):
        if not predicate(value):
            break
        streak.append(value)
    streak.reverse()
    return streak


def graded_acceptance_rejection(
    rows: Iterable[Mapping[str, Any]],
    pressure: float,
    vah: float,
    val: float,
    atr: float,
    *,
    window: int = 5,
) -> Tuple[float, str, Dict[str, float]]:
    """Return continuous response evidence, state and transparent components.

    Initiative acceptance requires the latest three closes outside value and
    pressure in the same direction, as before. Its magnitude now reflects:
    duration outside value (35%), depth (30%), pressure (25%) and continuation
    away from value (10%). Responsive rejection is graded by excursion (40%),
    return depth (35%) and pressure (25%).
    """
    recent = [dict(row) for row in rows][-max(3, int(window or 5)):]
    closes = [_f(row.get("close")) for row in recent]
    atr = max(abs(_f(atr)), 1e-9)
    pressure = clip(pressure)
    neutral = {
        "duration": 0.0,
        "depth": 0.0,
        "pressure": abs(pressure),
        "continuation": 0.0,
        "excursion": 0.0,
        "return_depth": 0.0,
    }
    if len(closes) >= 3 and all(close > vah for close in closes[-3:]) and pressure > 0:
        streak = _trailing_streak(closes, lambda close: close > vah)
        duration = min(1.0, len(streak) / max(float(window or 5), 1.0))
        depth = math.tanh(sum(max(0.0, close - vah) for close in streak) / max(len(streak), 1) / atr)
        continuation = math.tanh(max(0.0, streak[-1] - streak[0]) / atr) if len(streak) > 1 else 0.0
        strength = clip(0.35 * duration + 0.30 * depth + 0.25 * abs(pressure) + 0.10 * continuation)
        return strength, "INITIATIVE_BUY_ACCEPTANCE", {
            **neutral, "duration": duration, "depth": depth,
            "continuation": continuation,
        }
    if len(closes) >= 3 and all(close < val for close in closes[-3:]) and pressure < 0:
        streak = _trailing_streak(closes, lambda close: close < val)
        duration = min(1.0, len(streak) / max(float(window or 5), 1.0))
        depth = math.tanh(sum(max(0.0, val - close) for close in streak) / max(len(streak), 1) / atr)
        continuation = math.tanh(max(0.0, streak[0] - streak[-1]) / atr) if len(streak) > 1 else 0.0
        strength = clip(0.35 * duration + 0.30 * depth + 0.25 * abs(pressure) + 0.10 * continuation)
        return -strength, "INITIATIVE_SELL_ACCEPTANCE", {
            **neutral, "duration": duration, "depth": depth,
            "continuation": continuation,
        }
    if recent and any(_f(row.get("high")) > vah for row in recent) and closes[-1] < vah and pressure < 0:
        excursion = math.tanh(max(0.0, max(_f(row.get("high")) for row in recent) - vah) / atr)
        return_depth = math.tanh(max(0.0, vah - closes[-1]) / atr)
        strength = clip(0.40 * excursion + 0.35 * return_depth + 0.25 * abs(pressure))
        return -strength, "RESPONSIVE_SELL_REJECTION", {
            **neutral, "excursion": excursion, "return_depth": return_depth,
        }
    if recent and any(_f(row.get("low")) < val for row in recent) and closes[-1] > val and pressure > 0:
        excursion = math.tanh(max(0.0, val - min(_f(row.get("low")) for row in recent)) / atr)
        return_depth = math.tanh(max(0.0, closes[-1] - val) / atr)
        strength = clip(0.40 * excursion + 0.35 * return_depth + 0.25 * abs(pressure))
        return strength, "RESPONSIVE_BUY_REJECTION", {
            **neutral, "excursion": excursion, "return_depth": return_depth,
        }
    return 0.0, "BALANCED_AUCTION", neutral
