"""
services/aux_market_data.py — cached external feeds for the new non-voting agents.
(2026-08-19 upgrade, phase 2 - new agents)

Sources (all public, all free):
  * CFTC disaggregated COT weekly CSV  -> gold & WTI positioning
    (default: https://www.cftc.gov/dea/newcot/deacom.txt)
  * yfinance daily closes for GLD, IAU, ^VIX, ^OVX, ^GVZ, CL=F, BZ=F

Contract (identical to services/macro_data_provider.py):
  * every fetch is disk-cached with a TTL; a network failure falls back to the
    stale cache (fail-open) instead of breaking the analysis cycle
  * every public function returns a dict / list / None — it never raises

COT parsing note (measured against the real deacom.txt on 2026-08-19):
  The row layout is CSV with a quoted market name followed by a variable
  number of code columns (3 for CMX gold, 1 for ICE WTI), then the numeric
  block. Fixed indexes are therefore NOT safe. The parser locates the
  percentage section (first float field, always "100.0" = pct of OI) and
  walks back 40 columns to Open Interest, then takes the standard offsets:
  Money-Manager Long = OI+6, Money-Manager Short = OI+7. If the schema ever
  changes the verification fails and the row is dropped (fail-open).
"""
from __future__ import annotations

import csv
import io
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

DEFAULT_COT_URL = "https://www.cftc.gov/dea/newcot/deacom.txt"

# Offsets from the OI column inside a deacom.txt row:
#   OI+0 OpenInterest(All)  OI+1..3 Prod/Merc L/S  OI+3..5 Swap L/S/Spread
#   OI+6 MoneyManager Long  OI+7 MoneyManager Short  OI+8 MM Spread  OI+9 Other Long
COT_OI_TO_PCT_OFFSET = 40   # columns between OpenInterest(All) and "100.0"
COT_MM_LONG_OFFSET = 6
COT_MM_SHORT_OFFSET = 7

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


# ── generic json cache helpers ────────────────────────────────────────────────
def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _age_hours(iso: Optional[str]) -> float:
    if not iso:
        return 10 ** 9
    try:
        then = datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
        return (datetime.now(timezone.utc) - then).total_seconds() / 3600.0
    except (TypeError, ValueError):
        return 10 ** 9


def _read_json(path: Path) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None
    return None


def _write_json(path: Path, payload: Any) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)
    except Exception:  # noqa: BLE001
        pass


# ── COT ───────────────────────────────────────────────────────────────────────
def _to_int(value: Any) -> Optional[int]:
    try:
        return int(str(value).strip().replace(",", ""))
    except (TypeError, ValueError):
        return None


def _is_int(value: Any) -> bool:
    return _to_int(value) is not None


def _parse_cot_row(row: Sequence[Any]) -> Optional[Dict[str, Any]]:
    """Parse one deacom.txt row into {report_date, oi, mm_long, mm_short}.

    Returns None when the schema check fails (fail-open for that row).
    """
    try:
        date_idx = next(i for i, f in enumerate(row) if _DATE_RE.fullmatch(str(f or "").strip()))
        # percentage section: first float field (always "100.0" = pct of OI)
        pct_idx = None
        for i in range(date_idx + 1, len(row)):
            txt = str(row[i] or "").strip()
            if txt and "." in txt:
                try:
                    float(txt)
                    pct_idx = i
                    break
                except ValueError:
                    continue
        if pct_idx is None or pct_idx - COT_OI_TO_PCT_OFFSET <= date_idx:
            return None
        oi_idx = pct_idx - COT_OI_TO_PCT_OFFSET
        oi = _to_int(row[oi_idx])
        mm_long = _to_int(row[oi_idx + COT_MM_LONG_OFFSET])
        mm_short = _to_int(row[oi_idx + COT_MM_SHORT_OFFSET])
        if not oi or oi <= 0 or mm_long is None or mm_short is None:
            return None
        return {
            "report_date": str(row[date_idx]).strip(),
            "oi": oi,
            "mm_long": mm_long,
            "mm_short": mm_short,
        }
    except (StopIteration, IndexError, ValueError):
        return None


def parse_cot_text(text: str) -> Dict[str, Any]:
    """Pure parser (unit-testable). Returns {"gold": {...}|None, "wti": {...}|None}."""
    gold = wti = None
    try:
        rows = csv.reader(io.StringIO(text))
        for row in rows:
            if not row:
                continue
            name = str(row[0] or "").strip()
            if gold is None and name.startswith("GOLD - COMMODITY"):
                gold = _parse_cot_row(row)
            elif wti is None and name.startswith("CRUDE OIL, LIGHT SWEET-WTI"):
                wti = _parse_cot_row(row)
    except Exception:  # noqa: BLE001
        pass
    return {"gold": gold, "wti": wti}


def fetch_cot(config: Dict[str, Any]) -> Dict[str, Any]:
    """Weekly COT positioning for gold & WTI, disk-cached. Never raises."""
    cfg = config.get("sentiment_agent") or {}
    if not bool(cfg.get("enabled", True)):
        return {}
    url = str(cfg.get("cot_url", DEFAULT_COT_URL))
    cache_path = Path(str(cfg.get("cot_cache_path", "storage/sentiment/cot_cache.json")))
    ttl_hours = float(cfg.get("cot_ttl_days", 7) or 7) * 24.0

    cache = _read_json(cache_path)
    if isinstance(cache, dict) and _age_hours(cache.get("fetched_at")) < ttl_hours:
        return cache

    try:
        import requests

        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        parsed = parse_cot_text(resp.text)
        if parsed.get("gold") or parsed.get("wti"):
            payload = {
                "source": "cftc_deacom",
                "fetched_at": _now_iso(),
                "gold": parsed.get("gold"),
                "wti": parsed.get("wti"),
            }
            _write_json(cache_path, payload)
            return payload
    except Exception:  # noqa: BLE001 — network/parse failure falls back to stale cache
        pass

    if isinstance(cache, dict) and (cache.get("gold") or cache.get("wti")):
        cache["stale"] = True
        return cache
    return {"source": "cftc_deacom", "fetched_at": None, "gold": None, "wti": None}


def append_cot_history(config: Dict[str, Any], cot: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Store weekly mm_net_pct per commodity (dedupe by report_date). Returns history."""
    cfg = config.get("sentiment_agent") or {}
    path = Path(str(cfg.get("cot_history_path", "storage/sentiment/cot_history.json")))
    hist = _read_json(path)
    if not isinstance(hist, list):
        hist = []
    for commodity in ("gold", "wti"):
        row = (cot or {}).get(commodity) or {}
        if not row.get("report_date") or not row.get("oi"):
            continue
        net = int(row["mm_long"]) - int(row["mm_short"])
        entry = {
            "report_date": row["report_date"],
            "commodity": commodity,
            "mm_net_pct": round(net / int(row["oi"]) * 100.0, 3),
        }
        if any(
            e.get("report_date") == entry["report_date"] and e.get("commodity") == commodity
            for e in hist
        ):
            continue
        hist.append(entry)
    hist.sort(key=lambda e: str(e.get("report_date") or ""))
    _write_json(path, hist)
    return hist


# ── yfinance closes ───────────────────────────────────────────────────────────
def yf_closes(
    symbol: str,
    days: int = 120,
    cache_path: str = "",
    ttl_hours: float = 24.0,
) -> Optional[List[float]]:
    """Daily closes for one yfinance symbol, disk-cached. None on any failure."""
    if not cache_path:
        cache_path = f"storage/aux_cache/{symbol.replace('^', 'IDX_').replace('=', '_')}.json"
    path = Path(cache_path)
    cache = _read_json(path)
    if isinstance(cache, dict) and _age_hours(cache.get("fetched_at")) < ttl_hours:
        closes = cache.get("closes")
        if isinstance(closes, list) and len(closes) >= 2:
            return [float(v) for v in closes]

    try:
        import yfinance as yf

        df = yf.download(
            symbol, period=f"{int(days)}d", interval="1d",
            progress=False, auto_adjust=True,
        )
        if df is None or len(df) == 0:
            return None
        if isinstance(df.columns, type(df.index)):
            series = df["Close"] if "Close" in df else None
        else:
            # multi-index columns: take the ('Close', <symbol>) column if present
            close_cols = [c for c in df.columns if str(c[0]).lower() == "close"]
            if not close_cols:
                return None
            series = df[close_cols[0]]
        closes = [float(v) for v in series.dropna().tolist()]
        if len(closes) >= 2:
            _write_json(path, {"symbol": symbol, "fetched_at": _now_iso(), "closes": closes})
            return closes
    except Exception:  # noqa: BLE001
        pass
    if isinstance(cache, dict):
        closes = cache.get("closes")
        if isinstance(closes, list) and len(closes) >= 2:
            return [float(v) for v in closes]
    return None
