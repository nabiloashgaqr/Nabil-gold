"""
services/market_regime.py — D1/W1 market-regime layer (2026-08-19 upgrade).

Fixes the structural blind spot: the pipeline analyzed only 5m/15m/1H/4H and
daily_bias_agent used 4H as an explicit proxy for daily direction. Gold P&L is
dominated by the daily regime; a 15m system without it is structurally blind.

Design:
  * MT5-native D1 candles (zero API cost). Fail-open: no MT5 -> fallback label
    so the cycle never breaks.
  * classify_regime() is pure and unit-testable without MT5.
  * Gate contract: RANGE regime -> only PATH_1 (three-agent consensus) entries
    are admitted; two-agent paths (2/3/5) are downgraded to WAIT. Consumed in
    scripts/run_analysis.py via _apply_regime_and_correlation_gates().
"""
from __future__ import annotations

from typing import Any, Dict, List, Sequence

import numpy as np


def _ema(values: Sequence[float], period: int) -> float:
    v = np.asarray(values, dtype=float)
    if len(v) < period:
        return float(v[-1]) if len(v) else 0.0
    alpha = 2.0 / (period + 1)
    out = v[-period - 1 :].copy()
    seed = out[:period].mean()
    for i in range(period, len(out)):
        out[i] = out[i - 1] + alpha * (out[i] - out[i - 1])
    return float(out[-1]) if len(out) > period else float(seed)


def _tr(high: Sequence[float], low: Sequence[float], close: Sequence[float]) -> np.ndarray:
    h, l, c = np.asarray(high, dtype=float), np.asarray(low, dtype=float), np.asarray(close, dtype=float)
    pc = np.roll(c, 1)
    pc[0] = c[0]
    return np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))


def _atr(high: Sequence[float], low: Sequence[float], close: Sequence[float], period: int, end: int | None = None) -> float:
    h, l, c = np.asarray(high, dtype=float), np.asarray(low, dtype=float), np.asarray(close, dtype=float)
    if end is not None:
        h, l, c = h[:end], l[:end], c[:end]
    if len(c) < period + 1:
        return 0.0
    return float(_tr(h, l, c)[-period:].mean())


def _wilder_smooth(values: np.ndarray, period: int) -> np.ndarray:
    out = np.full(values.shape, np.nan, dtype=float)
    out[period - 1] = values[:period].mean()
    alpha = 1.0 / period
    for i in range(period, len(values)):
        out[i] = out[i - 1] + alpha * (values[i] - out[i - 1])
    return out


def _dmi(high: Sequence[float], low: Sequence[float], close: Sequence[float], period: int = 14) -> Dict[str, float]:
    h, l, c = np.asarray(high, dtype=float), np.asarray(low, dtype=float), np.asarray(close, dtype=float)
    up_move = np.diff(h)
    down_move = -np.diff(l)
    plus_dm = np.concatenate(([0.0], np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)))
    minus_dm = np.concatenate(([0.0], np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)))
    atr = _wilder_smooth(_tr(h, l, c), period)
    plus_di = 100.0 * _wilder_smooth(plus_dm, period) / np.where(atr == 0, np.nan, atr)
    minus_di = 100.0 * _wilder_smooth(minus_dm, period) / np.where(atr == 0, np.nan, atr)
    dx = 100.0 * np.abs(plus_di - minus_di) / np.where((plus_di + minus_di) == 0, np.nan, plus_di + minus_di)
    adx = _wilder_smooth(np.where(np.isnan(dx), 0.0, dx), period)
    return {
        "adx": float(adx[-1]) if len(adx) else 0.0,
        "plus_di": float(plus_di[-1]) if len(plus_di) else 0.0,
        "minus_di": float(minus_di[-1]) if len(minus_di) else 0.0,
    }


def classify_regime(
    d1_closes: Sequence[float], d1_highs: Sequence[float], d1_lows: Sequence[float]
) -> Dict[str, Any]:
    """Pure regime classification (no MT5 dependency)."""
    closes = list(d1_closes)
    if len(closes) < 130:
        return {"regime": "INSUFFICIENT_DATA", "confidence": 0.0}

    ema50 = _ema(closes, 50)
    ema200 = _ema(closes, 200)
    dmi = _dmi(list(d1_highs), list(d1_lows), closes)
    adx = dmi["adx"]

    if adx >= 25:
        regime = "TREND_UP" if ema50 > ema200 else "TREND_DOWN"
    else:
        regime = "RANGE"

    atr20 = _atr(list(d1_highs), list(d1_lows), closes, 20)
    rolling = [_atr(list(d1_highs), list(d1_lows), closes, 20, end=i) for i in range(120, len(closes))]
    rolling_arr = np.array([r for r in rolling if r > 0])
    vol_pct = float((rolling_arr < atr20).mean()) if len(rolling_arr) else 0.5

    return {
        "regime": regime,
        "adx": round(adx, 2),
        "ema50": round(ema50, 2),
        "ema200": round(ema200, 2),
        "atr20_d1": round(atr20, 2),
        "vol_percentile": round(vol_pct, 2),
        "vol_label": "LOW" if vol_pct < 0.25 else ("HIGH" if vol_pct > 0.75 else "NORMAL"),
        "confidence": round(min(90.0, adx * 1.2), 1),
    }


def fetch_d1_context(config: Dict[str, Any]) -> Dict[str, Any]:
    """MT5-native D1 fetch. Never raises: the analysis cycle must not break."""
    try:
        from services.mt5_feed import get_candles

        symbol = str(config.get("symbol", "XAU/USD"))
        payload = get_candles(symbol, "D1", count=500)
        if not payload or not payload.get("data"):
            return {"regime": "MT5_UNAVAILABLE", "fallback": "4H proxy", "source": "none"}
        candles = payload["data"]
        closes = [float(c["close"]) for c in candles]
        highs = [float(c["high"]) for c in candles]
        lows = [float(c["low"]) for c in candles]
        return {"source": "mt5_d1", **classify_regime(closes, highs, lows)}
    except Exception as exc:  # noqa: BLE001 — regime feed must never break the cycle
        return {"regime": "ERROR", "error": str(exc), "fallback": "4H proxy", "source": "error"}


def apply_range_gate(decision: Dict[str, Any], regime: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
    """Downgrade a decision to WAIT when regime is RANGE and the gate is on.

    RANGE -> only PATH_1 is admitted. Two-agent paths (PATH_2/3/5) and the
    auction-confirmed PATH_4/5 are downgraded with an explicit reason card.
    Gate honours config["market_regime"]["strict_range_gate"] (default True).
    """
    gate_cfg = config.get("market_regime", {}) or {}
    if not bool(gate_cfg.get("strict_range_gate", True)):
        return decision
    if str(regime.get("regime") or "").upper() != "RANGE":
        return decision
    signal = str(decision.get("decision") or decision.get("signal", "") or "").upper()
    if signal not in {"BUY", "SELL"}:
        return decision
    path_id = str(decision.get("execution_path_id") or "")
    if path_id.startswith("PATH_1"):
        return decision  # three-agent consensus stays admissible in RANGE
    decision["decision"] = "WAIT"
    decision["confidence"] = 0
    decision["signal"] = {}
    decision["regime_gate"] = {
        "applied": True,
        "regime": "RANGE",
        "original_path": path_id,
        "reason": "RANGE regime: only PATH_1 (three-agent consensus) is admitted",
    }
    decision["warnings"] = list(decision.get("warnings") or []) + [
        f"REGIME_GATE: {path_id} downgraded to WAIT in RANGE regime"
    ]
    return decision
