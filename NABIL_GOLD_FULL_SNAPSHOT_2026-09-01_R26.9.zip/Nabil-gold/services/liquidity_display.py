"""Display-only grouping of nearby liquidity references.

This module does not calculate or modify stop-loss, TP1, TP2, orders or trade
management. It only prevents Telegram from presenting two nearby prices as two
independent liquidity objectives.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable

from utils import trading_rules as _tr
from utils.instruments import price_to_points


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _cluster(anchor: float, levels: list[float], min_separation_points: float, symbol: str) -> list[float]:
    return [
        level for level in levels
        if abs(price_to_points(level - anchor, symbol=symbol)) < min_separation_points
    ]


def liquidity_display_zones(
    *,
    levels: Iterable[Any],
    direction: str,
    entry: float,
    stop: float,
    symbol: str,
    config: Dict[str, Any],
) -> Dict[str, Any]:
    """Return independent display zones L1/L2 without touching trade targets.

    L1 remains the nearest pool at or beyond the canonical TP1 floor (0.8R in
    the shipped configuration). Nearby levels are folded into L1's display
    zone. L2 is the first pool separated from L1 by at least the larger of
    100 points or 0.5R (both configurable under display settings).
    """
    direction = str(direction or "").upper()
    entry = _f(entry)
    stop = _f(stop)
    if direction not in {"BUY", "SELL"} or entry <= 0 or stop <= 0:
        return {"l1": None, "l2": None, "reason": "invalid display geometry"}

    risk_points = abs(price_to_points(stop - entry, symbol=symbol))
    if risk_points <= 0:
        return {"l1": None, "l2": None, "reason": "zero display risk"}

    delivery = (config.get("session_plan_delivery") or {}) if isinstance(config, dict) else {}
    display_cfg = delivery.get("liquidity_display") or {}
    min_points = max(0.0, _f(display_cfg.get("min_independent_separation_points"), 100.0))
    min_rr = max(0.0, _f(display_cfg.get("min_independent_separation_rr"), 0.5))
    min_separation_points = max(min_points, min_rr * risk_points)
    min_tp1_rr = _tr.target_ratios(config)["min_tp1_rr"]
    min_ahead_points = max(0.0, _f(min_tp1_rr, 0.8) * risk_points)

    def ahead(level: float) -> bool:
        return level > entry if direction == "BUY" else level < entry

    ordered = sorted(
        {
            round(_f(raw), 8) for raw in levels
            if _f(raw) > 0 and ahead(_f(raw))
        },
        key=lambda level: abs(level - entry),
    )
    eligible = [
        level for level in ordered
        if abs(price_to_points(level - entry, symbol=symbol)) >= min_ahead_points
    ]
    if not eligible:
        return {
            "l1": None,
            "l2": None,
            "risk_points": risk_points,
            "min_ahead_points": min_ahead_points,
            "min_separation_points": min_separation_points,
            "reason": "no liquidity beyond the display TP1 floor",
        }

    def payload(anchor: float, cluster_levels: list[float]) -> Dict[str, Any]:
        distance_points = abs(price_to_points(anchor - entry, symbol=symbol))
        return {
            "anchor": anchor,
            "low": min(cluster_levels),
            "high": max(cluster_levels),
            "levels": cluster_levels,
            "clustered": len(cluster_levels) > 1,
            "distance_points": distance_points,
            "rr": distance_points / risk_points,
        }

    l1_anchor = eligible[0]
    l1_levels = _cluster(l1_anchor, eligible, min_separation_points, symbol)
    l1 = payload(l1_anchor, l1_levels)

    l2_candidates = [
        level for level in eligible
        if abs(price_to_points(level - l1_anchor, symbol=symbol)) >= min_separation_points
    ]
    l2 = None
    if l2_candidates:
        l2_anchor = l2_candidates[0]
        l2_levels = _cluster(l2_anchor, l2_candidates, min_separation_points, symbol)
        l2 = payload(l2_anchor, l2_levels)

    return {
        "l1": l1,
        "l2": l2,
        "risk_points": risk_points,
        "min_ahead_points": min_ahead_points,
        "min_separation_points": min_separation_points,
        "display_only": True,
    }
