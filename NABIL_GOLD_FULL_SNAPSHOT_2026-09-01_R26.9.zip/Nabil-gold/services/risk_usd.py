# -*- coding: utf-8 -*-
"""R25.15: the single source of the DOLLAR risk law (operator 2026-08-28).

"ذهب: ستوب 400 نقطة على 0.1 لوت = $400 خسارة" - risk is measured in
dollars. Point values differ per pair, so a shared point-stop is NOT a
shared dollar risk. This module is the only place that converts:

    stop_points  --(point_size, contract, quote price)-->  loss_usd
    risk_usd band [$270, $400]  --solve-->  lot  (snapped to 0.01)

The stop stays STRUCTURAL per pair (liquidity law; gold candle band
[270, 400]); the lot is the derived variable. The operator's reference:
gold @400 => 0.10 lots exactly.

Margin planning honours config execution.margin_planning_leverage
(default 1000, options 100/500/1000) - the operator asked for 1:100 as a
CONFIG OPTION, not a hard account change.
"""
from __future__ import annotations

from typing import Any, Dict

#: Standard contract sizes (verified against the broker specs; WTI is
#: re-checked from MT5 Specification at deployment).
CONTRACT_SIZE = {
    "XAU/USD": 100,      # 100 oz per lot
    "WTI/USD": 1000,     # 1,000 barrels per lot (verify on the terminal)
    "EUR/USD": 100000,
    "GBP/USD": 100000,
    "USD/CAD": 100000,
    "USD/JPY": 100000,
}

#: The operator's dollar band per full stop, by pair liquidity.
RISK_USD_DEFAULT = 270.0
RISK_USD_CAP = 400.0

VOLUME_STEP = 0.01

#: USD-quoted-against-USD pairs: the conversion rate for the profit
#: currency. Callers may pass live prices; these defaults keep the module
#: usable offline (worst-case drift is a few % on the margin estimate).
DEFAULT_QUOTE = {"USD/CAD": 1.39022, "USD/JPY": 160.153}


#: point_size per symbol (matches config instruments; the loader merges
#: config over these, so a missing config still yields correct sizes).
POINT_SIZE = {"XAU/USD": 0.10, "WTI/USD": 0.01, "EUR/USD": 0.00001,
              "GBP/USD": 0.00001, "USD/CAD": 0.00001, "USD/JPY": 0.001}


def _instrument(config: Dict[str, Any] | None, symbol: str) -> Dict[str, Any]:
    """Read point_size from config instruments when available, else the
    built-in table (the config loader merges over the same values)."""
    sym = str(symbol).upper()
    for inst in (config or {}).get("instruments") or []:
        if str(inst.get("symbol") or "").upper() == sym:
            return inst
    if sym in POINT_SIZE:
        return {"symbol": sym, "point_size": POINT_SIZE[sym]}
    raise KeyError("instrument not in config: %s" % symbol)


def _contract(symbol: str) -> int:
    for key, val in CONTRACT_SIZE.items():
        if key in str(symbol).upper():
            return val
    raise KeyError("no contract size for %s" % symbol)


def usd_per_point(symbol: str, lots: float = 0.1,
                  quote_price: float | None = None) -> float:
    """Dollar value of ONE point (point_size from config) at `lots`.

    The quote-currency conversion divides by the pair's price for
    USD/CAD & USD/JPY (profit currency JPY/CAD -> dollars); when no live
    price is given the DEFAULT_QUOTE reference price is used so the
    planner stays usable offline."""
    c = _contract(symbol)
    pt = float(_instrument(None, symbol).get("point_size") or 0.00001)
    rate = 1.0
    sym = str(symbol).upper()
    for q, ref in DEFAULT_QUOTE.items():
        if q in sym:
            rate = float(quote_price) if quote_price else float(ref)
            break
    return lots * c * pt / rate


def usd_loss(symbol: str, stop_points: float, lots: float,
             quote_price: float | None = None) -> float:
    """Dollar loss of a full stop at `lots`."""
    return usd_per_point(symbol, lots, quote_price) * float(stop_points)


def usd_pnl(symbol: str, lots: float, entry: float, now: float,
            dirn: str, quote_price: float | None = None) -> float:
    """Realized/unrealized dollars for the move entry->now.

    R25.15 fix (2026-08-28): the sign follows whether the move was FAVORABLE
    for the direction, not the direction alone. The old fixed sign made a
    profitable SELL (now < entry) report negative dollars — the same sign as
    a losing SELL — because abs() had already destroyed the move's direction.
    """
    delta = float(now) - float(entry)
    pts = abs(delta) / float(
        _instrument(None, symbol).get("point_size") or 0.00001)
    favorable = (str(dirn).upper() == "BUY") == (delta >= 0)
    sign = 1.0 if favorable else -1.0
    return sign * usd_per_point(symbol, lots, quote_price) * pts


def lot_for_stop(symbol: str, stop_points: float, config: Dict[str, Any] | None = None,
                 risk_usd: float | None = None,
                 quote_price: float | None = None) -> float:
    """Solve the lot so the full stop lands on the operator's dollar band.

    Default target: $270 (band floor). The $400 ceiling is enforced by the
    caller's band check - lots are never solved ABOVE the cap target.
    Gold @270 -> 0.10 exactly (the operator's reference sizing).

    R25.7-D (2026-08-28): the 0.01 snap rounds UP (ceil). A down-round can
    ship the stop loss a hair UNDER the $270 floor (raw 1.1739 -> 1.17 =
    $269.1). Ceil keeps every solved loss >= target: raw 1.1739 -> 1.18 =
    $271.4, and the $400 check still holds at the band cap.
    """
    import math

    risk = float(risk_usd if risk_usd is not None else RISK_USD_DEFAULT)
    v01 = usd_per_point(symbol, 0.1, quote_price)          # $ per point @ 0.1
    per_lot = v01 / 0.1                                     # $ per point per 1.0 lot
    raw = risk / (per_lot * float(stop_points))
    steps = math.ceil(round(raw / float(VOLUME_STEP), 6) - 1e-9)
    return max(float(VOLUME_STEP), steps * float(VOLUME_STEP))


def expected_margin(symbol: str, lots: float, px: float | None = None,
                    leverage: int | None = None,
                    config: Dict[str, Any] | None = None) -> float:
    """Expected margin at the configured planning leverage.

    config execution.margin_planning_leverage: 100 | 500 | 1000
    (operator 2026-08-28: "اجعل الرافعة 1:100 كخيار"). USD-base pairs
    (USD/CAD, USD/JPY) need no conversion - the notional is in dollars.
    """
    lev = int(leverage or ((config or {}).get("execution") or {})
              .get("margin_planning_leverage", 1000) or 1000)
    c = _contract(symbol)
    if "USD/CAD" in str(symbol).upper():
        notional = lots * c
    elif "USD/JPY" in str(symbol).upper():
        notional = lots * c
    else:
        notional = lots * c * float(px or 0.0)
    return notional / lev
