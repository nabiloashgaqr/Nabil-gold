"""MT5 demo executor (demo branch, phase 1).

Transmits the unified-law levels (utils/trading_rules) to a MetaTrader 5
DEMO account. Never decides risk itself. Idempotent per trade via magic
number. Hard halt on reconciliation mismatch. All failures are logged and
reported; the executor must never crash the cycle.
"""

from __future__ import annotations

import json
import logging
import os
import time
import zlib
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

HALT_FILE = ".demo_halt"


def _mt5():
    import MetaTrader5 as mt5  # noqa: lazy on purpose
    return mt5


_MT5_READY = {"ok": False}


def _mt5_ready():
    """Lazy import + initialize ONCE (live incident 2026-08-10: the executor
    and tick manager queried the terminal without ever initializing it —
    every symbol_info_tick silently returned None and no order was ever
    sent)."""
    mt5 = _mt5()
    if not _MT5_READY["ok"]:
        try:
            path = os.environ.get("MT5_PATH") or None
            if mt5.initialize(path=path) if path else mt5.initialize():
                _MT5_READY["ok"] = True
            else:
                logger.warning("MT5 initialize failed: %s", mt5.last_error())
        except Exception as exc:  # noqa: BLE001
            logger.warning("MT5 initialize crashed: %s", exc)
    return mt5


def magic_for(trade_id: str) -> int:
    return 1000000 + (zlib.crc32(trade_id.encode()) % 8999999)


def plan_partial_close(volume: float, fraction: float, step: float):
    """Snap the TP1 booked slice to the broker's volume_step.

    Returns (part, remaining). This plan ONLY ever describes the fractional
    slice — it never escalates to closing the whole position (operator
    directive: close the half, nothing else). Pure + unit-tested.
    """
    if step <= 0:
        step = 0.01
    import math
    part = math.floor(volume * fraction / step + 1e-9) * step
    part = round(part, 8)
    return part, round(volume - part, 8)


class Mt5DemoExecutor:
    def __init__(self, config: Dict[str, Any], telegram=None):
        self.config = config or {}
        demo = (self.config.get("execution") or {}).get("demo") or {}
        self.lot = float(demo.get("lot_size", 0.10))
        self.deviation = int(demo.get("deviation_points_mt5", 30))
        self.max_per_day = int(demo.get("max_new_orders_per_day", 6))
        self.halt_on_mismatch = bool(demo.get("reconcile_halt_on_mismatch", True))
        self.symbol_map = demo.get("symbol_map") or {"XAU/USD": "XAUUSD"}
        self.telegram = telegram
        self._orders_today = 0
        self._orders_today_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        self.last_error = ""
        self.last_order: Dict[str, Any] = {}
        self.last_partial: Dict[str, Any] = {}
        self.last_close: Dict[str, Any] = {}
        # R25.7-G (2026-08-29, live journal 01:01:54): cancel + 3x SLTP
        # modify were hammered against a CLOSED market ("Market closed",
        # "Invalid stops"). Once the broker says the market is closed, all
        # send-actions back off for this many minutes and the callers just
        # retry on their next natural cycle (actions are queued by design,
        # never dropped).
        self.market_closed_until = 0.0

    def _market_closed_active(self) -> bool:
        return time.time() < float(getattr(self, "market_closed_until", 0.0))

    def _note_market_closed(self, mt5, res, what: str) -> bool:
        """True when `res` is the broker's MARKET-CLOSED refusal (the
        live 10018 seen in the journal). Arms the backoff window."""
        closed = int(getattr(mt5, "TRADE_RETCODE_MARKET_CLOSED", 10018) or 10018)
        try:
            retcode = int(getattr(res, "retcode", 0) or 0)
        except (TypeError, ValueError):
            return False
        if res is None or retcode != closed:
            return False
        wp = (self.config or {}).get("weekend_policy") or {}
        backoff_min = float(wp.get("market_closed_backoff_minutes", 10) or 10)
        self.market_closed_until = time.time() + backoff_min * 60.0
        logger.warning("R25.7-G %s refused: MARKET CLOSED — weekend guard "
                       "backs off %.0f min (queued, retried after open)",
                       what, backoff_min)
        return True

    # -- lifecycle ---------------------------------------------------------
    def alive(self) -> bool:
        try:
            return _mt5().terminal_info() is not None
        except Exception:  # noqa: BLE001
            return False

    def _sym(self, symbol: str) -> str:
        return self.symbol_map.get(symbol, symbol.replace("/", ""))

    def _demo_safe(self, mt5) -> bool:
        """Hard-refuse every broker mutation on a REAL account."""
        if not hasattr(mt5, "account_info"):
            return True  # lightweight unit-test fakes
        try:
            info = mt5.account_info()
            real = getattr(mt5, "ACCOUNT_TRADE_MODE_REAL", 2)
            if info is not None and getattr(info, "trade_mode", None) == real:
                self.last_error = "REAL MT5 account refused by demo executor"
                self._halt(self.last_error)
                return False
        except Exception as exc:  # noqa: BLE001
            self.last_error = f"account mode check failed: {exc}"
            logger.error(self.last_error)
            return False
        return True

    # -- halt --------------------------------------------------------------
    def _reset_if_new_day(self, now: datetime | None = None) -> None:
        """2026-08-19 fix: the daily order cap must reset at the UTC day
        boundary. The tick manager is a persistent process, so a counter that
        only resets on __init__ turns a DAILY cap into a PROCESS-LIFETIME cap
        (live incident: 'daily cap reached' refused every order for hours
        while the process stayed up)."""
        now = now or datetime.now(timezone.utc)
        today = now.strftime("%Y-%m-%d")
        if today != self._orders_today_date:
            self._orders_today = 0
            self._orders_today_date = today
            logger.info("Daily order cap reset for new UTC day %s", today)

    def halted(self) -> bool:
        return os.path.exists(HALT_FILE)

    def _margin_veto(self, mt5, symbol: str = "", lots: float = 0.0,
                     px: float = 0.0) -> str | None:
        """Margin/equity circuit breaker before NEW order sends (2026-08-19).

        Vetoes only openings (ensure_ticket) — protective closes and stop
        moves must always be allowed through. Fail-open: any exception or
        unavailable account_info returns None so the demo cycle never breaks.
        R25.15 (2026-08-28): when symbol/lots are provided, the margin this
        order will ADD is estimated first (risk_usd.expected_margin at
        execution.margin_planning_leverage) so the exposure cap is judged on
        the projected account, not the current one.
        """
        guard = self.config.get("margin_guard", {}) or {}
        if not bool(guard.get("enabled", True)):
            return None
        expected_usd = 0.0
        if symbol and lots and lots > 0:
            try:
                from services.risk_usd import expected_margin
                expected_usd = float(expected_margin(symbol, float(lots),
                                                     float(px or 0) or None,
                                                     config=self.config))
            except Exception as exc:  # noqa: BLE001 — estimate never blocks the guard
                logger.warning("expected_margin estimate failed for %s: %s", symbol, exc)
                expected_usd = 0.0
        try:
            from services.margin_guard import pre_send_veto

            acct = mt5.account_info()
            allow, reason = pre_send_veto(acct, self.config,
                                          expected_margin_usd=expected_usd)
            if not allow:
                return reason
        except Exception as exc:  # noqa: BLE001 — fail-open by design
            logger.warning("Margin guard unavailable (fail-open): %s", exc)
        return None

    def _order_lot(self, symbol: str, entry_price: float, sl: float) -> float:
        """Solve THIS order's volume from the dollar-budget law (R25.7-D).

        lot = target / (stop_points x $/point/lot), snapped UP to 0.01, so
        the full stop loss lands in [$270, $400] for the symbol's own stop
        band (gold [270,400] pts; WTI + forex [230,330] pts since R25.7-D).
        Any failure (no point size, no stop, unknown symbol) falls back to
        the configured demo lot - sizing must never block an order.
        """
        try:
            from utils.instruments import point_size
            from services.risk_usd import lot_for_stop

            pv = point_size(symbol, self.config)
            if pv > 0 and float(entry_price or 0.0) > 0 and float(sl or 0.0) > 0:
                dist = abs(float(entry_price) - float(sl))
                points = dist / pv
                solved = float(lot_for_stop(symbol, points, config=self.config))
                if solved > 0:
                    return round(solved, 2)
        except Exception as exc:  # noqa: BLE001 — sizing fallback, never a blocker
            logger.warning("order-lot solve failed for %s (config lot used): %s",
                           symbol, exc)
        return float(self.lot or 0.0)

    def _halt(self, why: str) -> None:
        if self.halt_on_mismatch:
            try:
                with open(HALT_FILE, "w", encoding="utf-8") as fh:
                    fh.write(why)
            except OSError:
                pass
        logger.error("DEMO HALT: %s", why)
        if self.telegram:
            try:
                self.telegram.send_error_alert(f"🧪 DEMO HALT: {why}")
            except Exception:  # noqa: BLE001
                pass

    # -- orders ------------------------------------------------------------
    def _position_by_magic(self, magic: int):
        try:
            for pos in _mt5_ready().positions_get() or []:
                if pos.magic == magic:
                    return pos
        except Exception:  # noqa: BLE001
            return None
        return None

    def _send_deal(self, mt5, request: Dict[str, Any]):
        """Send DEAL/PENDING; when the broker answers 10030 'Unsupported
        filling mode' (its flags can lie), retry across all filling modes.
        Live incident 2026-08-10: pendings flooded 10030 refusals."""
        pref = request.get(
            "type_filling", self._filling_type(mt5, request["symbol"]))
        tried = []
        last = None
        for mode in (pref, getattr(mt5, "ORDER_FILLING_RETURN", 2),
                     getattr(mt5, "ORDER_FILLING_IOC", 1),
                     getattr(mt5, "ORDER_FILLING_FOK", 0)):
            if mode in tried:
                continue
            tried.append(mode)
            request["type_filling"] = mode
            try:
                res = mt5.order_send(request)
            except Exception as exc:  # noqa: BLE001
                self.last_error = f"order_send crashed: {exc}"
                logger.error("order_send crashed: %s", exc)
                return None
            if res and res.retcode == mt5.TRADE_RETCODE_DONE:
                return res
            last = res
            if getattr(res, "retcode", None) != 10030:
                break
        if last is not None:
            self.last_error = (
                f"retcode={getattr(last, 'retcode', '?')} "
                f"{getattr(last, 'comment', '')}".strip())
            logger.error("order_send refused: %s", self.last_error)
        return None

    def _filling_type(self, mt5, sym: str):
        """Pick a filling mode the broker actually supports (live rejection
        2026-08-10: retcode 10030 'Unsupported filling mode' on XAUUSD.s).
        Preference IOC -> FOK -> RETURN, from the symbol's filling_mode flags."""
        try:
            info = mt5.symbol_info(sym)
            fm = int(getattr(info, "filling_mode", 0) or 0)
            if fm & getattr(mt5, "SYMBOL_FILLING_IOC", 2):
                return mt5.ORDER_FILLING_IOC
            if fm & getattr(mt5, "SYMBOL_FILLING_FOK", 1):
                return mt5.ORDER_FILLING_FOK
        except Exception:  # noqa: BLE001
            pass
        return getattr(mt5, "ORDER_FILLING_RETURN", 0)

    def _order_by_magic(self, magic: int):
        """Outstanding PENDING order with this magic (not yet a position)."""
        try:
            for o in _mt5_ready().orders_get() or []:
                if getattr(o, "magic", None) == magic:
                    return o
        except Exception:  # noqa: BLE001
            return None
        return None

    def ensure_ticket(
        self,
        trade_id: str,
        side: str,
        order_kind: str,
        entry_price: float,
        sl: float,
        tp: float,
        symbol: str,
    ) -> Optional[int]:
        """Idempotent open. Returns ticket or None (refused/failed).

        Idempotency covers BOTH states of an order's life: an open POSITION
        and an outstanding PENDING order. Without the pending check, a
        tick-level retry loop would stack duplicate limit orders.
        """
        self.last_error = ""
        self._reset_if_new_day()
        # R25.7-G: during a market-closed backoff window nothing is sent —
        # the action is retried on the caller's next natural cycle.
        if self._market_closed_active():
            self.last_error = "market closed (weekend guard) — action queued"
            return None
        if self.halted():
            self.last_error = "executor halted (.demo_halt)"
            return None
        if self.max_per_day > 0 and self._orders_today >= self.max_per_day:
            self.last_error = "daily order cap reached"
            logger.warning("Demo order refused: daily cap reached")
            return None
        magic = magic_for(trade_id)
        mt5 = _mt5_ready()
        if not self._demo_safe(mt5):
            return None
        existing = self._position_by_magic(magic)
        if existing:
            self.last_order = {
                "ticket": int(existing.ticket), "existing": True,
                "kind": "POSITION", "volume": float(existing.volume),
                "price": round(float(existing.price_open), 2),
            }
            return int(existing.ticket)
        existing_order = self._order_by_magic(magic)
        if existing_order:
            self.last_order = {
                "ticket": int(existing_order.ticket), "existing": True,
                "kind": str(order_kind or ""),
                "volume": float(getattr(existing_order, "volume_current",
                                         getattr(existing_order, "volume_initial", self.lot))),
                "price": round(float(getattr(existing_order, "price_open", entry_price) or entry_price), 2),
            }
            return int(existing_order.ticket)
        sym = self._sym(symbol)
        tick = mt5.symbol_info_tick(sym)
        if tick is None:
            self.last_error = f"no tick for {sym}"
            return None
        buy = str(side).upper() == "BUY"
        # R25.7-E (2026-08-28): the execution reference price. A pending
        # enters at its own level; a MARKET order fills at the live tick —
        # the tick manager passes entry_price=0.0 for market orders, and
        # using that raw zero made every market order skip the band clamp
        # AND fall back to the configured lot (the live EUR 0.1 incident).
        is_market = str(order_kind or "").upper().endswith("MARKET")
        ref_price = float(entry_price or 0.0)
        if ref_price <= 0:
            ref_price = float(tick.ask if buy else tick.bid or 0.0)
        # R25.7-E: the band law is ABSOLUTE at the execution door — the
        # chokepoint every order passes through. Whatever a path computed
        # upstream (pre-arm ATR stop, config floors, anything future), a
        # stop outside [floor, cap] points from the reference price is
        # clamped here before the order is built. Wrong-side stops (BE,
        # trailing, protection) pass untouched by design.
        sl_final = float(sl or 0.0)
        sl_band_fixed = False
        if sl_final > 0 and ref_price > 0:
            try:
                from utils.trading_rules import clamp_stop_price
                _clamped = float(clamp_stop_price(
                    direction=side, entry=ref_price, stop=sl_final,
                    cfg=self.config, symbol=symbol))
                if abs(_clamped - sl_final) > 1e-9:
                    logger.warning(
                        "R25.7-E band clamp %s %s %s: %.5f -> %.5f "
                        "(stop outside the symbol [floor, cap] band)",
                        trade_id, symbol, order_kind, sl_final, _clamped)
                    sl_final = _clamped
                    sl_band_fixed = True
            except Exception as exc:  # noqa: BLE001 - fail safe to raw sl
                logger.warning("band clamp unavailable for %s: %s",
                               trade_id, exc)
        # R25.7-D (2026-08-28): the DOLLAR law ships the lot — solved from
        # THIS order's own stop distance (reference price vs the FINAL
        # clamped stop) so the full stop lands in [$270, $400] per symbol
        # (gold [270,400] pts, WTI+FX [230,330]). A missing/unusable stop
        # falls back to the configured lot honestly.
        order_lot = self._order_lot(symbol, ref_price, sl_final)
        # 2026-08-19: margin/equity circuit breaker before NEW openings only
        # (protective closes and stop moves are never vetoed). R25.7-E: it
        # now runs after the tick fetch so MARKET orders are vetoed against
        # the live price instead of a raw 0.0.
        veto = self._margin_veto(mt5, symbol=symbol, lots=float(order_lot),
                                 px=ref_price)
        if veto:
            self.last_error = f"margin guard veto: {veto}"
            self._halt(veto)
            return None
        if is_market:
            request = {
                "action": mt5.TRADE_ACTION_DEAL,
                "symbol": sym,
                "volume": order_lot,
                "type": mt5.ORDER_TYPE_BUY if buy else mt5.ORDER_TYPE_SELL,
                "price": tick.ask if buy else tick.bid,
                "sl": sl_final,
                "tp": float(tp),
                "deviation": self.deviation,
                "magic": magic,
                "comment": "SS-demo",
                "type_filling": self._filling_type(mt5, sym),
            }
        else:
            request = {
                "action": mt5.TRADE_ACTION_PENDING,
                "symbol": sym,
                "volume": order_lot,
                "type": mt5.ORDER_TYPE_BUY_LIMIT if buy else mt5.ORDER_TYPE_SELL_LIMIT,
                "price": float(entry_price),
                "sl": sl_final,
                "tp": float(tp),
                "magic": magic,
                "comment": "SS-demo",
            }
        res = self._send_deal(mt5, request)
        if res is None:
            return None
        if self._note_market_closed(mt5, res, "order send"):
            return None
        self._orders_today += 1
        # DEAL results carry the broker's actual execution price. For pending
        # orders it normally equals the requested resting price. Persist this
        # so a market position never keeps Telegram's planned quote merely
        # because positions_get() needed one more terminal tick to materialize.
        applied_price = float(getattr(res, "price", 0.0) or request.get("price") or 0.0)
        self.last_order = {
            "ticket": int(res.order),
            "kind": str(order_kind or ""),
            "volume": order_lot,
            "price": round(applied_price, 2),
            "sl": sl_final,
            "sl_band_fixed": sl_band_fixed,
            "existing": False,
        }
        return int(res.order)

    def apply_stop(self, trade_id: str, new_sl: float, tp: float, symbol: str) -> bool:
        # R25.7-G: never hammer SLTP against a closed market (the live
        # journal shipped 3x "Invalid stops" at 01:01:54 on a closed book).
        if self._market_closed_active():
            logger.debug("SLTP skipped for %s: market closed (weekend guard)",
                         trade_id)
            return False
        magic = magic_for(trade_id)
        pos = self._position_by_magic(magic)
        if not pos:
            return False
        mt5 = _mt5_ready()
        if not self._demo_safe(mt5):
            return False
        request = {
            "action": mt5.TRADE_ACTION_SLTP,
            "symbol": self._sym(symbol),
            "position": int(pos.ticket),
            "sl": float(new_sl),
            "tp": float(tp),
        }
        try:
            res = mt5.order_send(request)
        except Exception as exc:  # noqa: BLE001
            self.last_error = f"SLTP crashed: {exc}"
            logger.error("SLTP modify crashed: %s", exc)
            return False
        if self._note_market_closed(mt5, res, "SLTP modify"):
            return False
        if res and res.retcode == mt5.TRADE_RETCODE_DONE:
            return True
        self.last_error = (f"SLTP retcode={getattr(res, 'retcode', '?')} "
                           f"{getattr(res, 'comment', '')}".strip())
        logger.warning("SLTP refused for %s: %s", trade_id, self.last_error)
        return False

    def _prior_tp1_partial(self, trade_id: str) -> Optional[Dict[str, Any]]:
        """Return a broker-confirmed TP1 slice already booked for this magic.

        The local book is a mirror, not the authority. If a concurrent JSON
        write ever loses ``partial_close=True``, broker history still prevents a
        second half-close (the 2026-08-10 incident closed 0.05 then another
        0.02 from the same 0.10 position).
        """
        mt5 = _mt5_ready()
        magic = magic_for(trade_id)
        try:
            deals = mt5.history_deals_get(0, int(time.time()) + 86400) or ()
        except Exception as exc:  # noqa: BLE001
            logger.warning("TP1 history check crashed for %s: %s", trade_id, exc)
            return None
        hits = [
            d for d in deals
            if getattr(d, "magic", None) == magic
            and str(getattr(d, "comment", "") or "").startswith("SS-demo-tp1")
            and getattr(d, "entry", None) == getattr(mt5, "DEAL_ENTRY_OUT", 1)
        ]
        if not hits:
            return None
        latest = max(hits, key=lambda d: getattr(d, "time", 0))
        return {
            "volume": round(sum(float(getattr(d, "volume", 0.0) or 0.0) for d in hits), 8),
            "price": round(float(getattr(latest, "price", 0.0) or 0.0), 2),
            "ticket": int(getattr(latest, "position_id",
                                  getattr(latest, "position", 0)) or 0),
            "existing": True,
        }

    def partial_close_at_tp1(self, trade_id: str, fraction: float, symbol: str) -> bool:
        """Close ONLY the booked fraction at TP1 (operator directive).

        NEVER full-close + reopen. The volume is snapped to the broker's
        volume_step; if the slice is below volume_min it cannot be booked at
        all. On any refusal: return False and leave the reason in
        self.last_error — the tick manager retries every tick and reports
        the refusal to the operator once per trade.
        """
        mt5 = _mt5_ready()
        self.last_error = ""
        if not self._demo_safe(mt5):
            return False
        magic = magic_for(trade_id)
        pos = self._position_by_magic(magic)
        if not pos:
            self.last_error = "position not found"
            return False
        prior = self._prior_tp1_partial(trade_id)
        if prior:
            prior["remaining"] = round(float(pos.volume), 8)
            self.last_partial = prior
            return True
        sym = self._sym(symbol)
        info = mt5.symbol_info(sym)
        step = float(getattr(info, "volume_step", 0.01) or 0.01)
        min_vol = float(getattr(info, "volume_min", 0.01) or 0.01)
        part, _remaining = plan_partial_close(float(pos.volume), fraction, step)
        if part < min_vol or part <= 0:
            self.last_error = (
                f"slice {part:.2f} below broker volume_min {min_vol:g} — "
                f"cannot book the half")
            logger.error("TP1 partial impossible for %s: %s", trade_id,
                         self.last_error)
            return False
        tick = mt5.symbol_info_tick(sym)
        close_type = (mt5.ORDER_TYPE_SELL if pos.type == mt5.ORDER_TYPE_BUY
                      else mt5.ORDER_TYPE_BUY)
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": sym,
            "volume": part,
            "type": close_type,
            "position": int(pos.ticket),
            "price": tick.bid if close_type == mt5.ORDER_TYPE_SELL else tick.ask,
            "deviation": self.deviation,
            "magic": magic,
            "comment": "SS-demo-tp1",
            "type_filling": self._filling_type(mt5, sym),
        }
        res = self._send_deal(mt5, request)
        if res is not None:
            self.last_partial = {
                "volume": part,
                "price": round(float(request["price"]), 2),
                "remaining": round(float(pos.volume) - part, 2),
                "ticket": int(pos.ticket),
                "existing": False,
            }
            return True
        logger.warning("TP1 partial refused for %s: %s (will retry)",
                       trade_id, self.last_error)
        return False

    def close_position(self, trade_id: str, symbol: str) -> bool:
        """Full market close of the trade's position (thesis exit handoff)."""
        mt5 = _mt5_ready()
        if not self._demo_safe(mt5):
            return False
        magic = magic_for(trade_id)
        pos = self._position_by_magic(magic)
        if not pos:
            self.last_error = "close_position: position not found"
            return False
        sym = self._sym(symbol)
        tick = mt5.symbol_info_tick(sym)
        close_type = (mt5.ORDER_TYPE_SELL if pos.type == mt5.ORDER_TYPE_BUY
                      else mt5.ORDER_TYPE_BUY)
        price = tick.bid if close_type == mt5.ORDER_TYPE_SELL else tick.ask
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": sym,
            "volume": float(pos.volume),
            "type": close_type,
            "position": int(pos.ticket),
            "price": price,
            "deviation": self.deviation,
            "magic": magic,
            "comment": "SS-demo-exit",
            "type_filling": self._filling_type(mt5, sym),
        }
        res = self._send_deal(mt5, request)
        if res is not None:
            self.last_close = {"price": round(float(price), 2),
                               "volume": float(pos.volume),
                               "ticket": int(pos.ticket)}
            return True
        logger.warning("close_position refused for %s: %s", trade_id,
                       self.last_error)
        return False

    def open_orders(self):
        """Outstanding broker orders (for pending reconciliation)."""
        try:
            return list(_mt5_ready().orders_get() or [])
        except Exception:  # noqa: BLE001
            return []

    def cancel_order(self, ticket: int) -> bool:
        """Cancel a broker pending order by ticket."""
        # R25.7-G: the live "failed cancel ... [Market closed]" incident.
        if self._market_closed_active():
            logger.debug("cancel %s skipped: market closed (weekend guard)",
                         ticket)
            return False
        mt5 = _mt5_ready()
        if not self._demo_safe(mt5):
            return False
        try:
            res = mt5.order_send({
                "action": mt5.TRADE_ACTION_REMOVE,
                "order": int(ticket),
            })
            if self._note_market_closed(mt5, res, f"cancel {ticket}"):
                return False
            ok = bool(res and res.retcode == mt5.TRADE_RETCODE_DONE)
            if not ok:
                logger.warning("cancel order %s refused: %s", ticket,
                               getattr(res, "comment", res))
            return ok
        except Exception as exc:  # noqa: BLE001
            logger.error("cancel order %s crashed: %s", ticket, exc)
            return False

    def last_exit(self, trade_id: str) -> Optional[Dict[str, Any]]:
        """The broker's own record of how this trade's position exited.

        Returns the newest OUT deal {price, profit, time} for the trade's
        magic, or None if no exit deal exists yet. Used so the DB mirrors
        the REAL broker exit price + realized P&L instead of the live tick
        at the moment we happened to notice the position was gone.
        """
        mt5 = _mt5()
        magic = magic_for(trade_id)
        try:
            now = int(time.time()) + 86400
            deals = mt5.history_deals_get(0, now) or ()
        except Exception as exc:  # noqa: BLE001
            logger.error("history_deals_get crashed: %s", exc)
            return None
        outs = [d for d in deals
                if getattr(d, "magic", None) == magic
                and getattr(d, "entry", None) == getattr(mt5, "DEAL_ENTRY_OUT", 1)]
        if not outs:
            return None
        d = max(outs, key=lambda x: getattr(x, "time", 0))
        return {"price": float(getattr(d, "price", 0.0)),
                "profit": float(getattr(d, "profit", 0.0)),
                "time": int(getattr(d, "time", 0)),
                "volume": float(getattr(d, "volume", 0.0)),
                # MetaTrader5's Python namedtuple calls this position_id on
                # current builds; older fakes/versions used position.
                "position": int(getattr(d, "position_id",
                                        getattr(d, "position", 0)) or 0)}

    # -- reconciliation ------------------------------------------------------
    def reconcile(self, open_rows: List[Dict[str, Any]]) -> List[str]:
        mismatches: List[str] = []
        for row in open_rows:
            ticket = row.get("mt5_ticket")
            if not ticket:
                continue
            pos = self._position_by_magic(magic_for(str(row.get("id"))))
            if pos is None:
                mismatches.append(f"{row.get('id')}: no MT5 position for ticket {ticket}")
                continue
            db_sl = float(row.get("stop_loss") or 0)
            if db_sl and abs(pos.sl - db_sl) > 0.05:
                mismatches.append(
                    f"{row.get('id')}: SL drift mt5={pos.sl:.2f} db={db_sl:.2f}")
            side_db = str(row.get("type") or row.get("side") or "").upper()
            pos_buy = pos.type == _mt5().ORDER_TYPE_BUY
            if (side_db == "BUY") != pos_buy:
                mismatches.append(f"{row.get('id')}: side mismatch")
        if mismatches and self.halt_on_mismatch:
            self._halt("; ".join(mismatches))
        return mismatches
