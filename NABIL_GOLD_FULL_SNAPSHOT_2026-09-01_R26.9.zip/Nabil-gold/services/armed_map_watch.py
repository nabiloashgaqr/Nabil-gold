"""ARMED MAP card: a Path-4-grade map waiting only for auction confirmation.

Operator 2026-08-19 (after the 4399 post-mortem): the repaired SMC agent
now maps the manual analyst's trade AT the raid — the replay produced a
SELL LIQUIDITY_REVERSAL at 4396.5 with quality 76 / dominance 92 /
return 79 / trigger 87 REJECTION_CONFIRMED, clearing every Path-4 floor
except the auction confirmation (flow read WAIT 57-62% all afternoon).
Under the old flow that map would have died in silence; the operator saw
the losing adds but never the winning map.

This module decides when such a map deserves a display-only card:

  * the selected SMC candidate passes ALL Path-4 floors (quality, return
    probability, dominance, trigger score + trigger_ready) EXCEPT the
    auction read — auction is the ONLY missing witness;
  * zero qualified core opposition (same as Path 4 itself);
  * throttled like AGENT WATCH: a card on NEW map / side FLIP / entry
    moved materially, plus a reminder at most once an hour — never a
    5-minute drumbeat. State survives a grace window so a flickering
    candidate does not re-announce as NEW.

Words only: no orders, no plans, no admission side effects.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict

ROOT = Path(__file__).resolve().parents[1]

DEFAULTS = {
    "enabled": True,
    "min_minutes_between_cards": 15,
    "reminder_interval_minutes": 60,
    "material_entry_move_points": 30.0,
    "clear_grace_minutes": 20,
}


def watch_config(config: Dict[str, Any]) -> Dict[str, Any]:
    raw = ((config.get("session_plan_delivery") or {}).get("armed_map_watch") or {})
    cfg = dict(DEFAULTS)
    if isinstance(raw, dict):
        for key in DEFAULTS:
            if key in raw:
                cfg[key] = raw[key]
    return cfg


def state_path(root: Path | None = None) -> Path:
    return (root or ROOT) / "storage" / "armed_map_watch_state.json"


def load_states(path: Path) -> Dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:  # noqa: BLE001
        return {}


def save_states(path: Path, states: Dict[str, Any]) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(states, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(path)
    except Exception:  # noqa: BLE001 - display state must never break a cycle
        pass


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def armed_map_review(
    candidate: Dict[str, Any] | None,
    auction: Dict[str, Any] | None,
    opposition_count: int,
    config: Dict[str, Any],
) -> Dict[str, Any]:
    """Is this candidate a Path-4-grade map missing ONLY the auction read?

    Mirrors the exact floors of signal_requirements.path4_smc_map_auction so
    the card can never promise a route the gate would refuse. Returns
    {"armed": bool, "reason": str, ...card fields}.
    """
    if not isinstance(candidate, dict) or not candidate:
        return {"armed": False, "reason": "no candidate"}
    p4 = (config.get("signal_requirements") or {}).get("path4_smc_map_auction") or {}
    if not bool(p4.get("enabled", False)):
        return {"armed": False, "reason": "path4 disabled"}
    direction = str(candidate.get("direction") or "").upper()
    if direction not in {"BUY", "SELL"}:
        return {"armed": False, "reason": "no direction"}
    quality = _f(candidate.get("quality_score"), _f((candidate.get("setup_quality") or {}).get("score")))
    ret = _f(candidate.get("return_probability_score"), _f(candidate.get("return_probability")))
    dom = _f(candidate.get("thesis_dominance_score"), _f(candidate.get("dominance")))
    trig = _f(candidate.get("trigger_score"))
    trig_ready = bool(candidate.get("trigger_ready"))
    checks = {
        "quality": quality >= _f(p4.get("min_map_quality"), 60.0),
        "return_probability": ret >= _f(p4.get("min_return_probability"), 55.0),
        "dominance": dom >= _f(p4.get("min_dominance"), 70.0),
        "trigger": trig >= _f(p4.get("min_trigger_score"), 70.0) and trig_ready,
        "opposition": int(opposition_count or 0) <= int(p4.get("max_qualified_opposition", 0) or 0),
    }
    if not all(checks.values()):
        failed = [k for k, ok in checks.items() if not ok]
        return {"armed": False, "reason": "floors failed: " + ",".join(failed)}
    # The map is Path-4 grade. Is auction genuinely the ONLY missing piece?
    auction = auction if isinstance(auction, dict) else {}
    a_side = str(auction.get("direction") or auction.get("signal") or "WAIT").upper()
    a_conf = _f(auction.get("confidence"))
    a_min = _f(p4.get("min_auction_confidence"), 65.0)
    if a_side == direction and a_conf >= a_min:
        return {"armed": False, "reason": "auction already confirms — Path 4 owns this"}
    return {
        "armed": True,
        "reason": "auction is the only missing witness",
        "direction": direction,
        "entry_price": _f(candidate.get("entry_price")),
        "stop_loss": _f(candidate.get("stop_loss")),
        "quality": round(quality, 1),
        "dominance": round(dom, 1),
        "return_probability": round(ret, 1),
        "trigger_score": round(trig, 1),
        "setup_type": str(candidate.get("setup_type") or ""),
        "auction_now": f"{a_side} {a_conf:.0f}%",
        "auction_needed": f"{direction} >= {a_min:.0f}%",
    }


def decide_card(
    prev: Dict[str, Any] | None,
    review: Dict[str, Any],
    cfg: Dict[str, Any],
    now: float | None = None,
) -> Dict[str, Any]:
    """Throttle: NEW / FLIP / MOVED / REMINDER — or silence."""
    now = time.time() if now is None else now
    floor_s = _f(cfg.get("min_minutes_between_cards"), 15) * 60.0
    remind_s = _f(cfg.get("reminder_interval_minutes"), 60) * 60.0
    move_pts = _f(cfg.get("material_entry_move_points"), 30.0)
    fresh = {
        "direction": review.get("direction"),
        "entry_price": _f(review.get("entry_price")),
        "last_card_at": now,
        "first_seen": now,
        "last_seen": now,
    }
    if not isinstance(prev, dict) or not prev:
        return {"send": True, "kind": "NEW", "state": fresh}
    fresh["first_seen"] = _f(prev.get("first_seen"), now)
    since = now - _f(prev.get("last_card_at"))
    if str(prev.get("direction")) != str(review.get("direction")):
        return {"send": True, "kind": "FLIP", "state": fresh}
    moved = abs(_f(review.get("entry_price")) - _f(prev.get("entry_price"))) * 10.0  # gold points
    kind = None
    if moved >= move_pts:
        kind = "MOVED"
    elif remind_s > 0 and since >= remind_s:
        kind = "REMINDER"
    if kind and (since >= floor_s or kind == "REMINDER"):
        return {"send": True, "kind": kind, "state": fresh}
    carried = dict(prev)
    carried["last_seen"] = now
    carried["entry_price"] = _f(review.get("entry_price"))
    return {"send": False, "kind": None, "state": carried}


def should_clear(prev: Dict[str, Any] | None, cfg: Dict[str, Any],
                 now: float | None = None) -> bool:
    if not isinstance(prev, dict) or not prev:
        return True
    now = time.time() if now is None else now
    grace_s = _f(cfg.get("clear_grace_minutes"), 20) * 60.0
    if grace_s <= 0:
        return True
    return (now - _f(prev.get("last_seen"))) >= grace_s
