"""Durable four-path trade ledger and comparable outcome statistics.

The ledger is operational measurement only.  It never changes admission,
risk, stops, targets, position size, or trade management.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List

from services.execution_paths import (
    PATH_DEFINITIONS,
    UNKNOWN_PATH,
    resolve_execution_path,
)
from utils.helpers import load_trades, mutate_trades

OPEN_STATUSES = {"PENDING", "OPEN", "PARTIAL", "TP1_HIT"}
UNFILLED_STATUSES = {"PENDING", "CANCELLED"}
CLOSED_STATUSES = {
    "TP2_HIT", "SL_HIT", "TRAILING_SL_HIT", "BE_HIT", "EXPIRED",
    "THESIS_EXIT", "MANUAL_CLOSE", "CLOSED", "CLOSED_TP1", "CLOSED_TP2",
    "CLOSED_SL",
}


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _pnl(row: Dict[str, Any]) -> float | None:
    for key in ("final_pnl", "pnl_points", "current_pnl_points", "current_pnl"):
        value = row.get(key)
        if value is None or value == "":
            continue
        try:
            return float(value)
        except (TypeError, ValueError):
            continue
    return None


def compact_trade_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    path = resolve_execution_path(row)
    snapshot = row.get("signal_snapshot") or {}
    if not isinstance(snapshot, dict):
        snapshot = {}
    signal = snapshot.get("signal") or {}
    if not isinstance(signal, dict):
        signal = {}
    return {
        "id": str(row.get("id") or row.get("trade_id") or ""),
        "execution_path_id": path.get("id"),
        "execution_path_number": path.get("number"),
        "execution_path_name": path.get("name"),
        "admission_path": path.get("admission_path"),
        "symbol": row.get("symbol") or snapshot.get("symbol"),
        "side": str(row.get("type") or row.get("side") or snapshot.get("decision") or "").upper(),
        "status": str(row.get("status") or "").upper(),
        "entry_price": row.get("entry_price"),
        "initial_stop_loss": row.get("initial_stop_loss", row.get("stop_loss")),
        "stop_loss": row.get("stop_loss"),
        "tp1": row.get("tp1", signal.get("tp1")),
        "tp2": row.get("tp2", signal.get("tp2")),
        "order_kind": row.get("order_kind") or signal.get("entry_kind"),
        "order_type": row.get("order_type") or signal.get("order_type"),
        "created_at": row.get("created_at") or row.get("entry_time"),
        "entry_time": row.get("entry_time"),
        "closed_at": row.get("closed_at") or row.get("close_time"),
        "close_price": row.get("close_price"),
        "final_pnl": row.get("final_pnl"),
        "pnl_points": row.get("pnl_points", row.get("current_pnl_points")),
        "partial_close": bool(row.get("partial_close", False)),
        "mt5_ticket": row.get("mt5_ticket"),
        "last_updated": row.get("last_updated") or _now_iso(),
    }


class PathPerformanceTracker:
    """Mirror trade state into a local, path-focused ledger.

    Supabase remains the main trade book.  This local mirror exists so the VPS
    can compare paths even when its live Supabase schema has not yet added the
    optional execution_path scalar columns; provenance also remains embedded
    in ``signal_snapshot``.
    """

    def __init__(self, path: str | Path = "storage/path_performance/trades.json") -> None:
        candidate = Path(path)
        if not candidate.is_absolute():
            candidate = Path(__file__).resolve().parents[1] / candidate
        self.path = candidate

    def record_trade(self, trade: Dict[str, Any]) -> None:
        compact = compact_trade_snapshot(trade)
        if not compact.get("id"):
            return

        def _upsert(rows: List[Dict[str, Any]]) -> None:
            for index, existing in enumerate(rows):
                if str(existing.get("id")) == compact["id"]:
                    merged = dict(existing)
                    merged.update(compact)
                    rows[index] = merged
                    return
            rows.append(compact)

        mutate_trades(_upsert, self.path)

    def record_update(self, trade_id: str, updates: Dict[str, Any]) -> None:
        if not trade_id or not isinstance(updates, dict):
            return

        def _update(rows: List[Dict[str, Any]]) -> None:
            for row in rows:
                if str(row.get("id")) != str(trade_id):
                    continue
                # Only outcome/geometry fields belong in the measurement
                # mirror.  Unknown update keys are intentionally ignored.
                for key in (
                    "status", "entry_price", "initial_stop_loss", "stop_loss",
                    "tp1", "tp2", "order_kind", "order_type", "closed_at",
                    "close_time", "close_price", "final_pnl", "pnl_points",
                    "current_pnl_points", "partial_close", "mt5_ticket",
                    "last_updated",
                ):
                    if key in updates:
                        target = "closed_at" if key == "close_time" else key
                        target = "pnl_points" if key == "current_pnl_points" else target
                        row[target] = deepcopy(updates[key])
                row["status"] = str(row.get("status") or "").upper()
                row["last_updated"] = updates.get("last_updated") or _now_iso()
                return

        mutate_trades(_update, self.path)

    def rows(self) -> List[Dict[str, Any]]:
        return load_trades(self.path)


def summarize_paths(rows: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    """Summarize all four paths with one transparent success definition.

    ``success_rate_pct`` = resolved trades with positive net points divided by
    resolved trades that carry a numeric final/realized PnL. Breakeven counts
    in the denominator and is reported separately. Pending/open trades never
    inflate or depress success rate.
    """
    grouped: Dict[str, List[Dict[str, Any]]] = {
        path_id: [] for path_id in PATH_DEFINITIONS
    }
    unknown: List[Dict[str, Any]] = []
    for raw in rows:
        if not isinstance(raw, dict):
            continue
        path = resolve_execution_path(raw)
        path_id = str(path.get("id") or UNKNOWN_PATH)
        if path_id in grouped:
            grouped[path_id].append(raw)
        else:
            unknown.append(raw)

    result_rows: List[Dict[str, Any]] = []
    for path_id, definition in PATH_DEFINITIONS.items():
        trades = grouped[path_id]
        pending = sum(str(t.get("status") or "").upper() == "PENDING" for t in trades)
        open_count = sum(str(t.get("status") or "").upper() in {"OPEN", "PARTIAL", "TP1_HIT"} for t in trades)
        unfilled = sum(
            str(t.get("status") or "").upper() == "CANCELLED"
            and not t.get("mt5_ticket") for t in trades
        )
        resolved_with_pnl: List[tuple[Dict[str, Any], float]] = []
        for trade in trades:
            status = str(trade.get("status") or "").upper()
            pnl = _pnl(trade)
            unfilled_terminal = (
                status in {"CANCELLED", "EXPIRED"}
                and not trade.get("mt5_ticket")
            )
            if status not in OPEN_STATUSES and not unfilled_terminal and pnl is not None:
                resolved_with_pnl.append((trade, pnl))
        wins = sum(pnl > 0 for _, pnl in resolved_with_pnl)
        losses = sum(pnl < 0 for _, pnl in resolved_with_pnl)
        breakeven = sum(abs(pnl) < 1e-9 for _, pnl in resolved_with_pnl)
        pnl_values = [pnl for _, pnl in resolved_with_pnl]
        gross_win = sum(value for value in pnl_values if value > 0)
        gross_loss = abs(sum(value for value in pnl_values if value < 0))
        resolved = len(resolved_with_pnl)
        filled = sum(
            bool(t.get("mt5_ticket"))
            or str(t.get("status") or "").upper() not in (UNFILLED_STATUSES | {"EXPIRED"})
            for t in trades
        )
        result_rows.append({
            **deepcopy(definition),
            "trades_recorded": len(trades),
            "filled_or_activated": filled,
            "fill_rate_pct": round(filled / len(trades) * 100.0, 1) if trades else None,
            "pending": pending,
            "open": open_count,
            "cancelled_unfilled": unfilled,
            "resolved_with_pnl": resolved,
            "wins": wins,
            "losses": losses,
            "breakeven": breakeven,
            "success_rate_pct": round(wins / resolved * 100.0, 1) if resolved else None,
            "loss_rate_pct": round(losses / resolved * 100.0, 1) if resolved else None,
            "net_points": round(sum(pnl_values), 1),
            "average_points": round(sum(pnl_values) / resolved, 1) if resolved else None,
            "profit_factor": round(gross_win / gross_loss, 2) if gross_loss > 0 else (None if gross_win == 0 else "INF"),
            "tp1_or_partial_count": sum(
                bool(t.get("partial_close"))
                or str(t.get("status") or "").upper() in {"TP1_HIT", "PARTIAL", "TP2_HIT"}
                for t in trades
            ),
            "sample_ready": resolved >= 20,
            "sample_note": (
                "comparison sample is still small; do not tune rules from it"
                if resolved < 20 else "minimum comparison sample reached"
            ),
        })

    ranked = sorted(
        [row for row in result_rows if row.get("success_rate_pct") is not None],
        key=lambda row: (float(row.get("success_rate_pct") or 0), float(row.get("net_points") or 0)),
        reverse=True,
    )
    return {
        "generated_at": _now_iso(),
        "success_definition": (
            "positive net points among resolved trades with numeric PnL; "
            "pending/open excluded, breakeven included in denominator"
        ),
        "minimum_sample_for_comparison": 20,
        "paths": result_rows,
        "current_leader": ranked[0].get("id") if ranked else None,
        "unknown_legacy_trades": len(unknown),
        "warning": "Measurement only. It does not auto-change weights, thresholds, stops, targets, or execution rules.",
    }
