"""One canonical 50..95 confidence score for calibrated edge agents.

The historical logistic curve is retained as a monotonic shape, but its own
attainable range is normalized onto the canonical voting-confidence scale.
This prevents a valid curve whose raw probability only spans (for example)
47..59 percent from making a 67-percent voting bar mathematically impossible.

Only the normalized score is exposed to operators. It is an evidence-confidence
score, not a second probability field.
"""
from __future__ import annotations

import math
from typing import Any, Dict, Mapping


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _sigmoid(z: float) -> float:
    bounded = max(-60.0, min(60.0, float(z)))
    return 1.0 / (1.0 + math.exp(-bounded))


def normalized_logistic_confidence(
    strength: float,
    calibration: Mapping[str, Any] | None,
    *,
    floor: float = 50.0,
    ceiling: float = 95.0,
    min_curve_span_points: float = 2.0,
) -> Dict[str, Any]:
    """Map edge strength 0..1 to one canonical confidence number.

    Let ``P(x)`` be the stored monotonic logistic curve. The returned score is::

        floor + (ceiling-floor) * (P(strength)-P(0)) / (P(1)-P(0))

    A curve spanning fewer than ``min_curve_span_points`` percentage points
    has no useful discriminating power and is held at the neutral floor.
    When calibration is deliberately optional, callers may use the explicit
    linear fallback returned for a missing curve.
    """
    strength = max(0.0, min(1.0, _f(strength)))
    logistic = (calibration or {}).get("logistic") or {}
    if "a" not in logistic or "b" not in logistic:
        score = floor + (ceiling - floor) * strength
        return {
            "score": max(floor, min(ceiling, score)),
            "valid": True,
            "mode": "linear_edge_fallback",
            "strength": strength,
            "curve_span_points": None,
        }

    a = _f(logistic.get("a"))
    b = max(0.0, _f(logistic.get("b")))
    p0 = _sigmoid(a)
    p1 = _sigmoid(a + b)
    span = p1 - p0
    span_points = span * 100.0
    if span_points < max(0.0, _f(min_curve_span_points, 2.0)):
        return {
            "score": floor,
            "valid": False,
            "mode": "normalized_logistic_evidence",
            "strength": strength,
            "curve_span_points": span_points,
            "reason": "CALIBRATION_HAS_NO_DISCRIMINATING_POWER",
        }

    current = _sigmoid(a + b * strength)
    normalized = max(0.0, min(1.0, (current - p0) / span))
    score = floor + (ceiling - floor) * normalized
    return {
        "score": max(floor, min(ceiling, score)),
        "valid": True,
        "mode": "normalized_logistic_evidence",
        "strength": strength,
        "curve_span_points": span_points,
    }
