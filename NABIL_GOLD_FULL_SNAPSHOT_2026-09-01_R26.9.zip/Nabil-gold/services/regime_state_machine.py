# -*- coding: utf-8 -*-
"""services/regime_state_machine.py — regime-aware SETUP STATE MACHINE (R25.8).

The audit found a strong *order/trade* lifecycle (the setup_memory ladder and
the executor's pending/fill/manage states) but no explicit, guarded state
machine that couples a setup's lifecycle to the MARKET REGIME. This module is
that machine: a small, pure, heavily-guard-railed transition table.

States (a setup's life):
    DETECTED          -> the pattern/POI exists
    POI_MARKED        -> the resting pool / zone is identified
    SWEEP_CONFIRMED   -> the liquidity raid happened (PATH 9) / trigger armed
    ENTRY_ARMED       -> a resting LIMIT is justified inside the band
    ENTRY_TRIGGERED   -> filled / committed to the executor
    MANAGED           -> live position (BE / trailing / partials handled elsewhere)
    CLOSED            -> terminal (TP / SL / thesis exit)
    REFUSED           -> terminal (a gate / regime / reflection veto)
    EXPIRED           -> terminal (TTL / stale)

The machine is REGIME-AWARE: a transition is only legal if the current regime
admits the path that owns the setup (see services.regime_switcher). A regime
that blocks the path moves a pre-entry setup to REFUSED with an auditable
reason instead of letting it arm into a hostile environment. It never
reverses a terminal state and never invents transitions.

This is PURE: callers persist whatever they like (setup_memory / DB). The
machine answers "is this move legal, and what is the resulting state + reason".
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

#: Ordered progression for pre-entry/active states.
STATE_ORDER: Dict[str, int] = {
    "DETECTED": 0,
    "POI_MARKED": 1,
    "SWEEP_CONFIRMED": 2,
    "ENTRY_ARMED": 3,
    "ENTRY_TRIGGERED": 4,
    "MANAGED": 5,
    "CLOSED": 6,
    "REFUSED": 6,
    "EXPIRED": 6,
}

TERMINAL_STATES = {"CLOSED", "REFUSED", "EXPIRED"}
INITIAL_STATE = "DETECTED"

#: Legal forward transitions (the guarded table). Anything not listed is
#: refused. Terminal states have no outgoing transitions.
LEGAL_TRANSITIONS: Dict[str, set] = {
    "DETECTED": {"POI_MARKED", "REFUSED", "EXPIRED"},
    "POI_MARKED": {"SWEEP_CONFIRMED", "ENTRY_ARMED", "REFUSED", "EXPIRED"},
    "SWEEP_CONFIRMED": {"ENTRY_ARMED", "REFUSED", "EXPIRED"},
    "ENTRY_ARMED": {"ENTRY_TRIGGERED", "REFUSED", "EXPIRED"},
    "ENTRY_TRIGGERED": {"MANAGED", "CLOSED", "EXPIRED"},
    "MANAGED": {"CLOSED", "EXPIRED"},
    "CLOSED": set(),
    "REFUSED": set(),
    "EXPIRED": set(),
}

#: States from which a regime/reflection veto is allowed to REFUSE (never
#: after capital is committed).
VETOABLE_STATES = {"DETECTED", "POI_MARKED", "SWEEP_CONFIRMED", "ENTRY_ARMED"}


class RegimeStateMachine:
    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        self.config = config or {}
        rsm = self.config.get("regime_state_machine", {}) or {}
        self.enabled = bool(rsm.get("enabled", True))
        # When False the regime gate only warns (advisory); when True it
        # actually drives pre-entry setups to REFUSED. Default: enforce.
        self.enforce_regime = bool(rsm.get("enforce_regime", True))

    # ── core transition ───────────────────────────────────────────────────
    def transition(self, *, from_state: str, to_state: str,
                   event: str = "",
                   regime: Optional[Dict[str, Any]] = None,
                   reflection_veto: Optional[Dict[str, Any]] = None,
                   path_id: str = "") -> Dict[str, Any]:
        """Evaluate a proposed transition.

        Returns {"allowed": bool, "from":..., "to":..., "state": <new state>,
                 "reason": str, "warnings": [...]}. On refusal the new state
                 is either REFUSED (a veto) or the unchanged from_state (an
                 illegal move).
        """
        from_state = str(from_state or INITIAL_STATE).upper()
        to_state = str(to_state or "").upper()
        warnings: List[str] = []

        if from_state not in STATE_ORDER:
            return {"allowed": False, "from": from_state, "to": to_state,
                    "state": from_state, "reason": f"unknown_from_state:{from_state}",
                    "warnings": warnings}
        if from_state in TERMINAL_STATES:
            return {"allowed": False, "from": from_state, "to": to_state,
                    "state": from_state,
                    "reason": f"terminal_state_{from_state}_is_immutable",
                    "warnings": warnings}
        if to_state not in STATE_ORDER:
            return {"allowed": False, "from": from_state, "to": to_state,
                    "state": from_state, "reason": f"unknown_to_state:{to_state}",
                    "warnings": warnings}

        # ── veto: reflection cooldown (pre-entry only) ─────────────────────
        if reflection_veto and isinstance(reflection_veto, dict) \
                and reflection_veto.get("veto") and from_state in VETOABLE_STATES:
            reason = str(reflection_veto.get("reason") or "reflection_cooldown")
            return {"allowed": False, "from": from_state, "to": to_state,
                    "state": "REFUSED", "reason": reason,
                    "veto": "reflection", "warnings": warnings}

        # ── veto: regime does not admit the path (pre-entry only) ──────────
        if (regime and self.enforce_regime and self.enabled
                and from_state in VETOABLE_STATES and path_id
                and to_state not in TERMINAL_STATES):
            blocked = self._regime_blocks(path_id, regime)
            if blocked:
                reason = (f"regime_{regime.get('regime')}_blocks_{path_id}: "
                          f"admit={regime.get('admit_paths')}")
                warnings.append(reason)
                return {"allowed": False, "from": from_state, "to": to_state,
                        "state": "REFUSED", "reason": reason,
                        "veto": "regime", "warnings": warnings}

        # ── legality table ─────────────────────────────────────────────────
        if to_state not in LEGAL_TRANSITIONS.get(from_state, set()):
            # Allow same-state no-ops and forward re-assertion within VETOABLE
            # pre-entry ladder only via the table; a backward move is illegal.
            if to_state == from_state:
                return {"allowed": True, "from": from_state, "to": to_state,
                        "state": from_state, "reason": "noop_same_state",
                        "warnings": warnings}
            return {"allowed": False, "from": from_state, "to": to_state,
                    "state": from_state,
                    "reason": f"illegal_transition:{from_state}->{to_state}",
                    "warnings": warnings}

        return {"allowed": True, "from": from_state, "to": to_state,
                "state": to_state,
                "reason": f"event:{event or to_state.lower()}",
                "warnings": warnings}

    # ── convenience: advance a setup from observed signals ────────────────
    def advance(self, setup: Dict[str, Any], *, event: str,
                regime: Optional[Dict[str, Any]] = None,
                reflection_veto: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Apply a named event to a setup dict, returning the updated copy.

        Events: poi_marked, sweep_confirmed, arm, trigger, fill, manage,
        close, refuse, expire. The setup dict carries at least
        {"setup_state", "execution_path_id"}.
        """
        out = dict(setup)
        state = str(out.get("setup_state") or INITIAL_STATE).upper()
        path_id = str(out.get("execution_path_id") or out.get("path_id") or "")
        target = {
            "poi_marked": "POI_MARKED",
            "sweep_confirmed": "SWEEP_CONFIRMED",
            "arm": "ENTRY_ARMED",
            "trigger": "ENTRY_TRIGGERED",
            "fill": "MANAGED",
            "manage": "MANAGED",
            "close": "CLOSED",
            "refuse": "REFUSED",
            "expire": "EXPIRED",
        }.get(str(event).lower())
        if target is None:
            out["_rsm_error"] = f"unknown_event:{event}"
            return out
        res = self.transition(from_state=state, to_state=target, event=event,
                              regime=regime, reflection_veto=reflection_veto,
                              path_id=path_id)
        out["setup_state"] = res["state"]
        out["_rsm_last"] = {"allowed": res["allowed"], "reason": res.get("reason"),
                            "veto": res.get("veto")}
        if res.get("warnings"):
            out["_rsm_warnings"] = res["warnings"]
        return out

    # ── helpers ───────────────────────────────────────────────────────────
    @staticmethod
    def _regime_blocks(path_id: str, regime: Dict[str, Any]) -> bool:
        admit = regime.get("admit_paths")
        if not admit:  # no policy present -> do not block (fail-open)
            return False
        token = ""
        for n in range(1, 10):
            if str(path_id).startswith(f"PATH_{n}") or str(path_id) == f"PATH_{n}":
                token = f"PATH_{n}"
                break
        if not token:
            return False
        return token not in set(admit)
