"""A 15-minute memory for Gemini's two-agent confirmation verdict.

Operator 2026-08-18i: 'ممكن ان نسال جميناي مرة كل ربع ساعة اذا كان هناك
وكيلين مؤهلين — كانت صفقة مفتوحة او لم تكن'. Gemini's ONE consuming job
is confirming a two-agent entry candidate (Path 3); everything else
(hourly WAIT context/news/macro reviews, post-decision documentation)
was burning the daily quota for display value.

The burn that motivated this: on 2026-08-17 a two-agent candidate stood
for a full hour and the 5-minute cycle asked Gemini about essentially the
same book TWELVE times. Each analysis cycle is a fresh process, so the
throttle lives on disk: the last verdict per symbol+side is REUSED for
confirmation_cache_minutes — a cached YES still confirms, a cached NO
still refuses, and the API is touched at most once per window.

Unavailable results (503, quota, parse failure) are never cached: a
transient outage must not lock the door for 15 minutes.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict

ROOT = Path(__file__).resolve().parents[1]

DEFAULT_TTL_MINUTES = 15.0


def cache_path(root: Path | None = None) -> Path:
    return (root or ROOT) / "storage" / "gemini_confirm_cache.json"


def _load_all(path: Path) -> Dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:  # noqa: BLE001 - missing/corrupt cache means "no memory"
        return {}


def load_confirmation(
    symbol: str,
    side: str,
    *,
    max_age_minutes: float = DEFAULT_TTL_MINUTES,
    root: Path | None = None,
    now: float | None = None,
    vol_signature: float | None = None,
    vol_invalidation_pct: float = 25.0,
) -> Dict[str, Any] | None:
    """Return the cached review for this symbol+side, or None.

    None means "ask the API". A verdict for the OTHER side does not carry
    over: a direction flip is a new question and may be asked immediately.

    2026-08-19 (warning #4 fix): when the caller passes the current ATR as
    ``vol_signature`` and the cached verdict was stored with one, a regime
    jump invalidates the memory — a YES recorded on a calm tape must not
    confirm a candidate on a suddenly violent one. Relative deviation
    beyond ``vol_invalidation_pct`` (default 25%) returns None.
    """
    if max_age_minutes <= 0:
        return None
    entry = _load_all(cache_path(root)).get(str(symbol).upper())
    if not isinstance(entry, dict):
        return None
    if str(entry.get("side") or "").upper() != str(side or "").upper():
        return None
    now = time.time() if now is None else now
    asked_at = float(entry.get("asked_at") or 0.0)
    if (now - asked_at) > max_age_minutes * 60.0:
        return None
    stored_sig = entry.get("vol_signature")
    if (
        isinstance(stored_sig, (int, float))
        and isinstance(vol_signature, (int, float))
        and float(stored_sig) > 0
        and float(vol_signature) > 0
    ):
        drift_pct = abs(float(vol_signature) - float(stored_sig)) / float(stored_sig) * 100.0
        if drift_pct > max(0.0, vol_invalidation_pct):
            return None  # volatility regime changed: old verdict is not the same question
    review = entry.get("review")
    if not isinstance(review, dict) or not review:
        return None
    review = dict(review)
    review["_cache_age_minutes"] = round((now - asked_at) / 60.0, 1)
    return review


def store_confirmation(
    symbol: str,
    side: str,
    review: Dict[str, Any] | None,
    *,
    root: Path | None = None,
    now: float | None = None,
    vol_signature: float | None = None,
) -> None:
    """Persist a DEFINITE review. Unavailable/empty results are not stored."""
    if not isinstance(review, dict) or not review:
        return
    if review.get("available") is False:
        return  # a 503/quota/parse failure must not lock the window
    if not str(review.get("verdict") or "").strip():
        return
    path = cache_path(root)
    data = _load_all(path)
    entry = {
        "side": str(side or "").upper(),
        "asked_at": time.time() if now is None else now,
        "review": {k: v for k, v in review.items() if not str(k).startswith("_")},
    }
    # volatility signature: prefer the hint riding inside the review, then the
    # explicit keyword argument (either may be absent)
    sig = review.get("_vol_signature_hint") if isinstance(review, dict) else None
    if not isinstance(sig, (int, float)):
        sig = vol_signature
    if isinstance(sig, (int, float)) and float(sig) > 0:
        entry["vol_signature"] = float(sig)
    data[str(symbol).upper()] = entry
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)
    except Exception:  # noqa: BLE001 - a cache write failure only costs quota
        pass
