# -*- coding: utf-8 -*-
"""services/path9_reversal.py — PATH 9: LIQUIDITY SWEEP RAID REVERSAL (R25.8).

Operator order (2026-08-29): "طبق المسار ٩ الجديد" — the institutional stop
raid / Turtle-Soup fade, reborn on the PATH 9 slot that previously held the
retired FX-4 strong-structure lane.

THE SETUP (counter-sweep, never a continuation):
  1. A MAJOR resting liquidity pool exists — previous-day high/low (PDH/PDL),
     the session high/low, or a major swing extreme — with stop orders parked
     just beyond it.
  2. Price RAIDS the pool: the wick extends BEYOND the level by a qualifying
     excursion (>= min_sweep_points, ATR-aware) but the candle CLOSES back
     inside — a failed breakout / liquidity grab.
  3. RESPONSIVE REJECTION: auction flow / volume confirms the rejection (a
     responsive step against the raid), so it is not just a quiet poke.
  4. M5 REVERSAL CANDLE: an entry-timeframe reversal (pin / rejection bar or
     an engulfing bar back inside the swept range).
  Direction is COUNTER the sweep: a sell-side sweep (lows taken) => BUY the
     rejection back up; a buy-side sweep (highs taken) => SELL.

This module is a PURE EVALUATOR: it detects the pattern and emits the admission
verdict (allow / refuse + reasons). It never sizes or sends an order. The stop
and targets are built through the single-source laws
(`utils.trading_rules.clamp_stop_price` / `targets_law`) and the lot through
`services.risk_usd`, so PATH 9 obeys the same absolute stop band and dollar
law as every other path. R24-0 risk supremacy still vetoes downstream.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence

from utils.instruments import point_size, price_to_points
from utils.trading_rules import clamp_stop_price, targets_law

#: Default config lives under config["path9_reversal"].
DEFAULTS: Dict[str, Any] = {
    "enabled": True,
    # The wick must clear the swept level by at least this many SYSTEM points
    # (gold uses 0.1 "points"; this is in the same point unit as the stop law).
    "min_sweep_points": 60.0,
    # ... but no more than this (a full-blown impulsive break, not a raid).
    "max_sweep_points": 400.0,
    # The rejection candle must close back inside by at least this fraction of
    # the wick excursion (0.5 = price reclaims half the raid wick).
    "min_reclaim_fraction": 0.35,
    # Require the M5 reversal candle to carry a body/wick rejection at least
    # this fraction of its own range (pin quality), or a full engulf.
    "rejection_wick_fraction": 0.55,
    # ── The independent witness (operator 2026-08-30, live) ──
    # The auction/flow TAPE is the MANDATORY witness for PATH 9 — this is the
    # REVERSE of PATH 4. In PATH 4 the SMC map is the thesis and the auction
    # signature merely unlocks it; in PATH 9 the raid+rejection is the thesis
    # and the responsive tape is what proves it is not a quiet poke. No tape
    # signature -> the snapshot raid fades without a trade.
    "require_flow_witness": True,
    # Auction/flow responsive confidence floor (0-100) for the tape witness.
    "flow_confidence_floor": 65.0,
    # ── SMC is the CONFIRMING witness (boost, not gate) ──
    # SMC agreement (same direction + a STRONG/MODERATE counter-trend sweep on
    # its own map) does NOT veto by itself; it lifts confidence / priority.
    # PATH 9 specifically covers the ORPHAN raid that SMC/planner did not map.
    "smc_confirmation": True,
    "smc_confidence_floor": 60.0,
    "smc_confidence_boost": 8.0,
    # ── Fence 2: the raid must be FRESH ──
    # The reversal candle has to confirm within this many M5 candles of the
    # raid wick; a rejection that arrives late is exhaustion, not a trap.
    "max_reversal_candles": 2,
    # ── Fence 4: a tight-stop snap must still pay ──
    # The geometry (stop just beyond the raid extreme, target the opposing
    # pool) must clear this minimum reward-to-risk; otherwise the tight stop
    # is paired with no real objective and the trade is skipped.
    "min_rr_ratio": 1.5,
    # The swept level must be among the recent important pools within this
    # many points of the extreme (so we fade PDH/PDL/session/swing, not noise).
    "pool_proximity_points": 200.0,
    # Lookback for a major swing extreme when PDH/PDL is absent.
    "swing_lookback_bars": 40,
}

ADMISSION_PATH = "LIQUIDITY_SWEEP_REVERSAL"


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def config_block(cfg: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    out = dict(DEFAULTS)
    raw = ((cfg or {}).get("path9_reversal") or {})
    if isinstance(raw, dict):
        for key, val in raw.items():
            if key == "description":
                continue
            out[key] = val
    return out


# ── candle primitives (pure) ────────────────────────────────────────────────

def _rejection_bar(candle: Dict[str, Any], direction: str) -> bool:
    """True if `candle` is a pin/rejection bar favouring `direction`.

    For a BUY (rejecting a sell-side sweep) we want a long LOWER wick: the low
    spiked and price closed back toward the high. For a SELL, a long UPPER
    wick. `rejection_wick_fraction` of the candle's range must be the wick on
    the rejected side.
    """
    o = _f(candle.get("open")); h = _f(candle.get("high"))
    lo = _f(candle.get("low")); c = _f(candle.get("close"))
    rng = h - lo
    if rng <= 0:
        return False
    if direction == "BUY":
        lower_wick = min(o, c) - lo
        return lower_wick / rng >= DEFAULTS["rejection_wick_fraction"] and c >= o - 1e-9
    upper_wick = h - max(o, c)
    return upper_wick / rng >= DEFAULTS["rejection_wick_fraction"] and c <= o + 1e-9


def _engulfing(prev: Dict[str, Any], candle: Dict[str, Any], direction: str) -> bool:
    """True if `candle` engulfs `prev` in the reversal `direction`."""
    po, pc = _f(prev.get("open")), _f(prev.get("close"))
    o, c = _f(candle.get("open")), _f(candle.get("close"))
    if direction == "BUY":
        return pc < po and c > o and c >= po and o <= pc      # bullish engulf
    return pc > po and c < o and c <= po and o >= pc          # bearish engulf


def _is_reversal_candle(candle: Dict[str, Any], prev: Optional[Dict[str, Any]],
                        direction: str, wick_floor: float) -> Optional[str]:
    """Trigger name if `candle` reverses in `direction`, else None.

    A pin/rejection bar whose rejection-side wick is >= wick_floor of its
    range, or an engulfing bar against the prior candle in the reversal
    direction.
    """
    o = _f(candle.get("open")); h = _f(candle.get("high"))
    lo = _f(candle.get("low")); c = _f(candle.get("close"))
    rng = h - lo
    pin = False
    if rng > 0:
        if direction == "BUY":
            pin = ((min(o, c) - lo) / rng >= wick_floor) and c >= o - 1e-9
        else:
            pin = ((h - max(o, c)) / rng >= wick_floor) and c <= o + 1e-9
    if pin:
        return "pin_bar"
    if prev is not None and _engulfing(prev, candle, direction):
        return "engulfing"
    return None


def _reversal_confirmed(candles: Sequence[Dict[str, Any]], direction: str,
                        cfg: Dict[str, Any], start_index: int = 0,
                        require_following: bool = False) -> Dict[str, Any]:
    """Check the M5 window for a CONFIRMATION reversal in `direction`.

    Fence 2 (freshness): the eye of the trap is a confirmation candle AFTER
    the raid wick - the raid candle itself only proves a spike. When
    ``require_following`` is set (an explicit raid candle), the trigger must
    be on one of the next ``max_reversal_candles`` closed candles after it;
    in scan mode (no explicit raid) the raid candle is the latest by
    construction and is allowed to confirm itself.
    """
    wick_floor = _f(cfg.get("rejection_wick_fraction"), DEFAULTS["rejection_wick_fraction"])
    window = int(_f(cfg.get("max_reversal_candles"), DEFAULTS["max_reversal_candles"]))
    if not candles:
        return {"confirmed": False, "reason": "no_m5_candles"}
    start_index = max(0, min(start_index, len(candles) - 1))
    first = start_index + 1 if require_following else start_index
    end_index = min(len(candles) - 1, start_index + max(window, 0))
    for idx in range(end_index, first - 1, -1):
        prev = candles[idx - 1] if idx - 1 >= 0 else None
        trigger = _is_reversal_candle(candles[idx], prev, direction, wick_floor)
        if trigger:
            return {"confirmed": True, "trigger": trigger,
                    "reversal_index": idx,
                    "lag_candles": (idx - start_index) if require_following else 0}
    return {"confirmed": False, "reason": "no_m5_reversal_candle_in_window"}


# ── sweep detection (pure) ──────────────────────────────────────────────────

def _candidate_pools(context: Dict[str, Any]) -> Dict[str, List[float]]:
    """Collect resting liquidity pools as {buy_side:[highs...], sell_side:[lows...]}.

    Sources, in priority order: explicit PDH/PDL, session high/low, then major
    swing extremes from the recent daily/structure context.
    """
    buy_side: List[float] = []
    sell_side: List[float] = []

    def _add(high: Any, low: Any) -> None:
        if _f(high) > 0:
            buy_side.append(_f(high))
        if _f(low) > 0:
            sell_side.append(_f(low))

    pdh = context.get("pdh") or context.get("previous_day_high")
    pdl = context.get("pdl") or context.get("previous_day_low")
    if _f(pdh) > 0 or _f(pdl) > 0:
        _add(pdh, pdl)
    sess = context.get("session") or {}
    if isinstance(sess, dict):
        _add(sess.get("high"), sess.get("low"))
    swings = context.get("swings") or {}
    if isinstance(swings, dict):
        for v in (swings.get("highs") or []):
            if _f(v) > 0:
                buy_side.append(_f(v))
        for v in (swings.get("lows") or []):
            if _f(v) > 0:
                sell_side.append(_f(v))
    # SMC liquidity map if present (same shape as the stop law uses).
    liq = context.get("liquidity_map") or context.get("liquidity") or {}
    if isinstance(liq, dict):
        for v in (liq.get("buy_side") or []):
            if _f(v) > 0:
                buy_side.append(_f(v))
        for v in (liq.get("sell_side") or []):
            if _f(v) > 0:
                sell_side.append(_f(v))
    return {"buy_side": sorted(set(buy_side)), "sell_side": sorted(set(sell_side))}


def detect_sweep(*, candle: Dict[str, Any], pools: Dict[str, List[float]],
                 symbol: str, config: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """Inspect one raid candle against the known pools.

    Returns a sweep descriptor, or None when no qualifying raid is present.
    A BUY-SETUP sweep = sell-side liquidity (lows) taken then reclaimed;
    a SELL-SETUP sweep = buy-side liquidity (highs) taken then rejected.
    `config` is the full system config (used for the per-symbol point size);
    numeric sweep thresholds are read by the caller and passed on the candle
    context via evaluate_path9_reversal.
    """
    cfg = config_block(config)
    pv = point_size(symbol, config) or 0.0
    high = _f(candle.get("high"))
    low = _f(candle.get("low"))
    close = _f(candle.get("close"))
    if high <= 0 or low <= 0 or close <= 0:
        return None
    min_pts = _f(cfg.get("min_sweep_points"))
    max_pts = _f(cfg.get("max_sweep_points"))
    reclaim_floor = _f(cfg.get("min_reclaim_fraction"))
    prox = _f(cfg.get("pool_proximity_points"))

    best: Optional[Dict[str, Any]] = None
    # Sell-side sweep (lows) -> BUY setup.
    for level in pools.get("sell_side", []):
        if low >= level:
            continue  # never traded below the pool -> no raid
        excursion_pts = (level - low) / pv if pv > 0 else 0.0
        if excursion_pts < min_pts or excursion_pts > max_pts:
            continue
        # Close must reclaim back ABOVE the swept level (failed breakdown).
        if close <= level:
            continue
        wick = level - low
        reclaim = (close - level) / wick if wick > 0 else 0.0
        if reclaim < reclaim_floor:
            continue
        desc = {
            "sweep_side": "sell_side", "direction": "BUY", "level": level,
            "excursion_points": round(excursion_pts, 1),
            "reclaim_fraction": round(reclaim, 3),
        }
        if best is None or excursion_pts > best["excursion_points"]:
            best = desc
    # Buy-side sweep (highs) -> SELL setup.
    for level in pools.get("buy_side", []):
        if high <= level:
            continue  # never traded above the pool
        excursion_pts = (high - level) / pv if pv > 0 else 0.0
        if excursion_pts < min_pts or excursion_pts > max_pts:
            continue
        if close >= level:
            continue  # closed above = breakout, not a raid
        wick = high - level
        reject = (level - close) / wick if wick > 0 else 0.0
        if reject < reclaim_floor:
            continue
        desc = {
            "sweep_side": "buy_side", "direction": "SELL", "level": level,
            "excursion_points": round(excursion_pts, 1),
            "reclaim_fraction": round(reject, 3),
        }
        if best is None or excursion_pts > best["excursion_points"]:
            best = desc
    if best is None:
        return None
    best["within_pool_proximity"] = True
    return best


# ── admission evaluator ─────────────────────────────────────────────────────

def evaluate_path9_reversal(
    *,
    symbol: str,
    raid_candle: Optional[Dict[str, Any]] = None,
    m5_candles: Optional[Sequence[Dict[str, Any]]] = None,
    context: Optional[Dict[str, Any]] = None,
    flow: Optional[Dict[str, Any]] = None,
    smc: Optional[Dict[str, Any]] = None,
    config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Pure PATH 9 admission verdict.

    Parameters
    ----------
    raid_candle : the candle that performed the raid (open/high/low/close).
        When omitted, the evaluator scans the last ``max_reversal_candles``
        candles of ``m5_candles`` (newest first) for a qualifying raid and
        requires the reversal trigger within the freshness window.
    m5_candles : entry-timeframe candles; the reversal (pin / engulf) must
        confirm on the raid candle or within ``max_reversal_candles`` after it.
    context : {"pdh","pdl","session":{"high","low"},"swings":{"highs","lows"},
        "liquidity_map":{"buy_side":[],"sell_side":[]}} — resting pools.
    flow : the MANDATORY auction/flow tape witness
        {"direction":"BUY"/"SELL","confidence":0-100,"responsive":bool}. It
        must agree, be responsive and clear flow_confidence_floor; when
        require_flow_witness is true a missing/empty read refuses the trade.
    smc : the CONFIRMING structure witness (reverse of PATH 4) —
        {"direction","confidence","recent_sweep":{"type","confirmation",
        "with_trend"}}. Agreement + a counter-trend STRONG/MODERATE sweep
        lifts confidence; absence never vetoes (PATH 9 covers orphan raids).

    Returns a verdict dict: {allow, admission_path, direction, reasons[],
    sweep, trigger, entry, stop, tp1, tp2, confidence, ...}.
    """
    cfg = config_block(config)
    context = context or {}
    flow = flow or {}
    smc = smc or {}
    m5 = list(m5_candles or [])

    verdict: Dict[str, Any] = {
        "allow": False,
        "path": "PATH_9",
        "admission_path": ADMISSION_PATH,
        "direction": None,
        "reasons": [],
        "checks": {"enabled": bool(cfg.get("enabled", True)),
                   "sweep": False, "reversal": False,
                   "flow": None, "smc": None},
    }
    if not bool(cfg.get("enabled", True)):
        verdict["reasons"].append("path9_disabled_in_config")
        return verdict

    pools = _candidate_pools(context)

    # ── Locate the raid + reversal within the freshness window (Fence 2) ──
    found = None
    if raid_candle is not None:
        sweep = detect_sweep(candle=raid_candle, pools=pools, symbol=symbol, config=config)
        if sweep:
            # The explicit raid candle is the raid of record. Build the
            # sequence that FOLLOWS it: the raid plus the candles after it.
            after: List[Dict[str, Any]] = []
            if m5:
                for _i in range(len(m5) - 1, -1, -1):
                    if m5[_i] is raid_candle or m5[_i] == raid_candle:
                        after = m5[_i:]            # raid + what followed it
                        break
            window_seq = after or [raid_candle]
            # The reversal must confirm on the raid candle itself or within the
            # next max_reversal_candles candles after it (fence 2, freshness).
            reversal = _reversal_confirmed(window_seq, sweep["direction"], cfg,
                                           start_index=0, require_following=True)
            if reversal.get("confirmed"):
                trig_idx = reversal.get("reversal_index", 0) or 0
                trig_candle = window_seq[min(trig_idx, len(window_seq) - 1)]
                found = (trig_candle, sweep, reversal)
    else:
        window = int(_f(cfg.get("max_reversal_candles"), DEFAULTS["max_reversal_candles"]))
        newest_first = list(range(len(m5) - 1, max(-1, len(m5) - 1 - window), -1))
        for idx in newest_first:
            cand = m5[idx]
            sweep = detect_sweep(candle=cand, pools=pools, symbol=symbol, config=config)
            if not sweep:
                continue
            reversal = _reversal_confirmed(m5, sweep["direction"], cfg, start_index=idx)
            if reversal.get("confirmed"):
                # The trigger candle (the freshest confirmed one) sets timing.
                found = (m5[reversal["reversal_index"]], sweep, reversal)
                break
    # Stamp the sweep when a qualifying raid was found on ANY window candle,
    # even if the reversal confirmation then failed (diagnostics honesty).
    _sweep_seen = None
    for _c in (m5 or ([raid_candle] if raid_candle else [])):
        _sweep_seen = detect_sweep(candle=_c, pools=pools, symbol=symbol, config=config)
        if _sweep_seen:
            break
    if not found:
        if _sweep_seen:
            verdict["checks"]["sweep"] = True
            verdict["direction"] = _sweep_seen["direction"]
            verdict["sweep"] = {k: _sweep_seen[k] for k in
                ("sweep_side", "level", "excursion_points", "reclaim_fraction")}
            verdict["reasons"].append("no_m5_reversal_candle_in_window")
        elif not m5 and raid_candle is None:
            verdict["reasons"].append("no_m5_candles")
        else:
            verdict["reasons"].append("no_fresh_liquidity_sweep_reversal")
        return verdict

    candle, sweep, reversal = found
    direction = sweep["direction"]
    verdict["checks"]["sweep"] = True
    verdict["checks"]["reversal"] = True
    verdict["direction"] = direction
    verdict["sweep"] = {k: sweep[k] for k in
                        ("sweep_side", "level", "excursion_points", "reclaim_fraction")}
    verdict["trigger"] = reversal.get("trigger")
    verdict["reversal_lag_candles"] = reversal.get("lag_candles", 0)

    # ── Witness 1 (MANDATORY): the responsive auction/flow tape ──────────
    # This is the reverse of PATH 4: the tape must SIGN the raid, or no trade.
    f_dir = str(flow.get("direction") or "").upper()
    f_conf = _f(flow.get("confidence"))
    responsive = bool(flow.get("responsive", True))
    floor = _f(cfg.get("flow_confidence_floor"))
    require_flow = bool(cfg.get("require_flow_witness", True))
    flow_ok = False
    if not flow:
        if require_flow:
            verdict["reasons"].append("no_auction_tape_witness")
            return verdict
    else:
        if f_dir and f_dir != direction:
            verdict["reasons"].append(f"flow_disagrees ({f_dir} vs {direction})")
            return verdict
        if responsive is False:
            verdict["reasons"].append("flow_not_responsive")
            return verdict
        if require_flow and (not f_dir or f_conf < floor):
            verdict["reasons"].append(
                f"flow_confidence_{f_conf:.0f}_below_{floor:.0f}")
            return verdict
        if f_dir and f_conf < floor:
            # Flow present but weak and the witness is optional: treat as no
            # signature rather than a contradiction.
            pass
        else:
            flow_ok = True
    if flow_ok:
        verdict["checks"]["flow"] = {"direction": f_dir or direction,
                                     "confidence": f_conf, "responsive": responsive}

    # ── Witness 2 (CONFIRMING): SMC agreement boosts, never vetoes ───────
    confidence = f_conf if flow_ok and f_conf > 0 else 65.0
    smc_ok = False
    s_dir = str(smc.get("direction") or smc.get("signal") or "").upper()
    s_conf = _f(smc.get("confidence"))
    s_floor = _f(cfg.get("smc_confidence_floor"))
    recent = smc.get("recent_sweep") or {}
    s_sweep_type = str(recent.get("type") or "").lower()
    s_sweep_conf = str(recent.get("confirmation") or "").upper()
    s_with_trend = bool(recent.get("with_trend", False))
    sweep_aligned = ((direction == "BUY" and s_sweep_type == "sell_side")
                     or (direction == "SELL" and s_sweep_type == "buy_side"))
    smc_dir_agrees = bool(s_dir) and s_dir == direction and s_conf >= s_floor
    smc_sweep_confirmed = bool(smc_dir_agrees and sweep_aligned
                               and not s_with_trend
                               and s_sweep_conf in {"STRONG", "MODERATE"})
    if bool(cfg.get("smc_confirmation", True)) and smc_dir_agrees:
        smc_ok = True
        boost = _f(cfg.get("smc_confidence_boost")) if smc_sweep_confirmed else _f(cfg.get("smc_confidence_boost")) / 2.0
        confidence = min(92.0, confidence + boost)
        verdict["checks"]["smc"] = {
            "direction": s_dir, "confidence": s_conf,
            "sweep_confirmation": s_sweep_conf or None,
            "counter_trend_sweep": smc_sweep_confirmed,
        }

    # ── geometry through the single-source laws ──────────────────────────
    entry = _f(candle.get("close"))
    # The stop sits just beyond the raid extreme (the failed side), then is
    # CLAMPED into the symbol's absolute [floor, cap] band by the law.
    if direction == "BUY":
        raw_stop = float(candle.get("low"))
    else:
        raw_stop = float(candle.get("high"))
    stop = clamp_stop_price(direction=direction, entry=entry, stop=raw_stop,
                            cfg=config or {}, symbol=symbol)
    risk_price = abs(entry - stop)
    # Targets: reuse the operator target law (TP1 >= 0.8R, TP2 = 2x) anchored
    # on the swept pool and the opposing pools as objectives.
    levels = (pools.get("buy_side") if direction == "BUY" else pools.get("sell_side")) or []
    tp1 = tp2 = 0.0
    used_pool = False
    rr = 0.0
    try:
        tp1, tp2, used_pool = targets_law(
            direction=direction, entry=entry, risk_price=risk_price,
            levels=levels, cfg=config or {}, symbol=symbol)
        if tp2 and risk_price > 0:
            rr = abs(tp2 - entry) / risk_price
    except Exception:  # noqa: BLE001 — geometry never crashes the verdict
        tp1 = tp2 = 0.0
        used_pool = False

    # Fence 4: a tight-stop snap must still have a real objective.
    min_rr = _f(cfg.get("min_rr_ratio"))
    if min_rr > 0 and (not tp2 or rr < min_rr):
        verdict["reasons"].append(
            f"reward_to_risk_{rr:.2f}R_below_{min_rr:.1f}R_no_objective")
        return verdict

    reasons = ["liquidity_sweep_raid", "auction_tape_witness",
               f"m5_{verdict['trigger']}"]
    if smc_ok:
        reasons.append("smc_confirms_reversal"
                       if smc_sweep_confirmed else "smc_agrees")
    verdict.update({
        "allow": True,
        "entry": round(entry, 5),
        "stop": round(stop, 5),
        "tp1": round(tp1, 5) if tp1 else None,
        "tp2": round(tp2, 5) if tp2 else None,
        "rr_ratio": round(rr, 2),
        "confidence": round(confidence, 1),
        "targets_used_pool": bool(used_pool),
        "swept_level": round(sweep["level"], 5),
        "reasons": reasons,
    })
    return verdict
