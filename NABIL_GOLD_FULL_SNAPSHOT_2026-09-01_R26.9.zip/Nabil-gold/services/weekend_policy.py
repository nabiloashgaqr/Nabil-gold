"""R25.7-G (2026-08-29, v2 operator law): WEEKEND TIME ACCOUNTING.

Operator order 2026-08-29 (reversal of the v1 sweep): NO pending order is
ever cancelled by a weekend policy — every pending completes its configured
life (pending_freshness.stale_after_hours / r25_scalp.ttl_minutes), and the
age accounting EXCLUDES Saturday and Sunday entirely.

  effective_age = raw_age - (all Sat+Sun time inside the span)

The calendar is read in the SERVER timezone (Asia/Hebron), which is exactly
the market's closed window in both seasons: the FX week closes Fri 22:00 UTC
winter / 21:00 UTC summer = Sat 00:00 Hebron, and reopens Mon 00:00 Hebron.
So "Saturday and Sunday" as Hebron calendar days == the closed weekend,
hour-for-hour, summer and winter.

The executor's market-closed BACKOFF (mt5_executor._note_market_closed)
stays: it never cancels anything — it only stops hammering the broker with
sends while the market is closed (the 01:01:54 journal incident) and lets
callers retry on their next natural cycle.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

try:  # the VPS and this repo both ship zoneinfo (py>=3.9)
    from zoneinfo import ZoneInfo
    MARKET_TZ = ZoneInfo("Asia/Hebron")
except Exception:  # pragma: no cover - stripped-down hosts
    MARKET_TZ = timezone(timedelta(hours=3))

DEFAULTS: Dict[str, Any] = {
    "weekend_days": [5, 6],        # datetime.weekday(): Sat=5, Sun=6
    "market_closed_backoff_minutes": 10,
}


def policy(config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    out = dict(DEFAULTS)
    raw = (config or {}).get("weekend_policy") or {}
    if isinstance(raw.get("weekend_days"), (list, tuple)):
        out["weekend_days"] = [int(d) for d in raw["weekend_days"]]
    if "market_closed_backoff_minutes" in raw:
        out["market_closed_backoff_minutes"] = raw["market_closed_backoff_minutes"]
    return out


def weekend_days(config: Optional[Dict[str, Any]] = None) -> List[int]:
    return list(policy(config)["weekend_days"])


def weekend_excluded_seconds(start: datetime, end: datetime,
                             config: Optional[Dict[str, Any]] = None) -> float:
    """Total weekend (Sat+Sun by default) time inside [start, end].

    Both datetimes must be aware; the day boundaries are read in the
    SERVER timezone (MARKET_TZ) so the excluded span matches the closed
    market window in both DST seasons.
    """
    if end <= start:
        return 0.0
    days = set(weekend_days(config))
    tz = MARKET_TZ
    s = start.astimezone(tz)
    e = end.astimezone(tz)
    total = 0.0
    day = s.date()
    while day <= e.date():
        if day.weekday() in days:
            day_start = datetime(day.year, day.month, day.day, tzinfo=tz)
            day_end = day_start + timedelta(days=1)
            ov_s = max(s, day_start)
            ov_e = min(e, day_end)
            if ov_e > ov_s:
                total += (ov_e - ov_s).total_seconds()
        day += timedelta(days=1)
    return total


def effective_pending_age_hours(created: datetime, now: datetime,
                                config: Optional[Dict[str, Any]] = None) -> float:
    """Age in hours with Sat+Sun excluded (the v2 operator law): a pending
    created Friday evening and checked Monday morning has only grown by
    its pre-weekend + post-weekend hours, never by the closed weekend."""
    if now <= created:
        return 0.0
    raw = (now - created).total_seconds()
    excluded = weekend_excluded_seconds(created, now, config)
    return max(0.0, raw - excluded) / 3600.0
