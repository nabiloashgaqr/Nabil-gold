"""Send the AGENT WATCH card on CHANGE, not on persistence.

The card was born on 2026-08-17 to make a strong-but-blocked book visible.
By the same afternoon the operator reported the opposite problem: the same
watch state re-announced itself every 5-minute cycle — six near-identical
cards between 10:01 and 11:01. The telegram dedup window (180s) is shorter
than the cycle (300s), and the card body mutates a little every cycle
(net 80.3 -> 79.3 -> 76.9), so no text-level dedup can catch it.

Policy (operator 2026-08-17): a card goes out only when the watch STATE
changes, plus a low-frequency reminder while it persists:

  NEW        no active watch -> a qualifying book appeared
  FLIP       watch side reversed (BUY <-> SELL)
  SUPPORTERS the qualified supporter set changed (new thesis mix)
  CONFIDENCE net confidence moved >= material_confidence_change points
             since the last card
  REMINDER   nothing changed for reminder_interval_minutes (default 60);
             a one-line nudge, not the full card

A hard floor of min_minutes_between_cards applies to everything except a
FLIP (a reversal must never wait out a cooldown). When the book no longer
qualifies, the state is cleared so the next appearance is NEW again.

State lives in storage/agent_watch_state.json keyed by symbol; the file is
advisory display state, deliberately outside the trades/plans stores.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict

DEFAULTS = {
    "min_minutes_between_cards": 15,
    "reminder_interval_minutes": 60,
    "material_confidence_change": 10.0,
    "resend_on_supporter_change": True,
    # Flap guard (operator 2026-08-17c): a book hovering around the 65 bar
    # de-qualifies for one cycle and re-qualifies the next; clearing state
    # immediately made every return a NEW card (live: WTI cleared 22:01,
    # NEW 22:21, cleared 22:26, NEW 22:31). The state now survives a grace
    # window after de-qualification; a return inside it is a continuation.
    "clear_grace_minutes": 20,
}


def throttle_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Operator knobs under session_plan_delivery.monitoring_only."""
    mo = ((config.get("session_plan_delivery") or {}).get("monitoring_only") or {})
    raw = mo.get("agent_watch_throttle") or {}
    cfg = dict(DEFAULTS)
    if isinstance(raw, dict):
        for key in DEFAULTS:
            if key in raw:
                cfg[key] = raw[key]
    return cfg


def state_path(root: Path | None = None) -> Path:
    base = root or Path(__file__).resolve().parents[1]
    return base / "storage" / "agent_watch_state.json"


def load_states(path: Path) -> Dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:  # noqa: BLE001 - missing/corrupt state means "no watch"
        return {}


def save_states(path: Path, states: Dict[str, Any]) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(states, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(path)
    except Exception:  # noqa: BLE001 - display state must never break a cycle
        pass


def decide(
    prev: Dict[str, Any] | None,
    *,
    side: str,
    supporters: list,
    confidence: float,
    cfg: Dict[str, Any],
    now: float | None = None,
) -> Dict[str, Any]:
    """Return {"send": bool, "kind": str|None, "state": dict}.

    ``prev`` is the stored per-symbol state (None = no active watch).
    ``kind`` is one of NEW/FLIP/SUPPORTERS/CONFIDENCE/REMINDER when sending.
    The returned state must be persisted by the caller WHEN send is True;
    when send is False the previous state rides on unchanged (except that
    last_seen is refreshed so expiry logic elsewhere could use it).
    """
    now = time.time() if now is None else now
    supporters = sorted(str(s) for s in (supporters or []))
    floor_s = float(cfg.get("min_minutes_between_cards", 15)) * 60.0
    reminder_s = float(cfg.get("reminder_interval_minutes", 60)) * 60.0
    material = float(cfg.get("material_confidence_change", 10.0))
    on_supporters = bool(cfg.get("resend_on_supporter_change", True))

    fresh = {
        "side": str(side).upper(),
        "supporters": supporters,
        "confidence": float(confidence),
        "last_card_at": now,
        "last_card_confidence": float(confidence),
        "first_seen": now,
        "last_seen": now,
    }

    if not isinstance(prev, dict) or not prev:
        return {"send": True, "kind": "NEW", "state": fresh}

    fresh["first_seen"] = float(prev.get("first_seen") or now)
    since_card = now - float(prev.get("last_card_at") or 0.0)

    if str(prev.get("side") or "").upper() != fresh["side"]:
        # A reversal is the one change that must never wait out a cooldown.
        return {"send": True, "kind": "FLIP", "state": fresh}

    kind = None
    if on_supporters and sorted(prev.get("supporters") or []) != supporters:
        kind = "SUPPORTERS"
    elif abs(float(confidence) - float(prev.get("last_card_confidence") or 0.0)) >= material:
        kind = "CONFIDENCE"
    elif reminder_s > 0 and since_card >= reminder_s:
        kind = "REMINDER"

    if kind and (since_card >= floor_s or kind == "REMINDER"):
        return {"send": True, "kind": kind, "state": fresh}

    carried = dict(prev)
    carried["last_seen"] = now
    carried["side"] = fresh["side"]
    carried["supporters"] = supporters
    carried["confidence"] = float(confidence)
    return {"send": False, "kind": None, "state": carried}


def should_clear(prev: Dict[str, Any] | None, cfg: Dict[str, Any],
                 now: float | None = None) -> bool:
    """May a de-qualified watch state be forgotten yet?

    Returns True only after clear_grace_minutes have passed since the state
    last SAW a qualifying book (last_seen). Inside the window the state is
    kept so a flapping book that returns is a continuation, not a NEW card.
    """
    if not isinstance(prev, dict) or not prev:
        return True
    now = time.time() if now is None else now
    grace_s = float(cfg.get("clear_grace_minutes", 20)) * 60.0
    if grace_s <= 0:
        return True
    return (now - float(prev.get("last_seen") or 0.0)) >= grace_s
