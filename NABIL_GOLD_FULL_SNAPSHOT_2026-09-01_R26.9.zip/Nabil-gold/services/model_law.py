# -*- coding: utf-8 -*-
"""R25.12: THE single source of the Gemini model law (operator 2026-08-28).

Every consumer imports from here - the review-service defaults, both live
probes, the config-consistency checks and the tree lint. A retired model id
can never re-enter the system by construction: ALLOWED_MODELS is the whole
permitted universe, and tests/test_no_retired_tokens.py enforces it
tree-wide on every suite run.
"""
from __future__ import annotations

#: The operator's production chain, in failover order.
PRIMARY_MODEL = "gemini-3.1-flash-lite"          # ~500/day (live-probed)
FALLBACK_MODELS = (
    "gemini-3.5-flash-lite",                     # ~500/day
    "gemini-3.6-flash",                          # ~20/day
    "gemini-3.5-flash",                          # ~20/day
)
PRODUCTION_CHAIN = (PRIMARY_MODEL,) + FALLBACK_MODELS

#: The entire permitted universe of model ids anywhere in the system.
ALLOWED_MODELS = frozenset(PRODUCTION_CHAIN)


#: The ONLY files allowed to spell retired ids (they BUILD the patterns
#: that forbid them). Both the lint test and the packaging tool exempt
#: exactly these relative paths - one list, imported by both.
ENFORCEMENT_FILES = (
    "tests/test_no_retired_tokens.py",
    "tests/test_build_package_tool.py",
    "scripts/build_package.py",
)


def is_allowed(model) -> bool:
    """True only for configured-chain ids; anything else is legacy."""
    return str(model or "").strip() in ALLOWED_MODELS


DESCRIPTION_AR = (
    "قانون الموديلات (أمر المشغل 2026-08-28): السلسلة = "
    "gemini-3.1-flash-lite (500/يوم) -> gemini-3.5-flash-lite (500/يوم) -> "
    "gemini-3.6-flash (20/يوم) -> gemini-3.5-flash (20/يوم). "
    "لا إرث — المصدر الوحيد services/model_law.py."
)
