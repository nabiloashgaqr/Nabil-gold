# -*- coding: utf-8 -*-
"""R19-A (2026-08-27): ONE post-news digest per EVENT, covering all pairs.

Operator report 2026-08-27: a single Unemployment Claims release produced
SIX near-identical Telegram cards (one per instrument) because the post-news
checker runs per symbol and its dedup key was symbol-scoped. Worse, the
forex cards spoke about GOLD (the single-symbol persona falls back to gold
for every non-WTI symbol) and the USD/JPY card quoted invented gold levels
($2335/$2315 - gold trades near 4600) because non-gold payloads carry no
gold price at all.

This module renders the replacement card: one event header, one row per
instrument in the canonical watchlist order (missing rows shown as N/A so
coverage gaps stay visible), one shared key insight, ONE notice block.
Pure functions only - no IO, no config, never raises on bad data.

File is ASCII by policy: emoji reach Telegram through \\u escapes.
"""
from __future__ import annotations

import html
from typing import Any, Dict, Iterable, List

# Canonical watchlist order for the digest rows; unknown symbols are
# appended after these in the order the model returned them.
SYMBOL_ORDER = ("XAU/USD", "WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")

_SEPARATOR = "\u2501" * 21  # heavy box drawing dash

_IMPACT_EMOJI = {
    "BULLISH": "\U0001F7E2",  # green circle
    "BEARISH": "\U0001F534",  # red circle
    "NEUTRAL": "\U0001F7E1",  # yellow circle
}
_SURPRISE_EMOJI = {
    "BETTER": "\U0001F4C8",   # chart upwards
    "WORSE": "\U0001F4C9",    # chart downwards
    "IN_LINE": "\u2796",      # heavy minus
}
_MISSING_EMOJI = "\u26AA"     # white circle
_BULB = "\U0001F4A1"          # electric bulb
_KEY = "\U0001F511"           # key
_NEWS = "\U0001F4F0"          # newspaper
_WARN = "\u26A0\uFE0F"        # warning sign


def digest_event_key(bucket: str) -> str:
    """Symbol-free dedup key: ONE card per event release bucket.

    The legacy key was f"{symbol}_{bucket}" - six symbols produced six
    near-identical cards for the same release. This key is identical for
    every instrument, so the first instrument cycle after the release sends
    the single digest and every later cycle (any symbol) is silent.
    """
    return "ALL::{0}".format(str(bucket or "").strip())


def _norm(symbol: Any) -> str:
    return str(symbol or "").replace(" ", "").upper()


def render_post_news_digest(
    event_name: str,
    pairs: Iterable[Dict[str, Any]],
    requested_symbols: Iterable[str] = (),
    global_insight: str = "",
    surprise: str = "",
) -> str:
    """Build the ONE-card digest (Telegram HTML). Never raises on data.

    pairs: the model's per-instrument analyses; requested_symbols: the
    instruments the digest was built for - a requested pair with no model
    line renders as N/A instead of disappearing silently.
    """
    by_symbol: Dict[str, Dict[str, Any]] = {}
    for row in (pairs or []):
        if isinstance(row, dict) and _norm(row.get("symbol")):
            by_symbol[_norm(row.get("symbol"))] = row
    ordered: List[str] = []
    for sym in list(SYMBOL_ORDER) + list(requested_symbols or []):
        key = _norm(sym)
        if key and key not in ordered:
            ordered.append(key)
    for key in by_symbol:
        if key not in ordered:
            ordered.append(key)

    lines = [
        "{0} <b>Post-News Digest - {1}</b>".format(
            _NEWS, html.escape(str(event_name or "Economic Event"))),
        _SEPARATOR,
    ]
    surprise_txt = str(surprise or "").upper()
    if surprise_txt:
        lines.append("{0} <b>Surprise:</b> {1}".format(
            _SURPRISE_EMOJI.get(surprise_txt, _MISSING_EMOJI), surprise_txt))
        lines.append(_SEPARATOR)
    lines.append("<b>Impact by pair</b>")
    for key in ordered:
        row = by_symbol.get(key)
        sym = str((row or {}).get("symbol") or key)
        if not row:
            lines.append("{0} <b>{1}</b> - N/A (no model line)".format(
                _MISSING_EMOJI, html.escape(sym)))
            continue
        impact = str(row.get("impact") or row.get("gold_impact")
                     or row.get("oil_impact") or "N/A").upper()
        conf = row.get("confidence")
        conf_txt = (" \u00b7 conf {0}%".format(conf)
                    if conf not in (None, "") else "")
        lines.append("{0} <b>{1}</b> - {2}{3}".format(
            _IMPACT_EMOJI.get(impact, _MISSING_EMOJI), html.escape(sym),
            impact, conf_txt))
        rec = str(row.get("recommendation") or "").strip()
        if rec:
            lines.append("{0} {1}".format(_BULB, html.escape(rec)))
    insight = str(global_insight or "").strip()
    if insight:
        lines.append("")
        lines.append("{0} <b>Key Insight:</b> {1}".format(
            _KEY, html.escape(insight)))
    lines.append("")
    lines.append("{0} NOTICE {0}".format(_WARN))
    lines.append("This is an <b>observation</b>, NOT an entry signal.")
    lines.append("Wait for full 3-agent consensus for any trade.")
    lines.append(_SEPARATOR)
    return "\n".join(lines)
