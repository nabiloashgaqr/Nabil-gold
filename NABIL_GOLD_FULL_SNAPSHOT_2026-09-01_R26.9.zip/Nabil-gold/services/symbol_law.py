# -*- coding: utf-8 -*-
"""R25.12: the single accessor for the symbol table (config.json).

The operator's config owns the instruments (symbol, category, point size,
sessions, per-symbol factors). THIS module is the one way code asks about
them - so "is this gold?", "which symbols are forex?" has exactly one
implementation and zero per-symbol if-branches.

The companion lint (tests/test_no_symbol_branches.py) freezes the existing
count of hard-coded symbol literals inside production code and refuses any
growth; new code must ask here instead.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]

#: Canonical symbol ids (the config instruments table is the store; these
#: constants exist only for tests and error messages to reference).
GOLD = "XAU/USD"
OIL = "WTI/USD"
FOREX_PAIRS = ("EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")

_CACHE: Dict[str, Any] | None = None


def load_instruments() -> List[Dict[str, Any]]:
    """The operator's instruments table, verbatim from config.json."""
    global _CACHE
    if _CACHE is None:
        cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
        _CACHE = list(cfg.get("instruments") or [])
    return _CACHE


def category_of(symbol: str) -> str:
    """'metal' | 'oil' | 'forex' as configured; '' when unknown."""
    for inst in load_instruments():
        if str(inst.get("symbol") or "").upper() == str(symbol or "").upper():
            return str(inst.get("category") or "")
    return ""


def is_gold(symbol: str) -> bool:
    return str(symbol or "").upper() == GOLD


def is_oil(symbol: str) -> bool:
    return str(symbol or "").upper() == OIL


def is_forex(symbol: str) -> bool:
    return category_of(symbol) == "forex"


def all_symbols() -> List[str]:
    return [str(i.get("symbol")) for i in load_instruments() if i.get("symbol")]


def macro_symbols(config: Dict[str, Any] | None = None) -> List[str]:
    """The macro-confirmation symbol list (config is the store)."""
    if config is None:
        try:
            config = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001 - never break a caller on a read
            return []
    sig = (config or {}).get("signal_requirements") or {}
    two = (sig.get("two_agent_entry") or {})
    macro = (two.get("macro_confirmation") or {})
    return list(macro.get("symbols") or [])
