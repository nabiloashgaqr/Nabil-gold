"""
services/risk_analytics.py — Portfolio risk analytics: VaR, CVaR, ratios,
dollar-based daily loss limit. (2026-08-19 upgrade)

Problem (evidence):
  - agents/risk_management_agent.py sizes positions as fixed-fraction % of
    capital only. No Kelly/Optimal-f, no volatility targeting.
  - Daily loss limit is POINTS-based (450 pts gold) — its dollar value silently
    changes when lots or capital change. Capital protection must be
    currency-based.
  - No VaR/CVaR, no MAE/MFE measurement (the standard institutional exit-quality
    diagnostics) and no Sharpe/Sortino/Calmar anywhere.

Integration:
  - services/dynamic_risk.py: dollar daily-loss check (additive; enabled only
    when config risk_settings.max_daily_loss_percent > 0).
  - scripts/run_risk_analytics.py: standalone CLI producing
    storage/risk_analytics_report.json from closed trades.

Tests: tests/test_dollar_daily_limit.py + upgrades-independent unit tests.
"""
from __future__ import annotations

import math
from typing import Any, Dict, List

import numpy as np


# ── daily loss limit (dollar-based) ───────────────────────────────────────────
GOLD_POINTS_PER_DOLLAR_PER_LOT = 10.0   # 1 lot = 100 oz, $1 move = $10 -> $10/point
WTI_POINTS_PER_DOLLAR_PER_LOT = 10.0    # 1 lot = 1,000 bbl, $0.01 move = $10 -> $10/point
FOREX_VALUE_PER_POINT_PER_LOT = 1.0     # 1 lot = 100k units, 1 point = 0.00001 -> $1/lot


def _trade_dollar_pnl(trade: Dict[str, Any]) -> float | None:
    """Best-effort dollar PnL for one closed trade. None when not derivable."""
    for key in ("final_pnl_usd", "profit_usd", "pnl_usd"):
        v = trade.get(key)
        if isinstance(v, (int, float)):
            return float(v)
    pnl_points = None
    for key in ("final_pnl", "current_pnl", "pnl", "current_pnl_points"):
        v = trade.get(key)
        if isinstance(v, (int, float)):
            pnl_points = float(v)
            break
    if pnl_points is None:
        return None
    symbol = str(trade.get("symbol") or "")
    value_per_point = (
        WTI_POINTS_PER_DOLLAR_PER_LOT if "WTI" in symbol.upper()
        else GOLD_POINTS_PER_DOLLAR_PER_LOT
    )
    lots = None
    for key in ("lots", "volume"):
        v = trade.get(key)
        if isinstance(v, (int, float)):
            lots = float(v)
            break
    if lots is None:
        ps = trade.get("position_size") or {}
        if isinstance(ps, dict):
            v = ps.get("recommended_lots")
            if isinstance(v, (int, float)):
                lots = float(v)
    if lots is None:
        return None  # points-only trade: dollar value unknown, never guess
    return pnl_points * value_per_point * lots


def dollar_daily_limit(trades: List[Dict[str, Any]], config: Dict[str, Any]) -> Dict[str, Any]:
    """Currency-based daily loss limit verdict (HALT/STRICT/NORMAL/DISABLED).

    trades: closed-today trade rows (as returned by database.get_today_trades()).
    Falls back to DISABLED when max_daily_loss_percent <= 0, with the legacy
    points limit untouched — the mechanism ships safe and the operator enables
    it explicitly.
    """
    settings = config.get("risk_settings", {}) or {}
    capital = float(settings.get("account_capital", 10_000) or 10_000)
    pct = float(settings.get("max_daily_loss_percent", 0.0) or 0.0)
    if pct <= 0:
        return {"mode": "DISABLED", "reason": "max_daily_loss_percent not set (>0 enables)"}

    daily_pnl = 0.0
    priced = 0
    unpriced = 0
    for t in trades:
        usd = _trade_dollar_pnl(t)
        if usd is None:
            unpriced += 1
            continue
        daily_pnl += usd
        priced += 1

    limit_usd = capital * pct / 100.0
    level = "HALT" if daily_pnl <= -limit_usd else ("STRICT" if daily_pnl <= -0.5 * limit_usd else "NORMAL")
    return {
        "mode": "DOLLARS",
        "limit_dollars": round(limit_usd, 2),
        "daily_pnl_usd": round(daily_pnl, 2),
        "priced_trades": priced,
        "unpriced_trades": unpriced,
        "level": level,
        "capital": capital,
        "pct": pct,
        "note": "points-only trades skipped (no lots/profit-usd stored); never estimated",
    }



class RiskAnalytics:
    """Historical + parametric VaR / CVaR and equity-curve ratios."""

    def __init__(self, equity_points: List[float]):
        self.equity = np.asarray(equity_points, dtype=float)

    def returns(self) -> np.ndarray:
        e = self.equity
        return np.diff(e) / np.where(e[:-1] == 0, np.nan, e[:-1])

    def historical_var_cvar(self, level: float = 0.95) -> Dict[str, float]:
        r = self.returns()
        r = r[np.isfinite(r)]
        if len(r) < 20:
            return {"var": 0.0, "cvar": 0.0, "n": int(len(r))}
        var = float(-np.quantile(r, 1 - level))
        tail = r[r <= -var]
        cvar = float(-tail.mean()) if len(tail) else var
        return {"var": round(var, 5), "cvar": round(cvar, 5), "n": int(len(r))}

    def parametric_var(self, level: float = 0.95) -> float:
        r = self.returns()
        r = r[np.isfinite(r)]
        if len(r) < 20 or r.std() == 0:
            return 0.0
        try:
            from scipy.stats import norm as _norm  # optional dependency

            z = float(_norm.ppf(level))
        except Exception:  # noqa: BLE001 — degrade to the standard normal quantile
            z = 1.645
        return float(-(r.mean() + z * r.std()))

    def sharpe(self, risk_free_annual: float = 0.04, periods_per_year: int = 252) -> float:
        r = self.returns()
        r = r[np.isfinite(r)]
        if len(r) < 10 or r.std() == 0:
            return 0.0
        rf_daily = risk_free_annual / periods_per_year
        return float((r.mean() - rf_daily) / r.std() * math.sqrt(periods_per_year))

    def sortino(self, risk_free_annual: float = 0.04, periods_per_year: int = 252) -> float:
        r = self.returns()
        r = r[np.isfinite(r)]
        if len(r) < 10:
            return 0.0
        rf_daily = risk_free_annual / periods_per_year
        downside = r[r < 0]
        if len(downside) == 0 or downside.std() == 0:
            return 0.0
        return float((r.mean() - rf_daily) / downside.std() * math.sqrt(periods_per_year))

    def calmar(self, periods_per_year: int = 252) -> float:
        r = self.returns()
        r = r[np.isfinite(r)]
        if len(r) < 10:
            return 0.0
        annual_return = r.mean() * periods_per_year
        peak = np.maximum.accumulate(self.equity)
        dd = (self.equity - peak) / np.where(peak == 0, np.nan, peak)
        max_dd = float(np.nanmin(dd)) if len(dd) else 0.0
        if max_dd == 0:
            return 0.0
        return float(annual_return / abs(max_dd))


def mae_mfe_stats(trades: List[Dict[str, Any]]) -> Dict[str, Any]:
    """MAE/MFE per trade from recorded max adverse/favorable excursion (in R multiples).

    Each trade row needs keys added at close time by open_trades_manager:
      mae_r  = max distance against position / initial stop distance (negative)
      mfe_r  = max distance in favour / initial stop distance (positive)
    """
    mae, mfe = [], []
    for t in trades:
        for key, sink in (("mae_r", mae), ("mfe_r", mfe)):
            v = t.get(key)
            if isinstance(v, (int, float)):
                sink.append(float(v))
    if not mae:
        return {"n": 0}
    return {
        "n": len(mae),
        "median_mae_r": round(float(np.median(mae)), 2),
        "p90_mae_r": round(float(np.quantile(mae, 0.10)), 2),   # 90% of trades stay above
        "median_mfe_r": round(float(np.median(mfe)), 2),
        "p90_mfe_r": round(float(np.quantile(mfe, 0.90)), 2),
    }
