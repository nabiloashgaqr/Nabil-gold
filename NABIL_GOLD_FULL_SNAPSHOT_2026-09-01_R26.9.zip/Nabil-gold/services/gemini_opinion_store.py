"""BUILD 28 R2 (2026-08-22, operator order): Gemini's stored per-symbol opinion.

Operator decision 2026-08-22 (applied on top of BUILD 28):
  * the stored opinion is at most ``stored_opinion_hours`` old - 30 minutes;
  * a NEW opinion is fetched at TRADE ENTRY (forced) and on the HOURLY status
    update (the hourly tick finds the stored read stale -> refresh);
  * every other DISPLAY (signal / plan / trade-management cards) reads the
    store only - never an extra API call (telegram_bot._stored_gemini_opinion);
  * the SAME model chain as before (GeminiReviewService's
    DEFAULT_FALLBACK_MODELS order - no reassignment);
  * it runs the whole trading week - no night shutdown.

The store is the shared file ``storage/llm/gemini_status_cache.json`` (per
symbol keys, same file the hourly status card used since BUILD 24/25).

Fail-open: a missing store, a dead API or a parse failure never breaks a
card; failed refreshes keep the old verdict and are never cached as
verdicts (the attempt clock stops hammering the quota).
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

DEFAULT_TTL_HOURS = 0.5            # 30 minutes (operator decision 2026-08-22)
FORCE_MIN_INTERVAL_SECONDS = 300   # anti-hammer for forced (entry) refreshes


def store_path(config: Dict[str, Any] | None) -> Path:
    """Resolve the shared opinion store (relative paths -> repo root)."""
    llm_cfg = (config or {}).get("llm_review") or {}
    raw = str(llm_cfg.get("status_cache_path")
              or "storage/llm/gemini_status_cache.json")
    p = Path(raw)
    if not p.is_absolute():
        p = Path(__file__).resolve().parents[1] / p
    return p


def ttl_hours(config: Dict[str, Any] | None) -> float:
    """The stored opinion's max age in hours (default 30 minutes)."""
    llm_cfg = (config or {}).get("llm_review") or {}
    try:
        v = float(llm_cfg.get("stored_opinion_hours") or 0.0)
        return v if v > 0 else DEFAULT_TTL_HOURS
    except (TypeError, ValueError):
        return DEFAULT_TTL_HOURS


def _parse_ts(value: Any) -> Optional[datetime]:
    try:
        dt = datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except (TypeError, ValueError):
        return None


def load_store(config: Dict[str, Any] | None) -> Dict[str, Any]:
    """Read the store keyed by symbol; migrates the legacy single-verdict
    file (pre-BUILD 25) under the first symbol that reads it."""
    p = store_path(config)
    if not p.exists():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8") or "{}")
    except Exception:  # noqa: BLE001 - a corrupt store means "no memory"
        return {}
    if not isinstance(data, dict):
        return {}
    if isinstance(data.get("verdict"), dict):
        data = {"_legacy": {
            "verdict": data["verdict"],
            "generated_at": data.get("generated_at"),
            "last_attempt_at": data.get("last_attempt_at"),
        }}
    return data


def _save_store(config: Dict[str, Any] | None, data: Dict[str, Any]) -> None:
    try:
        p = store_path(config)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                     encoding="utf-8")
    except Exception as exc:  # noqa: BLE001 - display must survive
        logger.warning("Gemini opinion store write failed: %s", exc)


def _entry_for(symbol: str, data: Dict[str, Any]) -> Dict[str, Any]:
    entry = data.get(symbol)
    if isinstance(entry, dict):
        return entry
    # legacy single-verdict file: the first symbol reading it claims it
    legacy = data.get("_legacy")
    if isinstance(legacy, dict) and not any(
            isinstance(v, dict) for v in data.values() if v is not legacy):
        return legacy
    return {}


def get_stored(symbol: str, config: Dict[str, Any] | None,
               now: datetime | None = None) -> Tuple[Optional[Dict[str, Any]],
                                                     Optional[float]]:
    """READ-ONLY: the stored verdict for one symbol + its age in hours
    (age is None when nothing was ever generated). No API call."""
    now = now or datetime.now(timezone.utc)
    entry = _entry_for(symbol, load_store(config))
    verdict = entry.get("verdict")
    if not isinstance(verdict, dict):
        return None, None
    gen_at = _parse_ts(entry.get("generated_at"))
    if gen_at is None:
        return verdict, None
    return verdict, (now - gen_at).total_seconds() / 3600.0


def refresh_opinion(symbol: str,
                    config: Dict[str, Any] | None,
                    *,
                    all_results: Dict[str, Any] | None = None,
                    current_price: float = 0.0,
                    force: bool = False,
                    now: datetime | None = None
                    ) -> Tuple[Optional[Dict[str, Any]], bool, Optional[float]]:
    """Return ``(verdict, refreshed, age_h)``.

    * not ``force`` (hourly status): the API is asked only when the stored
      verdict is older than the 30-minute TTL AND the last attempt is older
      than the TTL (a failed attempt is not retried inside its window).
    * ``force`` (trade entry): the API is asked even with a fresh store -
      the entering trade gets a current read - but never more often than
      once per 5 minutes per symbol (two entries minutes apart do not
      double-bill the quota).
    * success stores the new verdict; failure keeps the old one and marks
      ``last_attempt_at`` only (failures are never cached as verdicts).
    """
    now = now or datetime.now(timezone.utc)
    data = load_store(config)
    entry = _entry_for(symbol, data)
    verdict = entry.get("verdict")
    if not isinstance(verdict, dict):
        verdict = None
    gen_at = _parse_ts(entry.get("generated_at"))
    try_at = _parse_ts(entry.get("last_attempt_at"))
    ttl_s = ttl_hours(config) * 3600.0
    age_h = ((now - gen_at).total_seconds() / 3600.0) if gen_at else None
    att_age_s = (now - try_at).total_seconds() if try_at else None

    if not force:
        if age_h is not None and 0 <= age_h <= ttl_hours(config):
            return verdict, False, age_h
        if att_age_s is not None and att_age_s < ttl_s:
            return verdict, False, age_h
    else:
        if att_age_s is not None and att_age_s < FORCE_MIN_INTERVAL_SECONDS:
            return verdict, False, age_h

    try:
        from services.llm_review import get_gemini_review_service
        gemini = get_gemini_review_service(config)
    except Exception as exc:  # noqa: BLE001 - never break the card
        logger.warning("Gemini service unavailable for %s: %s", symbol, exc)
        gemini = None
    # No service (or no API key): there was nothing to attempt - do NOT
    # touch the store (tests must not mark attempts in the live file).
    if gemini is None or not getattr(gemini, "enabled", False):
        return verdict, False, age_h
    try:
        result = gemini.analyze_market_context({
            "symbol": symbol,
            "decision": {"symbol": symbol},
            "all_results": all_results or {},
            "current_price": current_price,
        })
        if (isinstance(result, dict) and result.get("available")
                and not result.get("suppressed")):
            verdict = {
                "bias": result.get("market_bias"),
                "action": result.get("action"),
                "reason": result.get("reason"),
                "model": getattr(gemini, "model", ""),
            }
            data[symbol] = {"verdict": verdict,
                            "generated_at": now.isoformat(),
                            "last_attempt_at": now.isoformat()}
            _save_store(config, data)
            return verdict, True, 0.0
    except Exception as exc:  # noqa: BLE001 - never break the card
        logger.warning("Gemini stored-opinion refresh failed for %s: %s",
                       symbol, exc)

    # No usable verdict from this attempt: keep the old one, mark the
    # attempt so the next window (not every cycle) retries.
    entry = dict(entry)
    entry["last_attempt_at"] = now.isoformat()
    data[symbol] = entry
    _save_store(config, data)
    return verdict, False, age_h
