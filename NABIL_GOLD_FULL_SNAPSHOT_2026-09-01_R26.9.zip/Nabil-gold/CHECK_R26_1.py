#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
R26.1 LIVE SERVER CHECK  (pure stdlib)
Run from C:\\Nabil-gold:   python CHECK_R26_1.py

It reads the EFFECTIVE law the bot actually uses (config.json merged over
utils/instruments.py), verifies every per-symbol value, proves $-risk is held,
and scans for leftovers of the OLD law (230/330/160/70-buffer/x0.4/R25.7-D).
Exit code 0 = all green, 1 = something to look at.
"""
import json, os, re, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

PASS, FAIL = "PASS", "FAIL"
results = []   # (status, label, detail)

def rec(ok, label, detail=""):
    results.append((PASS if ok else FAIL, label, detail))

# ---------------------------------------------------------------- load
from utils.helpers import load_config
from utils.instruments import DEFAULT_INSTRUMENTS, config_for_instrument, enabled_instruments

cfg = load_config()
insts = {i["symbol"]: config_for_instrument(cfg, i) for i in enabled_instruments(cfg)}

GOLD = "XAU/USD"; OIL = "WTI/USD"
FX = ["EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"]

def stop_law(c):
    return (c.get("trading_rules", {}) or {}).get("stop", {}) or {}
def trail_law(c):
    tr = (c.get("trading_rules", {}) or {}).get("trailing", {}) or {}
    if tr:
        return tr.get("distance_points"), tr.get("step_points"), tr.get("early_breakeven_points")
    return c.get("trailing_distance"), c.get("trailing_step"), c.get("early_breakeven_points")
def min_sl(c):
    return (c.get("risk_settings", {}) or {}).get("min_sl_distance_points",
            c.get("min_sl_distance_points"))
def post_tp2(c):
    return ((c.get("trading_rules", {}) or {}).get("post_tp2", {}) or {}).get("min_distance_points")
def planner(c):
    return c.get("session_planner", {}) or {}
def fam_cross(c):
    return (((c.get("signal_requirements", {}) or {}).get("two_agent_entry", {}) or {})
            .get("cross_entry_distance_points"))
def fam_scale(c):
    return (((c.get("order_execution", {}) or {}).get("fixed_risk", {}) or {})
            .get("scale_in_trigger_points"))

# ---------------------------------------------------------------- gold anchors
g = insts.get(GOLD)
if g:
    gl = stop_law(g)
    rec(gl.get("min_liquidity_points") == 200, "GOLD stop liquidity=200", str(gl.get("min_liquidity_points")))
    rec(gl.get("safety_buffer_points") == 70, "GOLD buffer=70", str(gl.get("safety_buffer_points")))
    rec(gl.get("max_stop_points") == 400, "GOLD cap=400", str(gl.get("max_stop_points")))
    rec(min_sl(g) == 400, "GOLD min_sl=400", str(min_sl(g)))
    gt = trail_law(g)
    rec(tuple(gt) == (150, 40, 150), "GOLD trailing 150/40/150", str(gt))
    rec(DEFAULT_INSTRUMENTS[GOLD].get("duplicate_zone_points") == 150, "GOLD family=150",
        str(DEFAULT_INSTRUMENTS[GOLD].get("duplicate_zone_points")))

# ---------------------------------------------------------------- factor proofs
def approx(a, b, tol=1.5):
    try: return abs(float(a) - float(b)) <= tol
    except Exception: return False

if g and OIL in insts:
    w = insts[OIL]; wl = stop_law(w)
    rec(wl.get("min_liquidity_points") == 100, "OIL liquidity=100 (gold 200 x0.5)", str(wl.get("min_liquidity_points")))
    rec(wl.get("safety_buffer_points") == 35, "OIL buffer=35 (gold 70 x0.5)", str(wl.get("safety_buffer_points")))
    rec(wl.get("max_stop_points") == 200, "OIL cap=200 (gold 400 x0.5)", str(wl.get("max_stop_points")))
    floor = (wl.get("min_liquidity_points",0) or 0) + (wl.get("safety_buffer_points",0) or 0)
    rec(floor == 135, "OIL floor=135 (100+35)", str(floor))
    rec(min_sl(w) == 200, "OIL min_sl=200", str(min_sl(w)))
    wt = trail_law(w)
    rec(tuple(wt) == (75, 20, 75), "OIL trailing 75/20/75 (x0.5)", str(wt))
    rec(DEFAULT_INSTRUMENTS[OIL].get("duplicate_zone_points") == 75, "OIL duplicate=75",
        str(DEFAULT_INSTRUMENTS[OIL].get("duplicate_zone_points")))
    rec(fam_cross(w) == 75, "OIL cross=75", str(fam_cross(w)))
    rec(fam_scale(w) == 75, "OIL scale-in=75", str(fam_scale(w)))
    rec(post_tp2(w) == 125, "OIL post-TP2=125 (gold 250 x0.5)", str(post_tp2(w)))
    pw = planner(w)
    rec(pw.get("standby_min_distance_points") == 75, "OIL planner standby=75", str(pw.get("standby_min_distance_points")))
    rec(pw.get("max_primary_zone_width_points") == 225, "OIL planner zone=225", str(pw.get("max_primary_zone_width_points")))
    rec(pw.get("min_entry_zone_width_points") == 30, "OIL planner entry=30", str(pw.get("min_entry_zone_width_points")))

for s in FX:
    c = insts.get(s)
    if not c:
        rec(False, f"{s} present/enabled", "MISSING"); continue
    sl = stop_law(c)
    rec(sl.get("min_liquidity_points") == 450, f"{s} FX liquidity=450", str(sl.get("min_liquidity_points")))
    rec(sl.get("safety_buffer_points") == 150, f"{s} FX buffer=150", str(sl.get("safety_buffer_points")))
    rec(sl.get("max_stop_points") == 900, f"{s} FX cap=900 (90 pips)", str(sl.get("max_stop_points")))
    floor = (sl.get("min_liquidity_points",0) or 0) + (sl.get("safety_buffer_points",0) or 0)
    rec(floor == 600, f"{s} FX floor=600 (60 pips)", str(floor))
    rec(min_sl(c) == 900, f"{s} FX min_sl=900", str(min_sl(c)))
    t = trail_law(c)
    rec(tuple(t) == (340, 90, 340), f"{s} FX trailing 340/90/340", str(t))
    rec(DEFAULT_INSTRUMENTS[s].get("duplicate_zone_points") == 340, f"{s} FX duplicate=340",
        str(DEFAULT_INSTRUMENTS[s].get("duplicate_zone_points")))
    rec(post_tp2(c) == 560, f"{s} FX post-TP2=560", str(post_tp2(c)))

# ---------------------------------------------------------------- $-risk constant
try:
    from services.risk_usd import lot_for_stop, usd_per_point
    prices = {GOLD:4650.0, OIL:75.0, "EUR/USD":1.085, "GBP/USD":1.275, "USD/CAD":1.365, "USD/JPY":155.2}
    for s, c in insts.items():
        sl = stop_law(c)
        lo = (sl.get("min_liquidity_points",0) or 0)+(sl.get("safety_buffer_points",0) or 0)
        hi = sl.get("max_stop_points", 0) or 0
        px = prices.get(s)
        worst = 0.0
        for pts in (lo, hi):
            if not pts: continue
            lot = lot_for_stop(s, pts, config=c, risk_usd=270, quote_price=px)
            loss = lot * usd_per_point(s, 1.0, px) * pts
            worst = max(worst, loss)
        rec(270-1 <= worst <= 290, f"{s} solved stop loss in $270-290", f"max ~${worst:.2f}")
except Exception as e:
    rec(False, "$-risk lot solver importable", repr(e))

# ---------------------------------------------------------------- remnant scan
def read(rel):
    p = os.path.join(ROOT, rel)
    return open(p, encoding="utf-8").read() if os.path.exists(p) else ""

remnants = []
cfg_txt = read("config.json")
for pat in ["min_sl_distance_note", "R25.7-D", "230,330", "[230,330]"]:
    if pat in cfg_txt:
        remnants.append(f"config.json contains stale marker: {pat!r}")
# any live min_sl still old?
try:
    raw = json.loads(cfg_txt)
    for e in raw.get("instruments", []):
        if isinstance(e, dict) and e.get("min_sl_distance_points") in (230, 160, 330):
            remnants.append(f"config.json {e.get('symbol')} min_sl still {e.get('min_sl_distance_points')}")
        if isinstance(e, dict) and "min_sl_distance_note" in e:
            remnants.append(f"config.json {e.get('symbol')} still has min_sl_distance_note")
except Exception as e:
    remnants.append(f"config.json parse issue: {e}")

spec_txt = read(os.path.join("deploy", "config_merge.json"))
for pat in ['"max_stop_points": 160', '"min_sl_distance_points": 160',
            '"distance_points": 60', '"standby_min_distance_points": 60',
            '"max_primary_zone_width_points": 180', 'x0.4', 'x 0.4', '0.4 حسابيا']:
    if pat in spec_txt:
        remnants.append(f"deploy/config_merge.json still carries old-law value: {pat!r}")

inst_txt = read(os.path.join("utils", "instruments.py"))
# isolate the WTI block to avoid flagging gold's legitimate 400/150
m = re.search(r'"WTI/USD"\s*:\s*\{(.*?)\n        \},', inst_txt, re.S)
wti_block = m.group(1) if m else ""
for pat, label in [(r'\b330\b', '330 (old oil cap)'), (r'\b160\b', '160 (old oil noise)'),
                   (r'\b230\b', '230 (old floor)'), (r'0\.4', '0.4 (old oil factor)'),
                   (r'\b60\b(?![0-9])', '60 (old oil family)')]:
    if re.search(pat, wti_block):
        remnants.append(f"utils/instruments.py WTI block still references {label}")

# FX blocks must not carry 330/230 stops
for s in FX:
    mm = re.search(r'"%s"\s*:\s*\{(.*?)\n        \},' % re.escape(s), inst_txt, re.S)
    blk = mm.group(1) if mm else ""
    if re.search(r'"max_stop_points"\s*:\s*(330|230)\b', blk) or re.search(r'"min_liquidity_points"\s*:\s*160\b', blk):
        remnants.append(f"utils/instruments.py {s} block still on old 160/330 law")

rec(not remnants, "No old-law remnants in live files", " ; ".join(remnants) if remnants else "clean")

# ---------------------------------------------------------------- report
print("="*64)
print("  R26.1 LIVE SERVER CHECK")
print("  root:", ROOT)
print("="*64)
npass = sum(1 for r in results if r[0] == PASS)
nfail = sum(1 for r in results if r[0] == FAIL)
for st, label, detail in results:
    mark = "[ OK ]" if st == PASS else "[FAIL]"
    line = f"  {mark} {label}"
    if st == FAIL and detail:
        line += f"   -> {detail}"
    print(line)
print("-"*64)
print(f"  TOTAL: {npass} pass, {nfail} fail")
if remnants:
    print("\n  REMNANTS FOUND:")
    for r in remnants:
        print("   -", r)
print("="*64)
print("  RESULT:", "ALL GREEN - R26.1 fully applied, no old-law leftovers."
      if nfail == 0 else f"{nfail} item(s) need attention (see [FAIL] above).")
sys.exit(0 if nfail == 0 else 1)
