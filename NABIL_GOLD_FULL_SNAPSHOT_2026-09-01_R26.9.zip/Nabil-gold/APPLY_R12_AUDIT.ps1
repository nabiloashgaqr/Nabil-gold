# =====================================================================
# BUILD31-R12 : install the trade audit tool (LOCAL-ONLY, no cloud)
# Copy APPLY_R12_AUDIT.ps1 + Nabil-gold-R12-AUDIT-TOOL-*.zip into
# C:\Nabil-gold  then run:  powershell -NoProfile -ExecutionPolicy Bypass -File .\APPLY_R12_AUDIT.ps1
# =====================================================================
$ErrorActionPreference = "Stop"
$root = "C:\Nabil-gold"
if (-not (Test-Path $root)) { throw "Project root not found: $root" }
Set-Location $root

$zip = Get-ChildItem -Path $root -Filter "Nabil-gold-R12-AUDIT-TOOL-*.zip" |
       Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $zip) { throw "No Nabil-gold-R12-AUDIT-TOOL-*.zip found in $root" }
Write-Host "[1/3] Found package: $($zip.Name)"

$tmp = Join-Path $env:TEMP ("R12_AUDIT_" + [guid]::NewGuid().ToString("N").Substring(0,8))
Expand-Archive -Path $zip.FullName -DestinationPath $tmp -Force

# -- copy payload -----------------------------------------------------
$map = @(
    @{ src = "audit_recent_trades.py";            dst = "scripts\audit_recent_trades.py" },
    @{ src = "RUN_TRADE_AUDIT.bat";               dst = "RUN_TRADE_AUDIT.bat" },
    @{ src = "test_audit_recent_trades_tool.py";  dst = "tests\test_audit_recent_trades_tool.py" }
)
foreach ($m in $map) {
    $s = Join-Path $tmp $m.src
    $d = Join-Path $root $m.dst
    $ddir = Split-Path $d -Parent
    if (-not (Test-Path $ddir)) { New-Item -ItemType Directory -Path $ddir | Out-Null }
    Copy-Item -Path $s -Destination $d -Force
    Write-Host ("      installed: " + $m.dst)
}

# -- verify -----------------------------------------------------------
Write-Host "[2/3] Verifying..."
$py = Join-Path $root "scripts\audit_recent_trades.py"
$compiled = & python -m py_compile $py 2>&1
if ($LASTEXITCODE -ne 0) { throw "py_compile failed: $compiled" }
$probe = & python $py --help 2>&1
if ($LASTEXITCODE -ne 0) { throw "audit tool --help failed" }
$t = & python -m pytest (Join-Path $root "tests\test_audit_recent_trades_tool.py") -q -p no:cacheprovider 2>&1
Write-Host $t[-1]

Remove-Item -Recurse -Force $tmp
Write-Host "[3/3] DONE. Run the audit with:  python scripts\audit_recent_trades.py --days 2"
Write-Host "      or double-click  RUN_TRADE_AUDIT.bat"
