#!/usr/bin/env python3
"""R26.1 per-symbol point/stop harmonization applier.

DESIGNED NOT TO BREAK THE LIVE VPS:
  * NEVER replaces config.json. The live config (tokens, auction_flow,
    EIA files, symbol notes) is preserved. config.json is only PATCHED in
    place by the idempotent deploy/config_merge.json spec.
  * backs up every replaced file into _backup_R26_1/<timestamp>/
  * copies the code default  : utils/instruments.py
  * copies the merge spec    : deploy/config_merge.json
  * runs  deploy/apply_config_merge.py  to repair min_sl + the oil law
  * removes the stale min_sl_distance_note keys
  * prints a post-merge verification (per-symbol min_sl)

Run from C:\\Nabil-gold:  python APPLY_R26_1_harmonization.py
(or just double-click APPLY_R26_1.bat). Idempotent.
"""
from __future__ import annotations
import argparse, json, os, shutil, subprocess, sys, time

_script = os.path.dirname(os.path.abspath(__file__))

# Code files copied verbatim. config.json is DELIBERATELY absent:
# it is patched, never replaced.
COPY = [
    "utils/instruments.py",
    "deploy/config_merge.json",
    "deploy/apply_config_merge.py",
]

SYMBOLS = ["XAU/USD", "WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"]
EXPECT_MIN_SL = {"XAU/USD": 400, "WTI/USD": 200,
                 "EUR/USD": 900, "GBP/USD": 900, "USD/CAD": 900, "USD/JPY": 900}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", default=_script,
                    help="project root to patch (default: this script's folder)")
    ap.add_argument("--payload", default=None,
                    help="payload folder (default: <target>/R26_1_HARMONIZATION)")
    args = ap.parse_args()

    def _clean(p: str) -> str:
        # guard against any stray quote/backslash a cmd.exe argument may carry
        return os.path.abspath(p.strip().strip('"').rstrip("\\"))

    HERE = _clean(args.target)
    STAGE = _clean(args.payload or os.path.join(HERE, "R26_1_HARMONIZATION"))
    BACKUP = os.path.join(HERE, "_backup_R26_1")

    os.chdir(HERE)
    if not os.path.isdir(STAGE):
        print("ERROR: payload folder R26_1_HARMONIZATION not found.")
        print("       expected:", STAGE)
        print("       Make sure you extracted the WHOLE zip into C:\\Nabil-gold")
        return 2

    stamp = time.strftime("%Y%m%d_%H%M%S")
    bak = os.path.join(BACKUP, stamp)
    os.makedirs(bak, exist_ok=True)

    print("== R26.1 harmonization applier ==")
    for rel in COPY:
        src_pkg = os.path.join(STAGE, rel)
        dst = os.path.join(HERE, rel)
        if not os.path.exists(src_pkg):
            print(f"  ! payload missing {rel} - skipping")
            continue
        if os.path.exists(dst):
            b = os.path.join(bak, rel)
            os.makedirs(os.path.dirname(b), exist_ok=True)
            shutil.copy2(dst, b)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src_pkg, dst)
        print(f"  copied {rel}")

    # refresh the FULL tests/ tree so the on-VPS suite matches the new law
    # (tests never affect live trading; they are the integrity gate).
    src_tests = os.path.join(STAGE, "tests")
    dst_tests = os.path.join(HERE, "tests")
    n = 0
    if os.path.isdir(src_tests):
        for root, _dirs, files in os.walk(src_tests):
            for name in files:
                if not name.endswith(".py"):
                    continue
                rel = os.path.relpath(os.path.join(root, name), src_tests)
                tdst = os.path.join(dst_tests, rel)
                os.makedirs(os.path.dirname(tdst), exist_ok=True)
                shutil.copy2(os.path.join(root, name), tdst)
                n += 1
        print(f"  tests refreshed ({n} files)")

    # PATCH config.json in place (idempotent; never replaced)
    spec = os.path.join(HERE, "deploy", "config_merge.json")
    cfg = os.path.join(HERE, "config.json")
    if not os.path.exists(cfg):
        print("ERROR: config.json not found in", HERE)
        return 2
    shutil.copy2(cfg, os.path.join(bak, "config.json"))   # backup live config
    r = subprocess.run([sys.executable, "deploy/apply_config_merge.py",
                        "--config", cfg, "--spec", spec],
                       capture_output=True, text=True)
    print("  merge:", (r.stdout.strip() or r.stderr.strip()))
    if r.returncode != 0:
        print("MERGE FAILED - config untouched, backup at", bak)
        return r.returncode

    # post-merge verification
    print("== post-merge verification (min_sl_distance_points) ==")
    data = json.load(open(cfg, encoding="utf-8"))
    ent = {e["symbol"]: e for e in data.get("instruments", [])
           if isinstance(e, dict) and e.get("symbol")}
    ok = True
    for sym in SYMBOLS:
        e = ent.get(sym)
        got = e.get("min_sl_distance_points") if e else None
        note = "note" if e and "min_sl_distance_note" in e else ""
        want = EXPECT_MIN_SL[sym]
        good = (got == want) and not note
        ok &= good
        print(f"  {sym:9} min_sl={got}  (want {want})  {note}  {'OK' if good else 'MISMATCH'}")
    if not ok:
        print("VERIFICATION MISMATCH - see above (backup at", bak, ")")
        return 1

    print("\nAll files applied and config.json verified.")
    print("Backup of replaced files + config.json:", bak)
    print("Optional full self-test :  python -m pytest tests/ -q")
    return 0


if __name__ == "__main__":
    sys.exit(main())
