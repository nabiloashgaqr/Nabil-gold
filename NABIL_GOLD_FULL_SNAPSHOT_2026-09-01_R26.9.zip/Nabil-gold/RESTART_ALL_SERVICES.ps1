# =====================================================================
# Nabil-gold R14 : RESTART SERVICES + VERIFY ALL 6 PAIRS (LOCAL-ONLY)
#
# WHY: the code already supports all 6 pairs (run_analysis loops
# enabled_instruments; the tick manager collects aux ticks for every
# enabled symbol). But Python loads code at STARTUP: services started
# days ago still run the OLD code in memory. Evidence (2026-08-27):
#   * gold tick store  : 31k ticks/5m, heartbeat 2.8s  -> process alive
#   * WTI+forex stores : tick age inf, heartbeat inf   -> aux loop never ran
#   * decision_audit   : XAU 50 rows / 7d, forex ZERO  -> forex never cycled
# Restarting re-reads the NEW tree: aux collectors initialize, forex
# analysis cycles start, and the R13 spread caps take effect.
#
# RUN: extract the package, then (as Administrator ideally):
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\RESTART_ALL_SERVICES.ps1
# or double-click RESTART_ALL_SERVICES.bat
# =====================================================================
$ErrorActionPreference = "Continue"
$root = "C:\Nabil-gold"
if (-not (Test-Path $root)) { throw "Project root not found: $root" }
Set-Location $root

Write-Host "==============================================================="
Write-Host " R14: restart tick manager + analysis loops, then verify"
Write-Host "==============================================================="

# -- 1. show the current python workers -------------------------------
Write-Host "[1/5] Current Nabil-gold python processes:"
$patterns = @("run_tick_manager", "run_demo_loop", "demo_watchdog", "run_analysis")
$procs = Get-CimInstance Win32_Process -Filter "Name LIKE 'python%'" |
         Where-Object { $cl = $_.CommandLine; ($patterns | Where-Object { $cl -and $cl.Contains($_) }).Count -gt 0 }
if ($procs) {
    foreach ($p in $procs) { Write-Host ("      PID " + $p.ProcessId + "  " + $p.CommandLine.Substring(0, [Math]::Min(90, $p.CommandLine.Length))) }
} else {
    Write-Host "      (none found - they may have stopped already)"
}

# -- 2. stop them (ONLY our four loops; bots/dashboard untouched) ------
Write-Host "[2/5] Stopping old processes (they hold the single-instance locks)..."
foreach ($p in $procs) {
    try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; Write-Host ("      stopped PID " + $p.ProcessId) }
    catch { Write-Host ("      could not stop PID " + $p.ProcessId + ": " + $_.Exception.Message) }
}
Start-Sleep -Seconds 3

# -- 3. clear stale pidfiles so fresh instances can claim the locks ----
Write-Host "[3/5] Clearing stale pidfiles + rotating oversize logs..."
Get-ChildItem -Path $root -Filter "*.pid" -File -ErrorAction SilentlyContinue |
    ForEach-Object { Remove-Item $_.FullName -Force; Write-Host ("      removed " + $_.Name) }

# -- R23.1: rotate any log above 40 MB while the services are stopped
#    (the launcher holds the file while running - renaming mid-run is
#    impossible; between stop and start is the safe window).
$logMax = 40MB
Get-ChildItem (Join-Path $root "logs") -Filter "*.log" -ErrorAction SilentlyContinue |
    Where-Object { $_.Length -gt $logMax } |
    ForEach-Object {
        try {
            Move-Item -Force $_.FullName ($_.FullName + ".1")
            Write-Host ("      rotated: " + $_.Name + " -> " + $_.Name + ".1")
        } catch {
            Write-Host ("      could not rotate " + $_.Name + ": " + $_.Exception.Message)
        }
    }

# -- 4. start the four canonical services (logs\*.log) -----------------
Write-Host "[4/5] Starting services (tick manager waits 60s for MT5 logon)..."
foreach ($task in @("tick_manager", "demo_loop", "demo_analysis", "demo_watchdog")) {
    $bat = Join-Path $root ("deploy\tasks\" + $task + ".bat")
    if (Test-Path $bat) {
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c", ("`"" + $bat + "`"") `
                      -WorkingDirectory $root -WindowStyle Hidden
        Write-Host ("      started: " + $task)
    } else {
        Write-Host ("      MISSING: " + $bat)
    }
}

# -- 5. wait for the first cycles, then verify -------------------------
Write-Host "[5/5] Waiting 100s for startup + first ticks/cycles..."
Start-Sleep -Seconds 100

Write-Host ""
Write-Host "------ tick manager log (aux collectors proof) ------"
$log = Join-Path $root "logs\tick_manager.log"
if (Test-Path $log) {
    $hits = Select-String -Path $log -Pattern "Aux tick collectors|aux live tick feed started|Aux tick collector init failed" -ErrorAction SilentlyContinue |
            Select-Object -Last 8
    if ($hits) { foreach ($h in $hits) { Write-Host ("      " + $h.Line) } }
    else { Write-Host "      (no aux lines yet - check again in a few minutes)" }
} else { Write-Host "      log not found: $log" }

Write-Host ""
Write-Host "------ auction agent diagnosis (expect fresh heartbeats) ------"
& python (Join-Path $root "scripts\diagnose_auction_agent.py")

Write-Host ""
Write-Host "------ symbol funnel (expect forex audit rows appearing) ------"
& python (Join-Path $root "scripts\diagnose_symbol_funnel.py") --days 1

Write-Host ""
Write-Host "------ MT5 live feed + agents, all 6 pairs ------"
& python (Join-Path $root "scripts\verify_all_instruments_live.py")

Write-Host "==============================================================="
Write-Host " DONE. If forex stores now show fresh heartbeats, the 50% mystery"
Write-Host " is over: the auction agent will publish REAL confidence for them."
Write-Host " Forex analysis rows appear in decision_audit within ~2 cycles (10 min)."
Write-Host " Re-run anytime:  python scripts\diagnose_auction_agent.py"
Write-Host "==============================================================="
