@echo off
cd /d "%~dp0"
echo ========================================================
echo   RUNNING FORENSIC AUDIT (PYTHON DIRECT / POWERSHELL BYPASS)
echo ========================================================
python scripts\audit_trade_entries_and_agents.py
if %ERRORLEVEL% NEQ 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0AUDIT_ENTRIES_AND_MAPS.ps1"
)
pause
