@echo off
REM Nabil-gold R14: restart services + verify all 6 pairs. Right-click >
REM "Run as administrator" is best; normal run usually works too.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RESTART_ALL_SERVICES.ps1"
echo.
pause
