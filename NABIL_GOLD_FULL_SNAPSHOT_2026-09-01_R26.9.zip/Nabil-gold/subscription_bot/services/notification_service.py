import logging
from typing import Dict, Any, Optional
from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup
import config
from database import get_db

logger = logging.getLogger(__name__)

async def notify_admin_new_member(bot: Bot, subscriber: dict):
    """تنبيه المدير بدخول عضو جديد - تعليمات التفعيل السريع"""
    try:
        chat_id = config.admin_destination()
        name = subscriber.get("full_name", "-")
        username = subscriber.get("telegram_username") or "no username"
        if username != "no username" and not username.startswith("@"):
            username = "@" + username
        
        text = (
            "🆕 <b>عضو جديد انضم للقناة</b>\n"
            "━━━━━━━━━━━━━━\n"
            f"👤 الاسم: {name}\n"
            f"🔗 اليوزر: {username}\n\n"
            "💡 <b>لتفعيل الاشتراك أرسل:</b>\n"
            f"<code>{username} 1</code> ⬅️ شهر واحد\n"
            f"<code>{username} 3</code> ⬅️ 3 أشهر"
        )
        
        await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML",
                               disable_web_page_preview=True)
        get_db().log_notification(subscriber.get("id"), "new_member", chat_id, text)
    except Exception as e:
        logger.exception("notify_admin_new_member failed: %s", e)


async def notify_admin_expiring_3d(bot: Bot, sub: dict):
    chat_id = config.admin_destination()
    name = sub.get("full_name")
    username = sub.get("telegram_username") or ""
    if username and not username.startswith("@"):
        username = "@" + username
    expiry = sub.get("expiry_date")
    sid = sub.get("id")
    text = (
        "⏰ <b>Subscription expires in 3 days</b>\n"
        f"👤 {name} {username}\n"
        f"📅 Expiry: {expiry}\n"
        f"🆔 <code>{sub.get('telegram_id')}</code>"
    )
    keyboard = [[
        InlineKeyboardButton("🔄 Renew", callback_data=f"renew:{sid}"),
        InlineKeyboardButton("⏭ Ignore", callback_data=f"ignore:{sid}")
    ]]
    try:
        await bot.send_message(chat_id, text, parse_mode="HTML",
                               reply_markup=InlineKeyboardMarkup(keyboard))
        get_db().log_notification(sid, "before_3_days_admin", chat_id, text)
    except Exception:
        logger.exception("notify_admin_expiring_3d failed")


async def notify_admin_expiring_1d(bot: Bot, sub: dict):
    chat_id = config.admin_destination()
    name = sub.get("full_name")
    username = sub.get("telegram_username") or ""
    if username and not username.startswith("@"):
        username = "@" + username
    expiry = sub.get("expiry_date")
    sid = sub.get("id")
    
    # الرسالة التي تصل للمدير
    admin_text = (
        "⚠️ <b>تنبيه: انتهاء اشتراك غداً</b>\n"
        "━━━━━━━━━━━━━━\n"
        f"👤 المشترك: {name} {username}\n"
        f"📅 تاريخ الانتهاء: {expiry}\n\n"
        "💬 <b>الرسالة المقترحة لإرسالها للمشترك:</b>\n"
        "━━━━━━━━━━━━━━\n"
        f"مرحباً {name}، نود تذكيرك بأن اشتراكك في القناة سينتهي غداً. يرجى التواصل معنا لتجديد الاشتراك لضمان استمرار وصول التوصيات. ✨"
    )
    
    keyboard = [[InlineKeyboardButton("🔄 Renew now", callback_data=f"renew:{sid}")]]
    try:
        await bot.send_message(chat_id, admin_text, parse_mode="HTML",
                               reply_markup=InlineKeyboardMarkup(keyboard))
        get_db().log_notification(sid, "before_1_day_admin", chat_id, admin_text)
    except Exception:
        logger.exception("notify_admin_expiring_1d failed")


async def notify_admin_expired_kicked(bot: Bot, sub: dict):
    chat_id = config.admin_destination()
    name = sub.get("full_name")
    username = sub.get("telegram_username") or ""
    if username and not username.startswith("@"):
        username = "@" + username
    sid = sub.get("id")
    
    # الرسالة التي تصل للمدير
    admin_text = (
        "❌ <b>تنبيه: انتهى الاشتراك اليوم</b>\n"
        "━━━━━━━━━━━━━━\n"
        f"👤 المشترك: {name} {username}\n"
        "حالة الاشتراك: منتهي (تم الطرد تلقائياً)\n\n"
        "💬 <b>الرسالة المقترحة لإرسالها للمشترك:</b>\n"
        "━━━━━━━━━━━━━━\n"
        f"مرحباً {name}، نود إبلاغك بأن اشتراكك قد انتهى وتم إخراجك من القناة. يمكنك التجديد الآن للعودة مجدداً. ✨"
    )
    
    keyboard = [[InlineKeyboardButton("🔄 Renew & Re-invite", callback_data=f"reinvite:{sid}")]]
    try:
        await bot.send_message(chat_id, admin_text, parse_mode="HTML",
                               reply_markup=InlineKeyboardMarkup(keyboard))
        get_db().log_notification(sid, "expired_admin", chat_id, admin_text)
    except Exception:
        logger.exception("notify_admin_expired_kicked failed")


async def dm_subscriber(bot: Bot, telegram_id: int, text: str) -> bool:
    """Send DM to subscriber – returns True if delivered"""
    try:
        await bot.send_message(chat_id=telegram_id, text=text)
        return True
    except Exception as e:
        logger.warning("dm_subscriber failed %s -> %s", telegram_id, e)
        return False


async def notify_subscriber_3days(bot: Bot, sub: dict) -> bool:
    """Subscriber message #1 in lifetime – 3 days reminder – ENGLISH ONLY"""
    tid = int(sub.get("telegram_id"))
    expiry = sub.get("expiry_date")
    text = config.MESSAGES["sub_remind_3d"].format(expiry=expiry, admin=config.ADMIN_CONTACT)
    ok = await dm_subscriber(bot, tid, text)
    db = get_db()
    if ok:
        db.log_notification(sub["id"], "before_3_days_subscriber", tid, text)
    else:
        db.log_notification(sub["id"], "before_3_days_subscriber_failed", tid, "failed")
        # notify admin about delivery failure
        try:
            await bot.send_message(
                chat_id=config.admin_destination(),
                text=f"⚠️ Failed to send 3-day reminder to {sub.get('full_name')} (<code>{tid}</code>)\nUser has not activated bot (/start). Notify manually.\nContact: {config.ADMIN_CONTACT}",
                parse_mode="HTML"
            )
        except Exception:
            pass
    return ok


async def notify_subscriber_expired(bot: Bot, sub: Dict) -> bool:
    """Subscriber message #2 in lifetime – expired kicked – ENGLISH ONLY"""
    tid = int(sub.get("telegram_id"))
    text = config.MESSAGES["sub_expired_kicked"].format(admin=config.ADMIN_CONTACT)
    ok = await dm_subscriber(bot, tid, text)
    db = get_db()
    if ok:
        db.log_notification(sub["id"], "expired_subscriber", tid, text)
    else:
        db.log_notification(sub["id"], "expired_subscriber_failed", tid, "failed")
        try:
            await bot.send_message(
                chat_id=config.admin_destination(),
                text=f"⚠️ Could not notify kicked subscriber {sub.get('full_name')} (<code>{tid}</code>) about expiry.",
                parse_mode="HTML"
            )
        except Exception:
            pass
    return ok
