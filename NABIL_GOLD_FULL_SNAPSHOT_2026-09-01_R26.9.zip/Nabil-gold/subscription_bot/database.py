"""Subscriber database for the subscription bot.

BUILD 16 (2026-08-20): dual backend. Supabase when configured (cloud mode),
otherwise a LOCAL JSON store under storage/subscription_bot.json.

The VPS runs the whole system with Windows tasks and no external services;
this bot used to crash with "SUPABASE_URL / SUPABASE_KEY missing" there. It
now follows the same local-fallback rule as the main trade database.
"""
import json
import logging
import threading
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

try:  # Supabase is optional now: the VPS runs on the local JSON backend
    from supabase import create_client, Client  # type: ignore
except Exception:  # noqa: BLE001
    create_client = None
    Client = None

import config

logger = logging.getLogger(__name__)

LOCAL_PATH = Path(__file__).resolve().parents[1] / "storage" / "subscription_bot.json"
_local_lock = threading.Lock()


def _now_iso() -> str:
    return datetime.utcnow().isoformat()


class Database:
    def __init__(self):
        self.use_supabase = bool(
            config.SUPABASE_URL and config.SUPABASE_KEY and create_client
        )
        self.client = None
        if self.use_supabase:
            self.client = create_client(config.SUPABASE_URL, config.SUPABASE_KEY)
            logger.info("Subscription bot database: Supabase")
        else:
            logger.info(
                "Subscription bot database: local JSON fallback (%s)", LOCAL_PATH
            )
            self._ensure_local()

    # ─────────────────────────── local backend ───────────────────────────
    def _ensure_local(self) -> None:
        LOCAL_PATH.parent.mkdir(parents=True, exist_ok=True)
        if not LOCAL_PATH.exists():
            self._write_local({"subscribers": [], "notifications_log": []})

    def _load_local(self) -> Dict[str, Any]:
        with _local_lock:
            try:
                data = json.loads(LOCAL_PATH.read_text(encoding="utf-8") or "{}")
            except (json.JSONDecodeError, OSError):
                data = {}
            if not isinstance(data, dict):
                data = {}
            data.setdefault("subscribers", [])
            data.setdefault("notifications_log", [])
            return data

    def _write_local(self, data: Dict[str, Any]) -> None:
        with _local_lock:
            tmp = LOCAL_PATH.with_suffix(".tmp")
            tmp.write_text(
                json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            tmp.replace(LOCAL_PATH)

    def _update_local_row(self, subscriber_id: str, updates: Dict[str, Any]) -> bool:
        data = self._load_local()
        for row in data["subscribers"]:
            if str(row.get("id")) == str(subscriber_id):
                row.update(updates)
                row["updated_at"] = _now_iso()
                self._write_local(data)
                return True
        return False

    # ──────────────────────── subscribers ────────────────────────────────
    def get_subscriber_by_tid(self, telegram_id: int) -> Optional[Dict[str, Any]]:
        if self.use_supabase:
            try:
                res = self.client.table("subscribers").select("*").eq("telegram_id", telegram_id).limit(1).execute()
                return res.data[0] if res.data else None
            except Exception as e:
                logger.exception("get_subscriber_by_tid failed: %s", e)
                return None
        for row in self._load_local()["subscribers"]:
            try:
                if int(row.get("telegram_id") or 0) == int(telegram_id):
                    return row
            except (TypeError, ValueError):
                continue
        return None

    def get_subscriber_by_username(self, username: str) -> Optional[Dict[str, Any]]:
        """بحث عن مشترك بواسطة اليوزرنيم"""
        clean_username = (username or "").replace("@", "").strip().lower()
        if self.use_supabase:
            try:
                res = self.client.table("subscribers").select("*").eq("telegram_username", clean_username).limit(1).execute()
                return res.data[0] if res.data else None
            except Exception:
                logger.exception("get_subscriber_by_username failed")
                return None
        if not clean_username:
            return None
        for row in self._load_local()["subscribers"]:
            if str(row.get("telegram_username") or "").replace("@", "").strip().lower() == clean_username:
                return row
        return None

    def upsert_on_join(self, telegram_id: int, full_name: str, username: Optional[str]) -> Dict[str, Any]:
        """عند دخول عضو جديد – تسجيل فقط بدون تفعيل تلقائي"""
        today = date.today().isoformat()
        if self.use_supabase:
            existing = self.get_subscriber_by_tid(telegram_id)
            if existing:
                try:
                    self.client.table("subscribers").update({
                        "full_name": full_name,
                        "telegram_username": username,
                        "join_date": today,
                        "status": "pending_duration",
                        "kicked": False,
                        "updated_at": datetime.utcnow().isoformat()
                    }).eq("telegram_id", telegram_id).execute()
                except Exception:
                    logger.exception("update on re-join failed")
                return self.get_subscriber_by_tid(telegram_id) or existing
            payload = {
                "full_name": full_name,
                "telegram_username": username,
                "telegram_id": telegram_id,
                "join_date": today,
                "status": "pending_duration",
                "can_dm": False
            }
            try:
                res = self.client.table("subscribers").insert(payload).execute()
                return res.data[0] if res.data else payload
            except Exception:
                logger.exception("insert subscriber failed")
                return payload
        existing = self.get_subscriber_by_tid(telegram_id)
        if existing:
            self._update_local_row(existing["id"], {
                "full_name": full_name,
                "telegram_username": username,
                "join_date": today,
                "status": "pending_duration",
                "kicked": False,
            })
            return self.get_subscriber_by_tid(telegram_id) or existing
        row = {
            "id": f"sub_{uuid.uuid4().hex[:12]}",
            "full_name": full_name,
            "telegram_username": username,
            "telegram_id": int(telegram_id),
            "join_date": today,
            "status": "pending_duration",
            "can_dm": False,
            "kicked": False,
            "created_at": _now_iso(),
            "updated_at": _now_iso(),
        }
        data = self._load_local()
        data["subscribers"].append(row)
        self._write_local(data)
        return row

    def set_can_dm(self, telegram_id: int, can_dm: bool = True):
        if self.use_supabase:
            try:
                self.client.table("subscribers").update({"can_dm": can_dm, "updated_at": datetime.utcnow().isoformat()}).eq("telegram_id", telegram_id).execute()
            except Exception:
                logger.exception("set_can_dm failed")
            return
        row = self.get_subscriber_by_tid(telegram_id)
        if row:
            self._update_local_row(row["id"], {"can_dm": bool(can_dm)})

    def set_subscription(self, subscriber_id: str, duration: int, duration_type: str) -> Optional[date]:
        """يحسب expiry_date ويحدث الحالة إلى active"""
        today = date.today()
        if duration_type == "day":
            expiry = today + timedelta(days=duration)
        elif duration_type == "week":
            expiry = today + timedelta(weeks=duration)
        elif duration_type == "month":
            # تقريب 30 يوم للشهر
            expiry = today + timedelta(days=30 * duration)
        elif duration_type == "year":
            expiry = today + timedelta(days=365 * duration)
        else:
            expiry = today + timedelta(days=duration)
        if self.use_supabase:
            try:
                self.client.table("subscribers").update({
                    "subscription_duration": duration,
                    "duration_type": duration_type,
                    "expiry_date": expiry.isoformat(),
                    "status": "active",
                    "kicked": False,
                    "updated_at": datetime.utcnow().isoformat()
                }).eq("id", subscriber_id).execute()
                return expiry
            except Exception:
                logger.exception("set_subscription failed")
                return None
        if self._update_local_row(subscriber_id, {
            "subscription_duration": duration,
            "duration_type": duration_type,
            "expiry_date": expiry.isoformat(),
            "status": "active",
            "kicked": False,
        }):
            return expiry
        return None

    def list_by_status(self, status: str, limit: int = 50) -> List[Dict[str, Any]]:
        if self.use_supabase:
            try:
                res = self.client.table("subscribers").select("*").eq("status", status).order("expiry_date", desc=False).limit(limit).execute()
                return res.data or []
            except Exception:
                logger.exception("list_by_status failed")
                return []
        rows = [r for r in self._load_local()["subscribers"] if str(r.get("status")) == status]
        rows.sort(key=lambda r: str(r.get("expiry_date") or "9999-12-31"))
        return rows[:limit]

    def get_pending(self) -> List[Dict[str, Any]]:
        return self.list_by_status("pending_duration", 100)

    def get_active(self) -> List[Dict[str, Any]]:
        return self.list_by_status("active", 200)

    def get_expired(self) -> List[Dict[str, Any]]:
        return self.list_by_status("expired", 200)

    def search_subscribers(self, q: str) -> List[Dict[str, Any]]:
        q = q.strip()
        if not q:
            return []
        if self.use_supabase:
            try:
                res = self.client.table("subscribers").select("*").limit(200).execute()
                out = []
                ql = q.lower()
                for r in res.data or []:
                    if (ql in str(r.get("full_name", "")).lower() or
                        ql in str(r.get("telegram_username", "")).lower() or
                        ql == str(r.get("telegram_id", ""))):
                        out.append(r)
                return out[:30]
            except Exception:
                logger.exception("search failed")
                return []
        out = []
        ql = q.lower()
        for r in self._load_local()["subscribers"]:
            if (ql in str(r.get("full_name", "")).lower() or
                    ql in str(r.get("telegram_username", "")).lower() or
                    ql == str(r.get("telegram_id", ""))):
                out.append(r)
        return out[:30]

    def get_expiring_in_days(self, days: int) -> List[Dict[str, Any]]:
        target = (date.today() + timedelta(days=days)).isoformat()
        if self.use_supabase:
            try:
                res = self.client.table("subscribers").select("*").eq("status", "active").eq("expiry_date", target).execute()
                return res.data or []
            except Exception:
                logger.exception("get_expiring_in_days failed")
                return []
        return [r for r in self._load_local()["subscribers"]
                if str(r.get("status")) == "active" and str(r.get("expiry_date")) == target]

    def get_expired_today_or_before(self) -> List[Dict[str, Any]]:
        today = date.today().isoformat()
        if self.use_supabase:
            try:
                res = self.client.table("subscribers").select("*").eq("status", "active").lte("expiry_date", today).execute()
                return res.data or []
            except Exception:
                logger.exception("get_expired_today failed")
                return []
        return [r for r in self._load_local()["subscribers"]
                if str(r.get("status")) == "active" and str(r.get("expiry_date") or "9999-12-31") <= today]

    def mark_expired_kicked(self, subscriber_id: str):
        if self.use_supabase:
            try:
                self.client.table("subscribers").update({
                    "status": "expired",
                    "kicked": True,
                    "updated_at": datetime.utcnow().isoformat()
                }).eq("id", subscriber_id).execute()
            except Exception:
                logger.exception("mark_expired_kicked failed")
            return
        self._update_local_row(subscriber_id, {"status": "expired", "kicked": True})

    def cancel_subscriber(self, subscriber_id: str):
        if self.use_supabase:
            try:
                self.client.table("subscribers").update({
                    "status": "cancelled",
                    "updated_at": datetime.utcnow().isoformat()
                }).eq("id", subscriber_id).execute()
                return True
            except Exception:
                logger.exception("cancel failed")
                return False
        return self._update_local_row(subscriber_id, {"status": "cancelled"})

    def delete_subscriber(self, subscriber_id: str):
        if self.use_supabase:
            try:
                self.client.table("subscribers").delete().eq("id", subscriber_id).execute()
                return True
            except Exception:
                logger.exception("delete failed")
                return False
        data = self._load_local()
        before = len(data["subscribers"])
        data["subscribers"] = [r for r in data["subscribers"] if str(r.get("id")) != str(subscriber_id)]
        if len(data["subscribers"]) == before:
            return False
        self._write_local(data)
        return True

    def update_expiry(self, subscriber_id: str, new_expiry: date):
        if self.use_supabase:
            try:
                self.client.table("subscribers").update({
                    "expiry_date": new_expiry.isoformat(),
                    "status": "active",
                    "kicked": False,
                    "updated_at": datetime.utcnow().isoformat()
                }).eq("id", subscriber_id).execute()
                return True
            except Exception:
                logger.exception("update_expiry failed")
                return False
        return self._update_local_row(subscriber_id, {
            "expiry_date": new_expiry.isoformat(),
            "status": "active",
            "kicked": False,
        })

    def get_by_id(self, subscriber_id: str) -> Optional[Dict[str, Any]]:
        if self.use_supabase:
            try:
                res = self.client.table("subscribers").select("*").eq("id", subscriber_id).limit(1).execute()
                return res.data[0] if res.data else None
            except Exception:
                return None
        for row in self._load_local()["subscribers"]:
            if str(row.get("id")) == str(subscriber_id):
                return row
        return None

    # ────────────────────── notifications_log ────────────────────────────
    def has_notification(self, subscriber_id: str, notification_type: str, unique_day: Optional[str] = None) -> bool:
        """منع التكرار"""
        if self.use_supabase:
            try:
                q = self.client.table("notifications_log").select("id").eq("subscriber_id", subscriber_id).eq("notification_type", notification_type)
                res = q.execute()
                if not res.data:
                    return False
                if unique_day:
                    return True
                return True
            except Exception:
                return False
        for n in self._load_local()["notifications_log"]:
            if (str(n.get("subscriber_id")) == str(subscriber_id)
                    and str(n.get("notification_type")) == str(notification_type)):
                return True
        return False

    def log_notification(self, subscriber_id: str, notification_type: str, sent_to: int, message: str):
        if self.use_supabase:
            try:
                self.client.table("notifications_log").insert({
                    "subscriber_id": subscriber_id,
                    "notification_type": notification_type,
                    "sent_to": sent_to,
                    "message": message[:2000]
                }).execute()
            except Exception:
                logger.exception("log_notification failed")
            return
        data = self._load_local()
        data["notifications_log"].append({
            "subscriber_id": str(subscriber_id),
            "notification_type": str(notification_type),
            "sent_to": int(sent_to),
            "message": (message or "")[:2000],
            "created_at": _now_iso(),
        })
        self._write_local(data)

    # ─────────────────────── settings / stats ────────────────────────────
    def get_stats(self) -> Dict[str, int]:
        if self.use_supabase:
            try:
                def count_status(s):
                    r = self.client.table("subscribers").select("id", count="exact").eq("status", s).execute()
                    return r.count or 0
                pending = count_status("pending_duration")
                active = count_status("active")
                expired = count_status("expired")
                cancelled = count_status("cancelled")
                soon = 0
                for d in [1, 2, 3]:
                    soon += len(self.get_expiring_in_days(d))
                return {
                    "total": pending + active + expired + cancelled,
                    "pending": pending,
                    "active": active,
                    "expired": expired,
                    "cancelled": cancelled,
                    "expiring_soon": soon
                }
            except Exception:
                logger.exception("get_stats failed")
                return {"total": 0, "pending": 0, "active": 0, "expired": 0, "cancelled": 0, "expiring_soon": 0}
        rows = self._load_local()["subscribers"]
        def count_status(s):
            return len([r for r in rows if str(r.get("status")) == s])
        pending = count_status("pending_duration")
        active = count_status("active")
        expired = count_status("expired")
        cancelled = count_status("cancelled")
        soon = 0
        for d in [1, 2, 3]:
            soon += len(self.get_expiring_in_days(d))
        return {
            "total": pending + active + expired + cancelled,
            "pending": pending,
            "active": active,
            "expired": expired,
            "cancelled": cancelled,
            "expiring_soon": soon,
        }


# singleton
_db_instance: Optional[Database] = None


def get_db() -> Database:
    global _db_instance
    if _db_instance is None:
        _db_instance = Database()
    return _db_instance
