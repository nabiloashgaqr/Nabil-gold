# -*- coding: utf-8 -*-
"""R25.1: merge the SHIPPED config laws into the LIVE production config.

R25.1 incident (2026-08-28): the installer copies payload folders but never
touches config.json - so the VPS stayed on the pre-R24 law (market conversion
ON, no r24_gates, no r25_scalp, 6h pending life) and 12 verification tests
failed against the old law.

Merge semantics (the R13 rule, made precise):
  1. FORCE the operator's LAW keys - the R24/R25 orders are laws, not
     suggestions: r24_gates, r25_scalp (PATH 7), the contextual activation
     veto, convert_touched_zone_to_market=false, stale_after_hours=12.
  2. FILL every other shipped key ONLY when missing in the live config -
     local tweaks (telegram ids, risk numbers) are never overwritten.
  3. Live-only keys are never removed. A timestamped backup is written
     before the first change. Idempotent: re-running reports 0 changes.
"""
import argparse
import json
import sys
import time
from collections import OrderedDict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# The operator's laws, by exact path. Scalars/blocks here are FORCED to the
# shipped value even when the live config carries an older value.
LAW_TOP_BLOCKS = ("r24_gates", "r25_scalp", "forex_strong_structure", "llm_review")
LAW_SCALARS = (
    ("split_execution", "convert_touched_zone_to_market"),
    ("pending_freshness", "stale_after_hours"),
)
LAW_NESTED_BLOCKS = (
    ("pending_freshness", "activation_book_gate", "r25_contextual"),
    # R25.8: the R25.7 laws are forced too - the VPS kept the old
    # single_family_confirmers (["macro"]) because the key already existed
    # and fill-missing never overwrites. These are operator orders, not
    # suggestions.
    ("signal_requirements", "family_diversity", "single_family_confirmers"),
    ("signal_requirements", "two_agent_entry", "macro_confirmation", "symbols"),
)


def _force(live: OrderedDict, path: tuple, value, stats: dict) -> None:
    node = live
    for part in path[:-1]:
        nxt = node.get(part)
        if not isinstance(nxt, dict):
            nxt = OrderedDict()
            node[part] = nxt
        node = nxt
    leaf = path[-1]
    if node.get(leaf) != value:
        node[leaf] = value
        stats["forced"] += 1


def _fill_missing(live: OrderedDict, shipped: OrderedDict, stats: dict) -> None:
    """Add every shipped key that is missing live; never touch existing ones."""
    for key, value in shipped.items():
        if key not in live:
            live[key] = json.loads(json.dumps(value), object_pairs_hook=OrderedDict) \
                if isinstance(value, dict) else value
            stats["added"] += 1
        elif isinstance(value, dict) and isinstance(live[key], dict):
            _fill_missing(live[key], value, stats)


def merge(live: OrderedDict, shipped: OrderedDict) -> OrderedDict:
    stats = {"forced": 0, "added": 0}
    for block in LAW_TOP_BLOCKS:
        if block in shipped:
            # count a change only when the content actually differs -
            # re-forcing an identical block must stay idempotent.
            if live.get(block) != shipped[block]:
                live[block] = json.loads(json.dumps(shipped[block]),
                                         object_pairs_hook=OrderedDict)
                stats["forced"] += 1
    for path in LAW_SCALARS:
        node = shipped
        for part in path:
            node = node.get(part) if isinstance(node, dict) else None
            if node is None:
                break
        if node is not None:
            _force(live, path, node, stats)
    for path in LAW_NESTED_BLOCKS:
        node = shipped
        for part in path:
            node = node.get(part) if isinstance(node, dict) else None
            if node is None:
                break
        if node is not None:
            _force(live, path, node, stats)
    _fill_missing(live, shipped, stats)
    merge.changed = stats
    return live


def main():
    ap = argparse.ArgumentParser(
        description="Merge the shipped R24/R25 config laws into the live config.json")
    ap.add_argument("--root", default=None,
                    help="project root containing config.json (default: parent of this script)")
    args = ap.parse_args()
    root = Path(args.root) if args.root else ROOT
    live_path = root / "config.json"
    shipped_path = Path(__file__).resolve().parents[1] / "config.json"
    if not live_path.exists():
        print("FAIL: live config.json not found at %s" % live_path)
        return 1
    if not shipped_path.exists():
        print("FAIL: shipped config.json not found at %s" % shipped_path)
        return 1
    live = json.loads(live_path.read_text(encoding="utf-8"),
                      object_pairs_hook=OrderedDict)
    shipped = json.loads(shipped_path.read_text(encoding="utf-8"),
                         object_pairs_hook=OrderedDict)
    merged = merge(live, shipped)
    stats = getattr(merge, "changed", {"forced": 0, "added": 0})
    changed = stats["forced"] + stats["added"]
    if changed:
        stamp = time.strftime("%Y%m%d_%H%M%S")
        backup = live_path.with_name("config.json.bak_r25_" + stamp)
        backup.write_text(live_path.read_text(encoding="utf-8"),
                          encoding="utf-8")
        live_path.write_text(json.dumps(merged, indent=2, ensure_ascii=True),
                             encoding="utf-8")
        print("R25 merge: %d key(s) applied (%d law keys forced, %d missing "
              "added; local tweaks untouched); backup: %s"
              % (changed, stats["forced"], stats["added"], backup.name))
    else:
        print("R25 merge: config already carries every shipped key - nothing "
              "changed (idempotent).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
