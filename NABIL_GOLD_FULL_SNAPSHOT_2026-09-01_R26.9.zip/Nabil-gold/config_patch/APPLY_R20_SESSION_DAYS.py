# -*- coding: utf-8 -*-
"""BUILD31-R20 (2026-08-27): GUARANTEE 24h trading Mon-Fri, remove any break.

Operator directive: trade daily Monday-Friday, 24 hours a day, NO nightly
or morning break. Research fact (checked): the FX/gold week runs from the
Sunday open to the Friday close with no intra-week breaks - in northern
summer that is Sunday 21:00 UTC to Friday 21:00 UTC, which in Asia/Hebron
(UTC+3) is EXACTLY Monday 00:00 -> Saturday 00:00. The canonical session
below therefore matches the real market week hour-for-hour.

Note: a previous draft of this patch added Sunday (weekday 6). That was
WRONG and was reverted on operator correction: adding the Sunday calendar
day only opens closed-market hours (the real Sunday open already falls on
Monday 00:00-01:00 Hebron in summer).

This patch merges into an EXISTING production config.json (same doctrine
as R13/R16: never overwrite the file wholesale):
  * replaces the sessions list with the ONE canonical full-day Mon-Fri
    session (partial/legacy sessions = potential breaks - removed);
  * disables the Friday cutoff (a Friday-night break);
  * fixes the stale "02:00-22:00" trade-management description text.
Idempotent: safe to re-run.
"""
import argparse
import json
import sys
from collections import OrderedDict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

CANON_DAYS = [0, 1, 2, 3, 4]  # Monday..Friday (python weekday)

CANON_SESSION = OrderedDict([
    ("name", "Full-Day Session (24h Mon-Fri, operator directive 2026-08-27 - no daily break)"),
    ("start_hour", 0), ("start_minute", 0),
    ("end_hour", 24), ("end_minute", 0),
    ("days", list(CANON_DAYS)),
    ("quality", "HIGH"),
    ("allow_signals", True),
    ("allow_reports", True),
    ("description", "\u0642\u0631\u0627\u0631 \u0627\u0644\u0645\u0634\u063a\u0644 2026-08-27: 24 \u0633\u0627\u0639\u0629 \u0645\u062a\u0648\u0627\u0635\u0644\u0629 \u0627\u0644\u0627\u062b\u0646\u064a\u0646-\u0627\u0644\u062c\u0645\u0639\u0629 \u0628\u0644\u0627 \u0623\u064a \u0627\u0633\u062a\u0631\u0627\u062d\u0629. "
                    "\u0628\u0627\u0644\u062a\u0648\u0642\u064a\u062a \u0627\u0644\u0635\u064a\u0641\u064a \u0647\u0630\u0627 \u064a\u0637\u0627\u0628\u0642 \u0623\u0633\u0628\u0648\u0639 \u0627\u0644\u0633\u0648\u0642 \u062d\u0631\u0641\u064a\u0627\u064b: \u0627\u0644\u0623\u062d\u062f 21:00 UTC (\u0627\u0644\u0627\u062b\u0646\u064a\u0646 00:00 "
                    "\u0628\u0627\u0644\u062e\u0644\u064a\u0644) \u062d\u062a\u0649 \u0627\u0644\u062c\u0645\u0639\u0629 21:00 UTC (\u0627\u0644\u0633\u0628\u062a 00:00 \u0628\u0627\u0644\u062e\u0644\u064a\u0644)."),
])

TM_DESC = (
    "\u0645\u062a\u0627\u0628\u0639\u0629 \u0627\u0644\u0635\u0641\u0642\u0627\u062a \u0627\u0644\u0645\u0641\u062a\u0648\u062d\u0629 (SL/TP/breakeven/trailing) \u062a\u0639\u0645\u0644 \u0639\u0644\u0649 \u0645\u062f\u0627\u0631 \u0627\u0644\u0633\u0627\u0639\u0629. "
    "\u062a\u0648\u0644\u064a\u062f \u0627\u0644\u0625\u0634\u0627\u0631\u0627\u062a \u0627\u0644\u062c\u062f\u064a\u062f\u0629 \u064a\u0639\u0645\u0644 \u0623\u064a\u0636\u0627\u064b 24 \u0633\u0627\u0639\u0629 \u0645\u062a\u0648\u0627\u0635\u0644\u0629 \u0645\u0646 \u0627\u0644\u0627\u062b\u0646\u064a\u0646 \u0644\u0644\u062c\u0645\u0639\u0629 "
    "(\u0642\u0631\u0627\u0631 \u0627\u0644\u0645\u0634\u063a\u0644 2026-08-27: \u0644\u0627 \u062a\u0648\u062c\u062f \u0623\u064a \u0627\u0633\u062a\u0631\u0627\u062d\u0629 \u0644\u064a\u0644\u064a\u0629 \u0623\u0648 \u0635\u0628\u0627\u062d\u064a\u0629 - \u062c\u0644\u0633\u0629 "
    "\u0643\u0627\u0645\u0644\u0629 00:00-24:00 \u0628\u062a\u0648\u0642\u064a\u062a \u0627\u0644\u062e\u0644\u064a\u0644\u060c \u0645\u0637\u0627\u0628\u0642\u0629 \u0644\u0623\u0633\u0628\u0648\u0639 \u0627\u0644\u0633\u0648\u0642 \u0645\u0646 \u0627\u0644\u0623\u062d\u062f 21:00 UTC "
    "\u0625\u0644\u0649 \u0627\u0644\u062c\u0645\u0639\u0629 21:00 UTC \u0628\u0627\u0644\u062a\u0648\u0642\u064a\u062a \u0627\u0644\u0635\u064a\u0641\u064a)."
)


def _is_canonical(session):
    return (isinstance(session, dict)
            and int(session.get("start_hour", -1)) == 0
            and int(session.get("end_hour", -1)) == 24
            and list(session.get("days") or []) == CANON_DAYS
            and bool(session.get("allow_signals")))


def main():
    ap = argparse.ArgumentParser(
        description="R20: enforce 24h Mon-Fri sessions, remove any break")
    ap.add_argument("--root", default=None,
                    help="project root containing config.json (default: parent of this script)")
    args = ap.parse_args()
    root = Path(args.root) if args.root else ROOT
    path = root / "config.json"
    if not path.exists():
        print("FAIL: config.json not found at %s" % path)
        return 1
    cfg = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=OrderedDict)

    hours = cfg.get("trading_hours")
    if not isinstance(hours, dict):
        print("SKIP: no trading_hours block")
        return 0
    changed = False

    sessions = hours.get("sessions")
    if not isinstance(sessions, list) or not sessions:
        sessions = []
    if len(sessions) == 1 and _is_canonical(sessions[0]):
        print("already true (skipped): sessions = single full-day Mon-Fri")
    else:
        removed = 0
        for session in sessions:
            if not _is_canonical(session):
                removed += 1
                try:
                    print("REMOVED session (break risk): %s (%s-%s:%s days=%s)" % (
                        session.get("name", "?"), session.get("start_hour"),
                        session.get("end_hour"), session.get("end_minute"),
                        session.get("days")))
                except Exception:
                    print("REMOVED one non-canonical session")
        if not removed and sessions:
            print("PATCHED: session window/days -> full-day Mon-Fri")
        elif removed:
            print("PATCHED: %d session(s) removed, canonical full-day installed" % removed)
        hours["sessions"] = [CANON_SESSION]
        changed = True

    if hours.get("enforce_friday_cutoff"):
        hours["enforce_friday_cutoff"] = False
        print("PATCHED: enforce_friday_cutoff -> False (Friday-night break removed)")
        changed = True

    tm = cfg.get("trade_management")
    if isinstance(tm, dict) and "02:00-22:00" in str(
            tm.get("description_update_outside_trading_hours", "")):
        tm["description_update_outside_trading_hours"] = TM_DESC
        print("FIXED: stale 02:00-22:00 description text")
        changed = True

    if changed:
        path.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
        print("OK: %s updated" % path)
    else:
        print("OK: nothing to change")
    return 0


if __name__ == "__main__":
    sys.exit(main())
