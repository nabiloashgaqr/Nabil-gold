# -*- coding: utf-8 -*-
"""
APPLY_PATH9_AND_REGIME_UPGRADE.py  —  R25.8 (operator order 2026-08-29)

Applies the PATH 9 rebirth + the three architecture-closing modules onto a
live Nabil-gold tree (target root defaults to C:\\Nabil-gold, overridable with
--root). It is IDEMPOTENT and SAFE:

  * It COPIES the new/changed files from the package folder into the target,
    never deleting anything. The live `storage` folder is never touched.
  * It MERGES the four new config blocks into config.json (existing keys are
    kept; only the new blocks are added/updated), then rewrites valid JSON.
  * It runs the FULL pytest suite and prints the result.

Deliverables applied
--------------------
  NEW   services/path9_reversal.py          PATH 9 - Liquidity Sweep Raid Reversal
  NEW   services/regime_switcher.py         central market-environment router
  NEW   services/regime_state_machine.py    regime-aware setup state machine
  NEW   services/reflection_agent.py        short-term reflection/cooldown memory
  NEW   tests/test_r25_8_path9_regime_reflection.py   (23 unit tests)
  EDIT  services/execution_paths.py         PATH 9 reborn; old FX-4 lane -> legacy bucket
  EDIT  scripts/run_analysis.py             guarded hooks (all fail-open; switcher ships OFF)
  EDIT  tests/test_r25_fx_macro.py          PATH 9 expectation updated
  EDIT  tests/test_fx4_seven_paths_no_dedicated_lane.py
  EDIT  tests/test_path4_execution_and_measurement.py
  EDIT  tests/test_build30_prearm_ote.py    registry count 9 -> 10
  MERGE config.json                         path9_reversal / regime_switcher (off by
                                            default) / regime_state_machine / reflection_agent

Run (Windows, on the VPS, as Administrator after stopping the services):

    python APPLY_PATH9_AND_REGIME_UPGRADE.py
    python APPLY_PATH9_AND_REGIME_UPGRADE.py --root D:\\some\\other\\Nabil-gold

Flags:
    --root PATH     target project root (default C:\\Nabil-gold)
    --no-tests      skip the pytest run
    --dry-run       show what would be copied/merged, change nothing
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

# Files copied verbatim from the package (relative to this script's folder)
# into the same relative location in the target root.
NEW_FILES = [
    "services/path9_reversal.py",
    "services/regime_switcher.py",
    "services/regime_state_machine.py",
    "services/reflection_agent.py",
    "tests/test_r25_8_path9_regime_reflection.py",
]
EDITED_FILES = [
    "services/execution_paths.py",
    "scripts/run_analysis.py",
    "tests/test_r25_fx_macro.py",
    "tests/test_fx4_seven_paths_no_dedicated_lane.py",
    "tests/test_path4_execution_and_measurement.py",
    "tests/test_build30_prearm_ote.py",
    # 2026-08-30 operator order: these assert the ARMED MAP card is now OFF
    # (PATH 9 trades the reversal live) and the shipped PATH-9 witness config.
    "tests/test_armed_map_watch.py",
    "tests/test_build13_operator_orders.py",
]
ALL_FILES = NEW_FILES + EDITED_FILES

# Config blocks merged into config.json (these ship inside the package's own
# config.json; the applier copies the SAME blocks so a target whose config has
# drifted still receives the new keys without losing its own values).
CONFIG_BLOCK_KEYS = [
    "path9_reversal",
    "regime_switcher",
    "regime_state_machine",
    "reflection_agent",
]

# Nested sub-blocks merged one level deep (so turning the ARMED MAP card off
# never overwrites the operator's other session_plan_delivery keys).
CONFIG_SUBKEY_MERGE = {
    "session_plan_delivery": ["armed_map_watch"],
    "r25_scalp": ["mode"],
}


def _here() -> Path:
    return Path(__file__).resolve().parent


def copy_files(src_root: Path, dst_root: Path, dry_run: bool) -> int:
    n = 0
    for rel in ALL_FILES:
        src = src_root / rel
        dst = dst_root / rel
        if not src.exists():
            print(f"  [MISSING] package file not found: {rel}")
            continue
        if dry_run:
            print(f"  [dry-run] would copy {rel}")
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            print(f"  [OK] copied {rel}")
        n += 1
    return n


def merge_config(src_root: Path, dst_root: Path, dry_run: bool) -> None:
    src_cfg_path = src_root / "config.json"
    dst_cfg_path = dst_root / "config.json"
    if not dst_cfg_path.exists():
        print(f"  [SKIP] target config.json not found at {dst_cfg_path}")
        return
    with dst_cfg_path.open("r", encoding="utf-8") as fh:
        target = json.load(fh)
    if src_cfg_path.exists():
        with src_cfg_path.open("r", encoding="utf-8") as fh:
            source = json.load(fh)
    else:
        source = {}
    added = []
    for key in CONFIG_BLOCK_KEYS:
        block = source.get(key)
        if block is None:
            continue
        if target.get(key) != block:
            target[key] = block
            added.append(key)
    # One-level-deep sub-blocks: apply only the named nested keys so the
    # operator's unrelated settings under the same parent block survive.
    for parent, subkeys in CONFIG_SUBKEY_MERGE.items():
        src_parent = source.get(parent)
        if not isinstance(src_parent, dict):
            continue
        dst_parent = target.setdefault(parent, {})
        if not isinstance(dst_parent, dict):
            dst_parent = {}
            target[parent] = dst_parent
        for sk in subkeys:
            if sk in src_parent and isinstance(src_parent[sk], dict):
                merged = dict(dst_parent.get(sk) or {})
                merged.update(src_parent[sk])
                dst_parent[sk] = merged
                if parent not in added:
                    added.append(f"{parent}.{sk}")
            elif sk in src_parent:
                dst_parent[sk] = src_parent[sk]
                if parent not in added:
                    added.append(f"{parent}.{sk}")
    # r25_scalp mode is a scalar ("live") - force it through the sub-merge
    # above only when present; nothing else to do.
    if dry_run:
        print(f"  [dry-run] would merge config blocks: {added or 'none (already present)'}")
        return
    backup = dst_cfg_path.with_suffix(".json.bak_r25_8")
    if not backup.exists():
        shutil.copy2(dst_cfg_path, backup)
        print(f"  [OK] backed up config.json -> {backup.name}")
    with dst_cfg_path.open("w", encoding="utf-8") as fh:
        json.dump(target, fh, ensure_ascii=False, indent=2)
    print(f"  [OK] merged config blocks: {added or 'none (already present)'}")


def run_tests(dst_root: Path) -> bool:
    print("\n[3/3] running the full test suite (about 1-3 minutes)...\n")
    cmd = [sys.executable, "-m", "pytest", "tests", "-q", "-p", "no:cacheprovider"]
    proc = subprocess.run(cmd, cwd=str(dst_root))
    if proc.returncode == 0:
        print("\n==============================================")
        print(" SUCCESS - R25.8 PATH 9 + regime/reflection")
        print(" upgrade applied and the suite is green.")
        print("==============================================")
        return True
    print("\n*** TESTS REPORTED FAILURES - review the output above.")
    print("    (The two storage-data tests need the live storage/ tree;")
    print("     they fail on a clean snapshot by design, not from this patch.)")
    return False


def main() -> int:
    ap = argparse.ArgumentParser(description="Apply the R25.8 PATH 9 + regime upgrade.")
    ap.add_argument("--root", default=r"C:\Nabil-gold", help="target project root")
    ap.add_argument("--no-tests", action="store_true", help="skip pytest")
    ap.add_argument("--dry-run", action="store_true", help="preview only")
    args = ap.parse_args()

    src_root = _here()
    dst_root = Path(args.root)
    print(f"Package source : {src_root}")
    print(f"Target root    : {dst_root}")
    if args.dry_run:
        print("(dry-run: nothing will be changed)")
    if not dst_root.exists() and not args.dry_run:
        print(f"[ABORT] target root does not exist: {dst_root}")
        print("        pass --root <path> if your install lives elsewhere.")
        return 2

    print("\n[1/3] copying new/updated modules and tests...")
    copy_files(src_root, dst_root, args.dry_run)

    print("\n[2/3] merging config.json blocks...")
    merge_config(src_root, dst_root, args.dry_run)

    if args.dry_run:
        print("\n(dry-run complete - no changes made)")
        return 0
    if args.no_tests:
        print("\n[--no-tests] skipped the suite. Apply finished.")
        return 0
    return 0 if run_tests(dst_root) else 1


if __name__ == "__main__":
    raise SystemExit(main())
