#!/usr/bin/env python3
"""Apply a declarative config merge spec to config.json (BUILD 31 R2).

WHY THIS EXISTS
---------------
config.json OVERRIDES code defaults (per-instrument entries merge over
utils/instruments.py). A patch that changes law values in the code but not
in the VPS config would silently keep the OLD law on the VPS - and the test
suite would fail on the stale config and roll back the whole patch (this
exactly happened on BUILD 31 on 2026-08-24). So law-carrying packages now
ship a merge spec that is applied to config.json BEFORE the tests run.

SPEC FORMAT (deploy/config_merge.json)
--------------------------------------
{
  "instruments": {
    "WTI/USD": {
      "min_sl_distance_points": 400,      # set/replace in the symbol entry
      "trading_rules": { ... },           # nested blocks are replaced whole
      "__remove__": ["session_planner"]   # delete stale keys from the entry
    }
  },
  "top_level_if_missing": {
    "pre_arm_ote": { ... }                # added ONLY when the key is absent
  },
  "top_level_merge": {
    "pre_arm_ote": {"vote_gate": {...}}   # shallow-merge into the existing
                                          # block (or create it if absent)
  }
}

Guarantees: pure stdlib, idempotent (re-running is a no-op), atomic write
(temp file + os.replace), everything else in config.json is preserved
(auction_flow.calibration_required, tokens, EIA files, ...).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", required=True, help="path to config.json")
    ap.add_argument("--spec", required=True, help="path to the merge spec JSON")
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    with open(args.spec, "r", encoding="utf-8") as f:
        spec = json.load(f)

    entries = {}
    for e in cfg.get("instruments") or []:
        if isinstance(e, dict) and e.get("symbol"):
            entries[str(e["symbol"])] = e

    changed = []
    for symbol, fields in (spec.get("instruments") or {}).items():
        entry = entries.get(symbol)
        if entry is None:
            # R26.1: a spec may carry instruments this deployment does not use
            # (e.g. a forex-only or metals-only config). Skip them with a
            # warning instead of aborting the whole merge (which would leave a
            # half-patched config and roll back the patch).
            print(f"WARN: instrument {symbol} not in config.json - skipped")
            continue
        if not isinstance(fields, dict):
            print(f"ERROR: spec for {symbol} must be an object", file=sys.stderr)
            return 2
        for key, value in fields.items():
            if key == "__remove__":
                if not isinstance(value, list):
                    print(f"ERROR: __remove__ for {symbol} must be a list", file=sys.stderr)
                    return 2
                for stale in value:
                    if stale in entry:
                        del entry[stale]
                        changed.append(f"{symbol}: removed {stale}")
                continue
            if entry.get(key) != value:
                entry[key] = value
                changed.append(f"{symbol}.{key}")

    for key, value in (spec.get("top_level_if_missing") or {}).items():
        if key not in cfg:
            cfg[key] = value
            changed.append(f"top-level: added {key}")

    for key, value in (spec.get("top_level_merge") or {}).items():
        existing = cfg.get(key)
        if isinstance(existing, dict) and isinstance(value, dict):
            for sub_k, sub_v in value.items():
                if existing.get(sub_k) != sub_v:
                    existing[sub_k] = sub_v
                    changed.append(f"top-level: {key}.{sub_k}")
        elif key not in cfg:
            cfg[key] = value
            changed.append(f"top-level: added {key}")

    if changed:
        cfg_path = os.path.abspath(args.config)
        fd, tmp = tempfile.mkstemp(
            dir=os.path.dirname(cfg_path) or ".", suffix=".config.tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(cfg, f, indent=2, ensure_ascii=False)
                f.write("\n")
            os.replace(tmp, cfg_path)
        except Exception:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
    print("config merge applied:",
          ", ".join(changed) if changed else "no changes (already merged)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
