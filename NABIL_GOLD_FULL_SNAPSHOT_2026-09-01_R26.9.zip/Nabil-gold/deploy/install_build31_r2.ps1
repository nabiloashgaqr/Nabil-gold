#Requires -Version 5.1
<#
.SYNOPSIS
    BUILD 31 R2 installer — the SINGLE command for this package.

.DESCRIPTION
    The VPS config.json OVERRIDES code defaults, and the BUILD 31 WTI
    gold-parity law lives in BOTH. BUILD 31 (first release) failed on the
    VPS because the manual config merge had not happened before the test
    suite ran -> automatic rollback. This installer fixes the ordering:

      1) extract the merge spec + tool from the zip to a temp folder
      2) back up config.json, apply the WTI law merge (idempotent)
      3) run deploy\APPLY_PATCH.ps1 -Force (extract payload, py_compile,
         FULL test suite, automatic rollback, restart SS_DemoLoop)
      4) if the patch failed/rolled back, restore config.json too
         (atomic: nothing is left half-applied)

    From BUILD 32 on, APPLY_PATCH.ps1 v4 (shipped in this payload) applies
    any config merge spec it finds in the payload automatically — no
    separate installer needed.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File C:\Nabil-gold\deploy\install_build31_r2.ps1
#>
$ErrorActionPreference = "Stop"

$RepoRoot = Split-Path $PSScriptRoot -Parent
$cfg = Join-Path $RepoRoot "config.json"
if (-not (Test-Path $cfg)) {
    $RepoRoot = "C:\Nabil-gold"
    $cfg = Join-Path $RepoRoot "config.json"
    if (-not (Test-Path $cfg)) { throw "config.json not found (is the repo at C:\Nabil-gold?)" }
}

# 1) locate the zip (repo root, then Downloads)
$zip = $null
$cands = @((Join-Path $RepoRoot "Nabil-gold-BUILD31-R2*.zip"),
          (Join-Path $env:USERPROFILE "Downloads\Nabil-gold-BUILD31-R2*.zip"))
foreach ($pattern in $cands) {
    $hit = @(Get-ChildItem $pattern -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    if ($hit.Count -gt 0) { $zip = $hit[0]; break }
}
if (-not $zip) { throw "Nabil-gold-BUILD31-R2*.zip not found in the repo root or Downloads" }
Write-Host "==> ZIP: $($zip.FullName)" -ForegroundColor Cyan

# 2) extract merge spec + tool to temp
$tmp = Join-Path $env:TEMP ("nabil_b31r2_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
Expand-Archive $zip.FullName -DestinationPath $tmp -Force
$spec = @(Get-ChildItem $tmp -Recurse -Filter "config_merge.json") | Select-Object -First 1
$tool = @(Get-ChildItem $tmp -Recurse -Filter "apply_config_merge.py") | Select-Object -First 1
if (-not $spec -or -not $tool) { throw "config merge spec/tool not found inside the zip" }

# 3) back up config, then merge (idempotent)
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$bakDir = Join-Path $RepoRoot "deploy\backups\config_merge_$stamp"
New-Item -ItemType Directory -Path $bakDir -Force | Out-Null
Copy-Item $cfg (Join-Path $bakDir "config.json") -Force
Write-Host "==> config backup -> $bakDir" -ForegroundColor Cyan
& python $tool.FullName --config $cfg --spec $spec.FullName
if ($LASTEXITCODE -ne 0) {
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
    throw "config merge FAILED - config.json is untouched (see error above)"
}

# 4) run the standard patch flow (tests run against the MERGED config)
$patch = Join-Path $RepoRoot "deploy\APPLY_PATCH.ps1"
if (-not (Test-Path $patch)) { throw "deploy\APPLY_PATCH.ps1 not found under $RepoRoot" }
& powershell -ExecutionPolicy Bypass -File $patch -ZipPath $zip.FullName -RepoRoot $RepoRoot -Force
$rc = $LASTEXITCODE

# 5) if the patch failed/rolled back, restore the config too (atomic)
if ($rc -ne 0) {
    Write-Host "==> patch failed or rolled back - restoring config.json from backup" -ForegroundColor Yellow
    Copy-Item (Join-Path $bakDir "config.json") $cfg -Force
}
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
exit $rc
