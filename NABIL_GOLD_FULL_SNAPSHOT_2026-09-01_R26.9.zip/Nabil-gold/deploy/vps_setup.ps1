# =============================================================================
# FULL-VPS bootstrap: DEMO ONLY (branch demo/mt5).
# GitHub keeps ONLY the Dashboard. Paper trading is STOPPED.
# Run PowerShell AS ADMIN inside C:\Nabil-gold. Idempotent: re-runnable.
# NOTE: this file is ASCII-only ON PURPOSE. Windows PowerShell 5.1 reads
# non-BOM .ps1 files as ANSI, and any smart-dash/box character corrupts the
# parser ("Missing closing '}'"). Keep it ASCII.
# =============================================================================

$ErrorActionPreference = "Stop"
Write-Host "=== Setting up SmartSignal VPS (branch demo/mt5) ===" -ForegroundColor Cyan

# 0. Sanity: must run in repo root
if (-not (Test-Path "config.json")) {
    Write-Host "ERROR: run this script inside the repo root (C:\Nabil-gold)." -ForegroundColor Red
    Exit 1
}

# 1. Python environment
$python = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $python) {
    Write-Host "ERROR: Python not in PATH. Install Python 3.11/3.12 (x64) + add to PATH." -ForegroundColor Red
    Exit 1
}
Write-Host "Python: $python ($(& python --version))"

# 2. Dependencies
Write-Host "Installing Python requirements..." -ForegroundColor Yellow
python -m pip install --upgrade pip | Out-Null
python -m pip install -r requirements.txt
python -m pip install MetaTrader5

# 3. Create Desktop shortcuts
$wsh = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath("Desktop")
$repo = (Get-Location).Path

$sc1 = $wsh.CreateShortcut("$desktop\SmartSignal - Start Loop.lnk")
$sc1.TargetPath = "$repo\deploy\tasks\demo_loop.bat"
$sc1.WorkingDirectory = $repo
$sc1.IconLocation = "shell32.dll,138"
$sc1.Save()

$sc2 = $wsh.CreateShortcut("$desktop\SmartSignal - Watchdog.lnk")
$sc2.TargetPath = "$repo\deploy\tasks\demo_watchdog.bat"
$sc2.WorkingDirectory = $repo
$sc2.IconLocation = "shell32.dll,220"
$sc2.Save()

# 4. .env from template (EDIT VALUES BEFORE ANYTHING RUNS!)
if (-not (Test-Path .env)) { Copy-Item deploy\.env.example .env; Write-Host "EDIT .env NOW - fill every key." -ForegroundColor Yellow }

# 5. Logs dir
New-Item -ItemType Directory -Force -Path logs | Out-Null

# 6. Scheduled tasks - Calculate exact Hebron (UTC+3) times for this VPS
$serverTz = [System.TimeZoneInfo]::Local
$utcNow = [System.DateTime]::UtcNow
try {
    $hebronTz = [System.TimeZoneInfo]::FindSystemTimeZoneById("Middle East Standard Time")
} catch {
    try {
        $hebronTz = [System.TimeZoneInfo]::FindSystemTimeZoneById("Jordan Standard Time")
    } catch {
        $hebronTz = [System.TimeZoneInfo]::CreateCustomTimeZone("Hebron", [System.TimeSpan]::FromHours(3), "Asia/Hebron", "Asia/Hebron")
    }
}
$hebronNow = [System.TimeZoneInfo]::ConvertTimeFromUtc($utcNow, $hebronTz)
$todayHebron = $hebronNow.Date

# Daily Report: 23:50 Hebron converted to VPS Local Time
$targetDailyHebron = $todayHebron.AddHours(23).AddMinutes(50)
$targetDailyUtc = [System.TimeZoneInfo]::ConvertTimeToUtc($targetDailyHebron, $hebronTz)
$targetDailyServer = [System.TimeZoneInfo]::ConvertTimeFromUtc($targetDailyUtc, $serverTz)
$dailyTriggerTime = $targetDailyServer.ToString("HH:mm")

# Weekly Report: 23:55 Hebron converted to VPS Local Time
$targetWeeklyHebron = $todayHebron.AddHours(23).AddMinutes(55)
$targetWeeklyUtc = [System.TimeZoneInfo]::ConvertTimeToUtc($targetWeeklyHebron, $hebronTz)
$targetWeeklyServer = [System.TimeZoneInfo]::ConvertTimeFromUtc($targetWeeklyUtc, $serverTz)
$weeklyTriggerTime = $targetWeeklyServer.ToString("HH:mm")

$t = Join-Path (Get-Location).Path "deploy\tasks"
schtasks /Create /TN "SS_DemoAnalysis" /SC MINUTE /MO 5  /TR "cmd /c $t\demo_analysis.bat" /F
schtasks /Create /TN "SS_DemoWatchdog" /SC MINUTE /MO 1  /TR "cmd /c $t\demo_watchdog.bat" /F
schtasks /Create /TN "SS_DemoLoop"     /SC ONLOGON       /TR "cmd /c $t\demo_loop.bat"     /F
schtasks /Create /TN "SS_TickManager"  /SC ONLOGON       /TR "cmd /c $t\tick_manager.bat"  /F
schtasks /Create /TN "SS_MT5Terminal"  /SC ONLOGON       /TR "cmd /c $t\mt5_terminal.bat"  /F
schtasks /Create /TN "SS_DashboardAPI" /SC ONLOGON       /TR "cmd /c $t\dashboard_api.bat"  /F
schtasks /Create /TN "SS_MarketStatus" /SC HOURLY /MO 1 /ST 00:01 /TR "cmd /c $t\market_status.bat"      /F
schtasks /Create /TN "SS_MacroContext" /SC HOURLY /MO 1 /ST 00:07 /TR "cmd /c $t\macro_demo.bat"         /F
schtasks /Create /TN "SS_DailyReport"  /SC DAILY  /ST $dailyTriggerTime /TR "cmd /c $t\daily_report_demo.bat"  /RL HIGHEST /F
schtasks /Create /TN "SS_Dashboard"    /SC DAILY  /ST $dailyTriggerTime /TR "cmd /c $t\dashboard_demo.bat"     /RL HIGHEST /F
schtasks /Create /TN "SS_WeeklyReport" /SC WEEKLY /D FRI /ST $weeklyTriggerTime /TR "cmd /c $t\weekly_report_demo.bat" /RL HIGHEST /F

# 7. Smoke test BEFORE the first scheduled run
python scripts\demo_smoke_test.py

Write-Host ""
Write-Host "Setup complete. SS_DailyReport locked to 23:50 Hebron ($dailyTriggerTime VPS time)." -ForegroundColor Green
Write-Host "Double click 'SmartSignal - Start Loop' on Desktop to begin." -ForegroundColor Green
