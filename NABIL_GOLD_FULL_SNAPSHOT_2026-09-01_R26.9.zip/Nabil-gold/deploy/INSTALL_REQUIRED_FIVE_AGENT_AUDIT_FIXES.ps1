# Five required fixes from the independent audit.
# Demo only: closed candles, one raw book, activity units, conflict WAIT, shared scale-in admission.
param([string]$Root = "C:\Nabil-gold")
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$release = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = if (Test-Path (Join-Path $release "payload")) {
    Join-Path $release "payload"
} elseif (Test-Path (Join-Path $release "..\payload")) {
    (Resolve-Path (Join-Path $release "..\payload")).Path
} else {
    throw "Payload directory not found next to installer"
}

if (-not (Test-Path $Root)) { throw "Project root not found: $Root" }
if (-not (Test-Path (Join-Path $payload "services\mt5_feed.py"))) {
    throw "Payload missing services\mt5_feed.py"
}
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run PowerShell as Administrator"
}

Set-Location $Root
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backup = Join-Path $Root "storage\deployment_backups\required_five_agent_audit_fixes_$stamp"
New-Item -ItemType Directory -Force -Path $backup | Out-Null
Start-Transcript -Path (Join-Path $backup "install.log") -Force | Out-Null

$taskNames = @("SS_DemoWatchdog", "SS_DemoAnalysis")
$taskState = @{}
$fileState = @{}
$activated = $false

function Save-And-Stop-Tasks {
    foreach ($name in $taskNames) {
        $task = Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
        if (-not $task) { continue }
        $taskState[$name] = @{
            Enabled = ($task.Settings.Enabled -ne $false)
            WasRunning = ($task.State -eq "Running")
        }
        try { Stop-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue } catch {}
        Disable-ScheduledTask -TaskName $name | Out-Null
    }
}

function Restore-Tasks {
    foreach ($name in $taskNames) {
        if (-not $taskState.ContainsKey($name)) { continue }
        try {
            if ($taskState[$name].Enabled) {
                Enable-ScheduledTask -TaskName $name | Out-Null
            } else {
                Disable-ScheduledTask -TaskName $name | Out-Null
            }
            if ($taskState[$name].WasRunning) {
                Start-ScheduledTask -TaskName $name
            }
        } catch {
            Write-Warning "Could not restore task $name : $($_.Exception.Message)"
        }
    }
}

function Restore-Files {
    foreach ($rel in $fileState.Keys) {
        $target = Join-Path $Root $rel
        $saved = Join-Path $backup (Join-Path "files" $rel)
        if ($fileState[$rel]) {
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
            Copy-Item -LiteralPath $saved -Destination $target -Force
        } elseif (Test-Path $target) {
            Remove-Item -LiteralPath $target -Force
        }
    }
}

function Invoke-IsolatedFullTests {
    # Run from a clean copy OUTSIDE C:\Nabil-gold. Running pytest in the live
    # tree lets python-dotenv reload real Telegram/MT5/Supabase values and lets
    # recursive source tests inspect deployment_backups as if they were live
    # source files. Both produce false failures unrelated to this patch.
    $testRoot = Join-Path ([IO.Path]::GetTempPath()) "NabilGoldCleanTest_$stamp"
    $saved = @{}
    $names = @{
        "EXECUTION_MODE" = $true
        "DATA_SOURCE_PRIMARY" = $true
        "TRADES_TABLE" = $true
        "TELEGRAM_BOT_TOKEN" = $true
        "TELEGRAM_CHAT_ID" = $true
        "TELEGRAM_DEMO_CHAT_ID" = $true
        "SUPABASE_URL" = $true
        "SUPABASE_KEY" = $true
        "GEMINI_API_KEY" = $true
        "PYTHON_DOTENV_DISABLED" = $true
        "PYTEST_RUNNING" = $true
    }
    # Block every key present in the live .env without reading or printing its
    # value. Empty process variables are considered already defined, so
    # load_dotenv(override=False) cannot refill them in the child process.
    $envFile = Join-Path $Root ".env"
    if (Test-Path $envFile) {
        foreach ($line in Get-Content -LiteralPath $envFile) {
            if ([string]$line -match '^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=') {
                $names[$matches[1]] = $true
            }
        }
    }

    try {
        Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction SilentlyContinue
        New-Item -ItemType Directory -Force -Path $testRoot | Out-Null
        $copyArgs = @(
            $Root, $testRoot, "/E", "/R:1", "/W:1", "/NFL", "/NDL",
            "/NJH", "/NJS", "/NP",
            "/XD", ".git", ".venv", "__pycache__", ".pytest_cache",
            ".mypy_cache", ".arena", "node_modules", "storage",
            "diagnostics", "rounds", "reports", "build", "dist", "coverage",
            "/XF", ".env", "*.pyc", "*.pyo", "*.log", "*.pid"
        )
        & robocopy @copyArgs | Out-Null
        $copyExit = $LASTEXITCODE
        if ($copyExit -ge 8) { throw "Clean test copy failed with robocopy code $copyExit" }

        # One committed analyst label is a deliberate test fixture. Copy only
        # those fixtures, never runtime trades, SQLite, calibrations or backups.
        $testStorage = Join-Path $testRoot "storage"
        New-Item -ItemType Directory -Force -Path $testStorage | Out-Null
        $labelFiles = Get-ChildItem -LiteralPath (Join-Path $Root "storage") -File -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -like "*_analyst_label.csv" -or
                $_.Name -like "analyst_labels_*.json"
            }
        foreach ($label in $labelFiles) {
            Copy-Item -LiteralPath $label.FullName -Destination $testStorage -Force
        }
        if (-not $labelFiles) { throw "Clean test sandbox has no analyst-label fixture" }

        foreach ($name in $names.Keys) {
            $saved[$name] = [Environment]::GetEnvironmentVariable($name, "Process")
            [Environment]::SetEnvironmentVariable($name, "", "Process")
        }
        [Environment]::SetEnvironmentVariable("PYTHON_DOTENV_DISABLED", "1", "Process")
        [Environment]::SetEnvironmentVariable("PYTEST_RUNNING", "true", "Process")

        Set-Location $testRoot
        & python -m pytest -q | Out-Host
        $testExit = $LASTEXITCODE
        return $testExit
    } finally {
        Set-Location $Root
        foreach ($name in $saved.Keys) {
            [Environment]::SetEnvironmentVariable($name, $saved[$name], "Process")
        }
        Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
try {
    Write-Host "[1/7] Verifying Demo mode and existing runtime artifacts..." -ForegroundColor Cyan
    python -c "import json; c=json.load(open('config.json',encoding='utf-8')); assert c.get('trading_mode')=='mt5_demo', c.get('trading_mode'); print('DEMO MODE OK')"
    if ($LASTEXITCODE -ne 0) { throw "Demo-only guard failed" }
    foreach ($rel in @(
        "storage\model_calibration\unified_trend_v1.json",
        "storage\model_calibration\auction_flow_v1.json",
        "storage\auction_flow.sqlite3"
    )) {
        if (-not (Test-Path (Join-Path $Root $rel))) {
            throw "Existing runtime artifact missing: $rel"
        }
    }

    Write-Host "[2/7] Stopping analysis writers only..." -ForegroundColor Cyan
    Save-And-Stop-Tasks
    Write-Host "SS_TickManager was not stopped or launched by this installer." -ForegroundColor DarkGray

    Write-Host "[3/7] Backing up and applying payload..." -ForegroundColor Cyan
    $files = Get-ChildItem $payload -Recurse -File | Where-Object {
        -not $_.FullName.EndsWith(".env") -and
        -not $_.FullName.EndsWith(".sqlite3") -and
        (-not $_.FullName.EndsWith(".json") -or $_.Name -eq "config.json")
    }
    foreach ($file in $files) {
        $rel = $file.FullName.Substring($payload.Length).TrimStart('\')
        $target = Join-Path $Root $rel
        $exists = Test-Path $target
        $fileState[$rel] = $exists
        if ($exists) {
            $savedFile = Join-Path $backup (Join-Path "files" $rel)
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $savedFile) | Out-Null
            Copy-Item -LiteralPath $target -Destination $savedFile -Force
        }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath $file.FullName -Destination $target -Force
    }
    $activated = $true

    Write-Host "[4/7] Syntax and five required audit invariants..." -ForegroundColor Cyan
    python -m py_compile services\mt5_feed.py services\shared_market_data.py services\auction_flow_store.py services\timeframe_fusion.py services\agent_confidence_audit.py agents\decision_agent.py agents\auction_flow_agent.py scripts\run_analysis.py scripts\check_agents_now.py tests\test_required_audit_fixes.py tests\test_scale_in_delivery.py
    if ($LASTEXITCODE -ne 0) { throw "Syntax validation failed" }

    # Verify the five invariants without sending Telegram or creating orders.
    $verifyPath = Join-Path $Root "verify_required_audit_fixes_$stamp.py"
    @'
import inspect, json
from services.timeframe_fusion import fuse_timeframe_results
from agents.decision_agent import DecisionAgent
from scripts import run_analysis
from services import mt5_feed
c = json.load(open("config.json", encoding="utf-8"))
assert c["learning"]["auto_adjust_confidence"] is False
assert "copy_rates_from_pos(mt5_symbol, tf_const, 1, count)" in inspect.getsource(mt5_feed.get_candles)
conflict = fuse_timeframe_results("classical", {
    "5m": {"direction": "WAIT", "confidence": 32},
    "15m": {"direction": "SELL", "confidence": 71},
    "1H": {"direction": "BUY", "confidence": 70},
    "4H": {"direction": "WAIT", "confidence": 28},
})
assert conflict["signal"] == "WAIT" and conflict["timeframe_fusion"]["conflict_wait"]
source = inspect.getsource(run_analysis._check_scale_in)
assert "evaluate_directional_admission" in source
assert "net_weighted / total_weight" not in source
agent = DecisionAgent(c, learning_service=object())
assert agent.learning_confidence_adjustments_enabled is False
print("CLOSED CANDLES: PASS")
print("ONE RAW DISPLAY/DECISION BOOK: PASS")
print("NEAR-ZERO FRAME CONFLICT -> WAIT: PASS")
print("SCALE-IN SHARED ADMISSION: PASS")
print("ACTIVITY SAME-UNIT WINDOWS: covered by full regression test")
'@ | Set-Content -LiteralPath $verifyPath -Encoding ASCII
    try {
        python $verifyPath
        if ($LASTEXITCODE -ne 0) { throw "Required audit invariants failed" }
    } finally {
        Remove-Item -LiteralPath $verifyPath -Force -ErrorAction SilentlyContinue
    }
    Write-Host "[5/7] Running the complete isolated test suite..." -ForegroundColor Cyan
    $testExit = Invoke-IsolatedFullTests
    if ($testExit -ne 0) { throw "Full regression tests failed" }

    Write-Host "[6/7] Producing one shared live five-agent check..." -ForegroundColor Cyan
    python scripts\check_agents_now.py | Out-Host
    if ($LASTEXITCODE -ne 0) { throw "Live five-agent check failed" }

    Write-Host "[7/7] Restoring scheduled task states..." -ForegroundColor Cyan
    Restore-Tasks
    "Success $(Get-Date -Format o)" | Set-Content (Join-Path $backup "SUCCESS") -Encoding ASCII
    Write-Host "COMPLETE: all five required independent-audit fixes are active." -ForegroundColor Green
    Write-Host "Weights, 67/72 thresholds, stops, targets and Demo-only execution remain unchanged." -ForegroundColor Green
    Stop-Transcript | Out-Null
    exit 0
} catch {
    $failure = $_
    Write-Host "INSTALL FAILED: $($failure.Exception.Message)" -ForegroundColor Red
    try {
        if ($activated) { Restore-Files }
        Restore-Tasks
        Write-Host "ROLLBACK COMPLETE" -ForegroundColor Yellow
    } catch {
        Write-Host "ROLLBACK ERROR: $($_.Exception.Message)" -ForegroundColor Red
    }
    try { Stop-Transcript | Out-Null } catch {}
    exit 1
}
