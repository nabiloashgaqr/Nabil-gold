# Two-agent Telegram monitoring maps with complete levels and no execution authority.
# Demo only. No tick download, no calibration rebuild, and Tick Manager is not stopped.
param([string]$Root = "C:\Nabil-gold")
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$release = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = if (Test-Path (Join-Path $release "payload")) {
    Join-Path $release "payload"
} elseif (Test-Path (Join-Path $release "..\payload")) {
    (Resolve-Path (Join-Path $release "..\payload")).Path
} else {
    throw "Payload directory not found next to installer"
}

if (-not (Test-Path $Root)) { throw "Project root not found: $Root" }
if (-not (Test-Path (Join-Path $payload "scripts\run_analysis.py"))) {
    throw "Payload missing scripts\run_analysis.py"
}
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run PowerShell as Administrator"
}

Set-Location $Root
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backup = Join-Path $Root "storage\deployment_backups\two_agent_monitoring_maps_$stamp"
New-Item -ItemType Directory -Force -Path $backup | Out-Null
Start-Transcript -Path (Join-Path $backup "install.log") -Force | Out-Null

$taskNames = @("SS_DemoWatchdog", "SS_DemoAnalysis")
$taskState = @{}
$fileState = @{}
$activated = $false

function Save-And-Stop-Tasks {
    foreach ($name in $taskNames) {
        $task = Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
        if (-not $task) { continue }
        $taskState[$name] = @{
            Enabled = ($task.Settings.Enabled -ne $false)
            WasRunning = ($task.State -eq "Running")
        }
        try { Stop-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue } catch {}
        Disable-ScheduledTask -TaskName $name | Out-Null
    }
}

function Restore-Tasks {
    foreach ($name in $taskNames) {
        if (-not $taskState.ContainsKey($name)) { continue }
        try {
            if ($taskState[$name].Enabled) {
                Enable-ScheduledTask -TaskName $name | Out-Null
            } else {
                Disable-ScheduledTask -TaskName $name | Out-Null
            }
            if ($taskState[$name].WasRunning) {
                Start-ScheduledTask -TaskName $name
            }
        } catch {
            Write-Warning "Could not restore task $name : $($_.Exception.Message)"
        }
    }
}

function Restore-Files {
    foreach ($rel in $fileState.Keys) {
        $target = Join-Path $Root $rel
        $saved = Join-Path $backup (Join-Path "files" $rel)
        if ($fileState[$rel]) {
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
            Copy-Item -LiteralPath $saved -Destination $target -Force
        } elseif (Test-Path $target) {
            Remove-Item -LiteralPath $target -Force
        }
    }
}

function Invoke-IsolatedFullTests {
    # Run from a clean copy OUTSIDE C:\Nabil-gold. Running pytest in the live
    # tree lets python-dotenv reload real Telegram/MT5/Supabase values and lets
    # recursive source tests inspect deployment_backups as if they were live
    # source files. Both produce false failures unrelated to this patch.
    $testRoot = Join-Path ([IO.Path]::GetTempPath()) "NabilGoldCleanTest_$stamp"
    $saved = @{}
    $names = @{
        "EXECUTION_MODE" = $true
        "DATA_SOURCE_PRIMARY" = $true
        "TRADES_TABLE" = $true
        "TELEGRAM_BOT_TOKEN" = $true
        "TELEGRAM_CHAT_ID" = $true
        "TELEGRAM_DEMO_CHAT_ID" = $true
        "SUPABASE_URL" = $true
        "SUPABASE_KEY" = $true
        "GEMINI_API_KEY" = $true
        "PYTHON_DOTENV_DISABLED" = $true
        "PYTEST_RUNNING" = $true
    }
    # Block every key present in the live .env without reading or printing its
    # value. Empty process variables are considered already defined, so
    # load_dotenv(override=False) cannot refill them in the child process.
    $envFile = Join-Path $Root ".env"
    if (Test-Path $envFile) {
        foreach ($line in Get-Content -LiteralPath $envFile) {
            if ([string]$line -match '^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=') {
                $names[$matches[1]] = $true
            }
        }
    }

    try {
        Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction SilentlyContinue
        New-Item -ItemType Directory -Force -Path $testRoot | Out-Null
        $copyArgs = @(
            $Root, $testRoot, "/E", "/R:1", "/W:1", "/NFL", "/NDL",
            "/NJH", "/NJS", "/NP",
            "/XD", ".git", ".venv", "__pycache__", ".pytest_cache",
            ".mypy_cache", ".arena", "node_modules", "storage",
            "diagnostics", "rounds", "reports", "build", "dist", "coverage",
            "/XF", ".env", "*.pyc", "*.pyo", "*.log", "*.pid"
        )
        & robocopy @copyArgs | Out-Null
        $copyExit = $LASTEXITCODE
        if ($copyExit -ge 8) { throw "Clean test copy failed with robocopy code $copyExit" }

        # One committed analyst label is a deliberate test fixture. Copy only
        # those fixtures, never runtime trades, SQLite, calibrations or backups.
        $testStorage = Join-Path $testRoot "storage"
        New-Item -ItemType Directory -Force -Path $testStorage | Out-Null
        $labelFiles = Get-ChildItem -LiteralPath (Join-Path $Root "storage") -File -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -like "*_analyst_label.csv" -or
                $_.Name -like "analyst_labels_*.json"
            }
        foreach ($label in $labelFiles) {
            Copy-Item -LiteralPath $label.FullName -Destination $testStorage -Force
        }
        if (-not $labelFiles) { throw "Clean test sandbox has no analyst-label fixture" }

        foreach ($name in $names.Keys) {
            $saved[$name] = [Environment]::GetEnvironmentVariable($name, "Process")
            [Environment]::SetEnvironmentVariable($name, "", "Process")
        }
        [Environment]::SetEnvironmentVariable("PYTHON_DOTENV_DISABLED", "1", "Process")
        [Environment]::SetEnvironmentVariable("PYTEST_RUNNING", "true", "Process")

        Set-Location $testRoot
        & python -m pytest -q | Out-Host
        $testExit = $LASTEXITCODE
        return $testExit
    } finally {
        Set-Location $Root
        foreach ($name in $saved.Keys) {
            [Environment]::SetEnvironmentVariable($name, $saved[$name], "Process")
        }
        Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
try {
    Write-Host "[1/7] Verifying Demo mode and existing runtime artifacts..." -ForegroundColor Cyan
    python -c "import json; c=json.load(open('config.json',encoding='utf-8')); assert c.get('trading_mode')=='mt5_demo', c.get('trading_mode'); print('DEMO MODE OK')"
    if ($LASTEXITCODE -ne 0) { throw "Demo-only guard failed" }
    foreach ($rel in @(
        "storage\model_calibration\unified_trend_v1.json",
        "storage\model_calibration\auction_flow_v1.json",
        "storage\auction_flow.sqlite3"
    )) {
        if (-not (Test-Path (Join-Path $Root $rel))) {
            throw "Existing runtime artifact missing: $rel"
        }
    }

    Write-Host "[2/7] Stopping analysis writers only..." -ForegroundColor Cyan
    Save-And-Stop-Tasks
    Write-Host "SS_TickManager was not stopped or launched by this installer." -ForegroundColor DarkGray

    Write-Host "[3/7] Backing up and applying payload..." -ForegroundColor Cyan
    $files = Get-ChildItem $payload -Recurse -File | Where-Object {
        -not $_.FullName.EndsWith(".env") -and
        -not $_.FullName.EndsWith(".sqlite3") -and
        (-not $_.FullName.EndsWith(".json") -or $_.Name -eq "config.json")
    }
    foreach ($file in $files) {
        $rel = $file.FullName.Substring($payload.Length).TrimStart('\')
        $target = Join-Path $Root $rel
        $exists = Test-Path $target
        $fileState[$rel] = $exists
        if ($exists) {
            $savedFile = Join-Path $backup (Join-Path "files" $rel)
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $savedFile) | Out-Null
            Copy-Item -LiteralPath $target -Destination $savedFile -Force
        }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath $file.FullName -Destination $target -Force
    }
    $activated = $true

    Write-Host "[4/7] Syntax and monitoring-only safety gate..." -ForegroundColor Cyan
    python -m py_compile scripts\run_analysis.py services\telegram_bot.py tests\test_monitoring_map_delivery.py
    if ($LASTEXITCODE -ne 0) { throw "Syntax validation failed" }

    # Put the temporary verifier in the project root so imports resolve under
    # Windows exactly as they do in production. This sends no Telegram message.
    $verifyPath = Join-Path $Root "verify_monitoring_map_$stamp.py"
    @'
import json
from scripts.run_analysis import _monitoring_map_delivery_gate, _planner_execution_gate
c = json.load(open("config.json", encoding="utf-8"))
plan = {
    "plan_ready": True, "session_bias": "SELL",
    "primary_entry_zone": {"low": 4397.68, "high": 4404.71},
    "primary_entry_price": 4401.19, "invalidation_level": 4406.81,
    "target_liquidity": 4340.0,
    "primary_execution": {"stop_loss": 4406.81, "tp1": 4368.07, "tp2": 4340.0},
    "primary_poi": {"details": {"liquidity": {"sell_side": [4368.07, 4340.0]}}},
    "execution_admission": {"allow": False, "support_count": 2, "opposition_count": 0, "confidence": 73.3},
    "agent_book_summary": {"matches_execution_admission": True},
}
watch = _monitoring_map_delivery_gate(plan, c)
assert watch["allow"] and watch["mode"] == "MONITORING_ONLY", watch
decision = {"decision": "SELL", "session_plan": {"plan_ready": True, "session_bias": "SELL"}, "agent_details": {
    "auction_flow": {"direction": "SELL", "confidence": 73.1},
    "price_action": {"direction": "SELL", "confidence": 73.5},
    "unified_trend": {"direction": "WAIT", "confidence": 55.2},
    "classical": {"direction": "WAIT", "confidence": 60.1},
    "smc": {"direction": "WAIT", "confidence": 29.8},
}}
execution = _planner_execution_gate(decision, c)
assert execution["allow"] is False, execution
print("MONITORING DISPLAY ALLOWED; REAL EXECUTION BLOCKED")
'@ | Set-Content -LiteralPath $verifyPath -Encoding ASCII
    try {
        python $verifyPath
        if ($LASTEXITCODE -ne 0) { throw "Monitoring-only safety verification failed" }
    } finally {
        Remove-Item -LiteralPath $verifyPath -Force -ErrorAction SilentlyContinue
    }
    Write-Host "[5/7] Running the complete isolated test suite..." -ForegroundColor Cyan
    $testExit = Invoke-IsolatedFullTests
    if ($testExit -ne 0) { throw "Full regression tests failed" }

    Write-Host "[6/7] Producing one shared live five-agent check..." -ForegroundColor Cyan
    python scripts\check_agents_now.py | Out-Host
    if ($LASTEXITCODE -ne 0) { throw "Live five-agent check failed" }

    Write-Host "[7/7] Restoring scheduled task states..." -ForegroundColor Cyan
    Restore-Tasks
    "Success $(Get-Date -Format o)" | Set-Content (Join-Path $backup "SUCCESS") -Encoding ASCII
    Write-Host "COMPLETE: two-agent maps can be displayed as MONITORING ONLY with complete levels." -ForegroundColor Green
    Write-Host "No execution rule, weight or threshold changed; monitoring cards cannot create orders." -ForegroundColor Green
    Stop-Transcript | Out-Null
    exit 0
} catch {
    $failure = $_
    Write-Host "INSTALL FAILED: $($failure.Exception.Message)" -ForegroundColor Red
    try {
        if ($activated) { Restore-Files }
        Restore-Tasks
        Write-Host "ROLLBACK COMPLETE" -ForegroundColor Yellow
    } catch {
        Write-Host "ROLLBACK ERROR: $($_.Exception.Message)" -ForegroundColor Red
    }
    try { Stop-Transcript | Out-Null } catch {}
    exit 1
}
