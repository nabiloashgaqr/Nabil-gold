# 📦 حزمة الترقية — Nabil-gold — 2026-08-19

**الاسم:** `Nabil-gold-UPGRADES-20260819.zip` · **المنصة:** VPS ويندوز + MT5 · **الفرع:** demo/mt5
**التحقق:** المجموعة الكاملة داخل الحزمة نفسها قبل الضغط — **2190 نجاح / 3 تخطٍّ / 0 فشل**
(2081 الأصلية + 43 المرحلة 1 + 37 المرحلة 2)

---

## 🆕 المرحلة 2 (هذه النسخة): وكلاء جدد + ترقية auction — كلها غير مصوّتة/مغلقة افتراضياً

| # | المكوّن | الملفات | التأثير |
|---|---|---|---|
| 1 | **SentimentAgent** — مشاعر COT + تدفقات ETF | `agents/sentiment_agent.py` + `services/aux_market_data.py` | يقرأ مراكز Money Managers من تقرير CFTC الأسبوعي الحقيقي (ذهب + نفط) + زخم GLD/IAU. انعكاسي عند الذروات بمئين على تاريخ محلي (8 أسابيع حد أدنى). **لا يصوّت أبداً** — سياق فقط |
| 2 | **VolatilityAgent** — نظام التقلب | `agents/volatility_agent.py` | ^VIX + ^GVZ (ذهب) أو ^OVX (نفط) + مئين ATR من طبقة D1. يُخرج regime + مضاعف مخاطرة مقترح (EXTREME 0.5). `apply_risk_multiplier=false` — استشاري فقط |
| 3 | **OilMacroAgent** — أساسيات النفط | `agents/oil_macro_agent.py` + قوالب `storage/oil/*.example` | مفاجأة مخزون EIA مقابل الموسمي + نبرة OPEC + فروق Brent-WTI. للذهب حيادي ببطاقة OIL-ONLY. **إلزامي قبل ترقية WTI 23/08** |
| 4 | **ترقية auction_flow لمصوّت سادس (آلية)** | `utils/helpers.py` + `services/thesis_consensus.py` | **مغلقة افتراضياً** (`auction_promotion.enabled=false`). عند التفعيل: الأوزان الخمسة تُنسب إلى 95% + auction 5%، ينضم لعائلة tape، مع حارس منع الازدواج في المسار 5. يُفعَّل بعد استيفاء معاييرك: ≥8 محسومة، hit≥50%، PF≥0.8×ذهب |
| 5 | **تحقق حي** | — | جُلب COT حقيقي من CFTC (2026-08-11) + VIX/GLD حقيقيان، والوكلاء الثلاثة عملوا فعلياً بلا تسرب تصويت |

**ملفات النفط الأسبوعية:** املأ `storage/oil/eia_weekly.json` كل أربعاء و`opec_context.json` بعد كل اجتماع — القوالب مرفقة بصيغة `.example`.

## 1) ماذا تتضمن المرحلة 1 (من التسليم السابق — ما زالت فعالة)

| # | المكوّن | التأثير |
|---|---|---|
| 1 | **طبقة ريجيم D1 الحقيقية** + بوابة RANGE | في نظام RANGE يُقبل مسار 1 فقط |
| 2 | **حارس ارتباط XAU↔WTI** | استشاري افتراضياً؛ `enforce=true` قبل ترقية النفط |
| 3 | **قاطع الهامش/الحقوق قبل الأوامر** | هامش <300% / تعرض >40% / انكماش >30% |
| 4 | **حد خسارة يومي بالدولار** | 3% إضافية فوق حد الـ450 نقطة |
| 5 | **VaR/CVaR/Sharpe/Sortino/Calmar** + **Walk-Forward** | تقارير `run_risk_analytics.py` / `run_walk_forward_report.py` |
| 6 | **ADX Wilder قانوني** + **إصلاح 999→3** + D1/W1 في mt5_feed | |

## 2) طريقة التطبيق

```powershell
# من مجلد المستودع (باورشيل عادي — ليس Admin، القاعدة رقم 1):
powershell -ExecutionPolicy Bypass -File deploy\APPLY_20260819_UPGRADES.ps1

# مع أرشفة النسخ الجذرية القديمة:
powershell -ExecutionPolicy Bypass -File deploy\APPLY_20260819_UPGRADES.ps1 -RemoveRootDuplicates

# مسار مخصص / تخطي الاختبارات:
powershell -ExecutionPolicy Bypass -File deploy\APPLY_20260819_UPGRADES.ps1 -RepoRoot C:\Nabil-gold -SkipTests
```

**السكربت يقوم تلقائياً بـ:**
1. فحوصات ما قبل (python + config.json + payload)
2. **نسخة احتياطية مؤرخة** لكل ملف معدَّل → `deploy\backups\upgrades_20260819_<وقت>\`
3. نسخ الملفات الـ22 فوق المستودع
4. حذف `__pycache__` (قاعدة التشغيل 2)
5. `py_compile` لكل ملف معدَّل
6. **تشغيل مجموعة الاختبارات كاملة** — إذا فشلت: **استرجاع تلقائي كامل** من النسخة الاحتياطية
7. إعادة تشغيل مهمة `SS_DemoLoop` (مسّت run_analysis/dynamic_risk/mt5_executor — قاعدة 2)
8. ملخص + تذكير `icacls ... /grant Users:F /T` إن ظهر WinError 5

## 3) بعد التطبيق — خطوات إلزامية للمشغل

| الخطوة | الأمر / الإجراء | الموعد |
|---|---|---|
| إغلاقات الارتباط تتراكم يومياً | تلقائي عبر التقرير اليومي (يتطلب `correlation_guard.enabled=true`) | من اليوم |
| تشغيل تقرير المخاطر | `python scripts\run_risk_analytics.py` | أسبوعياً |
| Walk-Forward | `python scripts\run_walk_forward_report.py --symbol XAU/USD --tf 15m --count 4000` | قبل قرار 21/08 |
| **تفعيل `correlation_guard.enabled=true`** في config.json | بعد أول أسبوع بيانات | قبل 21/08 |
| **`correlation_guard.enforce=true`** | بعد التحقق من عدم وجود فيتوهات خاطئة | **إلزامي قبل ترقية النفط 23/08** |
| `max_daily_loss_percent` | مراقبة أن الحد النقطي يسبق دائماً (450 نقطة) | — |
| **المرحلة 2**: املأ ملفات النفط | `storage/oil/eia_weekly.json` كل أربعاء + `opec_context.json` بعد كل اجتماع OPEC | أسبوعياً من اليوم |
| **المرحلة 2**: راقب سياق الوكلاء الجدد | تظهر بطاقات sentiment/volatility/oil_macro في market_context لكل صفقة | من اليوم |
| **المرحلة 2**: ترقية auction | فقط بعد `shadow_report --days 7` باستيفاء المعايير (≥8، hit≥50%، PF≥0.8×) ثم `auction_promotion.enabled=true` | بعد 23/08 |
| COT يبني تاريخه | تلقائي — أول إشارة تُسجَّل بعد 8 أسابيع تراكم | — |

## 4) دليل الحماية من الفشل (Fail-Safe Map)

| المكوّن | السلوك عند العطل |
|---|---|
| طبقة الريجيم | انقطاع MT5 ⇒ `regime=MT5_UNAVAILABLE` ⇒ البوابة لا تمس القرار |
| حارس الارتباط | نقص البيانات (<10 أيام) ⇒ `PASS`؛ خطأ ⇒ استشاري فقط |
| قاطع الهامش | تعذر قراءة الحساب ⇒ فتح مسموح (Fail-open) |
| الحد الدولاري | صفقة بلا قيمة دولارية ⇒ تُتخطى، لا تُقدَّر |
| الخطاف اليومي | أي خطأ ⇒ تسجيل فقط، التقرير لا ينكسر |
| SentimentAgent | لا COT/ETF ⇒ WAIT صفر ثقة مع قائمة missing؛ تاريخ <8 أسابيع ⇒ معلوماتي فقط بلا تسجيل |
| VolatilityAgent | غياب المؤشرات ⇒ UNKNOWN ومضاعف 1.0 (لا تأثير) |
| OilMacroAgent | غياب الملفات ⇒ يتخطى المدخل؛ للذهب ⇒ حيادي OIL-ONLY |
| ترقية auction | مغلقة افتراضياً؛ عند التفعيل لا تُحتسب كتصويت وتأكيد معاً (حارس الازدواج) |

## 5) التراجع اليدوي

```powershell
# انسخ محتويات مجلد النسخة الاحتياطية فوق المستودع:
Copy-Item deploy\backups\upgrades_20260819_<وقت>\* -Destination C:\Nabil-gold -Recurse -Force
```

**ملاحظة:** هذه الترقية لا تغير أي سلوك تداول افتراضي — كل البوابات الجديدة إما استشارية أو إضافية فوق القواعد القائمة. التغيير السلوكي الوحيد المباشر هو `max_consecutive_losses: 3` (توحيد مصدر الحقيقة).
