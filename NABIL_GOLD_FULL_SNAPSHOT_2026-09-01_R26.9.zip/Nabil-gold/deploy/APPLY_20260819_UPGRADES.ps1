# ============================================================================
# APPLY_20260819_UPGRADES.ps1
# Nabil-gold - Upgrade package installer (2026-08-19)
# ----------------------------------------------------------------------------
# Applies the architectural upgrade package:
#   1) D1 market-regime layer + RANGE gate          (services/market_regime.py)
#   2) Cross-asset correlation guard XAU<->WTI      (services/correlation_exposure.py)
#   3) Margin/equity circuit breaker before orders  (services/margin_guard.py)
#   4) VaR/CVaR/Sharpe analytics + dollar daily loss limit
#   5) Canonical Wilder ADX in utils.indicators
#   6) config.json: new sections + max_consecutive_losses 999 -> 3
#
# Safety: timestamped backup + automatic rollback if the test suite fails.
# Run from a NORMAL PowerShell (never admin - see FINAL_OPERATIONS_RUNBOOK).
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File deploy\APPLY_20260819_UPGRADES.ps1
#   powershell -ExecutionPolicy Bypass -File deploy\APPLY_20260819_UPGRADES.ps1 -RepoRoot C:\Nabil-gold -SkipTests
#   powershell -ExecutionPolicy Bypass -File deploy\APPLY_20260819_UPGRADES.ps1 -RemoveRootDuplicates
# ============================================================================

param(
    [string]$RepoRoot = "C:\Nabil-gold",
    [string]$PayloadDir = "",
    [switch]$SkipTests,
    [switch]$RemoveRootDuplicates,
    [switch]$NoRestartTask
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($PayloadDir)) {
    $PayloadDir = Join-Path $ScriptDir "upgrades_20260819\payload"
}
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$BackupDir = Join-Path $RepoRoot "deploy\backups\upgrades_20260819_$Stamp"

function Write-Step([string]$msg) { Write-Host "==> $msg" -ForegroundColor Cyan }
function Write-Ok([string]$msg)   { Write-Host "    [OK] $msg" -ForegroundColor Green }
function Write-Err([string]$msg)  { Write-Host "    [FAIL] $msg" -ForegroundColor Red }

# ----------------------------------------------------------------------------
Write-Step "Preflight checks"
if (-not (Test-Path $RepoRoot))            { throw "Repo root not found: $RepoRoot" }
if (-not (Test-Path (Join-Path $RepoRoot "config.json"))) { throw "config.json missing - wrong RepoRoot?" }
if (-not (Test-Path $PayloadDir))          { throw "Payload dir not found: $PayloadDir" }
if (-not (Test-Path (Join-Path $PayloadDir "config.json"))) { throw "Payload invalid: config.json missing inside payload" }

$python = (Get-Command python -ErrorAction SilentlyContinue)
if (-not $python) { throw "python not on PATH" }
$pyVer = & python --version 2>&1
Write-Ok "python: $pyVer"

# ----------------------------------------------------------------------------
$Files = @(
    "config.json",
    "utils\indicators.py",
    "utils\helpers.py",
    "agents\technical_agent.py",
    "agents\sentiment_agent.py",
    "agents\volatility_agent.py",
    "agents\oil_macro_agent.py",
    "services\market_regime.py",
    "services\correlation_exposure.py",
    "services\risk_analytics.py",
    "services\margin_guard.py",
    "services\aux_market_data.py",
    "services\thesis_consensus.py",
    "services\mt5_feed.py",
    "services\dynamic_risk.py",
    "services\telegram_bot.py",
    "services\gemini_confirm_cache.py",
    "services\mt5_executor.py",
    "scripts\run_analysis.py",
    "scripts\run_daily_report.py",
    "scripts\run_risk_analytics.py",
    "scripts\run_walk_forward_report.py",
    "scripts\map_support_report.py",
    "scripts\verify_redesign_readiness.py",
    "scripts\system_healthcheck.py",
    "tests\mt5_fake.py",
    "agents\risk_management_agent.py",
    "agents\open_trades_manager.py",
    "agents\macro_fundamental_agent.py",
    "agents\classical_agent.py",
    "agents\price_action_agent.py",
    "tests\test_market_regime_service.py",
    "tests\test_correlation_exposure_service.py",
    "tests\test_margin_guard_service.py",
    "tests\test_dollar_daily_limit.py",
    "tests\test_calculate_adx_indicators.py",
    "tests\test_regime_gate_in_analysis.py",
    "tests\test_mt5_margin_veto.py",
    "tests\test_remaining_fixes_20260819.py",
    "tests\test_map_support_report.py",
    "tests\test_verify_redesign_readiness.py",
    "tests\test_agent_fixes_20260819.py",
    "tests\test_sentiment_agent.py",
    "tests\test_volatility_agent.py",
    "tests\test_oil_macro_agent.py",
    "tests\test_auction_promotion.py",
    "storage\oil\eia_weekly.json.example",
    "storage\oil\opec_context.json.example",
    "storage\oil\README_AR.txt",
    "storage\macro\economic_events.json.example"
)

Write-Step "Backup existing files -> $BackupDir"
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
foreach ($f in $Files) {
    $src = Join-Path $RepoRoot $f
    if (Test-Path $src) {
        $dst = Join-Path $BackupDir $f
        New-Item -ItemType Directory -Path (Split-Path -Parent $dst) -Force | Out-Null
        Copy-Item $src $dst -Force
    }
}
Write-Ok "Backup complete ($($Files.Count) files checked)"

# ----------------------------------------------------------------------------
Write-Step "Copying payload files into repo"
foreach ($f in $Files) {
    $src = Join-Path $PayloadDir $f
    if (-not (Test-Path $src)) { throw "Payload file missing: $f" }
    $dst = Join-Path $RepoRoot $f
    New-Item -ItemType Directory -Path (Split-Path -Parent $dst) -Force | Out-Null
    Copy-Item $src $dst -Force
}
Write-Ok "Payload copied"

# ----------------------------------------------------------------------------
Write-Step "Clearing __pycache__ (runbook rule 2)"
Get-ChildItem -Path $RepoRoot -Directory -Recurse -Filter "__pycache__" -ErrorAction SilentlyContinue |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Write-Ok "__pycache__ cleared"

# ----------------------------------------------------------------------------
Write-Step "py_compile verification"
foreach ($f in $Files) {
    if ($f -like "*.py") {
        & python -m py_compile (Join-Path $RepoRoot $f)
        if ($LASTEXITCODE -ne 0) { throw "py_compile failed for $f" }
    }
}
Write-Ok "All changed files compile"

# ----------------------------------------------------------------------------
if (-not $SkipTests) {
    Write-Step "Running full test suite (this takes ~1-2 min)"
    Push-Location $RepoRoot
    try {
        & python -m pytest tests/ -q
        $testExit = $LASTEXITCODE
    } finally {
        Pop-Location
    }
    if ($testExit -ne 0) {
        Write-Err "Test suite failed (exit $testExit) - rolling back"
        foreach ($f in $Files) {
            $bak = Join-Path $BackupDir $f
            if (Test-Path $bak) {
                Copy-Item $bak (Join-Path $RepoRoot $f) -Force
            } else {
                Remove-Item (Join-Path $RepoRoot $f) -Force -ErrorAction SilentlyContinue
            }
        }
        Write-Err "ROLLBACK COMPLETE - system is back to the pre-upgrade state"
        exit 1
    }
    Write-Ok "Test suite passed"
} else {
    Write-Host "    [SKIP] tests skipped (-SkipTests)" -ForegroundColor Yellow
}

# ----------------------------------------------------------------------------
if ($RemoveRootDuplicates) {
    Write-Step "Archiving legacy root duplicates (runbook rule 4)"
    $dups = @("run_analysis.py", "database.py", "run_tick_manager.py")
    foreach ($d in $dups) {
        $root = Join-Path $RepoRoot $d
        if (Test-Path $root) {
            $legacy = "$root.legacy_20260819"
            Move-Item $root $legacy -Force
            Write-Ok "$d -> $d.legacy_20260819"
        }
    }
}

# ----------------------------------------------------------------------------
if (-not $NoRestartTask) {
    Write-Step "Restarting scheduled demo loop (changed run_analysis/dynamic_risk/mt5_executor)"
    $task = Get-ScheduledTask -TaskName "SS_DemoLoop" -ErrorAction SilentlyContinue
    if ($task) {
        Stop-ScheduledTask -TaskName "SS_DemoLoop" -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 3
        Start-ScheduledTask -TaskName "SS_DemoLoop"
        Write-Ok "SS_DemoLoop restarted"
    } else {
        Write-Host "    [INFO] SS_DemoLoop task not found - restart manually if named differently" -ForegroundColor Yellow
    }
}

# ----------------------------------------------------------------------------
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host " UPGRADE 2026-08-19 APPLIED SUCCESSFULLY" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host " Backup: $BackupDir"
Write-Host " Next steps:"
Write-Host "  1. Before WTI promotion (23/08): set correlation_guard.enabled=true"
Write-Host "     (enforce=true only after shadow validation)"
Write-Host "  2. Verify daily run: python scripts\run_risk_analytics.py"
Write-Host "  3. If ACL errors appear (WinError 5):"
Write-Host "     icacls `"$RepoRoot`" /grant Users:F /T"
Write-Host "  4. Rollback anytime: restore files from the backup directory"
