<#
.SYNOPSIS
    APPLY_PATCH.ps1 (v3) - extract a downloaded patch ZIP straight into the
    project folder and run the FULL test suite, with backup and automatic
    rollback.

.DESCRIPTION
    v4 change (2026-08-24, BUILD 31 R2): when the package ships a config
    merge spec (deploy\config_merge.json inside the payload, with
    deploy\apply_config_merge.py), it is applied to config.json AFTER
    extraction and BEFORE the test suite - and it is rolled back with the
    rest when tests fail. This closes the BUILD 31 failure mode where a
    law change in the code met a STALE per-instrument entry in the VPS
    config (config overrides code) and the suite rolled everything back
    for nothing.
    v3 change (2026-08-19): files are now extracted DIRECTLY from the ZIP via
    .NET ZipFile (entry-name math only). v2 used Expand-Archive + a filesystem
    walk whose relative-path computation could break on Windows PowerShell 5.1
    (short/long path mismatches), which caused "0 overwritten, 22 new" and the
    patch silently landing in a stray folder. Entry names inside a ZIP always
    use "/" separators and are exact strings, so this class of bug is gone.

    Workflow (same guarantees as v2):
      1) ZIP auto-discovery: newest .zip in Downloads (Nabil*.zip preferred),
         or use -ZipPath for an explicit file.
      2) Payload-root auto-detection from ENTRY NAMES. Handles:
           - flat zip (files at the zip root)
           - zip wrapped in one top folder (Nabil-gold-XXX/...)
           - wrapper folder + payload/ subfolder (delivery packages);
             package docs/scripts outside payload/ are never applied.
      3) Timestamped backup of every file that will be overwritten.
      4) Extract -> purge __pycache__ -> py_compile every applied .py
      5) Runs `python -m pytest tests -q` (the full suite).
      6) If tests fail: automatic ROLLBACK (overwritten files restored,
         newly added files removed).
      7) SS_DemoLoop restart only when runtime files were touched.
      8) Risky extensions (.exe .dll .msi .scr .vbs .com .bat .cmd) are
         skipped; entries with ".." (zip-slip) are rejected.

.EXAMPLE
    cd C:\Nabil-gold
    powershell -ExecutionPolicy Bypass -File deploy\APPLY_PATCH.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File deploy\APPLY_PATCH.ps1 -ZipPath "$env:USERPROFILE\Downloads\add_chain_locks.zip"

.PARAMETER ZipPath
    Explicit ZIP to apply. Default: auto-detect newest zip in Downloads.

.PARAMETER RepoRoot
    Project root. Default: current directory when it contains config.json,
    otherwise C:\Nabil-gold.

.PARAMETER Force
    Skip the confirmation prompt.

.PARAMETER SkipTests
    Apply without running the test suite (rollback guard is disabled too).

.PARAMETER NoBackup
    Skip the timestamped backup (rollback will then only delete new files).

.PARAMETER NoRestartTask
    Never restart SS_DemoLoop, even when runtime files were touched.

.PARAMETER RemoveRootDuplicates
    After a successful apply, archive the legacy root duplicates
    (run_analysis.py / database.py / run_tick_manager.py) to
    *.legacy_20260819. Production uses scripts\ and services\ - the root
    copies lack the family gate and the scale-in locks (runbook rule 4).

.NOTES
    Run from a NORMAL PowerShell, never elevated (runbook rule 1).
    If ACL errors appear: icacls "C:\Nabil-gold" /grant Users:F /T
#>
[CmdletBinding()]
param(
    [string]$ZipPath = "",
    [string]$RepoRoot = "",
    [switch]$Force,
    [switch]$SkipTests,
    [switch]$NoBackup,
    [switch]$NoRestartTask,
    [switch]$RemoveRootDuplicates
)

$ErrorActionPreference = "Stop"
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"

function Write-Step([string]$msg) { Write-Host "==> $msg" -ForegroundColor Cyan }
function Write-Ok([string]$msg)   { Write-Host "    [OK] $msg" -ForegroundColor Green }
function Write-Bad([string]$msg)  { Write-Host "    [FAIL] $msg" -ForegroundColor Red }
function Write-Warn([string]$msg) { Write-Host "    [!] $msg" -ForegroundColor Yellow }

# -----------------------------------------------------------------------------
# 1) Locate repo root
# -----------------------------------------------------------------------------
if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
    if (Test-Path (Join-Path (Get-Location) "config.json")) {
        $RepoRoot = (Get-Location).Path
    } else {
        $RepoRoot = "C:\Nabil-gold"
    }
}
if (-not (Test-Path (Join-Path $RepoRoot "config.json"))) {
    throw "config.json not found under $RepoRoot - pass -RepoRoot <project folder>"
}

# -----------------------------------------------------------------------------
# 2) Locate the ZIP
# -----------------------------------------------------------------------------
if ([string]::IsNullOrWhiteSpace($ZipPath)) {
    $dl = Join-Path $env:USERPROFILE "Downloads"
    if (-not (Test-Path $dl)) { throw "Downloads folder not found: $dl (use -ZipPath)" }
    $all = @(Get-ChildItem -Path $dl -Filter "*.zip" -ErrorAction SilentlyContinue)
    if ($all.Count -eq 0) { throw "No .zip files in $dl (use -ZipPath)" }
    $nabil = @($all | Where-Object { $_.Name -like "Nabil*" } | Sort-Object LastWriteTime -Descending)
    if ($nabil.Count -gt 0) { $ZipPath = $nabil[0].FullName }
    else { $ZipPath = ($all | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName }
    Write-Warn "Auto-detected ZIP: $ZipPath"
}
if (-not (Test-Path $ZipPath)) { throw "ZIP not found: $ZipPath" }

# -----------------------------------------------------------------------------
# 3) Preflight: python + confirmation
# -----------------------------------------------------------------------------
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "python is not on PATH"
}
$pyVer = (& python --version 2>&1 | Out-String).Trim()
Write-Ok "python: $pyVer"

Write-Step "Patch plan"
Write-Host "    ZIP  : $ZipPath"
Write-Host "    Repo : $RepoRoot"
if (-not $Force) {
    $answer = Read-Host "    Continue? (Y/N)"
    if ($answer -notmatch '^[Yy]') { Write-Host "Aborted by operator."; exit 0 }
}

# -----------------------------------------------------------------------------
# 4) Read ZIP entry names and detect the payload root (string math only)
# -----------------------------------------------------------------------------
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
try {
    $allNames = @($zip.Entries | ForEach-Object { $_.FullName })
} finally { $zip.Dispose() }

$files = @($allNames | Where-Object {
    $_ -and -not $_.EndsWith("/") -and
    $_ -notmatch "__MACOSX" -and $_ -notmatch "\.DS_Store" -and
    $_ -notmatch "__pycache__"
})
if ($files.Count -eq 0) { throw "ZIP contains no applicable files" }

# payload prefix detection: single top folder, then optional payload/ subfolder
$prefix = ""
$tops = @($files | ForEach-Object { ($_ -split "/")[0] } | Sort-Object -Unique)
if ($tops.Count -eq 1) { $prefix = "$($tops[0])/" }
$after = $files
if ($prefix) { $after = @($files | ForEach-Object { $_.Substring($prefix.Length) }) }
# payload/ subfolder convention: when present it is the authoritative repo
# mirror. Package docs/scripts sitting next to it are never applied.
if (@($after | Where-Object { $_.StartsWith("payload/") }).Count -gt 0) {
    $prefix += "payload/"
}
$inPayload = @($files | Where-Object { $_.StartsWith($prefix) })
$outPayload = @($files | Where-Object { -not $_.StartsWith($prefix) })
foreach ($s in $outPayload) { Write-Warn "Skipped package file (outside payload root): $s" }
Write-Ok "Payload root detected: '$prefix' (applying $($inPayload.Count) of $($files.Count) entries)"

if ($inPayload.Count -eq 0) { throw "ZIP contains no applicable files under the payload root" }

# -----------------------------------------------------------------------------
# 5) Build the apply list + backup existing targets (entry-name math only)
# -----------------------------------------------------------------------------
$risky = @("\.exe$", "\.dll$", "\.msi$", "\.scr$", "\.vbs$", "\.com$", "\.bat$", "\.cmd$")
$applyFiles = @()
foreach ($name in $inPayload) {
    $rel = $name.Substring($prefix.Length).Replace("/", "\").TrimStart("\")
    if ([string]::IsNullOrWhiteSpace($rel)) { continue }
    if ($rel -match '\.\.') {
        Write-Warn "REJECTED zip-slip entry: $name"
        continue
    }
    if ($risky | Where-Object { $rel -match $_ }) {
        Write-Warn "SKIPPED risky file: $rel"
        continue
    }
    $dst = Join-Path $RepoRoot $rel
    $existed = Test-Path $dst
    $applyFiles += [PSCustomObject]@{
        Rel     = $rel
        ZipName = $name
        Dst     = $dst
        Existed = $existed
    }
}
if ($applyFiles.Count -eq 0) { throw "ZIP contains no applicable files (all filtered out)" }
Write-Ok "Staged $($applyFiles.Count) files"

# Anomaly guard: files that MUST pre-exist in a healthy repo. If none of them
# do, the operator is almost certainly pointing at the wrong repo.
$expectedExisting = @("config.json", "utils\indicators.py", "agents\technical_agent.py", "scripts\run_analysis.py")
$missingPre = @($applyFiles | Where-Object { ($expectedExisting -contains $_.Rel) -and (-not $_.Existed) })
if ($missingPre.Count -eq $expectedExisting.Count) {
    Write-Warn "None of the expected repo files (config.json, utils\indicators.py, agents\technical_agent.py, scripts\run_analysis.py) pre-existed - is -RepoRoot correct?"
}

$BackupDir = Join-Path $RepoRoot "deploy\backups\patch_$Stamp"
$overwrites = 0
if (-not $NoBackup) {
    foreach ($f in $applyFiles) {
        if ($f.Existed) {
            $bak = Join-Path $BackupDir $f.Rel
            New-Item -ItemType Directory -Path (Split-Path -Parent $bak) -Force | Out-Null
            Copy-Item $f.Dst $bak -Force
            $overwrites++
        }
    }
    Write-Ok "Backup ready ($overwrites files) -> $BackupDir"
} else {
    Write-Warn "Backup skipped (-NoBackup). Rollback will only delete newly added files."
}

# -----------------------------------------------------------------------------
# 6) Extract directly from the ZIP into the repo
# -----------------------------------------------------------------------------
function Invoke-Rollback {
    Write-Step "ROLLING BACK"
    foreach ($f in $applyFiles) {
        if ($f.Existed -and -not $NoBackup) {
            Copy-Item (Join-Path $BackupDir $f.Rel) $f.Dst -Force -ErrorAction SilentlyContinue
            Write-Host "    restored: $($f.Rel)"
        } elseif ($f.Existed) {
            Write-Warn "cannot restore $($f.Rel) (no backup was taken)"
        } else {
            Remove-Item $f.Dst -Force -ErrorAction SilentlyContinue
            Write-Host "    removed new file: $($f.Rel)"
        }
    }
    # v4: the config merge (if it ran) rolls back with everything else.
    if ($ConfigBak -and (Test-Path $ConfigBak)) {
        Copy-Item $ConfigBak (Join-Path $RepoRoot "config.json") -Force
        Write-Host "    restored: config.json"
    }
    Write-Bad "ROLLBACK COMPLETE - repo is back to the pre-patch state"
}

Write-Step "Applying $($applyFiles.Count) files"
$zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
$applyError = $null
try {
    foreach ($f in $applyFiles) {
        try {
            $entry = $zip.GetEntry($f.ZipName)
            if ($null -eq $entry) { throw "entry not found: $($f.ZipName)" }
            New-Item -ItemType Directory -Path (Split-Path -Parent $f.Dst) -Force | Out-Null
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $f.Dst, $true)
        } catch {
            $applyError = $_.Exception.Message
            Write-Bad "extract failed for $($f.Rel): $applyError"
            if ($applyError -match "Access to the path|UnauthorizedAccess|denied") {
                Write-Warn "ACL hint: run  icacls `"$RepoRoot`" /grant Users:F /T  then retry"
            }
            break
        }
    }
} finally {
    $zip.Dispose()
}
if ($applyError) {
    Invoke-Rollback
    exit 1
}
Write-Ok "All files extracted"

# -----------------------------------------------------------------------------
# 7) Purge __pycache__ + py_compile every applied .py
# -----------------------------------------------------------------------------
Write-Step "Purging __pycache__ (runbook rule 2)"
$purged = @(Get-ChildItem $RepoRoot -Recurse -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue)
foreach ($d in $purged) { Remove-Item $d.FullName -Recurse -Force -ErrorAction SilentlyContinue }
Write-Ok "purged $($purged.Count) __pycache__ folders"

Write-Step "py_compile verification"
foreach ($f in $applyFiles) {
    if ($f.Rel -match "\.py$") {
        & python -m py_compile $f.Dst
        if ($LASTEXITCODE -ne 0) {
            Write-Bad "py_compile failed for $($f.Rel)"
            Invoke-Rollback
            exit 1
        }
    }
}
Write-Ok "all applied .py files compile"

# -----------------------------------------------------------------------------
# 7b) v4 (BUILD 31 R2): apply the package's config merge BEFORE the tests
# -----------------------------------------------------------------------------
# The VPS config.json OVERRIDES code defaults. A patch carrying new law
# values must also land them in config.json before the suite runs, or the
# tests fail on the stale config and roll back the whole patch.
$ConfigBak = $null
$shipsSpec = @($applyFiles | Where-Object { $_.Rel -eq "deploy\config_merge.json" }).Count -gt 0
$shipsTool = @($applyFiles | Where-Object { $_.Rel -eq "deploy\apply_config_merge.py" }).Count -gt 0
$specOnDisk = Join-Path $RepoRoot "deploy\config_merge.json"
$toolOnDisk = Join-Path $RepoRoot "deploy\apply_config_merge.py"
if ($shipsSpec -and (Test-Path $specOnDisk) -and ($shipsTool -and (Test-Path $toolOnDisk) -or (Test-Path $toolOnDisk))) {
    Write-Step "Applying config merge: deploy\config_merge.json (v4)"
    New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
    $ConfigBak = Join-Path $BackupDir "config.json"
    Copy-Item (Join-Path $RepoRoot "config.json") $ConfigBak -Force
    & python $toolOnDisk --config (Join-Path $RepoRoot "config.json") --spec $specOnDisk
    if ($LASTEXITCODE -ne 0) {
        Write-Bad "config merge failed"
        Invoke-Rollback
        exit 1
    }
    Write-Ok "config merge applied (backup: $ConfigBak)"
}

# -----------------------------------------------------------------------------
# 8) Full test suite
# -----------------------------------------------------------------------------
$testExit = 0
if (-not $SkipTests) {
    Write-Step "Running FULL test suite: python -m pytest tests -q"
    Push-Location $RepoRoot
    try {
        & python -m pytest tests -q
        $testExit = $LASTEXITCODE
    } finally {
        Pop-Location
    }
    if ($testExit -ne 0) {
        Write-Bad "pytest exited with $testExit"
        Invoke-Rollback
        exit 1
    }
    Write-Ok "test suite passed"
} else {
    Write-Warn "tests skipped (-SkipTests) - no safety net on this patch"
}

# -----------------------------------------------------------------------------
# 9) Archive legacy root duplicates (optional, after a green test suite)
# -----------------------------------------------------------------------------
if ($RemoveRootDuplicates) {
    Write-Step "Archiving legacy root duplicates (runbook rule 4)"
    foreach ($dup in @("run_analysis.py", "database.py", "run_tick_manager.py")) {
        $root = Join-Path $RepoRoot $dup
        if (Test-Path $root) {
            $target = "$root.legacy_20260819"
            if (Test-Path $target) { $target = "$root.legacy_20260819_$Stamp" }
            Move-Item $root $target -Force
            Write-Ok "$dup -> $(Split-Path $target -Leaf)"
        }
    }
}

# -----------------------------------------------------------------------------
# 10) Restart SS_DemoLoop if runtime files were touched
# -----------------------------------------------------------------------------
$runtimePattern = "(run_analysis|run_trade_updates|run_tick_manager|tick_manager|run_demo_loop|open_trades_manager|dynamic_risk|mt5_executor|mt5_feed)\.py$"
$runtimeHits = @($applyFiles | Where-Object { $_.Rel -match $runtimePattern })
if ($runtimeHits.Count -gt 0 -and -not $NoRestartTask) {
    if (-not (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue)) {
        Write-Warn "runtime files touched but Get-ScheduledTask is unavailable - restart SS_DemoLoop manually"
    } else {
        $task = Get-ScheduledTask -TaskName "SS_DemoLoop" -ErrorAction SilentlyContinue
        if ($task) {
            Stop-ScheduledTask -TaskName "SS_DemoLoop" -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 3
            Start-ScheduledTask -TaskName "SS_DemoLoop"
            Write-Ok "SS_DemoLoop restarted (runtime files touched)"
        } else {
            Write-Warn "runtime files touched but SS_DemoLoop task not found - restart manually"
        }
    }
}

# -----------------------------------------------------------------------------
# 10) Summary
# -----------------------------------------------------------------------------
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host " PATCH APPLIED SUCCESSFULLY" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host " ZIP        : $ZipPath"
Write-Host " Files      : $($applyFiles.Count) applied ($overwrites overwritten, $($applyFiles.Count - $overwrites) new)"
if (-not $NoBackup) { Write-Host " Backup     : $BackupDir" }
Write-Host " Tests      : $(if ($SkipTests) {'SKIPPED'} else {'FULL SUITE - PASSED'})"
Write-Host ""
Write-Host " Manual rollback anytime:"
Write-Host "   Copy-Item `"$BackupDir\*`" -Destination `"$RepoRoot`" -Recurse -Force"
if (-not $SkipTests) {
    Write-Host " Quick re-verify anytime:"
    Write-Host "   python -m pytest tests -q"
}
