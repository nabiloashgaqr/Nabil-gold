# PATH 4 - SMC Conditional Map + Auction Flow.
# Demo-only. No tick download or calibration rebuild. Existing weights, 67/72, stops and targets remain unchanged.
param([string]$Root = "C:\Nabil-gold")
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$release = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = if (Test-Path (Join-Path $release "payload")) {
    Join-Path $release "payload"
} elseif (Test-Path (Join-Path $release "..\payload")) {
    (Resolve-Path (Join-Path $release "..\payload")).Path
} else {
    throw "Payload directory not found next to installer"
}

if (-not (Test-Path $Root)) { throw "Project root not found: $Root" }
if (-not (Test-Path (Join-Path $payload "services\execution_paths.py"))) {
    throw "Payload missing services\execution_paths.py"
}
if (-not (Test-Path (Join-Path $payload "tests\test_path4_execution_and_measurement.py"))) {
    throw "Payload missing Path 4 regression tests"
}
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run PowerShell as Administrator"
}

Set-Location $Root
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backup = Join-Path $Root "storage\deployment_backups\path4_smc_map_auction_$stamp"
New-Item -ItemType Directory -Force -Path $backup | Out-Null
Start-Transcript -Path (Join-Path $backup "install.log") -Force | Out-Null

$taskNames = @("SS_DemoWatchdog", "SS_DemoAnalysis", "SS_TickManager")
$taskState = @{}
$fileState = @{}
$activated = $false

function Save-And-Stop-Tasks {
    foreach ($name in $taskNames) {
        $task = Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
        if (-not $task) { continue }
        $taskState[$name] = @{
            Enabled = ($task.Settings.Enabled -ne $false)
            WasRunning = ($task.State -eq "Running")
        }
        try { Stop-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue } catch {}
        Disable-ScheduledTask -TaskName $name | Out-Null
    }
}

function Restore-Tasks {
    foreach ($name in $taskNames) {
        if (-not $taskState.ContainsKey($name)) { continue }
        try {
            if ($taskState[$name].Enabled) {
                Enable-ScheduledTask -TaskName $name | Out-Null
            } else {
                Disable-ScheduledTask -TaskName $name | Out-Null
            }
            if ($taskState[$name].WasRunning) {
                Start-ScheduledTask -TaskName $name
            }
        } catch {
            Write-Warning "Could not restore task $name : $($_.Exception.Message)"
        }
    }
}

function Restore-Files {
    foreach ($rel in $fileState.Keys) {
        $target = Join-Path $Root $rel
        $saved = Join-Path $backup (Join-Path "files" $rel)
        if ($fileState[$rel]) {
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
            Copy-Item -LiteralPath $saved -Destination $target -Force
        } elseif (Test-Path $target) {
            Remove-Item -LiteralPath $target -Force
        }
    }
}

function Invoke-IsolatedFullTests {
    # Run from a clean copy OUTSIDE C:\Nabil-gold. Running pytest in the live
    # tree lets python-dotenv reload real Telegram/MT5/Supabase values and lets
    # recursive source tests inspect deployment_backups as if they were live
    # source files. Both produce false failures unrelated to this patch.
    $testRoot = Join-Path ([IO.Path]::GetTempPath()) "NabilGoldCleanTest_$stamp"
    $saved = @{}
    $names = @{
        "EXECUTION_MODE" = $true
        "DATA_SOURCE_PRIMARY" = $true
        "TRADES_TABLE" = $true
        "TELEGRAM_BOT_TOKEN" = $true
        "TELEGRAM_CHAT_ID" = $true
        "TELEGRAM_DEMO_CHAT_ID" = $true
        "SUPABASE_URL" = $true
        "SUPABASE_KEY" = $true
        "GEMINI_API_KEY" = $true
        "PYTHON_DOTENV_DISABLED" = $true
        "PYTEST_RUNNING" = $true
    }
    # Block every key present in the live .env without reading or printing its
    # value. Empty process variables are considered already defined, so
    # load_dotenv(override=False) cannot refill them in the child process.
    $envFile = Join-Path $Root ".env"
    if (Test-Path $envFile) {
        foreach ($line in Get-Content -LiteralPath $envFile) {
            if ([string]$line -match '^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=') {
                $names[$matches[1]] = $true
            }
        }
    }

    try {
        Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction SilentlyContinue
        New-Item -ItemType Directory -Force -Path $testRoot | Out-Null
        $copyArgs = @(
            $Root, $testRoot, "/E", "/R:1", "/W:1", "/NFL", "/NDL",
            "/NJH", "/NJS", "/NP",
            "/XD", ".git", ".venv", "__pycache__", ".pytest_cache",
            ".mypy_cache", ".arena", "node_modules", "storage",
            "diagnostics", "rounds", "reports", "build", "dist", "coverage",
            "/XF", ".env", "*.pyc", "*.pyo", "*.log", "*.pid"
        )
        & robocopy @copyArgs | Out-Null
        $copyExit = $LASTEXITCODE
        if ($copyExit -ge 8) { throw "Clean test copy failed with robocopy code $copyExit" }

        # One committed analyst label is a deliberate test fixture. Copy only
        # those fixtures, never runtime trades, SQLite, calibrations or backups.
        $testStorage = Join-Path $testRoot "storage"
        New-Item -ItemType Directory -Force -Path $testStorage | Out-Null
        $labelFiles = Get-ChildItem -LiteralPath (Join-Path $Root "storage") -File -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -like "*_analyst_label.csv" -or
                $_.Name -like "analyst_labels_*.json"
            }
        foreach ($label in $labelFiles) {
            Copy-Item -LiteralPath $label.FullName -Destination $testStorage -Force
        }
        if (-not $labelFiles) { throw "Clean test sandbox has no analyst-label fixture" }

        foreach ($name in $names.Keys) {
            $saved[$name] = [Environment]::GetEnvironmentVariable($name, "Process")
            [Environment]::SetEnvironmentVariable($name, "", "Process")
        }
        [Environment]::SetEnvironmentVariable("PYTHON_DOTENV_DISABLED", "1", "Process")
        [Environment]::SetEnvironmentVariable("PYTEST_RUNNING", "true", "Process")

        Set-Location $testRoot
        & python -m pytest -q | Out-Host
        $testExit = $LASTEXITCODE
        return $testExit
    } finally {
        Set-Location $Root
        foreach ($name in $saved.Keys) {
            [Environment]::SetEnvironmentVariable($name, $saved[$name], "Process")
        }
        Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
try {
    Write-Host "[1/7] Verifying Demo mode and existing runtime artifacts..." -ForegroundColor Cyan
    python -c "import json; c=json.load(open('config.json',encoding='utf-8')); assert c.get('trading_mode')=='mt5_demo', c.get('trading_mode'); print('DEMO MODE OK')"
    if ($LASTEXITCODE -ne 0) { throw "Demo-only guard failed" }
    foreach ($rel in @(
        "storage\model_calibration\unified_trend_v1.json",
        "storage\model_calibration\auction_flow_v1.json",
        "storage\auction_flow.sqlite3"
    )) {
        if (-not (Test-Path (Join-Path $Root $rel))) {
            throw "Existing runtime artifact missing: $rel"
        }
    }

    Write-Host "[2/7] Stopping scheduled writers safely..." -ForegroundColor Cyan
    Save-And-Stop-Tasks
    Write-Host "SS_TickManager is stopped/restarted only through Task Scheduler; no parallel manual loop is launched." -ForegroundColor DarkGray

    Write-Host "[3/7] Backing up and applying payload..." -ForegroundColor Cyan
    $files = Get-ChildItem $payload -Recurse -File | Where-Object {
        -not $_.FullName.EndsWith(".env") -and
        -not $_.FullName.EndsWith(".sqlite3") -and
        (-not $_.FullName.EndsWith(".json") -or $_.Name -eq "config.json")
    }
    foreach ($file in $files) {
        $rel = $file.FullName.Substring($payload.Length).TrimStart('\')
        $target = Join-Path $Root $rel
        $exists = Test-Path $target
        $fileState[$rel] = $exists
        if ($exists) {
            $savedFile = Join-Path $backup (Join-Path "files" $rel)
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $savedFile) | Out-Null
            Copy-Item -LiteralPath $target -Destination $savedFile -Force
        }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath $file.FullName -Destination $target -Force
    }
    $activated = $true

    Write-Host "[4/7] Syntax and exact Path 4 regression..." -ForegroundColor Cyan
    python -m py_compile agents\open_trades_manager.py services\execution_paths.py services\path_performance.py services\thesis_consensus.py services\session_planner.py services\telegram_bot.py services\database.py scripts\run_analysis.py scripts\run_tick_manager.py scripts\summarize_execution_paths.py tests\test_path4_execution_and_measurement.py
    if ($LASTEXITCODE -ne 0) { throw "Syntax validation failed" }

    # Exact non-trading verifier: no Telegram, no MT5 order, no tick/calibration work.
    $verifyPath = Join-Path $Root "verify_path4_$stamp.py"
    @'
import json
from services.thesis_consensus import evaluate_directional_admission
from services.execution_paths import PATH_4, stamp_execution_path
c=json.load(open("config.json",encoding="utf-8"))
book={
 "unified_trend":{"signal":"WAIT","confidence":51},
 "classical":{"signal":"WAIT","confidence":55},
 "smc":{"signal":"WAIT","confidence":52,"market_structure":{"structure_quality":"STRONG"},"setup_structure":{
   "id":"VERIFY_PATH4","state_key":"VERIFY_PATH4_STATE","direction":"SELL","quality_score":63,
   "return_probability_score":70.2,"thesis_dominance_score":77.1,"trigger_score":76,
   "trigger_ready":True,"entry_price":4401.19,"details":{"structure_quality":"STRONG"}}},
 "price_action":{"signal":"WAIT","confidence":50},
 "auction_flow":{"signal":"SELL","confidence":80},
}
r=evaluate_directional_admission("SELL",book,c)
assert r["allow"] and r["path"]=="SMC_MAP_AUCTION_CONFIRMATION", r
assert r["supporters"]==["auction_flow"] and r["smc_map_counted_as_vote"] is False, r
assert r["order_policy"]=="LIMIT_ONLY_AT_SMC_POI", r
d={}; stamp_execution_path(d,r); assert d["execution_path_id"]==PATH_4, d
book["price_action"]={"signal":"BUY","confidence":67}
blocked=evaluate_directional_admission("SELL",book,c)
assert not blocked["allow"] and blocked["opponents"]==["price_action"], blocked
print("PATH 4 EXACT REGRESSION: PASS")
'@ | Set-Content -LiteralPath $verifyPath -Encoding ASCII
    try {
        python $verifyPath
        if ($LASTEXITCODE -ne 0) { throw "Path 4 exact verifier failed" }
    } finally {
        Remove-Item -LiteralPath $verifyPath -Force -ErrorAction SilentlyContinue
    }
    Write-Host "[5/7] Running the complete isolated test suite..." -ForegroundColor Cyan
    $testExit = Invoke-IsolatedFullTests
    if ($testExit -ne 0) { throw "Full regression tests failed" }

    Write-Host "[6/7] Verifying four-path measurement command..." -ForegroundColor Cyan
    python -c "from services.execution_paths import PATH_DEFINITIONS; from services.path_performance import summarize_paths; s=summarize_paths([]); assert len(PATH_DEFINITIONS)==4 and len(s['paths'])==4; print('FOUR-PATH MEASUREMENT: PASS')"
    if ($LASTEXITCODE -ne 0) { throw "Four-path measurement verification failed" }

    Write-Host "[7/7] Restoring scheduled task states..." -ForegroundColor Cyan
    Restore-Tasks
    "Success $(Get-Date -Format o)" | Set-Content (Join-Path $backup "SUCCESS") -Encoding ASCII
    Write-Host "COMPLETE: PATH 4 - SMC CONDITIONAL MAP + AUCTION FLOW is active on Demo." -ForegroundColor Green
    Write-Host "All trade lifecycle cards carry the path name; four-path measurement is ready." -ForegroundColor Green
    Write-Host "No tick download/calibration rebuild. Existing weights, 67/72, stops and targets are unchanged." -ForegroundColor Green
    Stop-Transcript | Out-Null
    exit 0
} catch {
    $failure = $_
    Write-Host "INSTALL FAILED: $($failure.Exception.Message)" -ForegroundColor Red
    try {
        if ($activated) { Restore-Files }
        Restore-Tasks
        Write-Host "ROLLBACK COMPLETE" -ForegroundColor Yellow
    } catch {
        Write-Host "ROLLBACK ERROR: $($_.Exception.Message)" -ForegroundColor Red
    }
    try { Stop-Transcript | Out-Null } catch {}
    exit 1
}
