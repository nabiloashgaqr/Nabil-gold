#Requires -Version 5.1
<#
.SYNOPSIS
    BUILD 31 R10 (post-audit fixes) installer - the SINGLE command.
.DESCRIPTION
    Idempotent. Safe to re-run. Steps:
      1) locate the R10 files-ONLY package (repo root or Downloads) and
         extract it OVER the repo root (paths inside the zip are repo-relative)
      2) pip install tzdata (ZoneInfo("Asia/Hebron") on Windows needs it)
      3) python scripts\verify_r10_fixes.py  (self-healing: auto-migrates
         legacy storage\shadow into storage\archive\shadow_20260827)
      4) run the FULL pytest suite
    Any pytest failure after step 4 is printed, but the migration and the
    fix audit already ran - re-run this installer any time.
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File C:\Nabil-gold\deploy\install_build31_r10.ps1
#>
$ErrorActionPreference = "Continue"

$RepoRoot = Split-Path $PSScriptRoot -Parent
if (-not (Test-Path (Join-Path $RepoRoot "config.json"))) { $RepoRoot = "C:\Nabil-gold" }
if (-not (Test-Path (Join-Path $RepoRoot "config.json"))) { throw "config.json not found (is the repo at C:\Nabil-gold?)" }
Set-Location $RepoRoot
Write-Host "==> Repo root: $RepoRoot" -ForegroundColor Cyan

# 1) locate + extract the package
$zip = $null
$cands = @((Join-Path $RepoRoot "Nabil-gold-R10-FIXED-FILES-ONLY*.zip"),
          (Join-Path $env:USERPROFILE "Downloads\Nabil-gold-R10-FIXED-FILES-ONLY*.zip"))
foreach ($pattern in $cands) {
    $hit = @(Get-ChildItem $pattern -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    if ($hit.Count -gt 0) { $zip = $hit[0]; break }
}
if ($zip) {
    Write-Host "==> Extracting package: $($zip.FullName)" -ForegroundColor Cyan
    Expand-Archive $zip.FullName -DestinationPath $RepoRoot -Force
    Write-Host "[OK] files extracted over the repo root." -ForegroundColor Green
} else {
    Write-Host "[SKIP] no Nabil-gold-R10-FIXED-FILES-ONLY*.zip found - assuming files were copied already." -ForegroundColor Yellow
}

# 2) tzdata for ZoneInfo on Windows
Write-Host "==> Installing tzdata (IANA database for Windows ZoneInfo)..." -ForegroundColor Cyan
python -m pip install --quiet "tzdata>=2024.1" 2>$null
if ($LASTEXITCODE -eq 0) { Write-Host "[OK] tzdata ready." -ForegroundColor Green }
else { Write-Host "[WARN] tzdata install failed - ZoneInfo may fall back incorrectly." -ForegroundColor Yellow }

# 3) fix audit (self-healing migration included)
Write-Host "==> Verifying R10 fixes (self-healing)..." -ForegroundColor Cyan
python scripts\verify_r10_fixes.py
$audit = $LASTEXITCODE

# 4) full test suite
Write-Host "==> Running the FULL pytest suite..." -ForegroundColor Cyan
python -m pytest tests -q --tb=short -p no:cacheprovider
$tests = $LASTEXITCODE

Write-Host "==================================================================" 
if ($audit -eq 0 -and $tests -eq 0) {
    Write-Host "[DONE] BUILD 31 R10 installed and verified. 14/14 + full suite green." -ForegroundColor Green
} else {
    Write-Host "[ATTENTION] audit=$audit tests=$tests - read the output above." -ForegroundColor Yellow
}
Write-Host "=================================================================="
