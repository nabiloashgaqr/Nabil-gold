#Requires -Version 5.1
<#
.SYNOPSIS
    BUILD 31 R11 (LOCAL-ONLY) installer - the SINGLE command for this package.
.DESCRIPTION
      1) locate Nabil-gold-R11*.zip (repo root or Downloads) and extract it
         OVER the repo root (paths inside the zip are repo-relative)
      2) delete every GitHub / Supabase / Vercel artifact
      3) python APPLY_R11_PATCH.py (config local, .env sanitized with backup,
         tests fixed, storage\shadow auto-migrated)
      4) run the FULL pytest suite
    Idempotent. If the zip is missing, steps 2-4 still run on the current tree.
.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File C:\Nabil-gold\deploy\install_build31_r11.ps1
#>
$ErrorActionPreference = "Continue"

$RepoRoot = Split-Path $PSScriptRoot -Parent
if (-not (Test-Path (Join-Path $RepoRoot "config.json"))) { $RepoRoot = "C:\Nabil-gold" }
if (-not (Test-Path (Join-Path $RepoRoot "config.json"))) { throw "config.json not found (is the repo at C:\Nabil-gold?)" }
Set-Location $RepoRoot
Write-Host "==> Repo root: $RepoRoot" -ForegroundColor Cyan

$zip = $null
$cands = @((Join-Path $RepoRoot "Nabil-gold-R11*.zip"),
          (Join-Path $env:USERPROFILE "Downloads\Nabil-gold-R11*.zip"))
foreach ($pattern in $cands) {
    $hit = @(Get-ChildItem $pattern -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    if ($hit.Count -gt 0) { $zip = $hit[0]; break }
}
if ($zip) {
    Write-Host "==> Extracting package: $($zip.FullName)" -ForegroundColor Cyan
    Expand-Archive $zip.FullName -DestinationPath $RepoRoot -Force
    Write-Host "[OK] files extracted over the repo root." -ForegroundColor Green
} else {
    Write-Host "[SKIP] no Nabil-gold-R11*.zip in repo root or Downloads - applying on the current tree." -ForegroundColor Yellow
}

# delete cloud-era artifacts
$dirs  = @(".github", "api", "dashboard\api")
$files = @(
  "deploy\GITHUB_SHUTDOWN_AR.md",
  "INSTALL_AUTO_UPDATER.bat", "deploy\install_auto_updater.ps1", "deploy\tasks\auto_update.bat",
  "scripts\migrate_supabase_to_local.py", "tests\test_local_migration.py",
  "tests\test_dashboard_api_leak.py",
  "SUPABASE_VERIFICATION_CHECKLIST.sql", "FIX_BACKFILL_CLOSED_AT.sql",
  "FIX_EXIT_WARNING_COLUMN_TYPE.sql", "PHASE6_ANALYST_DISTILLATION_MIGRATION.sql",
  "VERIFY_ALL_COLUMNS.sql", "supabase_schema_unified.sql", "deploy\trades_demo.sql",
  "subscription_bot\supabase_schema.sql",
  "tests\test_exit_warning_column_is_text.py", "tests\test_schema_has_partial_booking_columns.py"
)
$removed = 0
foreach ($d in $dirs) { $p = Join-Path $RepoRoot $d; if (Test-Path $p) { Remove-Item $p -Recurse -Force -ErrorAction SilentlyContinue; $removed++ } }
foreach ($f in $files) { $p = Join-Path $RepoRoot $f; if (Test-Path $p) { Remove-Item $p -Force -ErrorAction SilentlyContinue; $removed++ } }
Write-Host "[OK] cloud artifacts deleted ($removed items)." -ForegroundColor Green

Write-Host "==> Applying the R11 local-only patch..." -ForegroundColor Cyan
python APPLY_R11_PATCH.py
$patch = $LASTEXITCODE

Write-Host "==> FULL pytest suite..." -ForegroundColor Cyan
python -m pytest tests -q --tb=short -p no:cacheprovider
$tests = $LASTEXITCODE

Write-Host "=================================================================="
if ($patch -eq 0 -and $tests -eq 0) {
    Write-Host "[DONE] BUILD 31 R11 LOCAL-ONLY installed and verified." -ForegroundColor Green
} else {
    Write-Host "[ATTENTION] patch=$patch tests=$tests - read the output above." -ForegroundColor Yellow
}
Write-Host "=================================================================="
