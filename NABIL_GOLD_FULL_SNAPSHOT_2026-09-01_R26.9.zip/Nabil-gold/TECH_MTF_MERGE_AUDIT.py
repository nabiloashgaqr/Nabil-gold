"""Read-only evidence audit before merging Technical + Multi-Timeframe.

Sources:
1) storage/trades.json (agent votes + realized outcomes),
2) storage/session_plans.json (recent decision snapshots with agent_opinions),
3) one current read-only MT5 analysis.

No DB mutation, Telegram message, or broker order is performed.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import statistics
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(r"C:\Nabil-gold")
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env", override=False)
except Exception:
    pass
os.environ["DATA_SOURCE_PRIMARY"] = "mt5"
os.environ["EXECUTION_MODE"] = "mt5_demo"
os.environ["TRADES_TABLE"] = "trades_demo"

from agents.multitimeframe_agent import MultiTimeframeAgent
from agents.technical_agent import TechnicalAgent
from scripts.run_analysis import run_agent
from services.market_data import MarketDataService
from services.market_snapshot import build_market_snapshot
from utils.helpers import load_config
from utils.instruments import config_for_instrument

DIRECTIONAL = {"BUY", "SELL"}
CLOSED = {"TP2_HIT", "SL_HIT", "TRAILING_SL_HIT", "BE_HIT", "EXPIRED", "THESIS_EXIT", "MANUAL_CLOSE", "CLOSED"}


def parse_dt(value: Any):
    try:
        d = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return d.replace(tzinfo=timezone.utc) if d.tzinfo is None else d.astimezone(timezone.utc)
    except Exception:
        return None


def direction(value: Any) -> str:
    d = str(value or "WAIT").upper()
    return "WAIT" if d in {"NEUTRAL", "HOLD", "NO_TRADE", "NONE", ""} else d


def f(value: Any, default=0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    value = row.get("signal_snapshot") or {}
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except Exception:
            value = {}
    return value if isinstance(value, dict) else {}


def detail_from_map(details: Dict[str, Any], key: str) -> Dict[str, Any]:
    d = details.get(key) or {}
    if not isinstance(d, dict):
        return {}
    return {
        "direction": direction(d.get("direction") or d.get("signal")),
        "confidence": f(d.get("confidence")),
        "summary": str(d.get("summary") or ""),
    }


def details_from_plan(row: Dict[str, Any]) -> Dict[str, Any]:
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else row
    opinions = payload.get("agent_opinions") or []
    if isinstance(opinions, list):
        return {str(x.get("key") or x.get("agent") or ""): x for x in opinions if isinstance(x, dict)}
    return {}


def pnl_of(row: Dict[str, Any]) -> float:
    for key in ("pnl_points", "final_pnl_points", "final_pnl", "current_pnl_points", "current_pnl"):
        if row.get(key) is not None:
            return f(row.get(key))
    return 0.0


def core_details(raw: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    return {name: detail_from_map(raw, name) for name in
            ("technical", "multitimeframe", "classical", "smc", "price_action")}


def live_sample(config: Dict[str, Any]) -> Dict[str, Any] | None:
    try:
        market = MarketDataService(config)
        data = market.get_gold_data()
        if not data:
            return None
        data["verified_snapshot"] = build_market_snapshot(data, config)
        tech = run_agent("technical", TechnicalAgent(config), data)
        mtf = run_agent("multitimeframe", MultiTimeframeAgent(config), data)
        return {
            "id": "LIVE::" + datetime.now(timezone.utc).isoformat(),
            "time": datetime.now(timezone.utc).isoformat(),
            "source": "live_mt5",
            "price": data.get("current_price"),
            "details": {
                "technical": detail_from_map({"technical": tech}, "technical"),
                "multitimeframe": detail_from_map({"multitimeframe": mtf}, "multitimeframe"),
            },
        }
    except Exception as exc:
        return {"id": "LIVE_ERROR", "time": datetime.now(timezone.utc).isoformat(),
                "source": "live_mt5", "error": repr(exc), "details": {}}


def pearson(xs: List[float], ys: List[float]) -> float | None:
    if len(xs) < 3 or len(xs) != len(ys):
        return None
    mx, my = statistics.mean(xs), statistics.mean(ys)
    dx = [x - mx for x in xs]
    dy = [y - my for y in ys]
    den = math.sqrt(sum(x*x for x in dx) * sum(y*y for y in dy))
    return sum(x*y for x, y in zip(dx, dy)) / den if den else None


def correct(agent_side: str, trade_side: str, pnl: float) -> bool | None:
    if agent_side not in DIRECTIONAL or trade_side not in DIRECTIONAL or pnl == 0:
        return None
    return (agent_side == trade_side and pnl > 0) or (agent_side != trade_side and pnl < 0)


def composite(tech: Dict[str, Any], mtf: Dict[str, Any], bar: float) -> Dict[str, Any]:
    td, md = tech.get("direction", "WAIT"), mtf.get("direction", "WAIT")
    tc, mc = f(tech.get("confidence")), f(mtf.get("confidence"))
    if td in DIRECTIONAL and td == md:
        conf = tc * (20/35) + mc * (15/35)
        return {"direction": td, "confidence": round(conf, 1),
                "state": "AGREED", "qualified": conf >= bar}
    if td in DIRECTIONAL and md in DIRECTIONAL and td != md:
        return {"direction": "WAIT", "confidence": 0.0,
                "state": "CONFLICT", "qualified": False}
    lean = td if td in DIRECTIONAL else md if md in DIRECTIONAL else "WAIT"
    return {"direction": lean, "confidence": round(tc if td in DIRECTIONAL else mc if md in DIRECTIONAL else 0, 1),
            "state": "LEAN" if lean in DIRECTIONAL else "BOTH_WAIT", "qualified": False}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=30)
    ap.add_argument("--min-confidence", type=float, default=67)
    args = ap.parse_args()
    since = datetime.now(timezone.utc) - timedelta(days=max(args.days, 1))
    config = config_for_instrument(load_config(), {"symbol": "XAU/USD"})
    records: List[Dict[str, Any]] = []

    trade_path = ROOT / "storage" / "trades.json"
    trades = json.loads(trade_path.read_text(encoding="utf-8")) if trade_path.exists() else []
    for row in trades if isinstance(trades, list) else []:
        at = parse_dt(row.get("created_at") or row.get("entry_time"))
        if at and at < since:
            continue
        details = core_details((snapshot(row).get("agent_details") or {}))
        if not details["technical"] or not details["multitimeframe"]:
            continue
        records.append({
            "id": str(row.get("id")), "time": str(row.get("created_at") or row.get("entry_time") or ""),
            "source": "trade", "details": details,
            "trade_side": direction(row.get("type") or row.get("side")),
            "status": str(row.get("status") or "").upper(), "pnl": pnl_of(row),
            "closed": str(row.get("status") or "").upper() in CLOSED,
        })

    plans_path = ROOT / "storage" / "session_plans.json"
    plans = json.loads(plans_path.read_text(encoding="utf-8")) if plans_path.exists() else []
    for row in plans if isinstance(plans, list) else []:
        at = parse_dt(row.get("analysis_run_at") or row.get("created_at"))
        if at and at < since:
            continue
        details = core_details(details_from_plan(row))
        if not details["technical"] or not details["multitimeframe"]:
            continue
        records.append({
            "id": str(row.get("id")), "time": str(row.get("analysis_run_at") or row.get("created_at") or ""),
            "source": "session_plan", "details": details,
            "plan_ready": bool(row.get("plan_ready")), "plan_status": row.get("plan_status"),
        })

    live = live_sample(config)
    if live and live.get("details", {}).get("technical") and live.get("details", {}).get("multitimeframe"):
        records.append(live)

    counts = {k: 0 for k in ("same_direction", "opposite_direction", "tech_direction_mtf_wait",
                              "mtf_direction_tech_wait", "both_wait", "both_qualified_same")}
    disagreements = []
    xs, ys = [], []
    current_three = proposed_three_without_flow = 0
    current_accept_proposed_loses = []
    outcome = {"technical": [0, 0], "multitimeframe": [0, 0], "composite": [0, 0],
               "tech_only_correct": 0, "mtf_only_correct": 0}

    for rec in records:
        d = rec["details"]
        t, m = d["technical"], d["multitimeframe"]
        td, md = t.get("direction", "WAIT"), m.get("direction", "WAIT")
        tc, mc = f(t.get("confidence")), f(m.get("confidence"))
        xs.append(tc); ys.append(mc)
        comp = composite(t, m, args.min_confidence)
        rec["trend_composite_57_43"] = comp
        if td in DIRECTIONAL and md in DIRECTIONAL:
            if td == md:
                counts["same_direction"] += 1
                if tc >= args.min_confidence and mc >= args.min_confidence:
                    counts["both_qualified_same"] += 1
            else:
                counts["opposite_direction"] += 1
                disagreements.append(rec)
        elif td in DIRECTIONAL:
            counts["tech_direction_mtf_wait"] += 1
        elif md in DIRECTIONAL:
            counts["mtf_direction_tech_wait"] += 1
        else:
            counts["both_wait"] += 1

        qualified = {}
        for name, detail in d.items():
            side = detail.get("direction", "WAIT")
            if side in DIRECTIONAL and f(detail.get("confidence")) >= args.min_confidence:
                qualified.setdefault(side, []).append(name)
        before = any(len(v) >= 3 for v in qualified.values())
        if before:
            current_three += 1
        proposed = {"BUY": 0, "SELL": 0}
        if comp["qualified"]:
            proposed[comp["direction"]] += 1
        for name in ("classical", "smc", "price_action"):
            detail = d.get(name) or {}
            side = detail.get("direction", "WAIT")
            if side in DIRECTIONAL and f(detail.get("confidence")) >= args.min_confidence:
                proposed[side] += 1
        after = max(proposed.values()) >= 3
        if after:
            proposed_three_without_flow += 1
        if before and not after:
            current_accept_proposed_loses.append(rec)

        if rec.get("closed"):
            pnl, trade_side = f(rec.get("pnl")), rec.get("trade_side", "WAIT")
            ct, cm, cc = correct(td, trade_side, pnl), correct(md, trade_side, pnl), correct(comp["direction"], trade_side, pnl)
            for name, val in (("technical", ct), ("multitimeframe", cm), ("composite", cc)):
                if val is not None:
                    outcome[name][1] += 1
                    outcome[name][0] += int(val)
            if ct is True and cm is False: outcome["tech_only_correct"] += 1
            if cm is True and ct is False: outcome["mtf_only_correct"] += 1

    total = len(records)
    both_directional = counts["same_direction"] + counts["opposite_direction"]
    agreement_rate = counts["same_direction"] / both_directional * 100 if both_directional else 0
    corr = pearson(xs, ys)
    accuracy = {}
    for name in ("technical", "multitimeframe", "composite"):
        wins, n = outcome[name]
        accuracy[name] = {"correct": wins, "samples": n,
                          "accuracy_pct": round(wins/n*100, 1) if n else None}

    recommendation = "INSUFFICIENT_DATA"
    if total >= 50 and both_directional >= 30:
        if agreement_rate >= 80 and (corr is not None and corr >= 0.70):
            recommendation = "MERGE_SUPPORTED"
        elif agreement_rate < 65 or outcome["tech_only_correct"] + outcome["mtf_only_correct"] >= 10:
            recommendation = "KEEP_SEPARATE_PENDING_MORE_RESEARCH"
        else:
            recommendation = "PAPER_TRIAL_REQUIRED"

    summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(), "days": args.days,
        "min_confidence": args.min_confidence, "samples": total,
        "counts": counts, "both_directional_samples": both_directional,
        "direction_agreement_pct": round(agreement_rate, 1),
        "confidence_pearson": round(corr, 3) if corr is not None else None,
        "outcome_accuracy": accuracy,
        "technical_only_correct": outcome["tech_only_correct"],
        "mtf_only_correct": outcome["mtf_only_correct"],
        "current_three_agent_cases": current_three,
        "proposed_three_without_auction_flow": proposed_three_without_flow,
        "current_cases_lost_before_auction_flow": len(current_accept_proposed_loses),
        "recommendation": recommendation,
        "important_limitation": "Auction Flow does not exist yet; proposed acceptance impact is incomplete.",
    }

    outdir = ROOT / "diagnostics"; outdir.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    json_path = outdir / f"tech_mtf_merge_audit_{stamp}.json"
    txt_path = outdir / f"tech_mtf_merge_audit_{stamp}.txt"
    json_path.write_text(json.dumps({"summary": summary, "disagreements": disagreements[-30:],
                                     "lost_cases": current_accept_proposed_loses[-30:],
                                     "records": records}, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    lines = [
        "TECHNICAL + MULTI-TIMEFRAME MERGE AUDIT", "="*48,
        f"Samples: {total} | both directional: {both_directional}",
        f"Same direction: {counts['same_direction']} | opposite: {counts['opposite_direction']}",
        f"Agreement: {agreement_rate:.1f}% | confidence correlation: {summary['confidence_pearson']}",
        f"Both qualified same direction: {counts['both_qualified_same']}",
        f"Technical directional / MTF WAIT: {counts['tech_direction_mtf_wait']}",
        f"MTF directional / Technical WAIT: {counts['mtf_direction_tech_wait']}",
        "", "OUTCOME ACCURACY", json.dumps(accuracy, ensure_ascii=False),
        f"Technical only correct: {outcome['tech_only_correct']}",
        f"MTF only correct: {outcome['mtf_only_correct']}",
        "", "HYPOTHETICAL 57/43 COMPOSITE (Auction Flow missing)",
        f"Current >=3-agent cases: {current_three}",
        f"After merge, >=3 among Composite+Classical+SMC+PA: {proposed_three_without_flow}",
        f"Cases lost before adding Auction Flow: {len(current_accept_proposed_loses)}",
        "", f"RECOMMENDATION: {recommendation}",
        "Do not activate the merge from this report alone unless sample and outcome coverage are sufficient.",
        "", f"JSON: {json_path}",
    ]
    txt_path.write_text("\n".join(lines), encoding="utf-8")
    print("TXT REPORT:", txt_path)
    print("JSON REPORT:", json_path)
    print("\n".join(lines[:-2]))


if __name__ == "__main__":
    main()
