# تقرير الإصلاحات — 2026-08-14

## نتيجة الاختبارات

| | قبل | بعد |
|---|---|---|
| ناجح | 1850 | **1861** |
| فاشل | **11** | **0** |
| متخطى | 3 | 3 |
| زمن التشغيل | 143 ثانية | **17.5 ثانية** (8× أسرع) |

---

## الإصلاحات

### 1) تسريب متغيرات `.env` إلى الاختبارات — 9 اختبارات فاشلة
**الملف:** `tests/conftest.py`

**المشكلة:** `scripts/run_analysis.py` ينفّذ `load_dotenv()` عند الاستيراد، فتتسرّب
قيم `.env` الحقيقية (TELEGRAM_BOT_TOKEN، EXECUTION_MODE=mt5_demo، GEMINI_API_KEY...)
إلى عملية pytest. النتيجة:

- `tests/test_services.py` (5 اختبارات): تبني `TelegramService` بدون توكن وتتوقع
  `False`، لكن التوكن الحقيقي من البيئة كان يفوز، فكانت الرسائل **تُرسل فعلياً
  إلى تيليجرام أثناء الاختبارات** (وهذا أيضاً سبب بطء التشغيل 143 ثانية).
- `tests/test_signal_delivery.py` (3 اختبارات): `EXECUTION_MODE=mt5_demo` كان يحوّل
  مسار التسليم إلى طابور التنفيذ بدل `telegram.send_signal`، و`GEMINI_API_KEY`
  الحقيقي فعّل كتلة Gemini التي انفجرت على `MagicMock`.
- اختبار `test_telegram_no_token_logs_message` بنفس السبب.

**الحل:** fixture تلقائية `_isolate_dotenv_environment` تحذف 10 متغيرات حسّاسة
من بيئة كل اختبار. الاختبارات التي تحتاج قيمة معيّنة تضبطها بنفسها عبر
`monkeypatch.setenv` (تعمل بعد الـfixture فتفوز).

**فائدة إضافية:** لم تعد الاختبارات ترسل رسائل حقيقية أو تستهلك حصص API — لذلك
هبط زمن التشغيل من 143 إلى 17.5 ثانية.

### 2) تكافؤ المعايرة مع الوكيل الحي — اختباران فاشلان
**الملفات:** `agents/unified_trend_agent.py`، `scripts/build_agent_calibrations.py`

**المشكلة:** `tests/test_unified_trend_calibration_parity.py` يطالب بأن يتدرّب
منحنى المعايرة على نفس الكمية التي يحسبها الوكيل الحي، عبر دالة قانونية واحدة
`UnifiedTrendAgent.weighted_family_scores` — لكن الدالة لم تكن موجودة أصلاً،
وكان مدرّب المعايرة يعيد تنفيذ الرياضيات بنفسه **مع عقوبة coherence** لا يجوز
وجودها في التدريب.

**الحل:**
- أضفت `UnifiedTrendAgent.weighted_family_scores(family_by_tf, config)`:
  دمج قانوني واحد لعائلات الأدلة (ema/structure/momentum/macd/rsi) عبر
  الفريمات الأربعة، مع دعم أوزان اختيارية `unified_trend.timeframe_weights`
  (الافتراضي: أوزان متساوية = السلوك التاريخي نفسه).
- الوكيل الحي (`analyze`) يستدعيها الآن بدل الحساب اليدوي.
- `_edge_from_family_by_tf` في مدرّب المعايرة أصبحت تفوّض إليها وأزيلت
  عقوبة coherence من حافة التدريب (تبقى coherence معدِّل ثقة وقت التشغيل فقط).

### 3) ملفات تصنيفات المحلّل مفقودة — اختبار فاشل
**المجلد:** `storage/`

**المشكلة:** `tests/test_analyst_labels_are_scoreable.py` يرفض النجاح الصامت
عندما لا يجد أي تصنيف («a silent pass is not a pass»)، والملف المضغوط لم يتضمن
مجلد `storage/` الخاص بالتصنيفات.

**الحل:** استعدت الملفات الأربعة من فرع `demo/mt5` على GitHub:
`2026-07-30_analyst_label.csv`، `2026-08-03_analyst_label.csv`،
`2026-08-03b_analyst_label.csv`، `analyst_labels_20260729.json`.

### 4) تحذير إهمال (Deprecation) في بايثون 3.12+
**الملفان:** `utils/helpers.py`، `helpers.py`

`datetime.utcnow()` مهملة ومقررة للإزالة → استبدلت بـ
`datetime.now(timezone.utc)` في `is_weekend_hebron`.

---

## ⚠️ تحذير أمني عاجل (خارج نطاق الكود)

ملف `.env` داخل الأرشيف — المنشور في مستودع GitHub **عام** — يحتوي مفاتيح حقيقية:
- توكن بوت تيليجرام + توكن بوت الاشتراكات
- مفاتيح Gemini وOpenAI وAnthropic وTwelveData
- كلمة مرور حساب MT5

**يجب إبطال/تدوير كل هذه المفاتيح فوراً**، وإزالة `.env` من المستودع
(وإضافته إلى `.gitignore`، ثم تنظيف تاريخ Git بـ `git filter-repo` أو ما شابه).

## ملاحظات إضافية (لم أُعدّلها بدون إذنك)

- **ازدواج ملفات الجذر:** `run_analysis.py` في الجذر (4941 سطراً) أقدم وأقصر من
  `scripts/run_analysis.py` (5330 سطراً) — نفس الشيء مع `run_tick_manager.py`
  و`database.py`. نسخ الجذر تبدو قديمة ويستحسن حذفها أو توحيدها حتى لا يشغَّل
  الإصدار القديم بالخطأ.
- `helpers.py` في الجذر يختلف عن `utils/helpers.py` بسطر واحد رغم تطابق عدد الأسطر.
- مخرجات وقت التشغيل داخل المستودع (`*.pid`، `heartbeat.json`،
  `dashboard_public_url.txt`) يستحسن نقلها إلى `.gitignore`.
