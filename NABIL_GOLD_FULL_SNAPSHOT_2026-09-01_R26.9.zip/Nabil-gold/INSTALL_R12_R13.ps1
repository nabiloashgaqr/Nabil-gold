# =====================================================================
# Nabil-gold R12+R13 COMPLETE installer (LOCAL-ONLY build, no cloud)
# Installs BOTH fixes in one shot:
#   R12: forensic trade audit tool  (scripts/audit_recent_trades.py + bat)
#   R13: per-symbol spread caps + shadow evidence + 2 diagnostics
# HOW TO RUN (see INSTALL_README_ARABIC.txt):
#   1. Extract this package anywhere.
#   2. Double-click INSTALL_R12_R13.bat   (or run this ps1 with -File)
# The installer NEVER overwrites your config.json - it merges only the
# per-symbol spread caps via APPLY_R13_CONFIG_MERGE.py.
# =====================================================================
param([string]$ProjectRoot = "C:\Nabil-gold")
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "==============================================================="
Write-Host " Nabil-gold R12+R13 COMPLETE installer"
Write-Host " package : $here"
Write-Host " project : $ProjectRoot"
Write-Host "==============================================================="

if (-not (Test-Path $ProjectRoot)) {
    throw "Project root not found: $ProjectRoot - edit the -ProjectRoot value at the top of this file."
}

# -- 1. copy payload (mirrored tree) ----------------------------------
Write-Host "[1/5] Copying 16 payload files..."
$dirs = @("services", "agents", "utils", "scripts", "tests")
foreach ($d in $dirs) {
    $src = Join-Path $here $d
    if (-not (Test-Path $src)) { throw "Package folder missing: $src (extract the WHOLE zip first)" }
    $dst = Join-Path $ProjectRoot $d
    if (-not (Test-Path $dst)) { New-Item -ItemType Directory -Path $dst | Out-Null }
    Copy-Item -Path (Join-Path $src "*") -Destination $dst -Force
}
Copy-Item -Path (Join-Path $here "RUN_TRADE_AUDIT.bat")      -Destination $ProjectRoot -Force
Copy-Item -Path (Join-Path $here "RUN_SYMBOL_DIAGNOSIS.bat") -Destination $ProjectRoot -Force
Write-Host "      copied: services x2, agents x2, utils x1, scripts x3, tests x6, bats x2"

# -- 2. merge config (never overwrite) --------------------------------
Write-Host "[2/5] Merging per-symbol spread caps into config.json..."
$merge = Join-Path $here "config_patch\APPLY_R13_CONFIG_MERGE.py"
$mergeOut = & python $merge --root $ProjectRoot 2>&1
if ($LASTEXITCODE -ne 0) { throw "config merge failed: $mergeOut" }
Write-Host ($mergeOut | Select-Object -First 1)

# -- 3. compile check --------------------------------------------------
Write-Host "[3/5] py_compile..."
$pyFiles = @("services\guard_replay.py", "services\database.py", "utils\instruments.py",
             "agents\auction_flow_agent.py", "agents\risk_management_agent.py",
             "scripts\audit_recent_trades.py", "scripts\diagnose_symbol_funnel.py",
             "scripts\diagnose_auction_agent.py")
foreach ($f in $pyFiles) {
    $out = & python -m py_compile (Join-Path $ProjectRoot $f) 2>&1
    if ($LASTEXITCODE -ne 0) { throw "py_compile failed for ${f}: $out" }
}
Write-Host "      8/8 OK"

# -- 4. run the new tests ---------------------------------------------
Write-Host "[4/5] Running the R12+R13 test files..."
$tests = @("tests\test_audit_recent_trades_tool.py", "tests\test_guard_replay_service.py",
           "tests\test_spread_guard_per_symbol.py", "tests\test_database_would_block.py",
           "tests\test_diagnose_symbol_funnel.py", "tests\test_auction_agent_diagnosis.py")
$paths = $tests | ForEach-Object { Join-Path $ProjectRoot $_ }
$t = & python -m pytest @paths -q -p no:cacheprovider 2>&1
Write-Host $t[-1]
if ($LASTEXITCODE -ne 0) { throw "tests failed - see output above" }

# -- 5. live diagnostics preview --------------------------------------
Write-Host "[5/5] Diagnostics preview (full output after install):"
$fun = & python (Join-Path $ProjectRoot "scripts\diagnose_symbol_funnel.py") --days 7 2>&1
Write-Host ($fun | Select-Object -First 6)
$auc = & python (Join-Path $ProjectRoot "scripts\diagnose_auction_agent.py") 2>&1
Write-Host ($auc | Select-Object -First 6)

Write-Host "==============================================================="
Write-Host " DONE. Usage:"
Write-Host "   python scripts\audit_recent_trades.py --days 2     (R12 trade audit)"
Write-Host "   python scripts\diagnose_symbol_funnel.py --days 7  (why a pair does not trade)"
Write-Host "   python scripts\diagnose_auction_agent.py           (why the agent shows 50)"
Write-Host " Or double-click RUN_TRADE_AUDIT.bat / RUN_SYMBOL_DIAGNOSIS.bat"
Write-Host "==============================================================="
