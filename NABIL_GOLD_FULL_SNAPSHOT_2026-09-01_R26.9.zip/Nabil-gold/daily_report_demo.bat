@echo off
REM BUILD 31 R10 (post-audit 2026-08-27): single source of truth.
REM The root copies had drifted from the canonical deploy\tasks wrappers
REM (stale comments, missing env vars such as FORCE_WEEKLY_REPORT).
REM This root file now only DELEGATES - edit deploy\tasks\daily_report_demo.bat instead.
call "%~dp0deploy\tasks\daily_report_demo.bat"
