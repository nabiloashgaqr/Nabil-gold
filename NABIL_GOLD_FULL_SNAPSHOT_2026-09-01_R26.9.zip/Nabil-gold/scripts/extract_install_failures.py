# -*- coding: utf-8 -*-
"""R25.1: pull the FAILED test sections out of install_test_output.txt.

The installer asks the operator to send the full log; this tool distills it
to just the failure sections (header + traceback per failed test), writing
them to install_failures_dump.txt next to the log. Pure stdlib, ASCII output.

Usage (from the project or package folder):
    python scripts\\extract_install_failures.py "C:\\path\\to\\install_test_output.txt"
"""
import re
import sys
from pathlib import Path

SECTION_RE = re.compile(r"^_{5,}\s*(.+?)\s*_{5,}\s*$")


def extract(log_text: str):
    """Return (failed_ids, sections) - sections matching the FAILED ids.

    R25.2: installer logs use --tb=line (one line per failure, no section
    headers), so the FAILED lines are kept VERBATIM - their error suffix
    (e.g. " - PermissionError: [WinError 32] ...") is often the whole
    diagnosis. Full sections are added when the log carries tracebacks.
    """
    failed_ids = [ln.strip() for ln in log_text.splitlines()
                  if ln.startswith("FAILED ")]
    basenames = []
    for fid in failed_ids:
        leaf = fid.split(" - ")[0]
        name = leaf.split("::")[-1].strip()
        if name:
            basenames.append(name)
    sections, current, current_name = [], [], None
    for line in log_text.splitlines():
        m = SECTION_RE.match(line.strip())
        if m:
            if current and current_name is not None:
                sections.append((current_name, current))
            current, current_name = [line], m.group(1)
        elif current_name is not None:
            current.append(line)
            if line.startswith("=======") and "short test summary" in line.lower():
                sections.append((current_name, current))
                current, current_name = [], None
        # lines before the first section are ignored
    if current and current_name is not None:
        sections.append((current_name, current))
    picked = [sec for sec in sections
              if any(name in sec[0] for name in basenames)]
    return failed_ids, picked


def main():
    if len(sys.argv) < 2:
        print("Usage: python scripts\\extract_install_failures.py "
              "<path to install_test_output.txt>")
        return 1
    log_path = Path(sys.argv[1])
    if not log_path.exists():
        print("FAIL: log not found: %s" % log_path)
        return 1
    failed_ids, picked = extract(log_path.read_text(encoding="utf-8",
                                                     errors="replace"))
    out = log_path.parent / "install_failures_dump.txt"
    with out.open("w", encoding="utf-8") as fh:
        fh.write("FAILED test lines, verbatim (%d):\n" % len(failed_ids))
        for fid in failed_ids:
            fh.write("  " + fid + "\n")
        fh.write("\nDetailed sections (%d):\n" % len(picked))
        for name, lines in picked:
            fh.write("\n".join(lines).rstrip() + "\n\n")
    print("extracted %d failed id(s), %d detailed section(s) -> %s"
          % (len(failed_ids), len(picked), out))
    return 0


if __name__ == "__main__":
    sys.exit(main())
