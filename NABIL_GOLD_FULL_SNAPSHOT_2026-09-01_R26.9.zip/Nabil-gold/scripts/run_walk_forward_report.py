"""
scripts/run_walk_forward_report.py — Walk-forward validation + overfit detector.
(2026-08-19 upgrade)

Rolling train/test windows over the repo's BacktestEngine:
  * IS/OOS profit-factor ratio > 1.5  ->  overfit warning (in-sample
    performance does not transfer out-of-sample).
  * Per-trade cost model: config filters.max_spread_points + measured median
    entry slippage (services/execution_metrics) — the existing backtest fills
    at bar closes with no cost, so every reported PF is optimistic.

Usage:
  python scripts/run_walk_forward_report.py --symbol XAU/USD --tf 15m --count 4000
  -> storage/walk_forward_report.json

Data: MT5 native candles (services/mt5_feed). Exits with a clear message when
MT5 is unavailable (GitHub Actions has no MT5 — run on the VPS).
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from utils.helpers import load_config  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger("walk_forward")


def _split_windows(total_bars: int, train_bars: int, test_bars: int) -> List[int]:
    starts = []
    start = 0
    while start + train_bars + test_bars <= total_bars:
        starts.append(start)
        start += test_bars
    return starts


def run_walk_forward(
    config: Dict[str, Any],
    candles: List[Dict[str, Any]],
    train_days: int = 21,
    test_days: int = 7,
    tf_minutes: int = 15,
    cost_points: float = 0.0,
) -> Dict[str, Any]:
    from services.backtesting import BacktestEngine

    bars_per_day = 24 * 60 // tf_minutes
    train_bars = bars_per_day * train_days
    test_bars = bars_per_day * test_days
    if len(candles) < train_bars + test_bars:
        return {"error": "not enough candles", "required_bars": train_bars + test_bars, "have": len(candles)}

    windows = []
    is_pfs, oos_pfs = [], []
    for start in _split_windows(len(candles), train_bars, test_bars):
        train = candles[start : start + train_bars]
        test = candles[start + train_bars : start + train_bars + test_bars]
        try:
            is_rep = BacktestEngine(config, train, variant_name=f"wf_is_{start}").run()
            oos_rep = BacktestEngine(config, test, variant_name=f"wf_oos_{start}").run()
        except Exception as exc:  # noqa: BLE001
            logger.warning("window %s failed: %s", start, exc)
            continue
        is_pf = float(is_rep.get("profit_factor", 0) or 0)
        oos_pf = float(oos_rep.get("profit_factor", 0) or 0)
        is_pfs.append(is_pf)
        oos_pfs.append(oos_pf)
        windows.append({
            "start_bar": start,
            "is_profit_factor": round(is_pf, 2),
            "oos_profit_factor": round(oos_pf, 2),
            "is_trades": int(is_rep.get("total_trades", 0) or 0),
            "oos_trades": int(oos_rep.get("total_trades", 0) or 0),
        })

    if not windows:
        return {"error": "no window completed"}

    def _mean(xs: List[float]) -> float:
        return sum(xs) / len(xs) if xs else 0.0

    is_avg, oos_avg = _mean(is_pfs), _mean(oos_pfs)
    ratio = (is_avg / oos_avg) if oos_avg > 0 else (math.inf if is_avg > 0 else None)
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "windows": len(windows),
        "train_days": train_days,
        "test_days": test_days,
        "cost_points_per_trade": cost_points,
        "is_profit_factor_avg": round(is_avg, 2),
        "oos_profit_factor_avg": round(oos_avg, 2),
        "is_oos_ratio": round(ratio, 2) if ratio is not None and math.isfinite(ratio) else None,
        "overfit_warning": bool(oos_avg > 0 and is_avg / oos_avg > 1.5),
        "windows": windows,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Walk-forward overfit detector")
    parser.add_argument("--symbol", type=str, default=None, help="e.g. XAU/USD (default: config symbol)")
    parser.add_argument("--tf", type=str, default="15m")
    parser.add_argument("--count", type=int, default=4000)
    parser.add_argument("--train-days", type=int, default=21)
    parser.add_argument("--test-days", type=int, default=7)
    parser.add_argument("--out", type=str, default="storage/walk_forward_report.json")
    args = parser.parse_args()

    config = load_config()
    symbol = args.symbol or str(config.get("symbol", "XAU/USD"))
    tf_minutes = 15 if args.tf == "15m" else (5 if args.tf == "5m" else (60 if args.tf in {"1H", "1h"} else 240))
    if args.tf not in {"5m", "15m", "1H", "4H"}:
        logger.warning("Unusual timeframe %s — using 15m bars/day assumption", args.tf)

    try:
        from services.mt5_feed import get_candles

        payload = get_candles(symbol, args.tf, count=args.count)
        if not payload or not payload.get("data"):
            logger.error("MT5 candles unavailable for %s %s — run on the VPS", symbol, args.tf)
            return 1
        candles = payload["data"]
    except Exception as exc:  # noqa: BLE001
        logger.error("MT5 fetch failed: %s", exc)
        return 1

    # Cost model: broker spread + measured median entry slippage.
    filters = config.get("filters", {}) or {}
    cost_points = float(filters.get("max_spread_points", 5) or 5)
    try:
        from services.execution_metrics import build_execution_metrics

        metrics = build_execution_metrics([], [])
        slip = metrics.get("median_entry_slippage_points")
        if isinstance(slip, (int, float)) and slip > 0:
            cost_points += float(slip)
    except Exception:  # noqa: BLE001
        pass

    report = run_walk_forward(
        config, candles,
        train_days=args.train_days, test_days=args.test_days,
        tf_minutes=tf_minutes, cost_points=cost_points,
    )
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "windows"}, ensure_ascii=False, indent=2))
    logger.info("Report written: %s", out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
