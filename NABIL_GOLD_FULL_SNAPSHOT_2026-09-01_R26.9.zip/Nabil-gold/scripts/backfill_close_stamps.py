"""BACKFILL CLOSE STAMPS (2026-08-21, build 22 companion, read-only by default).

The live tick manager wrote TP2_HIT/SL_HIT without closed_at, so the
post-TP2 2.5h block and the WIN/LOSS cooldowns measured from the OPEN time
(the 09:16 pending slipped through five minutes after a real TP2). Build 22
stamps every future close; this script backfills TODAY's unstamped closed
rows with the REAL broker deal time.

Rules:
  * only rows whose status is a CLOSED state and closed_at is missing;
  * the stamp comes from the broker's own OUT deal for the row's magic
    (real data, never invented) - fallback: the row's close_time;
  * OPEN/PENDING rows are NEVER touched (operator order: leave the live
    trade alone).

Usage:
  python scripts\\backfill_close_stamps.py            # dry-run
  python scripts\\backfill_close_stamps.py --apply    # write trades.json
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

from utils.helpers import mutate_trades  # noqa: E402

CLOSED_STATUSES = {"TP2_HIT", "SL_HIT", "BE_HIT", "THESIS_EXIT", "MANUAL_CLOSE", "EXPIRED"}
UNTOUCHABLE = {"OPEN", "PARTIAL", "TP1_HIT", "PENDING", "CANCELLED"}


def _iso(epoch: float | int | None) -> Optional[str]:
    try:
        value = float(epoch) if epoch is not None else 0.0
        if value <= 0:
            return None
        return datetime.fromtimestamp(value, tz=timezone.utc).isoformat().replace("+00:00", "Z")
    except (TypeError, ValueError, OSError):
        return None


def broker_exit_stamps(mt5, executor) -> Dict[str, str]:
    """map: magic-str(ticket)->closed-at ISO for every OUT deal seen today.

    Reads the real broker history; no value is invented."""
    stamps: Dict[str, str] = {}
    try:
        now = int(datetime.now(timezone.utc).timestamp()) + 86400
        deals = mt5.history_deals_get(0, now) or ()
        for deal in deals:
            entry = getattr(deal, "entry", None)
            if entry != getattr(mt5, "DEAL_ENTRY_OUT", 1):
                continue
            ts = _iso(getattr(deal, "time", 0))
            if not ts:
                continue
            magic = getattr(deal, "magic", None)
            if magic is None:
                continue
            stamps[str(magic)] = ts
    except Exception as exc:  # noqa: BLE001
        print(f"broker deal scan failed: {exc}")
    return stamps


def broker_clock_skew(mt5) -> Optional[float]:
    """Seconds the broker clock leads the VPS clock, from a LIVE tick.

    The 2026-08-21 backfill scan returned a broker deal stamped 12:13:44Z
    while the VPS clock read ~11:24 - the broker server runs ~+3h. A raw
    deal stamp is therefore in the FUTURE relative to the VPS clock, which
    would make the post-TP2 window compute negative and fail open. This
    measures the live skew from a current tick so historical stamps can be
    corrected with real data instead of a guess."""
    try:
        tick = mt5.symbol_info_tick("XAUUSD.s")
        if tick is None:
            return None
        msc = int(getattr(tick, "time_msc", 0) or 0)
        if msc <= 0:
            return None
        return msc / 1000.0 - time.time()
    except Exception:  # noqa: BLE001
        return None


def corrected_deal_stamp(raw_ts: float, skew: Optional[float], now_ts: float) -> str:
    """(closed_at ISO) for a broker deal, corrected to the VPS clock.

    * skew between 5 minutes and 12 hours -> subtract it (real UTC);
    * anything still in the future after correction -> clamp to now;
    * no usable correction -> clamp to now (never future, never invented).
    """
    ts = float(raw_ts)
    if skew is not None and 300.0 < skew < 43200.0:
        ts = ts - skew
    if ts > now_ts + 300.0:
        ts = now_ts
    return _iso(ts) or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(ROOT))
    parser.add_argument("--apply", action="store_true",
                        help="write trades.json (default: dry-run)")
    args = parser.parse_args()
    root = Path(args.root)
    mode = "APPLY" if args.apply else "DRY-RUN"
    print(f"BACKFILL CLOSE STAMPS  [{mode}]  root={root}")
    trades_path = root / "storage" / "trades.json"
    if not trades_path.exists():
        print("trades.json not found")
        return 1
    trades: List[Dict[str, Any]] = json.loads(trades_path.read_text(encoding="utf-8") or "[]")

    # Real broker stamps by magic + the live clock skew correction.
    stamps: Dict[str, str] = {}
    skew: Optional[float] = None
    try:
        from services.mt5_executor import _mt5_ready, magic_for, Mt5DemoExecutor
        from utils.helpers import load_config
        mt5 = _mt5_ready()
        executor = Mt5DemoExecutor(load_config())
        stamps = broker_exit_stamps(mt5, executor)
        skew = broker_clock_skew(mt5)
        print(f"broker OUT deals scanned: {len(stamps)}")
        if skew is not None:
            print(f"broker clock leads the VPS clock by {skew / 3600.0:+.2f}h - "
                  f"deal stamps will be corrected with this measured skew")
    except Exception as exc:  # noqa: BLE001
        print(f"MT5 unavailable ({exc}) - falling back to the rows' own close_time")

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    candidates = []
    for row in trades:
        if not isinstance(row, dict):
            continue
        status = str(row.get("status") or "").upper()
        if status in UNTOUCHABLE or status not in CLOSED_STATUSES:
            continue
        if row.get("closed_at") or row.get("close_time"):
            continue
        created = str(row.get("created_at") or "")
        if not created.startswith(today):
            continue  # backfill today's gap only
        candidates.append(row)

    if not candidates:
        print("no unstamped closed rows from today - nothing to do")
        return 0

    for row in candidates:
        tid = str(row.get("id") or "")
        status = str(row.get("status") or "")
        created = str(row.get("created_at") or "")[:19]
        raw_stamp: Optional[float] = None
        try:
            from services.mt5_executor import magic_for
            raw = stamps.get(str(magic_for(tid)))
            if raw:
                raw_stamp = float(datetime.fromisoformat(raw.replace("Z", "+00:00")).timestamp())
        except Exception:  # noqa: BLE001
            raw_stamp = None
        if raw_stamp:
            stamp = corrected_deal_stamp(raw_stamp, skew, time.time())
            source = "broker deal time (clock-skew corrected)" if skew and 300 < skew < 43200 else "broker deal time"
        else:
            stamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
            source = "fallback: now (no broker deal found)"
        print(f"  {tid[:34]}  {status:12s} opened {created} -> closed_at={stamp}  ({source})")

    if not args.apply:
        print("DRY-RUN: nothing written. Re-run with --apply to execute.")
        return 0

    try:
        from services.mt5_executor import magic_for as _magic_for
    except Exception:  # noqa: BLE001
        _magic_for = lambda tid: tid  # noqa: E731

    def _apply(rows: List[Dict[str, Any]]) -> None:
        by_id = {str(r.get("id") or ""): r for r in rows}
        for row in candidates:
            target = by_id.get(str(row.get("id") or ""))
            if target is None:
                continue
            raw_stamp = None
            try:
                raw = stamps.get(str(_magic_for(row.get("id") or "")))
                if raw:
                    raw_stamp = float(datetime.fromisoformat(raw.replace("Z", "+00:00")).timestamp())
            except Exception:  # noqa: BLE001
                raw_stamp = None
            if raw_stamp:
                stamp = corrected_deal_stamp(raw_stamp, skew, time.time())
            else:
                stamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
            target["closed_at"] = stamp
            target["close_time"] = stamp

    mutate_trades(_apply, trades_path)
    print(f"stamped {len(candidates)} row(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
