"""GEMINI MODEL PROBE (BUILD 23.1).

Probes the candidate models configured in config.json (llm_review.model +
fallback_models, in order) with a 30-second timeout per model.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv()
except Exception:
    pass

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:
        pass

import requests

from services.model_law import PRODUCTION_CHAIN as _LAW_PRODUCTION_CHAIN

API_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"


def probe_model(api_key: str, model: str, timeout: int = 30) -> Tuple[str, str]:
    try:
        resp = requests.post(
            API_URL.format(model=model),
            params={"key": api_key},
            json={"contents": [{"parts": [{"text": "ping"}]}],
                  "generationConfig": {"maxOutputTokens": 8}},
            timeout=timeout,
        )
    except Exception as exc:
        return "NETWORK", f"request failed: {exc}"
    if resp.status_code == 200:
        try:
            body = resp.json()
            text = ((((body.get("candidates") or [{}])[0].get("content") or {})
                     .get("parts") or [{}])[0].get("text") or "")
            snippet = text.strip()[:60].replace(chr(10), " ")
            return "OK", f"answered: {snippet!r}"
        except Exception:
            return "OK", f"answered: {(resp.text or '')[:60]}"
    if resp.status_code in (401, 403):
        return "AUTH", f"the KEY itself is refused (HTTP {resp.status_code})"
    if resp.status_code == 404:
        return "404", "this key cannot use this model id"
    if resp.status_code == 429:
        text = resp.text or ""
        if "PerDay" in text or "per day" in text.lower():
            return "429-RPD", "daily quota exhausted (resets at midnight Pacific)"
        if "PerMinute" in text or "per minute" in text.lower():
            return "429-RPM", "per-minute limit - retry in a moment"
        return "429", f"rate limited: {(text or '')[:80]}"
    return f"HTTP{resp.status_code}", f"{(resp.text or '')[:80]}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", default=None, help="comma-separated model list")
    args = parser.parse_args()

    api_key = os.environ.get("GEMINI_API_KEY") or ""
    if not api_key:
        print("GEMINI_API_KEY not found in .env - nothing to probe.")
        return 1

    cfg_path = ROOT / "config.json"
    configured_models = []
    if cfg_path.exists():
        try:
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
            llm_cfg = cfg.get("llm_review") or cfg.get("gemini") or {}
            if llm_cfg.get("model"):
                configured_models.append(llm_cfg.get("model"))
            configured_models.extend(llm_cfg.get("fallback_models") or [])
        except Exception:
            pass

    candidates = (
        [m.strip() for m in (args.models or "").split(",") if m.strip()]
        or configured_models
        or list(_LAW_PRODUCTION_CHAIN)
    )
    candidates = list(dict.fromkeys(candidates))

    print(f"GEMINI MODEL PROBE - key length {len(api_key)} - {len(candidates)} models (timeout 30s)")
    print("=" * 68)
    for model in candidates:
        status, detail = probe_model(api_key, model, timeout=30)
        print(f"  {status:10s} {model:26s} {detail}")
    print("=" * 68)
    print("OK = usable now. 404 = unusable for this key.")
    print("429-RPD = quota dead today; failover switches to next model (BUILD 23).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
