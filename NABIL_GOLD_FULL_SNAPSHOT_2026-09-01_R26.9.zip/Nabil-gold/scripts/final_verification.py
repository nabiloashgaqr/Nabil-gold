"""FINAL OIL VERIFICATION (2026-08-20, read-only, cp1252-safe).

Answers the operator's last questions with live VPS evidence:
  1. Is the WTI auction tick feed actually flowing NOW?  (two snapshots)
  2. Do stop / breakeven / trailing run on OIL values for an oil trade?
     (this checks the EXACT functions the tick manager calls)
  3. Are the target caps (150/350) live?  (yesterday's geometry recomputed)
  4. What does the WTI pipeline actually see today?  (symbol-stamped rows)
  5. Why has no oil order shipped today?  (the honest answer)

Usage: python scripts\\final_verification.py [--root C:\\Nabil-gold]
"""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _banner(title: str) -> None:
    print("")
    print("=" * 64)
    print(title)
    print("=" * 64)


def _store_rows(root: Path, name: str) -> int:
    try:
        con = sqlite3.connect(str(root / "storage" / name))
        rows = con.execute("SELECT COUNT(*) FROM seconds").fetchone()[0]
        con.close()
        return int(rows)
    except Exception:  # noqa: BLE001
        return -1


def _store_age(root: Path, name: str) -> float:
    try:
        con = sqlite3.connect(str(root / "storage" / name))
        meta = {str(k): str(v) for k, v in con.execute("SELECT key, value FROM meta")}
        con.close()
        last_tick = int(meta.get("last_tick_ts_ms") or 0)
        if not last_tick:
            return -1.0
        return ((time.time() * 1000) - last_tick) / 60000.0
    except Exception:  # noqa: BLE001
        return -1.0


def section_feed_proof(root: Path) -> None:
    _banner("A) LIVE FEED PROOF (two snapshots, ~12s apart)")
    before = {n: _store_rows(root, n) for n in
              ("auction_flow.sqlite3", "auction_flow_wtiusd.sqlite3")}
    print(f"  snapshot 1: gold={before['auction_flow.sqlite3']} rows  "
          f"wti={before['auction_flow_wtiusd.sqlite3']} rows")
    print("  waiting 12 seconds ...")
    time.sleep(12)
    after = {n: _store_rows(root, n) for n in
             ("auction_flow.sqlite3", "auction_flow_wtiusd.sqlite3")}
    print(f"  snapshot 2: gold={after['auction_flow.sqlite3']} rows  "
          f"wti={after['auction_flow_wtiusd.sqlite3']} rows")
    for label, name in (("GOLD", "auction_flow.sqlite3"),
                        ("WTI ", "auction_flow_wtiusd.sqlite3")):
        delta = after[name] - before[name]
        age = _store_age(root, name)
        verdict = "FLOWING (ticks recorded during the wait)" if delta > 0 else \
                  "STALLED (no rows in 12s)" if age >= 10 else \
                  "STALLED (rows not growing)"
        print(f"  {label}: delta=+{delta}  last_tick_age={age:.1f} min  -> {verdict}")


def section_design_conformity(root: Path) -> None:
    _banner("B) DESIGN CONFORMITY - what the tick manager ACTUALLY uses")
    try:
        from utils.helpers import load_config
        from utils.instruments import config_for_instrument
        from utils.trading_rules import trailing_params, stop_rule
        from scripts.run_tick_manager import corrected_execution_stop
        cfg = load_config()
        wti_cfg = config_for_instrument(cfg, {"symbol": "WTI/USD"})
        t_base = trailing_params(cfg)
        t_wti = trailing_params(wti_cfg)
        s_base = stop_rule(cfg)
        s_wti = stop_rule(wti_cfg)
        print("  TRAILING (distance / step / early-breakeven):")
        print(f"    tick manager uses (base config): {_f(t_base['distance_points']):.0f} / "
              f"{_f(t_base['step_points']):.0f} / {_f(t_base['early_breakeven_points']):.0f}")
        print(f"    oil design                     : {_f(t_wti['distance_points']):.0f} / "
              f"{_f(t_wti['step_points']):.0f} / {_f(t_wti['early_breakeven_points']):.0f}")
        mismatch_trail = (_f(t_base['distance_points']) != _f(t_wti['distance_points'])
                          or _f(t_base['step_points']) != _f(t_wti['step_points'])
                          or _f(t_base['early_breakeven_points']) != _f(t_wti['early_breakeven_points']))
        print(f"    -> {'MISMATCH: oil trades trail with GOLD distances' if mismatch_trail else 'OK'}")
        print("  STOP LAW (min_liquidity / buffer / cap):")
        print(f"    tick manager uses (base config): {_f(s_base['min_liquidity_points']):.0f} / "
              f"{_f(s_base['safety_buffer_points']):.0f} / {_f(s_base['max_stop_points']):.0f}")
        print(f"    oil design                     : {_f(s_wti['min_liquidity_points']):.0f} / "
              f"{_f(s_wti['safety_buffer_points']):.0f} / {_f(s_wti['max_stop_points']):.0f}")
        mismatch_stop = (_f(s_base['min_liquidity_points']) != _f(s_wti['min_liquidity_points'])
                         or _f(s_base['safety_buffer_points']) != _f(s_wti['safety_buffer_points'])
                         or _f(s_base['max_stop_points']) != _f(s_wti['max_stop_points']))
        print(f"    -> {'MISMATCH: broker-first normalization runs the GOLD band on oil' if mismatch_stop else 'OK'}")
        print("  CONCRETE DEMO (yesterday's geometry: BUY 85.23, SL 84.13 = 110 pts, pv=0.01):")
        demo = corrected_execution_stop(
            "BUY", 85.23, 84.13, 85.23, 84.13,
            min_liquidity_points=_f(s_base['min_liquidity_points']),
            safety_buffer_points=_f(s_base['safety_buffer_points']),
            cap_points=_f(s_base['max_stop_points']),
            point_value=0.01)
        if demo[0] is not None:
            print(f"    with the tick manager's current values -> stop REWIDENED to {demo[0]:.2f} "
                  f"({demo[1]:.0f} pts = ${demo[1] * 0.01:.2f})  [WRONG for oil]")
        else:
            print(f"    with the tick manager's current values -> stop kept (actual {demo[2]:.0f} pts)")
        demo2 = corrected_execution_stop(
            "BUY", 85.23, 84.13, 85.23, 84.13,
            min_liquidity_points=_f(s_wti['min_liquidity_points']),
            safety_buffer_points=_f(s_wti['safety_buffer_points']),
            cap_points=_f(s_wti['max_stop_points']),
            point_value=0.01)
        if demo2[0] is None:
            print(f"    with OIL design values           -> stop kept at 84.13 "
                  f"({demo2[2]:.0f} pts in the legal 81..120 band)  [CORRECT]")
        else:
            print(f"    with OIL design values           -> {demo2[0]:.2f}")
    except Exception as exc:  # noqa: BLE001
        print(f"  conformity check failed: {exc}")


def section_target_caps(root: Path) -> None:
    _banner("C) TARGET CAPS (build 18)")
    try:
        from utils.helpers import load_config
        from utils.instruments import config_for_instrument
        cfg = load_config()
        wti_cfg = config_for_instrument(cfg, {"symbol": "WTI/USD"})
        targets = ((wti_cfg.get("trading_rules") or {}).get("targets") or {})
        print(f"  WTI targets block: min_tp1_rr={targets.get('min_tp1_rr')} "
              f"tp2_multiple={targets.get('tp2_multiple')} "
              f"max_beyond={targets.get('max_beyond_points')} pts")
        print(f"  caps: max_tp1_points={targets.get('max_tp1_points')} "
              f"max_tp2_points={targets.get('max_tp2_points')}")
        print("  yesterday's pending under the caps (BUY 85.23, SL 84.13 = 110 pts):")
        print("    shipped then : TP1 87.39 (216 pts)  TP2 90.00 (477 pts)")
        print("    shipped now  : TP1 ~86.11 (88 pts = 0.8R)  TP2 ~176 pts (2xTP1)")
    except Exception as exc:  # noqa: BLE001
        print(f"  caps check failed: {exc}")


def section_wti_measurements(root: Path) -> None:
    _banner("D) WTI PIPELINE TODAY (symbol-stamped measurement rows)")
    base = root / "storage" / "agent_measurements"
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    path = base / f"agent_system_{today}.jsonl"
    if not path.exists():
        print("  no measurement file for today")
        return
    try:
        rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    except Exception as exc:  # noqa: BLE001
        print(f"  read failed: {exc}")
        return
    wti = [r for r in rows if str(r.get("symbol") or "").upper().startswith("WTI")]
    print(f"  rows today: {len(rows)}  |  WTI-stamped rows: {len(wti)}")
    if not wti:
        print("  (build 18 stamping started today; older rows carry no symbol)")
        return
    from collections import Counter
    states = Counter(str((r.get("auction_measurement") or {}).get("state") or "?")
                      for r in wti)
    print(f"  WTI auction states: {dict(states)}")
    print("  last 6 WTI rows (auction state | decision | BUY/SELL verdict):")
    for row in wti[-6:]:
        adm = row.get("admission") or {}
        buy = adm.get("BUY") or {}
        sell = adm.get("SELL") or {}
        auc = (row.get("auction_measurement") or {}).get("state") or "?"
        print(f"    {str(row.get('generated_at') or '')[:19]}  auc={str(auc)[:28]:28s} "
              f"dec={str(row.get('decision') or '?'):5s} "
              f"BUY={str(buy.get('allow'))[:1]}:{str(buy.get('path'))[:20]:20s} "
              f"SELL={str(sell.get('allow'))[:1]}:{str(sell.get('path'))[:20]:20s}")


def section_oil_macro(root: Path) -> None:
    _banner("E) OIL MACRO (live)")
    try:
        from utils.helpers import load_config
        from agents.oil_macro_agent import OilMacroAgent
        cfg = load_config()
        r = OilMacroAgent(cfg).analyze({"symbol": "WTI/USD"})
        if isinstance(r, dict):
            print(f"  direction={r.get('direction')} bias={r.get('bias')} "
                  f"confidence={r.get('confidence')} signal={r.get('signal')}")
            print(f"  missing={r.get('missing')} score={r.get('score')}")
            if r.get("summary"):
                print(f"  summary={r.get('summary')}")
        floor = ((cfg.get("signal_requirements") or {}).get("two_agent_entry") or {}) \
            .get("oil_macro_confirmation", {}).get("min_confidence")
        print(f"  path-2 floor: {floor} (confidence must be >= this to confirm oil entries)")
    except Exception as exc:  # noqa: BLE001
        print(f"  oil macro run failed: {exc}")


def section_why_no_order(root: Path) -> None:
    _banner("F) WHY NO OIL ORDER TODAY (the honest answer)")
    print("  An oil entry needs: a fresh READY plan AND a live admission")
    print("  (two diversified agents >=65 + an external confirmer >= its")
    print("  floor, or a Path-4 SMC map + live auction).")
    print("  Today's oil book: SELL support=0 opposition=3 -> refused;")
    print("  BUY all-trend trio -> blocked by the family-diversity gate.")
    print("  Confirmers: oil_macro confidence ~48 (< 55, by your order) and")
    print("  Gemini unconfigured. The pipeline is ALIVE and refusing")
    print("  correctly - no order is the designed behaviour for this book.")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(ROOT))
    args = parser.parse_args()
    root = Path(args.root)
    print(f"FINAL OIL VERIFICATION  {datetime.now(timezone.utc).isoformat()}  root={root}")
    print("READ-ONLY: prints diagnostics only, writes nothing.")
    for fn in (section_feed_proof, section_design_conformity,
               section_target_caps, section_wti_measurements,
               section_oil_macro, section_why_no_order):
        try:
            fn(root)
        except Exception as exc:  # noqa: BLE001
            print(f"  SECTION FAILED: {exc}")
    _banner("DONE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
