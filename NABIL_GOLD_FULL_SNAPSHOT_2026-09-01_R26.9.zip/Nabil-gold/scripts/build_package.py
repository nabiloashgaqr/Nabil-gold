# -*- coding: utf-8 -*-
"""R25.12: the ONE packaging tool - diff-driven, self-verifying.

Replaces memory-driven hand packaging (the R25.7/R25.8 failure class:
stale or forgotten files) with a mechanical pipeline:

  [1/7] extract the previous package zip -> stage/
  [2/7] sync the GOVERNED tree (agents, services, utils, scripts, tests,
        config_patch + config.json) from the CURRENT source into the stage,
        wholesale - every build ships the full governed tree, so a file can
        never be forgotten or go stale (parity policy)
  [3/7] retired-token scan over the staged code + config (0 required)
  [4/7] completeness check: every governed source file exists in the stage
  [5/7] VPS-simulation: full copy of the source tree + the stage overlaid
        on top (what the installer produces on the operator's machine),
        then the FULL test suite runs there - 0 failed required
  [6/7] FILES_MANIFEST.txt measured at build time, then zip + sha256
        roundtrip verify
  [7/7] the files-changed markdown report (prev zip vs new zip), generated

Usage (from the project root):
    python scripts\\build_package.py --prev <prev.zip> --out <new.zip> ^
        --label R25.12 --files-doc <path.md> [--readme-title ...] ^
        [--readme-insert <block.txt>] [--skip-suite]
    (--skip-suite exists ONLY for the unit test; real builds never skip.)

All functions take explicit roots so the unit test can drive them on tiny
fake trees (tests/test_build_package_tool.py).
"""
from __future__ import annotations

import argparse
import filecmp
import hashlib
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))  # so the law module imports when run as a script

GOVERNED_DIRS = ("agents", "services", "utils", "scripts", "tests", "config_patch")
GOVERNED_FILES = ("config.json",)
SKIP_DIR_NAMES = {
    "__pycache__", ".pytest_cache", ".git", ".venv", "venv", "build",
    "dist", "out", "target", "coverage", "node_modules", "storage",
}
SKIP_FILE_MARKS = (".bak", ".pyc", ".zip", ".env")


def _skip(rel: Path) -> bool:
    """rel: path RELATIVE to its root (dirs + name checked)."""
    if any(part in SKIP_DIR_NAMES for part in rel.parts):
        return True
    return any(mark in rel.name for mark in SKIP_FILE_MARKS)


def _is_secret_env(name: str) -> bool:
    """Secret env files never travel - but the harmless .env.template does."""
    return name == ".env" or (name.startswith(".env") and name != ".env.template")


# ── [2/7] governed-tree sync ────────────────────────────────────────────────
def governed_source_files(src_root: Path) -> list:
    files = []
    for d in GOVERNED_DIRS:
        base = src_root / d
        if not base.is_dir():
            continue
        for p in sorted(base.rglob("*")):
            if p.is_file() and not _skip(p.relative_to(src_root)):
                files.append(p)
    for f in GOVERNED_FILES:
        p = src_root / f
        if p.is_file():
            files.append(p)
    return files


def sync_governed(src_root: Path, stage: Path) -> dict:
    """Copy the WHOLE governed tree from src_root into stage (parity)."""
    report = {"copied": 0, "unchanged": 0, "added": 0}
    for p in governed_source_files(src_root):
        rel = p.relative_to(src_root)
        dst = stage / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            if filecmp.cmp(p, dst, shallow=False):
                report["unchanged"] += 1
            else:
                shutil.copy2(p, dst)
                report["copied"] += 1
        else:
            shutil.copy2(p, dst)
            report["added"] += 1
    return report


# ── [3/7] retired-token scan (mirror of tests/test_no_retired_tokens.py) ───
def retired_patterns():
    return (
        re.compile(r"gemini-flash-latest"),
        re.compile(r"gemini-2\.5"),
        re.compile(r"gemini-flash(?![\-0-9a-z])"),
        re.compile(r"gemini-flash-lite(?![\-0-9a-z])"),
    )


def scan_tokens(root: Path, extra_files=("config.json",)) -> list:
    offenders = []
    from services.model_law import ENFORCEMENT_FILES
    for path in root.rglob("*.py"):
        rel = path.relative_to(root).as_posix()
        if rel in ENFORCEMENT_FILES:
            continue
        if _skip(path.relative_to(root)):
            continue
        for lineno, line in enumerate(
                path.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
            if any(p.search(line) for p in retired_patterns()):
                offenders.append("%s:%d" % (path.relative_to(root).as_posix(), lineno))
                break
    for name in extra_files:
        f = root / name
        if f.is_file():
            text = f.read_text(encoding="utf-8", errors="ignore")
            if any(p.search(text) for p in retired_patterns()):
                offenders.append(name)
    return offenders


# ── [4/7] completeness ──────────────────────────────────────────────────────
def completeness_missing(src_root: Path, stage: Path) -> list:
    missing = []
    for p in governed_source_files(src_root):
        rel = p.relative_to(src_root)
        if not (stage / rel).exists():
            missing.append(rel.as_posix())
    return missing


# ── [6/7] manifest + zip ────────────────────────────────────────────────────
def build_manifest(stage: Path, label: str, changed_note: str = "") -> tuple:
    files = sorted(p for p in stage.rglob("*")
                   if p.is_file() and p.name != "FILES_MANIFEST.txt")
    total = sum(p.stat().st_size for p in files)
    lines = [
        "Nabil-gold FINAL (%s SCALP) - FILES MANIFEST" % label,
        "Built: %s - LOCAL-ONLY (no cloud)" % time.strftime("%Y-%m-%d"),
        "Files (measured at build time): %d + this manifest" % len(files),
        "Total bytes (measured): %d" % total,
    ]
    if changed_note:
        lines += ["", changed_note]
    lines += ["", "-- measured listing --"]
    lines += ["%10d  %s" % (p.stat().st_size, p.relative_to(stage).as_posix())
              for p in files]
    (stage / "FILES_MANIFEST.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(files), total


def zip_and_verify(stage: Path, out: Path) -> dict:
    allf = sorted(p for p in stage.rglob("*") if p.is_file())
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in allf:
            z.write(p, p.relative_to(stage).as_posix())
    tmp = Path(tempfile.mkdtemp())
    try:
        with zipfile.ZipFile(out) as z:
            if z.testzip() is not None:
                raise RuntimeError("zip integrity failure: %s" % out)
            z.extractall(tmp)
        mism = [p.relative_to(stage).as_posix() for p in allf
                if hashlib.sha256(p.read_bytes()).hexdigest()
                != hashlib.sha256((tmp / p.relative_to(stage)).read_bytes()).hexdigest()]
        return {"files": len(allf), "bytes": out.stat().st_size, "mismatches": mism}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ── [5/7] VPS-simulation suite ──────────────────────────────────────────────
def vps_sim_suite(src_root: Path, stage: Path, timeout: int = 900) -> dict:
    sim = Path(tempfile.mkdtemp(prefix="vps_sim_"))
    try:
        # Faithful copy of the operator machine: the FULL source tree
        # INCLUDING storage/ (tests read label corpora and archives there)
        # and .env.template - minus caches/junk and secret env files. Then
        # the stage is overlaid on top (what the installer changes).
        for p in src_root.rglob("*"):
            rel = p.relative_to(src_root)
            if _is_secret_env(rel.name):
                continue
            if any(part in SKIP_DIR_NAMES and part != "storage" for part in rel.parts):
                continue
            if any(mark in rel.name for mark in (".pyc", ".bak", ".zip")):
                continue
            dst = sim / rel
            if p.is_dir():
                dst.mkdir(parents=True, exist_ok=True)
            else:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, dst)
        for p in stage.rglob("*"):
            rel = p.relative_to(stage)
            if p.is_dir():
                (sim / rel).mkdir(parents=True, exist_ok=True)
            else:
                (sim / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, sim / rel)
        proc = subprocess.run(
            [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"],
            cwd=str(sim), capture_output=True, text=True, timeout=timeout)
        out_lines = (proc.stdout or "").strip().splitlines()
        tail = out_lines[-1:] or [""]
        failed = [l for l in out_lines if l.startswith("FAILED")][:20]
        return {"rc": proc.returncode, "tail": tail[0].strip("= "), "failed": failed}
    finally:
        shutil.rmtree(sim, ignore_errors=True)


# ── [7/7] files-changed report ──────────────────────────────────────────────
def changed_report(prev_dir: Path, new_dir: Path) -> list:
    """(relpath, status) - status in {added, changed}; zip-relative paths.

    Only GOVERNED paths are reported (installer scripts/docs live in the
    package lineage only and are not source-tree state).
    """
    old_files = {p.relative_to(prev_dir).as_posix(): p
                 for p in prev_dir.rglob("*") if p.is_file()}
    new_files = {p.relative_to(new_dir).as_posix(): p
                 for p in new_dir.rglob("*") if p.is_file()}
    out = []
    for rel in sorted(new_files):
        if rel == "FILES_MANIFEST.txt":
            continue
        governed = rel.split("/")[0] in GOVERNED_DIRS or rel in GOVERNED_FILES
        if rel not in old_files:
            if governed:
                out.append((rel, "added"))
        elif governed and not filecmp.cmp(old_files[rel], new_files[rel], shallow=False):
            out.append((rel, "changed"))
    return out


def write_files_doc(doc_path: Path, prev_dir: Path, new_dir: Path,
                    label: str, suite_tail: str, zip_info: dict) -> int:
    rows = changed_report(prev_dir, new_dir)
    lines = [
        "# ملفات التعديل — %s (مولَّدة آلياً بواسطة scripts/build_package.py)" % label,
        "",
        "الحزمة: `%s` — %d بايت / %d ملفاً · فكّ-تحقق sha256: %s" % (
            zip_info.get("name", "-"), zip_info.get("bytes", 0), zip_info.get("files", 0),
            "نظيف" if not zip_info.get("mismatches") else "فشل!"),
        "المجموعة الكاملة (داخل شجرة محاكاة VPS): %s" % suite_tail,
        "",
        "| # | الملف (مسار كامل) | الحالة |",
        "|---|---|---|",
    ]
    for i, (rel, status) in enumerate(rows, 1):
        lines.append("| %d | `%s` | %s |" % (i, rel, "جديد" if status == "added" else "معدَّل"))
    lines += ["", "---", ""]
    for rel, status in rows:
        lines.append("## `%s` — %s — diff كامل" % (
            rel, "جديد في الحزمة" if status == "added" else "معدَّل"))
        lines.append("```diff")
        old, new = prev_dir / rel, new_dir / rel
        if old.exists():
            import difflib
            a = old.read_text(encoding="utf-8", errors="ignore").splitlines()
            b = new.read_text(encoding="utf-8", errors="ignore").splitlines()
            diff = list(difflib.unified_diff(a, b, lineterm="", n=2,
                                             fromfile="قبل " + label, tofile="بعد " + label))
            lines += diff if diff else ["(لا فرق نصي — تغيّر الترميز/النهايات فقط)"]
        else:
            body = new.read_text(encoding="utf-8", errors="ignore").splitlines()
            lines += ["+ (ملف جديد بالكامل)"] + ["+ " + l for l in body[:40]]
            if len(body) > 40:
                lines.append("+ ... (%d سطراً إجمالاً — الكامل داخل الحزمة)" % len(body))
        lines.append("```")
        lines.append("")
    doc_path.parent.mkdir(parents=True, exist_ok=True)
    doc_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(rows)


# ── main ────────────────────────────────────────────────────────────────────
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="R25.12 packaging tool (diff-driven, self-verifying).")
    ap.add_argument("--prev", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--label", required=True)
    ap.add_argument("--files-doc", default=None)
    ap.add_argument("--readme-title", default=None)
    ap.add_argument("--readme-insert", default=None)
    ap.add_argument("--skip-suite", action="store_true",
                    help="UNIT-TEST ONLY: skip the VPS-simulation suite run")
    args = ap.parse_args(argv)

    prev_zip, out_zip = Path(args.prev), Path(args.out)
    if not prev_zip.is_file():
        print("FAIL: --prev not found: %s" % prev_zip)
        return 1
    work = Path(tempfile.mkdtemp(prefix="pkg_build_"))
    ok = True
    off, missing = [], []
    zi = {"bytes": 0, "files": 0, "mismatches": ["not-built"], "name": out_zip.name}
    suite_tail = "SKIPPED (--skip-suite; unit tests only)"
    try:
        stage = work / "stage"
        with zipfile.ZipFile(prev_zip) as z:
            z.extractall(stage)
        print("[2/7] syncing the governed tree (parity policy) ...")
        rep = sync_governed(ROOT, stage)
        print("      copied=%(copied)d unchanged=%(unchanged)d added=%(added)d" % rep)

        print("[3/7] retired-token scan over the stage ...")
        off = scan_tokens(stage)
        print("      offenders: %s" % (off or "NONE ✓"))
        ok &= not off

        print("[4/7] completeness (every governed source file in the stage) ...")
        missing = completeness_missing(ROOT, stage)
        print("      missing: %s" % (missing or "NONE ✓"))
        ok &= not missing

        if not args.skip_suite:
            print("[5/7] VPS-simulation: full source tree + stage overlay, FULL suite ...")
            res = vps_sim_suite(ROOT, stage)
            suite_tail = res["tail"]
            print("      rc=%s | %s" % (res["rc"], suite_tail))
            for line in res.get("failed", []):
                print("      FAILED %s" % line)
            ok &= (res["rc"] == 0)

        if args.readme_title or args.readme_insert:
            rd = stage / "INSTALL_README_ARABIC.txt"
            if rd.exists():
                lines = rd.read_text(encoding="utf-8").splitlines()
                if args.readme_title:
                    lines[0] = args.readme_title
                if args.readme_insert:
                    block = Path(args.readme_insert)
                    ins = block.read_text(encoding="utf-8").splitlines() if block.is_file() else []
                    lines = lines[:1] + ins + lines[1:]
                rd.write_text("\n".join(lines) + "\n", encoding="utf-8")

        print("[6/7] manifest + zip + roundtrip sha256 ...")
        note = ("R25.12 policy: the package SHIPS THE WHOLE GOVERNED TREE "
                "(agents/services/utils/scripts/tests/config_patch + config.json), "
                "built mechanically by scripts/build_package.py (diff-driven, self-verifying).")
        build_manifest(stage, args.label, note)
        out_zip.parent.mkdir(parents=True, exist_ok=True)
        zi = zip_and_verify(stage, out_zip)
        zi["name"] = out_zip.name
        print("      zip: %d bytes / %d files | roundtrip: %s"
              % (zi["bytes"], zi["files"], zi["mismatches"] or "NONE ✓"))
        ok &= not zi["mismatches"]

        if args.files_doc:
            prev_dir = work / "prev"
            with zipfile.ZipFile(prev_zip) as z:
                z.extractall(prev_dir)
            n = write_files_doc(Path(args.files_doc), prev_dir, stage,
                                args.label, suite_tail, zi)
            print("[7/7] files-changed doc: %s (%d changed/added)" % (args.files_doc, n))
        else:
            print("[7/7] files-changed doc: skipped (--files-doc not given)")

        print("=" * 64)
        print("CHECKLIST %s — suite:%s tokens:%s completeness:%s roundtrip:%s"
              % ("PASS ✓" if ok else "FAIL ✗",
                 "SKIPPED" if args.skip_suite else "OK",
                 "OK" if not off else "FAIL", "OK" if not missing else "FAIL",
                 "OK" if not zi["mismatches"] else "FAIL"))
        return 0 if ok else 1
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
