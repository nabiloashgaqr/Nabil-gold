"""Automated Multi-Pair MT5 Historical Data Fetcher and Auction Flow Calibration Trainer.

Trains and builds logistic calibration curves for ALL enabled pairs:
- XAU/USD (Gold)
- WTI/USD (Crude Oil)
- EUR/USD (Euro)
- GBP/USD (British Pound)
- USD/CAD (Canadian Dollar)
- USD/JPY (Japanese Yen)

Fetches:
1. Native M5, M15, H1, H4 candles from MT5 broker feed.
2. High-resolution broker tick history into dedicated storage SQLite files.
3. Fits logistic sigmoid calibration models (alpha, beta, span, lift).
4. Generates verified JSON calibration artifacts in storage/model_calibration/.
5. Locks calibration_required=true in config.json.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.auction_flow_store import AuctionFlowStore
from services.timeframe_fusion import CANONICAL_TIMEFRAMES
from utils.helpers import load_config
from utils.instruments import config_for_instrument, enabled_instruments, normalize_symbol
from scripts.build_agent_calibrations import (
    _fetch_ticks,
    _mt5_ready,
    _native_rates,
    _symbol,
    build_auction,
)

CONFIG_PATH = ROOT / "config.json"


def instrument_paths(base_config: Dict[str, Any], symbol: str) -> Tuple[Dict[str, Any], Path, Path]:
    norm_sym = normalize_symbol(symbol)
    icfg = config_for_instrument(base_config, {"symbol": norm_sym})
    auction_cfg = icfg.get("auction_flow") or {}
    store_raw = str(auction_cfg.get("storage_path") or "storage/auction_flow.sqlite3")
    cal_raw = str(auction_cfg.get("calibration_path") or "storage/model_calibration/auction_flow_v1.json")
    
    if norm_sym == "XAU/USD":
        store_path = ROOT / store_raw
        cal_path = ROOT / cal_raw
    else:
        stem = norm_sym.replace("/", "").lower()
        sp = Path(store_raw)
        cp = Path(cal_raw)
        store_path = ROOT / sp.with_name(f"{sp.stem}_{stem}{sp.suffix}")
        cal_path = ROOT / cp.with_name(f"{cp.stem}_{stem}{cp.suffix}")

    store_path.parent.mkdir(parents=True, exist_ok=True)
    cal_path.parent.mkdir(parents=True, exist_ok=True)
    return icfg, store_path, cal_path


def set_instrument_calibration_flag(cfg_path: Path, symbol: str, required: bool) -> bool:
    norm_sym = normalize_symbol(symbol)
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    changed = False
    for inst in cfg.get("instruments") or []:
        if isinstance(inst, dict) and normalize_symbol(inst.get("symbol")) == norm_sym:
            inst.setdefault("auction_flow", {})["calibration_required"] = bool(required)
            changed = True
    if not changed:
        cfg.setdefault("instruments", []).append({
            "symbol": norm_sym,
            "auction_flow": {"calibration_required": bool(required)}
        })
    cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return True


def train_single_instrument(
    mt5, base_config: Dict[str, Any], symbol: str,
    days: int = 180, tick_days: int = 60, force: bool = False
) -> bool:
    norm_sym = normalize_symbol(symbol)
    print("\n" + "=" * 65)
    print(f"🎯 TRAINING AUCTION FLOW CALIBRATION: {norm_sym}")
    print("=" * 65)

    icfg, store_path, cal_path = instrument_paths(base_config, norm_sym)
    broker_sym = _symbol(icfg)
    print(f"   • Broker Symbol:    {broker_sym}")
    print(f"   • SQLite Database:  {store_path.relative_to(ROOT)}")
    print(f"   • Model Output:     {cal_path.relative_to(ROOT)}")

    if not mt5.symbol_select(broker_sym, True):
        print(f"❌ MT5 symbol_select failed for {broker_sym}: {mt5.last_error()}")
        return False

    print(f"📥 Fetching {days} days of native candle history ({', '.join(CANONICAL_TIMEFRAMES)})...")
    rates = {}
    for tf in CANONICAL_TIMEFRAMES:
        try:
            r = _native_rates(mt5, broker_sym, tf, days)
            rates[tf] = r
            print(f"   • {tf:4s}: {len(r):5d} candles")
        except Exception as exc:
            print(f"❌ Failed to fetch {tf} rates for {broker_sym}: {exc}")
            return False

    store = AuctionFlowStore(str(store_path))
    total_ticks = 0
    fetch_errors = []
    print(f"📥 Fetching broker tick history (target {tick_days} days)...")
    for attempt_days in (tick_days, 30, 15, 7):
        try:
            total_ticks = _fetch_ticks(mt5, broker_sym, attempt_days, store)
            print(f"   • Loaded {total_ticks:,} ticks across {attempt_days} days")
            break
        except Exception as exc:
            fetch_errors.append(f"{attempt_days}d: {exc}")
            print(f"   ⚠️ {attempt_days}d attempt failed: {exc}")
    else:
        print("❌ Tick fetch failed at all ranges: " + "; ".join(fetch_errors))
        return False

    print("🧠 Fitting logistic sigmoid model & computing span/lift...")
    try:
        payload = build_auction(icfg, rates, store, cal_path)
    except Exception as exc:
        print(f"❌ build_auction failed for {norm_sym}: {exc}")
        return False

    span = float(((payload or {}).get("curve_health") or {}).get("span_points") or 0.0)
    lift = float(((payload or {}).get("curve_health") or {}).get("tercile_lift_points") or 0.0)
    samples = payload.get("sample_count", 0)
    print(f"✅ FIT RESULT: {samples} samples | span={span:.2f}pp | lift={lift:.2f}pp")

    set_instrument_calibration_flag(CONFIG_PATH, norm_sym, True)
    print(f"🔒 Locked calibration_required=true for {norm_sym} in config.json")

    # Verify agent can load the curve immediately
    from agents.auction_flow_agent import AuctionFlowAgent
    fresh_cfg = config_for_instrument(load_config(), {"symbol": norm_sym})
    agent = AuctionFlowAgent(fresh_cfg)
    if agent.calibration is None:
        print(f"⚠️ Warning: Agent could not load generated curve for {norm_sym}")
        return False

    print(f"🎉 {norm_sym} AUCTION FLOW CALIBRATION OPERATIONAL!")
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description="Multi-pair MT5 historical data fetcher & auction trainer")
    parser.add_argument("--symbol", default="ALL", help="Specific symbol (e.g. EUR/USD) or ALL")
    parser.add_argument("--days", type=int, default=180, help="Candle history days")
    parser.add_argument("--tick-days", type=int, default=60, help="Broker tick history days")
    args = parser.parse_args()

    print("=" * 65)
    print("🚀 STARTING UNIVERSAL MULTI-PAIR CALIBRATION TRAINER")
    print("=" * 65)

    base_config = load_config()
    all_inst = enabled_instruments(base_config)

    if args.symbol.upper() == "ALL":
        target_symbols = [inst["symbol"] for inst in all_inst]
    else:
        target_symbols = [normalize_symbol(args.symbol)]

    print(f"📋 Target Symbols ({len(target_symbols)}): {', '.join(target_symbols)}")

    mt5 = _mt5_ready()
    success_count = 0

    for sym in target_symbols:
        try:
            ok = train_single_instrument(mt5, base_config, sym, days=args.days, tick_days=args.tick_days)
            if ok:
                success_count += 1
        except Exception as exc:
            print(f"❌ Exception training {sym}: {exc}")

    print("\n" + "=" * 65)
    print(f"🏁 CALIBRATION TRAINING SUMMARY: {success_count}/{len(target_symbols)} PAIRS COMPLETED")
    print("=" * 65)
    return 0 if success_count == len(target_symbols) else 1


if __name__ == "__main__":
    raise SystemExit(main())
