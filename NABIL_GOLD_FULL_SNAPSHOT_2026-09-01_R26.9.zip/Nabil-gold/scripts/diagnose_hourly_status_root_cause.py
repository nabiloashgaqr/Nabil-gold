"""Diagnose exact root cause of missing hourly status message."""
from __future__ import annotations

import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from utils.helpers import load_config


def main():
    print("=" * 75)
    print("         التحقيق الجنائي في سبب عدم إرسال رسالة الحالة الساعية         ")
    print("=" * 75)

    cfg = load_config()
    notif = cfg.get("notifications", {}) or {}
    now = datetime.now(timezone.utc)
    current_hour_key = now.strftime("%Y-%m-%dT%H")

    # 1. فحص ملف قفل الساعة
    slot_path = ROOT / "storage" / "hourly_status_last.json"
    print("\n[1] فحص ملف قفل الساعة (storage/hourly_status_last.json):")
    if slot_path.exists():
        try:
            mtime = datetime.fromtimestamp(slot_path.stat().st_mtime, timezone.utc)
            content = json.loads(slot_path.read_text(encoding="utf-8"))
            print(f"  • الملف موجود وتم تعديله في: {mtime.strftime('%Y-%m-%d %H:%M:%S')} UTC")
            print(f"  • محتوى الملف: {content}")
            if content.get("hour") == current_hour_key:
                print(f"  🚨 السبب الرئيسي: الملف مسجل به أن الساعة ({current_hour_key}) تم الإرسال فيها بالفعل!")
                print(f"     وبالتالي أي تشغيل في نفس الساعة يتم إيقافه تلقائياً لمنع التكرار (Dedup Guard).")
        except Exception as e:
            print(f"  ⚠️ خطأ في قراءة الملف: {e}")
    else:
        print("  • الملف غير موجود (القفل مفتوح وجاهز للإرسال).")

    # 2. فحص نافذة الدقائق
    print(f"\n[2] فحص شرط نافذة رأس الساعة (minute < 10):")
    print(f"  • الدقيقة الحالية بتوقيت UTC: {now.minute}")
    if now.minute < 10:
        print(f"  • نافذة رأس الساعة: مفتوحة (الدقيقة {now.minute} < 10) ✅")
    else:
        print(f"  • نافذة رأس الساعة: مغلقة حالياً (الدقيقة {now.minute} >= 10).")
        print(f"    (المنظومة تسمح بإرسال الحالة فقط في أول 10 دقائق من كل ساعة لمنع العشوائية).")

    # 3. فحص سجلات التشغيل الأخيرة
    print("\n[3] فحص آخر نشاط للمنظومة على القرص:")
    shared_data = ROOT / "storage" / "shared_market_data.json"
    if shared_data.exists():
        sm_time = datetime.fromtimestamp(shared_data.stat().st_mtime, timezone.utc)
        print(f"  • آخر تحديث لبيانات السوق (shared_market_data.json): {sm_time.strftime('%Y-%m-%d %H:%M:%S')} UTC")

    measurements = ROOT / "storage" / "agent_measurements" / f"agent_system_{now.strftime('%Y-%m-%d')}.jsonl"
    if measurements.exists():
        mm_time = datetime.fromtimestamp(measurements.stat().st_mtime, timezone.utc)
        print(f"  • آخر قياس مسجل للوكلاء (agent_measurements): {mm_time.strftime('%Y-%m-%d %H:%M:%S')} UTC")

    # 4. تصفير القفل للاستعداد لرأس الساعة القادمة
    if slot_path.exists():
        slot_path.unlink()
        print("\n[4] الإجراء التصحيحي:")
        print("  ✅ تم حذف قفل الساعة المتبقي بنجاح لضمان انطلاق الرسالة عند رأس الساعة القادمة دون أي حجب.")

    print("\n" + "=" * 75)


if __name__ == "__main__":
    main()
