"""
scripts/map_support_report.py — READY maps + their agent supporters (2026-08-19).

Answers exactly: "which maps were qualified/READY today, and which agents
supported each map?" from two persisted sources:

  1) storage/session_plans.json      - planner snapshots incl. agent_opinions
     (the 5 voters + macro_fundamental) and quality metrics.
  2) storage/agent_measurements/*.jsonl - the live book per snapshot:
     agents (incl. auction_flow), macro, auction measurement, and the
     admission verdicts for BUY/SELL replayed with the CURRENT config.

Output: console summary + storage/map_support_report_<date>.json/.txt

Usage:
  python scripts/map_support_report.py                     # today (Asia/Hebron)
  python scripts/map_support_report.py --date 2026-08-19
  python scripts/map_support_report.py --days 7
  python scripts/map_support_report.py --ready-only        # only READY maps
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo
from typing import Any, Dict, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# Console-encoding guard: Windows consoles are cp1252; Arabic would crash
# print(). Reconfigure to replace unencodable chars instead of raising.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

from services.thesis_consensus import evaluate_directional_admission  # noqa: E402
from utils.helpers import load_config  # noqa: E402

VOTERS = ("technical", "multitimeframe", "classical", "smc", "price_action")
ALL_READERS = (*VOTERS, "auction_flow", "macro_fundamental")


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _dt(value: Any) -> datetime | None:
    for fmt in (str(value or ""),):
        try:
            return datetime.fromisoformat(fmt.replace("Z", "+00:00"))
        except (TypeError, ValueError):
            return None


# ── source 1: session_plans.json ─────────────────────────────────────────────
def _plan_payload(row: Dict[str, Any]) -> Dict[str, Any]:
    p = row.get("payload")
    return p if isinstance(p, dict) else row


def _row_time(row: Dict[str, Any], plan: Dict[str, Any]) -> datetime | None:
    for value in (row.get("analysis_run_at"), row.get("updated_at"), row.get("created_at"),
                  plan.get("plan_created_at"), plan.get("created_at")):
        parsed = _dt(value)
        if parsed:
            return parsed
    return None


def _opinions(plan: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    opinions = plan.get("agent_opinions") or []
    if not opinions:
        opinions = ((plan.get("execution_audit") or {}).get("agent_reads") or [])
    details: Dict[str, Dict[str, Any]] = {}
    for op in opinions:
        if not isinstance(op, dict):
            continue
        key = str(op.get("key") or op.get("agent") or "")
        if key:
            details[key] = {
                "direction": str(op.get("direction") or op.get("signal") or "WAIT").upper(),
                "confidence": _f(op.get("confidence")),
            }
    macro = plan.get("macro_plan") or {}
    if isinstance(macro, dict):
        direction = str(macro.get("direction") or macro.get("signal") or "WAIT").upper()
        if direction in {"BUY", "SELL", "WAIT"}:
            details["macro_fundamental"] = {
                "direction": direction,
                "confidence": _f(macro.get("confidence")),
            }
    return details


def _map_metrics(plan: Dict[str, Any]) -> Dict[str, Any]:
    primary = plan.get("primary_poi") or {}
    if not isinstance(primary, dict):
        primary = {}
    setup_quality = _f(primary.get("quality_score"),
                       _f((primary.get("setup_quality") or {}).get("score")
                          if isinstance(primary.get("setup_quality"), dict) else 0.0))
    return {
        "side": str(plan.get("session_bias") or plan.get("authority_direction") or "WAIT").upper(),
        "ready": bool(plan.get("plan_ready")),
        "status": plan.get("plan_status"),
        "reason": plan.get("plan_reason"),
        "dominance": _f(primary.get("thesis_dominance_score")),
        "return_probability": _f(primary.get("return_probability_score")),
        "setup_quality": setup_quality,
        "trigger_score": _f(primary.get("trigger_score")),
        "structure_quality": str(plan.get("structure_quality")
                                 or (primary.get("details") or {}).get("structure_quality") or "UNKNOWN").upper(),
        "planner_score": _f(plan.get("planner_confidence")),
        "setup_type": primary.get("setup_type") or plan.get("scenario_type"),
        "setup_state": primary.get("setup_state"),
    }


# ── source 2: agent_measurements jsonl ───────────────────────────────────────
def _measurement_rows(date_str: str, root: Path) -> List[Dict[str, Any]]:
    base = root / "storage" / "agent_measurements"
    path = base / f"agent_system_{date_str}.jsonl"
    rows: List[Dict[str, Any]] = []
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                row = json.loads(line)
                if isinstance(row, dict):
                    rows.append(row)
            except Exception:  # noqa: BLE001
                continue
    return rows


def _measurement_book(row: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    book: Dict[str, Dict[str, Any]] = {}
    for name, info in (row.get("agents") or {}).items():
        if isinstance(info, dict):
            book[name] = {
                "direction": str(info.get("direction") or "WAIT").upper(),
                "confidence": _f(info.get("confidence")),
                "qualified": bool(info.get("qualified")),
            }
    macro = row.get("macro") or {}
    if isinstance(macro, dict) and macro.get("bias"):
        side = {"BULLISH_GOLD": "BUY", "BEARISH_GOLD": "SELL"}.get(str(macro["bias"]).upper(), "WAIT")
        book["macro_fundamental"] = {
            "direction": side, "confidence": _f(macro.get("confidence")), "qualified": False,
        }
    auction = row.get("auction_measurement") or {}
    if isinstance(auction, dict):
        book.setdefault("auction_flow", {
            "direction": "WAIT", "confidence": _f(auction.get("confidence")),
            "qualified": False, "state": auction.get("state"),
        })
    return book


# ── supporter classification ────────────────────────────────────────────────
def _support_rows(book: Dict[str, Dict[str, Any]], side: str, min_conf: float) -> List[Dict[str, Any]]:
    rows = []
    for name in ALL_READERS:
        info = book.get(name)
        if not isinstance(info, dict):
            continue
        direction = str(info.get("direction") or "WAIT").upper()
        confidence = _f(info.get("confidence"))
        qualified = confidence >= min_conf and direction in {"BUY", "SELL"}
        role = "NEUTRAL"
        if side in {"BUY", "SELL"}:
            if direction == side:
                role = "SUPPORTS" if qualified else "WEAK_SUPPORT"
            elif direction in {"BUY", "SELL"}:
                role = "OPPOSES" if qualified else "WEAK_OPPOSE"
        rows.append({
            "agent": name,
            "direction": direction,
            "confidence": round(confidence, 1),
            "qualified": qualified,
            "role": role,
        })
    return sorted(rows, key=lambda r: (-_f(r["confidence"])))


def _plan_report(plan_row: Dict[str, Any], cfg: Dict[str, Any], min_conf: float) -> Dict[str, Any]:
    plan = _plan_payload(plan_row)
    metrics = _map_metrics(plan)
    book = _opinions(plan)
    side = metrics["side"]
    admission = evaluate_directional_admission(side, book, cfg) if side in {"BUY", "SELL"} and book else {}
    supporters = [k for k in book if str(book[k].get("direction") or "").upper() == side
                  and _f(book[k].get("confidence")) >= min_conf]
    opponents = [k for k in book if str(book[k].get("direction") or "").upper() in {"BUY", "SELL"}
                 and str(book[k].get("direction") or "").upper() != side
                 and _f(book[k].get("confidence")) >= min_conf]
    return {
        "source": "session_plans",
        "time": str(plan_row.get("analysis_run_at") or plan_row.get("created_at") or ""),
        "snapshot_id": str(plan_row.get("id") or plan_row.get("plan_id") or ""),
        **metrics,
        "agents": _support_rows(book, side, min_conf),
        "supporters": supporters,
        "opponents": opponents,
        "admission": {
            "allow": bool(admission.get("allow")),
            "path": admission.get("path"),
            "net": admission.get("confidence"),
            "reason": admission.get("reason") or admission.get("family_diversity_reason"),
        },
    }


def _measurement_report(row: Dict[str, Any], cfg: Dict[str, Any], min_conf: float) -> Dict[str, Any]:
    map_info = row.get("map") or {}
    side = str(map_info.get("side") or "WAIT").upper()
    if side in {"NONE", "", "WAIT"}:
        side = str(row.get("decision") or "WAIT").upper()
        if side not in {"BUY", "SELL"}:
            side = "WAIT"
    book = _measurement_book(row)
    admission = (row.get("admission") or {}).get(side) if side in {"BUY", "SELL"} else {}
    smc = row.get("smc_measurement") or {}
    setup = smc.get("setup_candidates")
    return {
        "source": "agent_measurements",
        "time": str(row.get("generated_at") or ""),
        "snapshot_id": str(row.get("snapshot_id") or ""),
        "side": side,
        "ready": bool(map_info.get("ready")),
        "status": map_info.get("status"),
        "reason": None,
        "dominance": _f(smc.get("dominance")),
        "return_probability": _f(smc.get("return_probability")),
        "setup_quality": _f(smc.get("quality")),
        "trigger_score": _f(smc.get("trigger_score")),
        "structure_quality": str(smc.get("structure_quality") or "UNKNOWN").upper(),
        "planner_score": None,
        "setup_type": smc.get("setup_type"),
        "setup_state": smc.get("setup_state"),
        "agents": _support_rows(book, side, min_conf),
        "supporters": list(admission.get("supporters") or []),
        "opponents": list(admission.get("opponents") or []),
        "admission": {
            "allow": bool(admission.get("allow")),
            "path": admission.get("path"),
            "net": admission.get("confidence"),
            "reason": admission.get("reason"),
        },
    }


# ── rendering ────────────────────────────────────────────────────────────────
def _unique_ready(reports: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Collapse ready snapshots into unique maps (same side + quality signature)."""
    sigs: Dict[tuple, List[Dict[str, Any]]] = {}
    for r in reports:
        if not r["ready"]:
            continue
        sig = (r.get("side"), r.get("dominance"), r.get("return_probability"),
               r.get("setup_quality"), r.get("trigger_score"))
        sigs.setdefault(sig, []).append(r)
    out = []
    for rows in sigs.values():
        rows.sort(key=lambda r: str(r.get("time") or ""))
        last = rows[-1]
        out.append({
            "side": last["side"],
            "dominance": last["dominance"],
            "return_probability": last["return_probability"],
            "setup_quality": last["setup_quality"],
            "trigger_score": last["trigger_score"],
            "structure_quality": last["structure_quality"],
            "cycles": len(rows),
            "first": rows[0].get("time"),
            "last": last.get("time"),
            "final_allow": last["admission"].get("allow"),
            "final_path": last["admission"].get("path"),
            "final_reason": last["admission"].get("reason"),
            "final_supporters": last["supporters"],
        })
    out.sort(key=lambda m: -int(m["cycles"]))
    return out


def _render(reports: List[Dict[str, Any]]) -> List[str]:
    lines: List[str] = []
    ready = [r for r in reports if r["ready"]]
    not_ready = [r for r in reports if not r["ready"]]
    uniques = _unique_ready(reports)
    lines.append(f"READY CYCLES: {len(ready)} | UNIQUE MAPS: {len(uniques)} | NOT READY: {len(not_ready)}")
    lines.append("")
    if uniques:
        lines.append("-" * 74)
        lines.append("UNIQUE READY MAPS (collapsed from repeated 5-min cycles)")
        lines.append(f"{'SIDE':<6} {'DOM':>5} {'RET':>5} {'QUAL':>5} {'TRIG':>5} {'CYCLES':>7}  FINAL ADMISSION")
        for m in uniques:
            lines.append(
                f"{m['side']:<6} {m['dominance']:>5} {m['return_probability']:>5} "
                f"{m['setup_quality']:>5} {m['trigger_score']:>5} {m['cycles']:>7}  "
                f"allow={m['final_allow']} path={m['final_path']} ({str(m['final_reason'] or '')[:70]})"
            )
        lines.append("-" * 74)
        lines.append("")
    for r in ready:
        lines.extend(_render_one(r))
    if not ready:
        lines.append("(no ready maps in this window)")
    if not_ready:
        lines.append("")
        lines.append("NEAR/REFUSED MAPS (closest refusals and their reasons)")
        for r in not_ready[:8]:
            lines.append(f"- {r['time']} | {r['side'] or 'WAIT'} | {r['status']} | {r['reason'] or r['admission']['reason'] or ''}")
    return lines


def _render_one(r: Dict[str, Any]) -> List[str]:
    lines = [
        "=" * 72,
        f"[{r['time']}]  {r['side'] or 'WAIT'}  ready={r['ready']}  status={r['status']}  ({r['source']})",
        f"quality: dominance={r['dominance']} return={r['return_probability']} "
        f"setup_quality={r['setup_quality']} trigger={r['trigger_score']} "
        f"structure={r['structure_quality']} planner={r['planner_score']}",
        f"admission: allow={r['admission'].get('allow')} path={r['admission'].get('path')} "
        f"net={r['admission'].get('net')}  {r['admission'].get('reason') or ''}",
        f"supporters={r['supporters']} opponents={r['opponents']}",
        "-" * 72,
        f"{'AGENT':<20} {'DIR':<6} {'CONF':>6} {'QUAL':>6}  ROLE",
    ]
    for a in r["agents"]:
        lines.append(
            f"{a['agent']:<20} {a['direction']:<6} {a['confidence']:>6} "
            f"{str(a['qualified']):>6}  {a['role']}"
        )
    lines.append("")
    return lines


def main() -> int:
    parser = argparse.ArgumentParser(description="Ready maps + agent supporters")
    parser.add_argument("--date", type=str, default=None, help="YYYY-MM-DD (default: today)")
    parser.add_argument("--days", type=int, default=None, help="trailing window in days")
    parser.add_argument("--ready-only", action="store_true")
    parser.add_argument("--root", type=str, default=str(ROOT))
    args = parser.parse_args()

    root = Path(args.root)
    config = load_config()
    tz_name = str((config.get("schedule") or {}).get("timezone") or "Asia/Hebron")
    zone = ZoneInfo(tz_name)
    if args.date:
        target = datetime.fromisoformat(args.date).date()
    else:
        target = datetime.now(timezone.utc).astimezone(zone).date()
    start = target if not args.days else target - timedelta(days=args.days)

    min_conf = _f((config.get("signal_requirements") or {}).get("agent_min_confidence"), 67.0)

    reports: List[Dict[str, Any]] = []

    plans_path = root / "storage" / "session_plans.json"
    if plans_path.exists():
        try:
            raw = json.loads(plans_path.read_text(encoding="utf-8"))
            for row in raw:
                if not isinstance(row, dict):
                    continue
                plan = _plan_payload(row)
                stamp = _row_time(row, plan)
                if stamp and start <= stamp.astimezone(zone).date() <= target:
                    reports.append(_plan_report(row, config, min_conf))
        except Exception as exc:  # noqa: BLE001
            print(f"[!] session_plans.json parse failed: {exc}")
    else:
        print("[!] storage/session_plans.json not found")

    # measurements merge: replace/augment by snapshot_id when both exist
    meas_rows = _measurement_rows(target.strftime("%Y-%m-%d"), root)
    by_snap = {r["snapshot_id"]: r for r in reports if r["snapshot_id"]}
    for row in meas_rows:
        rep = _measurement_report(row, config, min_conf)
        existing = by_snap.get(rep["snapshot_id"])
        if existing:
            existing["measurement_backup"] = {k: existing[k] for k in ("agents", "admission")}
            existing["agents"] = rep["agents"]
            existing["admission"] = rep["admission"]
            existing["supporter_source"] = "merged(session_plans+measurements)"
        else:
            reports.append(rep)

    reports.sort(key=lambda r: str(r.get("time") or ""))
    if args.ready_only:
        reports = [r for r in reports if r["ready"]]

    if not reports:
        print(f"No session-plan or measurement rows for {target} in {root}/storage/")
        print("Make sure the analysis ran today and agent_measurement.enabled is on (config).")
        return 1

    lines = _render(reports)
    # House convention: diagnostic outputs live in diagnostics/ (README_AR,
    # SNAPSHOT_README_AR), NOT storage/.
    out_base = root / "diagnostics" / f"map_support_report_{target.strftime('%Y-%m-%d')}"
    json_path = out_base.with_suffix(".json")
    txt_path = out_base.with_suffix(".txt")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps({
        "date": target.strftime("%Y-%m-%d"),
        "ready_count": sum(1 for r in reports if r["ready"]),
        "reports": reports,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    text = "\n".join(lines)
    txt_path.write_text(text, encoding="utf-8")
    print(text)
    print(f"\nJSON: {json_path}")
    print(f"TXT : {txt_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
