# =============================================================================
# RUN ALL TESTS - BUILD 31 R10 (post-audit verification) - ASCII only
# Fallback/alternative runner: logs the full pytest output to
# logs\test_run_<timestamp>.log and prints the tail.
# =============================================================================
[CmdletBinding()]
param()

$ErrorActionPreference = "Continue"
if (-not (Test-Path "config.json")) {
    Write-Host "ERROR: run this script inside the repo root (C:\Nabil-gold)." -ForegroundColor Red
    Exit 1
}
if (-not (Test-Path "logs")) { New-Item -ItemType Directory -Path "logs" | Out-Null }

$stamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
$log = "logs\test_run_$stamp.log"

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host " SMARTSIGNAL FULL TEST SUITE - logging to $log" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"

python -m pytest tests -q --tb=short -p no:cacheprovider 2>&1 | Tee-Object -FilePath $log
$rc = $LASTEXITCODE

Write-Host ""
if ($rc -eq 0) {
    Write-Host "[OK] ALL TESTS PASSED (exit code 0). Log: $log" -ForegroundColor Green
} else {
    Write-Host "[FAIL] pytest exited with code $rc. Log: $log" -ForegroundColor Red
    Write-Host "First failing lines:" -ForegroundColor Yellow
    Get-Content $log | Select-String -Pattern "FAILED|ERROR" | Select-Object -First 20
}
Exit $rc
