"""Threshold what-if replay over recorded agent measurements (read-only).

We already record, every cycle, each agent's direction + confidence and the
current price (storage/agent_measurements/*.jsonl). This tool replays those
frozen books through the REAL shared admission function under different
threshold settings and scores every admitted signal against the actual
forward price move — measured evidence for the operator's question:

    "Should we lower the agent bar / net floor / supporting-agent count,
     or keep the current strictness?"

For each candidate setting it reports:
  admitted   how many cycles would have produced a signal
  hit%       % of admitted signals where price moved in the signal's
             direction at the horizon (1h/2h/4h from later rows)
  avg move   average signed forward move in points (direction-adjusted)

Nothing is written; live config is not touched. Macro/Gemini books are not
stored in measurements, so Paths 2/3 cannot be replayed — the comparison is
over Path 1 (consensus) and Path 5 (two agents + auction), which is exactly
where the thresholds under discussion live.

Usage:
    python scripts/threshold_whatif.py                (all recorded days)
    python scripts/threshold_whatif.py --days 3       (last 3 days)
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from services.thesis_consensus import evaluate_directional_admission  # noqa: E402
from utils.helpers import load_config  # noqa: E402

HORIZONS = {"1h": 1.0, "2h": 2.0, "4h": 4.0}


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _load_rows(days: int) -> List[Dict[str, Any]]:
    base = ROOT / "storage" / "agent_measurements"
    if not base.exists():
        return []
    rows: List[Dict[str, Any]] = []
    for path in sorted(base.glob("agent_system_*.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if isinstance(row, dict) and row.get("agents"):
                rows.append(row)
    def stamp(row: Dict[str, Any]) -> datetime:
        raw = str(row.get("generated_at") or "").replace("Z", "+00:00")
        try:
            return datetime.fromisoformat(raw).astimezone(timezone.utc)
        except ValueError:
            return datetime.fromtimestamp(0, tz=timezone.utc)
    rows.sort(key=stamp)
    for row in rows:
        row["_ts"] = stamp(row)
    if days > 0 and rows:
        cutoff = rows[-1]["_ts"] - timedelta(days=days)
        rows = [r for r in rows if r["_ts"] >= cutoff]
    return rows


def _forward_moves(rows: List[Dict[str, Any]]) -> None:
    """Attach forward price changes at each horizon to every row."""
    for i, row in enumerate(rows):
        price = _f(row.get("current_price"))
        row["_fwd"] = {}
        if price <= 0:
            continue
        for label, hours in HORIZONS.items():
            target = row["_ts"] + timedelta(hours=hours)
            for later in rows[i + 1:]:
                later_price = _f(later.get("current_price"))
                if later["_ts"] >= target and later_price > 0:
                    row["_fwd"][label] = later_price - price
                    break


def _book(row: Dict[str, Any]) -> Dict[str, Any]:
    """Rebuild the agent detail book the admission function expects."""
    details: Dict[str, Any] = {}
    for name, info in (row.get("agents") or {}).items():
        if isinstance(info, dict):
            details[name] = {
                "direction": info.get("direction"),
                "signal": info.get("direction"),
                "confidence": _f(info.get("confidence")),
            }
    return details


def _variant_config(base: Dict[str, Any], agent_bar: float, min_agents: int,
                    net_floor: float) -> Dict[str, Any]:
    cfg = copy.deepcopy(base)
    sig = cfg.setdefault("signal_requirements", {})
    sig["agent_min_confidence"] = agent_bar
    sig["min_agents_agree"] = min_agents
    sig["min_consensus_confidence"] = net_floor
    two = sig.setdefault("two_agent_entry", {})
    two["agent_min_confidence"] = agent_bar
    two["min_consensus_confidence"] = net_floor
    path5 = sig.setdefault("path5_two_agent_auction", {})
    path5["agent_min_confidence"] = agent_bar
    path5["min_consensus_confidence"] = net_floor
    return cfg


def _replay(rows: List[Dict[str, Any]], cfg: Dict[str, Any]) -> Dict[str, Any]:
    admitted = 0
    paths: Dict[str, int] = {}
    hits = {label: [0, 0] for label in HORIZONS}       # [correct, total]
    moves = {label: [] for label in HORIZONS}          # signed, direction-adjusted
    for row in rows:
        details = _book(row)
        if not details:
            continue
        chosen = None
        for side in ("BUY", "SELL"):
            adm = evaluate_directional_admission(side, details, cfg)
            if adm.get("allow"):
                chosen = (side, adm)
                break
        if not chosen:
            continue
        side, adm = chosen
        admitted += 1
        path = str(adm.get("path") or "?")
        paths[path] = paths.get(path, 0) + 1
        sign = 1.0 if side == "BUY" else -1.0
        for label in HORIZONS:
            fwd = row.get("_fwd", {}).get(label)
            if fwd is None:
                continue
            adjusted = sign * fwd
            moves[label].append(adjusted)
            hits[label][1] += 1
            if adjusted > 0:
                hits[label][0] += 1
    out: Dict[str, Any] = {"admitted": admitted, "paths": paths}
    for label in HORIZONS:
        correct, total = hits[label]
        avg = sum(moves[label]) / len(moves[label]) if moves[label] else 0.0
        out[label] = {
            "scored": total,
            "hit_pct": round(correct / total * 100.0, 1) if total else None,
            "avg_move_points": round(avg, 2),
        }
    return out


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=0, help="restrict to the last N days")
    args = parser.parse_args()

    config = load_config()
    rows = _load_rows(args.days)
    if len(rows) < 12:
        print(f"Only {len(rows)} measurement rows found in storage/agent_measurements/.")
        print("Need at least ~12 (one hour of 5-minute cycles) to score forward moves.")
        print("Let SS_DemoAnalysis run and retry later — measurements accumulate automatically.")
        return 1
    _forward_moves(rows)
    scoreable = sum(1 for r in rows if r.get("_fwd"))
    first, last = rows[0]["_ts"], rows[-1]["_ts"]
    print("=" * 78)
    print(f"THRESHOLD WHAT-IF REPLAY — {len(rows)} cycles "
          f"({first:%Y-%m-%d %H:%M} .. {last:%Y-%m-%d %H:%M} UTC), "
          f"{scoreable} scoreable")
    print("=" * 78)
    print("Replays the REAL shared admission function over recorded agent books.")
    print("Macro/Gemini are not recorded, so admissions here = Path 1 + Path 5 only.")
    print()

    sig = config.get("signal_requirements") or {}
    current = (
        _f(sig.get("agent_min_confidence"), 67),
        int(sig.get("min_agents_agree", 3) or 3),
        _f(sig.get("min_consensus_confidence"), 72),
    )

    variants: List[Tuple[str, float, int, float]] = [
        ("CURRENT  bar=67 agents=3 net=72", 67, 3, 72),
        ("bar=65   agents=3 net=72",        65, 3, 72),
        ("bar=63   agents=3 net=72",        63, 3, 72),
        ("bar=67   agents=2 net=72",        67, 2, 72),
        ("bar=67   agents=3 net=68",        67, 3, 68),
        ("bar=67   agents=3 net=65",        67, 3, 65),
        ("bar=65   agents=2 net=68",        65, 2, 68),
        ("bar=63   agents=2 net=65",        63, 2, 65),
    ]

    header = (f"{'variant':<34} {'admit':>5} "
              f"{'1h hit%':>8} {'1h avg':>7} {'2h hit%':>8} {'2h avg':>7} "
              f"{'4h hit%':>8} {'4h avg':>7}  paths")
    print(header)
    print("-" * len(header))
    for label, bar, agents, net in variants:
        cfg = _variant_config(config, bar, agents, net)
        result = _replay(rows, cfg)
        def cell(h: str, key: str) -> str:
            value = result[h][key]
            if value is None:
                return "-"
            return f"{value}"
        marker = " <=" if (bar, agents, net) == current else ""
        path_str = ",".join(f"{k.split('_')[0]}:{v}" for k, v in sorted(result["paths"].items()))
        print(f"{label:<34} {result['admitted']:>5} "
              f"{cell('1h','hit_pct'):>8} {cell('1h','avg_move_points'):>7} "
              f"{cell('2h','hit_pct'):>8} {cell('2h','avg_move_points'):>7} "
              f"{cell('4h','hit_pct'):>8} {cell('4h','avg_move_points'):>7}  {path_str}{marker}")

    print()
    print("HOW TO DECIDE:")
    print("  * hit% > 55 with positive avg move at 1h-2h = the loosened setting is")
    print("    admitting genuinely predictive signals -> consider adopting it.")
    print("  * admit count rises but hit% falls toward ~50 = the extra signals are")
    print("    noise -> keep the current strictness.")
    print("  * Few admitted rows overall = not enough data yet; let measurements")
    print("    accumulate a few more days and re-run with --days 7.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
