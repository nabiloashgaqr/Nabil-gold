#!/usr/bin/env python3
"""Reset storage and dashboard for a new MT5 Demo Account.

Safely archives legacy trades into storage/backups/ and creates a clean,
zeroed-out slate so the dashboard displays ONLY fresh trades from the new account.
"""

from __future__ import annotations

import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STORAGE = ROOT / "storage"
BACKUPS = STORAGE / "backups"


def reset_demo_storage():
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_dir = BACKUPS / f"account_backup_{timestamp}"
    backup_dir.mkdir(parents=True, exist_ok=True)

    files_to_backup = [
        "trades.json",
        "trades_demo.json",
        "daily_report.json",
        "decision_audit.json",
        "setup_state_events.json",
        "learning_history.json",
        "shared_market_data.json",
    ]

    print(f"==================================================================")
    print(f"🔄 RESETTING STORAGE FOR NEW DEMO ACCOUNT")
    print(f"==================================================================")
    print(f"[*] Creating backup directory: {backup_dir.relative_to(ROOT)}")

    for fname in files_to_backup:
        src = STORAGE / fname
        if src.exists():
            dst = backup_dir / fname
            shutil.copy2(src, dst)
            print(f"    [+] Backed up: {fname}")

    # Reset files cleanly
    (STORAGE / "trades.json").write_text("[]\n", encoding="utf-8")
    (STORAGE / "trades_demo.json").write_text("[]\n", encoding="utf-8")
    (STORAGE / "decision_audit.json").write_text("[]\n", encoding="utf-8")
    (STORAGE / "setup_state_events.json").write_text("[]\n", encoding="utf-8")
    (STORAGE / "daily_report.json").write_text("{}\n", encoding="utf-8")

    # Clean temporary lock/halt/state files
    for tmp in [ROOT / ".demo_halt", ROOT / "tick_heartbeat.json", STORAGE / "live_snapshot.json"]:
        if tmp.exists():
            try:
                if tmp.is_file():
                    tmp.unlink()
                    print(f"    [*] Cleared lock file: {tmp.name}")
            except Exception:
                pass

    print(f"[OK] Legacy trade stores cleared. Fresh empty state initialized.")

    # Regenerate dashboard
    try:
        from scripts.generate_dashboard import generate_dashboard
        generate_dashboard()
        print(f"[OK] Dashboard regenerated with clean fresh state.")
    except Exception as e:
        print(f"[!] Dashboard generation note: {e}")

    print(f"==================================================================")
    print(f"✅ READY FOR NEW MT5 DEMO ACCOUNT!")
    print(f"==================================================================")


if __name__ == "__main__":
    reset_demo_storage()
