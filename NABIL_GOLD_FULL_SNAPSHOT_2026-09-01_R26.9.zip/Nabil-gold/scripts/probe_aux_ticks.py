#!/usr/bin/env python3
"""One-shot aux tick probe (BUILD 31 R15). NOT a second collector loop.

Purpose: settle, with evidence, whether the WTI+forex aux tick pipeline
works on THIS machine - separately from the long-running tick manager.

What it does ONCE per non-gold enabled symbol:
  1. attach to the MT5 terminal (read-only)
  2. symbol_select(broker_symbol, True)        (Market Watch subscription)
  3. symbol_info_tick(broker_symbol)           (read one live tick)
  4. store.record_tick(tick) + store.mark_heartbeat()
  5. re-read the store health and print the verdict

Interpretation:
  * probe OK        -> the whole pipeline (terminal, subscription, store)
                       works; if diagnose_auction_agent.py still shows inf
                       afterwards, the RUNNING tick manager is an OLD-code
                       process: restart it for real (see README R15).
  * probe FAILS     -> the printed reason names the broken layer
                       (terminal attach / Market Watch / no quote).

Usage:  python scripts\\probe_aux_ticks.py
Exit code 0 always (a report tool, not a gate).
"""
from __future__ import annotations

import json
import math
import sys
import time
from copy import deepcopy
from pathlib import Path

# Windows consoles/pipes may use cp1252, which cannot encode glyphs like the
# ">=" that appears in live refusal reasons. Replace instead of crash (the
# full-fidelity text still goes to the JSON output, which is always UTF-8).
try:
    sys.stdout.reconfigure(errors="replace")
except (AttributeError, ValueError):
    pass


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main() -> int:
    import argparse

    ap = argparse.ArgumentParser(description="One-shot aux tick probe (not a loop)")
    ap.add_argument("--root", default=str(ROOT),
                    help="project root holding config.json + storage (default: repo root)")
    args = ap.parse_args()
    root = Path(args.root)

    try:
        import MetaTrader5 as mt5
    except Exception as exc:  # noqa: BLE001
        print("FAIL: MetaTrader5 package unavailable: %s" % exc)
        return 0

    from utils.helpers import load_config
    from utils.instruments import (
        config_for_instrument,
        enabled_instruments,
        normalize_symbol,
        point_size,
    )
    from services.auction_flow_store import AuctionFlowStore

    cfg = json.loads((root / "config.json").read_text(encoding="utf-8")) \
        if (root / "config.json").exists() else load_config()
    base_sym = normalize_symbol(str(cfg.get("symbol") or "XAU/USD"))
    demo_map = (((cfg.get("execution") or {}).get("demo") or {}).get("symbol_map")) \
        or cfg.get("symbol_map") or {}

    if not mt5.initialize():
        print("FAIL: MT5 terminal attach failed: %s (is the terminal running and logged in?)"
              % str(mt5.last_error()))
        return 0
    print("MT5 terminal attached OK.")

    auction_cfg = cfg.get("auction_flow", {}) or {}
    base_store = Path(str(auction_cfg.get("storage_path") or "storage/auction_flow.sqlite3"))
    if not base_store.is_absolute():
        base_store = root / base_store

    targets = []
    for inst in enabled_instruments(cfg):
        sym = normalize_symbol(str(inst.get("symbol") or ""))
        if not sym or sym == base_sym:
            continue
        stem = sym.replace("/", "").lower()
        spath = base_store.with_name("%s_%s%s" % (base_store.stem, stem, base_store.suffix))
        targets.append((sym, str(demo_map.get(sym, sym.replace("/", ""))), spath))

    print("Probing %d aux symbols (one tick each, then recording it):\n" % len(targets))
    summary = {}
    for sym, broker_sym, spath in targets:
        row = {"broker_symbol": broker_sym}
        selected = False
        try:
            selected = bool(mt5.symbol_select(broker_sym, True))
        except Exception as exc:  # noqa: BLE001
            row["select_error"] = str(exc)
        if not selected:
            row["verdict"] = "FAIL: symbol_select False - symbol missing from this broker/terminal?"
            summary[sym] = row
            print(" %-8s -> %s" % (sym, row["verdict"]))
            continue
        tick = mt5.symbol_info_tick(broker_sym)
        if tick is None:
            row["verdict"] = ("FAIL: symbol_info_tick None - Market Watch has no quote yet; "
                              "open the symbol chart once in MT5, then re-run.")
            summary[sym] = row
            print(" %-8s -> %s" % (sym, row["verdict"]))
            continue
        store = AuctionFlowStore(str(spath))
        recorded = store.record_tick(tick)
        store.mark_heartbeat()
        time.sleep(0.2)
        state = store.flow_state(
            session_timezone=str(auction_cfg.get("session_timezone") or "Asia/Hebron"),
            point_value=point_size(sym, cfg),
            profile_bin_points=float(auction_cfg.get("profile_bin_points", 10) or 10),
            value_area_pct=float(auction_cfg.get("value_area_pct", 70) or 70),
        )
        health = state.get("health") or {}
        hb = health.get("heartbeat_age_seconds")
        row["recorded"] = bool(recorded)
        row["heartbeat_age_seconds"] = None if hb == math.inf else round(float(hb), 1)
        row["bid"] = float(getattr(tick, "bid", 0) or 0)
        row["ask"] = float(getattr(tick, "ask", 0) or 0)
        row["verdict"] = ("OK: tick recorded + heartbeat written -> pipeline WORKS. "
                          "If the agent diagnosis still shows inf, the running tick "
                          "manager is OLD-CODE: restart it (README R15).")
        summary[sym] = row
        print(" %-8s -> OK  bid=%s ask=%s heartbeat_age=%ss  (%s)"
              % (sym, row["bid"], row["ask"], row["heartbeat_age_seconds"], broker_sym))

    print("\nNext: python scripts\\diagnose_auction_agent.py")
    print("Expect: fresh heartbeats everywhere; ticks keep flowing only if the")
    print("RESTARTED tick manager's aux loop is alive (the probe writes ONE tick).")

    out = root / "storage" / "aux_probe_result.json"
    try:
        out.write_text(json.dumps({"generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                                                 time.gmtime()),
                                   "results": summary}, ensure_ascii=False, indent=2),
                       encoding="utf-8")
        print("JSON written: %s" % out)
    except OSError:
        pass
    mt5.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
