"""Create a non-trading comparison report for the four execution paths."""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.database import DatabaseService  # noqa: E402
from services.path_performance import PathPerformanceTracker, summarize_paths  # noqa: E402
from utils.helpers import load_config  # noqa: E402


def _combined_rows(config: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Prefer the canonical trade book and fill gaps from the local path ledger."""
    tracker_rows = PathPerformanceTracker().rows()
    by_id = {str(row.get("id")): dict(row) for row in tracker_rows if row.get("id")}
    try:
        canonical = DatabaseService(config).get_recent_trades(limit=10000)
    except Exception:
        canonical = []
    for row in canonical or []:
        tid = str(row.get("id") or "")
        if not tid:
            continue
        existing = by_id.get(tid, {})
        existing.update(row)
        by_id[tid] = existing
    return list(by_id.values())


def _text_report(summary: Dict[str, Any]) -> str:
    lines = [
        "FOUR EXECUTION PATHS — PERFORMANCE MEASUREMENT",
        "=" * 72,
        f"Generated: {summary.get('generated_at')}",
        f"Success definition: {summary.get('success_definition')}",
        f"Minimum sample: {summary.get('minimum_sample_for_comparison')} resolved trades per path",
        "",
    ]
    for row in summary.get("paths") or []:
        rate = "--" if row.get("success_rate_pct") is None else f"{row['success_rate_pct']:.1f}%"
        fill = "--" if row.get("fill_rate_pct") is None else f"{row['fill_rate_pct']:.1f}%"
        avg = "--" if row.get("average_points") is None else f"{row['average_points']:+.1f}"
        lines.extend([
            str(row.get("name")),
            f"  recorded={row.get('trades_recorded')} filled={row.get('filled_or_activated')} fill_rate={fill}",
            f"  pending={row.get('pending')} open={row.get('open')} resolved={row.get('resolved_with_pnl')}",
            f"  wins={row.get('wins')} losses={row.get('losses')} BE={row.get('breakeven')} success={rate}",
            f"  net={float(row.get('net_points') or 0):+.1f} pts avg={avg} pts profit_factor={row.get('profit_factor')}",
            f"  TP1/partial={row.get('tp1_or_partial_count')} sample_ready={row.get('sample_ready')}",
            f"  note: {row.get('sample_note')}",
            "",
        ])
    lines.extend([
        f"Current leader (descriptive only): {summary.get('current_leader') or '--'}",
        f"Unknown/legacy trades excluded from four-path ranking: {summary.get('unknown_legacy_trades')}",
        "",
        str(summary.get("warning") or ""),
    ])
    return "\n".join(lines).rstrip() + "\n"


def main() -> int:
    config = load_config()
    summary = summarize_paths(_combined_rows(config))
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    out_dir = ROOT / "diagnostics"
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / f"execution_path_performance_{stamp}.json"
    text_path = out_dir / f"execution_path_performance_{stamp}.txt"
    json_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    text = _text_report(summary)
    text_path.write_text(text, encoding="utf-8")
    print(text, end="")
    print(f"\nJSON: {json_path}")
    print(f"TEXT: {text_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
