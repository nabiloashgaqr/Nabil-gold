# -*- coding: utf-8 -*-
"""R23 (2026-08-27): storage-maintenance audit - INSPECT and FIX.

Operator report: the storage tree reached 1.5 GB. Code audit found the
maintenance plan half-executed:
  - the tick manager pruned ONLY the gold store, hourly (the five
    forex/oil aux stores were never pruned);
  - nothing ever ran VACUUM, so even pruned files never shrank;
  - logs\\*.log are appended by the task launchers with no rotation;
  - storage/agent_measurements daily files were never cleaned.

Modes:
  (default)  INSPECT - read-only: directory totals, top files, per-store
             prune status vs the configured retention, log sizes + churn,
             measurement age, decision-audit cap. Names the culprit file.
  --fix      perform the maintenance NOW: prune ALL stores (gold + aux),
             VACUUM each store at most once/day, delete measurement files
             older than 30 days, rotate any log above --log-max-mb (one
             generation; a locked log is reported, not forced).

Exit code 1 iff inspection found PRUNE-OVERDUE / oversize suspects and
--fix was not given. ASCII only.
"""
from __future__ import annotations

import argparse
import json
import os
import sqlite3
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

LOG_TRIM_BYTES = 40 * 1024 * 1024      # 40 MB per log generation
MEASUREMENT_KEEP_DAYS = 30
AUDIT_CAP_ROWS = 6000


def _human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return "{0:.1f} {1}".format(n, unit)
        n /= 1024.0
    return "{0:.1f} TB".format(n)


def _dir_stats(root, sub):
    base = root / sub
    total = 0
    files = []
    if base.is_dir():
        for f in base.rglob("*"):
            try:
                if f.is_file():
                    size = f.stat().st_size
                    total += size
                    files.append((size, f))
            except OSError:
                continue
    return total, files


def _store_report(path, cfg, now):
    second_days = int(cfg.get("second_retention_days", 7) or 7)
    minute_days = int(cfg.get("minute_retention_days", 90) or 90)
    entry = {"bytes": path.stat().st_size, "status": "OK", "rows_seconds": None,
             "rows_minutes": None, "oldest_seconds_age_days": None,
             "wal_bytes": None, "stale_seconds": None}
    wal = path.with_name(path.name + "-wal")
    if wal.exists():
        entry["wal_bytes"] = wal.stat().st_size
    try:
        con = sqlite3.connect(str(path), timeout=10.0)
        try:
            entry["rows_seconds"] = con.execute(
                "SELECT COUNT(*) FROM seconds").fetchone()[0]
            entry["rows_minutes"] = con.execute(
                "SELECT COUNT(*) FROM minutes").fetchone()[0]
            oldest = con.execute(
                "SELECT MIN(ts) FROM seconds").fetchone()[0]
            if oldest:
                age_days = (now - int(oldest)) / 86400.0
                entry["oldest_seconds_age_days"] = round(age_days, 1)
                stale = con.execute(
                    "SELECT COUNT(*) FROM seconds WHERE ts<?",
                    (int(now) - second_days * 86400,)).fetchone()[0]
                entry["stale_seconds"] = stale
                # Graduated verdict (R23.1, after the first live fix): rows
                # written exactly at the retention boundary age out between
                # the hourly prunes - a handful of stale rows minutes after
                # a prune is the healthy trickle, not an overdue chore.
                if stale == 0:
                    entry["status"] = "OK"
                elif stale < 50000:
                    entry["status"] = "EDGE (next hourly prune takes them)"
                else:
                    entry["status"] = "PRUNE-OVERDUE"
        finally:
            con.close()
    except Exception as exc:  # noqa: BLE001
        entry["status"] = "ERROR: {0}".format(exc)
    return entry


def inspect(root: Path, config: dict, log_max_mb: float = LOG_TRIM_BYTES / 1048576):
    now = time.time()
    report = {"root": str(root), "dirs": {}, "top_files": [], "stores": {},
              "logs": {}, "measurements": {}, "decision_audit": {},
              "findings": []}
    for sub in ("storage", "logs"):
        total, files = _dir_stats(root, sub)
        report["dirs"][sub] = {"bytes": total, "files": len(files)}
        files.sort(reverse=True)
        for size, f in files[:25]:
            report["top_files"].append({
                "path": str(f.relative_to(root)), "bytes": size})
    # auction stores
    from services.auction_flow_store import auction_store_paths
    cfg = (config or {}).get("auction_flow") or {}
    for path in auction_store_paths(root / "storage", config):
        report["stores"][str(path.relative_to(root))] = _store_report(path, cfg, now)
    # logs: sizes + constructor-churn estimate (each tick-manager start logs
    # one 'Aux tick collectors' line)
    logs_dir = root / "logs"
    if logs_dir.is_dir():
        for f in sorted(logs_dir.glob("*.log")):
            try:
                size = f.stat().st_size
                churn = None
                if "tick_manager" in f.name:
                    try:
                        with open(f, "r", encoding="utf-8", errors="ignore") as fh:
                            churn = sum(1 for line in fh
                                        if "Aux tick collectors" in line)
                    except OSError:
                        churn = None
                report["logs"][f.name] = {
                    "bytes": size, "oversize": size > log_max_mb * 1048576,
                    "tick_manager_starts_logged": churn}
            except OSError:
                continue
    # measurements
    meas = root / "storage" / "agent_measurements"
    if meas.is_dir():
        files = list(meas.glob("*.jsonl"))
        total = sum(f.stat().st_size for f in files if f.exists())
        oldest = min((f.stat().st_mtime for f in files if f.exists()), default=None)
        report["measurements"] = {
            "files": len(files), "bytes": total,
            "oldest_age_days": (round((now - oldest) / 86400.0, 1)
                                if oldest else None)}
    # decision audit
    audit_path = root / "storage" / "decision_audit.json"
    if audit_path.exists():
        try:
            rows = json.loads(audit_path.read_text(encoding="utf-8"))
            report["decision_audit"] = {
                "rows": len(rows) if isinstance(rows, list) else None,
                "bytes": audit_path.stat().st_size,
                "cap": AUDIT_CAP_ROWS}
        except Exception:
            report["decision_audit"] = {"rows": None, "error": "unreadable"}
    # findings
    for sub, info in report["dirs"].items():
        if info["bytes"] > 500 * 1048576:
            report["findings"].append(
                "{0}/ holds {1} - inspect top files below".format(
                    sub, _human(info["bytes"])))
    for name, entry in report["stores"].items():
        if entry["status"] == "PRUNE-OVERDUE":
            report["findings"].append(
                "{0}: {1} ({2} stale seconds rows)".format(
                    name, entry["status"], entry.get("stale_seconds")))
    for name, entry in report["logs"].items():
        if entry["oversize"]:
            report["findings"].append(
                "logs/{0} is {1} with no rotation - run --fix".format(
                    name, _human(entry["bytes"])))
    m = report["measurements"]
    if m.get("oldest_age_days") and m["oldest_age_days"] > MEASUREMENT_KEEP_DAYS:
        report["findings"].append(
            "agent_measurements: oldest file {0} days old - run --fix".format(
                m["oldest_age_days"]))
    return report


def _print_report(rep):
    print("=" * 76)
    print(" STORAGE MAINTENANCE AUDIT  (R23)")
    print("=" * 76)
    for sub, info in rep["dirs"].items():
        print(" {0}/: {1} in {2} files".format(
            sub, _human(info["bytes"]), info["files"]))
    print("\n TOP FILES:")
    for f in rep["top_files"][:15]:
        print("   {0:>10}  {1}".format(_human(f["bytes"]), f["path"]))
    print("\n AUCTION STORES (retention check):")
    for name, e in rep["stores"].items():
        wal = " (+WAL {0})".format(_human(e["wal_bytes"])) if e["wal_bytes"] else ""
        print("   {0}: {1}{2}".format(name, _human(e["bytes"]), wal))
        print("     rows seconds={0} minutes={1} | oldest={2}d | {3}".format(
            e["rows_seconds"], e["rows_minutes"],
            e["oldest_seconds_age_days"], e["status"]))
    print("\n LOGS:")
    for name, e in rep["logs"].items():
        churn = (" | tick-manager starts logged: {0}".format(
            e["tick_manager_starts_logged"])
            if e["tick_manager_starts_logged"] is not None else "")
        print("   {0}: {1}{2}{3}".format(
            name, _human(e["bytes"]),
            "  [OVERSIZE]" if e["oversize"] else "", churn))
    m = rep["measurements"]
    if m:
        print("\n MEASUREMENTS: {0} files, {1}, oldest {2} days".format(
            m.get("files"), _human(m.get("bytes") or 0), m.get("oldest_age_days")))
    d = rep["decision_audit"]
    if d:
        print(" DECISION AUDIT: {0} rows (cap {1})".format(
            d.get("rows"), d.get("cap")))
    print("\n FINDINGS:")
    if rep["findings"]:
        for f in rep["findings"]:
            print("   - {0}".format(f))
    else:
        print("   - none: maintenance state is healthy")


def _fix(root: Path, config: dict, log_max_mb: float) -> None:
    now = time.time()
    print("== FIX: legacy test-run trees + crashed atomic-write temps ==")
    freed = 0
    storage = root / "storage"
    if storage.is_dir():
        for d in sorted(storage.glob("nabil_pytest_storage_*")):
            try:
                size = sum(f.stat().st_size for f in d.rglob("*") if f.is_file())
                import shutil as _sh
                _sh.rmtree(d)
                freed += size
                print("   removed {0} ({1})".format(d.name, _human(size)))
            except OSError as exc:
                print("   could not remove {0}: {1}".format(d.name, exc))
        for f in sorted(storage.glob(".trades.json.*.tmp")):
            try:
                if now - f.stat().st_mtime > 86400:  # >1 day old = crashed write
                    size = f.stat().st_size
                    f.unlink()
                    freed += size
                    print("   removed {0} ({1})".format(f.name, _human(size)))
            except OSError as exc:
                print("   could not remove {0}: {1}".format(f.name, exc))
        backups = storage / "backups"
        if backups.is_dir():
            bsize = sum(f.stat().st_size for f in backups.rglob("*") if f.is_file())
            print("   kept storage/backups ({0}) - operator account backups".format(
                _human(bsize)))
    print("   freed: {0}".format(_human(freed)))
    print("== FIX: pruning ALL auction stores (gold + aux) ==")
    from services.auction_flow_store import prune_all_stores
    report = prune_all_stores(root / "storage", config, now=now)
    for path, e in report.items():
        if e.get("error"):
            print("   {0}: ERROR {1}".format(path, e["error"]))
        else:
            print("   {0}: {1} -> {2}  vacuum={3}  stale_left={4}".format(
                Path(path).name, _human(e["bytes_before"] or 0),
                _human(e["bytes_after"] or 0), e["vacuumed"],
                e["stale_seconds_remaining"]))
    print("== FIX: measurements older than {0}d ==".format(MEASUREMENT_KEEP_DAYS))
    meas = root / "storage" / "agent_measurements"
    removed = 0
    if meas.is_dir():
        for f in meas.glob("*.jsonl"):
            try:
                if now - f.stat().st_mtime > MEASUREMENT_KEEP_DAYS * 86400:
                    f.unlink()
                    removed += 1
            except OSError as exc:
                print("   could not remove {0}: {1}".format(f.name, exc))
    print("   removed {0} old measurement files".format(removed))
    print("== FIX: rotating logs above {0} MB ==".format(log_max_mb))
    logs_dir = root / "logs"
    if logs_dir.is_dir():
        for f in sorted(logs_dir.glob("*.log")):
            try:
                if f.stat().st_size > log_max_mb * 1048576:
                    gen1 = f.with_name(f.name + ".1")
                    if gen1.exists():
                        gen1.unlink()
                    f.rename(gen1)
                    print("   {0} -> {1}".format(f.name, gen1.name))
            except OSError as exc:
                # a running launcher holds the file: stop services first
                print("   {0}: locked ({1}) - stop services, then re-run".format(
                    f.name, exc))


def main() -> int:
    ap = argparse.ArgumentParser(
        description="R23 storage-maintenance audit (inspect / fix)")
    ap.add_argument("--fix", action="store_true",
                    help="prune all stores, vacuum, trim old measurements, "
                         "rotate oversize logs")
    ap.add_argument("--log-max-mb", type=float,
                    default=LOG_TRIM_BYTES / 1048576,
                    help="log size that triggers rotation in --fix (default 40)")
    args = ap.parse_args()
    cfg_path = ROOT / "config.json"
    config = json.loads(cfg_path.read_text(encoding="utf-8")) if cfg_path.exists() else {}
    rep = inspect(ROOT, config, args.log_max_mb)
    _print_report(rep)
    if args.fix:
        _fix(ROOT, config, args.log_max_mb)
        print("\n== re-run without --fix to verify the clean state ==")
        return 0
    unhealthy = bool(rep["findings"])
    print("\n(inspection only - re-run with --fix to execute the maintenance)")
    return 1 if unhealthy else 0


if __name__ == "__main__":
    sys.exit(main())
