# -*- coding: utf-8 -*-
"""R22 (2026-08-27): the GENERAL symbol-isolation audit tool.

Operator directive after the USD/JPY foreign-feed incident: make the
per-symbol separation structural and GENERAL - every pair's feed, agents,
plans and messages come from that pair's own source only, and cleanliness
must be CHECKABLE, not assumed. This tool walks every cross-symbol
storage channel and reports CLEAN / WARN / MIXED per channel:

  auction stores      per-symbol sqlite stamp (R21) vs expected symbol
  shared book         storage/shared_market_data.json meta symbol (R22)
  agent books         storage/agent_books/<SYMBOL>.json set
  measurements        agent_measurements rows carry a known symbol
  decision audit      decision_audit.json symbols are known instruments
  calibrations        model_calibration files match their symbol

Exit code 1 iff any channel is MIXED (a real cross-symbol contamination).
WARN means legacy/missing stamps that self-heal on the next write.
Pure core (audit_symbol_isolation) + thin CLI. ASCII only.
"""
from __future__ import annotations

import json
import sqlite3
import sys
from collections import OrderedDict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

SEVERITY_ORDER = {"CLEAN": 0, "WARN": 1, "MIXED": 2}


def _instruments(config):
    out = []
    for inst in (config or {}).get("instruments") or []:
        if isinstance(inst, dict) and inst.get("symbol"):
            out.append(str(inst["symbol"]))
    return out


def _norm(sym):
    return str(sym or "").replace("/", "").replace(".", "").upper()


def _expected_stem(symbol):
    return str(symbol).replace("/", "").lower()


def _channel_auction_stores(root, instruments):
    details, verdict = [], "CLEAN"
    base = root / "storage" / "auction_flow.sqlite3"
    for sym in instruments:
        if _norm(sym) == "XAUUSD":
            path = base
        else:
            path = base.with_name(
                "{0}_{1}{2}".format(base.stem, _expected_stem(sym), base.suffix))
        if not path.exists():
            details.append("{0}: no store yet (WARN)".format(sym))
            verdict = max(verdict, "WARN", key=lambda v: SEVERITY_ORDER[v])
            continue
        try:
            con = sqlite3.connect(str(path))
            rows = dict(con.execute("SELECT key,value FROM meta").fetchall())
            con.close()
        except Exception as exc:  # noqa: BLE001
            details.append("{0}: unreadable store ({1})".format(sym, exc))
            verdict = "MIXED"
            continue
        stamp = str(rows.get("symbol") or "")
        if not stamp:
            details.append("{0}: legacy un-stamped store - stamps on next "
                           "heartbeat after R21 deploy".format(sym))
            verdict = max(verdict, "WARN", key=lambda v: SEVERITY_ORDER[v])
        elif _norm(stamp) != _norm(sym):
            details.append("{0}: store stamped for {1} - MIXED".format(sym, stamp))
            verdict = "MIXED"
        else:
            details.append("{0}: stamp OK".format(sym))
    return verdict, details


def _channel_shared_book(root, instruments):
    path = root / "storage" / "shared_market_data.json"
    if not path.exists():
        return "WARN", ["no shared book on disk yet"]
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return "MIXED", ["unreadable book: {0}".format(exc)]
    meta = data.get("shared_market_data") or {}
    symbol = str(data.get("symbol") or meta.get("symbol") or "")
    if not symbol:
        return "WARN", ["book has no plain-text symbol (pre-R22 file) - "
                        "re-stamps on the next analysis cycle"]
    if symbol not in instruments:
        return "MIXED", ["book symbol {0} is not a configured instrument".format(symbol)]
    age = ""
    gen = str(meta.get("generated_at") or "")
    if gen:
        try:
            from datetime import datetime, timezone
            age = " ({0:.0f}s old)".format(
                (datetime.now(timezone.utc) - datetime.fromisoformat(gen)).total_seconds())
        except Exception:  # noqa: BLE001
            pass
    return "CLEAN", ["book belongs to {0}{1}".format(symbol, age)]


def _channel_agent_books(root, instruments):
    folder = root / "storage" / "agent_books"
    if not folder.exists():
        return "CLEAN", ["no agent_books dir yet"]
    known = {_norm(s) for s in instruments}
    details, verdict = [], "CLEAN"
    for f in sorted(folder.glob("*.json")):
        stem = _norm(f.stem)
        if stem in known:
            details.append("{0}: OK".format(f.name))
        else:
            details.append("{0}: unknown symbol file".format(f.name))
            verdict = max(verdict, "WARN", key=lambda v: SEVERITY_ORDER[v])
    return verdict, details


def _channel_measurements(root, instruments):
    folder = root / "storage" / "agent_measurements"
    if not folder.exists():
        return "CLEAN", ["no measurements dir yet"]
    files = sorted(folder.glob("*.jsonl"))
    if not files:
        return "CLEAN", ["no measurement files yet"]
    latest = files[-1]
    known = {_norm(s) for s in instruments}
    missing = unknown = rows = 0
    try:
        lines = latest.read_text(encoding="utf-8").strip().splitlines()[-200:]
    except Exception as exc:  # noqa: BLE001
        return "MIXED", ["unreadable {0}: {1}".format(latest.name, exc)]
    for line in lines:
        try:
            row = json.loads(line)
        except Exception:
            continue
        rows += 1
        sym = _norm(row.get("symbol"))
        if not sym:
            missing += 1
        elif sym not in known:
            unknown += 1
    if missing or unknown:
        return "MIXED", ["{0}: {1} rows without symbol, {2} unknown-symbol rows "
                         "of {3}".format(latest.name, missing, unknown, rows)]
    return "CLEAN", ["{0}: all {1} sampled rows symbol-stamped".format(latest.name, rows)]


def _channel_decision_audit(root, instruments):
    path = root / "storage" / "decision_audit.json"
    if not path.exists():
        return "CLEAN", ["no decision audit file yet"]
    try:
        rows = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return "MIXED", ["unreadable audit: {0}".format(exc)]
    if not isinstance(rows, list):
        return "MIXED", ["decision audit is not a list"]
    known = {_norm(s) for s in instruments}
    unknown = sorted({_norm((r or {}).get("symbol")) for r in rows} - known - {""})
    if unknown:
        return "MIXED", ["audit carries unknown symbols: {0}".format(", ".join(unknown))]
    return "CLEAN", ["all audit symbols are configured instruments"]


def _channel_calibrations(root, instruments):
    folder = root / "storage" / "model_calibration"
    if not folder.exists():
        return "CLEAN", ["no calibration dir yet"]
    details, verdict = [], "CLEAN"
    for sym in instruments:
        if _norm(sym) == "XAUUSD":
            path = folder / "auction_flow_v1.json"
        else:
            path = folder / "auction_flow_v1_{0}.json".format(_expected_stem(sym))
        if not path.exists():
            continue  # a symbol without calibration yet is fine
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            details.append("{0}: unreadable ({1})".format(path.name, exc))
            verdict = "MIXED"
            continue
        cal_sym = str(raw.get("symbol") or "")
        # Mirror the agent's shipped validator EXACTLY (second live-run
        # lesson): it strips the broker suffix AND compares with
        # bidirectional containment - the broker's WTI symbol is "WTI.s"
        # (short form) while the config symbol is "WTI/USD" ("WTI" is
        # contained in "WTIUSD"). Exact equality printed a second false
        # MIXED for the oil file; containment is the shipped semantics.
        cal_norm = (cal_sym.upper().replace("/", "")
                    .replace(".S", "").rstrip("."))
        mine = _norm(sym)
        if cal_norm and mine not in cal_norm and cal_norm not in mine:
            details.append("{0}: trained on {1} - MIXED".format(path.name, cal_sym))
            verdict = "MIXED"
        else:
            details.append("{0}: symbol OK ({1})".format(path.name, cal_sym or "unstamped"))
    if not details:
        return "CLEAN", ["no calibration files to check"]
    return verdict, details


def audit_symbol_isolation(root=None, config=None):
    """Pure core: returns an ordered report dict. Never raises."""
    root = Path(root) if root else ROOT
    if config is None:
        cfg_path = root / "config.json"
        config = json.loads(cfg_path.read_text(encoding="utf-8")) if cfg_path.exists() else {}
    instruments = _instruments(config) or ["XAU/USD"]
    channels = OrderedDict()
    channels["auction stores"] = _channel_auction_stores(root, instruments)
    channels["shared book"] = _channel_shared_book(root, instruments)
    channels["agent books"] = _channel_agent_books(root, instruments)
    channels["measurements"] = _channel_measurements(root, instruments)
    channels["decision audit"] = _channel_decision_audit(root, instruments)
    channels["calibrations"] = _channel_calibrations(root, instruments)
    overall = max((v for v, _ in channels.values()),
                  key=lambda v: SEVERITY_ORDER[v])
    return {"instruments": instruments, "channels": channels, "overall": overall}


def main() -> int:
    report = audit_symbol_isolation()
    print("=" * 76)
    print(" SYMBOL-ISOLATION AUDIT  (every cross-symbol channel, R22)")
    print("=" * 76)
    print(" instruments: {0}".format(", ".join(report["instruments"])))
    for name, (verdict, details) in report["channels"].items():
        print("\n[{0}] {1}".format(verdict, name))
        for line in details:
            print("   - {0}".format(line))
    print("\n" + "=" * 76)
    print(" OVERALL: {0}".format(report["overall"]))
    print(" CLEAN = separated | WARN = legacy stamps self-heal on next write")
    print(" MIXED = cross-symbol contamination found - fix before trading")
    print("=" * 76)
    return 1 if report["overall"] == "MIXED" else 0


if __name__ == "__main__":
    sys.exit(main())
