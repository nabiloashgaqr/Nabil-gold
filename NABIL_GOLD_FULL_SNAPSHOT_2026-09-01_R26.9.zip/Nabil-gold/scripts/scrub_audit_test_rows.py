# -*- coding: utf-8 -*-
"""R25.6/R25.8: scrub contamination out of the production decision_audit.

Two scrub laws:

1. (R25.6) Default run: remove pytest contamination rows - rows whose
   reason contains "unit-test" (case-insensitive).

2. (R25.8, NEW) ``--drop-stage STAGE --before ISO``: remove every row whose
   ``stage`` equals STAGE (case-insensitive) and whose ``created_at`` is
   strictly before ISO (UTC ISO-8601, e.g. 2026-08-28T23:59:00+00:00).
   Rows of the same stage at/after ISO are kept, and every other stage is
   untouched. This retires a retired pipeline's audit history without
   touching live stages.

Both modes: timestamped backup is written first, summary printed,
idempotent, and the tool never writes anything when it cannot parse the
audit (a court record is never destroyed on a read failure).

Usage (from the project root):
    python scripts\\scrub_audit_test_rows.py
    python scripts\\scrub_audit_test_rows.py --drop-stage "r25 scalp" --before "2026-08-28T23:59:00+00:00"
    python scripts\\scrub_audit_test_rows.py --audit storage\\decision_audit.json --drop-stage ... (optional path override)
"""
import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "storage" / "decision_audit.json"


def _parse_iso(value: str):
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:  # noqa: BLE001
        return None


def main(argv=None) -> int:
    # argv=None -> parse sys.argv (operator CLI); in-process callers may
    # pass an explicit list so a leaked session argv can never bite (R25.9).

    ap = argparse.ArgumentParser(description="Scrub decision_audit rows (test rows by default; --drop-stage for stage retirement).")
    ap.add_argument("--drop-stage", default=None, help="stage name to drop (case-insensitive), e.g. \"r25 scalp\"")
    ap.add_argument("--before", default=None, help="drop only rows created strictly before this UTC ISO time")
    ap.add_argument("--audit", default=None, help="optional audit path override (default storage/decision_audit.json)")
    args = ap.parse_args(argv)

    audit = Path(args.audit) if args.audit else AUDIT
    if not audit.exists():
        print("nothing to scrub: %s not found" % audit)
        return 0
    try:
        rows = json.loads(audit.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001 - never destroy a court record
        print("FAIL: could not parse %s (%s) - nothing written" % (audit, exc))
        return 1
    if not isinstance(rows, list):
        print("FAIL: unexpected audit layout - nothing written")
        return 1

    if args.drop_stage is not None:
        if not args.before:
            print("FAIL: --drop-stage requires --before (safety: never drop a stage without a time fence)")
            return 1
        before_dt = _parse_iso(args.before)
        if before_dt is None:
            print("FAIL: --before is not a valid ISO timestamp: %r" % args.before)
            return 1
        stage_l = str(args.drop_stage).strip().lower()
        keep, removed = [], []
        for row in rows:
            row = row or {}
            row_stage = str(row.get("stage") or "").strip().lower()
            row_dt = _parse_iso(row.get("created_at") or "")
            drop = (row_stage == stage_l and row_dt is not None and row_dt < before_dt)
            (removed if drop else keep).append(row)
        if not removed:
            print("clean already: %d rows scanned, 0 rows of stage %r before %s"
                  % (len(rows), args.drop_stage, args.before))
            return 0
    else:
        keep, removed = [], []
        for row in rows:
            reason = str((row or {}).get("reason") or "").lower()
            (removed if "unit-test" in reason else keep).append(row)
        if not removed:
            print("clean already: %d rows scanned, 0 test rows found" % len(rows))
            return 0

    stamp = time.strftime("%Y%m%d_%H%M%S")
    backup = audit.with_name(audit.name + ".bak_scrub_" + stamp)
    backup.write_text(audit.read_text(encoding="utf-8"), encoding="utf-8")
    audit.write_text(json.dumps(keep, ensure_ascii=True), encoding="utf-8")
    print("scrubbed %d row(s) out of %d (kept %d); backup: %s"
          % (len(removed), len(rows), len(keep), backup.name))
    return 0


if __name__ == "__main__":
    sys.exit(main())
