# -*- coding: utf-8 -*-
"""R25.6 (B1): WHY does each symbol's agent book fail to qualify?

Per enabled symbol, reads the freshest persisted book
(storage/agent_books/<SYMBOL>.json, written every analysis cycle) and
reports - from data, never guesses:
  * book age (minutes) and whether it is stale (>10 min reads as NO book);
  * every agent's direction/confidence;
  * qualified voices at the shared 65 bar (per side), family split;
  * the shared admission verdict for BUY and for SELL with the supporters
    and opponents - i.e. which path legs would light up and what is missing
    (macro confirmation? a third supporter? the auction confirmation?).

Usage (from the project root):
    python scripts\\diagnose_symbol_books.py
    python scripts\\diagnose_symbol_books.py --out books_report.txt
Writes the report file (default: diagnose_symbol_books.txt). Exit code 0.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services.agent_book_store import book_path  # noqa: E402
from services.thesis_consensus import evaluate_directional_admission  # noqa: E402
from utils.instruments import enabled_instruments  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description="per-symbol agent-book diagnosis")
    ap.add_argument("--root", default=".",
                    help="project root containing config.json and storage/ (default: cwd)")
    ap.add_argument("--out", default="diagnose_symbol_books.txt")
    args = ap.parse_args()
    root = Path(args.root)
    cfg = json.loads((root / "config.json").read_text(encoding="utf-8"))
    min_conf = float(((cfg.get("signal_requirements") or {}).get("agent_min_confidence")) or 65.0)

    symbols = []
    base = str(cfg.get("symbol") or "XAU/USD")
    symbols.append(base)
    try:
        for inst in enabled_instruments(cfg):
            sym = str(inst.get("symbol") or "")
            if sym and sym.upper() != base.upper() and sym.upper() not in [s.upper() for s in symbols]:
                symbols.append(sym)
    except Exception:  # noqa: BLE001 - broken registry still reports the base
        pass

    lines: list[str] = []
    add = lines.append
    add("=" * 78)
    add(" SYMBOL AGENT-BOOK DIAGNOSIS  (%s)   qualification bar = %.0f"
        % (time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime()), min_conf))
    add("=" * 78)
    for sym in symbols:
        path = book_path(sym, root=root)
        add("")
        add("[%s]" % sym)
        if not path.exists():
            add("  NO BOOK FILE - the symbol is not being cycled by analysis")
            add("  (check the schedule/watchlist; nothing downstream can judge it)")
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            add("  CORRUPT BOOK (%s)" % exc)
            continue
        written = float(payload.get("written_at") or 0.0)
        age_min = (time.time() - written) / 60.0
        add("  book age: %.1f min %s" % (age_min, "(STALE: gate reads NO book, activation/admission fail-open)" if age_min > 10 else "(fresh)"))
        agents = payload.get("agents") or {}
        book_for_admission = {}
        for name, row in sorted(agents.items()):
            if name == "_site":
                continue
            direction = str((row or {}).get("direction") or "WAIT").upper()
            conf = float((row or {}).get("confidence") or 0.0)
            mark = " *QUALIFIED*" if conf >= min_conf else ""
            add("    %-16s %-9s %5.1f%s" % (name, direction, conf, mark))
            book_for_admission[name] = {"direction": direction, "confidence": conf}
        site = payload.get("site") or {}
        if site.get("range_high") and site.get("range_low"):
            add("    known range in book: %.2f - %.2f" % (float(site["range_low"]), float(site["range_high"])))
        if age_min > 10:
            add("  VERDICT: stale book - every gate fails OPEN; fix the cycling, not the gates")
            continue
        for side in ("SELL", "BUY"):
            res = evaluate_directional_admission(side, book_for_admission, cfg, symbol=sym)
            supporters = ", ".join(res.get("supporters") or []) or "-"
            opponents = ", ".join(res.get("opponents") or []) or "-"
            verdict = "ADMITTED via %s" % res.get("path") if res.get("allow") else "refused"
            add("  %s: %s | net %.1f%% | support: %s | oppose: %s"
                % (side, verdict, float(res.get("confidence") or 0.0), supporters, opponents))
    add("")
    add("(the book is written every analysis cycle; a stale/missing book is a")
    add(" cycling problem, a WAIT-heavy book is an agent-qualification problem).")
    out = root / args.out
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("wrote %s (%d lines)" % (out, len(lines)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
