"""FIX LIVE WTI TRADE (2026-08-20, build 19 companion).

The first live oil trade (BUY @86.82, SL 84.12, TP 90.00) shipped with the
GOLD stop band: 86.82 - 84.12 = $2.70 = 270 pts = the gold floor (200+70),
because the tick manager normalized every trade with the base (gold) laws.
Build 19 fixed the code; this script repairs the LIVE row + the broker order.

Default: DRY-RUN - prints exactly what would change, writes nothing.
With --apply: writes the corrected stop/targets to storage/trades.json and
asks the broker (via Mt5DemoExecutor) to move SL/TP to the same values.

Corrected values follow the OIL design (build 18 caps + instrument profile):
  - stop: the planned stop if it sits in the legal [81, 120] pt band,
          else the 120-pt cap ($1.20).
  - targets: targets_law with the corrected stop (TP1 = 0.8R rung or the
             nearest pool within 60 pts; TP2 = 2x TP1 or the farthest pool
             within 60 pts, capped at 350 pts).

Usage:
  python scripts\\fix_live_wti_trade.py            # dry-run
  python scripts\\fix_live_wti_trade.py --apply    # write + broker
  python scripts\\fix_live_wti_trade.py --root C:\\Nabil-gold --apply
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, Optional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

from utils.helpers import load_config, mutate_trades  # noqa: E402
from utils.instruments import config_for_instrument, normalize_symbol  # noqa: E402
from utils.trading_rules import stop_rule, targets_law  # noqa: E402
from scripts.run_tick_manager import corrected_execution_stop  # noqa: E402

LIVE_STATUSES = {"OPEN", "PARTIAL", "TP1_HIT"}


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _snapshot_signal(row: Dict[str, Any]) -> Dict[str, Any]:
    snap = row.get("signal_snapshot") or {}
    if isinstance(snap, str):
        try:
            snap = json.loads(snap)
        except Exception:  # noqa: BLE001
            snap = {}
    if not isinstance(snap, dict):
        return {}
    signal = snap.get("signal") or {}
    return signal if isinstance(signal, dict) else {}


def _snapshot_levels(row: Dict[str, Any]) -> list:
    """Best-effort liquidity levels from the stored snapshot."""
    levels: list = []
    snap = row.get("signal_snapshot") or {}
    if isinstance(snap, str):
        try:
            snap = json.loads(snap)
        except Exception:  # noqa: BLE001
            snap = {}
    if not isinstance(snap, dict):
        snap = {}
    signal = snap.get("signal") or {}
    if isinstance(signal, dict):
        for key in ("targets", "liquidity_levels", "objectives"):
            raw = signal.get(key)
            if isinstance(raw, list):
                levels.extend(raw)
    plan = snap.get("session_plan") or {}
    if isinstance(plan, dict):
        for key in ("target_liquidity", "primary_poi"):
            raw = plan.get(key)
            if isinstance(raw, dict):
                for k in ("target_price", "target", "price"):
                    if raw.get(k):
                        levels.append(raw[k])
            elif isinstance(raw, (int, float)) and raw:
                levels.append(raw)
    out = []
    for lv in levels:
        try:
            v = float(lv)
            if v > 0:
                out.append(v)
        except (TypeError, ValueError):
            continue
    return out


def plan_repair(row: Dict[str, Any], wti_cfg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    side = str(row.get("type") or row.get("side") or "").upper()
    if side not in {"BUY", "SELL"}:
        print(f"  skip {row.get('id')}: unknown side {side!r}")
        return None
    entry = _f(row.get("entry_price"))
    current_stop = _f(row.get("stop_loss"))
    tp1_old = _f(row.get("tp1"))
    tp2_old = _f(row.get("tp2"))
    if entry <= 0 or current_stop <= 0:
        print(f"  skip {row.get('id')}: missing entry/stop")
        return None
    signal = _snapshot_signal(row)
    entry_info = signal.get("entry") or {}
    planned_entry = _f(entry_info.get("price") if isinstance(entry_info, dict) else None, entry)
    planned_stop = _f(signal.get("stop_loss"), current_stop)
    rule = stop_rule(wti_cfg)
    pv = 0.01
    corrected, required_pts, actual_pts = corrected_execution_stop(
        side, entry, current_stop, planned_entry, planned_stop,
        min_liquidity_points=_f(rule["min_liquidity_points"]),
        safety_buffer_points=_f(rule["safety_buffer_points"]),
        cap_points=_f(rule["max_stop_points"]),
        point_value=pv,
    )
    if corrected is None:
        # Stop already legal (the build-19 tick manager may have moved it to
        # the 120-pt cap on its own) - keep it, but the targets may still
        # carry the old far geometry and must be recomputed below.
        new_stop = current_stop
        final_pts = actual_pts
        basis = f"stop already legal ({actual_pts:.0f} pts) - kept"
    else:
        # If the ORIGINAL planned stop was legal in the oil band, restore it
        # instead of the cap: the over-widening was our bug, not the map's.
        planned_pts = abs(planned_entry - planned_stop) / pv if planned_entry > 0 and planned_stop > 0 else 0.0
        floor_pts = _f(rule["min_liquidity_points"]) + _f(rule["safety_buffer_points"])
        cap_pts = _f(rule["max_stop_points"])
        if floor_pts <= planned_pts <= cap_pts:
            new_stop = (planned_entry - planned_pts * pv) if side == "BUY" else (planned_entry + planned_pts * pv)
            final_pts = planned_pts
            basis = f"restored planned stop ({planned_pts:.0f} pts)"
        else:
            new_stop = corrected
            final_pts = required_pts
            basis = f"oil cap ({final_pts:.0f} pts = ${final_pts * pv:.2f})"
    risk = abs(entry - new_stop)
    if risk <= 0:
        return None
    levels = _snapshot_levels(row)
    new_tp1, new_tp2, used_pool = targets_law(
        direction=side, entry=entry, risk_price=risk,
        levels=levels, cfg=wti_cfg, symbol="WTI/USD",
    )
    # Nothing to change (stop legal AND targets already at the oil geometry)?
    if (abs(new_stop - current_stop) < 0.01
            and abs(new_tp1 - tp1_old) < 0.01
            and abs(new_tp2 - tp2_old) < 0.01):
        print(f"  {row.get('id')}: stop and targets already conform - nothing to fix")
        return None
    return {
        "id": row.get("id"),
        "side": side,
        "entry": entry,
        "stop_old": current_stop,
        "stop_new": round(new_stop, 2),
        "stop_pts": round(final_pts, 1),
        "stop_basis": basis,
        "tp1_old": tp1_old,
        "tp1_new": round(new_tp1, 2),
        "tp2_old": tp2_old,
        "tp2_new": round(new_tp2, 2),
        "tp_basis": "liquidity pools" if used_pool else "0.8R rung / 2x TP1",
        "rr_old": round(abs(tp2_old - entry) / abs(entry - current_stop), 2) if tp2_old else 0.0,
        "rr_new": round(abs(new_tp2 - entry) / risk, 2),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(ROOT))
    parser.add_argument("--apply", action="store_true",
                        help="write trades.json + move the broker SL/TP (default: dry-run)")
    args = parser.parse_args()
    root = Path(args.root)
    mode = "APPLY" if args.apply else "DRY-RUN"
    print(f"FIX LIVE WTI TRADE  [{mode}]  root={root}")
    cfg = load_config()
    wti_cfg = config_for_instrument(cfg, {"symbol": "WTI/USD"})
    trades_path = root / "storage" / "trades.json"
    if not trades_path.exists():
        print("trades.json not found")
        return 1
    trades = json.loads(trades_path.read_text(encoding="utf-8") or "[]")
    wti_live = [t for t in trades
                if isinstance(t, dict)
                and normalize_symbol(str(t.get("symbol") or "")) == "WTI/USD"
                and str(t.get("status") or "").upper() in LIVE_STATUSES]
    if not wti_live:
        print("no LIVE WTI rows found in trades.json")
        return 0
    print(f"live WTI rows: {len(wti_live)}\n")
    plans = []
    for row in wti_live:
        plan = plan_repair(row, wti_cfg)
        if not plan:
            continue
        plans.append((row, plan))
        print(f"  trade  : {plan['id']}")
        print(f"  side   : {plan['side']}  entry {plan['entry']:.2f}")
        print(f"  STOP   : {plan['stop_old']:.2f} -> {plan['stop_new']:.2f}  "
              f"({plan['stop_pts']:.0f} pts, {plan['stop_basis']})")
        print(f"  TP1    : {plan['tp1_old']:.2f} -> {plan['tp1_new']:.2f}")
        print(f"  TP2    : {plan['tp2_old']:.2f} -> {plan['tp2_new']:.2f}  ({plan['tp_basis']})")
        print(f"  RR     : {plan['rr_old']:.2f} -> {plan['rr_new']:.2f}")
        print("")
    if not plans:
        print("nothing to repair")
        return 0
    if not args.apply:
        print("DRY-RUN: nothing written. Re-run with --apply to execute.")
        return 0
    for row, plan in plans:
        tid = str(row.get("id") or "")
        updates = {
            "stop_loss": plan["stop_new"],
            "initial_stop_loss": plan["stop_new"],
            "execution_stop_normalized": True,
            "execution_stop_points": plan["stop_pts"],
            "tp1": plan["tp1_new"],
            "tp2": plan["tp2_new"],
            "rr_ratio": plan["rr_new"],
        }
        def _mut(local: list) -> None:
            for t in local:
                if str(t.get("id")) == tid:
                    t.update(updates)
                    return
        mutate_trades(_mut, trades_path)
        print(f"book updated: {tid}")
        # Broker: apply the same stop + TP2 via the demo executor. Best
        # effort - a failure here still leaves the book fixed, and the tick
        # manager's drift guard retries the broker side every pass.
        try:
            from services.mt5_executor import Mt5DemoExecutor
            executor = Mt5DemoExecutor(wti_cfg)
            if executor.apply_stop(tid, plan["stop_new"], plan["tp2_new"], "WTI/USD"):
                print(f"broker updated: SL {plan['stop_new']:.2f} / TP2 {plan['tp2_new']:.2f}")
            else:
                print(f"broker update FAILED: {executor.last_error} "
                      f"(tick manager will retry from the book)")
        except Exception as exc:  # noqa: BLE001
            print(f"broker update skipped: {exc} "
                  f"(tick manager will retry from the book)")
    print("DONE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
