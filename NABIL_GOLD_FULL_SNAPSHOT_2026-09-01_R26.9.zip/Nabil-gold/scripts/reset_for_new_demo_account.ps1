# =============================================================================
# Reset Storage and Dashboard for New MT5 Demo Account (ASCII only)
# =============================================================================

[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host " RESETTING STORAGE AND DASHBOARD FOR NEW MT5 DEMO ACCOUNT" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# 0. Sanity: must run in repo root
if (-not (Test-Path "config.json")) {
    Write-Host "ERROR: run this script inside the repo root (C:\Nabil-gold)." -ForegroundColor Red
    Exit 1
}

# 1. Run Python reset script
python scripts\reset_for_new_demo_account.py

Write-Host ""
Write-Host "[+] NEXT STEPS TO CONNECT NEW DEMO ACCOUNT:" -ForegroundColor Green
Write-Host "    1. In MetaTrader 5: File -> Login to Trade Account (Enter new Demo credentials)."
Write-Host "    2. Restart 'SmartSignal - Start Loop' on Desktop if running."
Write-Host "    3. The Dashboard will now record only new trades from this new account."
Write-Host "==================================================================" -ForegroundColor Cyan
