# -*- coding: utf-8 -*-
"""weekly_path_report.py — تقرير أداء أسبوعي لكل مسار (قياس فقط).

يقرأ ليدجر الصفقات (storage/trades.json ثم path_performance/trades.json)،
يحصر آخر N يومًا (افتراضي 7)، ويطبع/يحفظ جدولًا لكل مسار: عدد، ربح/خسارة/
تعادل، صافي PnL بالدولار، متوسط الربح مقابل متوسط الخسارة، عامل الربح PF،
نسبة النجاح. لا يغيّر أي وزن أو عتبة أو قاعدة تنفيذ (قياس بحت).

التشغيل من جذر المشروع:
    python scripts/weekly_path_report.py              # آخر 7 أيام
    python scripts/weekly_path_report.py --days 30    # آخر 30 يومًا
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services.path_performance import resolve_execution_path, UNKNOWN_PATH  # noqa: E402

OPEN_STATUSES = {"OPEN", "PARTIAL", "TP1_HIT", "PENDING"}
UNFILLED = {"CANCELLED", "EXPIRED", "REJECTED"}


def _f(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _pnl(row):
    for k in ("final_pnl", "realized_usd", "current_pnl"):
        v = row.get(k)
        if v is not None:
            try:
                return float(v)
            except (TypeError, ValueError):
                pass
    return None


def _close_date(row):
    for k in ("closed_at", "close_time"):
        v = str(row.get(k) or "")
        if v:
            try:
                return datetime.fromisoformat(v.replace("Z", "+00:00"))
            except ValueError:
                pass
    for k in ("entry_time",):
        v = str(row.get(k) or "")
        if v:
            try:
                return datetime.fromisoformat(v.replace("Z", "+00:00"))
            except ValueError:
                pass
    return None


def load_trades():
    for p in (ROOT / "storage" / "trades.json",
              ROOT / "storage" / "path_performance" / "trades.json"):
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
            if isinstance(data, dict):
                for key in ("trades", "rows", "data"):
                    if isinstance(data.get(key), list):
                        return data[key]
    return []


def build_report(days=7):
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    rows = []
    for t in load_trades():
        if not isinstance(t, dict):
            continue
        d = _close_date(t)
        if d is not None:
            if d.tzinfo is None:
                d = d.replace(tzinfo=timezone.utc)
            if d < cutoff:
                continue
        path = resolve_execution_path(t)
        pid = str(path.get("id") or UNKNOWN_PATH)
        pnl = _pnl(t)
        status = str(t.get("status") or "").upper()
        rows.append((pid, status, pnl, t))

    paths = {}
    for pid, status, pnl, t in rows:
        b = paths.setdefault(pid, {"n": 0, "w": 0, "l": 0, "be": 0, "open": 0,
                                   "unfilled": 0, "pnl": [], "gross_win": 0.0,
                                   "gross_loss": 0.0})
        b["n"] += 1
        if status in OPEN_STATUSES:
            b["open"] += 1
            continue
        if status in UNFILLED and not t.get("mt5_ticket"):
            b["unfilled"] += 1
            continue
        if pnl is None:
            continue
        b["pnl"].append(pnl)
        if pnl > 0:
            b["w"] += 1
            b["gross_win"] += pnl
        elif pnl < 0:
            b["l"] += 1
            b["gross_loss"] += abs(pnl)
        else:
            b["be"] += 1

    table = []
    for pid, b in sorted(paths.items()):
        resolved = b["w"] + b["l"] + b["be"]
        wins = [p for p in b["pnl"] if p > 0]
        losses = [p for p in b["pnl"] if p < 0]
        pf = (b["gross_win"] / b["gross_loss"]) if b["gross_loss"] > 0 else (
            None if b["gross_win"] == 0 else float("inf"))
        table.append({
            "path": pid,
            "recorded": b["n"], "open": b["open"], "unfilled": b["unfilled"],
            "wins": b["w"], "losses": b["l"], "breakeven": b["be"],
            "net_pnl": round(sum(b["pnl"]), 2),
            "avg_win": round(sum(wins) / len(wins), 2) if wins else None,
            "avg_loss": round(sum(losses) / len(losses), 2) if losses else None,
            "profit_factor": (round(pf, 2) if pf is not None and pf != float("inf")
                              else ("INF" if pf == float("inf") else None)),
            "win_rate_pct": round(100.0 * b["w"] / resolved, 1) if resolved else None,
        })
    return {"generated_at": datetime.now(timezone.utc).isoformat(),
            "window_days": days, "paths": table}


def print_report(rep):
    print("=" * 96)
    print(f"تقرير أداء المسارات — آخر {rep['window_days']} يوم — {rep['generated_at'][:16]}")
    print("(قياس فقط: لا يغيّر أي وزن/عتبة/قاعدة تنفيذ)")
    print("=" * 96)
    hdr = (f"{'المسار':38s} {'عدد':>4} {'ربح':>4} {'خسارة':>5} {'تعادل':>5} "
           f"{'صافي$':>9} {'متوسط ربح':>10} {'متوسط خسارة':>11} {'PF':>6} {'نجاح%':>6}")
    print(hdr)
    print("-" * 96)
    tot_win = tot_loss = 0.0
    for r in rep["paths"]:
        pf = r["profit_factor"]
        pf_s = f"{pf:.2f}" if isinstance(pf, (int, float)) else str(pf or "-")
        aw = f"{r['avg_win']:.1f}" if r["avg_win"] is not None else "-"
        al = f"{r['avg_loss']:.1f}" if r["avg_loss"] is not None else "-"
        wr = f"{r['win_rate_pct']:.0f}" if r["win_rate_pct"] is not None else "-"
        print(f"{r['path']:38s} {r['recorded']:>4} {r['wins']:>4} {r['losses']:>5} "
              f"{r['breakeven']:>5} {r['net_pnl']:>9.1f} {aw:>10} {al:>11} {pf_s:>6} {wr:>6}")
        if r["avg_win"]:
            tot_win += r["avg_win"]
        if r["avg_loss"]:
            tot_loss += abs(r["avg_loss"])
    print("-" * 96)
    print("ملاحظة: العينة الصغيرة (<20 صفقة مغلقة لكل مسار) لا تكفي لضبط القواعد.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--save", action="store_true", help="save JSON under diagnostics/")
    args = ap.parse_args()
    rep = build_report(args.days)
    print_report(rep)
    if args.save:
        outdir = ROOT / "diagnostics"
        outdir.mkdir(exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        p = outdir / f"weekly_paths_{stamp}.json"
        p.write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\nحُفظ: {p}")


if __name__ == "__main__":
    main()
