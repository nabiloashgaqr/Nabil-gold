# -*- coding: utf-8 -*-
"""GEMINI STATE PROBE (R25.11 addendum - observability for the model law).

The model law keeps the persisted state on a short leash: on LOAD, every
out-of-chain entry (resolved latch, exhausted, unavailable) is purged from
memory, and on WRITE only configured-chain names are persisted. But the
state file itself is otherwise only rewritten by a review-call
failure/fallback path - with a healthy primary model nothing ever
persists, so leftovers from an older era can sit in the file for days,
which looks alarming in `type storage\\llm\\gemini_quota_state.json`
even though the running service already purges them.

This probe makes the law VISIBLE, in one command, in three steps:

  [1/3] constructs GeminiReviewService exactly as production does and
        prints the loaded vs adopted latch verdict (an out-of-chain latch
        must print DISCARDED);
  [2/3] live-pings the effective primary model once (1 request,
        maxOutputTokens=8) and prints the HTTP verdict;
  [3/3] writes the quota state ONCE (retiring any out-of-chain leftovers)
        and prints the resulting file content.

Usage (from the project root):
    python scripts\\gemini_state_probe.py
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Any, Dict

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv()
except Exception:  # noqa: BLE001
    pass

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

import requests  # noqa: E402

from services.llm_review import GeminiReviewService  # noqa: E402

API_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"


def _load_config() -> Dict[str, Any]:
    return json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def main() -> int:
    cfg = _load_config()
    # construct exactly as production does - the load-time law runs here.
    svc = GeminiReviewService(cfg)
    adopted = GeminiReviewService._resolved_model
    state_path = svc._quota_state_path()
    raw = {}
    try:
        if state_path.exists():
            raw = json.loads(state_path.read_text(encoding="utf-8") or "{}")
    except Exception:  # noqa: BLE001
        raw = {}
    file_latch = str((raw or {}).get("resolved_model") or "")

    print("=" * 68)
    print("[1/3] SERVICE CONSTRUCTION (the load-time model law)")
    print("=" * 68)
    print("  state file          : %s" % state_path)
    print("  file resolved_model : %r" % file_latch)
    print("  effective model     : %s" % svc.model)
    print("  in-memory latch     : %r" % adopted)
    if file_latch and adopted != file_latch:
        print("  verdict             : %r DISCARDED - outside the configured chain" % file_latch)
    elif file_latch:
        print("  verdict             : %r ADOPTED (still a configured candidate)" % file_latch)
    else:
        print("  verdict             : no persisted latch to carry over")
    print("  configured chain    : %s" % (" -> ".join(svc._candidate_models())))

    # [2/3] one live ping through the real key + effective primary model.
    print("=" * 68)
    print("[2/3] LIVE PING (1 request, maxOutputTokens=8)")
    print("=" * 68)
    ok = False
    if not svc.api_key:
        print("  GEMINI_API_KEY not found in .env - ping skipped")
    else:
        try:
            resp = requests.post(
                API_URL.format(model=svc.model),
                params={"key": svc.api_key},
                json={"contents": [{"parts": [{"text": "ping"}]}],
                      "generationConfig": {"maxOutputTokens": 8}},
                timeout=30,
            )
            if resp.status_code == 200:
                ok = True
                print("  %s -> OK (the key can use this model now)" % svc.model)
            else:
                print("  %s -> HTTP %s: %s" % (svc.model, resp.status_code, (resp.text or "")[:90]))
        except Exception as exc:  # noqa: BLE001
            print("  %s -> NETWORK failure: %s" % (svc.model, exc))

    # [3/3] retire the stale latch: mirror the in-memory state once.
    print("=" * 68)
    print("[3/3] STATE FILE REWRITTEN ONCE")
    print("=" * 68)
    svc._persist_state()
    try:
        after = json.loads(state_path.read_text(encoding="utf-8") or "{}")
        print("  resolved_model : %r" % str(after.get("resolved_model") or ""))
        print("  updated_at     : %s (%s)"
              % (after.get("updated_at"),
                 time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(int(after.get("updated_at") or 0)))))
        print("  exhausted      : %s" % (after.get("exhausted_models") or []))
        print("  unavailable    : %s (chain names only are persisted)"
              % (after.get("unavailable_models") or []))
    except Exception as exc:  # noqa: BLE001
        print("  could not re-read the state file: %s" % exc)
    print("=" * 68)
    print("DONE - the running service uses %s regardless of any stale latch." % svc.model)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
