"""
scripts/inspect_running_modes.py — what is ACTUALLY running right now?
(2026-08-19, read-only, cp1252-safe)

Answers the operator's question in four sections:
  A) WATCH MAPS   today's session plans per status (READY / WATCH_ONLY /
                  NOT_READY) per symbol, with the watch-downgrade reason
                  breakdown (reversal proof / archetype / quality)
  B) MEASUREMENT  background measurement: agent_measurement rows, last write,
                  correlation closes, risk-analytics reports
  C) EXECUTION    symbol execution modes (all live),
                  execution mode env/config, today's trades by trading_mode
  D) PROCESSES    heartbeats freshness, .demo_halt, order-refusal count in
                  the tick log tail

Usage:
  python scripts/inspect_running_modes.py
  python scripts/inspect_running_modes.py --date 2026-08-19
  python scripts/inspect_running_modes.py --root D:\\Nabil-gold
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass


def _age_minutes(path: Path, now: datetime) -> float | None:
    try:
        mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
        return (now - mtime).total_seconds() / 60.0
    except OSError:
        return None


def _load_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


# ── A: watch maps ─────────────────────────────────────────────────────────────
def section_watch_maps(root: Path, target: str) -> list[str]:
    lines: list[str] = []
    path = root / "storage" / "session_plans.json"
    if not path.exists():
        return ["  session_plans.json MISSING - planner has never written a plan"]
    rows = _load_json(path) or []
    if not isinstance(rows, list):
        return ["  session_plans.json unreadable"]
    by_symbol = Counter()
    statuses = Counter()
    reasons = Counter()
    for row in rows:
        if not isinstance(row, dict):
            continue
        created = str(row.get("created_at") or "")
        if not created.startswith(target):
            continue
        symbol = str(row.get("symbol") or "XAU/USD")
        by_symbol[symbol] += 1
        status = str(row.get("plan_status") or "NOT_READY").upper()
        statuses[status] += 1
        if status == "WATCH_ONLY":
            reason = str(row.get("plan_reason") or "")
            if "reversal" in reason.lower():
                reasons["reversal_proof"] += 1
            elif "conviction" in reason.lower():
                reasons["archetype_conviction"] += 1
            elif "quality" in reason.lower() or "floor" in reason.lower():
                reasons["quality_floor"] += 1
            else:
                reasons["other"] += 1
    lines.append(f"  today's plans ({target}): total={sum(by_symbol.values())} by_symbol={dict(by_symbol)}")
    lines.append(f"  statuses: {dict(statuses)}")
    if reasons:
        lines.append(f"  WATCH_ONLY reasons: {dict(reasons)}")
        lines.append("  sample plan_reason texts:")
        samples: list[str] = []
        for row in rows:
            if isinstance(row, dict) and str(row.get("plan_status") or "").upper() == "WATCH_ONLY":
                text = str(row.get("plan_reason") or "").strip()
                if text and text not in samples:
                    samples.append(text)
                if len(samples) >= 4:
                    break
        for s in samples:
            lines.append(f"    - {s[:110]}")
    else:
        lines.append("  WATCH_ONLY reasons: none today")
    return lines


# ── B: measurement ───────────────────────────────────────────────────────────
def section_measurement(root: Path, target: str, config: dict) -> list[str]:
    lines: list[str] = []
    am = config.get("agent_measurement") or {}
    lines.append(f"  agent_measurement.enabled = {bool(am.get('enabled'))}")
    base = root / "storage" / "agent_measurements"
    if base.exists():
        files = sorted(base.glob("agent_system_*.jsonl"))
        today_file = base / f"agent_system_{target}.jsonl"
        rows_today = 0
        last_age = None
        if today_file.exists():
            try:
                rows_today = sum(1 for _ in today_file.open(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                rows_today = -1
            last_age = _age_minutes(today_file, datetime.now(timezone.utc))
        lines.append(
            f"  measurement files: {len(files)} | today rows: {rows_today} | "
            f"last write: {last_age:.0f} min ago" if last_age is not None
            else f"  measurement files: {len(files)} | today rows: {rows_today} | no today file"
        )
    else:
        lines.append("  storage/agent_measurements/ MISSING")
    cg = config.get("correlation_guard") or {}
    lines.append(f"  correlation_guard.enabled = {bool(cg.get('enabled'))} enforce = {bool(cg.get('enforce'))}")
    corr_path = root / "storage" / "correlation" / "daily_closes.json"
    if corr_path.exists():
        closes = _load_json(corr_path) or {}
        total = sum(len(v) for v in closes.values() if isinstance(v, (dict, list)))
        lines.append(f"  correlation closes file: {total} entries ({list(closes.keys()) if isinstance(closes, dict) else '?'})")
    else:
        lines.append("  correlation closes file: none yet")
    return lines


# ── C: execution modes ───────────────────────────────────────────────────────
def section_execution(root: Path, target: str, config: dict) -> list[str]:
    lines: list[str] = []
    symbols = config.get("symbols") or []
    for s in symbols:
        if isinstance(s, dict):
            lines.append(
                f"  symbol {s.get('symbol')}: enabled={s.get('enabled')} mode=LIVE"
            )
    exec_mode = (config.get("execution") or {}).get("execution_mode")
    lines.append(f"  config execution_mode = {exec_mode} | env EXECUTION_MODE = {__import__('os').environ.get('EXECUTION_MODE', '-')}")
    trades_path = root / "storage" / "trades.json"
    if trades_path.exists():
        rows = _load_json(trades_path) or []
        if isinstance(rows, list):
            modes = Counter(str(r.get("trading_mode") or "?") for r in rows
                            if str(r.get("created_at") or "").startswith(target))
            lines.append(f"  today's trades by trading_mode: {dict(modes)}")
    return lines


# ── D: processes ─────────────────────────────────────────────────────────────
def section_processes(root: Path) -> list[str]:
    lines: list[str] = []
    now = datetime.now(timezone.utc)
    for name in ("heartbeat.json", "tick_heartbeat.json"):
        p = root / name
        age = _age_minutes(p, now)
        lines.append(f"  {name}: {age:.0f} min ago" if age is not None else f"  {name}: MISSING")
    halt = root / ".demo_halt"
    if halt.exists():
        try:
            reason = halt.read_text(encoding="utf-8", errors="replace").strip()[:100]
        except Exception:  # noqa: BLE001
            reason = "(unreadable)"
        lines.append(f"  .demo_halt EXISTS: {reason}")
    else:
        lines.append("  .demo_halt absent")
    tick_log = root / "logs" / "tick_manager.log"
    if tick_log.exists():
        try:
            with tick_log.open("rb") as fh:
                fh.seek(0, 2)
                size = fh.tell()
                fh.seek(max(0, size - 65536))
                tail = fh.read().decode("utf-8", errors="replace")
            refusals = tail.count("Demo order refused")
            lines.append(f"  'Demo order refused' in tick log tail: {refusals}" + ("  <- daily cap!" if refusals else ""))
        except Exception:  # noqa: BLE001
            lines.append("  tick log unreadable")
    else:
        lines.append("  logs/tick_manager.log MISSING")
    return lines


def main() -> int:
    parser = argparse.ArgumentParser(description="What is running right now (read-only)")
    parser.add_argument("--date", type=str, default=None, help="YYYY-MM-DD (default: today)")
    parser.add_argument("--root", type=str, default=str(ROOT))
    args = parser.parse_args()
    root = Path(args.root)

    config = _load_json(root / "config.json") or {}
    tz_name = str((config.get("schedule") or {}).get("timezone") or "Asia/Hebron")
    try:
        zone = ZoneInfo(tz_name)
    except Exception:  # noqa: BLE001
        zone = ZoneInfo("UTC")
    target = args.date or datetime.now(timezone.utc).astimezone(zone).date().strftime("%Y-%m-%d")

    print("=" * 74)
    print(f"RUNNING MODES INSPECTION - {target} (read-only)")
    print("=" * 74)
    print()
    print("A) WATCH MAPS (session planner statuses today)")
    for line in section_watch_maps(root, target):
        print(line)
    print()
    print("B) BACKGROUND MEASUREMENT")
    for line in section_measurement(root, target, config):
        print(line)
    print()
    print("C) EXECUTION MODES (live execution)")
    for line in section_execution(root, target, config):
        print(line)
    print()
    print("D) BACKGROUND PROCESSES")
    for line in section_processes(root):
        print(line)
    print()
    print("-" * 74)
    print("What this means:")
    print("  WATCH_ONLY > 0       -> maps are being watched, not traded (reversal/")
    print("                          archetype/quality gates). To trade them: lower")
    print("                          planner floors or disable the gates.")
    print("  agent_measurement.on -> every cycle writes jsonl (background load).")
    print("  'Demo order refused' -> daily cap still blocking placements.")
    print("=" * 74)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
