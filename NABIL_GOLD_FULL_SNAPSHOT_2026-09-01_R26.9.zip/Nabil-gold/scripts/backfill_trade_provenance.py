"""Backfill route provenance onto trade rows saved before 2026-08-17.

The provenance patch (services/database.py::_entry_enrichment) writes
entry_mode / entry_path / execution_path_id / execution_path_name /
confirm_source / warnings at the TOP LEVEL of every NEW trade row. Rows
saved before the patch — including TRADE_20260817_110616, the first
unified-65 gold trade — still answer null, even though the full values sit
inside their own signal_snapshot.

This tool copies those fields up from each row's snapshot, once. It:
  * uses the project's own mutate_trades (interprocess file lock + atomic
    replace), so it is safe to run while the scheduled tasks are live;
  * only fills fields that are currently missing/None — it NEVER overwrites
    a value the new save path already wrote;
  * touches nothing else in the row and leaves the snapshot untouched.

Run from an ordinary (non-elevated) PowerShell:
    python scripts\\backfill_trade_provenance.py           # report + apply
    python scripts\\backfill_trade_provenance.py --dry-run # report only
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from utils.helpers import mutate_trades  # noqa: E402

FIELDS = (
    "entry_mode",
    "entry_path",
    "execution_path_id",
    "execution_path_name",
    "confirm_source",
)


def _from_snapshot(snap: dict, field: str):
    if field == "execution_path_name":
        value = snap.get(field)
        if value:
            return value
        ep = snap.get("execution_path")
        return ep.get("name") if isinstance(ep, dict) else None
    return snap.get(field)


def backfill(rows: list, apply: bool) -> dict:
    stats = {"rows": len(rows), "updated": 0, "filled": 0, "no_snapshot": 0}
    for row in rows:
        snap = row.get("signal_snapshot")
        if not isinstance(snap, dict):
            stats["no_snapshot"] += 1
            continue
        changed = []
        for field in FIELDS:
            if row.get(field) is None:
                value = _from_snapshot(snap, field)
                if value is not None:
                    if apply:
                        row[field] = value
                    changed.append(f"{field}={value}")
        if row.get("warnings") is None:
            snap_warnings = [str(w) for w in (snap.get("warnings") or []) if str(w).strip()]
            if apply:
                row["warnings"] = snap_warnings
            changed.append(f"warnings[{len(snap_warnings)}]")
        if changed:
            stats["updated"] += 1
            stats["filled"] += len(changed)
            print(f"  {row.get('id')}: " + ", ".join(changed))
    return stats


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--dry-run", action="store_true",
                        help="report what would change without writing")
    parser.add_argument("--trades", default=None,
                        help="path to trades.json (default: storage/trades.json)")
    args = parser.parse_args()

    path = Path(args.trades) if args.trades else ROOT / "storage" / "trades.json"
    if not path.exists():
        print(f"trades file not found: {path}")
        return 1

    print(("DRY RUN — " if args.dry_run else "") + f"backfilling provenance in {path}")
    if args.dry_run:
        # Read-only pass: mutate_trades would persist, so load via the same
        # strict reader without writing back.
        from utils.helpers import _load_json_list_strict  # noqa: PLC0415
        rows = _load_json_list_strict(path)
        stats = backfill(rows, apply=False)
    else:
        stats = mutate_trades(lambda rows: backfill(rows, apply=True), path)

    print(
        f"rows={stats['rows']} updated={stats['updated']} "
        f"fields_filled={stats['filled']} no_snapshot={stats['no_snapshot']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
