"""
scripts/oil_macro_check.py — is the OIL macro alive and working?
(2026-08-19 build 14, read-only, cp1252-safe)

The operator asked: where is the oil - why do I never see it entering
trades? The WTI entry chain is: two qualified core agents + oil_macro>=55
(or gemini>=70). This check tests every link of that chain live:

  A) CONFIG      oil_macro section (crack layer, files, thresholds)
  B) EIA FILE    storage/oil/eia_weekly.json presence + age + values
  C) OPEC FILE   storage/oil/opec_context.json presence + tone
  D) CRACK LAYER live RB=F / HO=F vs CL=F (yfinance) - works with NO files
  E) SPREAD      Brent-WTI spread z (BZ=F vs CL=F)
  F) AGENT RUN   OilMacroAgent.analyze("WTI/USD") -> direction/confidence/
                 missing inputs, and whether it would confirm a SELL/BUY at
                 the 55 floor

Usage:
  python scripts/oil_macro_check.py
  python scripts/oil_macro_check.py --root D:\\Nabil-gold
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass


def _age_hours(path: Path) -> Optional[float]:
    try:
        mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
        return (datetime.now(timezone.utc) - mtime).total_seconds() / 3600.0
    except OSError:
        return None


def _load_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def section_config(root: Path, config: dict) -> List[str]:
    lines: List[str] = []
    om = config.get("oil_macro") or {}
    lines.append(f"  crack_enabled = {bool(om.get('crack_enabled', True))}")
    lines.append(f"  eia_path      = {om.get('eia_path', 'storage/oil/eia_weekly.json')}")
    lines.append(f"  opec_path     = {om.get('opec_path', 'storage/oil/opec_context.json')}")
    oil_conf = ((config.get("signal_requirements") or {}).get("two_agent_entry") or {}).get(
        "oil_macro_confirmation") or {}
    lines.append(f"  confirmation  = enabled={bool(oil_conf.get('enabled', True))} min_confidence={oil_conf.get('min_confidence', 55)}")
    wti = [s for s in (config.get("symbols") or []) if isinstance(s, dict) and s.get("symbol") == "WTI/USD"]
    mode = "LIVE (executes on MT5)" if wti and "mode" not in wti[0] else str((wti[0] or {}).get("mode")) if wti else "MISSING"
    lines.append(f"  WTI symbol mode = {mode}")
    return lines


def section_files(root: Path, config: dict) -> Tuple[List[str], int]:
    lines: List[str] = []
    problems = 0
    om = config.get("oil_macro") or {}
    eia_path = root / str(om.get("eia_path", "storage/oil/eia_weekly.json"))
    if eia_path.exists():
        age = _age_hours(eia_path)
        data = _load_json(eia_path)
        if isinstance(data, dict):
            lines.append(
                f"  eia_weekly.json OK: week={data.get('week')} crude={data.get('crude_change_mb')} "
                f"gasoline={data.get('gasoline_change_mb')} distillate={data.get('distillate_change_mb')} "
                f"util={data.get('refinery_util_pct')} age={age:.0f}h" if age is not None
                else f"  eia_weekly.json OK: week={data.get('week')} (age unknown)")
            if data.get("week") is None:
                problems += 1
        else:
            lines.append("  eia_weekly.json unreadable")
            problems += 1
    else:
        lines.append("  eia_weekly.json MISSING - run scripts\\fill_oil_macro.py (free EIA_API_KEY)")
        lines.append("      or fill storage\\oil\\eia_weekly.json manually (see .example)")
        problems += 1

    opec_path = root / str(om.get("opec_path", "storage/oil/opec_context.json"))
    if opec_path.exists():
        data = _load_json(opec_path)
        if isinstance(data, dict):
            lines.append(f"  opec_context.json OK: tone={data.get('tone')} date={data.get('date')}")
            if str(data.get("tone") or "").upper() not in {"CUT", "HIKE", "NEUTRAL"}:
                problems += 1
        else:
            lines.append("  opec_context.json unreadable")
            problems += 1
    else:
        lines.append("  opec_context.json MISSING - fill after each OPEC meeting (see .example)")
        problems += 1
    return lines, problems


def section_live(root: Path) -> Tuple[List[str], int]:
    """Live crack + spread probe via yfinance (cached)."""
    from services.aux_market_data import yf_closes

    lines: List[str] = []
    problems = 0
    ok = 0
    for sym, name in (("CL=F", "crude"), ("RB=F", "gasoline"), ("HO=F", "distillate"), ("BZ=F", "brent")):
        closes = yf_closes(sym, days=90, cache_path=f"storage/aux_cache/{sym.replace('=','_')}.json", ttl_hours=0.5)
        if closes:
            lines.append(f"  {sym:<5} {name:<12} OK: {len(closes)} closes, last={closes[-1]:.2f}")
            ok += 1
        else:
            lines.append(f"  {sym:<5} {name:<12} FAIL: yfinance returned nothing (network? symbol?)")
            problems += 1
    if ok >= 3:
        try:
            from agents.oil_macro_agent import OilMacroAgent

            agent = OilMacroAgent({"oil_macro": {"enabled": True, "crack_enabled": True}})
            points, reasons = agent._crack_component()
            lines.append(f"  crack component: points={points} ({'; '.join(reasons) if reasons else 'stable'})")
            z = agent._spread_z()
            lines.append(f"  brent-wti spread z: {round(z, 2) if z is not None else 'N/A'}")
        except Exception as exc:  # noqa: BLE001
            lines.append(f"  live component run failed: {exc}")
            problems += 1
    else:
        lines.append("  crack/spread live probe incomplete - yfinance data missing")
    return lines, problems


def section_agent(root: Path, config: dict) -> List[str]:
    from agents.oil_macro_agent import OilMacroAgent

    lines: List[str] = []
    try:
        agent = OilMacroAgent(config)
        r = agent.analyze({"symbol": "WTI/USD"})
        lines.append(f"  direction={r.get('direction')} bias={r.get('bias')} confidence={r.get('confidence')}")
        lines.append(f"  score={r.get('score')} missing={r.get('missing')} signal={r.get('signal')}")
        conf = float(r.get("confidence") or 0)
        side = str(r.get("direction") or "WAIT")
        if side in {"BUY", "SELL"} and conf >= 55:
            lines.append(f"  -> WOULD CONFIRM a two-agent {side} entry (>=55)")
        elif side in {"BUY", "SELL"}:
            lines.append(f"  -> direction present but BELOW the 55 floor ({conf:.0f}) - no confirmation")
        else:
            lines.append("  -> NEUTRAL: the oil macro cannot confirm any entry right now")
        if r.get("summary"):
            lines.append(f"  summary: {r.get('summary')}")
    except Exception as exc:  # noqa: BLE001
        lines.append(f"  agent run failed: {exc}")
    return lines


def main() -> int:
    parser = argparse.ArgumentParser(description="Is the oil macro alive (read-only)")
    parser.add_argument("--root", type=str, default=str(ROOT))
    args = parser.parse_args()
    root = Path(args.root)

    from utils.helpers import load_config

    config = load_config()
    print("=" * 74)
    print("OIL MACRO CHECK - is the oil chain alive?")
    print("=" * 74)
    print()
    print("A) CONFIG")
    for line in section_config(root, config):
        print(line)
    print()
    print("B) OPERATOR FILES (EIA + OPEC)")
    file_lines, file_problems = section_files(root, config)
    for line in file_lines:
        print(line)
    print()
    print("C) LIVE MARKET LAYER (crack + spread)")
    live_lines, live_problems = section_live(root)
    for line in live_lines:
        print(line)
    print()
    print("D) AGENT RUN (WTI)")
    for line in section_agent(root, config):
        print(line)
    print()
    print("-" * 74)
    if live_problems == 0 and file_problems == 0:
        print("VERDICT: ALIVE - files filled + market layer live")
    elif live_problems == 0:
        print("VERDICT: ALIVE (market layer) - operator files missing; fill EIA/OPEC for the fundamental layer")
    elif file_problems == 0:
        print("VERDICT: WEAK - files exist but the live yfinance layer is down")
    else:
        print("VERDICT: WEAK - fill the EIA/OPEC files and check yfinance reachability")
    print("-" * 74)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
