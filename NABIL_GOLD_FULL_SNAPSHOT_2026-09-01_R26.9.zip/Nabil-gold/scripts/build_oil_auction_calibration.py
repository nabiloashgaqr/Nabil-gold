"""Build the WTI auction-flow calibration from MT5 history (BUILD 20).

The oil auction agent has been running on the explicit linear fallback
(calibration_required=false) since build 14. The operator ordered the REAL
curve built now that the WTI tick store is fed live.

This script reuses the EXACT gold trainer (scripts/build_agent_calibrations):
same edge sweep, same barrier/horizon labels, same monotonic logistic fit,
same checksummed payload - but pointed at the WTI suffixed store and the WTI
suffixed calibration path the agent derives (auction_flow_wtiusd.sqlite3 /
auction_flow_v1_wtiusd.json). It never touches the gold store or curve.

On success it flips the production flag (config.json WTI entry
auction_flow.calibration_required) to TRUE so the agent DEMANDS the curve
instead of silently falling back. On failure use --revert to flip it back
(the live feed keeps the linear fallback until the build can be retried).

Usage:
  python scripts\\build_oil_auction_calibration.py            # build + verify
  python scripts\\build_oil_auction_calibration.py --revert   # flag back to false
  python scripts\\build_oil_auction_calibration.py --days 60 --tick-days 15
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, Tuple

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

from services.auction_flow_store import AuctionFlowStore  # noqa: E402
from services.timeframe_fusion import CANONICAL_TIMEFRAMES  # noqa: E402
from utils.helpers import load_config  # noqa: E402
from utils.instruments import config_for_instrument, normalize_symbol  # noqa: E402
from scripts.build_agent_calibrations import (  # noqa: E402
    _fetch_ticks,
    _mt5_ready,
    _native_rates,
    _symbol,
    build_auction,
)

CONFIG_PATH = ROOT / "config.json"

# BUILD 20.2: parameters the edge sweep found promising for WTI
# (value_only +4.49pp lift at h=4/k=0.5; h=16/k=1.0 +3.92pp). The script
# retries with these automatically when the default build yields a weak
# curve, and persists them on success so the live agent trains/reads the
# same definition.
SUGGESTED_RETRY = {
    "edge_definition": "value_only",
    "calibration_horizon_15m_bars": 16,
    "calibration_barrier_atr": 1.0,
}


def oil_paths(base_config: Dict[str, Any]) -> Tuple[Dict[str, Any], Path, Path]:
    """(wti config, suffixed store path, suffixed calibration path).

    Mirrors the agent's own derivation exactly (agents/auction_flow_agent.py
    __init__): gold keeps its historical paths; every other instrument gets
    stem + '_' + lowercase symbol (auction_flow_wtiusd.sqlite3 /
    auction_flow_v1_wtiusd.json).
    """
    wti_cfg = config_for_instrument(base_config, {"symbol": "WTI/USD"})
    auction_cfg = wti_cfg.get("auction_flow") or {}
    store_path = Path(str(auction_cfg.get("storage_path") or "storage/auction_flow.sqlite3"))
    cal_path = Path(str(auction_cfg.get("calibration_path") or "storage/model_calibration/auction_flow_v1.json"))
    stem = normalize_symbol("WTI/USD").replace("/", "").lower()
    store = store_path.with_name(f"{store_path.stem}_{stem}{store_path.suffix}")
    cal = cal_path.with_name(f"{cal_path.stem}_{stem}{cal_path.suffix}")
    return wti_cfg, store, cal


def set_config_flag(cfg_path: Path, enabled: bool) -> bool:
    """Flip the production WTI calibration_required flag (config.json)."""
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    changed = False
    for inst in cfg.get("instruments") or []:
        if not isinstance(inst, dict):
            continue
        if "WTI" not in str(inst.get("symbol") or "").upper():
            continue
        inst.setdefault("auction_flow", {})["calibration_required"] = bool(enabled)
        changed = True
    if not changed:
        raise RuntimeError("WTI/USD instrument entry not found in config.json")
    cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return True


def _curve_accepted(payload: Dict[str, Any]) -> bool:
    """BUILD 20.1: the live agent's own discriminating-power rule.

    The agent holds the auction at the 50% floor (valid=False -> WAIT forever)
    whenever the stored curve spans < 2pp. A curve that cannot discriminate
    must NEVER lock the production flag or stay in the calibration path -
    otherwise it poisons even the linear fallback (the agent loads it and
    never votes).
    """
    span = float(((payload or {}).get("curve_health") or {}).get("span_points") or 0.0)
    return span >= 2.0


def _move_curve_aside(cal_path: Path, tag: str) -> None:
    """Move a curve file out of the agent's load path (kept for the record)."""
    if cal_path.exists():
        dest = cal_path.with_name(f"{cal_path.stem}.{tag}{cal_path.suffix}")
        cal_path.replace(dest)
        print(f"curve moved aside: {dest.name}")


def _apply_overrides(
    wti_cfg: Dict[str, Any],
    edge: str | None = None,
    horizon_bars: int | None = None,
    barrier_atr: float | None = None,
) -> Dict[str, Any]:
    """Apply optional retry parameters into the auction_flow block."""
    overrides: Dict[str, Any] = {}
    if edge:
        overrides["edge_definition"] = edge
    if horizon_bars:
        overrides["calibration_horizon_15m_bars"] = int(horizon_bars)
    if barrier_atr:
        overrides["calibration_barrier_atr"] = float(barrier_atr)
    auc = wti_cfg.setdefault("auction_flow", {})
    for key, value in overrides.items():
        auc[key] = value
    if overrides:
        print(f"retry parameters applied: {overrides}")
    return overrides


def _persist_overrides(cfg_path: Path, overrides: Dict[str, Any]) -> None:
    """Persist successful retry parameters into the production WTI entry so
    the LIVE agent uses the same definition the curve was trained on."""
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    for inst in cfg.get("instruments") or []:
        if isinstance(inst, dict) and "WTI" in str(inst.get("symbol") or "").upper():
            auc = inst.setdefault("auction_flow", {})
            for key, value in overrides.items():
                auc[key] = value
            cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"retry parameters persisted to production config: {overrides}")
            return
    raise RuntimeError("WTI/USD instrument entry not found in config.json")


def _finalize_build(
    payload: Dict[str, Any],
    cfg_path: Path,
    cal_path: Path,
    overrides: Dict[str, Any] | None = None,
) -> int:
    """Gate the curve, then lock or refuse the production flag.

    Returns 0 (healthy curve, flag locked), 2 (weak curve, flag kept off and
    the file moved aside so the linear fallback resumes).
    """
    span = float(((payload or {}).get("curve_health") or {}).get("span_points") or 0.0)
    lift = float(((payload or {}).get("curve_health") or {}).get("tercile_lift_points") or 0.0)
    print(f"AUCTION FLOW CALIBRATION OK: {payload.get('sample_count')} samples "
          f"span={span}pp lift={lift}pp")
    if not _curve_accepted(payload):
        print("")
        print("WEAK CURVE VERDICT: span < 2pp - the live agent would hold the")
        print("auction at the 50% floor (valid=False) -> permanent WAIT for oil.")
        print("The flag stays OFF and the weak curve is moved aside so the")
        print("linear fallback keeps Paths 4/5 alive.")
        set_config_flag(cfg_path, False)
        _move_curve_aside(cal_path, "weak")
        print("Retry with the parameters the sweep found promising:")
        print("  python scripts\\build_oil_auction_calibration.py "
              "--edge value_only --horizon-bars 16 --barrier-atr 1.0")
        return 2
    if overrides:
        _persist_overrides(cfg_path, overrides)
    set_config_flag(cfg_path, True)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=180,
                        help="candle history days for M5/M15/H1/H4")
    parser.add_argument("--tick-days", type=int, default=60,
                        help="broker tick history days for the WTI store")
    parser.add_argument("--revert", action="store_true",
                        help="flip the production calibration_required flag back to false")
    parser.add_argument("--edge", default=None,
                        help="retry: edge definition (the sweep found value_only)")
    parser.add_argument("--horizon-bars", type=int, default=None,
                        help="retry: calibration horizon in 15m bars (sweep found 16)")
    parser.add_argument("--barrier-atr", type=float, default=None,
                        help="retry: barrier in ATR multiples (sweep found 1.0)")
    args = parser.parse_args()

    if args.revert:
        set_config_flag(CONFIG_PATH, False)
        base_config = load_config()
        _, _, cal_path = oil_paths(base_config)
        _move_curve_aside(cal_path, "reverted")
        print("REVERTED: WTI calibration_required = false and any curve file")
        print("moved aside -> the linear fallback is active again.")
        return 0

    base_config = load_config()
    wti_cfg, store_path, cal_path = oil_paths(base_config)
    overrides = _apply_overrides(wti_cfg, args.edge, args.horizon_bars, args.barrier_atr)
    print(f"WTI calibration build: store={store_path}  output={cal_path}")

    mt5 = _mt5_ready()
    broker_symbol = _symbol(wti_cfg)
    print(f"broker symbol: {broker_symbol}")
    if not mt5.symbol_select(broker_symbol, True):
        raise RuntimeError(f"MT5 symbol_select failed for {broker_symbol}: {mt5.last_error()}")

    rates = {tf: _native_rates(mt5, broker_symbol, tf, args.days)
             for tf in CANONICAL_TIMEFRAMES}
    for tf in CANONICAL_TIMEFRAMES:
        print(f"NATIVE {tf}: {len(rates[tf])} candles")

    store = AuctionFlowStore(str(store_path))
    # BUILD 20.2: enlarge the sample with a graceful tick-history fallback.
    # The broker may not serve the full requested range; step down instead
    # of failing the whole build.
    total_ticks = 0
    fetch_errors = []
    for attempt_days in (args.tick_days, 30, 15):
        try:
            total_ticks = _fetch_ticks(mt5, broker_symbol, attempt_days, store)
            break
        except Exception as exc:  # noqa: BLE001
            fetch_errors.append(f"{attempt_days}d: {exc}")
            print(f"tick fetch with {attempt_days} days failed: {exc}")
    else:
        raise RuntimeError("tick history fetch failed at every range: " + "; ".join(fetch_errors))
    print(f"AUCTION TICKS LOADED: {total_ticks}")

    payload = build_auction(wti_cfg, rates, store, cal_path)
    status = _finalize_build(payload, CONFIG_PATH, cal_path, overrides)
    # BUILD 20.2 self-healing second pass: when the default definition yields
    # a weak curve and the operator passed no explicit overrides, retrain
    # with the sweep-found promising parameters in the SAME run.
    if status == 2 and not overrides:
        print("")
        print("AUTO-RETRY with the sweep-found parameters:")
        print(f"  {SUGGESTED_RETRY}")
        retry_overrides = _apply_overrides(
            wti_cfg,
            str(SUGGESTED_RETRY.get("edge_definition")),
            int(SUGGESTED_RETRY.get("calibration_horizon_15m_bars") or 0),
            float(SUGGESTED_RETRY.get("calibration_barrier_atr") or 0.0),
        )
        payload2 = build_auction(wti_cfg, rates, store, cal_path)
        status = _finalize_build(payload2, CONFIG_PATH, cal_path, retry_overrides)
    if status == 2:
        return 2

    auction_cfg = wti_cfg.get("auction_flow") or {}
    store.prune(
        second_days=int(auction_cfg.get("second_retention_days", 7) or 7),
        minute_days=int(auction_cfg.get("minute_retention_days", 90) or 90),
    )

    # End-to-end proof: a fresh agent over the fresh config must LOAD the curve.
    from agents.auction_flow_agent import AuctionFlowAgent
    agent = AuctionFlowAgent(config_for_instrument(load_config(), {"symbol": "WTI/USD"}))
    if agent.calibration is None:
        raise RuntimeError(
            "curve written but the WTI agent refuses it (checksum/version/symbol guard)")
    print(f"WTI agent verification: required={agent.calibration_required} "
          f"calibration_loaded={agent.calibration is not None}")
    print("CALIBRATIONS READY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
