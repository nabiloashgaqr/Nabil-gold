"""Automated Storage Maintenance and Cleanup Service.

Runs periodically to ensure disk space remains minimal and optimized:
- Rotates and caps log files to <= 5MB.
- Removes temporary image cards and charts older than 3 days.
- Retains only the 2 latest deployment backups.
- Cleans Python bytecode caches (__pycache__).
- Performs SQLite VACUUM and WAL checkpointing.
"""

from __future__ import annotations

import glob
import logging
import os
import shutil
import sqlite3
import time
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
logger = logging.getLogger("storage_maintenance")


def clean_pycache(base_dir: Path = ROOT_DIR) -> int:
    freed = 0
    for root, dirs, files in os.walk(base_dir, topdown=False):
        for d in dirs:
            if d in ("__pycache__", ".pytest_cache", ".coverage"):
                dp = os.path.join(root, d)
                try:
                    for rf, _, rfiles in os.walk(dp):
                        for rf_name in rfiles:
                            freed += os.path.getsize(os.path.join(rf, rf_name))
                    shutil.rmtree(dp, ignore_errors=True)
                except Exception:
                    pass
    return freed


def clean_old_backups(base_dir: Path = ROOT_DIR, keep_count: int = 2) -> int:
    freed = 0
    backups_dir = base_dir / "deploy" / "backups"
    if not backups_dir.exists():
        return 0
    subdirs = [backups_dir / d for d in os.listdir(backups_dir) if (backups_dir / d).is_dir()]
    subdirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    for old_dir in subdirs[keep_count:]:
        try:
            for rf, _, rfiles in os.walk(old_dir):
                for rf_name in rfiles:
                    freed += os.path.getsize(os.path.join(rf, rf_name))
            shutil.rmtree(old_dir, ignore_errors=True)
        except Exception:
            pass
    return freed


def rotate_logs(base_dir: Path = ROOT_DIR, max_bytes: int = 5 * 1024 * 1024, keep_lines: int = 2000) -> int:
    freed = 0
    patterns = [
        str(base_dir / "*.log"),
        str(base_dir / "logs" / "*.log"),
        str(base_dir / "storage" / "*.log"),
    ]
    for p in patterns:
        for lf in glob.glob(p):
            try:
                sz = os.path.getsize(lf)
                if sz > max_bytes:
                    with open(lf, "r", encoding="utf-8", errors="ignore") as f:
                        lines = f.readlines()
                    kept = lines[-keep_lines:]
                    with open(lf, "w", encoding="utf-8") as f:
                        f.writelines(kept)
                    new_sz = os.path.getsize(lf)
                    freed += max(0, sz - new_sz)
            except Exception:
                pass
    return freed


def clean_temp_media(base_dir: Path = ROOT_DIR, max_age_days: int = 3) -> int:
    freed = 0
    now = time.time()
    cutoff = now - (max_age_days * 86400)
    for folder in ("cards", "charts", "reports"):
        target_dir = base_dir / "storage" / folder
        if target_dir.exists():
            for f in target_dir.iterdir():
                if f.is_file() and f.stat().st_mtime < cutoff:
                    try:
                        freed += f.stat().st_size
                        f.unlink()
                    except Exception:
                        pass
    return freed


def optimize_sqlite_databases(base_dir: Path = ROOT_DIR) -> int:
    freed = 0
    db_patterns = [
        str(base_dir / "storage" / "*.sqlite3"),
        str(base_dir / "storage" / "*.db"),
    ]
    for p in db_patterns:
        for db_file in glob.glob(p):
            try:
                old_sz = os.path.getsize(db_file)
                conn = sqlite3.connect(db_file)
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE);")
                conn.execute("VACUUM;")
                conn.close()
                new_sz = os.path.getsize(db_file)
                if old_sz > new_sz:
                    freed += (old_sz - new_sz)
            except Exception:
                pass
    return freed


def run_maintenance(base_dir: Path = ROOT_DIR) -> dict[str, float]:
    f_pyc = clean_pycache(base_dir)
    f_bak = clean_old_backups(base_dir)
    f_log = rotate_logs(base_dir)
    f_med = clean_temp_media(base_dir)
    f_sql = optimize_sqlite_databases(base_dir)

    total_mb = (f_pyc + f_bak + f_log + f_med + f_sql) / (1024 * 1024)
    return {
        "pycache_freed_mb": f_pyc / (1024 * 1024),
        "backups_freed_mb": f_bak / (1024 * 1024),
        "logs_freed_mb": f_log / (1024 * 1024),
        "media_freed_mb": f_med / (1024 * 1024),
        "sqlite_freed_mb": f_sql / (1024 * 1024),
        "total_freed_mb": total_mb,
    }


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    res = run_maintenance()
    print(f"Auto-maintenance complete. Total freed: {res['total_freed_mb']:.2f} MB")
