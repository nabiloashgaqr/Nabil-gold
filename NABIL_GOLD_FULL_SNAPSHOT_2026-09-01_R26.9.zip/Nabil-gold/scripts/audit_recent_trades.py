#!/usr/bin/env python3
"""Recent-trades forensic audit (BUILD 31 R12) - today + yesterday.

Answers the operator's question with numbers, not opinions:

  1. What did we trade today and yesterday (per Hebron day)?
  2. For every LOSER: would the R10/R11 institutional guards have blocked
     it? (quiet hours 21:00-06:30 UTC, VWAP+/-1.2ATR bands, 80/20 dealing
     range, consolidation lockdown, flow confirmation at 65, buy-the-dip /
     sell-the-rally, consecutive-loss halt)
  3. THE HONEST METRIC: the same replay is run on WINNERS too. A guard that
     also blocks winners is not free - the report shows net points saved.

Evidence per trade comes from the trade row itself (entry_hour_local,
session_label, market_phase, regime_composite, warnings) plus a defensive
dig into the stored signal_snapshot (auction vwap, atr, smc zone/range,
archetype, market regime). Missing evidence is reported as UNKNOWN - never
guessed.

Usage (from the repo root):
    python scripts\\audit_recent_trades.py                 # today + yesterday
    python scripts\\audit_recent_trades.py --days 3
    python scripts\\audit_recent_trades.py --date 2026-08-27
    python scripts\\audit_recent_trades.py --json out.json

Exit code 0 always (a report tool, not a gate).
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

# Windows consoles/pipes may use cp1252, which cannot encode glyphs like the
# ">=" that appears in live refusal reasons. Replace instead of crash (the
# full-fidelity text still goes to the JSON output, which is always UTF-8).
try:
    sys.stdout.reconfigure(errors="replace")
except (AttributeError, ValueError):
    pass


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


HEBRON = ZoneInfo("Asia/Hebron")
DEFAULT_BOOK = ROOT / "storage" / "trades.json"

# BUILD31-R13: the guard logic lives ONCE in services/guard_replay.py so the
# manual report and the guard `would_block` field written by database.py can
# never drift apart. This script re-imports it.
from services.guard_replay import (  # noqa: E402
    CLOSED_STATUSES, WIN_STATUSES, LOSS_STATUSES, OLD_FLOW_BAR, NEW_FLOW_BAR,
    parse_ts, hebron_day, trade_pnl_points, outcome, in_quiet_hours,
    collect_evidence, is_breakout_chase, open_same_direction_at, replay_guards,
    would_block_for,
)


def load_book(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(data, dict):
        data = data.get("trades") or []
    return [t for t in data if isinstance(t, dict)]


def fmt_price(value, symbol):
    from utils.instruments import format_price
    return format_price(value, symbol)


def summarize_day(day, trades, book):
    closed = [t for t in trades if outcome(t) in ("WIN", "LOSS", "BE")]
    wins = [t for t in closed if outcome(t) == "WIN"]
    losses = [t for t in closed if outcome(t) == "LOSS"]
    open_tr = [t for t in trades if outcome(t) in ("OPEN", "LOSS(OPEN)")]
    pnls = {t["id"]: trade_pnl_points(t) for t in trades}
    net = sum(pnls.values())
    gross_w = sum(pnls[t["id"]] for t in wins)
    gross_l = sum(-pnls[t["id"]] for t in losses)
    pf = (gross_w / gross_l) if gross_l > 0 else float("inf") if gross_w > 0 else 0.0
    return {
        "trades": trades, "closed": closed, "wins": wins, "losses": losses,
        "open": open_tr, "net": net, "pf": pf,
        "gross_w": gross_w, "gross_l": gross_l,
    }


def print_table(rows, headers):
    widths = [max(len(str(h)), *(len(str(r[i])) for r in rows)) if rows else len(str(h))
              for i, h in enumerate(headers)]
    line = "  ".join(str(h).ljust(w) for h, w in zip(headers, widths))
    print(line)
    print("-" * len(line))
    for r in rows:
        print("  ".join(str(c).ljust(w) for c, w in zip(r, widths)))


def main():
    ap = argparse.ArgumentParser(description="Today+Yesterday trades forensic audit with guard replay")
    ap.add_argument("--book", default=str(DEFAULT_BOOK), help="path to the local trades book JSON")
    ap.add_argument("--days", type=int, default=2, help="how many Hebron days back (default 2)")
    ap.add_argument("--date", default=None, help="single Hebron date YYYY-MM-DD instead of a range")
    ap.add_argument("--json", dest="json_out", default=None, help="also write machine-readable JSON")
    args = ap.parse_args()

    book = load_book(args.book)
    now_h = datetime.now(HEBRON)
    if args.date:
        days = {datetime.strptime(args.date, "%Y-%m-%d").date()}
    else:
        days = {(now_h - timedelta(days=i)).date() for i in range(max(1, args.days))}

    by_day = defaultdict(list)
    unknown_day = 0
    for t in book:
        ts = parse_ts(t.get("created_at") or t.get("entry_time"))
        if not ts:
            unknown_day += 1
            continue
        d = hebron_day(ts)
        if d in days:
            by_day[d].append(t)

    report = {"days": {}, "generated_at": datetime.now(HEBRON).isoformat()}
    print("=" * 100)
    print(" RECENT TRADES FORENSIC AUDIT  (Hebron days)  book=%s  trades=%d" % (args.book, len(book)))
    print("=" * 100)

    for day in sorted(days, reverse=True):
        trades = by_day.get(day, [])
        s = summarize_day(day, trades, book)
        print("\n" + "=" * 100)
        print(" DAY %s   trades=%d  closed=%d  (W=%d L=%d BE=%d)  open=%d"
              % (day, len(trades), len(s["closed"]), len(s["wins"]),
                 len(s["losses"]), len(s["closed"]) - len(s["wins"]) - len(s["losses"]),
                 len(s["open"])))
        print(" net=%+.1f pts   grossWin=%.1f  grossLoss=%.1f  PF=%s   avgW=%+.1f  avgL=%+.1f"
              % (s["net"], s["gross_w"], s["gross_l"],
                 ("%.2f" % s["pf"]) if s["pf"] != float("inf") else "inf",
                 (sum(trade_pnl_points(t) for t in s["wins"]) / len(s["wins"])) if s["wins"] else 0.0,
                 (sum(trade_pnl_points(t) for t in s["losses"]) / len(s["losses"])) if s["losses"] else 0.0))
        print("-" * 100)

        rows = []
        for t in sorted(trades, key=lambda x: str(x.get("created_at") or x.get("entry_time") or "")):
            ts = parse_ts(t.get("created_at") or t.get("entry_time"))
            local = ts.astimezone(HEBRON).strftime("%H:%M") if ts else "??:??"
            o = outcome(t)
            rows.append([
                local, str(t.get("id") or "")[-8:], t.get("symbol"), t.get("type"),
                fmt_price(t.get("entry_price"), t.get("symbol")),
                fmt_price(t.get("close_price"), t.get("symbol")) if t.get("close_price") else "-",
                t.get("status"), "%+.1f" % trade_pnl_points(t),
                str(t.get("entry_path") or t.get("execution_path_id") or "-"),
                str(t.get("session_label") or "-")[:14], o,
            ])
        print_table(rows, ["H", "id", "symbol", "side", "entry", "close", "status",
                           "pnl", "path", "session", "outcome"])

        # -- GUARD REPLAY ----------------------------------------------------
        print("\n GUARD REPLAY - would the R10/R11 guards have blocked these?")
        print("-" * 100)
        saved = foregone = 0.0
        blocked_losses = blocked_wins = unknown_ev = 0
        rep_rows, detail = [], []
        for t in trades:
            o = outcome(t)
            blocked, notes, unknown, arch, ev = replay_guards(t, book)
            pnl = trade_pnl_points(t)
            if blocked or notes:
                if blocked:
                    if o in ("LOSS", "LOSS(OPEN)"):
                        saved += abs(min(pnl, 0))
                        blocked_losses += 1
                    elif o == "WIN":
                        foregone += pnl
                        blocked_wins += 1
                shown = ", ".join(blocked + [("note: " + n) for n in notes])[:58]
                rep_rows.append([str(t.get("id") or "")[-8:], o, "%+.1f" % pnl, shown])
            if unknown:
                unknown_ev += 1
            detail.append({"id": str(t.get("id") or ""), "outcome": o,
                           "pnl_points": round(pnl, 1),
                           "archetype": arch, "guards_blocking": blocked,
                           "notes": notes, "missing_evidence_fields": unknown})
        if rep_rows:
            print_table(rep_rows, ["id", "outcome", "pnl", "guards that would block"])
            print("\n losers that WOULD be blocked : %d   (points saved ~ %.1f)"
                  % (blocked_losses, saved))
            print(" winners that would be blocked: %d   (points foregone ~ %.1f)  <- honesty check"
                  % (blocked_wins, foregone))
            print(" NET effect of the new guards : %+.1f pts   %s"
                  % (saved - foregone, "(positive = the guards pay for themselves)" if saved - foregone > 0 else "(negative = guards would have cost more than they save)"))
        else:
            print(" no trade in this day trips any guard.")
        if unknown_ev:
            print(" NOTE: %d trade(s) had missing snapshot evidence (counted conservatively)."
                  % unknown_ev)

        report["days"][str(day)] = {
            "trades": len(trades), "net_points": round(s["net"], 1),
            "wins": len(s["wins"]), "losses": len(s["losses"]),
            "profit_factor": (s["pf"] if s["pf"] != float("inf") else None),
            "guard_replay": {"blocked_losses": blocked_losses, "points_saved": round(saved, 1),
                             "blocked_winners": blocked_wins, "points_foregone": round(foregone, 1),
                             "net_effect": round(saved - foregone, 1)},
            "trades_detail": detail,
        }

    # consecutive-loss halt replay (across the window, chronological)
    print("\n" + "=" * 100)
    chrono = sorted([t for t in book if parse_ts(t.get("created_at"))],
                    key=lambda t: parse_ts(t.get("created_at")))
    streak, halt_events = 0, 0
    for t in chrono:
        o = outcome(t)
        if streak >= 3 and o in ("WIN", "LOSS", "BE"):
            halt_events += 1
        if o == "LOSS":
            streak += 1
        elif o in ("WIN", "BE"):
            streak = 0
    print(" CONSECUTIVE-LOSS HALT (3): %d entry(ies) in the window occurred while the halt was armed."
          % halt_events)
    print(" Book reads: %d trades (%d without a parseable timestamp were skipped)." % (len(book), unknown_day))
    print("=" * 100)

    report["halt_replay"] = {"entries_while_armed": halt_events,
                             "book_trades": len(book),
                             "skipped_no_timestamp": unknown_day}
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(report, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
        print("JSON report written: %s" % args.json_out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
