# -*- coding: utf-8 -*-
"""R25.5: the SEVEN execution paths' effectiveness report - from YOUR data.

Answers, from the live stores only (no guessing):
  1. PATHS      - per execution path (1-7): trades in the window, wins/losses,
                  average points. PATH 7 (SCALP) rows carry r25_scalp flags.
  2. GUARDS     - every decision_audit refusal by stage (r24 gate, r25 scalp,
                  planner, spread guard, ...) - how often each prevention law
                  actually fired. A law that never fires is not the bottleneck.
  3. PER SYMBOL - audit rows / orders / trades per enabled symbol with the TOP
                  refusal reasons - which pairs are starved and by which gate.

Usage (from the project root):
    python scripts\\paths_effectiveness_report.py                 (7 days)
    python scripts\\paths_effectiveness_report.py --days 14
Writes paths_effectiveness_report.txt next to the stores. Exit code 0 always.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services.execution_paths import PATH_DEFINITIONS, resolve_execution_path  # noqa: E402
from utils.helpers import load_trades  # noqa: E402


def _parse_ts(row: dict) -> float | None:
    for key in ("created_at", "opened_at", "closed_at", "ts"):
        raw = str(row.get(key) or "")
        if not raw:
            continue
        try:
            return datetime.fromisoformat(raw.replace("Z", "+00:00")).timestamp()
        except ValueError:
            continue
    return None


def _in_window(row: dict, since: float) -> bool:
    ts = _parse_ts(row)
    return True if ts is None else ts >= since


def _row_symbol(row: dict, default: str = "") -> str:
    return (str(row.get("symbol") or "")
            or str((row.get("signal_snapshot") or {}).get("symbol") or "")
            or default).upper()


def main() -> int:
    ap = argparse.ArgumentParser(description="7-path effectiveness report")
    ap.add_argument("--root", default=".",
                    help="project root containing storage/ (default: cwd)")
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--out", default="paths_effectiveness_report.txt")
    args = ap.parse_args()
    root = Path(args.root)
    storage = root / "storage"
    since = time.time() - args.days * 86400.0

    trades = load_trades(storage / "trades.json") or []
    audits = []
    audit_path = storage / "decision_audit.json"
    if audit_path.exists():
        try:
            audits = json.loads(audit_path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001 - a corrupt row set is still reportable
            audits = []
    audits = [a for a in audits if isinstance(a, dict)]
    aud_win = [a for a in audits if _in_window(a, since)]
    trd_win = [t for t in trades if _in_window(t, since)]

    lines: list[str] = []
    add = lines.append
    add("=" * 78)
    add(" SEVEN-PATH EFFECTIVENESS REPORT  (window = %d days, until %s)"
        % (args.days, datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")))
    add(" sources: storage/trades.json (%d rows, %d in window) | "
        "storage/decision_audit.json (%d rows, %d in window)"
        % (len(trades), len(trd_win), len(audits), len(aud_win)))
    add("=" * 78)

    # ── 1. the seven paths ────────────────────────────────────────────────
    add("")
    add("[1] THE SEVEN EXECUTION PATHS - actual trades in the window")
    add("-" * 78)
    by_path: dict[str, list] = defaultdict(list)
    for t in trd_win:
        resolved = resolve_execution_path(t)
        pid = str(resolved.get("id") or "UNKNOWN_EXECUTION_PATH")
        by_path[pid].append(t)
    for pid, definition in sorted(PATH_DEFINITIONS.items(),
                                  key=lambda kv: kv[1]["number"]):
        rows = by_path.get(pid, [])
        wins = sum(1 for r in rows
                   if str(r.get("result") or "").upper() in {"WIN", "TP2_HIT", "TP1_HIT"})
        losses = sum(1 for r in rows
                     if str(r.get("result") or "").upper() in {"LOSS", "SL_HIT"})
        add("  %-28s %-42s trades=%-4d win=%-3d loss=%-3d"
            % (pid, definition["name"], len(rows), wins, losses))
    un = by_path.get("UNKNOWN_EXECUTION_PATH", [])
    add("  %-28s %-42s trades=%d (legacy: pre-arm rows resolve to PATH 6, "
        "reinforcement rows to PATH 8)"
        % ("UNKNOWN_EXECUTION_PATH", "not recorded", len(un)))
    scalp = sum(1 for r in trd_win
                if ((r.get("signal_snapshot") or {}).get("setup_context") or {}).get("r25_scalp"))
    add("  PATH 7 note: r25_scalp-flagged rows in window: %d (went live %s)"
        % (scalp, "2026-08-28 - zero so far is EXPECTED" if scalp == 0 else ""))

    # ── 2. the prevention laws - who actually fired ───────────────────────
    add("")
    add("[2] PREVENTION LAWS - decision_audit refusals by stage (window)")
    add("-" * 78)
    stage_outcome: Counter = Counter()
    refusals: list[str] = []
    delivered = 0
    for a in aud_win:
        stage = str(a.get("stage") or "?")
        outcome = str(a.get("outcome") or "?").upper()
        stage_outcome["%s | %s" % (stage, outcome)] += 1
        if outcome in {"REFUSED", "BLOCKED", "CANCELLED"}:
            reason = " ".join(str(a.get("reason") or "").split())[:90]
            refusals.append("%-14s %s" % (stage, reason))
        if outcome in {"SENT", "QUEUED"}:
            delivered += 1
    for key, n in stage_outcome.most_common(20):
        add("  %-46s %d" % (key, n))
    add("  orders delivered/queued in window: %d" % delivered)
    add("  top refusal reasons (all stages):")
    for text, n in Counter(refusals).most_common(15):
        add("    %-4d %s" % (n, text))

    # ── 3. per symbol - who is starved and by what ────────────────────────
    add("")
    add("[3] PER SYMBOL - funnel in the window")
    add("-" * 78)
    per_symbol: dict[str, dict] = defaultdict(lambda: {"audits": 0, "refusals": 0,
                                                       "orders": 0, "trades": 0,
                                                       "reasons": Counter()})
    for a in aud_win:
        sym = _row_symbol(a)
        if not sym:
            continue
        cell = per_symbol[sym]
        cell["audits"] += 1
        outcome = str(a.get("outcome") or "").upper()
        if outcome in {"REFUSED", "BLOCKED", "CANCELLED"}:
            cell["refusals"] += 1
            cell["reasons"][" ".join(str(a.get("reason") or "").split())[:80]] += 1
        if outcome in {"SENT", "QUEUED"}:
            cell["orders"] += 1
    for t in trd_win:
        sym = _row_symbol(t)
        if sym:
            per_symbol[sym]["trades"] += 1
    for sym in sorted(per_symbol):
        cell = per_symbol[sym]
        add("  %-12s audits=%-6d refusals=%-6d orders=%-4d trades=%-3d"
            % (sym, cell["audits"], cell["refusals"], cell["orders"], cell["trades"]))
        for text, n in cell["reasons"].most_common(4):
            add("      %-4d %s" % (n, text))

    add("")
    add("(a symbol with zero audit rows was never cycled - a schedule issue;")
    add(" a symbol with refusals is killed by the named gate - read the reason).")
    out = root / args.out
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("wrote %s (%d lines)" % (out, len(lines)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
