"""
scripts/verify_redesign_readiness.py — ONE-SCRIPT readiness gate for the
proposed redesign (two paths + family blocks + auction as voter).

Four measurements, one GO/NO-GO table. READ-ONLY: nothing is changed,
live config is untouched, no decision is flipped.

  M1 AUCTION_PROMOTION   Auction-involved paths (4+5) vs baseline:
                         resolved>=8, hit>=50%, PF>=0.8x baseline PF.
  M2 MACRO_NEUTRALITY    Neutral macro fraction over recorded cycles.
                         GO when < 40% (macro must be able to confirm).
  M3 NEW_DESIGN_SURVIVAL Winners under the CURRENT admission replayed
                         through the NEW two-path gate. GO when >=70% of
                         winning signals survive.
  M4 AUCTION_VOTER_IMPACT Admission-rate change when auction_flow joins
                         the vote. GO when the rate stays <= 2x.

Sources (read-only):
  storage/agent_measurements/*.jsonl   books + macro + auction + SMC map
  canonical trade book (DB) + storage/path_performance/trades.json

Design constants live in one block (defaults = the agreed proposal) and can
be overridden via config["redesign_proposal"].

Usage:
  python scripts/verify_redesign_readiness.py               # last 7 days
  python scripts/verify_redesign_readiness.py --days 30
  python scripts/verify_redesign_readiness.py --root D:\\Nabil-gold --days 7
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# Console-encoding guard: Windows consoles are cp1252 — never crash on print.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

DEFAULTS: Dict[str, Any] = {
    "families": {
        "structure": ["smc", "classical"],
        "tape": ["price_action", "auction_flow"],
        "trend": ["technical", "multitimeframe"],
    },
    "family_weights": {"structure": 0.40, "tape": 0.35, "trend": 0.25},
    "agent_bar": 65.0,
    "net_floor": 65.0,
    "max_opponents": 1,
    "macro_confirm": 55.0,
    "auction_confirm": 65.0,
    "map_quality": 60.0,
    "map_return": 55.0,
    "map_dominance": 70.0,
    "map_trigger": 70.0,
    "survival_threshold_pct": 70.0,
    "macro_neutral_limit_pct": 40.0,
    "admission_ratio_limit": 2.0,
    "confirmer_mode": "auction_or_macro",  # "auction_or_macro" | "macro_only"
    "promotion": {"min_resolved": 8, "min_hit_pct": 50.0, "min_pf_ratio": 0.8},
}

OPEN_STATUSES = {"OPEN", "PARTIAL", "TP1_HIT", "PENDING"}
UNFILLED_STATUSES = {"CANCELLED", "EXPIRED"}


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


# ── proposal config ──────────────────────────────────────────────────────────
def _proposal(config: Dict[str, Any]) -> Dict[str, Any]:
    prop: Dict[str, Any] = json.loads(json.dumps(DEFAULTS))
    override = config.get("redesign_proposal") or {}
    if isinstance(override, dict):
        for key, value in override.items():
            if key in prop:
                if isinstance(prop[key], dict) and isinstance(value, dict):
                    prop[key].update(value)
                else:
                    prop[key] = value
    return prop


def _families(prop: Dict[str, Any]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for family, members in (prop.get("families") or {}).items():
        for member in members:
            out[str(member)] = str(family)
    return out


def _weights(prop: Dict[str, Any]) -> Dict[str, float]:
    fam = prop.get("families") or {}
    fw = prop.get("family_weights") or {}
    out: Dict[str, float] = {}
    for family, members in fam.items():
        w = _f(fw.get(family)) / max(len(members), 1)
        for member in members:
            out[str(member)] = w
    return out


# ── measurement rows (mirrors scripts/threshold_whatif.py, root-parametrized) ─
def _load_rows(root: Path, days: int) -> List[Dict[str, Any]]:
    base = root / "storage" / "agent_measurements"
    if not base.exists():
        return []
    rows: List[Dict[str, Any]] = []
    for path in sorted(base.glob("agent_system_*.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if isinstance(row, dict) and row.get("agents"):
                rows.append(row)

    def stamp(row: Dict[str, Any]) -> datetime:
        raw = str(row.get("generated_at") or "").replace("Z", "+00:00")
        try:
            return datetime.fromisoformat(raw).astimezone(timezone.utc)
        except ValueError:
            return datetime.fromtimestamp(0, tz=timezone.utc)

    rows.sort(key=stamp)
    for row in rows:
        row["_ts"] = stamp(row)
    if days > 0 and rows:
        cutoff = rows[-1]["_ts"] - timedelta(days=days)
        rows = [r for r in rows if r["_ts"] >= cutoff]
    return rows


def _forward_moves(rows: List[Dict[str, Any]]) -> None:
    horizons = {"1h": 1.0, "2h": 2.0, "4h": 4.0}
    for i, row in enumerate(rows):
        price = _f(row.get("current_price"))
        row["_fwd"] = {}
        if price <= 0:
            continue
        for label, hours in horizons.items():
            target = row["_ts"] + timedelta(hours=hours)
            for later in rows[i + 1:]:
                later_price = _f(later.get("current_price"))
                if later["_ts"] >= target and later_price > 0:
                    row["_fwd"][label] = later_price - price
                    break


def _book(row: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    details: Dict[str, Dict[str, Any]] = {}
    for name, info in (row.get("agents") or {}).items():
        if isinstance(info, dict):
            details[name] = {
                "direction": str(info.get("direction") or "WAIT").upper(),
                "confidence": _f(info.get("confidence")),
            }
    return details


def _macro_side(row: Dict[str, Any]) -> Tuple[str, float]:
    macro = row.get("macro") or {}
    bias = str(macro.get("bias") or "").upper()
    side = {"BULLISH_GOLD": "BUY", "BEARISH_GOLD": "SELL"}.get(bias, "WAIT")
    return side, _f(macro.get("confidence"))


# ── NEW two-path admission (the design under test) ──────────────────────────
def new_path_a(
    row: Dict[str, Any], side: str, prop: Dict[str, Any], auction_voter: bool,
    confirmer_mode: str = "auction_or_macro",
) -> Tuple[bool, Dict[str, Any]]:
    """>=2 qualified supporters from >=2 families + external confirmation.

    confirmer_mode:
      "macro_only"       -> macro is the ONLY allowed confirmer (design v1;
                            measured NO-GO on the VPS: macro neutral 93.5%)
      "auction_or_macro" -> auction confirms mixed-family books (Rule B is
                            structurally satisfied: an all-trend book is a
                            single family and never reaches this gate),
                            macro remains an alternative. Design v2.
    """
    book = _book(row)
    fam = _families(prop)
    wts = _weights(prop)
    bar = _f(prop.get("agent_bar"), 65.0)
    floor = _f(prop.get("net_floor"), 65.0)
    max_opp = int(prop.get("max_opponents", 1) or 1)

    voters = ["technical", "multitimeframe", "classical", "smc", "price_action"]
    if auction_voter:
        voters.append("auction_flow")

    supporters: List[str] = []
    sup_score = 0.0
    sup_weight = 0.0
    sup_conf_sum = 0.0
    opponents = 0
    opp_score = 0.0
    for name in voters:
        info = book.get(name)
        if not isinstance(info, dict):
            continue
        direction = info["direction"]
        confidence = _f(info["confidence"])
        if confidence < bar or direction not in {"BUY", "SELL"}:
            continue
        weight = wts.get(name, 0.0)
        score = confidence / 100.0 * weight
        if direction == side:
            supporters.append(name)
            sup_score += score
            sup_weight += weight
            sup_conf_sum += confidence * weight
        else:
            opponents += 1
            opp_score += score

    if len(supporters) < 2:
        return False, {"why": "supporters<2"}
    seen_families = {fam.get(n, "unknown") for n in supporters}
    if len(seen_families) < 2:
        return False, {"why": "single_family", "families": sorted(seen_families)}
    if opponents > max_opp:
        return False, {"why": f"opponents={opponents}>{max_opp}"}
    net = (sup_conf_sum / sup_weight if sup_weight else 0.0) - min(
        30.0, (opp_score / sup_score * 30.0) if sup_score > 0 else 0.0
    )
    if net < floor:
        return False, {"why": f"net={net:.1f}<{floor:.0f}"}

    macro_side, macro_conf = _macro_side(row)
    macro_ok = macro_side == side and macro_conf >= _f(prop.get("macro_confirm"), 55.0)
    if confirmer_mode == "macro_only":
        if not macro_ok:
            return False, {"why": f"macro_confirmer(macro={macro_side}/{macro_conf:.0f})"}
        confirmer = "macro"
    else:
        # auction may confirm ONLY when it is NOT part of the voting book.
        # Mirrors the production guard in thesis_consensus
        # (path5_disabled_auction_is_voter): one read must never count twice.
        auction = book.get("auction_flow") or {}
        auction_ok = (
            not auction_voter
            and str(auction.get("direction") or "WAIT").upper() == side
            and _f(auction.get("confidence")) >= _f(prop.get("auction_confirm"), 65.0)
        )
        if not (macro_ok or auction_ok):
            return False, {
                "why": f"no_confirmer(macro={macro_side}/{macro_conf:.0f}, "
                       f"auction={auction.get('direction')}/{_f(auction.get('confidence')):.0f}, "
                       f"auction_is_voter={auction_voter})"
            }
        confirmer = "macro" if macro_ok else "auction"
    return True, {
        "why": "ok",
        "supporters": supporters,
        "families": sorted(seen_families),
        "net": round(net, 1),
        "confirmer": confirmer,
    }


def new_path_b(row: Dict[str, Any], side: str, prop: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
    """Qualified SMC map + auction confirmation (limit-only route)."""
    smc = row.get("smc_measurement") or {}
    setup_direction = str(smc.get("setup_direction") or smc.get("setup_type_direction") or "WAIT").upper()
    # fall back to map side when setup_direction is absent
    if setup_direction in {"", "NONE", "WAIT"}:
        map_info = row.get("map") or {}
        setup_direction = str(map_info.get("side") or "WAIT").upper()
    if setup_direction != side:
        return False, {"why": f"map_side={setup_direction}"}
    checks = {
        "dominance": (_f(smc.get("dominance")), _f(prop.get("map_dominance"), 70.0)),
        "return": (_f(smc.get("return_probability")), _f(prop.get("map_return"), 55.0)),
        "quality": (_f(smc.get("quality")), _f(prop.get("map_quality"), 60.0)),
        "trigger": (_f(smc.get("trigger_score")), _f(prop.get("map_trigger"), 70.0)),
    }
    for key, (value, floor) in checks.items():
        if value < floor:
            return False, {"why": f"{key}={value:.1f}<{floor:.0f}"}
    book = _book(row)
    auction = book.get("auction_flow") or {}
    auction_conf = _f(auction.get("confidence"))
    auction_dir = str(auction.get("direction") or "WAIT").upper()
    need = _f(prop.get("auction_confirm"), 65.0)
    if auction_dir != side or auction_conf < need:
        return False, {"why": f"auction={auction_dir}/{auction_conf:.0f}<{need:.0f}"}
    return True, {"why": "ok"}


def new_design_allows(
    row: Dict[str, Any], prop: Dict[str, Any], auction_voter: bool,
    confirmer_mode: str = "auction_or_macro",
) -> List[str]:
    sides = []
    for side in ("BUY", "SELL"):
        a_ok, _ = new_path_a(row, side, prop, auction_voter, confirmer_mode=confirmer_mode)
        b_ok, _ = new_path_b(row, side, prop)
        if a_ok or b_ok:
            sides.append(side)
    return sides


def current_allows(row: Dict[str, Any]) -> List[str]:
    admission = row.get("admission") or {}
    return [side for side in ("BUY", "SELL")
            if isinstance(admission.get(side), dict) and admission.get(side).get("allow")]


def _direction_adjusted(side: str, move: float) -> float:
    return move if side == "BUY" else -move


# ── M1: auction promotion from resolved trades (canonical book first) ──────
def _merged_trade_rows(root: Path, config: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Canonical trade book (DB) merged with the local path ledger, exactly
    like scripts/summarize_execution_paths.py::_combined_rows. Returns [] on
    any failure (M1 then reports the data gap honestly)."""
    rows: List[Dict[str, Any]] = []
    path_file = root / "storage" / "path_performance" / "trades.json"
    if path_file.exists():
        try:
            raw = json.loads(path_file.read_text(encoding="utf-8"))
            if isinstance(raw, list):
                rows.extend(r for r in raw if isinstance(r, dict))
            elif isinstance(raw, dict) and isinstance(raw.get("trades"), list):
                rows.extend(r for r in raw["trades"] if isinstance(r, dict))
        except Exception:  # noqa: BLE001
            pass
    try:
        from scripts.summarize_execution_paths import _combined_rows  # noqa: PLC0415

        rows.extend(r for r in (_combined_rows(config or {}) or []) if isinstance(r, dict))
    except Exception:  # noqa: BLE001
        pass
    by_id: Dict[str, Dict[str, Any]] = {}
    loose: List[Dict[str, Any]] = []
    for row in rows:
        tid = str(row.get("id") or row.get("trade_id") or "")
        if not tid:
            loose.append(row)  # rows without ids are kept as-is
            continue
        existing = by_id.get(tid, {})
        existing.update(row)
        by_id[tid] = existing
    return list(by_id.values()) + loose


def auction_promotion_metrics(
    root: Path, prop: Dict[str, Any], config: Optional[Dict[str, Any]] = None,
    rows: Optional[List[Dict[str, Any]]] = None,
) -> Optional[Dict[str, Any]]:
    """rows= injection isolates tests from the live local trade book."""
    if rows is None:
        rows = _merged_trade_rows(root, config)
    else:
        rows = [dict(r) for r in rows if isinstance(r, dict)]
    if not rows:
        return {"auction_paths": {"resolved": 0, "hit_pct": None, "profit_factor": None},
                "baseline": {"resolved": 0, "hit_pct": None, "profit_factor": None},
                "criteria": prop.get("promotion") or {},
                "verdict": "NO-GO",
                "detail": "no resolved trades in canonical book + path ledger (run summarize_execution_paths to verify)"}
    try:
        from services.execution_paths import PATH_4, PATH_5
        from services.path_performance import compact_trade_snapshot
    except Exception:  # noqa: BLE001
        return None

    def pnl_of(row: Dict[str, Any]) -> Optional[float]:
        for key in ("final_pnl", "pnl_points", "current_pnl_points", "current_pnl", "pnl"):
            v = row.get(key)
            if isinstance(v, (int, float)):
                return float(v)
        return None

    def resolved(row: Dict[str, Any]) -> bool:
        status = str(row.get("status") or "").upper()
        if status in OPEN_STATUSES:
            return False
        if status in UNFILLED_STATUSES and not row.get("mt5_ticket"):
            return False
        return pnl_of(row) is not None

    auction_rows: List[Dict[str, Any]] = []
    all_rows: List[Dict[str, Any]] = []
    for raw in rows:
        try:
            row = compact_trade_snapshot(raw)
        except Exception:  # noqa: BLE001
            row = raw
        if not isinstance(row, dict) or not resolved(row):
            continue
        all_rows.append(row)
        path_id = str(row.get("execution_path_id") or row.get("admission_path") or "")
        if path_id in {PATH_4, PATH_5}:
            auction_rows.append(row)

    def stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        pnls = [pnl_of(r) for r in rows if pnl_of(r) is not None]
        wins = sum(p > 0 for p in pnls)
        gross_win = sum(p for p in pnls if p > 0)
        gross_loss = abs(sum(p for p in pnls if p < 0))
        return {
            "resolved": len(pnls),
            "hit_pct": round(wins / len(pnls) * 100.0, 1) if pnls else None,
            "profit_factor": round(gross_win / gross_loss, 2) if gross_loss > 0 else (None if gross_win == 0 else "INF"),
        }

    prom = prop.get("promotion") or {}
    a = stats(auction_rows)
    b = stats(all_rows)
    min_resolved = int(prom.get("min_resolved", 8) or 8)
    min_hit = _f(prom.get("min_hit_pct"), 50.0)
    min_ratio = _f(prom.get("min_pf_ratio"), 0.8)

    if (a["resolved"] or 0) < min_resolved:
        verdict, detail = "NO-GO", f"resolved {a['resolved']}/{min_resolved} (insufficient sample)"
    elif (a["hit_pct"] or 0.0) < min_hit:
        verdict, detail = "NO-GO", f"hit {a['hit_pct']}% < {min_hit:.0f}%"
    elif isinstance(a["profit_factor"], (int, float)) and isinstance(b["profit_factor"], (int, float)) \
            and b["profit_factor"] > 0 and a["profit_factor"] < min_ratio * b["profit_factor"]:
        verdict, detail = "NO-GO", f"PF {a['profit_factor']} < {min_ratio}x baseline {b['profit_factor']}"
    elif a["profit_factor"] is None and b["profit_factor"] is None:
        verdict, detail = "NO-GO", "no profitable PF on either side"
    else:
        verdict, detail = "GO", "criteria met"
    return {
        "auction_paths": a, "baseline": b,
        "criteria": {"min_resolved": min_resolved, "min_hit_pct": min_hit, "min_pf_ratio": min_ratio},
        "verdict": verdict, "detail": detail,
    }


# ── M2: macro neutrality ────────────────────────────────────────────────────
def macro_neutral_fraction(rows: List[Dict[str, Any]], prop: Dict[str, Any]) -> Dict[str, Any]:
    total = 0
    neutral = 0
    for row in rows:
        macro = row.get("macro") or {}
        if not isinstance(macro, dict) or not macro.get("bias"):
            total += 1
            neutral += 1
            continue
        side, conf = _macro_side(row)
        if side == "WAIT" or conf < _f(prop.get("macro_confirm"), 55.0):
            neutral += 1
        total += 1
    fraction = neutral / total * 100.0 if total else 0.0
    limit = _f(prop.get("macro_neutral_limit_pct"), 40.0)
    verdict = "GO" if total and fraction < limit else ("N/A" if not total else "NO-GO")
    detail = f"neutral {fraction:.1f}% of {total} cycles (limit {limit:.0f}%)"
    return {"total_cycles": total, "neutral_pct": round(fraction, 1),
            "verdict": verdict, "detail": detail}


# ── M3 + M4: replay survival and auction-voter impact (both confirmer modes) ─
def _mode_stats(
    rows: List[Dict[str, Any]], prop: Dict[str, Any], auction_voter: bool,
    confirmer_mode: str, horizon: str = "2h",
) -> Tuple[int, int, int]:
    admits = 0
    scored = 0
    hits = 0
    for row in rows:
        sides = new_design_allows(row, prop, auction_voter, confirmer_mode)
        if sides:
            admits += 1
        fwd = row.get("_fwd", {}).get(horizon)
        if fwd is None:
            continue
        for side in sides:
            scored += 1
            if _direction_adjusted(side, fwd) > 0:
                hits += 1
    return admits, scored, hits


def replay_metrics(rows: List[Dict[str, Any]], prop: Dict[str, Any]) -> Dict[str, Any]:
    default_mode = str(prop.get("confirmer_mode") or "auction_or_macro")
    horizon = "2h"
    current_admits = 0
    current_scored = 0
    current_hits = 0
    for row in rows:
        cur = current_allows(row)
        if cur:
            current_admits += 1
        fwd = row.get("_fwd", {}).get(horizon)
        if fwd is None:
            continue
        for side in cur:
            current_scored += 1
            if _direction_adjusted(side, fwd) > 0:
                current_hits += 1

    # winners under the CURRENT design (the population to keep alive)
    kept = {"macro_only": 0, "auction_or_macro": 0}
    for row in rows:
        cur = current_allows(row)
        fwd = row.get("_fwd", {}).get(horizon)
        if fwd is None:
            continue
        for side in cur:
            if _direction_adjusted(side, fwd) > 0:
                for mode in kept:
                    if side in new_design_allows(row, prop, False, mode):
                        kept[mode] += 1

    threshold = _f(prop.get("survival_threshold_pct"), 70.0)

    def survival(kept_count: int) -> Tuple[Optional[float], str, str]:
        if current_hits:
            pct = kept_count / current_hits * 100.0
            verdict = "GO" if pct >= threshold else "NO-GO"
            return round(pct, 1), verdict, (
                f"kept {kept_count}/{current_hits} winning signals "
                f"({pct:.0f}%, need >= {threshold:.0f}%)"
            )
        return None, "N/A", "no winning signals scored in window"

    def mode_block(mode: str) -> Dict[str, Any]:
        admits, scored, hits = _mode_stats(rows, prop, True, mode, horizon)
        no_admits, no_scored, no_hits = _mode_stats(rows, prop, False, mode, horizon)
        pct, verdict, detail = survival(kept[mode])
        return {
            "admits": admits,
            "admits_without_auction_voter": no_admits,
            "hit_pct": round(hits / scored * 100.0, 1) if scored else None,
            "hit_no_voter_pct": round(no_hits / no_scored * 100.0, 1) if no_scored else None,
            "survival_pct": pct,
            "survival_verdict": verdict,
            "survival_detail": detail,
        }

    macro_block = mode_block("macro_only")
    default_block = mode_block(default_mode)

    # M4: admission impact of the auction voter under the DEFAULT mode
    ratio_limit = _f(prop.get("admission_ratio_limit"), 2.0)
    if default_block["admits_without_auction_voter"] and default_block["admits"]:
        ratio = default_block["admits"] / default_block["admits_without_auction_voter"]
        ratio_verdict = "GO" if ratio <= ratio_limit else "NO-GO"
        ratio_detail = (
            f"admissions {default_block['admits_without_auction_voter']} -> "
            f"{default_block['admits']} with voter (x{ratio:.2f}, limit x{ratio_limit:.1f})"
        )
    else:
        ratio, ratio_verdict, ratio_detail = None, "N/A", "insufficient admission data"

    return {
        "confirmer_mode": default_mode,
        "current_admits": current_admits,
        "current_hit_pct": round(current_hits / current_scored * 100.0, 1) if current_scored else None,
        "current_winners": current_hits,
        "macro_only": macro_block,
        "auction_or_macro": default_block,
        "ratio": round(ratio, 2) if ratio is not None else None,
        "ratio_verdict": ratio_verdict,
        "ratio_detail": ratio_detail,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Redesign readiness gate (4 measurements)")
    parser.add_argument("--days", type=int, default=7)
    parser.add_argument("--root", type=str, default=str(ROOT))
    parser.add_argument("--out", type=str, default="")
    args = parser.parse_args()
    root = Path(args.root)

    from utils.helpers import load_config

    try:
        config = load_config()
    except Exception:  # noqa: BLE001
        config = {}
    prop = _proposal(config)

    rows = _load_rows(root, args.days)
    _forward_moves(rows)
    m1 = auction_promotion_metrics(root, prop, config)
    m2 = macro_neutral_fraction(rows, prop)
    m3m4 = replay_metrics(rows, prop)

    lines = [
        "=" * 74,
        f"REDESIGN READINESS CHECK - {datetime.now(timezone.utc):%Y-%m-%d %H:%M} UTC",
        f"window: {args.days} days | measurement rows: {len(rows)}",
        "=" * 74,
        "",
        "M1 AUCTION_PROMOTION (paths 4+5 vs baseline)",
    ]
    if m1 is None:
        lines.append("  N/A - storage/path_performance/trades.json not found")
    else:
        a, b = m1["auction_paths"], m1["baseline"]
        lines.append(f"  auction paths: resolved={a['resolved']} hit={a['hit_pct']}% PF={a['profit_factor']}")
        lines.append(f"  baseline     : resolved={b['resolved']} hit={b['hit_pct']}% PF={b['profit_factor']}")
        lines.append(f"  {m1['verdict']}: {m1['detail']}")
    lines += [
        "",
        "M2 MACRO_NEUTRALITY",
        f"  {m2['verdict']}: {m2['detail']}",
        "",
        "M3 NEW_DESIGN_SURVIVAL (winner population under the CURRENT design)",
        f"  current: admits={m3m4['current_admits']} winners={m3m4['current_winners']} hit(2h)={m3m4['current_hit_pct']}%",
        f"  A confirmer=macro_only      : {m3m4['macro_only']['survival_verdict']} {m3m4['macro_only']['survival_detail']}",
        f"                              admits={m3m4['macro_only']['admits']} hit(2h)={m3m4['macro_only']['hit_pct']}%",
        f"  A confirmer=auction_or_macro: {m3m4['auction_or_macro']['survival_verdict']} {m3m4['auction_or_macro']['survival_detail']}",
        f"                              admits={m3m4['auction_or_macro']['admits']} hit(2h)={m3m4['auction_or_macro']['hit_pct']}%",
        "",
        "M4 AUCTION_VOTER_IMPACT (default confirmer mode)",
        f"  {m3m4['ratio_verdict']}: {m3m4['ratio_detail']}",
        f"  hit rate with voter={m3m4['auction_or_macro']['hit_pct']}% without={m3m4['auction_or_macro']['hit_no_voter_pct']}%",
        "",
    ]

    verdicts = [m2["verdict"], m3m4["auction_or_macro"]["survival_verdict"], m3m4["ratio_verdict"]]
    if m1 is not None:
        verdicts.append(m1["verdict"])
    if any(v == "NO-GO" for v in verdicts):
        overall = "BLOCKED (NO-GO on: " + ", ".join(sorted({k for k, v in
                   {"M1": m1["verdict"] if m1 else "N/A", "M2": m2["verdict"],
                    "M3": m3m4["auction_or_macro"]["survival_verdict"], "M4": m3m4["ratio_verdict"]}.items() if v == "NO-GO"})) + ")"
    elif all(v in {"GO", "N/A"} for v in verdicts) and "GO" in verdicts:
        overall = "GO"
    else:
        overall = "NEEDS DATA (no GO/NO-GO signal yet - let cycles accumulate)"
    lines += ["-" * 74, f"OVERALL: {overall}", "=" * 74]
    text = "\n".join(lines)
    print(text)

    out = Path(args.out) if args.out else root / "diagnostics" / \
        f"redesign_readiness_{datetime.now(timezone.utc):%Y-%m-%d}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "window_days": args.days,
        "rows": len(rows),
        "m1_auction_promotion": m1,
        "m2_macro_neutrality": m2,
        "m3m4_replay": m3m4,
        "overall": overall,
        "proposal": prop,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nJSON: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
