#!/usr/bin/env python3
"""Analysis-gate probe (BUILD 31 R17). One-shot, read-only, no orders.

Replays the analysis entry gates (scripts/run_analysis.py) for one or more
symbols IN ORDER, using the SAME code, and names the exact gate that stops
each symbol - or confirms it would pass into the agents:

  gate DATA_NONE        get_gold_data() returned no payload
  gate SOURCE_RELIABLE  _payload_supports_signal_generation() is False
  gate PRICE_SANITY     current price outside utils price_sanity_range
  PASS                  all entry gates clear -> cycles reach the agents

Usage:
    python scripts\\probe_analysis_gate.py
    python scripts\\probe_analysis_gate.py --symbols EUR/USD,GBP/USD

Exit code 0 always (a report tool, not a gate).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

try:
    sys.stdout.reconfigure(errors="replace")
except (AttributeError, ValueError):
    pass


def evaluate_payload(symbol: str, payload, price_sanity, supports_signal):
    """Pure gate evaluation over an already-fetched payload (testable).

    Returns (gate_name_or_PASS, detail_dict).
    """
    detail = {"symbol": symbol}
    if not payload:
        return "DATA_NONE", detail
    integrity = payload.get("source_integrity") or {}
    detail.update({
        "source": payload.get("source") or integrity.get("source") or "unknown",
        "grade": integrity.get("reliability_grade") or integrity.get("grade") or "UNKNOWN",
        "supports_signal_generation": bool(supports_signal),
        "current_price": payload.get("current_price"),
        "tf_candles": {tf: (len(v.get("data") or []) if isinstance(v, dict) else len(v or []))
                       for tf, v in (payload.get("timeframes") or {}).items()},
    })
    if not supports_signal:
        return "SOURCE_RELIABLE", detail
    price = float(payload.get("current_price") or 0)
    lo, hi = price_sanity
    detail["sanity_range"] = [lo, hi]
    if price > 0 and (price < lo or price > hi):
        return "PRICE_SANITY", detail
    return "PASS", detail


def probe_symbol(root: Path, symbol: str):
    from copy import deepcopy

    from utils.helpers import load_config
    from utils.instruments import config_for_instrument, price_sanity_range
    from services.market_data import MarketDataService
    from scripts.run_analysis import _payload_supports_signal_generation

    base = load_config() if (root / "config.json").exists() else {}
    if not base and not (root / "config.json").exists():
        return {"symbol": symbol, "gate": "CONFIG_MISSING",
                "detail": "config.json not found"}
    base = json.loads((root / "config.json").read_text(encoding="utf-8")) \
        if (root / "config.json").exists() else base
    cfg = config_for_instrument(deepcopy(base), {"symbol": symbol})
    mds = MarketDataService(cfg)
    payload = mds.get_gold_data()
    supports = bool(_payload_supports_signal_generation(payload))
    gate, detail = evaluate_payload(symbol, payload,
                                    price_sanity_range(symbol, base), supports)
    detail["symbol"] = symbol
    detail["gate"] = gate
    if gate == "PASS":
        detail["verdict"] = ("entry gates CLEAR - cycles reach the agents; "
                             "audit rows should appear within ~2 cycles")
    else:
        detail["verdict"] = ("every cycle EXITS at this gate with a telegram "
                             "outage card and NO audit row (the funnel silence)")
    return detail


def main():
    ap = argparse.ArgumentParser(description="Analysis entry-gate probe")
    ap.add_argument("--root", default=str(ROOT))
    ap.add_argument("--symbols", default=None,
                    help="comma list (default: all enabled instruments)")
    args = ap.parse_args()
    root = Path(args.root)

    if args.symbols:
        symbols = [x.strip() for x in args.symbols.split(",") if x.strip()]
    else:
        cfg_path = root / "config.json"
        symbols = []
        if cfg_path.exists():
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
            symbols = [str(i.get("symbol")) for i in (cfg.get("instruments") or [])
                       if isinstance(i, dict) and i.get("enabled", True)]

    print("=" * 100)
    print(" ANALYSIS ENTRY-GATE PROBE  (names the gate that silences a symbol)")
    print("=" * 100)
    for symbol in symbols:
        try:
            r = probe_symbol(root, symbol)
        except Exception as exc:  # noqa: BLE001 - a probe must never die
            r = {"symbol": symbol, "gate": "PROBE_EXCEPTION", "detail": repr(exc)}
        print("\n %-8s -> GATE: %s" % (symbol, r.get("gate")))
        for key in ("source", "grade", "current_price", "sanity_range",
                    "supports_signal_generation", "tf_candles", "verdict", "detail"):
            if key in r:
                print("    %-26s: %s" % (key, r[key]))
    print("\n" + "=" * 100)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
