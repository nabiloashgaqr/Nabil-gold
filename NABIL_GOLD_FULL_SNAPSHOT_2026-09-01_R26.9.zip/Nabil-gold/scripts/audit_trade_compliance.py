# -*- coding: utf-8 -*-
"""Audit EVERY entered trade for full rule compliance (R26.3).

Run from C:\\Nabil-gold:
    python scripts\\audit_trade_compliance.py
    python scripts\\audit_trade_compliance.py --limit 0     # all
    python scripts\\audit_trade_compliance.py --symbol XAU/USD

It replays each ENTERED trade (status OPEN/CLOSED - skipped CANCELLED/PENDING
that never filled) through the same post-decision auditor used live, using the
stored signal_snapshot/agent_details. It prints an Arabic report grouped by
issue and writes diagnostics/trade_compliance_<timestamp>.json.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from utils.helpers import load_config  # noqa: E402
from services.post_decision_auditor import audit_decision  # noqa: E402

ENTERED_STATUSES = {"OPEN", "CLOSED", "WIN", "LOSS", "MANUAL_CLOSE",
                    "THESIS_EXIT", "SL_HIT", "TP_HIT", "BREAKEVEN"}
SKIP_STATUSES = {"CANCELLED", "PENDING", "REFUSED", "REJECTED"}


def _trade_trade(record: dict) -> dict:
    """Reconstruct a decision-shaped dict from a stored ledger row."""
    snap = record.get("signal_snapshot") if isinstance(record.get("signal_snapshot"), dict) else {}
    decision = dict(snap) if snap else {}
    decision.setdefault("symbol", record.get("symbol"))
    decision.setdefault("decision", (record.get("type") or record.get("side") or "").upper())
    sig = decision.get("signal") if isinstance(decision.get("signal"), dict) else {}
    if not sig:
        sig = {"stop_loss": record.get("stop_loss"),
               "tp1": record.get("tp1"), "tp2": record.get("tp2"),
               "entry": {"price": record.get("entry_price") or record.get("entry")}}
        decision["signal"] = sig
    decision.setdefault("execution_path_id",
                        record.get("execution_path_id") or snap.get("execution_path_id"))
    decision.setdefault("trade_id", record.get("id") or record.get("trade_id"))
    return decision


def _book(record: dict) -> dict:
    snap = record.get("signal_snapshot") if isinstance(record.get("signal_snapshot"), dict) else {}
    for src in (snap.get("agent_details"), record.get("agent_details"),
                snap.get("all_results"), snap.get("results")):
        if isinstance(src, dict) and src:
            return src
    return {}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=60, help="rows to review (0 = all)")
    ap.add_argument("--symbol", default="")
    ap.add_argument("--config", default=os.path.join(ROOT, "config.json"))
    ap.add_argument("--since", default="",
                    help="baseline ISO datetime; trades before it are LEGACY "
                         "(expected pre-fix) and separated from live issues. "
                         "Default: config r26_3_audit.baseline_iso.")
    args = ap.parse_args()

    config = load_config(args.config) if os.path.exists(args.config) else {}
    baseline = args.since or str(
        (config.get("r26_3_audit") or {}).get("baseline_iso") or "")

    trades_path = os.path.join(ROOT, "storage", "trades.json")
    if not os.path.exists(trades_path):
        print("storage/trades.json not found at", trades_path)
        return 2
    rows = json.load(open(trades_path, encoding="utf-8"))
    if isinstance(rows, dict):
        rows = rows.get("trades") or rows.get("rows") or []
    rows = [r for r in rows if isinstance(r, dict)]
    if args.symbol:
        rows = [r for r in rows if str(r.get("symbol")) == args.symbol]
    # most recent first, then optional limit
    rows.sort(key=lambda r: str(r.get("opened_at") or r.get("created_at") or ""), reverse=True)
    if args.limit:
        rows = rows[: args.limit]

    entered, reviewed = [], 0
    for r in rows:
        st = str(r.get("status") or "").upper()
        if st in SKIP_STATUSES:
            continue
        entered.append(r)

    def _row_ts(r: dict) -> str:
        return str(r.get("opened_at") or r.get("open_time") or r.get("created_at") or "")

    def _is_live(r: dict) -> bool:
        ts = _row_ts(r)
        if not baseline:
            return True
        if not ts:
            return True
        return ts[:16] >= baseline[:16]

    report = []
    code_counts: dict = {}
    legacy_counts: dict = {}
    problem_rows = legacy_problems = 0
    for r in entered:
        decision = _trade_trade(r)
        book = _book(r)
        verdict = audit_decision(decision, config, book, None)
        reviewed += 1
        warns = [f for f in verdict.get("findings", []) if f["severity"] == "WARN"]
        infos = [f for f in verdict.get("findings", []) if f["severity"] == "INFO"]
        live = _is_live(r)
        if warns and live:
            problem_rows += 1
            for f in warns:
                code_counts[f["code"]] = code_counts.get(f["code"], 0) + 1
        elif warns:
            legacy_problems += 1
            for f in warns:
                legacy_counts[f["code"]] = legacy_counts.get(f["code"], 0) + 1
        report.append({
            "id": r.get("id") or r.get("trade_id"),
            "symbol": r.get("symbol"), "side": r.get("type") or r.get("side"),
            "status": r.get("status"), "path": decision.get("execution_path_id"),
            "opened": _row_ts(r), "live": live,
            "warnings": warns, "info": infos,
        })

    # ---- Arabic console report ----
    print("=" * 70)
    print("  تدقيق امتثال الصفقات الداخلة (R26.3)")
    print("  الجذر:", ROOT)
    print("  فاصل الإصلاح (baseline):", baseline or "(غير مضبوط — كل الصفقات تُعدّ حية)")
    print("  صفقات دُقّقت:", reviewed, "| تحذيرات حية:", problem_rows,
          "| تحذيرات إرث (قبل baseline):", legacy_problems)
    print("=" * 70)
    if code_counts:
        print("\nملخّص التحذيرات الحية (بعد baseline — تحتاج متابعة):")
        for code, n in sorted(code_counts.items(), key=lambda kv: -kv[1]):
            print(f"   {n:3d}  {code}")
    else:
        print("\n✅ لا تحذيرات حية بعد baseline.")
    if legacy_counts:
        print("\n(إرث ما قبل الإصلاح — متوقَّع ولا يحتاج إجراء: "
              + ", ".join(f"{c}×{n}" for c, n in
                          sorted(legacy_counts.items(), key=lambda kv: -kv[1])) + ")")
    print("\nتفاصيل الصفقات الحية ذات التحذيرات:")
    any_w = False
    for row in report:
        if not row["warnings"] or not row["live"]:
            continue
        any_w = True
        print(f"\n• {row['symbol']} {row['side']} [{row['status']}] {row['path'] or ''}")
        print(f"  id={row['id']}  opened={row['opened']}")
        for f in row["warnings"]:
            print(f"   ⚠️  [{f['code']}] {f['msg']}")
    if not any_w:
        print("\n  ✅ لا صفقات حية فيها تحذير.")

    if legacy_problems and not any_w:
        print(f"\n  (توجد {legacy_problems} صفقة إرثية بتحذيرات قبل baseline — "
              "مُفصَّلة في تقرير JSON حقل live=false.)")

    # remaining legacy detail lines to JSON only
    any_legacy = False
    for row in report:
        if not row["warnings"] or row["live"]:
            continue
        any_legacy = True
    if any_legacy:
        print("\nتفاصيل إرثية (قبل baseline) في تقرير JSON فقط.")

    os.makedirs(os.path.join(ROOT, "diagnostics"), exist_ok=True)
    out = os.path.join(ROOT, "diagnostics",
                       f"trade_compliance_{time.strftime('%Y%m%d_%H%M%S')}.json")
    json.dump({"generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
               "baseline": baseline,
               "reviewed": reviewed, "live_problems": problem_rows,
               "legacy_problems": legacy_problems,
               "live_code_counts": code_counts, "legacy_code_counts": legacy_counts,
               "rows": report},
              open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print("\nالتقرير الكامل حُفظ في:", out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
