"""
scripts/fill_oil_macro.py — auto-fill the oil macro operator files from the
free EIA API (2026-08-19 build 10, operator order: "fill the oil macro so it
works").

Requires a FREE API key from https://www.eia.gov/opendata/ (register, then
set EIA_API_KEY in .env or oil_macro.eia_api_key in config.json).

Fetches the weekly petroleum status (crude/gasoline/distillate stocks and
refinery utilization), writes storage/oil/eia_weekly.json and appends the
seasonal history to storage/oil/eia_history.json. Without a key the script
exits with a clear message - the agent still works via the automatic
crack-spread layer.

Usage:
  python scripts/fill_oil_macro.py            # fill now
  python scripts/fill_oil_macro.py --check    # dry-run: print, do not write
  python scripts/fill_oil_macro.py --root D:\\Nabil-gold
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# BUILD 21.1 (2026-08-20): the .env file holds EIA_API_KEY like every other
# script in the system; without this bootstrap the key had to be set as a
# machine-wide env var or pasted into config.json.
try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv()
except Exception:  # noqa: BLE001
    pass

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

SERIES = {
    # API v2 takes the BARE series name via facets[series][] (the route
    # already implies PET + weekly). The v1-style "PET.XXXX.W" ids returned
    # an EMPTY dataset for every series on 2026-08-20 (valid key, HTTP 200).
    # The second candidate is kept as a fallback for older dataset shapes.
    "crude": ["WCRSTUS1", "PET.WCRSTUS1.W"],
    "gasoline": ["WGTSTUS1", "PET.WGTSTUS1.W"],
    "distillate": ["WDISTUS1", "PET.WDISTUS1.W"],
    "utilization": ["WPULEUS3", "PET.WPULEUS3.W"],
}

PRIMARY_IDS = [ids[0] for ids in SERIES.values()]


def _change(data: List[Any]) -> Optional[float]:
    """latest - previous week, thousand barrels -> mb."""
    if len(data) < 2:
        return None
    v0 = _row_value(data[0])
    v1 = _row_value(data[1])
    if v0 is None or v1 is None:
        return None
    return round((v0 - v1) / 1000.0, 1)


def _row_period(row: Any) -> str:
    if isinstance(row, dict):
        return str(row.get("period") or "")
    if isinstance(row, (list, tuple)) and len(row) >= 1:
        return str(row[0])
    return ""


def _row_value(row: Any) -> Optional[float]:
    """A data point's value from either row shape the API actually returns:
    v2 dict rows (period/value keys) or legacy [period, value] lists."""
    try:
        if isinstance(row, dict):
            v = row.get("value")
            return float(v) if v is not None else None
        if isinstance(row, (list, tuple)) and len(row) >= 2:
            return float(row[1])
    except (TypeError, ValueError):
        return None
    return None


def _series_rows(payload: Dict[str, Any], series_id: str) -> List[Any]:
    """Flat v2 rows whose 'series' field matches the requested id."""
    entries = (payload.get("response") or {}).get("data") or []
    if isinstance(entries, dict):
        entries = entries.get("data") or []
    rows: List[Any] = []
    for entry in entries or []:
        if isinstance(entry, dict) and str(entry.get("series")) == series_id:
            rows.append(entry)
    return rows


def _seriesid_rows(payload: Dict[str, Any]) -> List[Any]:
    """Rows from the /v2/seriesid route: dict rows under response.data
    (the live 2026-08-20 shape) or legacy [period, value] lists under
    series[].data."""
    resp_data = (payload.get("response") or {}).get("data")
    if isinstance(resp_data, list) and resp_data:
        return [r for r in resp_data if isinstance(r, (dict, list))]
    series = payload.get("series")
    if isinstance(series, list):
        for entry in series:
            if (isinstance(entry, dict)
                    and isinstance(entry.get("data"), list)
                    and entry.get("data")):
                return [r for r in entry["data"] if isinstance(r, (dict, list))]
    return []


def fetch_eia_weekly(api_key: str, timeout: int = 25) -> Dict[str, Any]:
    """Fetch the latest weekly petroleum status values. Returns
    {week, crude_change_mb, gasoline_change_mb, distillate_change_mb,
    refinery_util_pct}. Raises on API/network failure.

    BUILD 21.3 (2026-08-20): the bare v2 ids matched but blew the 5000-row
    JSON cap ("incomplete return" warning) - the frequency constraint did not
    bite. Fixes, both from the official docs:
      * start/end date bounds on the v2 route (dates are a documented v2
        parameter; a 45-day window keeps every response tiny), and
      * a documented second route as the fallback:
        /v2/seriesid/PET.XXXX.W translates APIv1 ids directly.
    Every request prints its full parameter echo + total + first rows so any
    future anomaly is self-diagnosing.
    """
    import requests

    base_url = "https://api.eia.gov/v2/petroleum/stoc/wstk/data/"
    window_start = (date.today() - timedelta(days=45)).isoformat()
    window_end = date.today().isoformat()
    common = {
        "frequency": "weekly",
        "data[0]": "value",
        "sort[0][column]": "period",
        "sort[0][direction]": "desc",
        "length": "10",
        "start": window_start,
        "end": window_end,
        "api_key": api_key,
    }

    def _params(series_ids):
        params: List[Tuple[str, str]] = list(common.items())
        for series_id in series_ids:
            params.append(("facets[series][]", series_id))
        return params

    def _dump(label: str, resp, params=None) -> None:
        try:
            body = resp.json()
        except Exception:  # noqa: BLE001
            body = {}
        warnings = (body or {}).get("warnings")
        resp_block = (body or {}).get("response") or {}
        total = resp_block.get("total")
        data = resp_block.get("data")
        rows = len(data) if isinstance(data, list) else 0
        first = []
        if isinstance(data, list) and data:
            first = [str(e)[:70] for e in data[:2]]
        echo = []
        for key, value in (params or []):
            if key != "api_key":
                echo.append(f"{key}={value}")
        print(f"  EIA {label} :: HTTP {resp.status_code} | total={total} "
              f"rows={rows} warnings={bool(warnings)}")
        if first:
            print(f"    first rows: {first}")
        if echo:
            print(f"    params: {'&'.join(echo)}")
        elif warnings:
            print(f"    warnings: {str(warnings)[:120]}")

    def _get(url, params):
        return requests.get(url, params=params, timeout=timeout)

    # Phase 1: v2 route, bare ids, date-bounded combined request.
    params = _params(PRIMARY_IDS)
    resp = _get(base_url, params)
    resp.raise_for_status()
    payload = resp.json()
    found = sorted(
        str(e.get("series"))
        for e in ((payload.get("response") or {}).get("data") or [])
        if isinstance(e, dict) and e.get("series")
    )
    print(f"  EIA combined response series: {found}")
    if not found:
        _dump("combined", resp, params)
    series_data: Dict[str, List[Any]] = {
        label: _series_rows(payload, PRIMARY_IDS[i])
        for i, label in enumerate(SERIES)
    }

    # Phase 2: per-series fallbacks - v2 single request first, then the
    # documented /v2/seriesid/<v1-id> translation route.
    for label, ids in SERIES.items():
        if series_data[label]:
            print(f"  EIA {label} ({ids[0]}): {len(series_data[label])} rows"
                  f" latest={_row_period(series_data[label][0])}")
            continue
        for candidate in ids:
            print(f"  EIA {label}: trying series id {candidate}")
            single = None
            try:
                single = _get(base_url, _params([candidate]))
                single.raise_for_status()
                rows = _series_rows(single.json(), candidate)
            except Exception as exc:  # noqa: BLE001
                print(f"  EIA {label} ({candidate}) v2 request failed: {exc}")
                rows = []
            if rows:
                series_data[label] = rows
                print(f"  EIA {label} ({candidate}): {len(rows)} rows"
                      f" latest={_row_period(rows[0])}")
                break
            _dump(f"{label} ({candidate})", single if single is not None else resp,
                  _params([candidate]))
        if not series_data[label]:
            # Documented v1-translation route (only makes sense for the
            # v1-style id).
            v1_id = ids[1] if len(ids) > 1 else None
            if v1_id:
                print(f"  EIA {label}: trying /v2/seriesid/{v1_id}")
                try:
                    sid_url = f"https://api.eia.gov/v2/seriesid/{v1_id}"
                    sid_params: List[Tuple[str, str]] = [
                        ("api_key", api_key), ("length", "10")]
                    sid_resp = _get(sid_url, sid_params)
                    sid_resp.raise_for_status()
                    rows = _seriesid_rows(sid_resp.json())
                except Exception as exc:  # noqa: BLE001
                    print(f"  EIA {label} seriesid request failed: {exc}")
                    rows = []
                if rows:
                    series_data[label] = rows
                    print(f"  EIA {label} (seriesid/{v1_id}): {len(rows)} rows"
                          f" latest={_row_period(rows[0])}")
                else:
                    _dump(f"{label} seriesid/{v1_id}", sid_resp, sid_params)
        if not series_data[label]:
            print(f"  EIA {label}: 0 rows EMPTY (tried {ids} + seriesid)")

    crude = _change(series_data["crude"])
    gasoline = _change(series_data["gasoline"])
    distillate = _change(series_data["distillate"])
    util_data = series_data.get("utilization") or []
    util = _row_value(util_data[0]) if util_data else None
    week = _row_period(series_data["crude"][0]) if series_data["crude"] else "unknown"
    if crude is None:
        counts = {label: len(series_data[label]) for label in SERIES}
        raise ValueError(
            f"EIA response missing crude stocks series (rows per series: {counts})"
        )
    return {
        "week": week,
        "crude_change_mb": crude,
        "gasoline_change_mb": gasoline,
        "distillate_change_mb": distillate,
        "refinery_util_pct": util,
        "source": "eia_api_auto",
    }


def apply_eia_payload(payload: Dict[str, Any], root: Path) -> Tuple[Path, Path]:
    """Write eia_weekly.json + append the seasonal history row. Returns paths."""
    eia_path = root / "storage" / "oil" / "eia_weekly.json"
    hist_path = root / "storage" / "oil" / "eia_history.json"
    eia_path.parent.mkdir(parents=True, exist_ok=True)
    eia_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    history: List[Dict[str, Any]] = []
    if hist_path.exists():
        try:
            history = json.loads(hist_path.read_text(encoding="utf-8"))
            if not isinstance(history, list):
                history = []
        except Exception:  # noqa: BLE001
            history = []
    week = str(payload.get("week") or "")
    if not any(isinstance(h, dict) and h.get("week") == week for h in history):
        history.append({"week": week, "crude_change_mb": payload.get("crude_change_mb")})
    hist_path.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")
    return eia_path, hist_path


def main() -> int:
    parser = argparse.ArgumentParser(description="Auto-fill oil macro from the free EIA API")
    parser.add_argument("--check", action="store_true", help="dry-run: print, do not write")
    parser.add_argument("--root", type=str, default=str(ROOT))
    args = parser.parse_args()
    root = Path(args.root)

    import os

    from utils.helpers import load_config

    config = load_config()
    oil_cfg = config.get("oil_macro") or {}
    api_key = str(
        oil_cfg.get("eia_api_key") or os.environ.get("EIA_API_KEY") or ""
    ).strip()
    if not api_key:
        print("NO EIA API KEY configured.")
        print("Get a FREE key at https://www.eia.gov/opendata/ then either:")
        print("  - set EIA_API_KEY in the .env file, or")
        print('  - set "oil_macro": {"eia_api_key": "..."} in config.json')
        print("")
        print("Until then the oil macro still works via the automatic")
        print("crack-spread layer (RB=F/HO=F vs CL=F) - no files needed.")
        return 1

    try:
        payload = fetch_eia_weekly(api_key)
    except Exception as exc:  # noqa: BLE001
        print(f"EIA fetch failed: {exc}")
        return 1

    print(f"week             : {payload['week']}")
    print(f"crude_change_mb  : {payload['crude_change_mb']}")
    print(f"gasoline_change  : {payload['gasoline_change_mb']}")
    print(f"distillate_change: {payload['distillate_change_mb']}")
    print(f"refinery_util    : {payload['refinery_util_pct']}")
    if args.check:
        print("DRY RUN - nothing written")
        return 0
    eia_path, hist_path = apply_eia_payload(payload, root)
    print(f"written: {eia_path}")
    print(f"history appended: {hist_path}")
    print("The oil macro now reads this file (plus the crack layer).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
