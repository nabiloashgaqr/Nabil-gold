"""
scripts/run_risk_analytics.py — Portfolio risk analytics CLI (2026-08-19 upgrade).

Builds the equity curve from DB closed trades and writes
storage/risk_analytics_report.json with:
  * VaR 95% (historical) + CVaR 95% (expected shortfall)
  * Sharpe / Sortino / Calmar
  * per-day P&L and max drawdown
All analytics run on the stored PnL points series (the system's native unit);
a `unit: "points"` field makes this explicit.

Usage:
  python scripts/run_risk_analytics.py            # default report
  python scripts/run_risk_analytics.py --days 90  # trailing window
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from services.risk_analytics import RiskAnalytics  # noqa: E402
from utils.helpers import load_config  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger("risk_analytics")


def _trade_pnl_points(trade: Dict[str, Any]) -> float | None:
    for key in ("final_pnl", "current_pnl", "pnl", "current_pnl_points"):
        v = trade.get(key)
        if isinstance(v, (int, float)):
            return float(v)
    return None


def _trade_day(trade: Dict[str, Any]) -> str | None:
    ts = trade.get("closed_at") or trade.get("exit_time") or trade.get("created_at") or trade.get("entry_time")
    if not ts:
        return None
    return str(ts)[:10]


def build_equity_curve(trades: List[Dict[str, Any]], *, days: int | None = None) -> Dict[str, Any]:
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()[:10] if days else None
    rows = []
    for t in trades:
        day = _trade_day(t)
        if day and cutoff and day < cutoff:
            continue
        pnl = _trade_pnl_points(t)
        if pnl is None or not day:
            continue
        rows.append((day, pnl))
    if not rows:
        return {"unit": "points", "n": 0, "curve": [], "by_day": {}}

    rows.sort(key=lambda r: r[0])
    by_day: Dict[str, float] = {}
    for day, pnl in rows:
        by_day[day] = round(by_day.get(day, 0.0) + pnl, 2)
    curve = []
    running = 0.0
    for day in sorted(by_day):
        running += by_day[day]
        curve.append(round(running, 2))
    return {"unit": "points", "n": len(rows), "curve": curve, "by_day": by_day}


def _max_drawdown_pct(curve: List[float]) -> float:
    if not curve:
        return 0.0
    arr = np.asarray(curve, dtype=float)
    peak = np.maximum.accumulate(arr)
    dd = (arr - peak) / np.where(peak == 0, 1.0, peak)
    return float(abs(np.min(dd)))


def main() -> int:
    parser = argparse.ArgumentParser(description="Portfolio risk analytics report")
    parser.add_argument("--days", type=int, default=None, help="trailing window in days")
    parser.add_argument("--out", type=str, default="storage/risk_analytics_report.json")
    args = parser.parse_args()

    config = load_config()
    from services.database import DatabaseService

    database = DatabaseService(config)
    try:
        trades = database.get_recent_trades(limit=2000)
    except Exception as exc:  # noqa: BLE001
        logger.error("Failed to load trades: %s", exc)
        return 1

    curve_info = build_equity_curve(trades, days=args.days)
    if curve_info["n"] < 10:
        logger.warning("Not enough priced trades (%d) — report still written", curve_info["n"])

    ra = RiskAnalytics([float(v) for v in curve_info["curve"]] or [0.0])
    var_cvar = ra.historical_var_cvar(0.95)
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "window_days": args.days,
        "unit": curve_info["unit"],
        "trades_priced": curve_info["n"],
        "net_pnl": round(float(curve_info["curve"][-1]), 2) if curve_info["curve"] else 0.0,
        "max_drawdown_pct": round(_max_drawdown_pct(curve_info["curve"]), 4),
        "var_95": var_cvar["var"],
        "cvar_95": var_cvar["cvar"],
        "sharpe": round(ra.sharpe(), 3),
        "sortino": round(ra.sortino(), 3),
        "calmar": round(ra.calmar(), 3),
        "by_day": curve_info["by_day"],
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "by_day"}, ensure_ascii=False, indent=2))
    logger.info("Report written: %s", out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
