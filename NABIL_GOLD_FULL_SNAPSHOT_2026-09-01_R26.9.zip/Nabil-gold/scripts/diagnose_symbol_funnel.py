#!/usr/bin/env python3
"""Symbol entry funnel diagnosis (BUILD 31 R13).

Answers "why does symbol X never trade?" from the machine's own records:

  storage/decision_audit.json  - one row per cycle outcome (delivered AND
                                 refused), with the refusal reason.
  storage/trades.json          - the actual entries.
  config.json                  - the configured symbol universe + caps.

Per symbol it reports: audit rows, stage/outcome counts, the TOP refusal
reasons, SPREAD_GUARD hits, and the actual entry count. A symbol with zero
audit rows was never even CYCLED (schedule/watchlist problem); a symbol with
refusal rows is being killed by a named gate (the reason tells you which).

Usage (from the repo root):
    python scripts\\diagnose_symbol_funnel.py
    python scripts\\diagnose_symbol_funnel.py --days 14
    python scripts\\diagnose_symbol_funnel.py --json out.json

Exit code 0 always (a report tool, not a gate).
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path

# Windows consoles/pipes may use cp1252, which cannot encode glyphs like the
# ">=" that appears in live refusal reasons. Replace instead of crash (the
# full-fidelity text still goes to the JSON output, which is always UTF-8).
try:
    sys.stdout.reconfigure(errors="replace")
except (AttributeError, ValueError):
    pass


ROOT = Path(__file__).resolve().parents[1]


def parse_ts(value):
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (TypeError, ValueError):
        return None


def load_rows(path):
    if not Path(path).exists():
        return None  # None = file missing (UNKNOWN), never guessed
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if isinstance(data, dict):
        for key in ("trades", "rows", "data"):
            if isinstance(data.get(key), list):
                return data[key]
        return [data]
    return list(data or [])


def configured_symbols(config):
    symbols = []
    for entry in (config.get("symbols") or []):
        if isinstance(entry, dict) and entry.get("enabled", True):
            symbols.append(str(entry.get("symbol")))
        elif isinstance(entry, str):
            symbols.append(entry)
    if not symbols:
        fallback = str(config.get("symbol") or "XAU/USD")
        symbols = [fallback]
    return symbols


def spread_cap_for(config, symbol):
    try:
        sys.path.insert(0, str(ROOT))
        from utils.instruments import max_spread_points_for
        return max_spread_points_for(symbol, config)
    except Exception:  # noqa: BLE001 - report tool must not die here
        return None


def build_report(root, days):
    config_path = root / "config.json"
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        config = {}

    audits = load_rows(root / "storage" / "decision_audit.json")
    trades = load_rows(root / "storage" / "trades.json")

    since = datetime.now(timezone.utc) - timedelta(days=max(1, days))

    def in_window(row):
        ts = parse_ts(row.get("created_at"))
        return ts is None or ts >= since  # unparseable rows are kept, flagged

    window_audits = [a for a in (audits or []) if in_window(a)]
    window_trades = [t for t in (trades or []) if in_window(t)]

    report = {
        "generated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "window_days": days,
        "decision_audit_file": "MISSING" if audits is None else f"{len(audits)} rows",
        "trades_file": "MISSING" if trades is None else f"{len(trades)} rows",
        "symbols": {},
    }

    for symbol in configured_symbols(config):
        sym_audits = [a for a in window_audits if str(a.get("symbol")) == symbol]
        sym_trades = [t for t in window_trades if str(t.get("symbol")) == symbol]
        outcomes = Counter(str(a.get("outcome") or "?") for a in sym_audits)
        stages = Counter(str(a.get("stage") or "?") for a in sym_audits)
        # prefix the SIDE so the operator sees which direction each refusal hit
        def _reason_line(row):
            reason = str(row.get("reason") or "")[:90]
            side = str(row.get("side") or "").upper()
            return "[%s] %s" % (side or "?", reason) if side else reason
        reasons = Counter(_reason_line(a) for a in sym_audits
                          if str(a.get("outcome") or "").upper() not in ("SENT",))
        spread_hits = sum(
            1 for a in sym_audits
            if "SPREAD" in str(a.get("reason") or "").upper()
            or "SPREAD" in str(a.get("stage") or "").upper()
        )
        timestamps = [parse_ts(a.get("created_at")) for a in sym_audits]
        timestamps = [t for t in timestamps if t]
        report["symbols"][symbol] = {
            "spread_cap_points": spread_cap_for(config, symbol),
            "audit_rows": len(sym_audits),
            "last_audit_at": max(timestamps).replace(microsecond=0).isoformat() if timestamps else None,
            "outcomes": dict(outcomes),
            "stages": dict(stages),
            "top_refusal_reasons": dict(reasons.most_common(5)),
            "spread_guard_hits": spread_hits,
            "entries_in_window": len(sym_trades),
        }
    return report


def print_report(report):
    print("=" * 100)
    print(" SYMBOL ENTRY FUNNEL  window=%sd  decision_audit=%s  trades=%s"
          % (report["window_days"], report["decision_audit_file"], report["trades_file"]))
    print("=" * 100)
    for symbol, s in report["symbols"].items():
        cap = s["spread_cap_points"]
        print("\n %s   spread_cap=%s pts" % (symbol, cap if cap is not None else "UNKNOWN"))
        print("-" * 100)
        if s["audit_rows"] == 0:
            print("   ZERO decision-audit rows in window -> this symbol was never even")
            print("   CYCLED. Not a signal-quality problem: check the schedule/watchlist,")
            print("   per-symbol enabled flags and data collector liveness for it.")
            print("   entries_in_window: %d" % s["entries_in_window"])
            continue
        print("   audit_rows=%d  entries=%d  spread_guard_hits=%d  last=%s"
              % (s["audit_rows"], s["entries_in_window"], s["spread_guard_hits"],
                 s["last_audit_at"] or "UNKNOWN"))
        print("   outcomes: %s" % s["outcomes"])
        print("   stages:   %s" % s["stages"])
        if s["top_refusal_reasons"]:
            print("   top refusal reasons:")
            for reason, count in s["top_refusal_reasons"].items():
                print("     %4d x  %s" % (count, reason))
        else:
            print("   no refusal rows in window")
    print("\n" + "=" * 100)
    print(" READ: entries>0 = trading. entries=0 + spread_guard_hits high = spread cap.")
    print("       entries=0 + a named refusal reason = that gate. ZERO audit rows = never cycled.")
    print("=" * 100)


def main():
    ap = argparse.ArgumentParser(description="Per-symbol entry funnel diagnosis")
    ap.add_argument("--root", default=str(ROOT), help="project root (default: repo root)")
    ap.add_argument("--days", type=int, default=7, help="window in days (default 7)")
    ap.add_argument("--json", dest="json_out", default=None, help="also write machine-readable JSON")
    args = ap.parse_args()

    try:
        report = build_report(Path(args.root), args.days)
        print_report(report)
    except Exception:  # noqa: BLE001 - a report tool must never die silently
        import traceback
        err = traceback.format_exc()
        print("FUNNEL ERROR - full trace written to storage/funnel_last_error.txt")
        try:
            Path(args.root).joinpath("storage").mkdir(parents=True, exist_ok=True)
            Path(args.root).joinpath("storage", "funnel_last_error.txt").write_text(
                err, encoding="utf-8")
            print("Open storage/funnel_last_error.txt and send it to me.")
        except OSError:
            print(err)
        return 0
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(report, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
        print("JSON report written: %s" % args.json_out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
