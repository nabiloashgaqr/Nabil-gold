"""Diagnose status message dispatch logic and test Telegram delivery."""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.telegram_bot import TelegramService
from utils.helpers import load_config


def main():
    print("=" * 70)
    print("        فحص محرك رسائل الحالة والاتصال بالتيليجرام (Telegram Status)        ")
    print("=" * 70)

    cfg = load_config()
    notif = cfg.get("notifications", {}) or {}
    now = datetime.now(timezone.utc)
    current_hour_key = now.strftime("%Y-%m-%dT%H")
    current_minute = now.minute

    print(f"\n[1] فحص التوقيت وشروط الإرسال الدوري:")
    print(f"  • الوقت الحالي (UTC): {now.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  • الدقيقة الحالية: {current_minute} (نافذة الإرسال التلقائي: أول 10 دقائق من كل ساعة minute < 10)")
    print(f"  • تفعيل رسائل الحالة (hourly_status): {notif.get('hourly_status', False)}")
    print(f"  • منع التكرار في نفس الساعة (hourly_status_dedup): {notif.get('hourly_status_dedup', True)}")
    print(f"  • الفاصل الزمني المحدد: {notif.get('hourly_status_interval_minutes', 60)} دقيقة")

    # فحص ملف قفل الساعة
    slot_file = ROOT / "storage" / "hourly_status_last.json"
    print(f"\n[2] فحص سجل الإرسال للساعة الحالية:")
    if slot_file.exists():
        try:
            slot_data = json.loads(slot_file.read_text(encoding="utf-8"))
            last_hour = slot_data.get("hour")
            sent_at = slot_data.get("sent_at")
            print(f"  • آخر ساعة تم الإرسال فيها: {last_hour}")
            print(f"  • وقت الإرسال الأخير: {sent_at}")
            if last_hour == current_hour_key:
                print(f"  ⚠️ تم إرسال رسالة الحالة بالفعل لهذه الساعة ({current_hour_key}). لمنع الإزعاج تم تخطي التكرار.")
            else:
                print(f"  ✅ جاهز للإرسال في الساعة الجديدة.")
        except Exception as e:
            print(f"  ⚠️ خطأ في قراءة السجل: {e}")
    else:
        print("  • لا يوجد سجل إرسال سابق (جاهز للإرسال).")

    # فحص واختبار إرسال رسالة تجريبية مباشرة إلى تيليجرام
    print(f"\n[3] اختبار إرسال رسالة مباشرة إلى تيليجرام للتأكد من الاتصال:")
    tg = TelegramService(cfg)
    test_text = (
        "🟢 <b>SmartSignal — فحص حالة الاتصال المباشر</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"⏰ الوقت (UTC): {now.strftime('%Y-%m-%d %H:%M:%S')}\n"
        "📡 قناة التيليجرام متصلة وتستقبل الإشعارات بنجاح!\n"
        "━━━━━━━━━━━━━━━━━━━━"
    )
    sent = tg.send_message(test_text)
    if sent:
        print("  ✅ تم إرسال الرسالة التجريبية إلى التيليجرام بنجاح!")
    else:
        print("  ❌ فشل الإرسال إلى التيليجرام (يرجى التحقق من توكن البوت ومعرف القناة).")

    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()
