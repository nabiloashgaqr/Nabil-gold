"""Build the two mandatory calibrated-confidence artifacts from MT5 history.

Executed by the one-shot VPS installer before the voting book is switched.
It reads native M5/M15/H1/H4 separately and broker ticks directly; it never
resamples one timeframe into another and never stores credentials.
"""
from __future__ import annotations

import argparse
import bisect
import hashlib
import json
import math
import os
import sqlite3
import statistics
import sys
from collections import deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

from services.auction_evidence import (
    EDGE_DEFINITIONS,
    composite_auction_edge,
    graded_acceptance_rejection,
    normalized_flow_pressure,
    value_location_score,
)
from services.auction_flow_store import AuctionFlowStore
from services.timeframe_fusion import CANONICAL_TIMEFRAMES
from utils.helpers import load_config
from utils.indicators import calculate_atr
from utils.instruments import point_size


def _mt5_ready():
    import MetaTrader5 as mt5
    path = os.environ.get("MT5_PATH") or None
    ok = mt5.initialize(path=path) if path else mt5.initialize()
    if not ok:
        raise RuntimeError(f"MT5 initialize failed: {mt5.last_error()}")
    login = int(os.environ.get("MT5_LOGIN") or 0)
    if login and not mt5.login(
        login,
        password=os.environ.get("MT5_PASSWORD") or "",
        server=os.environ.get("MT5_SERVER") or "",
    ):
        raise RuntimeError(f"MT5 login failed: {mt5.last_error()}")
    info = mt5.account_info()
    if info is None:
        raise RuntimeError("MT5 account_info unavailable")
    demo_const = getattr(mt5, "ACCOUNT_TRADE_MODE_DEMO", 0)
    if int(getattr(info, "trade_mode", -1)) != int(demo_const):
        raise RuntimeError("REAL ACCOUNT REFUSED: calibration installer requires MT5 DEMO")
    return mt5


def _symbol(config: Mapping[str, Any]) -> str:
    public = str(config.get("symbol") or "XAU/USD")
    return str((((config.get("execution") or {}).get("demo") or {}).get("symbol_map") or {}).get(public) or public.replace("/", ""))


def _native_rates(mt5, symbol: str, timeframe: str, days: int) -> List[Dict[str, Any]]:
    constants = {
        "5m": mt5.TIMEFRAME_M5,
        "15m": mt5.TIMEFRAME_M15,
        "1H": mt5.TIMEFRAME_H1,
        "4H": mt5.TIMEFRAME_H4,
    }
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=days)
    rates = mt5.copy_rates_range(symbol, constants[timeframe], start, end)
    if rates is None or len(rates) == 0:
        raise RuntimeError(f"No native MT5 {timeframe} rates for {symbol}: {mt5.last_error()}")
    result = [
        {
            "time": int(r["time"]), "open": float(r["open"]),
            "high": float(r["high"]), "low": float(r["low"]),
            "close": float(r["close"]), "volume": float(r["tick_volume"]),
        }
        for r in rates
    ]
    result.sort(key=lambda c: int(c["time"]))
    return result


def _index_at(times: Sequence[int], ts: int) -> int:
    return bisect.bisect_right(times, int(ts)) - 1


def _signed_percentile(value: float, distribution: Sequence[float]) -> float:
    if not distribution or value == 0:
        return 0.0
    rank = bisect.bisect_right(distribution, abs(float(value))) / len(distribution)
    return math.copysign(min(1.0, rank), value)


def _barrier_label(
    direction: int, price: float, atr: float,
    future: Sequence[Mapping[str, Any]],
    bars: int = 16,
) -> int | None:
    if direction == 0 or price <= 0 or atr <= 0:
        return None
    upper = price + atr
    lower = price - atr
    for bar in future[:max(1, int(bars))]:
        high = float(bar.get("high", 0) or 0)
        low = float(bar.get("low", 0) or 0)
        hit_up = high >= upper
        hit_down = low <= lower
        if hit_up and hit_down:
            return None
        if hit_up:
            return 1 if direction > 0 else 0
        if hit_down:
            return 1 if direction < 0 else 0
    return None


def _fit_logistic_from(xs: Sequence[float], ys: Sequence[int], b_init: float) -> tuple[float, float]:
    rate = min(0.999, max(0.001, sum(ys) / len(ys)))
    a = math.log(rate / (1.0 - rate))
    b = float(b_init)
    for step in range(12000):
        ga = 0.0
        gb = 0.0
        for x, y in zip(xs, ys):
            z = max(-40.0, min(40.0, a + b * float(x)))
            p = 1.0 / (1.0 + math.exp(-z))
            err = p - float(y)
            ga += err
            gb += err * float(x)
        ga /= len(xs)
        gb /= len(xs)
        lr = 0.08 / (1.0 + step / 3000.0)
        a -= lr * ga
        b = max(0.0, b - lr * gb)
    return a, b


def _log_loss(xs: Sequence[float], ys: Sequence[int], a: float, b: float) -> float:
    total = 0.0
    for x, y in zip(xs, ys):
        z = max(-40.0, min(40.0, a + b * float(x)))
        p = min(1.0 - 1e-9, max(1e-9, 1.0 / (1.0 + math.exp(-z))))
        total += -(float(y) * math.log(p) + (1.0 - float(y)) * math.log(1.0 - p))
    return total / max(1, len(xs))


def _fit_monotonic_logistic(xs: Sequence[float], ys: Sequence[int]) -> Dict[str, float]:
    """Fit P(win)=sigmoid(a+b*|edge|) with b>=0, validated OUT OF SAMPLE.

    Two failure modes are guarded against simultaneously:

    * UNDER-fit (the original bug): a single b=0.5 seed stalls at the b=0
      boundary when the noise mass pushes the slope down early and the
      decaying learning rate cannot recover it, flattening a real signal.
      -> fit from several seeds spanning the observed |edge| scale.

    * OVER-fit (the naive fix's bug): choosing the best seed by TRAINING
      loss lets pure noise buy a positive slope, faking discrimination the
      market never offered.
      -> hold out 30% of the samples; a candidate slope is kept only when
      it beats the flat b=0 baseline on data it never saw. Otherwise the
      honest answer is b=0 and the live agent keeps the 50% floor.
    """
    if len(xs) != len(ys) or len(xs) < 50:
        raise RuntimeError("Not enough samples for logistic calibration")

    # Deterministic shuffle so the holdout is stable run-to-run.
    order = sorted(range(len(xs)), key=lambda i: hashlib.sha256(f"{i}:{xs[i]:.10f}".encode()).hexdigest())
    cut = max(25, int(len(order) * 0.7))
    train_idx, valid_idx = order[:cut], order[cut:]
    if len(valid_idx) < 25:
        train_idx, valid_idx = order, order  # tiny set: no honest holdout possible
    tx = [float(xs[i]) for i in train_idx]
    ty = [int(ys[i]) for i in train_idx]
    vx = [float(xs[i]) for i in valid_idx]
    vy = [int(ys[i]) for i in valid_idx]

    # Flat baseline (b=0): intercept from the TRAIN base rate, scored on holdout.
    rate = min(0.999, max(0.001, sum(ty) / len(ty)))
    a_flat = math.log(rate / (1.0 - rate))
    baseline_loss = _log_loss(vx, vy, a_flat, 0.0)

    spread = max(tx) if tx else 1.0
    seeds = [0.5, 2.0]
    if spread > 0:
        seeds.append(min(40.0, 2.0 / spread))  # a seed matched to the x-scale
    best: tuple[float, float] | None = None
    best_loss = baseline_loss - 1e-4  # must beat flat by a real margin
    for b0 in seeds:
        a, b = _fit_logistic_from(tx, ty, b0)
        loss = _log_loss(vx, vy, a, b)
        if loss < best_loss:
            best_loss = loss
            best = (a, b)

    if best is None:
        # No slope survived out-of-sample validation: report the flat truth.
        return {"a": round(a_flat, 10), "b": 0.0}

    # Refit the surviving shape on ALL data for the final published curve
    # (seeded from the validated slope so it cannot wander to a new shape).
    a_fin, b_fin = _fit_logistic_from(list(map(float, xs)), list(map(int, ys)), max(best[1], 0.1))
    return {"a": round(a_fin, 10), "b": round(b_fin, 10)}


def _write_checked(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = dict(payload)
    canonical = json.dumps(raw, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    raw["checksum"] = hashlib.sha256(canonical).hexdigest()
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    for attempt in range(10):
        try:
            os.replace(temp, path)
            break
        except PermissionError:
            if attempt == 9:
                raise
            import time as _time
            _time.sleep(0.2 * (attempt + 1))


def _fetch_ticks(mt5, symbol: str, days: int, store: AuctionFlowStore) -> int:
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=days)
    cursor = start
    total = 0
    while cursor < end:
        stop = min(cursor + timedelta(days=1), end)
        ticks = mt5.copy_ticks_range(symbol, cursor, stop, mt5.COPY_TICKS_ALL)
        if ticks is None:
            raise RuntimeError(f"MT5 tick history failed {cursor.date()}: {mt5.last_error()}")
        total += store.bulk_record_ticks(ticks)
        cursor = stop
    current = mt5.symbol_info_tick(symbol)
    if current is not None:
        store.record_tick(current)
    store.mark_heartbeat()
    return total


def _value_area(profile: Mapping[float, int], pct: float = 70.0) -> tuple[float, float, float]:
    return AuctionFlowStore._value_area(profile, pct)


def build_auction(
    config: Mapping[str, Any], rates: Mapping[str, List[Dict[str, Any]]],
    store: AuctionFlowStore, output: Path,
) -> Dict[str, Any]:
    with sqlite3.connect(str(store.path)) as con:
        rows_raw = con.execute(
            "SELECT ts,open_mid,high_mid,low_mid,close_mid,sum_mid,tick_count,up_count,down_count "
            "FROM minutes ORDER BY ts"
        ).fetchall()
    rows = [
        {"ts": int(r[0]), "open": float(r[1]), "high": float(r[2]), "low": float(r[3]),
         "close": float(r[4]), "sum_mid": float(r[5]), "ticks": int(r[6]),
         "up": int(r[7]), "down": int(r[8])}
        for r in rows_raw
    ]
    if len(rows) < 500:
        raise RuntimeError(f"Auction history has only {len(rows)} minute rows")
    tf_times = {tf: [int(c["time"]) for c in rates[tf]] for tf in CANONICAL_TIMEFRAMES}
    tf_atr = {tf: calculate_atr(rates[tf], 14) for tf in CANONICAL_TIMEFRAMES}
    m15 = rates["15m"]
    atr15 = tf_atr["15m"]
    auction_cfg = config.get("auction_flow") or {}
    bin_size = float(auction_cfg.get("profile_bin_points", 10) or 10) * point_size(str(config.get("symbol") or "XAU/USD"), dict(config))
    pressure_scale = float(auction_cfg.get("flow_pressure_scale", 0.12) or 0.12)
    value_scale = float(auction_cfg.get("value_location_scale_atr", 2.0) or 2.0)
    response_window = int(auction_cfg.get("acceptance_window_minutes", 5) or 5)

    xs: List[float] = []
    ys: List[int] = []
    candidates: List[Dict[str, Any]] = []
    last_sample_index = -10**9
    session_key = None
    session_zone = ZoneInfo(str((config.get("auction_flow") or {}).get("session_timezone", "Asia/Hebron")))
    profile: Dict[float, int] = {}
    sum_mid = 0.0
    sum_ticks = 0
    recent: deque[Dict[str, Any]] = deque(maxlen=31)
    for i, row in enumerate(rows):
        dt = datetime.fromtimestamp(row["ts"], tz=timezone.utc)
        key = dt.astimezone(session_zone).date()
        if key != session_key:
            session_key = key
            profile = {}
            sum_mid = 0.0
            sum_ticks = 0
            recent.clear()
        ticks = row["ticks"]
        if ticks <= 0:
            continue
        avg = row["sum_mid"] / ticks
        pbin = round(round(avg / max(bin_size, 1e-9)) * max(bin_size, 1e-9), 8)
        profile[pbin] = profile.get(pbin, 0) + ticks
        sum_mid += row["sum_mid"]
        sum_ticks += ticks
        recent.append(row)
        if i % 5 != 0 or len(recent) < 6 or sum_ticks <= 0:
            continue
        vwap = sum_mid / sum_ticks
        poc, vah, val = _value_area(profile, 70.0)
        if min(vwap, poc, vah, val) <= 0:
            continue
        last5 = list(recent)[-5:]
        up5 = sum(r["up"] for r in last5)
        down5 = sum(r["down"] for r in last5)
        pressure5 = (up5 - down5) / max(up5 + down5, 1)
        last1 = last5[-1]
        pressure1 = (last1["up"] - last1["down"]) / max(last1["up"] + last1["down"], 1)
        raw_pressure = max(-1.0, min(1.0, statistics.mean([pressure1, pressure5])))
        pressure = normalized_flow_pressure(raw_pressure, scale=pressure_scale)
        tf_context: List[float] = []
        valid = True
        for tf in CANONICAL_TIMEFRAMES:
            idx = _index_at(tf_times[tf], row["ts"])
            if idx < 14 or tf_atr[tf][idx] in (None, 0):
                valid = False
                break
            close = float(rates[tf][idx]["close"])
            atr = float(tf_atr[tf][idx] or 0)
            tf_context.append(value_location_score(
                close, vwap, poc, atr, scale_atr=value_scale,
            ))
        if not valid:
            continue
        idx15 = _index_at(tf_times["15m"], row["ts"])
        if idx15 < 14 or idx15 + 16 >= len(m15):
            continue
        atr = float(atr15[idx15] or 0)
        current_value = value_location_score(
            row["close"], vwap, poc, atr, scale_atr=value_scale,
        )
        value_location = max(-1.0, min(1.0, statistics.mean([current_value, *tf_context])))
        response, _response_state, _metrics = graded_acceptance_rejection(
            last5, pressure, vah, val, atr, window=response_window,
        )
        families = [pressure, value_location, response]
        base = statistics.mean(families)
        absolute = sum(abs(v) for v in families)
        coherence = abs(sum(families)) / absolute if absolute else 0.0
        prior_rates = [r["ticks"] for r in list(recent)[:-1] if r["ticks"] > 0]
        median_rate = statistics.median(prior_rates) if prior_rates else 0.0
        activity = row["ticks"] / median_rate if median_rate else 0.0
        quality = max(0.50, min(1.0, activity))
        edge = max(-1.0, min(1.0, base * coherence * quality))
        # ── Outcome definition fix (operator 2026-08-14) ──
        # The auction families measure minute-scale dynamics (60s/5m tick
        # pressure, 5-minute acceptance windows). Scoring them against a
        # 16-bar (4-hour) barrier let the signal decay to noise before it
        # was ever measured, which trained b -> 0 and produced a flat,
        # invalid curve. Three changes, all confined to TRAINING:
        #   1. horizon 4 bars of 15m (1 hour) with a 0.5*ATR barrier --
        #      matched to the natural lifetime of an auction read;
        #   2. near-zero edges are excluded: |edge| < 0.05 has no declared
        #      direction worth scoring, and that huge ~50% noise mass was
        #      crushing the informative tail;
        #   3. sampling every 15 minutes instead of every 5 so consecutive
        #      outcome windows overlap less.
        if (i - last_sample_index) < int(auction_cfg.get("calibration_sample_spacing_minutes", 15) or 15):
            continue
        last_sample_index = i
        candidates.append({
            "edge": edge, "close": row["close"], "atr": atr, "idx15": idx15,
            "pressure": pressure, "value_location": value_location,
            "response": response, "quality": quality,
        })

    horizon_bars = int(auction_cfg.get("calibration_horizon_15m_bars", 4) or 4)
    barrier_atr = float(auction_cfg.get("calibration_barrier_atr", 0.5) or 0.5)

    min_edge = float(auction_cfg.get("calibration_min_edge", 0.05) or 0.05)

    def _candidate_edge(c: Dict[str, Any], definition: str) -> float:
        return composite_auction_edge(
            c["pressure"], c["value_location"], c["response"], c["quality"],
            definition=definition,
        )

    def _label_all(h_bars: int, b_atr: float, definition: str) -> tuple[List[float], List[int]]:
        lx: List[float] = []
        ly: List[int] = []
        for c in candidates:
            edge_val = _candidate_edge(c, definition)
            if abs(edge_val) < min_edge:
                continue
            label = _barrier_label(
                1 if edge_val > 0 else -1 if edge_val < 0 else 0,
                c["close"], c["atr"] * b_atr,
                m15[c["idx15"] + 1: c["idx15"] + 1 + h_bars],
                bars=h_bars,
            )
            if label is not None:
                lx.append(abs(edge_val))
                ly.append(label)
        return lx, ly

    def _tercile_lift(lx: List[float], ly: List[int]) -> float:
        ordered_pairs = sorted(zip(lx, ly))
        m = len(ordered_pairs)
        if m < 30:
            return 0.0
        bottom_third = ordered_pairs[: max(1, m // 3)]
        top_third = ordered_pairs[-max(1, m // 3):]
        return (sum(y for _, y in top_third) / len(top_third)
                - sum(y for _, y in bottom_third) / len(bottom_third)) * 100.0

    # ── Diagnostic sweeps: measure, do not guess. ──
    # 1) horizon sweep on the configured edge definition;
    # 2) edge-DEFINITION sweep on the configured horizon: which combination
    #    of the three families actually ranks next-bar outcomes?
    # The published curve always uses the configured (definition, horizon)
    # pair, and the out-of-sample fitter still refuses unearned slopes.
    edge_definition = str(auction_cfg.get("edge_definition", "extension_mean") or "extension_mean")
    if edge_definition not in EDGE_DEFINITIONS:
        raise RuntimeError(f"Unknown auction_flow.edge_definition: {edge_definition}")

    print(f"AUCTION HORIZON SWEEP (definition={edge_definition}):")
    sweep_report: List[Dict[str, Any]] = []
    for h in (1, 2, 4, 8, 16):
        for k in (0.25, 0.5, 1.0):
            sx, sy = _label_all(h, k, edge_definition)
            if len(sy) < 30:
                continue
            base_pct = sum(sy) / len(sy) * 100.0
            lift = _tercile_lift(sx, sy)
            sweep_report.append({"horizon_bars": h, "barrier_atr": k,
                                 "samples": len(sy), "base_pct": round(base_pct, 2),
                                 "tercile_lift_pp": round(lift, 2)})
            print(f"  h={h:>2} k={k:<4} n={len(sy):>5} base={base_pct:5.1f}% lift={lift:+6.2f}pp")

    print(f"AUCTION EDGE-DEFINITION SWEEP (h={horizon_bars}, k={barrier_atr}):")
    definition_report: List[Dict[str, Any]] = []
    for d in EDGE_DEFINITIONS:
        sx, sy = _label_all(horizon_bars, barrier_atr, d)
        if len(sy) < 30:
            print(f"  {d:<26} n={len(sy):>5} (too few samples)")
            continue
        base_pct = sum(sy) / len(sy) * 100.0
        lift = _tercile_lift(sx, sy)
        marker = " <= configured" if d == edge_definition else ""
        definition_report.append({"definition": d, "samples": len(sy),
                                  "base_pct": round(base_pct, 2),
                                  "tercile_lift_pp": round(lift, 2)})
        print(f"  {d:<26} n={len(sy):>5} base={base_pct:5.1f}% lift={lift:+6.2f}pp{marker}")

    xs, ys = _label_all(horizon_bars, barrier_atr, edge_definition)
    minimum = int((config.get("auction_flow") or {}).get("min_calibration_samples", 300) or 300)
    if len(xs) < minimum:
        raise RuntimeError(f"Auction Flow calibration has {len(xs)} resolved samples; need {minimum}")

    logistic = _fit_monotonic_logistic(xs, ys)

    # ── Curve health report (printed at build time, stored in the payload) ──
    def _sig(z: float) -> float:
        return 1.0 / (1.0 + math.exp(-max(-60.0, min(60.0, z))))

    a_fit = float(logistic["a"])
    b_fit = float(logistic["b"])
    span_points = (_sig(a_fit + b_fit) - _sig(a_fit)) * 100.0
    ordered = sorted(zip(xs, ys))
    n = len(ordered)
    bottom = ordered[: max(1, n // 3)]
    top = ordered[-max(1, n // 3):]
    lift = (sum(y for _, y in top) / len(top) - sum(y for _, y in bottom) / len(bottom)) * 100.0
    print(f"AUCTION CURVE HEALTH: samples={n} base={sum(ys)/n*100:.1f}% "
          f"span={span_points:.2f}pp tercile_lift={lift:+.2f}pp b={b_fit:.4f}")
    if span_points < 2.0:
        print("AUCTION CURVE WARNING: span < 2pp -- the live agent will hold "
              "Auction Flow at the 50% floor (curve_valid=False). The signal/"
              "outcome relationship is too weak on this window; collect more "
              "history or review the family definitions.")

    payload = {
        "version": str((config.get("auction_flow") or {}).get("calibration_version", "auction_flow_v1")),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source": "mt5_native_ticks_plus_M5_M15_H1_H4",
        "symbol": _symbol(config),
        "sample_count": len(xs),
        "correct_count": int(sum(ys)),
        "base_accuracy": round(sum(ys) / len(ys) * 100.0, 3),
        "outcome": {
            "barrier_atr_15m": float(auction_cfg.get("calibration_barrier_atr", 0.5) or 0.5),
            "horizon_15m_bars": int(auction_cfg.get("calibration_horizon_15m_bars", 4) or 4),
            "min_edge": float(auction_cfg.get("calibration_min_edge", 0.05) or 0.05),
            "sample_spacing_minutes": int(auction_cfg.get("calibration_sample_spacing_minutes", 15) or 15),
        },
        "logistic": logistic,
        "curve_health": {
            "span_points": round(span_points, 3),
            "tercile_lift_points": round(lift, 3),
        },
        "horizon_sweep": sweep_report,
        "edge_definition": edge_definition,
        "edge_definition_sweep": definition_report,
    }
    _write_checked(output, payload)
    return payload


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=90)
    parser.add_argument("--tick-days", type=int, default=30)
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--reset-auction-store", action="store_true")
    args = parser.parse_args()
    config = load_config(args.config)
    mt5 = _mt5_ready()
    symbol = _symbol(config)
    if not mt5.symbol_select(symbol, True):
        raise RuntimeError(f"MT5 symbol_select failed for {symbol}: {mt5.last_error()}")
    rates = {tf: _native_rates(mt5, symbol, tf, args.days) for tf in CANONICAL_TIMEFRAMES}
    for tf in CANONICAL_TIMEFRAMES:
        print(f"NATIVE {tf}: {len(rates[tf])} candles")
    auction_cfg = config.get("auction_flow", {}) or {}
    store_path = Path(str(auction_cfg.get("storage_path") or "storage/auction_flow.sqlite3"))
    if args.reset_auction_store:
        for suffix in ("", "-wal", "-shm"):
            try:
                Path(str(store_path) + suffix).unlink()
            except FileNotFoundError:
                pass
    store = AuctionFlowStore(store_path)
    total_ticks = _fetch_ticks(mt5, symbol, args.tick_days, store)
    print(f"AUCTION TICKS LOADED: {total_ticks}")
    auction = build_auction(
        config, rates, store,
        Path(str(auction_cfg.get("calibration_path") or "storage/model_calibration/auction_flow_v1.json")),
    )
    print(f"AUCTION FLOW CALIBRATION OK: {auction['sample_count']} samples")
    store.prune(
        second_days=int(auction_cfg.get("second_retention_days", 7) or 7),
        minute_days=int(auction_cfg.get("minute_retention_days", 90) or 90),
    )
    print("CALIBRATIONS READY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
