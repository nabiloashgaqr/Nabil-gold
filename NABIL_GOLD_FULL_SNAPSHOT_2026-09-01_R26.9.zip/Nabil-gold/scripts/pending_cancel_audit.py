"""
scripts/pending_cancel_audit.py — WHY was a pending order cancelled?
(2026-08-19, read-only, cp1252-safe)

Reads the trade row from the local book + scans the logs, then reports the
cancellation story with the exact cause code. The known cancellation gates:

  ACTIVATION_BOOK_VETO          live book at touch: >=2 qualified opponents
                                (or book too old) - pending cancelled at the
                                moment it would have filled
  ORPHANED_ADD_AT_TOUCH         its lead leg already stopped out
  OPPOSITE_PLAN_GUARD           a newer READY plan in the opposite direction
  PLAN_STALE                    the session plan expired / map re-scored
  RR_BELOW_MINIMUM              planned R:R dropped below the floor
  LATE_TOUCH_REVALIDATION_FAILED  price ran away before the touch
  POST_NEWS_REVALIDATION_FAILED   news window broke the thesis
  TICK_STALE_RUNAWAY            tick manager: age or runaway excursion
  UNKNOWN                       not identifiable from the stored fields

Usage:
  python scripts/pending_cancel_audit.py
  python scripts/pending_cancel_audit.py --date 2026-08-19
  python scripts/pending_cancel_audit.py --hours 24
  python scripts/pending_cancel_audit.py --root D:\\Nabil-gold
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass

# codes that can appear in the row / logs -> human explanation
CODE_MEANINGS = {
    "ACTIVATION_BOOK_VETO": (
        "the live agent book VETOED the pending at the moment of touch "
        "(>=2 qualified opponents, or the book was too old) - the pending "
        "would have filled blindly, so it was cancelled instead"
    ),
    "ORPHANED_ADD_AT_TOUCH": "its lead leg already stopped out - averaging into a dead thesis",
    "OPPOSITE_PLAN_GUARD": "a newer READY plan in the opposite direction replaced it",
    "PLAN_STALE": "the session plan expired / the map was re-scored and no longer supports it",
    "RR_BELOW_MINIMUM": "the planned reward:risk fell below the floor",
    "LATE_TOUCH_REVALIDATION_FAILED": "price ran away before the touch - the limit re-validation failed",
    "POST_NEWS_REVALIDATION_FAILED": "a news window broke the thesis at touch",
    "TICK_STALE_RUNAWAY": "tick manager staleness: too old (>6h) OR thesis invalidation breached (legacy excursion rule is OFF since build 12)",
    "UNKNOWN": "no stored cause - check the log scan below",
}


def _load_rows(root: Path):
    path = root / "storage" / "trades.json"
    if not path.exists():
        return None
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return raw if isinstance(raw, list) else []
    except Exception:  # noqa: BLE001
        return None


def _dt(value) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None


def _classify(row: dict, log_hits: list) -> str:
    text_fields = " ".join([
        str(row.get("cancel_reason_code") or ""),
        str(row.get("cancel_reason") or ""),
        str(row.get("exit_warning") or ""),
        str(row.get("reasons") or ""),
        str(row.get("result") or ""),
        " ".join(str(x) for x in (row.get("updates_sent") or [])),
        " ".join(log_hits),
    ]).upper()
    for code in CODE_MEANINGS:
        if code == "UNKNOWN":
            continue
        if code.replace("_", " ") in text_fields or code in text_fields:
            return code
    if "FRESHNESS MIRROR" in text_fields:
        return "TICK_STALE_RUNAWAY"
    if "STALE" in text_fields or "EXPIRED" in text_fields:
        return "PLAN_STALE"
    if "REVALIDATION" in text_fields:
        return "LATE_TOUCH_REVALIDATION_FAILED"
    return "UNKNOWN"


def _scan_logs(root: Path, trade_id: str, since: datetime | None, window_hours: float) -> list:
    hits: list = []
    log_dir = root / "logs"
    if not log_dir.exists():
        return hits
    cutoff = since or (datetime.now(timezone.utc) - timedelta(hours=window_hours))
    for logfile in sorted(log_dir.glob("*.log"))[-6:]:
        try:
            with logfile.open("rb") as fh:
                fh.seek(0, 2)
                size = fh.tell()
                fh.seek(max(0, size - 2_000_000))  # last ~2MB
                for line in fh.read().decode("utf-8", errors="replace").splitlines():
                    if trade_id in line and any(
                        kw in line.upper() for kw in ("CANCEL", "VETO", "STALE", "EXPIR", "REVALID", "ORPHAN")
                    ):
                        hits.append(f"{logfile.name}: {line.strip()[-220:]}")
        except Exception:  # noqa: BLE001
            continue
    return hits


def main() -> int:
    parser = argparse.ArgumentParser(description="Why was a pending cancelled (read-only)")
    parser.add_argument("--date", type=str, default=None, help="YYYY-MM-DD")
    parser.add_argument("--hours", type=float, default=24.0, help="fallback window when no date")
    parser.add_argument("--root", type=str, default=str(ROOT))
    args = parser.parse_args()
    root = Path(args.root)

    rows = _load_rows(root)
    if rows is None:
        print("storage/trades.json missing or unreadable")
        return 1

    now = datetime.now(timezone.utc)
    if args.date:
        window_start = datetime.fromisoformat(args.date).replace(tzinfo=timezone.utc)
    else:
        window_start = now - timedelta(hours=args.hours)

    cancelled = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        if str(row.get("status") or "").upper() != "CANCELLED":
            continue
        closed = _dt(row.get("closed_at") or row.get("close_time") or row.get("updated_at"))
        if closed and closed < window_start:
            continue
        cancelled.append(row)

    # focus: rows that WERE placed on MT5 (ticket) and then cancelled
    placed = [r for r in cancelled if r.get("mt5_ticket")]
    never_placed = [r for r in cancelled if not r.get("mt5_ticket")]

    print("=" * 74)
    print(f"PENDING CANCEL AUDIT - {len(placed)} placed-then-cancelled | "
          f"{len(never_placed)} cancelled-before-placement")
    print("=" * 74)

    counts: Counter = Counter()
    for row in placed:
        tid = str(row.get("id") or "")[:28]
        log_hits = _scan_logs(root, tid, None, args.hours)
        code = _classify(row, log_hits)
        counts[code] += 1
        created = _dt(row.get("created_at") or row.get("entry_time"))
        closed = _dt(row.get("closed_at") or row.get("close_time"))
        minutes_open = (
            f"{(closed - created).total_seconds() / 60.0:.0f} min"
            if created and closed else "?"
        )
        print("-" * 74)
        print(f"id={row.get('id')}")
        print(f"  order={row.get('order_type')} entry={row.get('entry_price')} "
              f"ticket={row.get('mt5_ticket')} life={minutes_open}")
        print(f"  execution path: {row.get('execution_path_id') or row.get('admission_path') or 'UNKNOWN'}")
        print(f"  created={created.isoformat() if created else '?'} closed={closed.isoformat() if closed else '?'}")
        print(f"  stored cancel_code: {row.get('cancel_reason_code') or '-'}")
        print(f"  stored cancel_reason: {row.get('cancel_reason') or '-'}")
        print(f"  stored reasons: {row.get('reasons') or '-'}")
        print(f"  stored exit_warning: {row.get('exit_warning') or '-'}")
        print(f"  CAUSE: {code} -> {CODE_MEANINGS[code]}")
        if log_hits:
            print("  log evidence:")
            for hit in log_hits[:4]:
                print(f"    {hit}")

    if not placed:
        print("No placed-then-cancelled rows in the window.")
        print("(All cancelled rows were never placed - daily cap or pre-placement gates.)")
    print()
    print("-" * 74)
    print("SUMMARY:")
    for code, n in counts.most_common():
        print(f"  {n:>3}x {code}: {CODE_MEANINGS[code]}")
    if not counts:
        print("  (nothing classified)")
    print("-" * 74)
    print("If ACTIVATION_BOOK_VETO dominates: the pending touched while the")
    print("agent book opposed it (or was older than the activation window).")
    print("That is the designed protection - 'the pending must not fill blindly'.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
