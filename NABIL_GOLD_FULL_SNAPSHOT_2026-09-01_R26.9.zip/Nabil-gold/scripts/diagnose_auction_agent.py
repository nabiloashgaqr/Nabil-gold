#!/usr/bin/env python3
"""Auction-flow agent gate-by-gate diagnosis (BUILD 31 R13).

Answers precisely: "why does the auction agent always show exactly 50%?"

The 50% is NOT a broken score. In agents/auction_flow_agent.py::_wait the
display floor is hardcoded: ANY data-outage WAIT publishes confidence 50
("50 = the calibrated neutral floor"). So "always 50" means the agent never
got past its data gates even once. This tool walks those gates in the SAME
order the live agent does, using the SAME code, and prints exactly which
gate stops the agent for each symbol - plus the fix hint:

  gate 1  CALIBRATION_INVALID    file missing / checksum / version /
                                 samples < 300 / symbol mismatch
                                 (skipped entirely when the symbol's
                                 instruments[].auction_flow.calibration_required
                                 is false)
  gate 2  data problem (_data_problem):
          LIVE_TICK_FEED_STALE / COLLECTOR_HEARTBEAT_STALE /
          INSUFFICIENT_LIVE_TICKS / SPREAD_GUARD /
          SESSION_PROFILE_INCOMPLETE
  gate 3  (live cycles only) NATIVE_TIMEFRAME_BOOK_INCOMPLETE and
          SESSION_PROFILE_INCOMPLETE (VWAP/POC/VAH/VAL vs ATR)

Usage (from the repo root):
    python scripts\\diagnose_auction_agent.py
    python scripts\\diagnose_auction_agent.py --symbols EUR/USD,GBP/USD
    python scripts\\diagnose_auction_agent.py --json out.json

Exit code 0 always (a report tool, not a gate).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

# Windows consoles/pipes may use cp1252, which cannot encode glyphs like the
# ">=" that appears in live refusal reasons. Replace instead of crash (the
# full-fidelity text still goes to the JSON output, which is always UTF-8).
try:
    sys.stdout.reconfigure(errors="replace")
except (AttributeError, ValueError):
    pass


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

HINTS = {
    "SPREAD_GUARD": "spread exceeds the cap. R13 moved the cap per symbol "
                    "(EUR/USD=25, GBP/USD=30, USD/CAD=30, USD/JPY=25 pts) - "
                    "make sure APPLY_R13_CONFIG_MERGE.py ran on THIS machine.",
    "LIVE_TICK_FEED_STALE": "the tick collector is not writing fresh ticks for "
                            "this pair (check the collector cycle covers it).",
    "COLLECTOR_HEARTBEAT_STALE": "the collector heartbeat is stale - the "
                                 "collector process is likely not running.",
    "INSUFFICIENT_LIVE_TICKS": "fewer than min_unique_ticks_5m unique ticks in "
                               "the last 5 minutes - feed too quiet or "
                               "collector subscribed late.",
    "SESSION_PROFILE_INCOMPLETE": "not enough tick history in the store to "
                                  "build VWAP/POC/VAH/VAL for this session.",
    "CALIBRATION_INVALID": "rerun scripts/build_forex_auction_calibrations.py "
                           "on this machine, or set the symbol's "
                           "auction_flow.calibration_required=false to skip.",
}


def _abs(root: Path, value: str) -> str:
    p = Path(value)
    return str(p if p.is_absolute() else (root / p))


def calibration_verdict(cal_path: Path, cfg: dict, agent_symbol: str):
    """Replicate AuctionFlowAgent._load_calibration with itemized reasons."""
    if not cal_path.exists():
        return False, [f"file MISSING: {cal_path.name}"]
    reasons = []
    try:
        raw = json.loads(cal_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return False, [f"unreadable JSON: {exc}"]
    supplied = str(raw.pop("checksum", "") or "")
    canonical = json.dumps(raw, ensure_ascii=False, sort_keys=True,
                           separators=(",", ":")).encode("utf-8")
    if hashlib.sha256(canonical).hexdigest() != supplied:
        reasons.append("checksum mismatch (file edited or corrupt)")
    expected_version = str((cfg.get("auction_flow", {}) or {}).get(
        "calibration_version", "auction_flow_v1"))
    if str(raw.get("version")) != expected_version:
        reasons.append(f"version {raw.get('version')} != expected {expected_version}")
    minimum = int((cfg.get("auction_flow", {}) or {}).get(
        "min_calibration_samples", 300) or 300)
    samples = int(raw.get("sample_count", 0) or 0)
    if samples < minimum:
        reasons.append(f"samples {samples} < required {minimum}")
    cal_symbol = str(raw.get("symbol") or "").upper().replace("/", "").replace(".S", "").rstrip(".")
    my_symbol = agent_symbol.replace("/", "")
    if cal_symbol and my_symbol not in cal_symbol and cal_symbol not in my_symbol:
        reasons.append(f"symbol mismatch: calibrated for {cal_symbol}, agent is {my_symbol}")
    logistic = raw.get("logistic") or {}
    if "a" not in logistic or "b" not in logistic:
        reasons.append("logistic curve missing a/b")
    return (not reasons), (reasons or ["all checks passed"])


def diagnose_symbol(root: Path, config: dict, symbol: str):
    from agents.auction_flow_agent import AuctionFlowAgent
    from utils.instruments import normalize_symbol, point_size, max_spread_points_for
    from copy import deepcopy

    cfg = deepcopy(config)
    cfg["symbol"] = symbol
    inst_cfg = next((i for i in (config.get("instruments") or [])
                     if normalize_symbol(i.get("symbol")) == normalize_symbol(symbol)), {})
    auc_cfg = cfg.get("auction_flow", {}) or {}
    # absolutize per-symbol paths exactly like the agent does, then anchor at root
    agent_symbol = normalize_symbol(symbol)
    stem = agent_symbol.replace("/", "").lower()
    store_base = _abs(root, str(auc_cfg.get("storage_path") or "storage/auction_flow.sqlite3"))
    cal_base = _abs(root, str(auc_cfg.get("calibration_path") or "storage/model_calibration/auction_flow_v1.json"))
    # effective (once-suffixed) paths - for display + calibration verdict
    store_raw, cal_raw = store_base, cal_base
    if agent_symbol != "XAU/USD":
        sp, cp = Path(store_base), Path(cal_base)
        store_raw = str(sp.with_name(f"{sp.stem}_{stem}{sp.suffix}"))
        cal_raw = str(cp.with_name(f"{cp.stem}_{stem}{cp.suffix}"))
    auc_cfg = dict(auc_cfg)
    # R15 BUG FIX (reproduced + regression-tested): AuctionFlowAgent applies
    # its own per-symbol suffixing ONCE. Feeding it an already-suffixed path
    # made this tool read auction_flow_<x>_<x>.sqlite3 - a fresh EMPTY store -
    # and falsely report "heartbeat NEVER written" for healthy symbols.
    # Inject the BASE paths; the agent does the suffixing.
    auc_cfg["storage_path"] = store_base
    auc_cfg["calibration_path"] = cal_base
    cfg["auction_flow"] = auc_cfg
    if isinstance(inst_cfg, dict) and inst_cfg.get("auction_flow"):
        merged = dict(inst_cfg["auction_flow"])
        merged.update({k: v for k, v in auc_cfg.items() if k in ("storage_path", "calibration_path")})
        cfg["auction_flow"] = merged

    result = {"symbol": symbol, "agent_symbol": agent_symbol,
              "store_path": store_raw, "calibration_path": cal_raw}

    # -- gate 1: calibration ----------------------------------------------
    required = bool(cfg.get("auction_flow", {}).get(
        "calibration_required", True))
    ok, reasons = calibration_verdict(Path(cal_raw), cfg, agent_symbol)
    result["calibration_required"] = required
    result["calibration_valid"] = ok
    result["calibration_checks"] = reasons
    if required and not ok:
        result["verdict"] = "WAIT/CALIBRATION_INVALID -> displayed 50% (WAIT floor)"
        result["fix"] = HINTS["CALIBRATION_INVALID"]
        return result

    # -- gate 2: live data problem (same code as the agent) ---------------
    try:
        agent = AuctionFlowAgent(cfg)
    except Exception as exc:  # noqa: BLE001
        result["verdict"] = f"agent construction failed: {exc}"
        result["fix"] = "check the auction_flow section of config.json"
        return result
    pv = point_size(symbol, config)
    try:
        state = agent.store.flow_state(
            session_timezone=str(auc_cfg.get("session_timezone") or "Asia/Hebron"),
            point_value=pv,
            profile_bin_points=float(auc_cfg.get("profile_bin_points", 10) or 10),
            value_area_pct=float(auc_cfg.get("value_area_pct", 70) or 70),
        )
    except Exception as exc:  # noqa: BLE001
        result["verdict"] = f"store unreadable: {exc}"
        result["fix"] = HINTS["SESSION_PROFILE_INCOMPLETE"]
        return result
    problem = agent._data_problem(state, pv, symbol)  # noqa: SLF001
    health = state.get("health") or {}
    cap = max_spread_points_for(symbol, config)
    spread_pts = float(health.get("current_spread", 0) or 0) / max(pv, 1e-9)
    # heartbeat == inf means the key was NEVER written: the aux collector
    # init (which marks a heartbeat at startup) has not run against this
    # store in ANY process - i.e. the running manager predates the aux loop
    # or crashed before it. A large-but-finite age means stale-but-seen.
    def _age(value):
        return None if value == math.inf else round(float(value or 0), 1)

    result["health"] = {
        "last_tick_age_seconds": _age(health.get("last_tick_age_seconds")),
        "heartbeat_age_seconds": _age(health.get("heartbeat_age_seconds")),
        "heartbeat_never_written": health.get("heartbeat_age_seconds") == math.inf,
        "unique_ticks_5m": int(health.get("unique_ticks_5m", 0) or 0),
        "spread_points_now": round(spread_pts, 1),
        "spread_cap_points": cap,
    }
    if problem:
        result["verdict"] = f"WAIT/{problem[0]} -> displayed 50% (WAIT floor)"
        result["detail"] = problem[1]
        result["fix"] = HINTS.get(problem[0], "see agents/auction_flow_agent.py")
        return result

    result["verdict"] = ("data gates CLEAR (calibration + ticks + spread). "
                         "Remaining live-only gates: native timeframe book and "
                         "session VWAP/POC completeness - check the next live "
                         "cycle; a healthy agent scores 50..95, never a flat 50.")
    return result


def main():
    ap = argparse.ArgumentParser(description="Auction-flow agent gate diagnosis")
    ap.add_argument("--root", default=str(ROOT))
    ap.add_argument("--symbols", default=None, help="comma list (default: all enabled)")
    ap.add_argument("--json", dest="json_out", default=None)
    args = ap.parse_args()
    root = Path(args.root)

    config = json.loads((root / "config.json").read_text(encoding="utf-8"))
    if args.symbols:
        symbols = [s.strip() for s in args.symbols.split(",") if s.strip()]
    else:
        symbols = [str(i.get("symbol")) for i in (config.get("instruments") or [])
                   if isinstance(i, dict) and i.get("enabled", True)]

    print("=" * 100)
    print(" AUCTION-FLOW AGENT DIAGNOSIS  (50% = WAIT display floor, by design -")
    print(" agents/auction_flow_agent.py::_wait publishes confidence=50 for ANY outage)")
    print("=" * 100)
    report = {"generated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
              "symbols": {}}
    for symbol in symbols:
        r = diagnose_symbol(root, config, symbol)
        report["symbols"][symbol] = r
        print(f"\n {symbol}")
        print("-" * 100)
        print(f"   calibration_required : {r.get('calibration_required')}")
        for check in r.get("calibration_checks", []):
            print(f"   calibration          : {check}")
        h = r.get("health") or {}
        if h:
            if h.get("heartbeat_never_written"):
                print("   NOTE: heartbeat NEVER written -> the running tick manager")
                print("         never ran its aux init (old-code process or crashed start).")
            print(f"   last_tick_age        : {h['last_tick_age_seconds']}s  (limit "
                  f"{(config.get('auction_flow') or {}).get('max_tick_age_seconds', 5)}s)")
            print(f"   heartbeat_age        : {h['heartbeat_age_seconds']}s  (limit "
                  f"{(config.get('auction_flow') or {}).get('max_heartbeat_age_seconds', 10)}s)")
            print(f"   unique_ticks_5m      : {h['unique_ticks_5m']}  (limit "
                  f"{(config.get('auction_flow') or {}).get('min_unique_ticks_5m', 60)})")
            print(f"   spread now / cap     : {h['spread_points_now']} / {h['spread_cap_points']} pts")
        print(f"   VERDICT: {r.get('verdict')}")
        if r.get("detail"):
            print(f"   detail : {r['detail']}")
        if r.get("fix"):
            print(f"   FIX    : {r['fix']}")
    print("\n" + "=" * 100)
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(report, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
        print("JSON report written: %s" % args.json_out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
