"""Why is there no READY map or WATCH map? — read-only diagnostic.

Answers, from today's stored session-plan snapshots and the live agent book,
exactly which gate is refusing:

  GATE 1  Day-map authority   (needs 2 aligned sources: daily_bias / macro /
                               structure / reversal_watch — or 1 + sweep+zone)
  GATE 2  Structural floor    (needs >=2 qualified core agents aligned with
                               the map side + complete zone/stop/target)
  GATE 3  Execution admission (Paths 1/2/3/5 net >=72% or Path 4 map+auction)
  GATE 4  Watch-map display   (blocked admission but 2 agents, net>=72,
                               opposition<=1, complete levels)

Usage:  python scripts/why_no_map.py            (today)
        python scripts/why_no_map.py --last 20  (last 20 snapshots)
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from utils.helpers import load_config  # noqa: E402


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _load_plans() -> List[Dict[str, Any]]:
    path = ROOT / "storage" / "session_plans.json"
    if not path.exists():
        return []
    try:
        rows = json.loads(path.read_text(encoding="utf-8"))
        return [r for r in rows if isinstance(r, dict)]
    except (ValueError, OSError):
        return []


def _stamp(row: Dict[str, Any]) -> str:
    return str(row.get("analysis_run_at") or row.get("updated_at") or row.get("created_at") or "")


def _today(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    today = datetime.now(timezone.utc).date().isoformat()
    return [r for r in rows if _stamp(r)[:10] == today]


def _payload(row: Dict[str, Any]) -> Dict[str, Any]:
    p = row.get("payload")
    return p if isinstance(p, dict) else row


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--last", type=int, default=0, help="inspect the last N snapshots instead of today's")
    args = parser.parse_args()

    config = load_config()
    rows = _load_plans()
    if not rows:
        print("NO SNAPSHOTS AT ALL in storage/session_plans.json")
        print("=> The analysis cycle is not reaching the planner. Check that")
        print("   SS_DemoAnalysis runs every 5 minutes and logs\\demo_analysis.log")
        print("   shows cycles completing (no MT5/data errors at the top).")
        return 1

    rows.sort(key=_stamp)
    sample = rows[-args.last:] if args.last else _today(rows)
    if not sample:
        print(f"No snapshots for today (total stored: {len(rows)}, "
              f"latest: {_stamp(rows[-1])})")
        sample = rows[-10:]
        print("Falling back to the last 10 snapshots:\n")

    print("=" * 74)
    print(f"MAP REFUSAL DIAGNOSIS — {len(sample)} snapshot(s) "
          f"({_stamp(sample[0])[:16]} .. {_stamp(sample[-1])[:16]})")
    print("=" * 74)

    gate_counter: Counter[str] = Counter()
    reason_counter: Counter[str] = Counter()

    for row in sample:
        plan = _payload(row)
        ready = bool(plan.get("plan_ready"))
        status = str(plan.get("plan_status") or "?")
        reason = str(plan.get("plan_reason") or "")
        side = str(plan.get("session_bias") or plan.get("authority_direction") or "-")
        admission = plan.get("execution_admission") or {}
        adm_allow = bool(admission.get("allow"))
        adm_path = admission.get("path")
        support = int(_f(admission.get("support_count")))
        oppose = int(_f(admission.get("opposition_count")))
        net = _f(admission.get("confidence"))
        authority = plan.get("authority") or {}
        auth_state = str(authority.get("state") or plan.get("authority_state") or "?")
        auth_count = int(_f(authority.get("count") or plan.get("authority_count")))
        auth_sources = authority.get("sources") or []

        # Which gate refused?
        if ready and adm_allow:
            gate = "PASSED_ALL (order path open)"
        elif ready and not adm_allow:
            if support >= 2 and net >= 65 and oppose <= 1:
                gate = "GATE4? ready+2 agents+net>=72 — watch map SHOULD have been sent (check delivery log)"
            else:
                gate = f"GATE3 execution admission (support={support} net={net:.0f}% oppose={oppose})"
        elif "authority" in reason.lower() or "directional authority" in reason.lower() or auth_state in {"WEAK", "CONFLICTED"}:
            gate = f"GATE1 authority {auth_state} ({auth_count} source(s): {','.join(auth_sources) or '-'})"
        else:
            gate = f"GATE2 structural floor / other ({status})"
        gate_counter[gate.split(" (")[0]] += 1
        if reason:
            reason_counter[reason[:90]] += 1

    print("\nGATE SUMMARY (which wall refused, how often):")
    for gate, count in gate_counter.most_common():
        print(f"  {count:>3}x  {gate}")

    print("\nTOP REFUSAL REASONS (planner's own words):")
    for reason, count in reason_counter.most_common(6):
        print(f"  {count:>3}x  {reason}")

    # Latest snapshot in full detail
    plan = _payload(sample[-1])
    admission = plan.get("execution_admission") or {}
    authority = plan.get("authority") or {}
    print("\n" + "-" * 74)
    print(f"LATEST SNAPSHOT DETAIL  ({_stamp(sample[-1])[:19]})")
    print("-" * 74)
    print(f"  plan_ready / status : {plan.get('plan_ready')} / {plan.get('plan_status')}")
    print(f"  plan_reason         : {plan.get('plan_reason')}")
    print(f"  side / scenario     : {plan.get('session_bias') or '-'} / {plan.get('scenario_type') or '-'}")
    print(f"  GATE1 authority     : state={authority.get('state') or plan.get('authority_state')} "
          f"count={authority.get('count')} sources={authority.get('sources')}")
    print(f"        reason        : {authority.get('reason')}")
    print(f"  GATE3 admission     : allow={admission.get('allow')} path={admission.get('path')}")
    print(f"        support/net   : {admission.get('support_count')} agents, "
          f"net {admission.get('confidence')}%, opposition {admission.get('opposition_count')}")
    print(f"        supporters    : {admission.get('supporters')}")
    print(f"        opponents     : {admission.get('opponents')}")
    zone = plan.get("primary_entry_zone") or {}
    print(f"  levels              : zone {zone.get('low')}..{zone.get('high')} | "
          f"entry {plan.get('primary_entry_price')} | "
          f"stop {(plan.get('primary_execution') or {}).get('stop_loss') or plan.get('invalidation_level')} | "
          f"target {(plan.get('primary_execution') or {}).get('tp2') or plan.get('target_liquidity')}")

    # What is needed NOW, from the live agent book?
    print("\n" + "-" * 74)
    print("LIVE BOOK RIGHT NOW (what is missing for each gate)")
    print("-" * 74)
    shared_path = ROOT / "storage" / "shared_market_data.json"
    if not shared_path.exists():
        print("  no shared snapshot on disk — run one analysis cycle first")
        return 0
    try:
        data = json.loads(shared_path.read_text(encoding="utf-8"))
    except (ValueError, OSError) as exc:
        print(f"  cannot read shared snapshot: {exc}")
        return 0

    from agents.classical_agent import ClassicalAgent
    from agents.multitimeframe_agent import MultiTimeframeAgent
    from agents.price_action_agent import PriceActionAgent
    from agents.smc_agent import SMCAgent
    from agents.technical_agent import TechnicalAgent
    from agents.auction_flow_agent import AuctionFlowAgent
    from services.thesis_consensus import evaluate_directional_admission

    core = {
        "technical": TechnicalAgent, "multitimeframe": MultiTimeframeAgent,
        "classical": ClassicalAgent, "smc": SMCAgent,
        "price_action": PriceActionAgent, "auction_flow": AuctionFlowAgent,
    }
    results: Dict[str, Dict[str, Any]] = {}
    for name, cls in core.items():
        try:
            results[name] = cls(config).analyze(data)
        except Exception as exc:  # noqa: BLE001
            results[name] = {"signal": "ERROR", "confidence": 0, "error": str(exc)}

    min_conf = _f((config.get("signal_requirements") or {}).get("agent_min_confidence"), 67)
    print(f"  agent bar: {min_conf:.0f}%")
    for name, r in results.items():
        side = str(r.get("signal") or r.get("direction") or "WAIT").upper()
        conf = _f(r.get("confidence"))
        q = "QUALIFIED" if side in {"BUY", "SELL"} and conf >= min_conf else "-"
        err = f"  !! {r.get('error')}" if r.get("error") else ""
        print(f"  {name:<15} {side:<5} {conf:5.1f}%  {q}{err}")

    net_floor = _f((config.get("signal_requirements") or {}).get("min_consensus_confidence"), 72)
    for target in ("BUY", "SELL"):
        adm = evaluate_directional_admission(target, results, config)
        need = []
        if int(_f(adm.get("support_count"))) < 2:
            need.append(f"needs {2 - int(_f(adm.get('support_count')))} more qualified supporter(s)")
        if _f(adm.get("confidence")) < net_floor:
            need.append(f"net {adm.get('confidence')}% below {net_floor:.0f}%")
        if adm.get("allow"):
            need = [f"ADMITTED via {adm.get('path')}"]
        print(f"  {target}: support={adm.get('support_count')} net={adm.get('confidence')}% "
              f"oppose={adm.get('opposition_count')} -> {'; '.join(need)}")

    print("\nHOW TO READ THIS:")
    print("  GATE1 refusals = market context itself is split (bias/macro/structure")
    print("        disagree). Nothing is broken; the planner is refusing correctly.")
    print("  GATE3 refusals with support=2 and net just under 72 = the watch map is")
    print("        one qualified agent (or a few net points) away.")
    print("  If a gate says PASSED/SHOULD-HAVE-SENT but Telegram is silent, check")
    print("        logs\\demo_analysis.log for 'Session plan Telegram suppressed'.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
