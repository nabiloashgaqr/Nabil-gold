# =============================================================================
# Auto-Synchronize Daily & Weekly Report to Asia/Hebron Timezone (ASCII only)
# =============================================================================

[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host " SYNCHRONIZING DAILY AND WEEKLY REPORT TO 23:50 (ASIA/HEBRON)" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# 1. Get current server time and timezone
$serverTz = [System.TimeZoneInfo]::Local
$serverNow = [System.DateTime]::Now
$utcNow = [System.DateTime]::UtcNow

Write-Host "[*] Server Local Time: $($serverNow.ToString('yyyy-MM-dd HH:mm:ss')) ($($serverTz.Id))"
Write-Host "[*] Server UTC Time:   $($utcNow.ToString('yyyy-MM-dd HH:mm:ss')) (UTC)"

# 2. Find Asia/Hebron TimeZone (DST-aware only - BUILD 31 R10)
# R10 fix: the old fallback created a FIXED UTC+3 zone, which drifted one
# full hour every winter (Hebron observes DST: UTC+2 winter / UTC+3 summer).
# Jordan Standard Time carries the closest DST rules to Hebron; Middle East
# Standard Time (Beirut) is the second candidate. If neither exists the
# script now FAILS LOUDLY instead of silently scheduling an hour off.
$hebronTz = $null
try {
    $hebronTz = [System.TimeZoneInfo]::FindSystemTimeZoneById("Jordan Standard Time")
} catch {
    try {
        $hebronTz = [System.TimeZoneInfo]::FindSystemTimeZoneById("Middle East Standard Time")
    } catch {
        Write-Host "[FAIL] No DST-aware timezone matching Asia/Hebron found on this server." -ForegroundColor Red
        Write-Host "       Refusing to fall back to a fixed UTC+3 zone (winter drift risk)." -ForegroundColor Red
        Write-Host "       Install the matching Windows timezone update or schedule manually." -ForegroundColor Red
        Exit 1
    }
}

if ($null -eq $hebronTz) {
    Write-Host "[FAIL] Asia/Hebron-equivalent timezone could not be resolved." -ForegroundColor Red
    Exit 1
}

$hebronNow = [System.TimeZoneInfo]::ConvertTimeFromUtc($utcNow, $hebronTz)
Write-Host "[*] Hebron Local Time: $($hebronNow.ToString('yyyy-MM-dd HH:mm:ss')) (Asia/Hebron)"

# 3. Calculate target 23:50 Hebron time converted to Server Local Time
$todayHebron = $hebronNow.Date
$targetHebronTime = $todayHebron.AddHours(23).AddMinutes(50)
$targetUtcTime = [System.TimeZoneInfo]::ConvertTimeToUtc($targetHebronTime, $hebronTz)
$targetServerLocal = [System.TimeZoneInfo]::ConvertTimeFromUtc($targetUtcTime, $serverTz)

$dailyTriggerTime = $targetServerLocal.ToString("HH:mm")

# Target 23:55 Hebron for Weekly Report (Friday)
$targetWeeklyHebron = $todayHebron.AddHours(23).AddMinutes(55)
$targetWeeklyUtc = [System.TimeZoneInfo]::ConvertTimeToUtc($targetWeeklyHebron, $hebronTz)
$targetWeeklyServer = [System.TimeZoneInfo]::ConvertTimeFromUtc($targetWeeklyUtc, $serverTz)
$weeklyTriggerTime = $targetWeeklyServer.ToString("HH:mm")

Write-Host ""
Write-Host "[+] CALCULATED SCHEDULED TASK TRIGGERS:" -ForegroundColor Green
Write-Host "    - Target Hebron Time: 23:50 Asia/Hebron" -ForegroundColor Green
Write-Host "    - Server Trigger Time: $dailyTriggerTime (VPS local clock)" -ForegroundColor Green
Write-Host "    - Weekly Trigger Time: $weeklyTriggerTime (Fridays)" -ForegroundColor Green

# 4. Re-create Scheduled Tasks cleanly
$repoRoot = (Get-Location).Path
$tasksDir = Join-Path $repoRoot "deploy\tasks"
if (-not (Test-Path $tasksDir)) {
    $tasksDir = "C:\Nabil-gold\deploy\tasks"
}

$dailyBat = Join-Path $tasksDir "daily_report_demo.bat"
$weeklyBat = Join-Path $tasksDir "weekly_report_demo.bat"

Write-Host ""
Write-Host "[*] Updating Windows Task Scheduler..." -ForegroundColor Yellow

# Delete duplicate tasks if any exist
try { schtasks /Delete /TN "SS_DailyReport" /F 2>$null } catch {}
try { schtasks /Delete /TN "SS_WeeklyReport" /F 2>$null } catch {}

# Create single accurate task
schtasks /Create /TN "SS_DailyReport" /SC DAILY /ST $dailyTriggerTime /TR "cmd /c `"$dailyBat`"" /RL HIGHEST /F | Out-Null
schtasks /Create /TN "SS_WeeklyReport" /SC WEEKLY /D FRI /ST $weeklyTriggerTime /TR "cmd /c `"$weeklyBat`"" /RL HIGHEST /F | Out-Null

Write-Host "[OK] SS_DailyReport locked to trigger at exactly 23:50 Hebron time." -ForegroundColor Green
Write-Host "     VPS Trigger Time: $dailyTriggerTime" -ForegroundColor Green
Write-Host "[OK] SS_WeeklyReport locked to trigger at exactly 23:55 Hebron time." -ForegroundColor Green
Write-Host "     VPS Trigger Time: $weeklyTriggerTime" -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Cyan
