"""Summarize the non-trading one-day agent measurement JSONL."""
from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from utils.helpers import load_config


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _corr(xs: List[float], ys: List[float]) -> float | None:
    if len(xs) < 3 or len(xs) != len(ys):
        return None
    mx, my = statistics.mean(xs), statistics.mean(ys)
    dx = [x - mx for x in xs]
    dy = [y - my for y in ys]
    den = math.sqrt(sum(x*x for x in dx) * sum(y*y for y in dy))
    return sum(x*y for x, y in zip(dx, dy)) / den if den else None


def _source(config: Dict[str, Any], date: str | None) -> Path:
    base = Path(str((config.get("agent_measurement") or {}).get("storage_dir") or "storage/agent_measurements"))
    if not base.is_absolute():
        base = ROOT / base
    if date:
        return base / f"agent_system_{date}.jsonl"
    rows = sorted(base.glob("agent_system_*.jsonl"))
    if not rows:
        raise SystemExit(f"No measurement files under {base}")
    return rows[-1]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", default=None)
    args = parser.parse_args()
    config = load_config()
    source = _source(config, args.date)
    rows = []
    for line in source.read_text(encoding="utf-8").splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if isinstance(row, dict):
            rows.append(row)
    if not rows:
        raise SystemExit(f"No valid rows in {source}")

    agents = {}
    for name in ("technical", "multitimeframe", "classical", "smc", "price_action", "auction_flow"):
        vals = [(row.get("agents") or {}).get(name) or {} for row in rows]
        conf = [_f(v.get("confidence")) for v in vals]
        agents[name] = {
            "qualified_count": sum(bool(v.get("qualified")) for v in vals),
            "qualified_pct": round(sum(bool(v.get("qualified")) for v in vals) / len(vals) * 100, 2),
            "confidence_min": round(min(conf), 2),
            "confidence_max": round(max(conf), 2),
            "confidence_median": round(statistics.median(conf), 2),
            "directions": dict(Counter(str(v.get("direction") or "WAIT") for v in vals)),
        }

    fusion = {}
    for name in ("classical", "smc", "price_action"):
        values = [(row.get("fusion") or {}).get(name) or {} for row in rows]
        fusion[name] = {
            "conflict_wait_count": sum(bool(v.get("conflict_wait")) for v in values),
            "pre67_post_below67": sum(
                _f(v.get("pre_participation_confidence")) >= 67 and _f(v.get("confidence")) < 67
                for v in values
            ),
            "directional_count_distribution": dict(Counter(str(v.get("directional_count", 0)) for v in values)),
        }

    smc_values = [row.get("smc_measurement") or {} for row in rows]
    auction_values = [row.get("auction_measurement") or {} for row in rows]
    activity = [_f(v.get("activity_ratio")) for v in auction_values]
    offsets = sorted(set(int(_f(v.get("broker_offset_seconds"))) for v in auction_values))
    value_scores = [_f((v.get("family_scores") or {}).get("value_location")) for v in auction_values]
    acceptance_scores = [_f((v.get("family_scores") or {}).get("acceptance_rejection")) for v in auction_values]

    # Forward sampled outcomes at 1/2/4h from later measurement rows.
    parsed = []
    for row in rows:
        try:
            stamp = datetime.fromisoformat(str(row.get("generated_at")).replace("Z", "+00:00"))
        except Exception:
            continue
        parsed.append((stamp.astimezone(timezone.utc), _f(row.get("current_price")), row))
    forward = {"1h": [], "2h": [], "4h": []}
    for stamp, price, row in parsed:
        for label, hours in (("1h", 1), ("2h", 2), ("4h", 4)):
            future = next((p for t, p, _ in parsed if (t-stamp).total_seconds() >= hours*3600), None)
            if future is not None and price > 0:
                forward[label].append(round(future - price, 4))

    summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source": str(source),
        "rows": len(rows),
        "first": rows[0].get("generated_at"),
        "last": rows[-1].get("generated_at"),
        "agents": agents,
        "fusion": fusion,
        "smc": {
            "setup_rows": sum(bool(v.get("setup_type")) for v in smc_values),
            "quality_median": round(statistics.median([_f(v.get("quality")) for v in smc_values]), 2),
            "dominance_median": round(statistics.median([_f(v.get("dominance")) for v in smc_values]), 2),
        },
        "auction": {
            "states": dict(Counter(str(v.get("state") or "UNKNOWN") for v in auction_values)),
            "state_transitions": sum(
                str(auction_values[i].get("state")) != str(auction_values[i-1].get("state"))
                for i in range(1, len(auction_values))
            ),
            "activity_ratio_median": round(statistics.median(activity), 3),
            "activity_ratio_max": round(max(activity), 3),
            "broker_offsets": offsets,
            "value_acceptance_correlation": round(_corr(value_scores, acceptance_scores), 4) if _corr(value_scores, acceptance_scores) is not None else None,
        },
        "forward_price_changes": {
            key: {"samples": len(vals), "median_price_change": round(statistics.median(vals), 4) if vals else None}
            for key, vals in forward.items()
        },
        "trading_rules_changed": False,
    }
    out_dir = ROOT / "diagnostics"
    out_dir.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    json_path = out_dir / f"agent_measurement_summary_{stamp}.json"
    txt_path = out_dir / f"agent_measurement_summary_{stamp}.txt"
    json_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    lines = [
        "FIVE-AGENT NON-TRADING MEASUREMENT SUMMARY",
        "="*60,
        f"Source: {source}", f"Rows: {len(rows)}", f"Window: {summary['first']} -> {summary['last']}",
        "", "AGENTS",
    ]
    for name, data in agents.items():
        lines.append(f"- {name}: qualified {data['qualified_count']}/{len(rows)} ({data['qualified_pct']}%) conf {data['confidence_min']}..{data['confidence_max']} median {data['confidence_median']} directions={data['directions']}")
    lines += [
        "", "UNIFIED", f"- counterfactual crossed 67 while live did not: {counter_cross}",
        "", "FUSION", *[f"- {name}: {data}" for name, data in fusion.items()],
        "", "SMC", f"- {summary['smc']}",
        "", "AUCTION", f"- {summary['auction']}",
        "", "FORWARD OUTCOMES", f"- {summary['forward_price_changes']}",
        "", f"JSON: {json_path}", f"TXT : {txt_path}",
    ]
    txt_path.write_text("\n".join(lines)+"\n", encoding="utf-8")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
