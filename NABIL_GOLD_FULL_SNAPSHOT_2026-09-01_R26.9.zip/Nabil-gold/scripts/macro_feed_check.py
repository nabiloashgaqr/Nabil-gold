"""
scripts/macro_feed_check.py — macro feed health diagnostic (2026-08-19).

The 7-day measurement showed macro neutral in 93.5% of 1880 cycles while
PATH 2 (two-agent + macro) is the system's best-performing path (PF 7.86,
75% success, +3240 pts, n=24). A confirmer that feeds the profit engine
cannot be silent. This read-only check diagnoses WHY:

  1) storage/macro_context.json  - file age + source + freshness + fields
  2) live provider probe         - build_context() on the VPS right now,
                                    per-symbol success/failure/staleness

Usage:
  python scripts/macro_feed_check.py
  python scripts/macro_feed_check.py --probe    # include the live yfinance probe
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass


def _age_hours(iso: str | None) -> float | None:
    if not iso:
        return None
    try:
        then = datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
        return (datetime.now(timezone.utc) - then).total_seconds() / 3600.0
    except (TypeError, ValueError):
        return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--probe", action="store_true", help="live yfinance probe")
    parser.add_argument("--root", type=str, default=str(ROOT))
    args = parser.parse_args()

    root = Path(args.root)
    path = root / "storage" / "macro_context.json"
    print("=" * 74)
    print("MACRO FEED CHECK")
    print("=" * 74)
    if not path.exists():
        print("storage/macro_context.json MISSING - macro has no local context at all")
        print("-> it is written by the SCHEDULED scripts/update_macro_context.py, not the")
        print("   analysis cycle. Check that scheduled task exists and is running.")
        return 1

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        print(f"macro_context.json unreadable: {exc}")
        return 1

    stamp = data.get("updated_at") or data.get("created_at") or data.get("fetched_at")
    age = _age_hours(stamp)
    print(f"file age      : {age:.1f}h" if age is not None else "file age      : unknown")
    dq = data.get("data_quality") or {}
    print(f"source        : {dq.get('source') or data.get('source')}")
    print(f"freshness     : {dq.get('freshness')}")
    missing = dq.get("missing_fields") or data.get("missing_fields") or []
    print(f"missing fields: {missing if missing else 'none'}")

    # the fields macro_direction actually consumes
    consumed = ["dxy_trend", "us10y_trend", "real_yields_trend", "fed_tone",
                "inflation_surprise", "risk_sentiment", "oil_trend", "vix_level"]
    print("-" * 74)
    print("fields consumed by MacroFundamentalAgent.macro_direction():")
    unknown = 0
    for key in consumed:
        value = data.get(key)
        if value is None:
            value = (data.get("trends") or {}).get(key) if isinstance(data.get("trends"), dict) else None
        status = str(value) if value is not None else "MISSING"
        if value is None or str(value).lower() in {"unknown", "flat", ""}:
            unknown += 1
        print(f"  {key:<22} = {status}")
    print("-" * 74)
    verdict = "FEED DEAD" if unknown >= 6 else "FEED WEAK" if unknown >= 3 else "FEED OK"
    print(f"VERDICT: {verdict} ({unknown}/8 fields missing/unknown -> macro is neutral)")
    if verdict != "FEED OK":
        print("ACTION: the neutral macro comes from this file's inputs, not the agent.")
        print("  Check: is the update_macro_context scheduled task running (Task Scheduler)?")
        print("  Check: yfinance reachability from this VPS (pip list | findstr yfinance).")
        print("  Then run --probe to test the provider live.")

    if args.probe:
        print()
        print("LIVE PROVIDER PROBE (services.macro_data_provider.build_context):")
        try:
            from services.macro_data_provider import MacroDataProvider

            provider = MacroDataProvider({"data_source": {}})
            context = provider.build_context()
            dq2 = context.get("data_quality") or {}
            print(f"  source        : {dq2.get('source')}")
            print(f"  freshness     : {dq2.get('freshness')}")
            print(f"  missing_fields: {dq2.get('missing_fields') or 'none'}")
            print(f"  fx_symbols    : {dq2.get('fx_symbols')}")
            trends = {k: v for k, v in context.items() if "trend" in k or k in
                      ("fed_tone", "inflation_surprise", "risk_sentiment")}
            for k, v in sorted(trends.items()):
                print(f"  {k:<22} = {v}")
        except Exception as exc:  # noqa: BLE001
            print(f"  probe failed: {exc}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
