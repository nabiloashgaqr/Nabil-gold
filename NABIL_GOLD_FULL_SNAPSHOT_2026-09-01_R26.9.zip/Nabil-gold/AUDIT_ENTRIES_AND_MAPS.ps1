# =============================================================================
# Run Forensic Audit of Multi-Pair Trades, Maps and Agents (ASCII only)
# =============================================================================

[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

# 0. Sanity: must run in repo root
if (-not (Test-Path "config.json")) {
    Write-Host "ERROR: run this script inside the repo root (C:\Nabil-gold)." -ForegroundColor Red
    Exit 1
}

# 1. Run Python forensic audit
python scripts\audit_trade_entries_and_agents.py
