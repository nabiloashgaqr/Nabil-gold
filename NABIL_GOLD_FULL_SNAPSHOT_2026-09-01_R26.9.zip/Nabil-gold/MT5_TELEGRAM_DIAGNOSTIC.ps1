# Nabil-gold: read-only Telegram <-> DB <-> MT5 diagnostic
# Run in Windows PowerShell as Administrator.
# This script does NOT place, modify, or close any order and does NOT print secrets.

param(
    [string]$Repo = "C:\Nabil-gold"
)

$ErrorActionPreference = "Continue"
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"
try { [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false) } catch {}

if (-not (Test-Path $Repo)) {
    Write-Error "Repository not found: $Repo"
    exit 1
}

Set-Location $Repo
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$diagDir = Join-Path $Repo "diagnostics"
New-Item -ItemType Directory -Force -Path $diagDir | Out-Null
$report = Join-Path $diagDir "mt5_telegram_$stamp.txt"

Start-Transcript -Path $report -Force | Out-Null

function Section([string]$Title) {
    Write-Host ""
    Write-Host ("=" * 88)
    Write-Host $Title
    Write-Host ("=" * 88)
}

Section "1) CLOCK / REPOSITORY"
Write-Host "Local: $((Get-Date).ToString('o'))"
Write-Host "UTC:   $([DateTime]::UtcNow.ToString('o'))"
Write-Host "Repo:  $Repo"
try {
    Write-Host "Branch: $(git branch --show-current)"
    Write-Host "Commit: $(git rev-parse HEAD)"
    git status --short --branch
} catch { Write-Host "git check failed: $_" }

Section "2) SCHEDULED TASKS"
$taskNames = @(
    "SS_DemoAnalysis", "SS_TickManager", "SS_DemoLoop", "SS_DemoWatchdog",
    "SS_MT5Terminal", "SS_MarketStatus", "SS_MacroContext",
    "SS_DailyReport", "SS_Dashboard", "SS_WeeklyReport"
)
$taskRows = foreach ($name in $taskNames) {
    try {
        $task = Get-ScheduledTask -TaskName $name -ErrorAction Stop
        $info = Get-ScheduledTaskInfo -TaskName $name -ErrorAction Stop
        [pscustomobject]@{
            Task = $name
            State = $task.State
            LastRun = $info.LastRunTime
            LastResult = $info.LastTaskResult
            NextRun = $info.NextRunTime
        }
    } catch {
        [pscustomobject]@{Task=$name; State="MISSING"; LastRun=$null; LastResult=$null; NextRun=$null}
    }
}
$taskRows | Format-Table -AutoSize

Section "3) LIVE PYTHON / MT5 PROCESSES"
try {
    Get-CimInstance Win32_Process |
        Where-Object { $_.Name -match '^(python|pythonw|terminal64)\.exe$' } |
        Select-Object Name, ProcessId, CreationDate, CommandLine |
        Format-List
} catch { Write-Host "Process query failed: $_" }

Section "4) PID FILE OWNERS"
foreach ($pidFile in @("tick_manager.pid", "demo_loop.pid")) {
    Write-Host "--- $pidFile ---"
    if (-not (Test-Path $pidFile)) {
        Write-Host "MISSING"
        continue
    }
    $rawPid = (Get-Content $pidFile -Raw).Trim()
    Write-Host "pidfile value: $rawPid"
    try {
        $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$rawPid" -ErrorAction Stop
        if ($proc) {
            $proc | Select-Object Name, ProcessId, CreationDate, CommandLine | Format-List
        } else {
            Write-Host "STALE: no process owns PID $rawPid"
        }
    } catch {
        Write-Host "STALE/UNREADABLE: no process owns PID $rawPid"
    }
}

Section "5) HEARTBEATS"
foreach ($hb in @("tick_heartbeat.json", "heartbeat.json")) {
    Write-Host "--- $hb ---"
    if (-not (Test-Path $hb)) {
        Write-Host "MISSING"
        continue
    }
    $item = Get-Item $hb
    $raw = Get-Content $hb -Raw
    Write-Host "Length=$($item.Length) LastWriteUTC=$($item.LastWriteTimeUtc.ToString('o')) Raw=[$raw]"
    try {
        $obj = $raw | ConvertFrom-Json -ErrorAction Stop
        $ts = [DateTimeOffset]::Parse([string]$obj.ts)
        $age = ([DateTimeOffset]::UtcNow - $ts.ToUniversalTime()).TotalSeconds
        Write-Host ("Parsed ts={0} age={1:N1}s" -f $ts.ToString('o'), $age)
    } catch {
        Write-Host "INVALID HEARTBEAT JSON: $_"
    }
}

Section "6) HALT FILE"
if (Test-Path ".demo_halt") {
    Write-Host "DEMO IS HALTED:"
    Get-Content ".demo_halt" -Raw
} else {
    Write-Host "No .demo_halt file"
}

Section "7) SAFE EFFECTIVE ENVIRONMENT (values are never printed)"
$envFile = Join-Path $Repo ".env"
if (Test-Path $envFile) {
    $safeNames = @(
        "EXECUTION_MODE", "TRADES_TABLE", "DATA_SOURCE_PRIMARY",
        "SUPABASE_URL", "SUPABASE_KEY", "TELEGRAM_BOT_TOKEN",
        "TELEGRAM_CHAT_ID", "TELEGRAM_DEMO_CHAT_ID",
        "MT5_PATH", "MT5_LOGIN", "MT5_PASSWORD", "MT5_SERVER"
    )
    $envLines = Get-Content $envFile
    foreach ($name in $safeNames) {
        $line = $envLines | Where-Object { $_ -match "^\s*$([regex]::Escape($name))\s*=" } | Select-Object -Last 1
        if (-not $line) {
            Write-Host "$name = MISSING/COMMENTED"
        } else {
            $value = ($line -split '=', 2)[1].Trim()
            if ($value) { Write-Host "$name = SET" } else { Write-Host "$name = EMPTY" }
        }
    }
} else {
    Write-Host ".env MISSING"
}

Section "8) LOG FILE STATUS"
foreach ($log in @(
    "logs\tick_manager.log", "logs\demo_analysis.log", "logs\demo_loop.log",
    "logs\demo_watchdog.log", "logs\market_status.log"
)) {
    if (Test-Path $log) {
        $item = Get-Item $log
        Write-Host "$log | bytes=$($item.Length) | lastWriteUTC=$($item.LastWriteTimeUtc.ToString('o'))"
    } else {
        Write-Host "$log | MISSING"
    }
}

Section "9) TICK MANAGER LOG: LAST 250 LINES"
if (Test-Path "logs\tick_manager.log") {
    Get-Content "logs\tick_manager.log" -Tail 250
} else {
    Write-Host "logs\tick_manager.log is MISSING"
}

Section "10) ANALYSIS DELIVERY / SAVE EVENTS: LAST 24H TAIL"
if (Test-Path "logs\demo_analysis.log") {
    Get-Content "logs\demo_analysis.log" -Tail 1200 |
        Select-String -Pattern "telegram delivered|trade_id|TRADE_|signal|order|save|ladder created|Cancelled|ERROR|WARNING|Traceback" |
        ForEach-Object { $_.Line }
} else {
    Write-Host "logs\demo_analysis.log is MISSING"
}

Section "11) WATCHDOG ERRORS: LAST 120 LINES"
if (Test-Path "logs\demo_watchdog.log") {
    Get-Content "logs\demo_watchdog.log" -Tail 120
} else {
    Write-Host "logs\demo_watchdog.log is MISSING"
}

Section "12) LIVE DB <-> MT5 READ-ONLY CORRELATION"
$pythonCode = @'
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(r"C:\Nabil-gold")
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env", override=False)
except Exception as exc:
    print("dotenv warning:", repr(exc))

# Emulate the scheduled tick-manager wrapper without exposing secret values.
os.environ["EXECUTION_MODE"] = "mt5_demo"
os.environ["TRADES_TABLE"] = "trades_demo"
os.environ["DATA_SOURCE_PRIMARY"] = "mt5"

print("Python:", sys.version.replace("\n", " "))
for name in (
    "EXECUTION_MODE", "TRADES_TABLE", "DATA_SOURCE_PRIMARY", "SUPABASE_URL",
    "SUPABASE_KEY", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID",
    "TELEGRAM_DEMO_CHAT_ID", "MT5_PATH", "MT5_LOGIN", "MT5_PASSWORD", "MT5_SERVER",
):
    value = os.environ.get(name, "")
    print(f"ENV {name}: {'SET' if value else 'EMPTY'}")

from utils.helpers import load_config
from services.database import DatabaseService
from services.mt5_executor import magic_for

cfg = load_config()
db = DatabaseService(cfg)
print("DB backend:", "SUPABASE" if db.use_supabase else "LOCAL_JSON")
print("DB table:", db.trades_table)
print("DB local path:", db.local_path)

try:
    active = list(db.get_open_trades() or [])
except Exception as exc:
    print("DB get_open_trades FAILED:", repr(exc))
    active = []

try:
    recent = list(db.get_recent_trades(limit=30) or [])
except Exception as exc:
    print("DB get_recent_trades FAILED:", repr(exc))
    recent = []

by_id = {}
for row in recent + active:
    if row.get("id"):
        by_id[str(row["id"])] = row
rows = list(by_id.values())
rows.sort(key=lambda r: str(r.get("created_at") or r.get("entry_time") or ""), reverse=True)
print("DB active rows:", len(active), "recent unique rows:", len(rows))

# Validate local JSON independently; a zero-byte/partial file is critical.
local_path = Path(db.local_path)
if local_path.exists():
    print("LOCAL FILE bytes:", local_path.stat().st_size, "mtimeUTC:", datetime.fromtimestamp(local_path.stat().st_mtime, tz=timezone.utc).isoformat())
    try:
        local_data = json.loads(local_path.read_text(encoding="utf-8"))
        print("LOCAL JSON valid: YES rows=", len(local_data) if isinstance(local_data, list) else "NOT_A_LIST")
    except Exception as exc:
        print("LOCAL JSON valid: NO", repr(exc))
else:
    print("LOCAL FILE: MISSING")

try:
    import MetaTrader5 as mt5
except Exception as exc:
    print("MetaTrader5 import FAILED:", repr(exc))
    raise SystemExit(0)

path = os.environ.get("MT5_PATH") or None
try:
    ok = mt5.initialize(path=path) if path else mt5.initialize()
except Exception as exc:
    print("mt5.initialize CRASHED:", repr(exc))
    ok = False
print("MT5 initialize:", ok, "last_error:", mt5.last_error())
if not ok:
    raise SystemExit(0)

account = mt5.account_info()
terminal = mt5.terminal_info()
mode_map = {
    getattr(mt5, "ACCOUNT_TRADE_MODE_DEMO", -100): "DEMO",
    getattr(mt5, "ACCOUNT_TRADE_MODE_CONTEST", -101): "CONTEST",
    getattr(mt5, "ACCOUNT_TRADE_MODE_REAL", -102): "REAL",
}
if account:
    print("ACCOUNT mode:", mode_map.get(getattr(account, "trade_mode", None), str(getattr(account, "trade_mode", None))))
    print("ACCOUNT trade_allowed:", getattr(account, "trade_allowed", None), "trade_expert:", getattr(account, "trade_expert", None))
    print("ACCOUNT server:", getattr(account, "server", None))
if terminal:
    print("TERMINAL connected:", getattr(terminal, "connected", None), "trade_allowed:", getattr(terminal, "trade_allowed", None))

positions = list(mt5.positions_get() or [])
orders = list(mt5.orders_get() or [])
print("MT5 positions:", len(positions), "orders:", len(orders))

pos_by_magic = {int(getattr(p, "magic", 0) or 0): p for p in positions}
ord_by_magic = {int(getattr(o, "magic", 0) or 0): o for o in orders}

def side_of_position(p):
    return "BUY" if getattr(p, "type", None) == getattr(mt5, "POSITION_TYPE_BUY", 0) else "SELL"

def order_side(o):
    typ = getattr(o, "type", None)
    buys = {
        getattr(mt5, "ORDER_TYPE_BUY", 0), getattr(mt5, "ORDER_TYPE_BUY_LIMIT", 2),
        getattr(mt5, "ORDER_TYPE_BUY_STOP", 4), getattr(mt5, "ORDER_TYPE_BUY_STOP_LIMIT", 6),
    }
    return "BUY" if typ in buys else "SELL"

def f(v):
    try: return float(v or 0.0)
    except Exception: return 0.0

def planned(row, key, default=0.0):
    snap = row.get("signal_snapshot") or {}
    sig = snap.get("signal") or {}
    if key == "entry":
        return f((sig.get("entry") or {}).get("price"))
    return f(sig.get(key, default))

print("\n--- CORRELATED RECENT ROWS (Telegram plan / DB / broker) ---")
known_magics = set()
for row in rows[:30]:
    tid = str(row.get("id") or "")
    mg = magic_for(tid)
    known_magics.add(mg)
    p = pos_by_magic.get(mg)
    o = ord_by_magic.get(mg)
    side = str(row.get("type") or row.get("side") or "").upper()
    status = str(row.get("status") or "")
    tg_entry = planned(row, "entry")
    tg_sl = planned(row, "stop_loss")
    tg_tp1 = planned(row, "tp1")
    tg_tp2 = planned(row, "tp2")
    print("\nID", tid)
    print("  created=", row.get("created_at"), "status=", status, "side=", side,
          "kind=", row.get("order_kind"), "order_type=", row.get("order_type"))
    print("  TELEGRAM_PLAN entry/sl/tp1/tp2 =", tg_entry, tg_sl, tg_tp1, tg_tp2)
    print("  DB             entry/sl/tp1/tp2 =", f(row.get("entry_price")), f(row.get("stop_loss")), f(row.get("tp1")), f(row.get("tp2")))
    print("  DB ticket=", row.get("mt5_ticket"), "magic=", mg,
          "partial=", row.get("partial_close"), "BE=", row.get("sl_moved_to_entry"),
          "req_exit=", row.get("requested_exit"), "req_partial=", row.get("requested_partial"))
    if p is not None:
        print("  MT5 POSITION ticket/type/vol/entry/current/sl/tp/profit =",
              getattr(p, "ticket", None), side_of_position(p), getattr(p, "volume", None),
              getattr(p, "price_open", None), getattr(p, "price_current", None),
              getattr(p, "sl", None), getattr(p, "tp", None), getattr(p, "profit", None))
    elif o is not None:
        print("  MT5 ORDER ticket/type/vol/price/sl/tp =",
              getattr(o, "ticket", None), order_side(o), getattr(o, "volume_current", getattr(o, "volume_initial", None)),
              getattr(o, "price_open", None), getattr(o, "sl", None), getattr(o, "tp", None))
    else:
        print("  MT5 = MISSING")

    issues = []
    active_status = status in {"OPEN", "PARTIAL", "TP1_HIT", "PENDING"}
    if active_status and p is None and o is None:
        issues.append("ACTIVE_DB_ROW_BUT_NOT_ON_MT5")
    if p is not None:
        if side and side != side_of_position(p): issues.append("SIDE_MISMATCH")
        if f(row.get("stop_loss")) and abs(f(row.get("stop_loss")) - f(getattr(p, "sl", 0))) > 0.05: issues.append("SL_MISMATCH")
        if f(row.get("tp2")) and abs(f(row.get("tp2")) - f(getattr(p, "tp", 0))) > 0.05: issues.append("TP2_MISMATCH")
        if row.get("mt5_ticket") and int(row.get("mt5_ticket")) != int(getattr(p, "ticket", 0)): issues.append("TICKET_MISMATCH")
    if o is not None:
        if side and side != order_side(o): issues.append("PENDING_SIDE_MISMATCH")
        if f(row.get("entry_price")) and abs(f(row.get("entry_price")) - f(getattr(o, "price_open", 0))) > 0.05: issues.append("PENDING_ENTRY_MISMATCH")
        if f(row.get("stop_loss")) and abs(f(row.get("stop_loss")) - f(getattr(o, "sl", 0))) > 0.05: issues.append("PENDING_SL_MISMATCH")
        if f(row.get("tp2")) and abs(f(row.get("tp2")) - f(getattr(o, "tp", 0))) > 0.05: issues.append("PENDING_TP2_MISMATCH")
    if issues:
        print("  !!! ISSUES:", ", ".join(issues))

print("\n--- BROKER SS-demo POSITIONS/ORDERS WITHOUT A RECENT DB MATCH ---")
orphans = 0
for kind, items in (("POSITION", positions), ("ORDER", orders)):
    for item in items:
        mg = int(getattr(item, "magic", 0) or 0)
        comment = str(getattr(item, "comment", "") or "")
        if (comment.startswith("SS-demo") or 1000000 <= mg <= 9999999) and mg not in known_magics:
            orphans += 1
            print(kind, "ticket=", getattr(item, "ticket", None), "magic=", mg,
                  "symbol=", getattr(item, "symbol", None), "comment=", comment,
                  "price=", getattr(item, "price_open", None), "sl=", getattr(item, "sl", None),
                  "tp=", getattr(item, "tp", None))
if not orphans:
    print("NONE")

print("\n--- RECENT SS-demo DEALS (48h) ---")
try:
    now = datetime.now(timezone.utc)
    deals = list(mt5.history_deals_get(now - timedelta(hours=48), now + timedelta(minutes=5)) or [])
    ss = [d for d in deals if str(getattr(d, "comment", "") or "").startswith("SS-demo") or 1000000 <= int(getattr(d, "magic", 0) or 0) <= 9999999]
    ss.sort(key=lambda d: int(getattr(d, "time", 0) or 0), reverse=True)
    if not ss:
        print("NONE")
    for d in ss[:80]:
        ts = datetime.fromtimestamp(int(getattr(d, "time", 0) or 0), tz=timezone.utc).isoformat()
        print(ts, "ticket=", getattr(d, "ticket", None), "position=", getattr(d, "position_id", getattr(d, "position", None)),
              "magic=", getattr(d, "magic", None), "entry=", getattr(d, "entry", None),
              "type=", getattr(d, "type", None), "vol=", getattr(d, "volume", None),
              "price=", getattr(d, "price", None), "profit=", getattr(d, "profit", None),
              "comment=", getattr(d, "comment", None))
except Exception as exc:
    print("history_deals_get FAILED:", repr(exc))

try:
    mt5.shutdown()
except Exception:
    pass
'@

$pythonCode | python -

Section "13) KNOWN CODE-RISK CHECKS (READ-ONLY)"
Write-Host "Signal delivery is currently before DB save:"
Select-String -Path "scripts\run_analysis.py" -Pattern "telegram.send_signal|database.save_trade" |
    Where-Object { $_.LineNumber -ge 2000 -or $_.LineNumber -ge 4700 } |
    Select-Object LineNumber, Line | Format-Table -AutoSize
Write-Host ""
Write-Host "Heartbeat writer around tick manager lines 217-225:"
Get-Content "scripts\run_tick_manager.py" | Select-Object -Skip 216 -First 10
Write-Host ""
Write-Host "Local JSON writer (non-atomic/no-lock) around helpers lines 175-191:"
Get-Content "utils\helpers.py" | Select-Object -Skip 174 -First 18

Section "DONE"
Write-Host "Report saved to: $report"
Write-Host "This was read-only. No order was placed, modified, or closed."

Stop-Transcript | Out-Null
Write-Host ""
Write-Host "REPORT: $report"
