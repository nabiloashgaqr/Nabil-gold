# -*- coding: utf-8 -*-
"""BUILD31-R16.2: promote ALL non-gold instruments to FULL auction
calibration (operator order: WTI joined the 4 forex pairs).

Flips instruments[].auction_flow.calibration_required -> true for
WTI/USD, EUR/USD, GBP/USD, USD/CAD, USD/JPY - but ONLY after that pair's
calibration file passes the SAME checks the agent applies (fail-closed):

  * file exists + parses
  * checksum matches (sha256 over the canonical JSON, same recipe the
    calibration builder signs with)
  * version == auction_flow.version
  * sample_count >= min_calibration_samples (default 300)
  * symbol inside the file matches the pair
  * logistic curve carries a and b

A pair whose file fails ANY check is LEFT at false and reported. Gold is
never touched (it is already required). Idempotent: already-true pairs are
skipped. Never overwrites anything else in config.json.

Usage (the installer runs this automatically):
    python APPLY_R16_PROMOTION.py --root C:\\Nabil-gold
"""
from __future__ import annotations

import argparse
import hashlib
import json
from collections import OrderedDict
from pathlib import Path

# All five non-gold instruments (operator 2026-08-27: promote WTI too, so
# every tradable pair is calibration-required like gold).
PROMOTION_PAIRS = ("WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")

DESCRIPTION = (
    "BUILD31-R16.2 (2026-08-27): operator-approved promotion. The auction agent "
    "is now REQUIRED (fail-closed) for these pairs exactly like gold: "
    "their trained calibrations exist and passed all checks. If a calibration "
    "file is ever missing/corrupt, that pair's agent WAITs (never fabricates) "
    "until the file is restored or the flag is set back to false."
)


def _canonical(raw: dict) -> bytes:
    return json.dumps(raw, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def validate_calibration(cal_path: Path, auction_cfg: dict, symbol: str):
    """Mirror AuctionFlowAgent._load_calibration with itemized reasons."""
    if not cal_path.exists():
        return False, [f"file MISSING: {cal_path.name}"]
    reasons = []
    try:
        raw = json.loads(cal_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return False, [f"unreadable JSON: {exc}"]
    supplied = str(raw.pop("checksum", "") or "")
    if hashlib.sha256(_canonical(raw)).hexdigest() != supplied:
        reasons.append("checksum mismatch (file edited or corrupt)")
    expected_version = str((auction_cfg or {}).get(
        "calibration_version", "auction_flow_v1"))
    if str(raw.get("version")) != expected_version:
        reasons.append(f"version {raw.get('version')} != expected {expected_version}")
    minimum = int((auction_cfg or {}).get("min_calibration_samples", 300) or 300)
    samples = int(raw.get("sample_count", 0) or 0)
    if samples < minimum:
        reasons.append(f"samples {samples} < required {minimum}")
    cal_symbol = str(raw.get("symbol") or "").upper().replace("/", "").replace(".S", "").rstrip(".")
    my_symbol = str(symbol).upper().replace("/", "")
    if cal_symbol and my_symbol not in cal_symbol and cal_symbol not in my_symbol:
        reasons.append(f"symbol mismatch: file is for {cal_symbol}")
    logistic = raw.get("logistic") or {}
    if "a" not in logistic or "b" not in logistic:
        reasons.append("logistic curve missing a/b")
    return (not reasons), (reasons or ["all checks passed"])


def main():
    ap = argparse.ArgumentParser(description="Promote forex pairs to required calibration")
    ap.add_argument("--root", default=str(Path(__file__).resolve().parents[1]),
                    help="project root containing config.json + storage")
    args = ap.parse_args()
    root = Path(args.root)

    cfg_path = root / "config.json"
    if not cfg_path.exists():
        print("FAIL: config.json not found at %s" % cfg_path)
        return 1
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"), object_pairs_hook=OrderedDict)
    auction_cfg = cfg.get("auction_flow", {}) or {}
    cal_base = Path(str(auction_cfg.get("calibration_path")
                        or "storage/model_calibration/auction_flow_v1.json"))
    if not cal_base.is_absolute():
        cal_base = root / cal_base

    instruments = cfg.get("instruments") or []
    changed = []
    print("=" * 78)
    print(" R16 PROMOTION - all non-gold pairs -> calibration_required: true")
    print("=" * 78)
    for pair in PROMOTION_PAIRS:
        inst = next((i for i in instruments
                     if isinstance(i, dict) and str(i.get("symbol")) == pair), None)
        if inst is None:
            print(" %-8s -> NOT IN CONFIG (skipped)" % pair)
            continue
        auc = inst.setdefault("auction_flow", OrderedDict())
        if bool(auc.get("calibration_required", False)):
            print(" %-8s -> already true (skipped)" % pair)
            continue
        stem = pair.replace("/", "").lower()
        cal_path = cal_base.with_name("%s_%s%s" % (cal_base.stem, stem, cal_base.suffix))
        ok, reasons = validate_calibration(cal_path, auction_cfg, pair)
        for reason in reasons:
            print(" %-8s    check: %s" % (pair, reason))
        if ok:
            auc["calibration_required"] = True
            changed.append(pair)
            print(" %-8s -> PROMOTED (calibration valid)" % pair)
        else:
            print(" %-8s -> HELD AT false (fail-closed: fix the file first)" % pair)

    if not changed:
        print("\nNothing changed (already promoted or all held).")
        return 0
    if "description" not in cfg.get("filters", {}):
        pass  # filters untouched here
    # stamp the operator decision near the promotion for future archaeology
    for pair in changed:
        inst = next(i for i in instruments
                    if isinstance(i, dict) and str(i.get("symbol")) == pair)
        inst["auction_flow"]["promotion_note"] = DESCRIPTION
    cfg_path.write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n",
                        encoding="utf-8")
    print("\nOK: promoted %d pair(s): %s" % (len(changed), ", ".join(changed)))
    print("Gold untouched (already required). Safe to re-run any time.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
