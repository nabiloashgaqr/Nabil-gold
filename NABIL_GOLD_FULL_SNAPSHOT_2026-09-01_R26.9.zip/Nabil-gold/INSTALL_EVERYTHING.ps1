# =====================================================================
# Nabil-gold FINAL installer - R12..R25 (SCALP) in ONE click (LOCAL-ONLY)
# This installer copies the WHOLE payload folders, so it can never go
# stale: every .py/.bat shipped in this package gets installed, compiled
# and tested - counts are measured at run time, never hardcoded.
#
# HOW TO RUN (Arabic guide in INSTALL_README_ARABIC.txt):
#   1. Extract the WHOLE zip anywhere.
#   2. Double-click INSTALL_EVERYTHING.bat
#      (or: powershell -NoProfile -ExecutionPolicy Bypass -File .\INSTALL_EVERYTHING.ps1)
#   3. When it finishes: double-click RESTART_ALL_SERVICES.bat
#      (right-click > Run as administrator) - Python only re-reads code
#      at process start, so a REAL restart is part of the install.
# Your config.json is NEVER overwritten wholesale - the merges (R13 caps,
# R25 laws) apply keys and always write a timestamped backup first.
# =====================================================================
param([string]$ProjectRoot = "C:\Nabil-gold")
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "==============================================================="
Write-Host " Nabil-gold FINAL installer (R12..R25 - SCALP)"
Write-Host " package : $here"
Write-Host " project : $ProjectRoot"
Write-Host "==============================================================="

if (-not (Test-Path $ProjectRoot)) {
    throw "Project root not found: $ProjectRoot - edit -ProjectRoot at the top of this file."
}

# -- 1. copy the whole payload folders (self-updating, no file list) --
Write-Host "[1/5] Copying payload folders..."
$dirs = @("services", "agents", "utils", "scripts", "tests")
$total = 0
foreach ($d in $dirs) {
    $src = Join-Path $here $d
    if (-not (Test-Path $src)) { throw "Package folder missing: $src (extract the WHOLE zip first)" }
    $dst = Join-Path $ProjectRoot $d
    if (-not (Test-Path $dst)) { New-Item -ItemType Directory -Path $dst | Out-Null }
    Copy-Item -Path (Join-Path $src "*") -Destination $dst -Force
    $n = (Get-ChildItem $src -File | Measure-Object).Count
    $total += $n
    Write-Host ("      " + $d.PadRight(9) + "-> " + $n + " file(s)")
}
foreach ($bat in @("RUN_TRADE_AUDIT.bat", "RUN_SYMBOL_DIAGNOSIS.bat")) {
    Copy-Item -Path (Join-Path $here $bat) -Destination $ProjectRoot -Force
    $total += 1
}
# R25.1 fix: the restart scripts live at the package ROOT and were never
# copied - the project kept the OLD restart script, which failed the R23.1
# log-rotation verification test. Ship them like the RUN_*.bat pair.
foreach ($rootf in @("RESTART_ALL_SERVICES.bat", "RESTART_ALL_SERVICES.ps1")) {
    if (Test-Path (Join-Path $here $rootf)) {
        Copy-Item -Path (Join-Path $here $rootf) -Destination $ProjectRoot -Force
        $total += 1
    }
}
# config_patch installs INTO the project so its scripts (merge + promotion)
# and the tests that reference them work from the project root too.
$cpSrc = Join-Path $here "config_patch"
$cpDst = Join-Path $ProjectRoot "config_patch"
if (-not (Test-Path $cpDst)) { New-Item -ItemType Directory -Path $cpDst | Out-Null }
Copy-Item -Path (Join-Path $cpSrc "*") -Destination $cpDst -Force
$total += (Get-ChildItem $cpSrc -File | Measure-Object).Count
Write-Host ("      TOTAL copied: " + $total + " files (measured, not hardcoded)")

# -- 2. merge config (never overwrite) --------------------------------
Write-Host "[2/5] Merging per-symbol spread caps into config.json..."
$merge = Join-Path $here "config_patch\APPLY_R13_CONFIG_MERGE.py"
$mergeOut = & python $merge --root $ProjectRoot 2>&1
if ($LASTEXITCODE -ne 0) { throw "config merge failed: $mergeOut" }
Write-Host ($mergeOut | Select-Object -First 1)

# -- 2b. R16 forex promotion (fail-closed: validates each calibration, THEN
#        flips calibration_required to true; doubtful pairs stay false) ------
Write-Host "[2b] Forex promotion (R16) - validate calibrations, then promote..."
$_eap = $ErrorActionPreference
$ErrorActionPreference = "Continue"
try {
    $promo = Join-Path $here "config_patch\APPLY_R16_PROMOTION.py"
    $promoOut = & python $promo --root $ProjectRoot 2>&1 | Out-String
    $promoOut | Out-File -FilePath (Join-Path $here "promotion_output.txt") -Encoding utf8
    Write-Host ((($promoOut -split "`r?`n") | Where-Object { $_ -match "PROMOTED|HELD|already|NOT IN|OK:" }) |
                Select-Object -First 10)
} catch {
    Write-Host "      (promotion could not run - config untouched. Run manually:"
    Write-Host ("       python config_patch\APPLY_R16_PROMOTION.py --root " + $ProjectRoot + ")")
}
$ErrorActionPreference = $_eap

# -- 2c. R20 24h Mon-Fri sessions (operator 2026-08-27: no daily break;
#        removes partial/break sessions, merge-only, idempotent) ------------
Write-Host "[2c] 24h Mon-Fri sessions (R20) - removing any daily break..."
try {
    $r20 = Join-Path $here "config_patch\APPLY_R20_SESSION_DAYS.py"
    $r20Out = & python $r20 --root $ProjectRoot 2>&1 | Out-String
    $r20Out | Out-File -FilePath (Join-Path $here "r20_session_output.txt") -Encoding utf8
    Write-Host ((($r20Out -split "`r?`n") | Where-Object { $_ -match "PATCHED|already|OK:|SKIP" }) |
                Select-Object -First 5)
} catch {
    Write-Host "      (R20 patch could not run - config untouched. Run manually:"
    Write-Host ("       python config_patch\APPLY_R20_SESSION_DAYS.py --root " + $ProjectRoot + ")")
}

# -- 2d. R25 config merge (R25.1, operator 2026-08-28): the R24/R25 laws
#        ARE config keys. A payload-only install left the live config on
#        the pre-R24 law and 12 verification tests failed against it.
#        Deep-merges every shipped key; backs up first; idempotent. ------
Write-Host "[2d] R25 config merge (R24 gates + SCALP PATH 7 + 12h pending)..."
$r25m = Join-Path $here "config_patch\APPLY_R25_CONFIG_MERGE.py"
$r25Out = & python $r25m --root $ProjectRoot 2>&1
if ($LASTEXITCODE -ne 0) { throw "R25 config merge failed: $r25Out" }
Write-Host ($r25Out | Select-Object -First 1)

# -- 3. compile EVERY shipped .py (discovered dynamically) ------------
Write-Host "[3/5] py_compile on every shipped python file..."
$failed = 0
$checked = 0
foreach ($d in @("services", "agents", "utils", "scripts", "tests")) {
    foreach ($f in (Get-ChildItem (Join-Path $here $d) -Filter "*.py" -File)) {
        $rel = Join-Path $d $f.Name
        $out = & python -m py_compile (Join-Path $ProjectRoot $rel) 2>&1
        $checked += 1
        if ($LASTEXITCODE -ne 0) { $failed += 1; Write-Host ("      FAILED: " + $rel) }
    }
}
if ($failed -gt 0) { throw ("py_compile failed for " + $failed + " file(s)") }
Write-Host ("      " + $checked + "/" + $checked + " OK")

# -- 4. run EVERY shipped test file (verification - NEVER blocks install) --
$testsFailed = $false
Write-Host "[4/5] Running every shipped test file (verification)..."
# run from the PROJECT root: some checks read project files with relative
# paths and operators' CWDs vary (R16.3 lesson)
Push-Location $ProjectRoot
$testPaths = Get-ChildItem (Join-Path $here "tests") -Filter "*.py" -File |
             ForEach-Object { Join-Path $ProjectRoot (Join-Path "tests" $_.Name) }
$t = & python -m pytest @testPaths -q --tb=line -rf -p no:cacheprovider 2>&1
Pop-Location
$logPath = Join-Path $here "install_test_output.txt"
$t | Out-File -FilePath $logPath -Encoding utf8
Write-Host ($t[-1])
$failedLines = @($t | Where-Object { $_ -match "^FAILED" })
if ($LASTEXITCODE -ne 0) {
    $testsFailed = $true
    Write-Host "      *** SOME TESTS FAILED - the payload IS installed; this is"
    Write-Host "      *** a verification report, not a broken install."
    foreach ($fl in $failedLines) { Write-Host ("      " + $fl) }
    Write-Host ("      FULL LOG: " + $logPath + "  <- send this file to me")
} else {
    Write-Host "      all green"
}

# -- 5. live diagnostics preview (BEST-EFFORT: can never fail the install) --
Write-Host "[5/5] Diagnostics preview (best-effort)..."
# PS5.1 + EAP=Stop converts any python stderr line into a TERMINATING error.
# Previews are optional sugar -> run them with EAP=Continue and try/catch.
$_eap = $ErrorActionPreference
$ErrorActionPreference = "Continue"
try {
    $fun = & python (Join-Path $ProjectRoot "scripts\diagnose_symbol_funnel.py") --days 7 2>&1 |
            Out-String
    $fun | Out-File -FilePath (Join-Path $here "preview_funnel.txt") -Encoding utf8
    Write-Host (($fun -split "`r?`n") | Select-Object -First 4)
} catch {
    Write-Host "      (funnel preview unavailable - run it manually; install unaffected)"
}
try {
    $auc = & python (Join-Path $ProjectRoot "scripts\diagnose_auction_agent.py") 2>&1 |
            Out-String
    $auc | Out-File -FilePath (Join-Path $here "preview_auction.txt") -Encoding utf8
    Write-Host (($auc -split "`r?`n") | Select-Object -First 4)
} catch {
    Write-Host "      (auction preview unavailable - run it manually; install unaffected)"
}
$ErrorActionPreference = $_eap

Write-Host "==============================================================="
Write-Host " INSTALL DONE (payload + config merge + compile: OK)."
if ($testsFailed) {
    Write-Host " TESTS: had failures -> send install_test_output.txt to me."
} else {
    Write-Host " TESTS: all green."
}
Write-Host " MANDATORY NEXT STEP (Python reads code at process start):"
Write-Host "   from File Explorer : double-click RESTART_ALL_SERVICES.bat"
Write-Host "   (right-click > Run as administrator)"
Write-Host "   from PowerShell    :  .\RESTART_ALL_SERVICES.bat"
Write-Host " Then verify:"
Write-Host "   python scripts\probe_aux_ticks.py            -> expect 5x OK"
Write-Host "   python scripts\diagnose_auction_agent.py     -> fresh ages, all 6"
Write-Host "   python scripts\diagnose_symbol_funnel.py --days 1 -> forex rows"
Write-Host "==============================================================="
