"""DEPRECATED root shim - BUILD 31 R10 (post-audit 2026-08-27).

The canonical analysis pipeline lives in ``scripts/run_analysis.py``. This
root copy had drifted out of sync with the R9/R10 code (it was missing the
armed-map watch hook and newer admission logic) while importing nothing and
being executed by nothing - a silent-drift trap. The shim keeps the legacy
entry point ``python run_analysis.py`` working by delegating to the canonical
script, so both paths can never diverge again.
"""
from __future__ import annotations

import os
import runpy
import sys

_ROOT = os.path.dirname(os.path.abspath(__file__))
_CANONICAL = os.path.join(_ROOT, "scripts", "run_analysis.py")

if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

if __name__ == "__main__":
    # Load .env exactly like the wrappers do (real env vars always win).
    try:
        from dotenv import load_dotenv as _load_dotenv
        _load_dotenv()  # override=False: task-wrapper vars take precedence
    except ImportError:
        pass
    print("[R10] run_analysis.py at repo root is a shim - executing "
          "scripts/run_analysis.py (canonical).", flush=True)
    runpy.run_path(_CANONICAL, run_name="__main__")
else:  # imported, not executed: forward to the canonical module
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location("scripts.run_analysis", _CANONICAL)
    _mod = _ilu.module_from_spec(_spec)
    sys.modules.setdefault("scripts.run_analysis", _mod)
    _spec.loader.exec_module(_mod)
    globals().update({k: v for k, v in vars(_mod).items() if not k.startswith("_")})
