"""DEPRECATED root shim - BUILD 31 R10 (post-audit 2026-08-27).

The canonical MT5 demo executor lives in ``services/mt5_executor.py`` (the
only copy the tick manager and the analysis pipeline import). This root copy
was a stale duplicate of an early phase - kept only so any legacy reference
to ``mt5_executor`` keeps resolving. It now re-exports the canonical module,
so there is exactly one implementation to maintain.
"""
from __future__ import annotations

import os
import sys

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from services.mt5_executor import *  # noqa: F401,F403
from services.mt5_executor import Mt5DemoExecutor, magic_for, plan_partial_close  # noqa: F401
