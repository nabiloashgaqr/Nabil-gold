# Read-only current day-map/session-plan status for Nabil-gold.
$ErrorActionPreference = "Stop"
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"
Set-Location "C:\Nabil-gold"

$code = @'
from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(r"C:\Nabil-gold")
PATH = ROOT / "storage" / "session_plans.json"
TZ = ZoneInfo("Asia/Jerusalem")
now = datetime.now(timezone.utc)
local_now = now.astimezone(TZ)

def dt(value):
    if not value:
        return None
    try:
        x = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if x.tzinfo is None:
            x = x.replace(tzinfo=timezone.utc)
        return x.astimezone(timezone.utc)
    except Exception:
        return None

def when(row):
    for key in ("analysis_run_at", "updated_at", "created_at", "plan_created_at"):
        x = dt(row.get(key))
        if x:
            return x
    return datetime.min.replace(tzinfo=timezone.utc)

def payload(row):
    p = row.get("payload")
    return p if isinstance(p, dict) else row

def val(row, key, default=None):
    p = payload(row)
    v = row.get(key)
    return v if v is not None else p.get(key, default)

def local_day(row):
    return when(row).astimezone(TZ).date()

def fmt_time(value):
    x = dt(value)
    return x.astimezone(TZ).isoformat() if x else "-"

def show(title, row):
    print("\n===", title, "===")
    if not row:
        print("NONE")
        return
    p = payload(row)
    primary = p.get("primary_poi") or {}
    standby = p.get("standby_poi") or {}
    ready = bool(val(row, "plan_ready", False))
    print("snapshot_id:", row.get("id"))
    print("analysis_local:", when(row).astimezone(TZ).isoformat())
    print("ready:", ready)
    print("status:", val(row, "plan_status"))
    print("reason:", val(row, "plan_reason"))
    print("bias:", val(row, "session_bias"))
    print("session:", val(row, "session_label"))
    print("grade/confidence:", val(row, "planner_grade"), val(row, "planner_confidence"))
    print("authority:", val(row, "authority_state"), val(row, "authority_direction"))
    print("price/primary/standby/invalidation/target:",
          val(row, "current_price"), val(row, "primary_entry_price"),
          val(row, "standby_entry_price"), val(row, "invalidation_level"),
          val(row, "target_liquidity"))
    print("primary_poi:", {k: primary.get(k) for k in
          ("poi_type", "entry_price", "zone_low", "zone_high", "setup_state", "quality_score")
          if primary.get(k) is not None})
    print("standby_poi:", {k: standby.get(k) for k in
          ("poi_type", "entry_price", "zone_low", "zone_high", "setup_state", "quality_score")
          if standby.get(k) is not None})
    print("expires_local:", fmt_time(val(row, "plan_expires_at")))
    print("telegram_sent_local:", fmt_time(row.get("telegram_sent_at")))
    print("telegram_note:", row.get("telegram_delivery_note"))
    readiness = p.get("execution_readiness") or {}
    print("execution_readiness:", readiness.get("state"), readiness.get("reason"))
    audit = p.get("execution_audit") or {}
    print("execution_audit:", {k: audit.get(k) for k in
          ("planner_gate_allow", "planner_gate_kind", "planner_gate_reason",
           "ladder_created", "ladder_stop_reason", "delivery_sent", "delivery_sent_reason")
          if k in audit})

print("UTC now:", now.isoformat())
print("Jerusalem now:", local_now.isoformat())
print("Plan file:", PATH)
if not PATH.exists():
    print("ERROR: session_plans.json MISSING")
    raise SystemExit(2)
raw = PATH.read_text(encoding="utf-8")
plans = json.loads(raw)
if not isinstance(plans, list):
    print("ERROR: session_plans.json is not a list")
    raise SystemExit(2)
plans.sort(key=when, reverse=True)
today = [r for r in plans if local_day(r) == local_now.date()]
ready_today = [r for r in today if bool(val(r, "plan_ready", False))]
sent_today = [r for r in today if dt(r.get("telegram_sent_at")) is not None]
ready_sent_today = [r for r in sent_today if bool(val(r, "plan_ready", False))]

print("Total snapshots:", len(plans))
print("Today snapshots:", len(today))
print("Today ready snapshots:", len(ready_today))
print("Today sent snapshots:", len(sent_today))
print("Today READY+sent snapshots:", len(ready_sent_today))
print("TODAY_MAP_SENT:", "YES" if ready_sent_today else "NO")

show("LATEST SNAPSHOT", plans[0] if plans else None)
show("LATEST READY TODAY", ready_today[0] if ready_today else None)
show("LATEST SENT TODAY", sent_today[0] if sent_today else None)

print("\n=== LAST 15 TODAY ===")
for r in today[:15]:
    print(
        when(r).astimezone(TZ).strftime("%Y-%m-%d %H:%M:%S %Z"),
        "ready=", bool(val(r, "plan_ready", False)),
        "sent=", bool(r.get("telegram_sent_at")),
        "bias=", val(r, "session_bias"),
        "status=", val(r, "plan_status"),
        "reason=", str(val(r, "plan_reason") or "")[:180],
    )
'@

$code | python -
Write-Host ""
Write-Host "--- Relevant delivery log lines ---"
if (Test-Path ".\logs\demo_analysis.log") {
    Get-Content ".\logs\demo_analysis.log" -Tail 2500 |
        Select-String -Pattern "Session plan Telegram sent|Session plan Telegram returned False|Failed to deliver session plan|Session plan not ready|Session-plan ladder" |
        Select-Object -Last 80 |
        ForEach-Object { $_.Line }
}
