@echo off
REM BUILD31-R12: forensic audit of today + yesterday trades (Hebron days)
cd /d C:\Nabil-gold
python scripts\audit_recent_trades.py --days 2
echo.
pause
