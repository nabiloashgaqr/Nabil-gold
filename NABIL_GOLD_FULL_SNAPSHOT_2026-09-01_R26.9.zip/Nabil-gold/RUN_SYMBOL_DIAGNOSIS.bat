@echo off
REM BUILD31-R13: per-symbol entry funnel diagnosis (why does a symbol not trade?)
cd /d C:\Nabil-gold
python scripts\diagnose_symbol_funnel.py --days 7
echo.
pause
