# -*- coding: utf-8 -*-
"""
APPLY_R25_9_HARDENING.py — تطبيق إصلاحات ما بعد التشخيص R25.9 (2026-08-31).

يضع الملفات المعدّلة في مكانها داخل جذر مشروع نابيل، بعد أخذ نسخة احتياطية من
أي ملف سيُستبدَل ويكون محتواه مختلفًا. لا يمسّ الإعدادات ولا أي مفتاح تبديل.

الإصلاحات (دفاعية/ميكانيكية، لا تغيّر استراتيجية القبول):
  1) services/auction_flow_store.py : بوابة سعر عند الكتابة (رفض تيك رمز آخر).
  2) scripts/run_tick_manager.py    : تمرير النطاق السعري لكل متجر.
  3) services/database.py           : حفظ execution_path_id دائمًا + تشغيل
                                       ذاكرة التأمل عند الخسارة.
  4) tests/test_r25_9_diagnostics_fixes.py : اختبارات جديدة.
  5) DIAGNOSE_ALL.py                : الفاحص v2 (قراءة فقط).

آمن لإعادة التشغيل مرات عديدة:
  - إن كان الملف في الوجهة مطابقًا للمصدر → يُسجَّل "مطبّق بالفعل" بلا نسخ.
  - إن كان مختلفًا → نسخة احتياطية ثم استبدال.
  - إن كان ناقصًا → يُنسخ.

التشغيل:
    python APPLY_R25_9_HARDENING.py            # معاينة جافة (لا يكتب)
    python APPLY_R25_9_HARDENING.py --apply     # تطبيق فعلي
    python APPLY_R25_9_HARDENING.py --apply --target C:\\Nabil-gold
أو ببساطة انقر نقرًا مزدوجًا على  تطبيق_R25_9.bat
"""
from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent

NEW_FILES = [
    "tests/test_r25_9_diagnostics_fixes.py",
    "DIAGNOSE_ALL.py",
]
EDITED_FILES = [
    "services/auction_flow_store.py",
    "scripts/run_tick_manager.py",
    "services/database.py",
]
ALL_FILES = NEW_FILES + EDITED_FILES


def _sha(p: Path) -> str | None:
    try:
        return hashlib.sha256(p.read_bytes()).hexdigest()
    except OSError:
        return None


def resolve_target(cli_target: str | None) -> Path:
    """Find the Nabil-gold project root, wherever the zip was extracted."""
    candidates = []
    if cli_target:
        candidates.append(Path(cli_target))
    env = os.environ.get("NABIL_GOLD_ROOT")
    if env:
        candidates.append(Path(env))
    # 1) extracted directly over the project root?
    candidates.append(SCRIPT_DIR)
    # 2) standard install location
    for drive in ("C:", "D:", "E:"):
        candidates.append(Path(rf"{drive}\Nabil-gold"))
    for c in candidates:
        try:
            if c and (c / "config.json").exists() and (c / "services").is_dir():
                return c.resolve()
        except OSError:
            continue
    # fall back to script dir even if it doesn't look like the project
    return SCRIPT_DIR


def run_project_tests(dst_root: Path, which: str = sys.executable) -> int:
    """Run the R25.9 unit tests FROM the project root (where utils/ lives).

    The package extracts into e.g. Downloads, where ``utils`` does not exist,
    so pytest must run against the installed target tree. Failures never
    block the already-applied files - they only report a non-zero exit.
    """
    test_file = dst_root / "tests" / "test_r25_9_diagnostics_fixes.py"
    if not test_file.exists():
        print("⚠️  ملف الاختبار غير موجود في المشروع — تخطّي الاختبارات.")
        return 0
    print("=" * 70)
    print("   تشغيل الاختبارات من داخل المشروع (C:\\Nabil-gold) ...")
    print("=" * 70)
    cmd = [which, "-m", "pytest", "tests/test_r25_9_diagnostics_fixes.py", "-q"]
    try:
        proc = subprocess.run(cmd, cwd=str(dst_root))
        return proc.returncode
    except FileNotFoundError:
        print(f"⚠️  تعذّر تشغيل: {which} -m pytest . شغّل يدويًا من داخل C:\\Nabil-gold:")
        print("   python -m pytest tests/test_r25_9_diagnostics_fixes.py -q")
        return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="R25.9 hardening applier")
    parser.add_argument("--apply", action="store_true",
                        help="apply for real (default = dry-run)")
    parser.add_argument("--target", default=None,
                        help="Nabil-gold project root (auto-detected if omitted)")
    parser.add_argument("--no-test", action="store_true",
                        help="do not run the unit tests after applying")
    args = parser.parse_args()

    src_root = SCRIPT_DIR
    dst_root = resolve_target(args.target)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = dst_root / "backup" / f"r25_9_{stamp}"

    print("=" * 70)
    print("R25.9 — تطبيق إصلاحات ما بعد التشخيص")
    print("=" * 70)
    print(f"مجلد الحزمة (المصدر): {src_root}")
    print(f"مجلد المشروع (الوجهة): {dst_root}")
    print(f"الوضع: {'تطبيق فعلي' if args.apply else 'معاينة جافة (لم يُكتب أي شيء)'}")
    if not (dst_root / "config.json").exists():
        print("⚠️  تنبيه: لم أجد config.json في الوجهة — تأكد أن المسار هو جذر المشروع.")
    print()

    missing, copied, replaced, already = [], 0, 0, 0
    for rel in ALL_FILES:
        src = src_root / rel
        dst = dst_root / rel
        if not src.exists():
            missing.append(rel)
            print(f"  [MISSING] {rel} — الملف غير موجود في الحزمة")
            continue

        if dst.exists():
            if _sha(src) == _sha(dst):
                already += 1
                print(f"  [مطابق]   {rel} — مُطبّق بالفعل، لا تغيير")
                continue
            state = "استبدال (محتوى مختلف)"
        else:
            state = "جديد"

        if args.apply:
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists():
                backup_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, backup_dir / Path(rel).name)
            shutil.copy2(src, dst)
            if dst.exists() and state.startswith("استبدال"):
                replaced += 1
            else:
                copied += 1
        tag = "جديد  " if dst.exists() is False and not args.apply else "استبدال"
        print(f"  [{state}] {rel}")

    print()
    if missing:
        print(f"⚠️  {len(missing)} ملف ناقص في الحزمة: {missing}")
    if args.apply:
        print(f"✅ الجديد: {copied} | المستبدَل (مع نسخة احتياطية): {replaced} | "
              f"المطابق سابقًا: {already}")
        if replaced or copied:
            print(f"   النسخ الاحتياطي للملفات المستبدَلة: {backup_dir}")
        if not args.no_test and (dst_root / "config.json").exists():
            print()
            rc = run_project_tests(dst_root)
            print()
            if rc == 0:
                print("✅ الاختبارات ناجحة. أعِد تشغيل خدمة المُجمِّع (run_tick_manager).")
            else:
                print("⚠️  توجد اختبارات فاشلة — أرسل المخرجات للمحلل.")
            print("   بعدها أعد تشغيل خدمة المُجمِّع (run_tick_manager).")
        else:
            print("   الخطوات التالية:")
            print("   1) cd C:\\Nabil-gold ثم:  python -m pytest tests/test_r25_9_diagnostics_fixes.py -q")
            print("   2) أعد تشغيل خدمة المُجمِّع (run_tick_manager).")
    else:
        print("هذه معاينة جافة. للتطبيق الفعلي:")
        print("   إما انقر نقرًا مزدوجًا على  APPLY_R25_9.bat")
        print("   أو شغّل:  python APPLY_R25_9_HARDENING.py --apply")
    return 1 if missing else 0


if __name__ == "__main__":
    sys.exit(main())
