<#
.SYNOPSIS
    INSTALL_PSUTIL.ps1 - install psutil (system resources monitoring) and
    re-run the healthcheck.

.DESCRIPTION
    The healthcheck's RESOURCES section needs psutil; it is not installed on
    the VPS ("psutil not installed - resource monitoring skipped"). This
    script installs it into the user's Python and verifies the section
    turns green.

.PARAMETER RepoRoot
    Project root. Default: C:\Nabil-gold.

.EXAMPLE
    cd C:\Nabil-gold
    powershell -ExecutionPolicy Bypass -File INSTALL_PSUTIL.ps1
#>
param(
    [string]$RepoRoot = "C:\Nabil-gold"
)

$ErrorActionPreference = "Stop"
Push-Location $RepoRoot
try {
    Write-Host "==> Installing psutil ..."
    python -m pip install "psutil>=5.9.0"
    if ($LASTEXITCODE -ne 0) { throw "pip install psutil failed" }
    Write-Host "==> Verify the RESOURCES section ..."
    python scripts\system_healthcheck.py | Select-String -Pattern "RESOURCES|VERDICT"
    Write-Host "==> Done. The RESOURCES section should now report CPU/RAM/disk."
} finally {
    Pop-Location
}
