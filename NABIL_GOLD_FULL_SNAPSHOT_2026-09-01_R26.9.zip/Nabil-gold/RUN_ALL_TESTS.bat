@echo off
REM ==================================================================
REM  RUN ALL TESTS - BUILD 31 R10 (post-audit verification)
REM  One-click full test suite for the shipped artifact.
REM  ASCII only (PowerShell 5.1 encoding-safe, same policy as the
REM  other R9 one-click runners).
REM ==================================================================
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
if not exist logs mkdir logs
echo ========================================================
echo   SMARTSIGNAL FULL TEST SUITE (pytest over tests/)
echo ========================================================
python -m pytest tests -q --tb=short -p no:cacheprovider
set RC=%ERRORLEVEL%
echo.
if %RC% NEQ 0 (
    echo [FAIL] pytest exited with code %RC%. See output above.
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\run_all_tests.ps1"
) else (
    echo [OK] ALL TESTS PASSED.
)
pause
