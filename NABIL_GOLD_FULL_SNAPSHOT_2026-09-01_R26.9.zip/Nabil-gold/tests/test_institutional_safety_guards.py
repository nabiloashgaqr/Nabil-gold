"""Unit Tests for Institutional Safety Guards & Loss-Prevention Upgrades.

Covers the 5 core loss prevention rules:
1. Quiet Hours & Asian/Rollover Breakout Restriction (21:00-06:30 UTC)
2. Strict Premium / Discount & Extreme VWAP Band Guard
3. Consolidation / Pre-News Regime Breakout Prohibition
4. SMC / Auction Flow Confirmation on Breakout Entries
5. Structural Anchor + 1.0 ATR Stop Loss Noise Floor
"""

from __future__ import annotations

import pytest
from datetime import datetime, timezone
from unittest.mock import patch

from agents.decision_agent import DecisionAgent
from agents.risk_management_agent import RiskManagementAgent
from utils.helpers import load_config
from utils.instruments import config_for_instrument


@pytest.fixture
def base_config():
    return load_config()


def test_quiet_hours_rollover_breakout_blocked(base_config):
    """Rule 1: Breakout entries at 01:51 UTC (Asian rollover) must be blocked."""
    da = DecisionAgent(base_config)
    
    mock_results = {
        "technical": {"direction": "BUY", "confidence": 75.0},
        "multitimeframe": {"direction": "BUY", "confidence": 85.0},
        "classical": {"direction": "BUY", "confidence": 70.0},
        "smc": {"direction": "BUY", "confidence": 65.0, "setup_structure": {"setup_type": "CONTINUATION_BREAKDOWN"}},
        "price_action": {"direction": "BUY", "confidence": 70.0},
        "auction_flow": {"direction": "BUY", "confidence": 65.0},
        "setup_context": {"setup_type": "CONTINUATION_BREAKDOWN"},
        "session": {"trading_allowed": True, "allow_signals": True},
    }

    # Simulate Asian quiet hour: 01:51 UTC
    asian_time = datetime(2026, 8, 25, 1, 51, 0, tzinfo=timezone.utc)
    with patch("agents.decision_agent.datetime") as mock_dt:
        mock_dt.now.return_value = asian_time
        mock_dt.side_effect = lambda *args, **kwargs: datetime(*args, **kwargs)
        res = da.analyze(mock_results)
        assert res["signal"] == "WAIT"
        assert any("Quiet Session Guard" in w for w in res["warnings"])

    # Simulate London active hour: 08:30 UTC
    london_time = datetime(2026, 8, 25, 8, 30, 0, tzinfo=timezone.utc)
    with patch("agents.decision_agent.datetime") as mock_dt:
        mock_dt.now.return_value = london_time
        mock_dt.side_effect = lambda *args, **kwargs: datetime(*args, **kwargs)
        res = da.analyze(mock_results)
        assert res["signal"] == "BUY"


def test_extreme_premium_buy_blocked(base_config):
    """Rule 2: BUY at extreme premium above VWAP + 1.2*ATR must be blocked."""
    da = DecisionAgent(base_config)

    # Price 4670 while VWAP is 4635 and ATR is 10 (4635 + 12 = 4647 max allowed)
    mock_results = {
        "current_price": 4670.0,
        "technical": {"direction": "BUY", "confidence": 75.0, "atr": 10.0},
        "multitimeframe": {"direction": "BUY", "confidence": 85.0},
        "classical": {"direction": "BUY", "confidence": 70.0},
        "smc": {"direction": "BUY", "confidence": 65.0, "zone": "PREMIUM"},
        "price_action": {"direction": "BUY", "confidence": 70.0},
        "auction_flow": {"direction": "BUY", "confidence": 65.0, "session_vwap": 4635.0},
        "setup_context": {"setup_type": "ORDER_BLOCK_PULLBACK"},
        "session": {"trading_allowed": True, "allow_signals": True},
    }

    london_time = datetime(2026, 8, 25, 9, 0, 0, tzinfo=timezone.utc)
    with patch("agents.decision_agent.datetime") as mock_dt:
        mock_dt.now.return_value = london_time
        res = da.analyze(mock_results)
        assert res["signal"] == "WAIT"
        assert any("Premium Zone Guard" in w for w in res["warnings"])


def test_extreme_discount_sell_blocked(base_config):
    """Rule 2: SELL at extreme discount below VWAP - 1.2*ATR must be blocked."""
    da = DecisionAgent(base_config)

    # Price 4600 while VWAP is 4635 and ATR is 10 (4635 - 12 = 4623 min allowed)
    mock_results = {
        "current_price": 4600.0,
        "technical": {"direction": "SELL", "confidence": 75.0, "atr": 10.0},
        "multitimeframe": {"direction": "SELL", "confidence": 85.0},
        "classical": {"direction": "SELL", "confidence": 70.0},
        "smc": {"direction": "SELL", "confidence": 65.0, "zone": "DISCOUNT"},
        "price_action": {"direction": "SELL", "confidence": 70.0},
        "auction_flow": {"direction": "SELL", "confidence": 65.0, "session_vwap": 4635.0},
        "setup_context": {"setup_type": "ORDER_BLOCK_PULLBACK"},
        "session": {"trading_allowed": True, "allow_signals": True},
    }

    london_time = datetime(2026, 8, 25, 9, 0, 0, tzinfo=timezone.utc)
    with patch("agents.decision_agent.datetime") as mock_dt:
        mock_dt.now.return_value = london_time
        res = da.analyze(mock_results)
        assert res["signal"] == "WAIT"
        assert any("Discount Zone Guard" in w for w in res["warnings"])


def test_consolidation_regime_breakout_blocked(base_config):
    """Rule 3: Breakout continuation during consolidation regime must be blocked."""
    da = DecisionAgent(base_config)

    mock_results = {
        "current_price": 4640.0,
        "market_regime": {"regime": "CONSOLIDATION_RANGE"},
        "technical": {"direction": "BUY", "confidence": 75.0, "atr": 5.0},
        "multitimeframe": {"direction": "BUY", "confidence": 85.0},
        "classical": {"direction": "BUY", "confidence": 70.0},
        "smc": {"direction": "BUY", "confidence": 65.0, "setup_structure": {"setup_type": "CONTINUATION_BREAKDOWN"}},
        "price_action": {"direction": "BUY", "confidence": 70.0},
        "auction_flow": {"direction": "BUY", "confidence": 65.0, "session_vwap": 4640.0},
        "setup_context": {"setup_type": "CONTINUATION_BREAKDOWN"},
        "session": {"trading_allowed": True, "allow_signals": True},
    }

    london_time = datetime(2026, 8, 25, 9, 0, 0, tzinfo=timezone.utc)
    with patch("agents.decision_agent.datetime") as mock_dt:
        mock_dt.now.return_value = london_time
        res = da.analyze(mock_results)
        assert res["signal"] == "WAIT"
        assert any("Range Regime Guard" in w for w in res["warnings"])


def test_naked_indicator_breakout_requires_smc_or_flow(base_config):
    """Rule 4: Indicator-only breakout without SMC or Auction Flow alignment must be blocked."""
    da = DecisionAgent(base_config)

    # 3 trend agents vote BUY, but SMC and Auction Flow are in WAIT
    mock_results = {
        "current_price": 4640.0,
        "technical": {"direction": "BUY", "confidence": 78.0, "atr": 5.0},
        "multitimeframe": {"direction": "BUY", "confidence": 88.0},
        "classical": {"direction": "BUY", "confidence": 72.0},
        "smc": {"direction": "WAIT", "confidence": 30.0},
        "price_action": {"direction": "BUY", "confidence": 66.0},
        "auction_flow": {"direction": "WAIT", "confidence": 50.0, "session_vwap": 4640.0},
        "setup_context": {"setup_type": "CONTINUATION_BREAKDOWN"},
        "session": {"trading_allowed": True, "allow_signals": True},
    }

    london_time = datetime(2026, 8, 25, 9, 0, 0, tzinfo=timezone.utc)
    with patch("agents.decision_agent.datetime") as mock_dt:
        mock_dt.now.return_value = london_time
        res = da.analyze(mock_results)
        assert res["signal"] == "WAIT"
        assert any("Institutional Flow Guard" in w for w in res["warnings"])


def test_structural_stop_loss_minimum_noise_buffer(base_config):
    """Rule 5: Gold Stop Loss must respect the minimum 40.0 pts noise floor."""
    gold_cfg = config_for_instrument(base_config, {"symbol": "XAU/USD"})
    rma = RiskManagementAgent(gold_cfg)

    # Entry 4650.0, nearest support is at 4648.0 (only 20 pts away)
    sl_price, method, buffer = rma._stop_loss(
        direction="BUY",
        entry=4650.0,
        atr=3.0,
        supports=[4648.0],
        resistances=[],
        smc_suggestion={},
        results={"smc": {}},
        management_profile="default_profile",
    )

    # Stop Loss distance must be at least 40.0 points ($4.00) -> at most 4646.00
    sl_dist_pts = abs(4650.0 - sl_price) / 0.10
    assert sl_dist_pts >= 40.0, f"SL distance {sl_dist_pts} pts was below 40.0 pts floor"
    assert sl_price <= 4646.0
