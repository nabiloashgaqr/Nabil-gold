"""2026-08-19 build 10: crack-spread oil layer + EIA auto-fill + measurement ON."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import agents.oil_macro_agent as oma  # noqa: E402
import scripts.fill_oil_macro as fm  # noqa: E402


def _series(start: float, step: float, n: int = 60) -> list:
    return [start + step * i for i in range(n)]


class TestCrackComponent:
    def _agent(self):
        return oma.OilMacroAgent({"oil_macro": {"enabled": True, "crack_enabled": True}})

    def test_widening_cracks_bullish(self, monkeypatch):
        mapping = {
            "CL=F": _series(70.0, 0.02),       # crude roughly flat
            "RB=F": _series(95.0, 0.25),       # gasoline rising fast -> crack widens
            "HO=F": _series(90.0, 0.20),       # distillate rising -> crack widens
        }
        monkeypatch.setattr(oma, "yf_closes", lambda sym, *a, **k: mapping.get(sym))
        points, reasons = self._agent()._crack_component()
        assert points == 1.0
        assert any("Gasoline crack widening" in r for r in reasons)
        assert any("Distillate crack widening" in r for r in reasons)

    def test_narrowing_cracks_bearish(self, monkeypatch):
        mapping = {
            "CL=F": _series(70.0, 0.30),       # crude rising
            "RB=F": _series(95.0, 0.05),       # products lagging -> crack narrows
            "HO=F": _series(90.0, 0.03),
        }
        monkeypatch.setattr(oma, "yf_closes", lambda sym, *a, **k: mapping.get(sym))
        points, _ = self._agent()._crack_component()
        assert points == -1.0

    def test_disabled_returns_zero(self, monkeypatch):
        agent = oma.OilMacroAgent({"oil_macro": {"enabled": True, "crack_enabled": False}})
        monkeypatch.setattr(oma, "yf_closes", lambda *a, **k: _series(70.0, 0.1))
        points, reasons = agent._crack_component()
        assert points == 0.0 and reasons == []

    def test_missing_data_fails_open(self, monkeypatch):
        monkeypatch.setattr(oma, "yf_closes", lambda *a, **k: None)
        points, reasons = self._agent()._crack_component()
        assert points == 0.0 and reasons == []

    def test_crack_feeds_analyze_score(self, monkeypatch, tmp_path):
        cfg = {"oil_macro": {"enabled": True, "crack_enabled": True,
                             "eia_path": str(tmp_path / "eia.json"),
                             "eia_history_path": str(tmp_path / "hist.json"),
                             "opec_path": str(tmp_path / "opec.json")}}
        mapping = {"CL=F": _series(70.0, 0.02), "RB=F": _series(95.0, 0.25),
                   "HO=F": _series(90.0, 0.20), "BZ=F": _series(75.0, 0.02)}
        monkeypatch.setattr(oma, "yf_closes", lambda sym, *a, **k: mapping.get(sym))
        r = oma.OilMacroAgent(cfg).analyze({"symbol": "WTI/USD"})
        # no EIA/OPEC files: crack is the only component -> direction BUY
        assert r["direction"] == "BUY"
        assert r["confidence"] > 0
        assert r["signal"] == "WAIT"  # never votes


class TestFillOilMacro:
    class FakeResp:
        def __init__(self, payload):
            self._payload = payload

        def raise_for_status(self):
            pass

        def json(self):
            return self._payload

    def _response(self):
        # BUILD 21.3: the REAL v2 shape observed live - flat dict rows with
        # period/value keys (values are strings per API v2.1.6).
        return {
            "response": {"data": [
                {"series": "WCRSTUS1", "period": "2026-08-14", "value": "426000"},
                {"series": "WCRSTUS1", "period": "2026-08-07", "value": "430000"},
                {"series": "WGTSTUS1", "period": "2026-08-14", "value": "221000"},
                {"series": "WGTSTUS1", "period": "2026-08-07", "value": "219000"},
                {"series": "WDISTUS1", "period": "2026-08-14", "value": "120000"},
                {"series": "WDISTUS1", "period": "2026-08-07", "value": "120500"},
                {"series": "WPULEUS3", "period": "2026-08-14", "value": "92.3"},
                {"series": "WPULEUS3", "period": "2026-08-07", "value": "91.0"},
            ]}
        }

    def test_fetch_math(self, monkeypatch):
        import requests
        monkeypatch.setattr(requests, "get", lambda *a, **k: self.FakeResp(self._response()))
        payload = fm.fetch_eia_weekly("TESTKEY")
        assert payload["week"] == "2026-08-14"
        assert payload["crude_change_mb"] == -4.0      # (426000-430000)/1000
        assert payload["gasoline_change_mb"] == 2.0
        assert payload["distillate_change_mb"] == -0.5
        assert payload["refinery_util_pct"] == 92.3

    def test_apply_writes_and_dedupes_history(self, tmp_path):
        payload = {"week": "2026-08-14", "crude_change_mb": -4.0,
                   "gasoline_change_mb": 2.0, "distillate_change_mb": -0.5,
                   "refinery_util_pct": 92.3, "source": "eia_api_auto"}
        eia_path, hist_path = fm.apply_eia_payload(payload, tmp_path)
        assert json.loads(eia_path.read_text(encoding="utf-8"))["crude_change_mb"] == -4.0
        hist = json.loads(hist_path.read_text(encoding="utf-8"))
        assert len(hist) == 1
        # second apply with same week: no duplicate
        fm.apply_eia_payload(payload, tmp_path)
        hist2 = json.loads(hist_path.read_text(encoding="utf-8"))
        assert len(hist2) == 1

    def test_combined_missing_crude_falls_back_to_single(self, monkeypatch):
        """BUILD 21.1/21.2: a combined response without the crude series must
        fall back to a per-series request instead of failing the whole fill."""
        import requests
        combined = {
            "response": {"data": [
                {"series": "WGTSTUS1", "period": "2026-08-14", "value": "221000"},
                {"series": "WGTSTUS1", "period": "2026-08-07", "value": "219000"},
            ]}
        }
        single = {
            "response": {"data": [
                {"series": "WCRSTUS1", "period": "2026-08-14", "value": "426000"},
                {"series": "WCRSTUS1", "period": "2026-08-07", "value": "430000"},
            ]}
        }
        calls = []

        class FakeResp:
            def __init__(self, payload):
                self._payload = payload
                self.text = ""
                self.status_code = 200

            def raise_for_status(self):
                pass

            def json(self):
                return self._payload

        def fake_get(url, params=None, timeout=None):
            facets = [p[1] for p in (params or []) if p[0] == "facets[series][]"]
            calls.append(facets)
            return FakeResp(combined if len(facets) > 1 else single)

        monkeypatch.setattr(requests, "get", fake_get)
        payload = fm.fetch_eia_weekly("TESTKEY")
        assert payload["crude_change_mb"] == -4.0
        assert payload["week"] == "2026-08-14"
        # one combined call with the bare primary ids + single-series fallbacks
        assert calls[0] == fm.PRIMARY_IDS
        assert ["WCRSTUS1"] in calls[1:]

    def test_v1_style_ids_fall_back_when_bare_returns_empty(self, monkeypatch):
        """BUILD 21.2/21.3: if the bare ids match nothing, the v1-style
        candidates are tried next and their rows win."""
        import requests

        class FakeResp:
            def __init__(self, payload, text="", status=200):
                self._payload = payload
                self.text = text
                self.status_code = status

            def raise_for_status(self):
                pass

            def json(self):
                return self._payload

        def fake_get(url, params=None, timeout=None):
            facets = [p[1] for p in (params or []) if p[0] == "facets[series][]"]
            if facets == fm.PRIMARY_IDS:
                return FakeResp({"response": {"data": []}})  # combined: nothing
            if facets == ["PET.WCRSTUS1.W"]:
                return FakeResp({"response": {"data": [
                    {"series": "PET.WCRSTUS1.W", "period": "2026-08-14", "value": "426000"},
                    {"series": "PET.WCRSTUS1.W", "period": "2026-08-07", "value": "430000"},
                ]}})
            return FakeResp({"response": {"data": []}})

        monkeypatch.setattr(requests, "get", fake_get)
        payload = fm.fetch_eia_weekly("TESTKEY")
        assert payload["crude_change_mb"] == -4.0
        assert payload["week"] == "2026-08-14"

    def test_seriesid_route_fallback(self, monkeypatch):
        """BUILD 21.3: the documented /v2/seriesid/<v1-id> translation route
        is the final fallback per series (dict rows under response.data)."""
        import requests

        class FakeResp:
            def __init__(self, payload, text="", status=200):
                self._payload = payload
                self.text = text
                self.status_code = status

            def raise_for_status(self):
                pass

            def json(self):
                return self._payload

        def fake_get(url, params=None, timeout=None):
            if "/v2/seriesid/" in url:
                return FakeResp({"response": {"data": [
                    {"period": "2026-08-14", "value": "426000"},
                    {"period": "2026-08-07", "value": "430000"},
                ]}})
            return FakeResp({"response": {"data": []}})

        monkeypatch.setattr(requests, "get", fake_get)
        payload = fm.fetch_eia_weekly("TESTKEY")
        assert payload["crude_change_mb"] == -4.0
        assert payload["week"] == "2026-08-14"

    def test_row_parsers_handle_both_shapes(self):
        # flat v2 dict rows
        rows = fm._series_rows(
            {"response": {"data": [
                {"series": "WCRSTUS1", "period": "2026-08-14", "value": "426000"},
                {"series": "WGTSTUS1", "period": "2026-08-14", "value": "1"},
            ]}}, "WCRSTUS1")
        assert len(rows) == 1
        assert fm._row_period(rows[0]) == "2026-08-14"
        assert fm._row_value(rows[0]) == 426000.0
        # legacy [period, value] lists (seriesid route variant)
        assert fm._row_period(["2026-08-14", "426000"]) == "2026-08-14"
        assert fm._row_value(["2026-08-14", "426000"]) == 426000.0
        assert fm._row_value({"period": "x"}) is None
        # seriesid parser: dict rows via response.data
        assert len(fm._seriesid_rows({"response": {"data": [
            {"period": "2026-08-14", "value": "1"}]}})) == 1
        # seriesid parser: legacy series[].data lists
        assert len(fm._seriesid_rows({"series": [
            {"series_id": "PET.WCRSTUS1.W",
             "data": [["2026-08-14", "1"], ["2026-08-07", "2"]]}]})) == 2
        assert fm._seriesid_rows({}) == []

    def test_all_missing_raises_with_diagnostic_counts(self, monkeypatch, capsys):
        import requests

        class FakeResp:
            def raise_for_status(self):
                pass

            def json(self):
                return {"response": {"data": []}}

            text = "{}"
            status_code = 200

        monkeypatch.setattr(requests, "get", lambda *a, **k: FakeResp())
        import pytest
        with pytest.raises(ValueError) as exc:
            fm.fetch_eia_weekly("TESTKEY")
        msg = str(exc.value)
        assert "missing crude stocks series" in msg
        assert "crude" in msg
        out = capsys.readouterr().out
        # the parameter echo / totals dump ran so the API's answer is visible
        assert "HTTP" in out
        assert "total=" in out

    def test_api_error_raises(self, monkeypatch):
        def boom(*a, **k):
            raise ConnectionError("down")

        import requests
        monkeypatch.setattr(requests, "get", boom)
        import pytest

        with pytest.raises(ConnectionError):
            fm.fetch_eia_weekly("TESTKEY")


class TestConfigBuild10:
    def test_measurement_restarted_and_crack_on(self):
        cfg_path = Path(__file__).resolve().parents[1] / "config.json"
        prod = json.loads(cfg_path.read_text(encoding="utf-8"))
        assert (prod.get("agent_measurement") or {}).get("enabled") is True
        om = prod.get("oil_macro") or {}
        assert om.get("crack_enabled") is True
        assert om.get("eia_api_key_env") == "EIA_API_KEY"
