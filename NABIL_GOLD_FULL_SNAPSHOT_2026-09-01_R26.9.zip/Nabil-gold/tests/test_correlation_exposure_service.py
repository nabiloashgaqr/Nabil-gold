"""2026-08-19 upgrade tests: correlation exposure manager (XAU↔WTI)."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from services.correlation_exposure import CorrelationExposureManager  # noqa: E402


def _manager(tmp_path, enforce=False, enabled=True):
    cfg = {
        "instruments": [{"symbol": "XAU/USD"}, {"symbol": "WTI/USD"}],
        "correlation_guard": {
            "enabled": enabled,
            "enforce": enforce,
            "lookback_days": 60,
            "veto_correlation": 0.55,
            "max_heat": 1.5,
            "daily_closes_path": str(tmp_path / "closes.json"),
        },
    }
    return CorrelationExposureManager(cfg)


def _feed_correlated(m, days=80, seed=7):
    rng = np.random.default_rng(seed)
    base = rng.normal(0, 1, days).cumsum()
    for i in range(days):
        m.update_closes("XAU/USD", f"d{i:03d}", float(2000 + base[i] * 5))
        m.update_closes("WTI/USD", f"d{i:03d}", float(70 + base[i] * 0.3 + rng.normal(0, 0.1)))


class TestCorrelationExposure:
    def test_positive_correlation_detected(self, tmp_path):
        m = _manager(tmp_path)
        _feed_correlated(m)
        assert m.correlation("XAU/USD", "WTI/USD") > 0.5

    def test_not_enough_data_fails_open(self, tmp_path):
        m = _manager(tmp_path)
        assert m.correlation("XAU/USD", "WTI/USD") == 0.0

    def test_heat_reported(self, tmp_path):
        m = _manager(tmp_path)
        _feed_correlated(m)
        heat = m.portfolio_heat()
        assert heat["heat"] >= 1.0
        assert "XAU/USD<->WTI/USD" in heat["pairs"]

    def test_advisory_mode_never_vetoes(self, tmp_path):
        m = _manager(tmp_path, enforce=False)
        _feed_correlated(m)
        open_trades = [{"symbol": "WTI/USD", "signal": "SELL"}]
        verdict = m.review({"symbol": "XAU/USD", "signal": "BUY"}, open_trades)
        assert verdict["action"] == "ADVISORY_VETO"

    def test_enforce_vetoes_opposite_on_correlated(self, tmp_path):
        m = _manager(tmp_path, enforce=True)
        _feed_correlated(m)
        open_trades = [{"symbol": "WTI/USD", "signal": "SELL"}]
        verdict = m.review({"symbol": "XAU/USD", "signal": "BUY"}, open_trades)
        assert verdict["action"] == "VETO"
        assert "correlated" in verdict["reason"]

    def test_same_direction_passes(self, tmp_path):
        m = _manager(tmp_path, enforce=True)
        _feed_correlated(m)
        open_trades = [{"symbol": "WTI/USD", "signal": "BUY"}]
        verdict = m.review({"symbol": "XAU/USD", "signal": "BUY"}, open_trades)
        assert verdict["action"] == "PASS"
