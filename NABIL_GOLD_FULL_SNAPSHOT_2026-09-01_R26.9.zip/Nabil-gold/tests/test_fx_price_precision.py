"""R25.15 convoy step 1 — FX price precision (the gold-2dp defect).

Live evidence 2026-08-28 (operator screenshot, GBPUSD SELL):
  row entry 1.36000 vs broker fill 1.35504 — every price write rounded to a
  hardcoded 2 decimals (round(1.35504, 2) == 1.36). utils.instruments already
  shipped round_price/price_decimals; these tests pin them to the six symbols
  and to the sites that must never collapse FX digits again.
"""
from __future__ import annotations

import pytest

from agents.open_trades_manager import OpenTradesManager
from scripts.run_tick_manager import corrected_execution_stop
from utils.instruments import price_decimals, round_price


@pytest.mark.parametrize("symbol,decimals", [
    ("XAU/USD", 2), ("WTI/USD", 2), ("EUR/USD", 5),
    ("GBP/USD", 5), ("USD/CAD", 5), ("USD/JPY", 3),
])
def test_price_decimals_per_symbol(symbol, decimals):
    assert price_decimals(symbol, {}) == decimals


@pytest.mark.parametrize("symbol,price,expected", [
    ("XAU/USD", 4365.634, 4365.63),
    ("WTI/USD", 71.385, 71.39),
    ("EUR/USD", 1.081234, 1.08123),
    ("GBP/USD", 1.35504, 1.35504),
    ("USD/CAD", 1.390221, 1.39022),
    ("USD/JPY", 160.15321, 160.153),
])
def test_round_price_keeps_symbol_digits(symbol, price, expected):
    assert round_price(price, symbol, {}) == expected


def test_corrected_gbp_stop_is_not_swallowed_by_gold_rounding():
    """THE defect: round(1.35754, 2) == 1.36 silently restored the bad stop.

    GBPUSD SELL filled at 1.35504 with the stop recorded at the planned entry
    (1.36000 = 496 pts). The GBP law is [160 .. 250] pts, so the correction
    must land at 1.35504 + 250 * 0.00001 = 1.35754 — five digits intact.
    """
    stop, required, actual = corrected_execution_stop(
        "SELL", actual_entry=1.35504, current_stop=1.36,
        planned_entry=1.36, planned_stop=1.36504,
        min_liquidity_points=120, safety_buffer_points=40,
        cap_points=250, point_value=0.00001, digits=5,
    )
    assert actual == pytest.approx(496.0)
    assert required == 250.0
    assert stop == 1.35754  # round(...,2) would have returned 1.36 — the bug


def test_corrected_gold_stop_keeps_two_digits():
    """Gold behaviour is unchanged: digits default keeps the legacy 2dp."""
    stop, required, actual = corrected_execution_stop(
        "BUY", actual_entry=4392.63, current_stop=4368.00,
        planned_entry=4395.00, planned_stop=4368.00,
    )
    assert (stop, required, actual) == (4365.63, 270.0, 246.3)


def test_create_trade_record_keeps_fx_digits():
    """Rows are BORN with the symbol's digits, not gold's."""
    mgr = OpenTradesManager({})
    decision = {
        "symbol": "GBP/USD", "decision": "SELL",
        "signal": {"entry": {"price": 1.35504}, "stop_loss": 1.36504,
                   "tp1": 1.35004, "tp2": 1.34504},
    }
    rec = mgr.create_trade_record(decision)
    assert rec["entry_price"] == 1.35504
    assert rec["stop_loss"] == 1.36504
    assert rec["tp1"] == 1.35004
    assert rec["tp2"] == 1.34504


def test_rp_helper_uses_symbol_digits():
    mgr = OpenTradesManager({})
    assert mgr._rp(1.35504, "GBP/USD") == 1.35504
    assert mgr._rp(4365.634, "XAU/USD") == 4365.63
