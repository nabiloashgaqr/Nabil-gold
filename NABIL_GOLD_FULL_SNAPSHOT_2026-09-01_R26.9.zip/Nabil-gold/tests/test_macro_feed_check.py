"""2026-08-19: macro feed health check tests."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class TestMacroFeedCheck:
    def _fixture(self, root: Path, payload: dict) -> None:
        (root / "storage").mkdir(parents=True, exist_ok=True)
        (root / "storage" / "macro_context.json").write_text(
            json.dumps(payload), encoding="utf-8")

    def _run(self, root: Path, *extra) -> subprocess.CompletedProcess:
        script = Path(__file__).resolve().parents[1] / "scripts" / "macro_feed_check.py"
        return subprocess.run(
            [sys.executable, str(script), "--root", str(root), *extra],
            capture_output=True, text=True, timeout=180,
        )

    def test_feed_dead_when_fields_unknown(self, tmp_path):
        self._fixture(tmp_path, {
            "updated_at": "2026-08-19T10:00:00+00:00",
            "source": "yfinance_macro_proxy",
            "dxy_trend": "unknown", "us10y_trend": "unknown",
            "real_yields_trend": "unknown", "fed_tone": "unknown",
            "inflation_surprise": "unknown", "risk_sentiment": "unknown",
            "oil_trend": "unknown", "vix_level": None,
            "data_quality": {"source": "yfinance_macro_proxy", "freshness": "UNKNOWN",
                             "missing_fields": ["yfinance"]},
        })
        out = self._run(tmp_path)
        assert out.returncode == 0
        assert "FEED DEAD" in out.stdout

    def test_feed_ok_when_fields_live(self, tmp_path):
        self._fixture(tmp_path, {
            "updated_at": "2026-08-19T10:00:00+00:00",
            "source": "yfinance_macro_proxy",
            "dxy_trend": "falling", "us10y_trend": "falling",
            "real_yields_trend": "falling", "fed_tone": "dovish",
            "inflation_surprise": "cool", "risk_sentiment": "risk_off",
            "oil_trend": "rising", "vix_level": 18.2,
            "data_quality": {"source": "yfinance_macro_proxy", "freshness": "FRESH",
                             "missing_fields": []},
        })
        out = self._run(tmp_path)
        assert out.returncode == 0
        assert "FEED OK" in out.stdout

    def test_missing_file(self, tmp_path):
        out = self._run(tmp_path)
        assert out.returncode == 1
        assert "MISSING" in out.stdout
