# -*- coding: utf-8 -*-
"""R25.12: unit tests for scripts/build_package.py (tiny fake trees).

The real build runs the full VPS-simulation suite; these tests drive the
tool's functions directly on miniature trees so the pipeline itself
(sync parity, token scan, completeness, manifest, zip roundtrip, changed
report) is proven in seconds.
"""
from __future__ import annotations

import importlib.util
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

_spec = importlib.util.spec_from_file_location(
    "build_package_tool", ROOT / "scripts" / "build_package.py")
bp = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(bp)


def _mk_tree(base: Path) -> None:
    (base / "services").mkdir(parents=True)
    (base / "tests").mkdir(parents=True)
    (base / "storage").mkdir(parents=True)          # must never be packaged
    (base / "services" / "a.py").write_text("X = 1\n", encoding="utf-8")
    (base / "tests" / "t_a.py").write_text("def test_a():\n    assert True\n", encoding="utf-8")
    (base / "config.json").write_text(json.dumps({"k": 1}), encoding="utf-8")
    (base / "storage" / "junk.json").write_text("{}", encoding="utf-8")


def test_sync_is_wholesale_parity_and_skips_storage(tmp_path):
    src, stage = tmp_path / "src", tmp_path / "stage"
    _mk_tree(src)
    stage.mkdir()
    rep = bp.sync_governed(src, stage)
    assert rep["added"] == 3 and rep["copied"] == 0
    assert (stage / "services" / "a.py").exists()
    assert not (stage / "storage").exists()          # runtime state excluded
    # change + rerun: parity updates in place
    (src / "services" / "a.py").write_text("X = 2\n", encoding="utf-8")
    rep2 = bp.sync_governed(src, stage)
    assert rep2["copied"] == 1 and rep2["unchanged"] == 2


def test_token_scan_finds_retired_ids_and_skips_junk(tmp_path):
    tree = tmp_path / "tree"
    (tree / "services").mkdir(parents=True)
    (tree / "__pycache__").mkdir(parents=True)
    (tree / "services" / "clean.py").write_text("X = 1\n", encoding="utf-8")
    (tree / "services" / "dirty.py").write_text(
        'M = "gemini-flash-latest"\n', encoding="utf-8")
    (tree / "__pycache__" / "dirty2.py").write_text(
        'M = "gemini-2.5-flash"\n', encoding="utf-8")
    (tree / "config.json").write_text('{"a": 1}', encoding="utf-8")
    off = bp.scan_tokens(tree)
    assert off and off[0].startswith("services/dirty.py:"), off


def test_completeness_missing_names_unshipped_files(tmp_path):
    src, stage = tmp_path / "src", tmp_path / "stage"
    _mk_tree(src)
    stage.mkdir()
    (stage / "services").mkdir()
    (stage / "services" / "a.py").write_text("X = 1\n", encoding="utf-8")
    # tests/t_a.py + config.json deliberately absent from the stage
    assert bp.completeness_missing(src, stage) == ["tests/t_a.py", "config.json"]


def test_zip_roundtrip_and_changed_report(tmp_path):
    prev, new = tmp_path / "prev", tmp_path / "new"
    for d in (prev, new):
        (d / "services").mkdir(parents=True)
    (prev / "services" / "a.py").write_text("X = 1\n", encoding="utf-8")
    (new / "services" / "a.py").write_text("X = 2\n", encoding="utf-8")
    (new / "services" / "b.py").write_text("Y = 1\n", encoding="utf-8")
    (new / "INSTALL_README_ARABIC.txt").write_text("دليل\n", encoding="utf-8")  # package-only: not reported
    rows = bp.changed_report(prev, new)
    assert rows == [("services/a.py", "changed"), ("services/b.py", "added")], rows
    out = tmp_path / "out.zip"
    zi = bp.zip_and_verify(new, out)
    assert zi["mismatches"] == [] and zi["files"] == 3  # a.py + b.py + README
    doc = tmp_path / "doc.md"
    n = bp.write_files_doc(doc, prev, new, "RTest", "2778 passed", dict(zi, name=out.name))
    assert n == 2
    text = doc.read_text(encoding="utf-8")
    assert "-X = 1" in text and "+X = 2" in text and "2778 passed" in text


def test_main_end_to_end_on_fake_tree_with_skip_suite(tmp_path, monkeypatch):
    # point the tool at a miniature ROOT: prev zip with an OLD file
    src = tmp_path / "src"
    _mk_tree(src)
    prev_stage = tmp_path / "prev_stage"
    prev_stage.mkdir()
    (prev_stage / "services").mkdir()
    (prev_stage / "services" / "a.py").write_text("X = 0\n", encoding="utf-8")
    (prev_stage / "INSTALL_README_ARABIC.txt").write_text("عنوان قديم\n", encoding="utf-8")
    prev_zip = tmp_path / "prev.zip"
    with zipfile.ZipFile(prev_zip, "w") as z:
        for p in prev_stage.rglob("*"):
            if p.is_file():
                z.write(p, p.relative_to(prev_stage).as_posix())
    (src / "services" / "a.py").write_text("X = 1\n", encoding="utf-8")  # source is newer
    out_zip = tmp_path / "out" / "new.zip"
    doc = tmp_path / "doc.md"
    # drive main() against the FAKE root by patching the module ROOT
    monkeypatch.setattr(bp, "ROOT", src)
    rc = bp.main(["--prev", str(prev_zip), "--out", str(out_zip),
                  "--label", "RTest", "--files-doc", str(doc),
                  "--readme-title", "عنوان جديد", "--skip-suite"])
    assert rc == 0, "checklist must PASS"
    with zipfile.ZipFile(out_zip) as z:
        names = z.namelist()
        assert "services/a.py" in names and "config.json" in names
        # newline-agnostic: on Windows write_text produces CRLF - the stale
        # file must be replaced on BOTH platforms (VPS lesson R25.12).
        got = z.read("services/a.py").decode().replace("\r\n", "\n")
        assert got == "X = 1\n", "stale file must be replaced"
        assert z.read("INSTALL_README_ARABIC.txt").decode().startswith("عنوان جديد")
        assert "FILES_MANIFEST.txt" in names
    text = doc.read_text(encoding="utf-8")
    assert "services/a.py" in text and "+X = 1" in text
