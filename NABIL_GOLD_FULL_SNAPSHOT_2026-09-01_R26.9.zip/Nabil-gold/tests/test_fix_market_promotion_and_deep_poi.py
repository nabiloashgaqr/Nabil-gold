from __future__ import annotations
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.adaptive_execution import AdaptiveExecutionService
from agents.smc_agent import SMCAgent

def test_adaptive_execution_disabled_market_promotion():
    cfg = {
        "adaptive_execution": {
            "enabled": True,
            "allow_market_promotion": False,
            "keep_pending_max_move_points": 120,
            "promote_to_market_min_move_points": 60,
            "promote_to_market_max_move_points": 220,
        }
    }
    svc = AdaptiveExecutionService(cfg)
    # Trade is pending at 4657
    trade = {
        "id": "T1",
        "symbol": "XAU/USD",
        "type": "BUY",
        "status": "PENDING",
        "entry_price": 4657.0,
        "stop_loss": 4623.0,
        "tp1": 4700.0,
        "tp2": 4750.0,
        "signal_snapshot": {}
    }
    # Decision comes when price is at 4670 (moved 130 pts)
    decision = {
        "decision": "BUY",
        "symbol": "XAU/USD",
        "current_price": 4670.0,
        "stop_loss": 4633.0,
        "tp1": 4720.0,
        "tp2": 4750.0,
    }
    result = svc.review(decision, [trade])
    assert result["action"] != "PROMOTE_TO_MARKET"
    assert result["action"] in {"NO_TRADE_MISSED_MOVE", "KEEP_PENDING"}

def test_smc_ranks_deep_discount_poi():
    cfg = {
        "smc_engine": {
            "poi_preference": {
                "fresh_bonus": 18,
                "deep_zone_bonus": 20,
                "proximity_bonus_cap": 4,
            }
        }
    }
    agent = SMCAgent(cfg)
    dealing_range = {"high": 4680.0, "low": 4640.0}
    # Candidate 1: Shallow OB near 4665 (62% of range)
    cand_shallow = {
        "poi_type": "order_block",
        "zone": {"top": 4666.0, "bottom": 4664.0},
        "mitigation_status": "FRESH",
        "displacement_score": 5.0,
    }
    # Candidate 2: Deep Extreme OB near 4642 (5% of range, Deep Discount)
    cand_deep = {
        "poi_type": "order_block",
        "zone": {"top": 4643.0, "bottom": 4641.0},
        "mitigation_status": "FRESH",
        "displacement_score": 5.0,
    }
    ranked_shallow = agent._rank_poi_candidate(cand_shallow, "BUY", 4670.0, 3.0, {"trend": "BULLISH"}, {}, dealing_range=dealing_range)
    ranked_deep = agent._rank_poi_candidate(cand_deep, "BUY", 4670.0, 3.0, {"trend": "BULLISH"}, {}, dealing_range=dealing_range)
    
    assert float(ranked_deep["rank_score"]) > float(ranked_shallow["rank_score"])
    assert "deep_discount_preferred" in ranked_deep["rank_reasons"]
