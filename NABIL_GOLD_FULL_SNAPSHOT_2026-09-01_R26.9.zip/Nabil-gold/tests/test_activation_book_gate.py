"""A pending order asks the LIVE book before it becomes a position.

Operator 2026-08-18: 'الصفقة المعلقة لا تنتظر توافق الوكلاء في الاساسية
والاضافية ستدخل الا اذا حذفت الصفقة' — consensus was checked at PLACEMENT,
never at ACTIVATION. A LIMIT placed at 10:00 under a BUY consensus could
fill at 16:00 into a book that had flipped fully SELL, and the ADD leg
fills precisely when price moved 150 points AGAINST the thesis.

The design (veto, not re-admission):
  * >= min_opposing_agents (2) QUALIFIED (>= 65) agents voting the opposite
    way at touch time -> the pending is CANCELLED, with the opponents named;
  * an ADD/STANDBY leg whose PRIMARY already stopped out is cancelled at
    touch — averaging into a rejected thesis is not an add;
  * a lukewarm, missing, or stale book activates as planned: waiting out
    the pullback is the whole idea of a LIMIT, so the gate fails OPEN.

The freshest book travels via services/agent_book_store.py: the analysis
cycle writes it every 5 minutes; the trade-update process reads it (stale
after 10 minutes = no book).
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from agents.open_trades_manager import OpenTradesManager
from services.agent_book_store import book_path, load_agent_book, save_agent_book

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def _manager(**gate_overrides):
    cfg = json.loads(json.dumps(CONFIG))
    gate = cfg.setdefault("pending_freshness", {}).setdefault("activation_book_gate", {})
    gate.update({"enabled": True, "min_opposing_agents": 2, "cancel_orphaned_add": True})
    gate.update(gate_overrides)
    return OpenTradesManager(cfg)


def _opposing_book(direction="SELL", n=2, conf=70.0):
    agents = ["technical", "multitimeframe", "classical", "smc", "price_action"]
    book = {}
    for i, name in enumerate(agents):
        if i < n:
            book[name] = {"direction": direction, "confidence": conf}
        else:
            book[name] = {"direction": "WAIT", "confidence": 30.0}
    return book


# ── the veto itself ─────────────────────────────────────────────────────────

def test_two_qualified_opponents_veto_a_buy_activation():
    verdict = _manager()._activation_book_veto(_opposing_book("SELL", 2), "BUY")
    assert verdict["veto"] is True
    assert len(verdict["opponents"]) == 2


def test_one_opponent_is_not_enough():
    verdict = _manager()._activation_book_veto(_opposing_book("SELL", 1), "BUY")
    assert verdict["veto"] is False


def test_unqualified_opponents_do_not_count():
    """Two dissenters under the 65 bar are noise, not a flip."""
    verdict = _manager()._activation_book_veto(_opposing_book("SELL", 2, conf=64.9), "BUY")
    assert verdict["veto"] is False


def test_same_direction_book_never_vetoes():
    verdict = _manager()._activation_book_veto(_opposing_book("BUY", 3), "BUY")
    assert verdict["veto"] is False


def test_missing_book_fails_open():
    verdict = _manager()._activation_book_veto(None, "BUY")
    assert verdict["veto"] is False
    assert verdict["available"] is False


def test_gate_kill_switch():
    manager = _manager(enabled=False)
    verdict = manager._activation_book_veto(_opposing_book("SELL", 3), "BUY")
    assert verdict["veto"] is False


# ── orphaned ADD ────────────────────────────────────────────────────────────

def _ladder_pair(lead_status="SL_HIT", lead_result="LOSS"):
    scenario = "SCENARIO::XAU/USD::TEST"
    lead = {
        "id": "LEAD", "status": lead_status, "result": lead_result,
        "signal_snapshot": {"setup_context": {
            "scenario_id": scenario, "pending_plan_role": "PRIMARY"}},
    }
    add = {
        "id": "ADD", "status": "PENDING",
        "signal_snapshot": {"setup_context": {
            "scenario_id": scenario, "pending_plan_role": "STANDBY"}},
    }
    return lead, add


def test_add_whose_lead_stopped_out_is_orphaned():
    lead, add = _ladder_pair("SL_HIT", "LOSS")
    review = _manager()._orphaned_add_review(add, [lead, add])
    assert review["orphaned"] is True
    assert review["lead_id"] == "LEAD"


def test_add_with_a_living_lead_is_not_orphaned():
    lead, add = _ladder_pair("OPEN", None)
    review = _manager()._orphaned_add_review(add, [lead, add])
    assert review["orphaned"] is False


def test_primary_legs_are_never_orphans():
    lead, _ = _ladder_pair("SL_HIT", "LOSS")
    review = _manager()._orphaned_add_review(lead, [lead])
    assert review["orphaned"] is False


# ── the book store ──────────────────────────────────────────────────────────

def test_book_store_roundtrip(tmp_path: Path):
    save_agent_book("XAU/USD", {"technical": {"direction": "BUY", "confidence": 71}},
                    root=tmp_path)
    book = load_agent_book("XAU/USD", root=tmp_path)
    assert book["technical"]["direction"] == "BUY"


def test_stale_book_reads_as_none(tmp_path: Path):
    save_agent_book("XAU/USD", {"technical": {"direction": "BUY", "confidence": 71}},
                    root=tmp_path)
    import time as _t
    assert load_agent_book("XAU/USD", root=tmp_path,
                           now=_t.time() + 11 * 60) is None


def test_corrupt_book_reads_as_none(tmp_path: Path):
    path = book_path("XAU/USD", tmp_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("{broken", encoding="utf-8")
    assert load_agent_book("XAU/USD", root=tmp_path) is None


# ── wiring ──────────────────────────────────────────────────────────────────

def test_analysis_writes_and_updates_read_the_book():
    import io
    analysis = io.open(ROOT / "scripts" / "run_analysis.py", encoding="utf-8").read()
    updates = io.open(ROOT / "scripts" / "run_trade_updates.py", encoding="utf-8").read()
    assert "save_agent_book" in analysis
    assert "load_agent_book" in updates
    assert "agent_details=_activation_book" in updates


def test_gate_runs_in_both_activation_paths():
    import io
    src = io.open(ROOT / "agents" / "open_trades_manager.py", encoding="utf-8").read()
    assert src.count("_activation_gate_block(") >= 3  # def + touch + zone-touch


def test_shipped_config_carries_the_gate():
    gate = CONFIG["pending_freshness"]["activation_book_gate"]
    assert gate["enabled"] is True
    assert gate["min_opposing_agents"] == 2
    assert gate["cancel_orphaned_add"] is True
