"""Display L1/L2 as independent liquidity zones without touching targets."""
from __future__ import annotations

from copy import deepcopy

from services.liquidity_display import liquidity_display_zones
from services.telegram_bot import TelegramService
from utils import trading_rules as tr


CONFIG = {
    "symbol": "XAU/USD",
    "instruments": [{"symbol": "XAU/USD", "point_size": 0.10}],
    "risk_settings": {
        "min_tp1_rr": 0.8,
        "min_tp2_multiple_of_tp1": 2.0,
        "max_tp2_beyond_tp1_points": 200,
    },
    "session_plan_delivery": {
        "liquidity_display": {
            "min_independent_separation_points": 100,
            "min_independent_separation_rr": 0.5,
        }
    },
}


def test_fifty_point_levels_merge_into_one_l1_zone() -> None:
    # SELL entry 4400, stop 4430 -> R=300 points; independent spacing is
    # max(100, 0.5R=150) = 150 points.
    display = liquidity_display_zones(
        levels=[4375.0, 4370.0, 4350.0],
        direction="SELL", entry=4400.0, stop=4430.0,
        symbol="XAU/USD", config=CONFIG,
    )
    assert display["min_separation_points"] == 150.0
    assert display["l1"]["anchor"] == 4375.0
    assert display["l1"]["clustered"] is True
    assert display["l1"]["low"] == 4370.0
    assert display["l1"]["high"] == 4375.0
    assert display["l2"]["anchor"] == 4350.0


def test_no_fake_l2_when_only_nearby_levels_exist() -> None:
    display = liquidity_display_zones(
        levels=[4375.0, 4370.0],
        direction="SELL", entry=4400.0, stop=4430.0,
        symbol="XAU/USD", config=CONFIG,
    )
    assert display["l1"]["clustered"] is True
    assert display["l2"] is None


def test_one_hundred_points_is_the_floor_when_half_r_is_smaller() -> None:
    # R=100 points -> 0.5R=50, therefore the configured 100-point floor wins.
    display = liquidity_display_zones(
        levels=[4385.0, 4375.0],
        direction="SELL", entry=4400.0, stop=4410.0,
        symbol="XAU/USD", config=CONFIG,
    )
    assert display["min_separation_points"] == 100.0
    assert display["l1"]["anchor"] == 4385.0
    assert display["l2"]["anchor"] == 4375.0


def test_buy_side_is_the_exact_mirror() -> None:
    display = liquidity_display_zones(
        levels=[4425.0, 4430.0, 4450.0],
        direction="BUY", entry=4400.0, stop=4370.0,
        symbol="XAU/USD", config=CONFIG,
    )
    assert display["l1"]["anchor"] == 4425.0
    assert display["l1"]["low"] == 4425.0
    assert display["l1"]["high"] == 4430.0
    assert display["l2"]["anchor"] == 4450.0


def test_display_selector_does_not_change_canonical_tp1_tp2() -> None:
    levels = [4375.0, 4370.0, 4350.0]
    before = tr.targets_law(
        direction="SELL", entry=4400.0, risk_price=30.0,
        levels=levels, cfg=CONFIG, symbol="XAU/USD",
    )
    cfg_before = deepcopy(CONFIG)
    liquidity_display_zones(
        levels=levels, direction="SELL", entry=4400.0, stop=4430.0,
        symbol="XAU/USD", config=CONFIG,
    )
    after = tr.targets_law(
        direction="SELL", entry=4400.0, risk_price=30.0,
        levels=levels, cfg=CONFIG, symbol="XAU/USD",
    )
    assert before == after
    assert CONFIG == cfg_before


def test_telegram_labels_references_separately_from_execution_targets(monkeypatch) -> None:
    captured = {}
    service = TelegramService(CONFIG)

    def capture(text: str, **kwargs):
        captured["text"] = text
        return True

    monkeypatch.setattr(service, "send_message", capture)
    plan = {
        "symbol": "XAU/USD", "session_bias": "SELL",
        "plan_ready": True, "plan_status": "READY",
        "session_label": "Test", "session_quality": "HIGH",
        "planner_confidence": 80, "planner_grade": "A",
        "map_display_quality": {"score": 80, "grade": "A"},
        "authority_state": "WEAK",
        "primary_entry_zone": {"low": 4397.0, "high": 4403.0},
        "primary_entry_price": 4400.0,
        "invalidation_level": 4430.0,
        "target_liquidity": 4340.0,
        "primary_execution": {
            "stop_loss": 4430.0,
            "tp1": 4376.0,
            "tp2": 4352.0,
        },
        "primary_poi": {
            "details": {
                "liquidity": {
                    "sell_side": [4375.0, 4370.0, 4350.0],
                    "buy_side": [4425.0],
                }
            }
        },
        "execution_admission": {"allow": True, "path": "THREE_AGENT_CONSENSUS", "confidence": 75},
        "agent_book_summary": {"support_count": 3, "opposition_count": 0, "inactive_count": 2},
        "agent_min_confidence": 67,
    }
    assert service.send_session_plan(plan)
    text = captured["text"]
    assert "TP1 4376.00" in text
    assert "TP2 4352.00" in text
    assert "LIQUIDITY REFERENCES" in text
    assert "L1 4375.00" in text
    assert "zone 4370.00–4375.00" in text
    assert "L2 4350.00" in text
    assert "L2 4370.00" not in text
    assert "L1/L2 are liquidity references; TP1/TP2 above are the execution targets" in text
