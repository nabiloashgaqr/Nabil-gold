"""Non-trading measurement capture and summary foundations."""
from __future__ import annotations

import json
from copy import deepcopy

from services.agent_measurement import record_agent_measurement


CONFIG = {
    "schedule": {"timezone": "Asia/Hebron"},
    "agent_measurement": {"enabled": True},
    "agent_weights": {
        "technical": .20, "multitimeframe": .15, "classical": .25, "smc": .20,
        "price_action": .20,
    },
    "signal_requirements": {
        "agent_min_confidence": 67,
        "min_agents_agree": 3,
        "min_consensus_confidence": 72,
        "two_agent_entry": {"enabled": True, "min_agents_agree": 2,
                            "min_consensus_confidence": 72,
                            "macro_confirmation": {"enabled": True, "min_confidence": 55},
                            "gemini_confirmation": {"enabled": True, "min_confidence": 70}},
    },
}


def _results() -> dict:
    fusion = {"directional_count": 2, "directional_coverage": .5,
              "coherence": .8, "average_directional_confidence": 75,
              "participation_factor": .875, "conflict_wait": False}
    return {
        "current_price": 4400.0,
        "shared_market_data": {"snapshot_id": "MT5BOOK::measure",
                               "timeframes": {"5m": {"uses_closed_candles": True}}},
        "technical": {"signal": "WAIT", "confidence": 60},
        "multitimeframe": {"signal": "BUY", "confidence": 68, "timeframe_fusion": fusion},
        "classical": {"signal": "BUY", "confidence": 70, "timeframe_fusion": fusion},
        "smc": {"signal": "WAIT", "confidence": 32,
                "timeframe_analysis": {"5m": {"directional_score": 2, "confidence": 34}},
                "setup_candidates": [{"id": "x"}],
                "setup_structure": {"direction": "BUY", "setup_type": "OB",
                                    "quality_score": 60, "thesis_dominance_score": 55,
                                    "return_probability_score": 50, "trigger_score": 40}},
        "price_action": {"signal": "BUY", "confidence": 75, "timeframe_fusion": fusion},
        "auction_flow": {"signal": "WAIT", "confidence": 62, "state": "BALANCED_AUCTION",
                         "raw_edge": -.25, "family_scores": {"value_location": -.5,
                         "acceptance_rejection": 0}, "activity_ratio": 1.1,
                         "broker_offset_seconds": 10800},
        "session_plan": {"plan_ready": False, "plan_status": "WATCH_ONLY"},
    }


def test_measurement_writes_deduplicated_diagnostic_without_mutation(tmp_path) -> None:
    cfg = deepcopy(CONFIG)
    cfg["agent_measurement"]["storage_dir"] = str(tmp_path)
    results = _results()
    before = deepcopy(results)
    path = record_agent_measurement(results, {"decision": "WAIT"}, cfg)
    assert path is not None and path.exists()
    record_agent_measurement(results, {"decision": "WAIT"}, cfg)
    lines = path.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1
    row = json.loads(lines[0])
    assert row["non_trading_measurement"] is True
    assert row["fusion"]["price_action"]["pre_participation_confidence"] == 60.0
    assert row["smc_measurement"]["frames"]["5m"]["distance_to_buy_threshold"] == 2.0
    assert row["auction_measurement"]["broker_offset_seconds"] == 10800
    assert results == before


def test_measurement_disabled_writes_nothing(tmp_path) -> None:
    cfg = deepcopy(CONFIG)
    cfg["agent_measurement"] = {"enabled": False, "storage_dir": str(tmp_path)}
    assert record_agent_measurement(_results(), {"decision": "WAIT"}, cfg) is None
    assert list(tmp_path.iterdir()) == []
