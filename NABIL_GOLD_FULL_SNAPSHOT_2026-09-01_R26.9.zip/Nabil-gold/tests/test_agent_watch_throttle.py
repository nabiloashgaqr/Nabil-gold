"""AGENT WATCH fires on CHANGE, not persistence (operator 2026-08-17b).

Live complaint, same day the card was born: six near-identical cards
between 10:01 and 11:01 for one unchanged watch state. Root cause: the
telegram dedup window (180s) is shorter than the analysis cycle (300s),
and the card body drifts a little every cycle (net 80.3 -> 79.3 -> 76.9),
so text-level dedup can never catch it.

The throttle decides from STATE: NEW / FLIP / SUPPORTERS / CONFIDENCE /
hourly REMINDER. Everything else is suppressed. The state clears when the
book stops qualifying, so the next appearance announces as NEW.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.agent_watch_throttle import (
    DEFAULTS,
    decide,
    load_states,
    save_states,
    throttle_config,
)

CFG = dict(DEFAULTS)
T0 = 1_000_000.0
MIN_GAP = float(CFG["min_minutes_between_cards"]) * 60
REMIND = float(CFG["reminder_interval_minutes"]) * 60


def _watch(side="BUY", supporters=("technical", "multitimeframe"), conf=80.0):
    return {"side": side, "supporters": list(supporters), "confidence": conf}


def test_first_appearance_sends_new():
    verdict = decide(None, **_watch(), cfg=CFG, now=T0)
    assert verdict["send"] is True
    assert verdict["kind"] == "NEW"
    assert verdict["state"]["first_seen"] == T0


def test_unchanged_state_next_cycle_is_suppressed():
    """The exact live failure: same side, same supporters, tiny net drift."""
    first = decide(None, **_watch(conf=80.3), cfg=CFG, now=T0)
    second = decide(first["state"], **_watch(conf=79.3), cfg=CFG, now=T0 + 300)
    third = decide(second["state"], **_watch(conf=76.9), cfg=CFG, now=T0 + 600)

    assert second["send"] is False
    assert third["send"] is False


def test_six_card_morning_becomes_two():
    """Replay 10:01->11:01 (7 cycles): NEW at 10:01, SUPPORTERS at 10:56."""
    sent = []
    state = None
    cycles = [
        (0,    _watch(conf=80.3)),
        (900,  _watch(conf=79.3)),
        (1200, _watch(conf=76.9)),
        (1500, _watch(conf=76.9)),
        (3300, _watch(supporters=("multitimeframe", "price_action"), conf=80.9)),
        (3600, _watch(supporters=("multitimeframe", "classical"), conf=76.1)),
    ]
    for offset, watch in cycles:
        verdict = decide(state, **watch, cfg=CFG, now=T0 + offset)
        state = verdict["state"]
        if verdict["send"]:
            sent.append(verdict["kind"])
    # 10:01 NEW; 10:56 line-up change (past the 15-min floor); 11:01 line-up
    # changed again but only 5 minutes later -> suppressed by the floor.
    assert sent == ["NEW", "SUPPORTERS"]


def test_side_flip_sends_immediately_ignoring_cooldown():
    first = decide(None, **_watch("BUY"), cfg=CFG, now=T0)
    flip = decide(first["state"], **_watch("SELL"), cfg=CFG, now=T0 + 300)
    assert flip["send"] is True
    assert flip["kind"] == "FLIP"


def test_material_confidence_jump_sends_after_floor():
    first = decide(None, **_watch(conf=68.0), cfg=CFG, now=T0)
    jump = decide(first["state"], **_watch(conf=79.0), cfg=CFG, now=T0 + MIN_GAP + 1)
    assert jump["send"] is True
    assert jump["kind"] == "CONFIDENCE"


def test_confidence_jump_inside_floor_waits():
    first = decide(None, **_watch(conf=68.0), cfg=CFG, now=T0)
    early = decide(first["state"], **_watch(conf=79.0), cfg=CFG, now=T0 + 300)
    assert early["send"] is False


def test_hourly_reminder_when_nothing_changes():
    first = decide(None, **_watch(), cfg=CFG, now=T0)
    quiet = decide(first["state"], **_watch(), cfg=CFG, now=T0 + REMIND - 60)
    due = decide(quiet["state"], **_watch(), cfg=CFG, now=T0 + REMIND + 60)
    assert quiet["send"] is False
    assert due["send"] is True
    assert due["kind"] == "REMINDER"


def test_reminder_zero_disables_reminders():
    cfg = dict(CFG, reminder_interval_minutes=0)
    first = decide(None, **_watch(), cfg=cfg, now=T0)
    later = decide(first["state"], **_watch(), cfg=cfg, now=T0 + 86_400)
    assert later["send"] is False


def test_first_seen_survives_updates():
    """The reminder line says 'since HH:MM' — that anchor must not drift."""
    first = decide(None, **_watch(conf=68.0), cfg=CFG, now=T0)
    jump = decide(first["state"], **_watch(conf=79.0), cfg=CFG, now=T0 + MIN_GAP + 1)
    assert jump["state"]["first_seen"] == T0


def test_state_roundtrip_and_corrupt_file_fails_open(tmp_path: Path):
    path = tmp_path / "agent_watch_state.json"
    save_states(path, {"XAU/USD": {"side": "BUY"}})
    assert load_states(path)["XAU/USD"]["side"] == "BUY"

    path.write_text("{corrupt", encoding="utf-8")
    assert load_states(path) == {}, "corrupt state must read as 'no watch', never crash"


def test_throttle_config_reads_operator_knobs():
    cfg = throttle_config({
        "session_plan_delivery": {"monitoring_only": {"agent_watch_throttle": {
            "reminder_interval_minutes": 120, "material_confidence_change": 5,
        }}}})
    assert cfg["reminder_interval_minutes"] == 120
    assert cfg["material_confidence_change"] == 5
    assert cfg["min_minutes_between_cards"] == DEFAULTS["min_minutes_between_cards"]


def test_live_wiring_clears_state_and_logs_suppression():
    import io
    src = io.open("scripts/run_analysis.py", encoding="utf-8").read()
    assert "AGENT WATCH suppressed (unchanged)" in src
    assert "AGENT WATCH state cleared" in src
    assert "agent_watch_throttle" in src


# ── flap guard (operator 2026-08-17c) ───────────────────────────────────────
# Live: WTI hovered around the 65 bar — state cleared 22:01, NEW card 22:21,
# cleared 22:26, NEW card 22:31. Three "NEW" announcements for one story.

from services.agent_watch_throttle import should_clear

GRACE = float(DEFAULTS["clear_grace_minutes"]) * 60


def test_dequalified_state_survives_inside_grace():
    state = decide(None, **_watch(), cfg=CFG, now=T0)["state"]
    assert should_clear(state, CFG, now=T0 + GRACE - 60) is False


def test_dequalified_state_clears_after_grace():
    state = decide(None, **_watch(), cfg=CFG, now=T0)["state"]
    assert should_clear(state, CFG, now=T0 + GRACE + 60) is True


def test_flapping_book_is_a_continuation_not_a_new_card():
    """The exact WTI night: qualify, drop out one cycle, return — the
    return must be suppressed as unchanged, not announced as NEW."""
    first = decide(None, **_watch(conf=83.3), cfg=CFG, now=T0)
    # one cycle later the book de-qualifies; grace keeps the state
    assert should_clear(first["state"], CFG, now=T0 + 300) is False
    # two cycles later it returns, barely changed
    back = decide(first["state"], **_watch(conf=78.7), cfg=CFG, now=T0 + 600)
    assert back["send"] is False, "a flap return re-announced itself as NEW"


def test_grace_zero_restores_instant_clearing():
    cfg = dict(CFG, clear_grace_minutes=0)
    state = decide(None, **_watch(), cfg=cfg, now=T0)["state"]
    assert should_clear(state, cfg, now=T0 + 1) is True


def test_grace_anchors_on_last_seen_not_last_card():
    """A long-standing watch (old card) that saw the book this cycle must
    still be protected — the anchor is when the book was last SEEN."""
    first = decide(None, **_watch(conf=70.0), cfg=CFG, now=T0)
    seen = decide(first["state"], **_watch(conf=70.5), cfg=CFG, now=T0 + 7200)
    assert seen["send"] in (True, False)  # reminder may fire; irrelevant here
    assert should_clear(seen["state"], CFG, now=T0 + 7200 + 300) is False


def test_wti_card_does_not_promise_macro():
    """Macro is a gold verdict; the WTI blocked line must not advertise it."""
    import io
    src = io.open("scripts/run_analysis.py", encoding="utf-8").read()
    assert "macro does not judge this symbol" in src
    block = src.split("AGENT WATCH card")[1]
    assert 'normalize_symbol(symbol) != "XAU/USD"' in block[:12000]


def test_shipped_config_carries_the_throttle():
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    knobs = cfg["session_plan_delivery"]["monitoring_only"]["agent_watch_throttle"]
    assert knobs["min_minutes_between_cards"] == 15
    assert knobs["reminder_interval_minutes"] == 60
