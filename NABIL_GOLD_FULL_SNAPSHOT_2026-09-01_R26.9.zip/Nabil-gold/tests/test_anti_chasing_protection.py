from datetime import datetime, timezone, timedelta
from services.scenario_governor import ScenarioGovernor
from services.adaptive_execution import AdaptiveExecutionService
from services.pending_governor import PendingGovernor
from utils.helpers import load_config


def _base_config():
    cfg = load_config()
    cfg.setdefault("scenario_governor", {})["enforce_anti_chasing"] = True
    cfg.setdefault("adaptive_execution", {})["enforce_anti_chasing"] = True
    cfg.setdefault("adaptive_execution", {})["allow_continuation_replacement"] = False
    cfg.setdefault("pending_governor", {})["enforce_anti_chasing"] = True
    return cfg


def test_scenario_governor_blocks_higher_buy_entry_chasing():
    cfg = _base_config()
    gov = ScenarioGovernor(cfg)
    
    # Existing BUY pending order at 4636.15 (discount)
    old_pending = {
        "id": "TRADE_BUY_ORIGINAL",
        "symbol": "XAU/USD",
        "type": "BUY",
        "status": "PENDING",
        "entry_price": 4636.15,
        "stop_loss": 4596.15,
        "created_at": (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat(),
        "signal_snapshot": {
            "quality": {"score": 74.0, "grade": "B"},
            "pending_runtime": {"freshness_state": "FRESH"},
            "setup_context": {"thesis_dominance_score": 73.6, "selection_role": "PRIMARY"},
        },
    }
    
    # New plan generated higher up at 4647.97 with higher score 87.1
    new_plan = {
        "symbol": "XAU/USD",
        "session_bias": "BUY",
        "plan_ready": True,
        "scenario_id": "SCENARIO::NEW_SESSION",
        "planner_confidence": 87.1,
        "primary_poi": {"thesis_dominance_score": 85.0, "direction": "BUY"},
        "primary_leg": {"entry_price": 4647.97, "stop_loss": 4618.00},
    }
    
    review = gov.review_new_plan(new_plan, [old_pending])
    assert review["action"] == "KEEP_EXISTING_FAMILY"
    assert "Anti-chasing" in review["reason"]
    assert "4636.15" in review["reason"]


def test_scenario_governor_blocks_lower_sell_entry_chasing():
    cfg = _base_config()
    gov = ScenarioGovernor(cfg)
    
    old_pending = {
        "id": "TRADE_SELL_ORIGINAL",
        "symbol": "XAU/USD",
        "type": "SELL",
        "status": "PENDING",
        "entry_price": 4045.00,
        "created_at": (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat(),
        "signal_snapshot": {
            "quality": {"score": 74.0, "grade": "B"},
            "pending_runtime": {"freshness_state": "FRESH"},
            "setup_context": {"thesis_dominance_score": 73.6, "selection_role": "PRIMARY"},
        },
    }
    
    new_plan = {
        "symbol": "XAU/USD",
        "session_bias": "SELL",
        "plan_ready": True,
        "scenario_id": "SCENARIO::NEW_SESSION_SELL",
        "planner_confidence": 88.0,
        "primary_poi": {"thesis_dominance_score": 85.0, "direction": "SELL"},
        "primary_leg": {"entry_price": 4020.00, "stop_loss": 4045.00},
    }
    
    review = gov.review_new_plan(new_plan, [old_pending])
    assert review["action"] == "KEEP_EXISTING_FAMILY"
    assert "Anti-chasing" in review["reason"]


def test_adaptive_execution_blocks_continuation_chasing():
    cfg = _base_config()
    svc = AdaptiveExecutionService(cfg)
    
    old_pending = {
        "id": "TRADE_BUY_ORIGINAL",
        "symbol": "XAU/USD",
        "type": "BUY",
        "status": "PENDING",
        "entry_price": 4647.97,
        "stop_loss": 4618.00,
        "tp2": 4720.00,
    }
    
    decision = {
        "decision": "BUY",
        "symbol": "XAU/USD",
        "current_price": 4672.02,
        "signal": {
            "type": "BUY",
            "entry": {"price": 4659.58},
            "stop_loss": 4623.00,
            "tp2": 4732.64,
        },
        "setup_context": {
            "setup_type": "STRUCTURE_CONTINUATION",
            "trigger_state": "REJECTION_CONFIRMED",
            "trigger_score": 80.0,
            "thesis_dominance_score": 85.0,
            "return_probability_score": 80.0,
        },
    }
    
    review = svc.review(decision, [old_pending])
    assert review["action"] in {"KEEP_PENDING", "NO_TRADE_MISSED_MOVE"}
    assert review["action"] != "REPLACE_WITH_CONTINUATION"
    assert review.get("action") != "PROMOTE_TO_MARKET"
