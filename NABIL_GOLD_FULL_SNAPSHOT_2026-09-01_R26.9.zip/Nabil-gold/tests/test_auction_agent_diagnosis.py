# -*- coding: utf-8 -*-
"""BUILD31-R13: auction-agent data gates + the diagnosis tool.

Regression 1: _data_problem MUST use its `symbol` parameter (the R13
per-symbol spread patch briefly used self.symbol, which AuctionFlowAgent
does not define - that would have crashed the live agent every cycle).
Regression 2: the per-symbol spread cap flows through the agent (a 12-pt
EUR/USD spread must NOT trip the gate under the R13 cap of 25).
"""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from copy import deepcopy
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from agents.auction_flow_agent import AuctionFlowAgent  # noqa: E402

SCRIPT = os.path.join(ROOT, "scripts", "diagnose_auction_agent.py")


class _FakeTick:
    """Minimal mt5 tick look-alike for AuctionFlowStore.record_tick."""

    def __init__(self, bid, ask):
        self.bid, self.ask, self.time_msc, self.time = bid, ask, 0, 0


def _forex_config(tmp_root: Path, symbol="EUR/USD", required=True):
    cfg = {
        "symbol": symbol,
        "auction_flow": {
            "enabled": True,
            # BASE paths (unsuffixed): the agent applies its own per-symbol
            # suffixing exactly like the real config.json does.
            "storage_path": str(tmp_root / "storage" / "auction_flow.sqlite3"),
            "calibration_path": str(tmp_root / "storage" / "model_calibration" / "auction_flow_v1.json"),
            "calibration_required": required,
            "calibration_version": "auction_flow_v1",
            "min_calibration_samples": 300,
            "max_tick_age_seconds": 5,
            "max_heartbeat_age_seconds": 10,
            "min_unique_ticks_5m": 60,
        },
        "filters": {"max_spread_points_by_symbol": {"EUR/USD": 25.0}},
    }
    cfg["instruments"] = [{"symbol": symbol, "enabled": True,
                           "auction_flow": {"calibration_required": required}}]
    return cfg


def _state(tick_age=99.0, heartbeat=1.0, ticks=100, spread=0.00008, session_ticks=50):
    # session_ticks is read at the TOP level of state (matches the agent),
    # the rest live under state["health"].
    return {"session_ticks": session_ticks,
            "health": {
        "last_tick_age_seconds": tick_age,
        "heartbeat_age_seconds": heartbeat,
        "unique_ticks_5m": ticks,
        "current_spread": spread,
    }}


class TestDataProblemGate(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.agent = AuctionFlowAgent(_forex_config(Path(self.tmp.name)))

    def tearDown(self):
        self.tmp.cleanup()

    def test_uses_symbol_parameter_no_attribute_error(self):
        # regression: must NOT raise AttributeError(self.symbol)
        problem = self.agent._data_problem(_state(tick_age=99.0), 0.00001, "EUR/USD")
        self.assertIsNotNone(problem)
        self.assertEqual(problem[0], "LIVE_TICK_FEED_STALE")

    def test_forex_spread_12pts_passes_under_r13_cap_25(self):
        problem = self.agent._data_problem(
            _state(tick_age=1.0, heartbeat=1.0, ticks=100, spread=0.00012),
            0.00001, "EUR/USD")
        self.assertIsNone(problem)  # 12 pts < 25-pt cap -> data gates clear

    def test_old_global_cap_would_have_blocked_the_same_spread(self):
        from utils.instruments import max_spread_points_for
        legacy = {"filters": {"max_spread_points": 5}}
        self.assertEqual(max_spread_points_for("EUR/USD", legacy), 5.0)
        # 12 pts > 5 -> the pre-R13 behaviour that starved the agent to WAIT/50


class TestDiagnosisTool(unittest.TestCase):
    def test_tool_names_the_waiting_gate_on_empty_store(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            (tmp / "storage" / "model_calibration").mkdir(parents=True)
            (tmp / "config.json").write_text(json.dumps(
                _forex_config(tmp, required=False)), encoding="utf-8")
            proc = subprocess.run([sys.executable, SCRIPT, "--root", td,
                                   "--symbols", "EUR/USD"],
                                  capture_output=True, text=True, timeout=120)
            self.assertEqual(proc.returncode, 0, proc.stderr[-800:])
            self.assertIn("WAIT/LIVE_TICK_FEED_STALE", proc.stdout)
            self.assertIn("displayed 50% (WAIT floor)", proc.stdout)
            self.assertIn("tick collector", proc.stdout)

    def test_diagnose_reads_the_real_once_suffixed_store(self):
        """R15 regression: the tool used to double-suffix the store path
        (auction_flow_eurusd_eurusd.sqlite3) and falsely report
        'heartbeat NEVER written' for healthy stores."""
        from services.auction_flow_store import AuctionFlowStore

        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            (tmp / "storage" / "model_calibration").mkdir(parents=True)
            (tmp / "config.json").write_text(json.dumps(
                _forex_config(tmp, required=False)), encoding="utf-8")
            real_store = tmp / "storage" / "auction_flow_eurusd.sqlite3"
            store = AuctionFlowStore(str(real_store))  # the ONCE-suffixed path
            for _ in range(61):  # min_unique_ticks_5m = 60: simulate a live feed
                store.record_tick(_FakeTick(1.16434, 1.16440))
            store.mark_heartbeat()

            proc = subprocess.run([sys.executable, SCRIPT, "--root", td,
                                   "--symbols", "EUR/USD"],
                                  capture_output=True, text=True, timeout=120)
            self.assertEqual(proc.returncode, 0, proc.stderr[-800:])
            # the regression core: the REAL store is read (fresh finite ages),
            # never a double-suffixed empty one
            self.assertNotIn("NEVER", proc.stdout)
            self.assertNotIn("eurusd_eurusd", proc.stdout)
            self.assertIn("last_tick_age        : 0.", proc.stdout)
            self.assertIn("heartbeat_age        : 0.", proc.stdout)

    def test_tool_reports_missing_calibration_when_required(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            (tmp / "storage" / "model_calibration").mkdir(parents=True)
            (tmp / "config.json").write_text(json.dumps(
                _forex_config(tmp, required=True)), encoding="utf-8")
            proc = subprocess.run([sys.executable, SCRIPT, "--root", td,
                                   "--symbols", "EUR/USD"],
                                  capture_output=True, text=True, timeout=120)
            self.assertEqual(proc.returncode, 0, proc.stderr[-800:])
            self.assertIn("WAIT/CALIBRATION_INVALID", proc.stdout)
            self.assertIn("file MISSING", proc.stdout)


if __name__ == "__main__":
    unittest.main()
