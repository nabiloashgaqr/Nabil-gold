# -*- coding: utf-8 -*-
"""BUILD31-R12: tests for scripts/audit_recent_trades.py (forensic trade-book audit).

The audit tool is a standalone forensic reader over storage/trades.json.
These tests validate its guard-replay logic and its CLI contract on a
synthetic book (the shipped book is intentionally empty - never used here).
"""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPT = os.path.join(ROOT, "scripts", "audit_recent_trades.py")

sys.path.insert(0, os.path.join(ROOT, "scripts"))

audit = None  # imported in setUpModule (skips cleanly if the file is missing)


def setUpModule():
    global audit
    if not os.path.exists(SCRIPT):
        raise unittest.SkipTest("audit_recent_trades.py not present")
    import importlib.util

    spec = importlib.util.spec_from_file_location("audit_recent_trades", SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    audit = mod


def _ts(hours_ago):
    return (datetime.now(timezone.utc) - timedelta(hours=hours_ago)).replace(
        microsecond=0
    ).isoformat()


def _quiet_ts(hour="03", minute="00"):
    """Pinned quiet-window timestamp (21:00-06:30 UTC) - keeps guard tests
    deterministic at any wall-clock time the suite runs."""
    return f"2026-08-27T{hour}:{minute}:00+00:00"


def _chase_loss(symbol="WTI/USD", hours_ago=None, direction="BUY", created_at=None):
    """A breakout-chase loser entered during quiet hours with weak evidence."""
    if created_at is None:
        created_at = _quiet_ts()
    return {
        "id": "SYN-1",
        "type": direction,
        "symbol": symbol,
        "entry_price": 75.50 if symbol == "WTI/USD" else 2648.0,
        "close_price": 74.90 if symbol == "WTI/USD" else 2642.0,
        "status": "SL_HIT",
        "created_at": created_at,
        "closed_at": _quiet_ts("04"),
        "confidence": 75,
        "signal_snapshot": {
            "strategy_profile": {"resolved_setup_type": "BREAKOUT_EXPANSION"},
            "smc": {"direction": "WAIT", "confidence": 40},
            "auction_flow": {"direction": "WAIT", "confidence": 45},
            "technical": {"atr": 0.5},
            "market_regime": {"regime": "CONSOLIDATION_RANGE"},
        },
    }


class TestQuietHoursClassification(unittest.TestCase):
    def test_quiet_window_branches(self):
        U = timezone.utc
        self.assertTrue(audit.in_quiet_hours(datetime(2026, 8, 26, 22, 0, tzinfo=U)))
        self.assertTrue(audit.in_quiet_hours(datetime(2026, 8, 26, 3, 0, tzinfo=U)))
        self.assertTrue(audit.in_quiet_hours(datetime(2026, 8, 26, 6, 29, tzinfo=U)))
        self.assertFalse(audit.in_quiet_hours(datetime(2026, 8, 26, 6, 30, tzinfo=U)))
        self.assertFalse(audit.in_quiet_hours(datetime(2026, 8, 26, 12, 0, tzinfo=U)))

    def test_hebron_day_rolls_at_03_local(self):
        # 01:00 UTC = 04:00 Hebron -> same UTC calendar date (after the 03:00 roll)
        ts = datetime(2026, 8, 27, 1, 0, tzinfo=timezone.utc)
        self.assertEqual(audit.hebron_day(ts).isoformat(), "2026-08-27")
        # 00:00 UTC = 03:00 Hebron exactly -> still same day (roll boundary)
        ts2 = datetime(2026, 8, 27, 0, 0, tzinfo=timezone.utc)
        self.assertEqual(audit.hebron_day(ts2).isoformat(), "2026-08-27")

    def test_pnl_points_uses_point_size(self):
        t = {"symbol": "XAU/USD", "type": "BUY", "entry_price": 2640.0,
             "close_price": 2642.0, "final_pnl": None, "current_pnl_points": None}
        self.assertAlmostEqual(audit.trade_pnl_points(t), 20.0, places=6)


class TestGuardReplay(unittest.TestCase):
    def test_quiet_hours_chase_loss_is_blocked(self):
        blocked, notes, unknown, arch, ev = audit.replay_guards(_chase_loss(), [])
        self.assertIn("QUIET_HOURS_21_06(chase)", blocked)
        self.assertIn("CONSOLIDATION_LOCKDOWN(chase)", blocked)
        # named setup types are reported verbatim; MOMENTUM_CHASE is the fallback label
        self.assertEqual(arch, "BREAKOUT_EXPANSION")

    def test_pullback_during_quiet_hours_is_a_note_not_a_block(self):
        t = _chase_loss()
        t["signal_snapshot"]["strategy_profile"]["resolved_setup_type"] = "ORDER_BLOCK_PULLBACK"
        t["signal_snapshot"]["smc"]["direction"] = "SELL"
        t["signal_snapshot"]["smc"]["confidence"] = 66
        blocked, notes, unknown, arch, ev = audit.replay_guards(t, [])
        self.assertEqual(blocked, [])
        self.assertTrue(any("pullback" in n for n in notes))

    def test_buy_the_dip_guard_uses_open_same_direction_trade(self):
        early = {"id": "EARLY", "type": "BUY", "symbol": "EUR/USD",
                 "entry_price": 1.08400, "status": "OPEN",
                 "created_at": _quiet_ts("01"), "signal_snapshot": {}}
        late = _chase_loss(symbol="EUR/USD", direction="BUY",
                           created_at=_quiet_ts("02"))
        late["entry_price"] = 1.08600  # bought HIGHER than the existing long
        blocked, notes, unknown, arch, ev = audit.replay_guards(late, [early])
        self.assertTrue(any("BUY_THE_DIP" in b for b in blocked))

    def test_flow_guard_blocks_when_neither_source_reaches_65(self):
        t = _chase_loss()
        t["signal_snapshot"]["auction_flow"] = {"direction": "BUY", "confidence": 60}
        t["signal_snapshot"]["smc"] = {"direction": "WAIT", "confidence": 40}
        blocked, notes, unknown, arch, ev = audit.replay_guards(t, [])
        self.assertIn("FLOW_GUARD_65(chase)", blocked)
        # 60 >= legacy bar 55 -> flagged as a would-pass-old casualty
        self.assertTrue(any("DELTA_55_to_65" in g for g in blocked))

    def test_flow_guard_passes_when_a_source_reaches_65(self):
        t = _chase_loss()
        t["signal_snapshot"]["auction_flow"] = {"direction": "BUY", "confidence": 68}
        t["signal_snapshot"]["smc"] = {"direction": "WAIT", "confidence": 40}
        blocked, notes, unknown, arch, ev = audit.replay_guards(t, [])
        self.assertFalse(any("FLOW_GUARD" in g for g in blocked))


class TestCliContract(unittest.TestCase):
    def test_cli_runs_on_synthetic_book_and_writes_json(self):
        book = [_chase_loss(hours_ago=1),
                _chase_loss(symbol="XAU/USD", hours_ago=30)]
        with tempfile.TemporaryDirectory() as td:
            book_path = os.path.join(td, "trades.json")
            out_path = os.path.join(td, "audit.json")
            with open(book_path, "w", encoding="utf-8") as fh:
                json.dump(book, fh)
            proc = subprocess.run(
                [sys.executable, SCRIPT, "--book", book_path, "--json", out_path],
                capture_output=True, text=True, timeout=120,
            )
            self.assertEqual(proc.returncode, 0, proc.stderr[-800:])
            self.assertIn("FORENSIC AUDIT", proc.stdout)
            with open(out_path, encoding="utf-8") as fh:
                payload = json.load(fh)
            self.assertIn("halt_replay", payload)
            self.assertEqual(payload["halt_replay"]["book_trades"], 2)
            for day in payload["days"].values():
                self.assertIn("guard_replay", day)
                self.assertIn("trades_detail", day)


if __name__ == "__main__":
    unittest.main()
