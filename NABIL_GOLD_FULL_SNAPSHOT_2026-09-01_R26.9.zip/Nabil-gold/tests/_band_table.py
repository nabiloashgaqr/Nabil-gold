# -*- coding: utf-8 -*-
"""R26.1 reference stop-law table shared by the band test files.

Gold is the reference (factor 1.0, floor 270 / cap 400). WTI uses factor 0.5
(floor 135 / cap 200); the four forex pairs use factor 2.25 (floor 600 /
cap 900 system points = 60-90 pips). Every band concept scales by the same
factor. Tests import these instead of hard-coding the retired R25.7-D
230/330 numbers.
"""
from __future__ import annotations

FLOOR = {"XAU/USD": 270, "WTI/USD": 135,
         "EUR/USD": 600, "GBP/USD": 600, "USD/CAD": 600, "USD/JPY": 600}
CAP = {"XAU/USD": 400, "WTI/USD": 200,
       "EUR/USD": 900, "GBP/USD": 900, "USD/CAD": 900, "USD/JPY": 900}
NOISE = {"XAU/USD": 200, "WTI/USD": 100,
         "EUR/USD": 450, "GBP/USD": 450, "USD/CAD": 450, "USD/JPY": 450}
BUFFER = {s: FLOOR[s] - NOISE[s] for s in FLOOR}

FIVE = ("WTI/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")
SIX = ("XAU/USD",) + FIVE

# representative price per symbol for clamp geometry tests
REF_PRICE = {"XAU/USD": 4580.61, "WTI/USD": 61.50,
             "EUR/USD": 1.15852, "GBP/USD": 1.35404,
             "USD/CAD": 1.39022, "USD/JPY": 154.20}


def floor_cap(symbol: str) -> tuple[float, float]:
    return float(FLOOR[symbol]), float(CAP[symbol])
