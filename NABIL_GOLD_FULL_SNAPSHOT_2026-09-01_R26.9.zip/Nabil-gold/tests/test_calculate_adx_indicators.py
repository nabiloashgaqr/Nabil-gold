"""2026-08-19 upgrade tests: canonical utils.indicators.calculate_adx.

The TechnicalAgent._calculate_adx_proxy now delegates to this canonical
implementation. These tests pin:
  1) exact agreement between the two entry points (the agent path and the
     canonical path must return identical numbers),
  2) the Wilder reference (same independent reference the operator pinned on
     2026-08-14).
"""
from __future__ import annotations

import math
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from agents.technical_agent import TechnicalAgent  # noqa: E402
from utils.indicators import calculate_adx, calculate_dmi  # noqa: E402


def _candles(n, trend=0.0, seed=0, base=4000.0):
    rng = random.Random(seed)
    candles = []
    price = base
    for _ in range(n):
        high = price + rng.uniform(1, 3)
        low = price - rng.uniform(1, 3)
        close = price + rng.uniform(-2, 2) + trend
        candles.append({"high": high, "low": low, "close": close})
        price = close
    return candles


def _wilder_reference(cs, period=14):
    plus_dm, minus_dm, trs = [], [], []
    for i in range(1, len(cs)):
        h, l = cs[i]["high"], cs[i]["low"]
        hp, lp, cp = cs[i - 1]["high"], cs[i - 1]["low"], cs[i - 1]["close"]
        up, dn = h - hp, lp - l
        plus_dm.append(up if up > dn and up > 0 else 0.0)
        minus_dm.append(dn if dn > up and dn > 0 else 0.0)
        trs.append(max(h - l, abs(h - cp), abs(l - cp)))
    st, sp, sm = sum(trs[:period]), sum(plus_dm[:period]), sum(minus_dm[:period])
    dxs = []
    for i in range(period, len(trs)):
        st = st - st / period + trs[i]
        sp = sp - sp / period + plus_dm[i]
        sm = sm - sm / period + minus_dm[i]
        pdi, mdi = 100 * sp / max(st, 1e-9), 100 * sm / max(st, 1e-9)
        dxs.append(abs(pdi - mdi) / max(pdi + mdi, 1e-9) * 100)
    adx = sum(dxs[:period]) / period
    for dx in dxs[period:]:
        adx = (adx * (period - 1) + dx) / period
    return adx


class TestCanonicalADX:
    def test_agent_and_canonical_agree_exactly(self):
        agent = TechnicalAgent({"agent_weights": {}})
        cs = _candles(300, trend=0.8, seed=42)
        agent_adx, agent_label = agent._calculate_adx_proxy(cs)
        canon_adx, canon_label = calculate_adx(cs)
        assert abs(agent_adx - canon_adx) < 1e-9
        assert agent_label == canon_label

    def test_matches_wilder_reference(self):
        cs = _candles(300, trend=0.8, seed=42)
        adx, _ = calculate_adx(cs)
        assert abs(adx - _wilder_reference(cs)) < 0.01

    def test_trend_labels(self):
        up = _candles(300, trend=2.0, seed=7)
        down = _candles(300, trend=-2.0, seed=8)
        assert calculate_adx(up)[1] == "BULLISH"
        assert calculate_adx(down)[1] == "BEARISH"

    def test_dmi_sanity(self):
        up = _candles(300, trend=2.0, seed=9)
        dmi = calculate_dmi(up)
        assert dmi["plus_di"] > dmi["minus_di"]
        assert dmi["adx"] > 25
        assert len(dmi["adx_series"]) > 0

    def test_short_series_safe(self):
        adx, label = calculate_adx(_candles(10))
        assert adx == 0.0
        assert label in {"BULLISH", "BEARISH", "NEUTRAL"}
