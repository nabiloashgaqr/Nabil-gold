"""Operator-approved canonical agent policy (2026-08-14).

The original five voting agents are restored: Classical, Technical, SMC,
Price Action and Multi-Timeframe.  Auction Flow is a standalone non-voting
agent that confirms Path 4 (SMC conditional map) and Path 5 (two-agent +
auction) but carries no weight in the classic consensus.
"""
from __future__ import annotations

import json
from pathlib import Path

from agents.decision_agent import DecisionAgent
from services.session_planner import SessionPlannerService

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
CANONICAL = {
    "classical": 0.25,
    "technical": 0.20,
    "smc": 0.20,
    "price_action": 0.20,
    "multitimeframe": 0.15,
}



def _numeric_weights(weights: dict) -> dict:
    return {k: v for k, v in weights.items() if not str(k).startswith("_")}


def test_shipped_config_has_one_weight_source_and_one_agent_bar() -> None:
    assert _numeric_weights(CONFIG["agent_weights"]) == CANONICAL
    assert "auction_flow" not in _numeric_weights(CONFIG["agent_weights"])
    assert CONFIG["strategy_profile_weight_overrides_enabled"] is False
    assert CONFIG["unify_agent_min_confidence"] is True
    assert CONFIG["signal_requirements"]["agent_min_confidence"] == 65  # unified 65 (2026-08-14)
    assert CONFIG["session_planner"]["agent_alignment_min_confidence"] == 65
    assert CONFIG["session_plan_delivery"]["only_when_ready"] is True
    assert CONFIG["all_agents_timeframes"]["required"] == ["5m", "15m", "1H", "4H"]
    assert CONFIG["all_agents_timeframes"]["require_native"] is True
    assert CONFIG["data_source"]["resample_timeframes_from_base"] is False
    for profile in CONFIG["strategy_profiles"].values():
        assert profile["agent_min_confidence"] == 65
        assert "weight_overrides" not in profile


def test_auction_flow_is_standalone_and_path5_is_declared() -> None:
    assert CONFIG["auction_flow"]["voting"] is False
    path5 = CONFIG["signal_requirements"]["path5_two_agent_auction"]
    assert path5["enabled"] is True
    assert path5["min_agents_agree"] == 2
    # Operator 2026-08-14: net-confidence floor 70 (lowered from 72 after the
    # what-if replay); the auction agent's own confirmation floor stays 72.
    assert path5["min_consensus_confidence"] == 65
    assert path5["min_auction_confidence"] == 65


def test_trend_profile_uses_canonical_weights_not_hidden_overrides() -> None:
    agent = DecisionAgent(CONFIG)
    results = {
        "multitimeframe": {"signal": "BUY", "confidence": 92,
                           "setup_type": "TREND_CONTINUATION"},
        "technical": {"signal": "BUY", "confidence": 90},
        "classical": {"signal": "WAIT", "confidence": 30},
        "smc": {"signal": "WAIT", "confidence": 37,
                "setup_structure": {"setup_type": "ORDER_BLOCK_PULLBACK"}},
        "price_action": {"signal": "SELL", "confidence": 70},
    }
    result = agent.analyze(results)
    assert result["strategy_profile"]["name"] == "trend_pullback"
    assert result["strategy_profile"]["weight_policy"] == "canonical_config_only"
    assert _numeric_weights(result["weights"]) == CANONICAL
    buy_votes = {v["agent"]: v for v in result["votes"]["BUY"]}
    assert buy_votes["multitimeframe"]["weight"] == 0.15
    assert buy_votes["technical"]["weight"] == 0.20


def test_auction_flow_never_casts_a_core_vote() -> None:
    agent = DecisionAgent(CONFIG)
    results = {
        "auction_flow": {"signal": "BUY", "confidence": 95},
        "classical": {"signal": "WAIT", "confidence": 30},
    }
    result = agent.analyze(results)
    all_votes = [v["agent"] for side in ("BUY", "SELL", "WAIT") for v in result["votes"][side]]
    assert "auction_flow" not in all_votes


def test_planner_reads_the_same_unified_bar() -> None:
    planner = SessionPlannerService(CONFIG)
    assert planner.agent_alignment_min_confidence == 65


def test_every_map_snapshot_persists_agent_observability() -> None:
    source = (ROOT / "scripts" / "run_analysis.py").read_text(encoding="utf-8")
    assert '"agent_opinions": _session_plan_agent_opinions' in source
    assert '"decision_context": {' in source
    assert '"weights": deepcopy(decision.get("weights") or {})' in source
