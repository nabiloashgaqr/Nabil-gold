"""R25.15 convoy step 2 — stage="management" decision audits.

Mirrors the R25.14 scale-in audit pattern: every management decision the
5-minute engine takes (early/TP1 breakeven, TP1 partial, thesis scale-out,
trailing update) must leave a nameable evidence row — no silent management.
"""
from __future__ import annotations

from datetime import datetime, timezone

from agents.open_trades_manager import OpenTradesManager

NOW = datetime.now(timezone.utc)


class _AuditDB:
    def __init__(self):
        self.rows = []

    def save_decision_audit(self, row):
        self.rows.append(dict(row))


def _mgr():
    cfg = {
        "trade_management": {
            "expire_after_hours": 0, "time_warning_hours": 999,
            "auto_move_sl_to_entry_after_tp1": True,
            "partial_close_at_tp1": True, "partial_close_percentage": 50,
        },
        "trailing_stop": {"enabled": True, "trailing_distance": 100.0,
                          "trailing_step": 30.0, "early_breakeven_points": 100.0,
                          "min_profit_lock": 0.0},
    }
    return OpenTradesManager(cfg)


def _buy_trade():
    return {"id": "T-MGMT", "symbol": "XAU/USD", "type": "BUY", "status": "OPEN",
            "entry_price": 4000.0, "stop_loss": 3980.0, "tp1": 4026.7,
            "tp2": 4047.0, "sl_moved_to_entry": False, "updates_sent": []}


def _stage_rows(db, outcome=None):
    return [r for r in db.rows
            if r.get("stage") == "management"
            and (outcome is None or r.get("outcome") == outcome)]


def test_early_breakeven_leaves_management_audit():
    db = _AuditDB()
    ev = _mgr().evaluate_trade(_buy_trade(), 4010.0, now=NOW,
                               database=db)  # +100 pts
    assert "MOVE_SL_TO_BE" in ev["events"]
    rows = _stage_rows(db, "EARLY_BREAKEVEN")
    assert len(rows) == 1
    row = rows[0]
    assert row["symbol"] == "XAU/USD"
    assert row["trade_id"] == "T-MGMT"
    assert "breakeven" in (row.get("reason") or "").lower()


def test_tp1_partial_leaves_audit_with_remaining_target_tp2():
    db = _AuditDB()
    ev = _mgr().evaluate_trade(_buy_trade(), 4012.0, candle_high=4026.7,
                               now=NOW, database=db)  # TP1 touched
    assert "TP1_HIT" in ev["events"]
    upd = ev["updates"]
    # convoy item 4: the remaining half's target is TP2, stamped on the row
    assert upd.get("remaining_target") == 4047.0
    rows = _stage_rows(db, "TP1_PARTIAL")
    assert len(rows) == 1
    assert "remaining target" in (rows[0].get("reason") or "")


def test_trailing_update_leaves_audit_once():
    db = _AuditDB()
    t = _buy_trade()
    t.update({"sl_moved_to_entry": True, "stop_loss": 4000.0})
    ev = _mgr().evaluate_trade(t, 4015.0, now=NOW, database=db)  # trail -> 4005
    assert "TRAILING_SL_UPDATED" in ev["events"]
    rows = _stage_rows(db, "TRAILING_SL_UPDATED")
    assert len(rows) == 1
    assert "trailed" in (rows[0].get("reason") or "")


def test_no_database_is_silent_noop():
    """Without a database handle the audits degrade to nothing — trading
    decisions themselves are unaffected."""
    ev = _mgr().evaluate_trade(_buy_trade(), 4010.0, now=NOW, database=None)
    assert "MOVE_SL_TO_BE" in ev["events"]
