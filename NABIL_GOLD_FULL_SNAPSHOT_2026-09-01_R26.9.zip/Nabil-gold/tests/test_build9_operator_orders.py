"""2026-08-19 build 9: watch gates OFF, oil-macro confirmation, measurement OFF."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from services.session_planner import SessionPlannerService  # noqa: E402
from services.thesis_consensus import evaluate_directional_admission  # noqa: E402


def _cfg(**over):
    cfg = {
        "agent_weights": {"classical": 0.25, "technical": 0.20, "smc": 0.20,
                          "price_action": 0.20, "multitimeframe": 0.15},
        "risk_settings": {"min_confidence": 65},
        "signal_requirements": {
            "min_agents_agree": 3,
            "min_consensus_confidence": 72,
            "agent_min_confidence": 65,
            "two_agent_entry": {"enabled": True, "min_agents_agree": 2,
                                "min_consensus_confidence": 72,
                                "oil_macro_confirmation": {"enabled": True, "min_confidence": 55}},
            "path5_two_agent_auction": {"enabled": True, "min_agents_agree": 2,
                                        "min_consensus_confidence": 72,
                                        "min_auction_confidence": 65},
        },
    }
    cfg.update(over)
    return cfg


class TestWatchGates:
    def test_defaults_on_without_section(self):
        planner = SessionPlannerService({"session_planner": {}})
        assert planner.require_reversal_proof is True
        assert planner.require_archetype_conviction is True
        assert planner.watch_on_low_quality is True

    def test_production_config_all_off(self):
        cfg_path = Path(__file__).resolve().parents[1] / "config.json"
        prod = json.loads(cfg_path.read_text(encoding="utf-8"))
        planner = SessionPlannerService(prod)
        assert planner.require_reversal_proof is False
        assert planner.require_archetype_conviction is False
        assert planner.watch_on_low_quality is False

    def test_partial_override(self):
        planner = SessionPlannerService({"session_planner": {"watch_gates": {
            "require_reversal_proof": False}}})
        assert planner.require_reversal_proof is False
        assert planner.require_archetype_conviction is True  # untouched
        assert planner.watch_on_low_quality is True


class TestOilMacroConfirmation:
    def _details(self, side="BUY"):
        return {
            "technical": {"direction": side, "confidence": 74},
            "smc": {"direction": side, "confidence": 71},
            "classical": {"direction": "WAIT", "confidence": 20},
            "multitimeframe": {"direction": "WAIT", "confidence": 20},
            "price_action": {"direction": "WAIT", "confidence": 20},
        }

    def test_wti_confirmed_by_oil_macro(self):
        details = self._details("SELL")
        details["oil_macro"] = {"direction": "SELL", "confidence": 58}
        details["symbol"] = "WTI/USD"
        r = evaluate_directional_admission("SELL", details, _cfg())
        assert r.get("allow") is True
        assert r.get("path") == "TWO_AGENT_OIL_MACRO"

    def test_wti_refused_when_oil_macro_neutral(self):
        details = self._details("SELL")
        details["oil_macro"] = {"direction": "WAIT", "confidence": 0}
        details["symbol"] = "WTI/USD"
        r = evaluate_directional_admission("SELL", details, _cfg())
        assert r.get("allow") is False

    def test_wti_does_not_use_gold_macro(self):
        # macro is a GOLD verdict: for WTI it must be ignored even if bullish
        details = self._details("SELL")
        details["macro_fundamental"] = {"direction": "SELL", "confidence": 60}
        details["oil_macro"] = {"direction": "WAIT", "confidence": 0}
        details["symbol"] = "WTI/USD"
        r = evaluate_directional_admission("SELL", details, _cfg())
        assert r.get("allow") is False  # gold macro must NOT confirm oil

    def test_gold_still_uses_macro(self):
        details = self._details("BUY")
        details["macro_fundamental"] = {"direction": "BUY", "confidence": 60}
        details["symbol"] = "XAU/USD"
        r = evaluate_directional_admission("BUY", details, _cfg())
        assert r.get("allow") is True
        assert r.get("path") == "TWO_AGENT_MACRO"

    def test_symbol_param_flows(self):
        details = self._details("SELL")
        details["oil_macro"] = {"direction": "SELL", "confidence": 58}
        r = evaluate_directional_admission("SELL", details, _cfg(), symbol="WTI/USD")
        assert r.get("allow") is True
        assert r.get("path") == "TWO_AGENT_OIL_MACRO"


class TestProductionConfig:
    def test_build9_flags(self):
        cfg_path = Path(__file__).resolve().parents[1] / "config.json"
        prod = json.loads(cfg_path.read_text(encoding="utf-8"))
        # watch gates off
        wg = (prod.get("session_planner") or {}).get("watch_gates") or {}
        assert wg.get("require_reversal_proof") is False
        assert wg.get("require_archetype_conviction") is False
        assert wg.get("watch_on_low_quality") is False
        # oil confirmation on
        oil = ((prod.get("signal_requirements") or {}).get("two_agent_entry") or {}).get(
            "oil_macro_confirmation") or {}
        assert oil.get("enabled") is True
        # measurement RESTARTED by build 10 operator order (gold + oil)
        assert (prod.get("agent_measurement") or {}).get("enabled") is True
        # WTI live again (build 14 operator order)
        wti = [s for s in prod.get("symbols") or [] if s.get("symbol") == "WTI/USD"]
        assert wti and "mode" not in wti[0]
