"""BUILD 30: PRE-ARM OTE core math + gates (no DB/telegram needed)."""
from __future__ import annotations

import pytest

from services import pre_arm_ote as pa


def _candle(o, h, l, c, t="2026-08-20T10:00:00+00:00"):
    return {"time": t, "open": o, "high": h, "low": l, "close": c}


def _flat_then_impulse_up(points=40.0, atr_pts=8.0, n_flat=12):
    """12 flat candles around 4600, then a strong UP leg of `points`."""
    candles = []
    base = 4600.0
    for i in range(n_flat):
        candles.append(_candle(base, base + 1, base - 1, base))
    # impulse: from base up to base+points over 3 candles
    step = points / 3
    for i in range(3):
        o = base + step * i
        c = base + step * (i + 1)
        candles.append(_candle(o, c + 1, o - 1, c))
    # one more flat candle after the peak (forming bar)
    top = base + points
    candles.append(_candle(top, top + 0.5, top - 0.5, top))
    return candles


def test_detect_bullish_impulse_and_ote():
    candles = _flat_then_impulse_up(points=40.0)
    atr = 8.0
    cfg = pa._cfg({})
    leg = pa.detect_impulse_leg(candles, atr, cfg, "BUY")
    assert leg is not None, "a fresh 40pt up-leg must be detected"
    assert leg["direction"] == "BUY"
    # wicks extend the leg by ~1pt each side (synthetic candles)
    assert leg["leg_size"] == pytest.approx(42.0, abs=2.0)
    ote = pa.project_ote(leg, cfg)
    assert ote["direction"] == "BUY"
    # BUILD 31 R6: the entry is the 70% RETRACEMENT measured from the PEAK
    # (the original code measured it from the origin = the 30% fib).
    # peak - size*0.70 == origin + size*0.30
    expected_entry = leg["leg_peak"] - leg["leg_size"] * 0.70
    assert ote["entry"] == pytest.approx(expected_entry, abs=0.01)
    assert ote["zone_low"] < ote["entry"] < ote["zone_high"]
    # the OTE zone itself is a retracement zone: [peak-0.79*size, peak-0.62*size]
    assert ote["zone_low"] == pytest.approx(
        leg["leg_peak"] - leg["leg_size"] * 0.79, abs=0.01)
    assert ote["zone_high"] == pytest.approx(
        leg["leg_peak"] - leg["leg_size"] * 0.62, abs=0.01)
    assert ote["stop"] < leg["leg_origin"]  # stop below the leg origin
    assert ote["target"] == leg["leg_peak"]  # first objective = leg peak


def test_no_impulse_when_flat():
    candles = [_candle(4600, 4601, 4599, 4600) for _ in range(20)]
    cfg = pa._cfg({})
    assert pa.detect_impulse_leg(candles, 8.0, cfg, "BUY") is None
    assert pa.detect_impulse_leg(candles, 8.0, cfg, "SELL") is None


def test_impulse_too_small_is_rejected():
    # 40pt leg but ATR huge -> displacement < 1.2*ATR
    candles = _flat_then_impulse_up(points=40.0)
    cfg = pa._cfg({})
    assert pa.detect_impulse_leg(candles, 40.0, cfg, "BUY") is None  # 40 < 1.2*40


def test_stale_peak_not_recent():
    """A leg whose top is 13 bars old (price since pulled back and flat
    far below the peak) is NOT a fresh impulse."""
    candles = _flat_then_impulse_up(points=40.0)
    for i in range(16):
        # consolidation ~30pts below the peak (pushes the leg out of the
        # 15-bar lookback window)
        candles.append(_candle(4610, 4611, 4609, 4610))
    cfg = pa._cfg({})
    assert pa.detect_impulse_leg(candles, 8.0, cfg, "BUY") is None


def test_sell_impulse_mirror():
    candles = []
    base = 4600.0
    for i in range(12):
        candles.append(_candle(base, base + 1, base - 1, base))
    step = -40.0 / 3
    for i in range(3):
        o = base + step * i
        c = base + step * (i + 1)
        candles.append(_candle(o, o + 1, c - 1, c))
    bottom = base - 40.0
    candles.append(_candle(bottom, bottom + 0.5, bottom - 0.5, bottom))
    cfg = pa._cfg({})
    leg = pa.detect_impulse_leg(candles, 8.0, cfg, "SELL")
    assert leg is not None
    assert leg["direction"] == "SELL"
    ote = pa.project_ote(leg, cfg)
    assert ote["entry"] > leg["leg_origin"] - leg["leg_size"]  # entry below origin
    assert ote["stop"] > leg["leg_origin"]  # stop above the leg origin
    assert ote["target"] == leg["leg_peak"]


# ── full armer (fake database/telegram) ────────────────────────────────────
class _DB:
    def __init__(self):
        self.saved = []

    def new_trade_id(self):
        return "TRADE_PREARM_TEST"

    def save_trade(self, decision):
        self.saved.append(decision)
        return decision["trade_id"]


class _TG:
    def __init__(self):
        self.signals = []

    def send_signal(self, decision):
        self.signals.append(decision)
        return True


def _data(candles, current_price):
    return {"timeframes": {"15m": {"data": candles}},
            "current_price": current_price}


def _classic_book(direction="BUY", n_support=3, n_oppose=0, net=68.0):
    """THIS cycle's finished classic book — the same structure the
    two-agent paths read (consensus[side] metrics). n_support / n_oppose
    are the QUALIFIED voters; edge = weighted support - weighted
    opposition (the 'خصم المعارضين' math); net = net weighted confidence.
    smc always supports (it also carries the trend the hard gate needs)."""
    assert n_support >= 1, "smc must carry the trend + a qualified vote"
    agents = ["technical", "multitimeframe", "classical", "smc",
              "price_action", "auction_flow"]
    opposite = "SELL" if direction == "BUY" else "BUY"
    trend = "BULLISH" if direction == "BUY" else "BEARISH"
    supporters, opponents = ["smc"], []
    budget = n_support - 1
    for name in (a for a in agents if a != "smc"):
        if budget > 0:
            supporters.append(name)
            budget -= 1
        elif n_oppose > 0:
            opponents.append(name)
            n_oppose -= 1
    edge = 0.5 * (len(supporters) - len(opponents))
    return {"consensus": {
        direction: {"supporters": supporters, "opponents": opponents,
                    "support_count": len(supporters),
                    "opposition_count": len(opponents),
                    "edge": edge, "confidence": net},
        opposite: {"supporters": opponents, "opponents": supporters,
                   "support_count": len(opponents),
                   "opposition_count": len(supporters),
                   "edge": -edge, "confidence": 40.0},
    }}


def _macro_ok(direction="BUY", conf=58.0):
    """The gold macro confirming (XAU path of the two-agent chain)."""
    return {"macro_fundamental": {"macro_direction": {
        "bias": "BULLISH_GOLD" if direction == "BUY" else "BEARISH_GOLD",
        "confidence": conf}}}


def test_try_pre_arm_arms_buy_pending():
    candles = _flat_then_impulse_up(points=40.0)
    peak = max(c["high"] for c in candles)
    # price has started to pull back a little below the peak
    cp = peak - 5.0
    db, tg = _DB(), _TG()
    # PATH 6 (BUILD 31 R3): the two-agent book (3-1, net 68, edge > 0)
    # + macro confirmation (58% >= 55%) + risk approved.
    all_results = {"smc": {"trend": "BULLISH"}, "risk": {"approved": True},
                   **_macro_ok("BUY", 58.0)}
    side = pa.try_pre_arm(
        data=_data(candles, cp),
        all_results=all_results,
        config={}, symbol="XAU/USD",
        open_trades_snapshot=[], database=db, telegram=tg,
        current_price=cp,
        classic_book=_classic_book("BUY", n_support=3, n_oppose=1, net=68.0))
    assert side == "BUY"
    assert len(db.saved) == 1
    d = db.saved[0]
    assert d["armed_at"] == "pre_arm_ote"
    assert d["execution_path_id"] == "PATH_6_TWO_AGENT_OTE"
    assert d["entry_mode"] == "two_agent_ote"
    assert d["confirm_source"] == "macro"
    assert d["confirm_confidence"] == 58.0
    # the book + confirmation travel with the trade
    vote = d["vote_at_arm"]
    assert sorted(vote["supporters"]) == ["multitimeframe", "smc", "technical"]
    assert vote["opponents"] == ["classical"]
    assert vote["edge"] > 0 and vote["net_confidence"] == 68.0
    assert vote["min_supporters"] == 2
    assert d["decision"] == "BUY"
    assert d["signal"]["entry_kind"] == "LIMIT"
    entry = d["signal"]["entry"]["price"]
    assert entry < cp  # waiting for the pullback
    assert d["signal"]["stop_loss"] < entry
    assert d["signal"]["tp2"] > entry
    # thin reclaim (short leg vs ATR) -> objective extended to min RR
    risk = entry - d["signal"]["stop_loss"]
    assert (d["signal"]["tp2"] - entry) / risk >= 1.49


def test_try_pre_arm_blocked_by_existing_open_trade():
    candles = _flat_then_impulse_up(points=40.0)
    cp = max(c["high"] for c in candles) - 5.0
    db, tg = _DB(), _TG()
    side = pa.try_pre_arm(
        data=_data(candles, cp),
        all_results={"smc": {"trend": "BULLISH"}},
        config={}, symbol="XAU/USD",
        open_trades_snapshot=[{"symbol": "XAU/USD", "status": "OPEN"}],
        database=db, telegram=tg, current_price=cp)
    assert side is None
    assert db.saved == []


def test_try_pre_arm_blocked_by_neutral_trend():
    candles = _flat_then_impulse_up(points=40.0)
    cp = max(c["high"] for c in candles) - 5.0
    db, tg = _DB(), _TG()
    side = pa.try_pre_arm(
        data=_data(candles, cp),
        all_results={"smc": {"trend": "NEUTRAL"}},
        config={}, symbol="XAU/USD",
        open_trades_snapshot=[], database=db, telegram=tg, current_price=cp)
    assert side is None
    assert db.saved == []


def test_try_pre_arm_blocked_by_news():
    candles = _flat_then_impulse_up(points=40.0)
    cp = max(c["high"] for c in candles) - 5.0
    db, tg = _DB(), _TG()
    side = pa.try_pre_arm(
        data=_data(candles, cp),
        all_results={"smc": {"trend": "BULLISH"},
                     "news": {"can_trade": False}},
        config={}, symbol="XAU/USD",
        open_trades_snapshot=[], database=db, telegram=tg, current_price=cp)
    assert side is None


def test_try_pre_arm_consumed_when_price_already_below_ote():
    candles = _flat_then_impulse_up(points=40.0)
    trough = min(c["low"] for c in candles)
    ote_entry = trough + 40.0 * 0.70
    cp = ote_entry - 10.0  # pullback already ran through the OTE
    db, tg = _DB(), _TG()
    side = pa.try_pre_arm(
        data=_data(candles, cp),
        all_results={"smc": {"trend": "BULLISH"}},
        config={}, symbol="XAU/USD",
        open_trades_snapshot=[], database=db, telegram=tg, current_price=cp)
    assert side is None
    assert db.saved == []


def test_try_pre_arm_disabled_kills_the_feature():
    candles = _flat_then_impulse_up(points=40.0)
    cp = max(c["high"] for c in candles) - 5.0
    db, tg = _DB(), _TG()
    side = pa.try_pre_arm(
        data=_data(candles, cp),
        all_results={"smc": {"trend": "BULLISH"}},
        config={"pre_arm_ote": {"enabled": False}}, symbol="XAU/USD",
        open_trades_snapshot=[], database=db, telegram=tg, current_price=cp)
    assert side is None
    assert db.saved == []


def test_try_pre_arm_never_raises_on_garbage():
    db, tg = _DB(), _TG()
    assert pa.try_pre_arm(data=None, all_results=None, config=None,
                          symbol="XAU/USD", open_trades_snapshot=None,
                          database=db, telegram=tg, current_price=None) is None
    assert pa.try_pre_arm(data={}, all_results={}, config={}, symbol="X",
                          open_trades_snapshot=None, database=db, telegram=tg,
                          current_price=1.0) is None
    assert db.saved == []


# ── BUILD 31 R3: PATH 6 — the two-agent mechanism (operator 2026-08-24:
#    "المسار 6 المؤكد ل 2 وكلاء ... بنفس الالية" ) ───────────

def _cp(candles):
    return max(c["high"] for c in candles) - 5.0


def _arm_call(cp, classic_book=None, all_results=None, config=None,
              symbol="XAU/USD", db=None, tg=None):
    db = db or _DB()
    tg = tg or _TG()
    candles = _flat_then_impulse_up(points=40.0)
    side = pa.try_pre_arm(
        data=_data(candles, cp), all_results=all_results or {},
        config=config or {}, symbol=symbol, open_trades_snapshot=[],
        database=db, telegram=tg, current_price=cp,
        classic_book=classic_book)
    return side, db


def test_prearm_thin_book_does_not_arm():
    """1 qualified supporter < 2 -> no arm, even with macro confirmation."""
    cp = _cp(_flat_then_impulse_up(points=40.0))
    side, db = _arm_call(
        cp, classic_book=_classic_book("BUY", n_support=1),
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": True},
                     **_macro_ok("BUY", 58.0)})
    assert side is None
    assert db.saved == []


def test_prearm_opponents_deducted_edge_zero_veto():
    """2 supporters but 2 qualified opponents: edge = support - opposition
    = 0 -> the 'خصم المعارضين' math vetoes, no arm."""
    cp = _cp(_flat_then_impulse_up(points=40.0))
    side, db = _arm_call(
        cp, classic_book=_classic_book("BUY", n_support=2, n_oppose=2),
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": True},
                     **_macro_ok("BUY", 58.0)})
    assert side is None
    assert db.saved == []


def test_prearm_low_net_confidence_does_not_arm():
    """2 supporters, but net weighted confidence 50% < 65 -> no arm."""
    cp = _cp(_flat_then_impulse_up(points=40.0))
    side, db = _arm_call(
        cp, classic_book=_classic_book("BUY", n_support=2, net=50.0),
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": True},
                     **_macro_ok("BUY", 58.0)})
    assert side is None
    assert db.saved == []


def test_prearm_no_confirmation_does_not_arm(monkeypatch):
    """Good book, but macro silent and gemini disagrees -> no arm
    (fail closed: no confirmation = no entry)."""
    monkeypatch.setattr(pa, "_gemini_confirms",
                        lambda *a, **k: (False, None, 0.0))
    cp = _cp(_flat_then_impulse_up(points=40.0))
    side, db = _arm_call(
        cp, classic_book=_classic_book("BUY", n_support=3),
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": True}})
    assert side is None
    assert db.saved == []


def test_prearm_gemini_confirmation_arms(monkeypatch):
    """Macro silent, gemini confirms at 72% >= 70% -> armed, stamped
    confirm_source=gemini (the path-3 branch of the same chain)."""
    monkeypatch.setattr(pa, "_gemini_confirms",
                        lambda *a, **k: (True, "gemini", 72.0))
    cp = _cp(_flat_then_impulse_up(points=40.0))
    side, db = _arm_call(
        cp, classic_book=_classic_book("BUY", n_support=3, n_oppose=1),
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": True}})
    assert side == "BUY"
    d = db.saved[0]
    assert d["confirm_source"] == "gemini"
    assert d["confirm_confidence"] == 72.0
    assert d["vote_at_arm"]["confirm_source"] == "gemini"


def test_prearm_risk_refused_does_not_arm():
    """The risk agent's verdict is not advisory (as on paths 2/3):
    approved=False kills every confirmation."""
    cp = _cp(_flat_then_impulse_up(points=40.0))
    side, db = _arm_call(
        cp, classic_book=_classic_book("BUY", n_support=3),
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": False},
                     **_macro_ok("BUY", 58.0)})
    assert side is None
    assert db.saved == []


def test_prearm_oil_macro_confirms_wti():
    """WTI branch of the chain: the OIL macro (EIA/OPEC/spread) at 58%
    confirms; the gold macro must never confirm an oil entry."""
    cp = _cp(_flat_then_impulse_up(points=40.0))
    side, db = _arm_call(
        cp, classic_book=_classic_book("BUY", n_support=2),
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": True},
                     "oil_macro": {"direction": "BULLISH",
                                   "confidence": 58.0}},
        symbol="WTI/USD")
    assert side == "BUY"
    assert db.saved[0]["confirm_source"] == "oil_macro"
    # and the gold macro alone must NOT confirm WTI
    cp2 = _cp(_flat_then_impulse_up(points=40.0))
    side2, db2 = _arm_call(
        cp2, classic_book=_classic_book("BUY", n_support=2),
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": True},
                     **_macro_ok("BUY", 58.0)},
        symbol="WTI/USD")
    assert side2 is None
    assert db2.saved == []


def test_prearm_vote_gate_disable_keeps_legacy_behaviour():
    """Kill switch: vote_gate.enabled=false -> arms on its own signal
    again (the pre-gate behaviour), for rollback experiments only."""
    cp = _cp(_flat_then_impulse_up(points=40.0))
    side, db = _arm_call(
        cp,
        all_results={"smc": {"trend": "BULLISH"}},
        config={"pre_arm_ote": {"vote_gate": {"enabled": False}}})
    assert side == "BUY"
    assert db.saved[0]["vote_at_arm"]["supporters"] == []
    assert db.saved[0]["confirm_source"] is None


def test_prearm_fails_closed_without_a_readable_book():
    """A trend but no finished book (unreadable) -> NO arm. The
    operator's 'no solo entry' is enforced by failing CLOSED."""
    cp = _cp(_flat_then_impulse_up(points=40.0))
    side, db = _arm_call(
        cp,
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": True},
                     **_macro_ok("BUY", 58.0)})
    assert side is None
    assert db.saved == []


def test_prearm_vote_thresholds_come_from_config():
    """min_supporters=1 in config loosens the book bar to 1."""
    cp = _cp(_flat_then_impulse_up(points=40.0))
    side, db = _arm_call(
        cp, classic_book=_classic_book("BUY", n_support=1),
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": True},
                     **_macro_ok("BUY", 58.0)},
        config={"pre_arm_ote": {"vote_gate": {"min_supporters": 1}}})
    assert side == "BUY"
    assert db.saved[0]["vote_at_arm"]["min_supporters"] == 1


def test_prearm_vote_rejection_is_audited_jsonl(tmp_path, monkeypatch):
    """Measurability: a confirmation-less arm is counted (weekly review
    reads pre_arm_vote_rejections.jsonl)."""
    import json as _json

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(pa, "_gemini_confirms",
                        lambda *a, **k: (False, None, 0.0))
    cp = _cp(_flat_then_impulse_up(points=40.0))
    side, db = _arm_call(
        cp, classic_book=_classic_book("BUY", n_support=3),
        all_results={"smc": {"trend": "BULLISH"}, "risk": {"approved": True}})
    assert side is None
    events = (tmp_path / "pre_arm_vote_rejections.jsonl").read_text(
        encoding="utf-8").strip().splitlines()
    assert len(events) == 1
    ev = _json.loads(events[0])
    assert ev["reason"] == "no_confirmation"
    assert ev["direction"] == "BUY" and ev["symbol"] == "XAU/USD"
    assert len(ev["supporters"]) == 3


# ── zone-consumed cancellation (open_trades_manager) ───────────────────────

def _prearm_pending_trade(direction="BUY", entry=4628.4, zone=(4625.04, 4632.18),
                          stop=4591.0, tp2=4684.5):
    return {
        "id": "TRADE_PREARM_001",
        "type": direction,
        "symbol": "XAU/USD",
        "status": "PENDING",
        "entry_price": entry,
        "stop_loss": stop,
        "tp1": (entry + tp2) / 2,
        "tp2": tp2,
        "order_kind": "LIMIT",
        "order_type": "BUY_LIMIT" if direction == "BUY" else "SELL_LIMIT",
        "created_at": "2026-08-22T10:00:00+00:00",
        "entry_time": "2026-08-22T10:00:00+00:00",
        "updates_sent": [],
        "pending_cycles": 0,
        "signal_snapshot": {
            "armed_at": "pre_arm_ote",
            "decision": direction,
            "symbol": "XAU/USD",
            "signal": {"entry": {"price": entry, "low": zone[0], "high": zone[1],
                                 "kind": "LIMIT"}},
        },
    }


def _pending_mgr():
    from agents.open_trades_manager import OpenTradesManager
    return OpenTradesManager({
        "order_execution": {"entry_style": "hybrid",
                            "pending_expire_after_hours": 24,
                            "pending_order_max_cycles": 99},
    })


def test_prearm_zone_run_through_is_consumed():
    """Price ran through the WHOLE OTE zone on an unreliable touch source
    (a clean activation is impossible) -> cancelled as consumed, never
    chased."""
    mgr = _pending_mgr()
    trade = _prearm_pending_trade("BUY")
    result = mgr.evaluate_trade(
        trade, 4620.0, candle_high=4633.0, candle_low=4620.0,
        market_data_source="quote")
    assert result["new_status"] == "CANCELLED"
    assert result["cancel_reason_code"] == "OTE_ZONE_CONSUMED"
    assert "zone consumed" in str(result["updates"].get("reasons"))


def test_prearm_price_inside_zone_is_not_consumed():
    """Price within the zone (above the far edge) keeps the pending alive -
    the OTE premise is still live."""
    mgr = _pending_mgr()
    trade = _prearm_pending_trade("BUY")
    result = mgr.evaluate_trade(
        trade, 4627.0, candle_high=4633.0, candle_low=4626.5,
        market_data_source="quote")
    assert result.get("cancel_reason_code") != "OTE_ZONE_CONSUMED"


def test_reactive_pending_ignores_ote_rule():
    """A historical (reactive) pending has no armed_at -> the OTE rule must
    never touch it."""
    mgr = _pending_mgr()
    trade = _prearm_pending_trade("BUY")
    trade["signal_snapshot"] = {
        "decision": "BUY", "symbol": "XAU/USD",
        "signal": {"entry": {"price": 4628.4, "low": 4625.04,
                             "high": 4632.18, "kind": "LIMIT"}},
    }
    result = mgr.evaluate_trade(
        trade, 4620.0, candle_high=4633.0, candle_low=4620.0,
        market_data_source="quote")
    assert result.get("cancel_reason_code") != "OTE_ZONE_CONSUMED"


# ── persistence, path label, metrics ───────────────────────────────────────

def test_save_trade_persists_armed_at(tmp_path):
    from services.database import DatabaseService
    db = DatabaseService({"database": {"url": None, "key": None,
                                       "local_fallback_file":
                                       str(tmp_path / "trades.json")}})
    decision = {
        "symbol": "XAU/USD", "decision": "BUY", "confidence": 70,
        "current_price": 4636.0,
        "armed_at": "pre_arm_ote",
        "execution_path_id": "PATH_6_TWO_AGENT_OTE",
        "signal": {"symbol": "XAU/USD", "type": "BUY",
                   "entry_kind": "LIMIT", "order_type": "BUY_LIMIT",
                   "entry": {"price": 4628.4, "low": 4625.04,
                             "high": 4632.18, "kind": "LIMIT"},
                   "stop_loss": 4591.0, "tp1": 4656.0, "tp2": 4684.5},
    }
    db.save_trade(decision)
    row = db.get_open_trades()[0]
    assert row["armed_at"] == "pre_arm_ote"
    assert row["status"] == "PENDING"


def test_legacy_path0_label_resolves_to_path6_not_hidden():
    """BUILD 31 R4 (operator order): path 0 was deleted from the registry
    (6 paths remain). Legacy rows stamped with the old label must resolve
    to PATH 6 — a pre-armed order is never degraded to NOT RECORDED."""
    from services.execution_paths import (PATH_DEFINITIONS, PATH_6,
                                          resolve_execution_path)
    assert "PATH_PREARM_OTE" not in PATH_DEFINITIONS
    # R25.1 (operator 2026-08-28): PATH 7 - SCALP PREMIUM FADE joins the
    # registry, so the count is now seven. Paths 1-6 and the path-0 removal
    # law are unchanged.
    # R25.6: PATH 8 (REINFORCEMENT ADD-ON) and PATH 9 join. R25.8 (2026-08-29):
    # PATH 9 is reborn as LIQUIDITY SWEEP REVERSAL and the retired FX-4 lane
    # survives as a separate LEGACY history bucket - the registry holds ten
    # definitions (nine active paths + one legacy bucket).
    assert len(PATH_DEFINITIONS) == 10
    legacy = resolve_execution_path({"execution_path_id": "PATH_PREARM_OTE"})
    assert legacy["id"] == PATH_6
    new = resolve_execution_path(
        {"id": "T", "armed_at": "pre_arm_ote", "signal_snapshot": {}})
    assert new["id"] == PATH_6


def test_metrics_report_prearm_vs_reactive(tmp_path):
    from services import execution_metrics as em
    from datetime import datetime, timezone

    def _row(status, pnl, armed_at, closed_at):
        return {"status": status, "result": None,
                "final_pnl_points": pnl, "final_pnl": pnl * 0.1,
                "armed_at": armed_at, "closed_at": closed_at}

    db = type("DB", (), {
        "get_recent_decision_audits": lambda self, **k: [
            {"outcome": "SENT", "stage": "execution_queued"}],
        "get_recent_trades": lambda self, **k: [
            _row("TP2_HIT", 220.0, "pre_arm_ote",
                 "2026-08-21T12:00:00+00:00"),
            _row("SL_HIT", -80.0, "pre_arm_ote",
                 "2026-08-21T15:00:00+00:00"),
            _row("TP2_HIT", 150.0, None,
                 "2026-08-21T16:00:00+00:00"),
        ],
    })()
    m = em.build_execution_metrics(db, since="2026-08-14T00:00:00+00:00")
    assert m["pre_arm"]["closed"] == 2
    assert m["pre_arm"]["win"] == 1 and m["pre_arm"]["loss"] == 1
    assert m["pre_arm"]["net_pts"] == 140.0
    assert m["reactive"]["closed"] == 1
    lines = em.format_execution_metrics(m)
    assert any("Pre-arm OTE: 2 closed" in l for l in lines)
