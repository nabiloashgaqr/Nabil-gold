"""BUILD 16 (2026-08-20): Telegram polish - hourly status dedup, daily date
fix, dashboard demo-only + today section, weekly by-path section, tick-manager
rich card mapping, new schedules in config."""
from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

import scripts.run_analysis as ra
import scripts.run_daily_report as rdr
import scripts.run_tick_manager as rtm
from services.dashboard import format_dashboard_telegram
from services.weekly_report import WeeklyStats, WeeklyReportService


# ── 1) hourly status dedup ────────────────────────────────────────────────
class _Tg:
    def __init__(self):
        self.messages = []

    def send_message(self, body, urgent=False):
        self.messages.append(body)
        return True


def _dedup_state_path() -> Path:
    return Path(ra.__file__).resolve().parents[1] / "storage" / "hourly_status_last.json"


def test_hourly_status_dedup_allows_one_per_hour(monkeypatch, tmp_path):
    state = tmp_path / "hourly_status_last.json"
    monkeypatch.setattr("scripts.run_analysis._hourly_status_state_path", lambda: state)
    cfg = {"notifications": {"hourly_status_dedup": True}}
    tg = _Tg()
    assert ra._send_hourly_status_once(tg, cfg, "body-1") is True
    assert ra._send_hourly_status_once(tg, cfg, "body-2") is False
    assert len(tg.messages) == 1
    # a previous hour claims again
    state.write_text(json.dumps({"hour": "2000-01-01T00", "sent_at": "x"}), encoding="utf-8")
    assert ra._send_hourly_status_once(tg, cfg, "body-3") is True
    assert len(tg.messages) == 2


def test_hourly_status_dedup_off_sends_always(monkeypatch, tmp_path):
    state = tmp_path / "hourly_status_last.json"
    monkeypatch.setattr("scripts.run_analysis._hourly_status_state_path", lambda: state)
    cfg = {"notifications": {"hourly_status_dedup": False}}
    tg = _Tg()
    assert ra._send_hourly_status_once(tg, cfg, "a") is True
    assert ra._send_hourly_status_once(tg, cfg, "b") is True
    assert len(tg.messages) == 2


def test_status_message_has_time_book_and_gates(monkeypatch, tmp_path):
    state = tmp_path / "hourly_status_last.json"
    monkeypatch.setattr("scripts.run_analysis._hourly_status_state_path", lambda: state)

    class FakeDB:
        def get_open_trades(self):
            return []

    cfg = {"symbol": "XAU/USD", "notifications": {"hourly_status_dedup": True}}
    decision = {"symbol": "XAU/USD", "decision": "WAIT", "current_price": 4452.84}
    all_results = {
        "technical": {"signal": "BUY", "confidence": 32.0},
        "multitimeframe": {"signal": "WAIT", "confidence": 48.0},
        "classical": {"signal": "WAIT", "confidence": 0.0},
        "smc": {"signal": "WAIT", "confidence": 0.0},
        "price_action": {"signal": "WAIT", "confidence": 0.0},
        "auction_flow": {"signal": "WAIT", "confidence": 50.0},
    }
    body = ra._build_market_status_message(decision, all_results, FakeDB(), cfg)
    assert "UTC" in body
    assert "Book:" in body and "tech B32" in body
    assert "Decision: WAIT" in body


# ── 2) daily report date before 04:00 rolls back ──────────────────────────
class _FakeDatetime(datetime):
    _fixed = datetime(2026, 8, 20, 2, 30, tzinfo=timezone.utc)

    @classmethod
    def now(cls, tz=None):
        return cls._fixed


def test_daily_report_date_rolls_back_before_4am(monkeypatch):
    monkeypatch.setattr("scripts.run_daily_report.datetime", _FakeDatetime)
    assert rdr._resolve_report_date(None, "Asia/Hebron") == "2026-08-19"


class _FakeDatetimeEvening(datetime):
    _fixed = datetime(2026, 8, 19, 20, 50, tzinfo=timezone.utc)

    @classmethod
    def now(cls, tz=None):
        return cls._fixed


def test_daily_report_date_stays_at_2350(monkeypatch):
    monkeypatch.setattr("scripts.run_daily_report.datetime", _FakeDatetimeEvening)
    # 20:50 UTC = 23:50 Hebron -> today, not yesterday
    assert rdr._resolve_report_date(None, "Asia/Hebron") == "2026-08-19"


def test_daily_report_date_explicit_value_kept(monkeypatch):
    monkeypatch.setattr("scripts.run_daily_report.datetime", _FakeDatetime)
    assert rdr._resolve_report_date("2026-08-15", "Asia/Hebron") == "2026-08-15"
    assert rdr._resolve_report_date("yesterday", "Asia/Hebron") == "2026-08-19"


# ── 3) dashboard: today section + backward compatibility ──────────────────
def _summary(**kw):
    base = {"total": 10, "open": 1, "pending": 0, "wins": 6, "losses": 3,
            "breakeven": 1, "win_rate": 66.7, "net_points": 120.0,
            "profit_factor": 3.4, "open_floating_points": 18.0,
            "buy_count": 6, "buy_net": 80.0, "sell_count": 4, "sell_net": 40.0,
            "avg_confidence": 71.0}
    base.update(kw)
    return base


def test_dashboard_card_today_section_when_passed():
    text = format_dashboard_telegram(_summary(), today_summary=_summary(
        total=3, open=0, pending=0, wins=2, losses=0, breakeven=1,
        net_points=40.0, win_rate=100.0))
    assert "Today (Hebron)" in text
    assert "2W / 0L / 1BE" in text
    assert "Net +40 pts" in text


def test_dashboard_card_without_today_stays_legacy():
    text = format_dashboard_telegram(_summary())
    assert "Today (Hebron)" not in text
    assert "Closed: 10" in text


# ── 4) weekly by-path section ─────────────────────────────────────────────
def test_weekly_path_lines_best_worst():
    stats = WeeklyStats()
    stats.path_stats = {"2": {"count": 9, "net": 248.0},
                        "4": {"count": 6, "net": 120.0},
                        "1": {"count": 4, "net": -40.0}}
    lines = WeeklyReportService._weekly_path_lines(stats)
    text = "\n".join(lines)
    assert "PATH 2: 9 trades · +248 pts (best)" in text
    assert "PATH 1: 4 trades · -40 pts (worst)" in text


def test_weekly_path_lines_empty():
    stats = WeeklyStats()
    assert WeeklyReportService._weekly_path_lines(stats) == ["  No path data this week"]


def test_weekly_report_message_contains_path_section():
    stats = WeeklyStats(week_start="2026-08-14", week_end="2026-08-20",
                        total_trades=5, closed_trades=5, wins=3, losses=1,
                        break_even=1, win_rate=75.0, net_pnl_points=120.0)
    stats.path_stats = {"2": {"count": 4, "net": 140.0}, "1": {"count": 1, "net": -20.0}}
    service = WeeklyReportService(config={"weekly_report": {}}, database=None)
    msg = service._fallback_message(stats)
    assert "BY EXECUTION PATH" in msg
    assert "PATH 2: 4 trades" in msg


# ── 5) tick manager rich card mapping ─────────────────────────────────────
def test_tick_rich_card_trailing():
    row = {"status": "OPEN", "stop_loss": 4462.84, "entry_price": 4452.84, "pnl_points": 85.0}
    payload = rtm.TickManager._rich_card_payload(
        "🧪 DEMO: trailing stop moved to 4462.84 (confirmed at broker)", row)
    assert payload is not None
    event, updates, new_status, pnl = payload
    assert event == "TRAILING_SL_UPDATED"
    assert updates["stop_loss"] == 4462.84


def test_tick_rich_card_breakeven():
    row = {"status": "OPEN", "entry_price": 4452.84, "pnl_points": 0.0}
    event, updates, _, _ = rtm.TickManager._rich_card_payload(
        "🧪 DEMO: breakeven armed @ 4452.84 (confirmed at broker)", row)
    assert event == "MOVE_SL_TO_BE"
    assert updates["sl_moved_to_entry"] is True


def test_tick_rich_card_protected_close():
    row = {"status": "OPEN", "stop_loss": 4462.84, "entry_price": 4452.84,
           "pnl_points": 100.0, "sl_moved_to_entry": True}
    event, updates, new_status, pnl = rtm.TickManager._rich_card_payload(
        "🧪 DEMO: MT5 applied: position closed @ 4462.84 (SL_HIT) · vol 0.1 · ticket 1 +100 pts / +10.00$",
        row)
    assert event == "TRAILING_SL_HIT"
    assert updates["close_price"] == 4462.84


def test_tick_rich_card_plain_loss_close():
    row = {"status": "OPEN", "stop_loss": 4437.84, "entry_price": 4452.84,
           "pnl_points": -150.0, "sl_moved_to_entry": False}
    event, updates, _, _ = rtm.TickManager._rich_card_payload(
        "🧪 DEMO: MT5 applied: position closed @ 4437.84 (SL_HIT) · vol 0.1 · ticket 1 -150 pts",
        row)
    assert event == "SL_HIT"


def test_tick_rich_card_stale_pending_cancel():
    row = {"status": "PENDING", "cancel_reason_code": "TICK_STALE_RUNAWAY"}
    event, updates, new_status, _ = rtm.TickManager._rich_card_payload(
        "🧪 DEMO: MT5 applied: stale pending cancelled (age/excursion) — never placed", row)
    assert event == "PENDING_CANCELLED"
    assert new_status == "CANCELLED"


def test_tick_rich_card_informational_stays_plain():
    row = {"status": "OPEN"}
    payload = rtm.TickManager._rich_card_payload(
        "🧪 DEMO: MT5 applied: execution stop corrected from 4400.00 (550.0 pts) to 4410.00 (400.0 pts; liquidity law)",
        row)
    assert payload is None


