"""R25.7-C (2026-08-28) — the FX-4 macro works, so the dedicated forex
strong-structure lane was retired. R25.8 (2026-08-29) — PATH 9 is reborn as
the LIQUIDITY SWEEP RAID REVERSAL, and the retired FX-4 lane is demoted to a
LEGACY history bucket.

The check: the FX-4 macro is a first-class confirmer (macro_confirmation
carries all four; the macro agent resolves per symbol), the base paths are
symbol-agnostic, and PATH 9 now admits the institutional sweep raid reversal
for every instrument. The old STRONG_STRUCTURE_CONFIRMED admission maps only
to the legacy bucket — never to the active PATH 9.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from services.execution_paths import (
    PATH_1, PATH_2, PATH_3, PATH_4, PATH_5, PATH_6, PATH_7, PATH_9,
    LEGACY_STRONG_STRUCTURE, PATH_DEFINITIONS, path_id_from_admission,
    resolve_execution_path, stamp_execution_path,
)
from services.symbol_law import macro_symbols
from services.thesis_consensus import evaluate_strong_structure

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))

FX4 = ("EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY")
SEVEN = (PATH_1, PATH_2, PATH_3, PATH_4, PATH_5, PATH_6, PATH_7)


def test_fx4_macro_is_a_first_class_confirmer():
    macro = ((CONFIG.get("signal_requirements") or {})
             .get("two_agent_entry") or {}).get("macro_confirmation") or {}
    assert macro.get("enabled") is True
    symbols = {str(s) for s in (macro.get("symbols") or [])}
    assert set(FX4) <= symbols
    assert macro_symbols(CONFIG) and set(FX4) <= set(macro_symbols(CONFIG))
    assert float(macro.get("min_confidence", 0)) == 55.0


def test_macro_agent_resolves_each_fx_pair():
    """The macro agent is symbol-aware: it must answer for each of the four."""
    from agents.macro_fundamental_agent import MacroFundamentalAgent

    for symbol in FX4:
        agent = MacroFundamentalAgent({"symbol": symbol})
        out = agent.analyze({})
        assert out["symbol"] == symbol
        assert out["signal"] in {"BUY", "SELL", "WAIT"}
        assert "macro_direction" in out


def test_seven_base_paths_are_registered():
    assert len(SEVEN) == 7
    for path_id in SEVEN:
        assert path_id in PATH_DEFINITIONS


def test_path9_is_the_sweep_reversal_for_every_instrument():
    assert PATH_9 == "PATH_9_LIQUIDITY_SWEEP_REVERSAL"
    d = PATH_DEFINITIONS[PATH_9]
    assert d["admission_path"] == "LIQUIDITY_SWEEP_REVERSAL"
    assert not d.get("legacy")


@pytest.mark.parametrize("admission", [
    "THREE_AGENT_CONSENSUS", "TWO_AGENT_MACRO", "TWO_AGENT_GEMINI",
    "SMC_MAP_AUCTION_CONFIRMATION", "TWO_AGENT_AUCTION", "TWO_AGENT_OTE",
    "R25_SCALP_FADE", "LIQUIDITY_SWEEP_REVERSAL",
])
def test_fx_row_resolves_through_every_active_path(admission):
    """An FX row stamped by any active path resolves to its PATH — the base
    paths plus the reborn PATH 9 carry the forex four with no dedicated lane."""
    snapshot: dict = {"symbol": "EUR/USD"}
    stamp_execution_path(snapshot, admission)
    row = {"id": "T-FX", "symbol": "EUR/USD", "status": "TP2_HIT",
           "pnl_points": 100.0, "signal_snapshot": snapshot}
    resolved = resolve_execution_path(row)
    assert resolved["id"] == path_id_from_admission(admission)


def test_dedicated_forex_lane_is_retired():
    """The strong-structure lane can never admit again - and its block is gone."""
    out = evaluate_strong_structure("SELL", {}, CONFIG)
    assert out["allow"] is False
    assert "retired" in (out.get("reason") or "").lower()
    assert "forex_strong_structure" not in CONFIG


def test_retired_lane_keeps_a_legacy_history_bucket_separate_from_path9():
    """Rows stamped BEFORE the rebirth still report (never UNKNOWN) - but in
    the LEGACY bucket, never the reborn active PATH 9."""
    legacy_id = path_id_from_admission("STRONG_STRUCTURE_CONFIRMED")
    assert legacy_id == LEGACY_STRONG_STRUCTURE
    assert legacy_id != PATH_9
    snapshot: dict = {}
    stamp_execution_path(snapshot, "STRONG_STRUCTURE_CONFIRMED")
    row = {"id": "T-OLD", "status": "TP2_HIT", "pnl_points": 10.0,
           "signal_snapshot": snapshot}
    assert resolve_execution_path(row)["id"] == LEGACY_STRONG_STRUCTURE
