"""Guards for analysis status/no-signal notifications.

cron-job.org triggers the workflow through workflow_dispatch. Those external
runs must not send WAIT/Market Status messages every 10 minutes; only actual
signals/errors should be delivered.
"""

from __future__ import annotations

import scripts.run_analysis as ra
from utils.helpers import load_config


_CONFIG = {
    "notifications": {
        "send_no_signal_updates": True,
        "notify_on_blocked_signal": True,
        "hourly_status": True,
        "hourly_status_interval_minutes": 60,
    }
}


def test_workflow_dispatch_is_silent_by_default(monkeypatch):
    monkeypatch.setenv("GITHUB_EVENT_NAME", "workflow_dispatch")
    monkeypatch.delenv("SEND_STATUS_ON_MANUAL", raising=False)

    assert ra.should_send_status(_CONFIG) is False
    assert ra.should_send_hourly_status(_CONFIG) is False


def test_workflow_dispatch_can_opt_in_to_status(monkeypatch):
    monkeypatch.setenv("GITHUB_EVENT_NAME", "workflow_dispatch")
    monkeypatch.setenv("SEND_STATUS_ON_MANUAL", "true")

    assert ra.should_send_status(_CONFIG) is True
    assert ra.should_send_hourly_status(_CONFIG) is True


def test_native_schedule_keeps_hourly_status_when_config_enables_it(monkeypatch):
    monkeypatch.setenv("GITHUB_EVENT_NAME", "schedule")
    monkeypatch.delenv("SEND_STATUS_ON_MANUAL", raising=False)

    # The exact minute controls should_send_hourly_status, but blocked/no-signal
    # status visibility remains enabled when config explicitly enables it.
    assert ra.should_send_status(_CONFIG) is True


def test_repository_config_hourly_status_back_on(monkeypatch):
    """2026-08-19 (build 13, operator order): the hourly market status message
    is BACK ON in the repository config; blocked-signal spam stays off."""
    config = load_config()
    monkeypatch.setenv("GITHUB_EVENT_NAME", "schedule")
    monkeypatch.delenv("SEND_STATUS_ON_MANUAL", raising=False)

    assert config["notifications"]["send_no_signal_updates"] is False
    assert config["notifications"]["hourly_status"] is True
    assert config["notifications"]["notify_on_blocked_signal"] is False
    assert ra.should_send_status(config) is False  # blocked-signal spam stays off
