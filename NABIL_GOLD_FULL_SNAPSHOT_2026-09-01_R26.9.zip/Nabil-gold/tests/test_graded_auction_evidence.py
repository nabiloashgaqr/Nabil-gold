"""Auction evidence must move continuously instead of freezing at ±1 states."""
from __future__ import annotations

from pathlib import Path
from statistics import mean

from services.auction_evidence import (
    graded_acceptance_rejection,
    normalized_flow_pressure,
    soft_value_score,
)
from services.normalized_confidence import normalized_logistic_confidence


AUCTION_CURVE = {"logistic": {"a": -0.1193965366, "b": 0.4666169632}}


def _edge(families: list[float]) -> float:
    base = mean(families)
    absolute = sum(abs(value) for value in families)
    coherence = abs(sum(families)) / absolute if absolute else 0.0
    return max(-1.0, min(1.0, base * coherence))


def test_flow_pressure_expands_small_raw_imbalances_monotonically() -> None:
    values = [normalized_flow_pressure(raw, scale=0.12) for raw in (0.0, 0.02, 0.05, 0.08, 0.20)]
    assert values == sorted(values)
    assert values[0] == 0.0
    assert 0.35 < values[2] < 0.45  # raw 0.05 is meaningful, not left at 0.05
    assert values[-1] < 1.0
    assert normalized_flow_pressure(-0.05, scale=0.12) == -values[2]


def test_value_location_has_no_hard_one_atr_plateau() -> None:
    one = soft_value_score(1.0, scale_atr=2.0)
    two = soft_value_score(2.0, scale_atr=2.0)
    three = soft_value_score(3.0, scale_atr=2.0)
    assert 0 < one < two < three < 1.0
    assert soft_value_score(-2.0, scale_atr=2.0) == -two


def test_initiative_acceptance_is_graded_by_duration_depth_and_pressure() -> None:
    weak_rows = [
        {"close": 99.9, "high": 100.1, "low": 99.7},
        {"close": 99.8, "high": 100.0, "low": 99.6},
        {"close": 99.7, "high": 99.9, "low": 99.5},
    ]
    strong_rows = [
        {"close": 99.0, "high": 99.2, "low": 98.8},
        {"close": 97.5, "high": 98.0, "low": 97.0},
        {"close": 96.0, "high": 96.5, "low": 95.5},
        {"close": 94.5, "high": 95.0, "low": 94.0},
        {"close": 93.0, "high": 93.5, "low": 92.5},
    ]
    weak, weak_state, weak_metrics = graded_acceptance_rejection(
        weak_rows, pressure=-0.15, vah=110.0, val=100.0, atr=10.0,
    )
    strong, strong_state, strong_metrics = graded_acceptance_rejection(
        strong_rows, pressure=-0.75, vah=110.0, val=100.0, atr=5.0,
    )
    assert weak_state == strong_state == "INITIATIVE_SELL_ACCEPTANCE"
    assert -1.0 < strong < weak < 0.0
    assert strong_metrics["duration"] > weak_metrics["duration"]
    assert strong_metrics["depth"] > weak_metrics["depth"]
    assert abs(strong) - abs(weak) > 0.25


def test_same_state_now_produces_different_confidence_as_evidence_changes() -> None:
    weak_response, _, _ = graded_acceptance_rejection(
        [{"close": 99.9}, {"close": 99.8}, {"close": 99.7}],
        pressure=-0.15, vah=110.0, val=100.0, atr=10.0,
    )
    strong_response, _, _ = graded_acceptance_rejection(
        [{"close": 99.0}, {"close": 97.5}, {"close": 96.0}, {"close": 94.5}, {"close": 93.0}],
        pressure=-0.75, vah=110.0, val=100.0, atr=5.0,
    )
    weak_edge = _edge([-0.20, -0.35, weak_response])
    strong_edge = _edge([-0.70, -0.85, strong_response])
    weak_conf = normalized_logistic_confidence(abs(weak_edge), AUCTION_CURVE)["score"]
    strong_conf = normalized_logistic_confidence(abs(strong_edge), AUCTION_CURVE)["score"]
    assert strong_edge < weak_edge < 0
    assert strong_conf > weak_conf + 15.0
    assert 50.0 <= weak_conf <= 95.0
    assert 50.0 <= strong_conf <= 95.0


def test_future_calibration_builder_uses_the_same_graded_helpers() -> None:
    root = Path(__file__).resolve().parents[1]
    source = (root / "scripts" / "build_agent_calibrations.py").read_text(encoding="utf-8")
    assert "normalized_flow_pressure" in source
    assert "value_location_score" in source
    assert "graded_acceptance_rejection" in source
    assert "def _auction_response" not in source
