"""2026-08-19 build 15: per-pair open cap (each symbol gets its own limit)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from agents.risk_management_agent import RiskManagementAgent  # noqa: E402


def _base_results():
    return {
        "current_price": 2350.0,
        "spread_points": 2.0,
        "technical": {
            "direction": "BUY",
            "confidence": 80,
            "indicators_raw": {"atr": 4.0},
            "key_levels": {"nearest_support": 2344.0, "nearest_resistance": 2360.0},
        },
        "classical": {"direction": "BUY", "confidence": 75,
                      "support_levels": [2344.0, 2338.0],
                      "resistance_levels": [2360.0, 2372.0]},
        "smc": {"direction": "BUY", "confidence": 75,
                "entry_suggestion": {"type": "BUY", "entry": 2350.0, "sl": 2343.0, "tp": 2360.0},
                "order_blocks": []},
        "price_action": {"direction": "NEUTRAL", "confidence": 30},
        "multitimeframe": {"direction": "BUY", "confidence": 80},
        "portfolio": {"open_trades_count": 0, "open_trades_count_this_symbol": 0,
                      "today_signals_count": 0, "consecutive_losses": 0},
    }


def _cfg(**settings_over):
    cfg = {
        "risk_settings": {
            "max_open_trades": 4,
            "max_open_trades_per_symbol": 2,
            "min_rr_ratio": 1.5,
        },
        "filters": {
            "min_atr_for_entry": 1.0,
            "max_spread_points": 5,
            "max_consecutive_losses": 3,
        },
    }
    cfg["risk_settings"].update(settings_over)
    return cfg


class TestPerSymbolCap:
    def _run(self, cfg, symbol_open, aggregate):
        results = _base_results()
        results["portfolio"]["open_trades_count_this_symbol"] = symbol_open
        results["portfolio"]["open_trades_count"] = aggregate
        return RiskManagementAgent(cfg).evaluate(results)

    def test_symbol_below_cap_passes(self):
        r = self._run(_cfg(), symbol_open=1, aggregate=3)
        assert r["approved"] is True

    def test_symbol_at_cap_blocks_even_if_aggregate_free(self):
        # gold at its 2 cap while aggregate is below the belt -> BLOCK
        r = self._run(_cfg(), symbol_open=2, aggregate=2)
        assert r["approved"] is False
        assert r["rejection_reason"] == "Max trades reached"

    def test_other_symbol_at_cap_does_not_block_this_symbol(self):
        # oil has 2 open, gold 0 -> gold passes (aggregate 2 below belt 4)
        r = self._run(_cfg(), symbol_open=0, aggregate=2)
        assert r["approved"] is True

    def test_aggregate_belt_still_holds(self):
        # gold 2 + oil 2 -> aggregate 4 -> belt blocks
        r = self._run(_cfg(), symbol_open=2, aggregate=4)
        assert r["approved"] is False
        assert r["rejection_reason"] == "Max trades reached"

    def test_legacy_aggregate_mode_without_per_symbol_key(self):
        cfg = _cfg()
        cfg["risk_settings"].pop("max_open_trades_per_symbol")
        cfg["risk_settings"]["max_open_trades"] = 3
        r = self._run(cfg, symbol_open=1, aggregate=3)
        assert r["approved"] is False
        assert r["rejection_reason"] == "Max trades reached"

    def test_zero_per_symbol_disables_that_axis(self):
        cfg = _cfg(max_open_trades_per_symbol=0, max_open_trades=2)
        # per-symbol off -> aggregate only: 1 < 2 passes despite symbol at 5
        r = self._run(cfg, symbol_open=5, aggregate=1)
        assert r["approved"] is True

    def test_zero_aggregate_disables_belt(self):
        cfg = _cfg(max_open_trades=0)
        # per-symbol on (2): gold at 1 passes; aggregate unlimited
        r = self._run(cfg, symbol_open=1, aggregate=99)
        assert r["approved"] is True


class TestProductionConfigBuild15:
    def test_flags_shipped(self):
        prod = json.loads(
            Path(__file__).resolve().parents[1].joinpath("config.json").read_text(encoding="utf-8")
        )
        rs = prod.get("risk_settings") or {}
        assert rs.get("max_open_trades_per_symbol") in {2, 3}
        assert rs.get("max_open_trades") in {4, 6}
