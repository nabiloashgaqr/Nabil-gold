"""2026-08-19 build 12: pending guard - operator cancellation rules."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from agents.open_trades_manager import OpenTradesManager  # noqa: E402


def _manager(**pf_over):
    pf = {
        "enabled": True,
        "aging_after_hours": 2,
        "stale_after_hours": 6,
        "stale_after_excursion_points": 250,
        "stale_after_target_progress_pct": 60,
        "mark_revalidation_required_on_session_change": False,
    }
    pf.update(pf_over)
    return OpenTradesManager({
        "schedule": {"timezone": "Asia/Hebron"},
        "pending_freshness": pf,
        "order_execution": {"entry_style": "hybrid", "pending_order_max_cycles": 99,
                            "pending_expire_after_hours": 24},
        "risk_settings": {"min_rr_ratio": 1.5},
    })


def _trade(side="BUY", entry=4440.0, *, creation=4440.0, invalidation=None, session_plan=None):
    row = {
        "id": "TRADE_B12",
        "symbol": "XAU/USD",
        "type": side,
        "status": "PENDING",
        "order_type": f"{side}_LIMIT",
        "order_kind": "LIMIT",
        "entry_price": entry,
        "stop_loss": entry - 40 if side == "BUY" else entry + 40,
        "tp1": entry + 60 if side == "BUY" else entry - 60,
        "tp2": entry + 120 if side == "BUY" else entry - 120,
        "updates_sent": [],
        "signal_snapshot": {
            "session_info": {"current_session": "London + New York Afternoon"},
            "pending_runtime": {"creation_price": creation},
            "session_plan": session_plan or {},
        },
    }
    if invalidation is not None:
        row["signal_snapshot"]["session_plan"]["invalidation_level"] = invalidation
    return row


class TestDefaultNoExcursionKill:
    def test_small_excursion_stays_fresh_by_default(self):
        # market drifted 20 pts away without touching: no kill anywhere
        manager = _manager()
        trade = _trade("BUY", 4400.0, creation=4440.0)
        result = manager.evaluate_trade(trade, 4460.0, candle_high=4465.0, candle_low=4455.0)
        assert result["new_status"] == "PENDING"
        runtime = result["updates"]["signal_snapshot"]["pending_runtime"]
        assert runtime["freshness_state"] in {"FRESH", "AGING"}

    def test_fill_still_happens_when_price_crosses(self):
        # the guard change must NOT break fills: price crossed the limit
        manager = _manager()
        trade = _trade("BUY", 4440.0, creation=4440.0)
        result = manager.evaluate_trade(trade, 4360.0, candle_high=4365.0, candle_low=4355.0)
        assert result["new_status"] == "OPEN"


class TestInvalidationKill:
    def test_buy_invalidation_breach_is_stale(self):
        # gap geometry: price sits between entry and the invalidation level,
        # so the pending has NOT filled - and the thesis is already dead
        manager = _manager()
        trade = _trade("BUY", 4400.0, creation=4440.0, invalidation=4420.0)
        result = manager.evaluate_trade(trade, 4415.0, candle_high=4418.0, candle_low=4412.0)
        assert result["new_status"] == "PENDING"  # no fill happened
        runtime = result["updates"]["signal_snapshot"]["pending_runtime"]
        assert runtime["freshness_state"] == "STALE"
        assert any("invalidation" in str(r) for r in runtime.get("freshness_reasons", []))

    def test_buy_above_invalidation_is_fine(self):
        manager = _manager()
        trade = _trade("BUY", 4400.0, creation=4440.0, invalidation=4420.0)
        result = manager.evaluate_trade(trade, 4430.0, candle_high=4433.0, candle_low=4427.0)
        runtime = result["updates"]["signal_snapshot"]["pending_runtime"]
        assert runtime["freshness_state"] != "STALE"

    def test_sell_invalidation_breach_is_stale(self):
        manager = _manager()
        trade = _trade("SELL", 4400.0, creation=4360.0, invalidation=4380.0)
        result = manager.evaluate_trade(trade, 4385.0, candle_high=4388.0, candle_low=4382.0)
        assert result["new_status"] == "PENDING"
        runtime = result["updates"]["signal_snapshot"]["pending_runtime"]
        assert runtime["freshness_state"] == "STALE"
        assert any("invalidation" in str(r) for r in runtime.get("freshness_reasons", []))

    def test_invalidation_kill_can_be_disabled(self):
        manager = _manager(invalidation_kill_enabled=False)
        trade = _trade("BUY", 4400.0, creation=4440.0, invalidation=4420.0)
        result = manager.evaluate_trade(trade, 4415.0, candle_high=4418.0, candle_low=4412.0)
        runtime = result["updates"]["signal_snapshot"]["pending_runtime"]
        assert runtime["freshness_state"] != "STALE"

    def test_no_invalidation_no_kill(self):
        manager = _manager()
        trade = _trade("BUY", 4400.0, creation=4400.0, invalidation=None)
        result = manager.evaluate_trade(trade, 4415.0, candle_high=4418.0, candle_low=4412.0)
        runtime = result["updates"]["signal_snapshot"]["pending_runtime"]
        assert runtime["freshness_state"] != "STALE"  # age < 6h, no invalidation


class TestAgeAndExpiryStillKill:
    def test_age_kill_untouched(self):
        import datetime as _dt

        manager = _manager()
        trade = _trade("BUY", 4440.0)
        old = (_dt.datetime.now(_dt.timezone.utc) - _dt.timedelta(hours=7)).isoformat()
        trade["created_at"] = old
        trade["entry_time"] = old
        result = manager.evaluate_trade(trade, 4439.0, candle_high=4440.5, candle_low=4438.0)
        runtime = result["updates"]["signal_snapshot"]["pending_runtime"]
        assert runtime["freshness_state"] == "STALE"
        assert any("waiting too long" in str(r) for r in runtime.get("freshness_reasons", []))


class TestProductionConfig:
    def test_flags_shipped(self):
        import json

        prod = json.loads(Path(__file__).resolve().parents[1].joinpath("config.json").read_text(encoding="utf-8"))
        pf = prod.get("pending_freshness") or {}
        assert pf.get("excursion_kill_enabled") is False
        assert pf.get("invalidation_kill_enabled") is True
