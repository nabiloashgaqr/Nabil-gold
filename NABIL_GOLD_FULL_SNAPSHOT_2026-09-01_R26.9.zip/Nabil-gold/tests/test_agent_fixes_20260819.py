"""2026-08-19 agent-fix tests: Stochastic/Ichimoku, harmonic, H&S/flags,
macro economic events, MAE/MFE R-multiples, volatility targeting."""
from __future__ import annotations

import json
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from agents.classical_agent import ClassicalAgent  # noqa: E402
from agents.macro_fundamental_agent import MacroFundamentalAgent  # noqa: E402
from agents.open_trades_manager import OpenTradesManager  # noqa: E402
from agents.price_action_agent import PriceActionAgent  # noqa: E402
from agents.technical_agent import TechnicalAgent  # noqa: E402
from utils.indicators import calculate_ichimoku, calculate_stochastic  # noqa: E402


def _candles(n=200, trend=0.0, seed=0, base=4000.0):
    rng = random.Random(seed)
    candles = []
    price = base
    for _ in range(n):
        high = price + rng.uniform(1, 3)
        low = price - rng.uniform(1, 3)
        close = price + rng.uniform(-2, 2) + trend
        candles.append({"high": high, "low": low, "close": close})
        price = close
    return candles


class TestStochasticIchimoku:
    def test_stochastic_bounds_and_states(self):
        st = calculate_stochastic(_candles(100))
        assert 0 <= st["k"] <= 100 and 0 <= st["d"] <= 100
        assert st["state"] in {"OVERBOUGHT", "OVERSOLD", "NEUTRAL", "INSUFFICIENT_DATA"}
        assert st["crossover"] in {"BULLISH", "BEARISH", "NONE"}

    def test_stochastic_uptrend_overbought(self):
        st = calculate_stochastic(_candles(120, trend=2.0, seed=3))
        assert st["state"] == "OVERBOUGHT"

    def test_ichimoku_above_cloud_on_uptrend(self):
        ich = calculate_ichimoku(_candles(150, trend=1.5, seed=4))
        assert ich["state"] == "ABOVE_CLOUD"
        assert ich["cloud"] == "BULLISH"

    def test_technical_agent_exposes_new_evidence(self):
        agent = TechnicalAgent({"agent_weights": {}})
        result = agent._technical_analysis(_candles(160), {})
        assert "stochastic" in result and "ichimoku" in result
        assert any(e["name"] == "Stochastic" for e in result["evidence"])
        assert any(e["name"] == "Ichimoku cloud" for e in result["evidence"])


class TestHarmonicPatterns:
    def _bullish_gartley_candles(self):
        # X bottom -> A top -> B retrace ~0.618 -> C retrace -> price near D(0.786)
        x, a = 100.0, 112.0
        b = a - (a - x) * 0.618          # 104.584
        c = b + (a - b) * 0.5            # 108.292
        d = x + (a - x) * 0.786          # 109.432
        seg = []
        for start, end in ((x, a), (a, b), (b, c), (c, d)):
            steps = 16
            for i in range(steps):
                p = start + (end - start) * (i + 1) / steps
                seg.append({"high": p + 0.4, "low": p - 0.4, "close": p})
        # a couple of bars at D
        for i in range(3):
            seg.append({"high": d + 0.3, "low": d - 0.3, "close": d})
        return seg

    def test_gartley_detected(self, monkeypatch):
        agent = PriceActionAgent({"agent_weights": {}})
        candles = self._bullish_gartley_candles()
        # Inject explicit swing pivots (swing detection itself is covered by
        # its own tests) so the harmonic math is tested deterministically:
        # X=100(low) A=112(high) B=104.58(low) C=108.29(high), price at D=109.43
        swings = {
            "highs": [{"price": 112.0, "index": 13}, {"price": 108.29, "index": 41}],
            "lows": [{"price": 100.0, "index": 0}, {"price": 104.58, "index": 27}],
        }
        import agents.price_action_agent as pa

        monkeypatch.setattr(pa, "detect_swing_points", lambda c, lookback=3: swings)
        patterns, score = agent._detect_harmonic_patterns(candles, candles[-1]["close"])
        assert patterns, "expected a harmonic pattern"
        assert patterns[0]["harmonic"] is True
        assert "Gartley" in patterns[0]["pattern"]
        assert patterns[0]["type"] == "bullish"
        assert score > 0

    def test_no_pattern_on_noise(self):
        agent = PriceActionAgent({"agent_weights": {}})
        candles = _candles(120, seed=11)
        patterns, score = agent._detect_harmonic_patterns(candles, candles[-1]["close"])
        assert patterns == [] and score == 0

    def test_short_series_safe(self):
        agent = PriceActionAgent({"agent_weights": {}})
        patterns, score = agent._detect_harmonic_patterns(_candles(30), 4000.0)
        assert patterns == [] and score == 0


class TestHeadShouldersAndFlags:
    def _hs_candles(self):
        # three highs: L=110, head=116, R=110 (shoulders equal), neckline ~105
        candles = []
        for p in (100, 110, 105, 116, 105, 110, 104.5):
            candles.append({"high": p + 0.3, "low": p - 0.5, "close": p})
        return candles

    def test_head_and_shoulders_detected(self):
        agent = ClassicalAgent({"agent_weights": {}})
        candles = self._hs_candles()
        swings = {
            "highs": [{"price": 110, "index": 1}, {"price": 116, "index": 3}, {"price": 110, "index": 5}],
            "lows": [],
        }
        patterns = agent._head_shoulders_patterns(swings["highs"], swings["lows"], 104.5, 1.0, 6.0)
        assert patterns and patterns[0]["pattern"] == "Head and Shoulders"
        assert patterns[0]["type"] == "bearish"
        assert patterns[0]["completion"] == 100  # price broke the neckline

    def test_flag_detected(self):
        agent = ClassicalAgent({"agent_weights": {}})
        candles = []
        for i in range(8):  # strong pole up (>=12 window needs 12+ candles)
            p = 100 + i * 3
            candles.append({"high": p + 1, "low": p - 1, "close": p})
        for i in range(4):  # bull flag consolidation (lower highs, lower lows)
            p = 121 - i * 0.8
            candles.append({"high": p + 0.3, "low": p - 0.7, "close": p - 0.2})
        # breakout: current price above the flag's first consolidation high
        patterns = agent._flag_patterns(candles, 122.3, 20.0)
        assert patterns and "Bull Flag" in patterns[0]["pattern"]
        assert patterns[0]["status"] == "COMPLETE"


class TestMacroEconomicEvents:
    def _cfg(self, tmp_path, events=None, enabled=True):
        path = tmp_path / "events.json"
        if events is not None:
            path.write_text(json.dumps(events), encoding="utf-8")
        return {
            "macro_economic_events": {"enabled": enabled, "path": str(path), "max_age_days": 7},
        }

    def _events(self):
        now = datetime.now(timezone.utc)
        return [
            {"event": "CPI YoY", "forecast": 3.2, "actual": 3.5,
             "date": (now - timedelta(days=1)).strftime("%Y-%m-%d")},
            {"event": "NFP", "forecast": 180, "actual": 120,
             "date": (now - timedelta(days=2)).strftime("%Y-%m-%d")},
        ]

    def test_cpi_hot_and_weak_nfp_are_bullish(self, tmp_path):
        agent = MacroFundamentalAgent(self._cfg(tmp_path, self._events()))
        d = agent.macro_direction({"dxy_trend": "flat", "us10y_trend": "flat"})
        # 0.8 (CPI) + 1.3 (NFP) capped at the ±2.0 total ceiling -> 2.0
        assert d["confidence_breakdown"]["events"] == 2.0
        assert d["bias"] == "BULLISH_GOLD"
        assert any("CPI" in r for r in d["drivers"])

    def test_hawkish_surprise_is_bearish(self, tmp_path):
        now = datetime.now(timezone.utc)
        events = [{"event": "FOMC Rate Decision", "forecast": 0.0, "actual": 0.25,
                   "date": (now - timedelta(days=1)).strftime("%Y-%m-%d")}]
        agent = MacroFundamentalAgent(self._cfg(tmp_path, events))
        d = agent.macro_direction({"dxy_trend": "flat"})
        assert d["confidence_breakdown"]["events"] == -1.8
        assert d["bias"] == "BEARISH_GOLD"

    def test_disabled_by_default(self, tmp_path):
        agent = MacroFundamentalAgent(self._cfg(tmp_path, self._events(), enabled=False))
        d = agent.macro_direction({"dxy_trend": "flat"})
        assert d["confidence_breakdown"]["events"] == 0.0

    def test_stale_events_ignored(self, tmp_path):
        now = datetime.now(timezone.utc)
        events = [{"event": "CPI YoY", "forecast": 3.0, "actual": 3.5,
                   "date": (now - timedelta(days=30)).strftime("%Y-%m-%d")}]
        agent = MacroFundamentalAgent(self._cfg(tmp_path, events))
        d = agent.macro_direction({"dxy_trend": "flat"})
        assert d["confidence_breakdown"]["events"] == 0.0

    def test_missing_file_fails_open(self, tmp_path):
        agent = MacroFundamentalAgent(self._cfg(tmp_path, events=None))
        d = agent.macro_direction({"dxy_trend": "flat"})
        assert d["confidence_breakdown"]["events"] == 0.0

    def test_cap_at_two_points(self, tmp_path):
        now = datetime.now(timezone.utc)
        events = [
            {"event": "CPI", "forecast": 3.0, "actual": 4.0, "date": (now - timedelta(days=1)).strftime("%Y-%m-%d")},
            {"event": "PPI", "forecast": 2.0, "actual": 3.0, "date": (now - timedelta(days=1)).strftime("%Y-%m-%d")},
            {"event": "PCE", "forecast": 2.0, "actual": 3.0, "date": (now - timedelta(days=1)).strftime("%Y-%m-%d")},
        ]
        agent = MacroFundamentalAgent(self._cfg(tmp_path, events))
        d = agent.macro_direction({"dxy_trend": "flat"})
        assert d["confidence_breakdown"]["events"] <= 2.0


class TestMaeMfeRMultiples:
    def _trade(self):
        return {
            "id": "TRADE_MAEMFE", "type": "BUY", "symbol": "XAU/USD",
            "entry_price": 4000.0, "stop_loss": 3950.0,
            "tp1": 4080.0, "tp2": 4150.0, "status": "OPEN",
            "updates_sent": [], "sl_moved_to_entry": False, "partial_close": False,
        }

    def _manager(self, config):
        return OpenTradesManager(config)

    def test_mae_mfe_r_recorded(self):
        mgr = self._manager({"risk_settings": {}, "trade_management": {}})
        trade = self._trade()
        result = mgr.evaluate_trade(
            trade, current_price=3975.0, candle_high=3978.0, candle_low=3972.0,
        )
        updates = result.get("updates", {})
        # risk distance = 50 points; price dropped to 3972 => MAE -28pts => -0.56R
        assert updates.get("mae_r") is not None
        assert updates["mae_r"] <= -0.5
        assert updates["mfe_r"] is not None
