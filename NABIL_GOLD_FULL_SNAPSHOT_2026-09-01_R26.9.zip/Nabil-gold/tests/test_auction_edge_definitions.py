"""Shared composite auction edge definitions (operator 2026-08-14).

The three families were found to be near-duplicated in practice: the live
read showed value_location=0.70 and acceptance_rejection=0.70 moving
together, so the historical composite mostly measured "how far price has
stretched" rather than "does the flow support continuation" -- and stretch
alone barely ranks the next bar (+2.5pp tercile lift on 60 days).

The fix is measurement, not guessing: `composite_auction_edge` exposes six
candidate definitions, the calibration builder sweeps ALL of them on real
outcomes and prints the lift table, and the operator selects one in
`config.json::auction_flow.edge_definition`. Live agent and trainer share
the single function, so training/serving parity holds by construction.
"""
from __future__ import annotations

import math

import pytest

from services.auction_evidence import EDGE_DEFINITIONS, composite_auction_edge


def _legacy(p: float, v: float, r: float, q: float) -> float:
    base = (p + v + r) / 3.0
    absolute = abs(p) + abs(v) + abs(r)
    coherence = abs(p + v + r) / absolute if absolute else 0.0
    return max(-1.0, min(1.0, base * coherence * q))


def test_default_definition_is_byte_compatible_with_the_legacy_formula():
    cases = [
        (0.21, 0.70, 0.70, 0.943),   # the operator's actual live read
        (-0.5, 0.3, -0.8, 0.6),
        (0.0, 0.0, 0.0, 1.0),
        (1.0, -1.0, 1.0, 0.5),
    ]
    for p, v, r, q in cases:
        assert composite_auction_edge(p, v, r, q, definition="extension_mean") == pytest.approx(
            _legacy(p, v, r, q), abs=1e-12
        )


def test_flow_confirmed_acceptance_requires_agreeing_flow():
    # Flow confirms the acceptance -> geometric-mean strength, sign of r.
    e = composite_auction_edge(0.4, 0.9, 0.7, 1.0, definition="flow_confirmed_acceptance")
    assert e == pytest.approx(math.sqrt(0.7 * 0.4), abs=1e-9)
    # Opposing flow -> no conviction, zero edge.
    assert composite_auction_edge(-0.4, 0.9, 0.7, 1.0, definition="flow_confirmed_acceptance") == 0.0
    # No value event at all -> extension alone earns nothing.
    assert composite_auction_edge(0.4, 0.9, 0.0, 1.0, definition="flow_confirmed_acceptance") == 0.0
    # Symmetric on the sell side.
    e = composite_auction_edge(-0.4, -0.9, -0.7, 1.0, definition="flow_confirmed_acceptance")
    assert e == pytest.approx(-math.sqrt(0.7 * 0.4), abs=1e-9)


def test_single_family_definitions_isolate_their_family():
    assert composite_auction_edge(0.8, 0.1, -0.2, 1.0, definition="pressure_only") == pytest.approx(0.8)
    assert composite_auction_edge(0.8, 0.1, -0.2, 1.0, definition="value_only") == pytest.approx(0.1)
    assert composite_auction_edge(0.8, 0.1, -0.2, 1.0, definition="acceptance_only") == pytest.approx(-0.2)


def test_quality_scales_every_definition():
    for d in EDGE_DEFINITIONS:
        full = composite_auction_edge(0.6, 0.6, 0.6, 1.0, definition=d)
        half = composite_auction_edge(0.6, 0.6, 0.6, 0.5, definition=d)
        if full != 0.0:
            assert half == pytest.approx(full * 0.5, abs=1e-9)


def test_unknown_definition_is_rejected_by_the_trainer():
    import io

    src = io.open("scripts/build_agent_calibrations.py", encoding="utf-8").read()
    assert "Unknown auction_flow.edge_definition" in src
    # And the live agent reads the same config key.
    agent = io.open("agents/auction_flow_agent.py", encoding="utf-8").read()
    assert 'self.cfg.get("edge_definition"' in agent
    assert "composite_auction_edge" in agent


def test_live_agent_and_trainer_share_the_composite():
    """Parity: both sides import the one shared function."""
    import io

    agent = io.open("agents/auction_flow_agent.py", encoding="utf-8").read()
    trainer = io.open("scripts/build_agent_calibrations.py", encoding="utf-8").read()
    assert "composite_auction_edge" in agent
    assert "composite_auction_edge" in trainer
