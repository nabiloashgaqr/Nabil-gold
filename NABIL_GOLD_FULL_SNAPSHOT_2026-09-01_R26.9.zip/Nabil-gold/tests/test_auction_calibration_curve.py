"""Auction Flow calibration curve building logic (operator 2026-08-14).

The original trainer scored minute-scale auction evidence against a 4-hour
barrier, drowned the informative tail under the near-zero-edge noise mass,
and fitted from a single seed that stalled at the b=0 boundary. The result
was a flat curve (span < 2pp), which correctly made the live agent hold the
50% floor -- but for the wrong reason: the experiment, not the market.

These tests pin the fixed behaviour:
* a real monotonic signal earns a curve with usable span;
* pure noise is refused honestly (b == 0), never bought by overfitting --
  the fitter must validate its slope OUT of sample against the flat baseline;
* the training outcome definition matches the agent's natural horizon and
  excludes undeclared near-zero edges;
* the barrier label helper honours the configurable horizon.
"""
from __future__ import annotations

import math
import random

from scripts.build_agent_calibrations import (
    _barrier_label,
    _fit_monotonic_logistic,
    _log_loss,
)


def _sig(z: float) -> float:
    return 1.0 / (1.0 + math.exp(-max(-60.0, min(60.0, z))))


def _span_points(curve: dict) -> float:
    return (_sig(curve["a"] + curve["b"]) - _sig(curve["a"])) * 100.0


def _dataset(signal_strength: float, n: int, seed: int) -> tuple[list, list]:
    rng = random.Random(seed)
    xs, ys = [], []
    while len(xs) < n:
        edge = min(1.0, abs(rng.gauss(0, 0.16)))
        if edge < 0.05:
            continue  # mirrors the training-time min-edge exclusion
        p = min(0.97, max(0.03, 0.47 + signal_strength * edge))
        xs.append(edge)
        ys.append(1 if rng.random() < p else 0)
    return xs, ys


def test_real_signal_earns_a_curve_with_usable_span():
    xs, ys = _dataset(0.35, 1500, seed=11)
    curve = _fit_monotonic_logistic(xs, ys)
    assert curve["b"] > 0
    assert _span_points(curve) >= 2.0
    # And the earned slope must genuinely explain the data better than flat.
    rate = sum(ys) / len(ys)
    a_flat = math.log(rate / (1.0 - rate))
    assert _log_loss(xs, ys, curve["a"], curve["b"]) < _log_loss(xs, ys, a_flat, 0.0)


def test_pure_noise_is_refused_with_flat_slope_not_bought_by_overfit():
    xs, ys = _dataset(0.0, 1500, seed=13)
    curve = _fit_monotonic_logistic(xs, ys)
    # The honest answer for zero signal is b == 0 -> span 0 -> the live
    # agent keeps the 50% floor. A positive span here would be fabricated
    # discrimination the market never offered.
    assert _span_points(curve) < 2.0


def test_fit_is_deterministic_for_the_same_samples():
    xs, ys = _dataset(0.35, 800, seed=17)
    assert _fit_monotonic_logistic(xs, ys) == _fit_monotonic_logistic(xs, ys)


def test_barrier_label_honours_the_configured_horizon():
    bars = [
        {"high": 101.0, "low": 99.5},   # bar 1: nothing hit
        {"high": 101.0, "low": 99.5},   # bar 2: nothing hit
        {"high": 103.0, "low": 99.5},   # bar 3: upper barrier hit
    ]
    # Horizon of 2 bars: the bar-3 breakout must NOT be visible.
    assert _barrier_label(1, 100.0, 2.0, bars, bars=2) is None
    # Horizon of 3 bars sees it: long direction wins.
    assert _barrier_label(1, 100.0, 2.0, bars, bars=3) == 1
    # Same move scored against a short direction is a loss.
    assert _barrier_label(-1, 100.0, 2.0, bars, bars=3) == 0


def test_training_outcome_definition_matches_the_agent_horizon():
    """The stored outcome block must declare the short matched horizon."""
    import io

    src = io.open("scripts/build_agent_calibrations.py", encoding="utf-8").read()
    assert 'calibration_horizon_15m_bars", 4' in src
    assert 'calibration_barrier_atr", 0.5' in src
    assert 'calibration_min_edge", 0.05' in src
    assert 'calibration_sample_spacing_minutes", 15' in src
    # The old mismatched experiment must be gone.
    assert '"outcome": {"barrier_atr_15m": 1.0, "horizon_15m_bars": 16}' not in src
