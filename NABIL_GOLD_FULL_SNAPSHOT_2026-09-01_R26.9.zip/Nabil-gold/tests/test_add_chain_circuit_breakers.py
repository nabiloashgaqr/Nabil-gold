"""Three locks against the 2026-08-18 add chain (a martingale nobody ordered).

Live sequence, one afternoon, all BUY, all from the add engine, while the
book had flipped SELL and the manual analyst called distribution from 4399:

    13:31 add -> SL_HIT
    13:56 add -> SL_HIT
    14:36 add -> THESIS_EXIT (-248)
    15:01 add -> SL_HIT
    15:16 add -> SL_HIT
    15:21 add -> THESIS_EXIT (+84)

How "one add per parent" produced six adds:
  * each add, once open, was itself a valid PARENT for the next add;
  * every SL_HIT freed a seat under the 2-open cap;
  * the post-loss cooldown (after_loss_minutes=90) lived only in
    duplicate_signal_reason — the add path never called it;
  * the dynamic-risk breaker (halt_after_losses=3) was computed AFTER
    _check_scale_in in the cycle, so the adds never saw the halt.

The three locks (operator 2026-08-18h):
  1. an add is never a parent — only original entries anchor adds;
  2. a same-direction SL_HIT within the cooldown window freezes all adds
     in that direction on the symbol;
  3. dynamic risk is evaluated BEFORE the add engine, and any HALT level
     silences it for the cycle.
"""

from __future__ import annotations

import asyncio
import io
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from scripts.run_analysis import _check_scale_in

SRC = io.open(ROOT / "scripts" / "run_analysis.py", encoding="utf-8").read()


class _FakeDB:
    def __init__(self, recent=None):
        self.saved = []
        self._recent = recent or []

    def new_trade_id(self):
        return "TRADE_TEST_ADD"

    def save_trade(self, decision):
        self.saved.append(decision)
        return "TRADE_TEST_ADD"

    def get_recent_trades(self, limit=50):
        return list(self._recent)


class _FakeTelegram:
    def __init__(self):
        self.messages = []

    def send_message(self, message, urgent=False):
        self.messages.append(message)
        return True


def _config():
    return {
        "symbol": "XAU/USD",
        "order_execution": {
            "entry_style": "hybrid",
            "fixed_risk": {
                "scale_in_enabled": True,
                "scale_in_max": 1,
                "scale_in_trigger_points": 150,
                "scale_in_size_ratio": 0.5,
            },
        },
        "signal_requirements": {"agent_min_confidence": 65,
                                "min_agents_agree": 3,
                                "min_consensus_confidence": 65},
        "duplicate_signal_filter": {
            "open_trade": {"max_open_same_direction": 2},
            "cooldown": {"after_loss_minutes": 90, "lookback_hours": 6},
        },
        "risk_settings": {"max_open_trades": 2},
    }


def _results(price=4370.0):
    quiet = {"direction": "WAIT", "confidence": 30}
    return {
        "symbol": "XAU/USD",
        "current_price": price,
        "technical": dict(quiet), "multitimeframe": dict(quiet),
        # _levels_from_results reads support/resistance off the agent
        # sections, so the BUY add finds its nearby support on classical.
        "classical": {**quiet, "support_levels": [price - 5.0]},
        "smc": dict(quiet), "price_action": dict(quiet),
        "auction_flow": dict(quiet),
        "risk": {"approved": True, "checks": {
            "max_open_trades_filter": True, "max_daily_signals_filter": True,
            "atr_filter": True, "spread_filter": True,
            "consecutive_losses_filter": True}},
    }


def _original_parent(entry=4540.0):
    return {"id": "PARENT_ORIG", "type": "BUY", "status": "OPEN",
            "symbol": "XAU/USD", "entry_price": entry,
            "stop_loss": entry - 30, "tp1": entry + 25, "tp2": entry + 60,
            "signal": {"type": "BUY"}}


def _add_trade(entry=4540.0, trade_id="ADD_1"):
    t = _original_parent(entry)
    t["id"] = trade_id
    t["signal"] = {"type": "BUY", "scale_in": True, "parent_trade_id": "PARENT_ORIG"}
    return t


# ── lock 1: an add is never a parent ────────────────────────────────────────

def test_an_add_cannot_anchor_another_add():
    """The chain's engine: add #1 (open) tries to parent add #2. Refused."""
    db = _FakeDB()
    tg = _FakeTelegram()
    only_an_add_is_open = [_add_trade(entry=4540.0)]

    asyncio.run(_check_scale_in(_config(), _results(price=4370.0),
                                only_an_add_is_open, db, tg))

    assert db.saved == [], "an add anchored another add — the chain is back"
    assert tg.messages == []


def test_an_original_parent_still_anchors_one_add():
    db = _FakeDB()
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(_config(), _results(price=4370.0),
                                [_original_parent(entry=4540.0)], db, tg))

    assert len(db.saved) == 1


# ── lock 2: post-loss cooldown covers adds ──────────────────────────────────

def test_recent_same_direction_loss_freezes_adds():
    from datetime import datetime, timezone
    fresh_loss = {
        "id": "LOST_ADD", "type": "BUY", "status": "SL_HIT", "result": "LOSS",
        "symbol": "XAU/USD", "entry_price": 4560.0,
        "closed_at": datetime.now(timezone.utc).isoformat(),
    }
    db = _FakeDB(recent=[fresh_loss])
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(_config(), _results(price=4370.0),
                                [_original_parent(entry=4540.0)], db, tg))

    assert db.saved == [], "an add entered minutes after a same-direction stop-out"


def test_stale_loss_outside_the_window_does_not_freeze():
    from datetime import datetime, timedelta, timezone
    old_loss = {
        "id": "OLD_LOSS", "type": "BUY", "status": "SL_HIT", "result": "LOSS",
        "symbol": "XAU/USD", "entry_price": 4560.0,
        "closed_at": (datetime.now(timezone.utc) - timedelta(minutes=120)).isoformat(),
    }
    db = _FakeDB(recent=[old_loss])
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(_config(), _results(price=4370.0),
                                [_original_parent(entry=4540.0)], db, tg))

    assert len(db.saved) == 1, "a 2-hour-old loss must not freeze adds forever"


def test_opposite_direction_loss_does_not_freeze():
    from datetime import datetime, timezone
    sell_loss = {
        "id": "SELL_LOSS", "type": "SELL", "status": "SL_HIT", "result": "LOSS",
        "symbol": "XAU/USD", "entry_price": 4300.0,
        "closed_at": datetime.now(timezone.utc).isoformat(),
    }
    db = _FakeDB(recent=[sell_loss])
    tg = _FakeTelegram()

    asyncio.run(_check_scale_in(_config(), _results(price=4370.0),
                                [_original_parent(entry=4540.0)], db, tg))

    assert len(db.saved) == 1


# ── lock 3: dynamic risk runs first and a HALT silences the engine ─────────

def test_dynamic_risk_is_evaluated_before_the_add_engine():
    dr_at = SRC.index('all_results["dynamic_risk"] = DynamicRiskManager(config).evaluate(database)')
    scale_at = SRC.index("await _check_scale_in(")
    assert dr_at < scale_at, "the breaker is computed after the adds again"


def test_a_halt_level_silences_the_add_engine():
    block = SRC.split('DYNAMIC RISK BEFORE ADDS')[1][:2500]
    assert '"HALT" in _dr_level' in block
    assert "Scale-in engine silenced" in block
    silenced_at = block.index("Scale-in engine silenced")
    called_at = block.index("await _check_scale_in(")
    assert silenced_at < called_at


def test_the_locks_are_documented_at_the_site():
    assert "AN ADD IS NEVER A PARENT" in SRC
    assert "POST-LOSS COOLDOWN FOR ADDS" in SRC
    assert "DYNAMIC RISK BEFORE ADDS" in SRC
