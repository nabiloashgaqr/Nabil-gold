"""BUILD 26 (2026-08-21): per-symbol fundamentals end-to-end.

The final cross-symbol audit found three display/input leaks (the DECISION
routes were already isolated):
  1. `_planner_context_confirmation` and the display-confidence opposition
     penalty used GOLD macro semantics (BULLISH_GOLD/BEARISH_GOLD) on WTI
     cards -> oil cards were confirmed/punished by the wrong market.
  2. Gemini review payloads fed the GOLD macro block into WTI requests and
     the review_signal persona said "specialized in XAU/USD" literally.
  3. Rule A (single-family confirmers) refused `oil_macro` rescues of
     all-trend WTI books because the gold rule only names "macro".

These tests pin: WTI reads oil_macro everywhere, gold behaviour is
byte-for-byte unchanged, and the entry ladder lets the oil macro rescue its
own book.
"""
from __future__ import annotations

import json

import scripts.run_analysis as ra
from services.thesis_consensus import evaluate_directional_admission


def _core_book(side="BUY", conf=75.0, symbol="WTI/USD", **extra):
    details = {
        "symbol": symbol,
        "technical": {"direction": side, "confidence": conf},
        "multitimeframe": {"direction": side, "confidence": conf},
        "classical": {"direction": side, "confidence": conf},
        "smc": {"direction": "WAIT", "confidence": 20.0},
        "price_action": {"direction": "WAIT", "confidence": 30.0},
    }
    details.update(extra)
    return details


def _cfg(symbol="WTI/USD"):
    import json as _json
    from pathlib import Path
    base = _json.loads((Path(__file__).resolve().parents[1] / "config.json").read_text(encoding="utf-8"))
    base["symbol"] = symbol
    return base


# ── 1) planner display confirmation is symbol-aware ────────────────────────
def test_wti_decision_confirms_via_oil_macro():
    decision = {"symbol": "WTI/USD", "agent_details": {
        "oil_macro": {"direction": "BUY", "confidence": 60.0}}}
    result = ra._planner_context_confirmation(decision, _cfg("WTI/USD"), "BUY")
    assert result.get("allow") is True
    assert result.get("source") == "oil_macro"


def test_gold_macro_cannot_confirm_a_wti_decision():
    decision = {
        "symbol": "WTI/USD",
        "news_context": {"macro": {"macro_direction": {
            "bias": "BULLISH_GOLD", "confidence": 80.0}}},
        "agent_details": {"oil_macro": {"direction": "WAIT", "confidence": 0.0}},
    }
    result = ra._planner_context_confirmation(decision, _cfg("WTI/USD"), "BUY")
    # the gold macro is the wrong market: it must NOT confirm a WTI card
    assert result.get("allow") is False or result.get("source") != "macro"


def test_gold_decision_confirms_via_gold_macro_unchanged():
    decision = {
        "symbol": "XAU/USD",
        "news_context": {"macro": {"macro_direction": {
            "bias": "BULLISH_GOLD", "confidence": 80.0}}},
    }
    result = ra._planner_context_confirmation(decision, _cfg("XAU/USD"), "BUY")
    assert result.get("allow") is True
    assert result.get("source") == "macro"


def test_display_confidence_wti_ignores_gold_macro_opposition():
    base_decision = {
        "symbol": "WTI/USD",
        "agent_details": {
            "technical": {"direction": "BUY", "confidence": 75.0},
            "multitimeframe": {"direction": "BUY", "confidence": 75.0},
            "classical": {"direction": "WAIT", "confidence": 40.0},
            "smc": {"direction": "WAIT", "confidence": 20.0},
            "price_action": {"direction": "WAIT", "confidence": 30.0},
            "oil_macro": {"direction": "BUY", "confidence": 60.0},
        },
        "news_context": {"macro": {"macro_direction": {
            "bias": "BEARISH_GOLD", "confidence": 85.0}}},
    }
    candidate = {"thesis_dominance_score": 70.0, "quality_score": 60.0}
    conf = ra._planner_display_confidence(
        base_decision, {}, candidate, _cfg("WTI/USD"), direction="BUY")
    # 75*0.75 + 70*0.25 = 73.75; +2 (oil macro confirms) = 75.75; NO gold -5
    assert abs(conf - 75.8) < 0.05


def test_display_confidence_gold_still_pays_gold_macro_opposition():
    base_decision = {
        "symbol": "XAU/USD",
        "agent_details": {
            "technical": {"direction": "BUY", "confidence": 75.0},
            "multitimeframe": {"direction": "BUY", "confidence": 75.0},
            "classical": {"direction": "WAIT", "confidence": 40.0},
            "smc": {"direction": "WAIT", "confidence": 20.0},
            "price_action": {"direction": "WAIT", "confidence": 30.0},
        },
        "news_context": {"macro": {"macro_direction": {
            "bias": "BEARISH_GOLD", "confidence": 85.0}}},
    }
    candidate = {"thesis_dominance_score": 70.0, "quality_score": 60.0}
    conf = ra._planner_display_confidence(
        base_decision, {}, candidate, _cfg("XAU/USD"), direction="BUY")
    # 73.75 (no confirmation) - 5 (opposing gold macro) = 68.75
    assert abs(conf - 68.8) < 0.05


# ── 2) Gemini payloads carry the right market's fundamentals ───────────────
def _gemini():
    import services.llm_review as llm
    svc = llm.GeminiReviewService({})
    svc.enabled = True
    return svc


def test_signal_payload_wti_carries_oil_macro_not_gold():
    svc = _gemini()
    payload = {
        "symbol": "WTI/USD",
        "decision": {"symbol": "WTI/USD", "decision": "BUY", "signal": {}},
        "all_results": {
            "macro_fundamental": {"macro_direction": {"bias": "BULLISH_GOLD", "confidence": 70.0}},
            "oil_macro": {"direction": "SELL", "confidence": 44.0, "bias": "BEARISH_OIL",
                          "score": -0.5, "summary": "spread widening"},
        },
    }
    compact = svc._compact_signal_payload(payload)
    assert compact["macro_direction"] is None           # gold block suppressed
    assert compact["oil_macro"]["direction"] == "SELL"
    assert compact["oil_macro"]["confidence"] == 44.0
    assert "spread widening" in compact["oil_macro"]["summary"]


def test_signal_payload_gold_carries_gold_macro_not_oil():
    svc = _gemini()
    payload = {
        "symbol": "XAU/USD",
        "decision": {"symbol": "XAU/USD", "decision": "BUY", "signal": {}},
        "all_results": {
            "macro_fundamental": {"macro_direction": {"bias": "BULLISH_GOLD", "confidence": 70.0}},
            "oil_macro": {"direction": "SELL", "confidence": 44.0},
        },
    }
    compact = svc._compact_signal_payload(payload)
    assert compact["macro_direction"]["bias"] == "BULLISH_GOLD"
    assert compact["oil_macro"] is None


def test_market_payload_wti_carries_oil_macro():
    svc = _gemini()
    payload = {
        "symbol": "WTI/USD",
        "decision": {"symbol": "WTI/USD"},
        "all_results": {
            "oil_macro": {"direction": "BUY", "confidence": 55.0, "bias": "BULLISH_OIL",
                          "score": 1.5, "summary": "crude draw surprise"},
        },
    }
    compact = svc._compact_market_payload(payload)
    assert compact["macro_direction"] is None
    assert compact["oil_macro"]["direction"] == "BUY"


def test_review_signal_persona_names_the_symbol(monkeypatch):
    svc = _gemini()
    prompts = []

    class _Resp:
        status_code = 200
        text = json.dumps({"candidates": [{"content": {"parts": [{"text": json.dumps(
            {"verdict": "WAIT", "confidence": 50, "reason": "x",
             "macro_alignment": "NEUTRAL", "risk_level": "MEDIUM",
             "invalidation": "y"})}]}}]})
        headers = {}

        def json(self):
            return json.loads(self.text)

    class _Sess:
        def post(self, url, params=None, json=None, timeout=None):
            prompts.append(json.get("contents")[0]["parts"][0]["text"])
            return _Resp()

    monkeypatch.setattr(svc, "session", _Sess())
    svc.review_signal({"symbol": "WTI/USD",
                       "decision": {"symbol": "WTI/USD", "decision": "BUY", "signal": {}},
                       "all_results": {}})
    assert "specialized in WTI/USD" in prompts[0]
    assert "XAU/USD" not in prompts[0]


# ── 3) Rule A lets the oil macro rescue its own all-trend book ─────────────
def test_r25_7f_all_trend_wti_book_refused_oil_macro_rescue_closed():
    """R25.7-F (operator 2026-08-28): paths 2/3 require TWO families, so
    the oil macro can no longer rescue its own all-trend book. Under the
    kill switch the BUILD 26 symbol-aware rescue returns unchanged."""
    details = _core_book(side="BUY", conf=75.0, symbol="WTI/USD",
                         oil_macro={"direction": "BUY", "confidence": 60.0})
    verdict = evaluate_directional_admission("BUY", details, _cfg("WTI/USD"), symbol="WTI/USD")
    assert verdict.get("allow") is False
    assert verdict.get("path23_single_family_refused") == ["trend"]

    import copy
    cfg = _cfg("WTI/USD")
    cfg["signal_requirements"]["family_diversity"][
        "path23_require_two_families"] = False
    verdict2 = evaluate_directional_admission(
        "BUY", copy.deepcopy(details), cfg, symbol="WTI/USD")
    assert verdict2.get("allow") is True
    assert verdict2.get("path") == "TWO_AGENT_OIL_MACRO"
    assert verdict2.get("confirm_source") == "oil_macro"


def test_all_trend_wti_book_still_refuses_auction_rescue():
    details = _core_book(side="BUY", conf=75.0, symbol="WTI/USD",
                         oil_macro={"direction": "WAIT", "confidence": 0.0},
                         auction_flow={"direction": "BUY", "confidence": 80.0})
    verdict = evaluate_directional_admission("BUY", details, _cfg("WTI/USD"), symbol="WTI/USD")
    # oil macro is silent and Rule B forbids auction rescues of trend books
    assert verdict.get("allow") is False


def test_r25_7f_all_trend_gold_book_rescues_closed_until_kill_switch():
    """R25.7-F: the law is symbol-independent — the gold all-trend book is
    refused on paths 2/3 even with macro/gemini (Rule A machinery and the
    R25.6-G2 list stay in config; the kill switch restores them)."""
    details = _core_book(side="BUY", conf=75.0, symbol="XAU/USD",
                         macro_fundamental={"direction": "BUY", "confidence": 60.0})
    verdict = evaluate_directional_admission("BUY", details, _cfg("XAU/USD"), symbol="XAU/USD")
    assert verdict.get("allow") is False
    assert verdict.get("path23_single_family_refused") == ["trend"]

    details2 = _core_book(side="BUY", conf=75.0, symbol="XAU/USD",
                          macro_fundamental={"direction": "WAIT", "confidence": 0.0},
                          gemini={"direction": "BUY", "confidence": 80.0, "available": True})
    verdict2 = evaluate_directional_admission("BUY", details2, _cfg("XAU/USD"), symbol="XAU/USD")
    assert verdict2.get("allow") is False

    import copy
    cfg = _cfg("XAU/USD")
    cfg["signal_requirements"]["family_diversity"][
        "path23_require_two_families"] = False
    verdict3 = evaluate_directional_admission(
        "BUY", copy.deepcopy(details), cfg, symbol="XAU/USD")
    assert verdict3.get("allow") is True
    assert verdict3.get("path") == "TWO_AGENT_MACRO"
    verdict4 = evaluate_directional_admission(
        "BUY", copy.deepcopy(details2), cfg, symbol="XAU/USD")
    assert verdict4.get("allow") is True
    assert verdict4.get("path") == "TWO_AGENT_GEMINI"
