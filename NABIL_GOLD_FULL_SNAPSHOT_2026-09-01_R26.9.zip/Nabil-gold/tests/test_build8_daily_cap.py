"""2026-08-19 build 8: daily-cap lifecycle + phantom handling + visibility."""
from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from services.mt5_executor import Mt5DemoExecutor  # noqa: E402
from scripts.run_trade_updates import (  # noqa: E402
    _cap_refusal,
    _is_market_entry,
)
from scripts.system_healthcheck import _execution_gate_status  # noqa: E402


class TestDailyCapReset:
    def _executor(self, monkeypatch, orders=7, date="2026-08-18"):
        ex = Mt5DemoExecutor({}, telegram=None)
        ex._orders_today = orders
        ex._orders_today_date = date
        return ex

    def test_resets_at_new_utc_day(self):
        ex = Mt5DemoExecutor({}, telegram=None)
        ex._orders_today = 7
        ex._orders_today_date = "2026-08-18"
        ex._reset_if_new_day(datetime(2026, 8, 19, 0, 5, tzinfo=timezone.utc))
        assert ex._orders_today == 0
        assert ex._orders_today_date == "2026-08-19"

    def test_keeps_count_same_day(self):
        ex = Mt5DemoExecutor({}, telegram=None)
        ex._orders_today = 7
        ex._orders_today_date = "2026-08-19"
        ex._reset_if_new_day(datetime(2026, 8, 19, 23, 50, tzinfo=timezone.utc))
        assert ex._orders_today == 7

    def test_ensure_ticket_calls_reset_before_checks(self, monkeypatch, tmp_path):
        # prove ordering: ensure_ticket resets the daily counter FIRST, then
        # evaluates the halt gate (halting here short-circuits before MT5)
        import services.mt5_executor as m5

        monkeypatch.setattr(m5, "HALT_FILE", str(tmp_path / ".demo_halt"))
        ex = Mt5DemoExecutor({}, telegram=None)
        ex._orders_today = 6
        ex._orders_today_date = "2026-08-18"
        calls = {}

        def _record_reset(now=None):
            calls["reset"] = True
            ex._orders_today = 0
            ex._orders_today_date = "2026-08-19"

        monkeypatch.setattr(ex, "_reset_if_new_day", _record_reset)
        monkeypatch.setattr(ex, "halted", lambda: True)  # short-circuit after reset
        ex.ensure_ticket("TRADE_CAP", "BUY", "BUY_MARKET", 4300.0, 4290.0, 4320.0, "XAU/USD")
        assert calls.get("reset") is True  # reset ran before the halt gate
        assert "halted" in ex.last_error


class TestCapPhantomHelpers:
    def test_cap_refusal_detected(self):
        assert _cap_refusal("daily order cap reached") is True
        assert _cap_refusal("executor halted (.demo_halt)") is False
        assert _cap_refusal("") is False

    def test_market_entry_detected(self):
        assert _is_market_entry({"order_type": "BUY_MARKET"}) is True
        assert _is_market_entry({"order_kind": "MARKET"}) is True
        assert _is_market_entry({"order_type": "BUY_LIMIT"}) is False
        assert _is_market_entry({}) is False


class TestExecutionGateStatus:
    def test_clean_root(self, tmp_path):
        exists, reason, refusals = _execution_gate_status(tmp_path)
        assert exists is False
        assert refusals == 0

    def test_halt_detected(self, tmp_path):
        (tmp_path / ".demo_halt").write_text("REAL MT5 account refused", encoding="utf-8")
        exists, reason, _ = _execution_gate_status(tmp_path)
        assert exists is True
        assert "REAL" in reason

    def test_refusals_counted_from_tail(self, tmp_path):
        logs = tmp_path / "logs"
        logs.mkdir(parents=True)
        (logs / "tick_manager.log").write_text(
            "WARNING: Demo order refused: daily cap reached\n" * 5
            + "INFO: something else\n",
            encoding="utf-8",
        )
        _, _, refusals = _execution_gate_status(tmp_path)
        assert refusals == 5
