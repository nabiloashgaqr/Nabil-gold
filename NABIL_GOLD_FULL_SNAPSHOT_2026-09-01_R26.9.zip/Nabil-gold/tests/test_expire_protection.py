"""BUILD 29 (2026-08-22, operator order): time-expiry of OPEN trades is
REMOVED from the code.

Before: an open trade that outlived trade_management.expire_after_hours was
force-closed at market (status EXPIRED) - except protected winners. The
operator decided the clock must not outrank the trade's own exit rules: an
open trade now runs until TP1/TP2, (trailing) stop loss, thesis exit, or
manual close. The config keys are no longer read at all (even an explicit
expire_after_hours=24 does nothing).

Kept on purpose: PENDING orders still hard-expire after
pending_expire_after_hours (a stale UNFILLED order never entered the
market - a different risk). The EXPIRED status itself stays alive for that
path; reports/metrics already handle it.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from agents.open_trades_manager import OpenTradesManager


def _mgr(**mgmt):
    cfg = {
        "trade_management": {"time_warning_hours": 999, **mgmt},
        "trailing_stop": {"enabled": True, "trailing_distance": 100.0, "trailing_step": 5.0,
                          "early_breakeven_points": 100.0, "min_profit_lock": 0.0},
    }
    return OpenTradesManager(cfg)


def _old_trade(**over):
    now = datetime.now(timezone.utc)
    opened = (now - timedelta(hours=30)).isoformat()
    t = {"id": "T", "type": "SELL", "status": "OPEN", "entry_price": 4130.14,
         "stop_loss": 4150.14, "tp1": 4103.47, "tp2": 4083.47,
         "sl_moved_to_entry": False, "updates_sent": [], "entry_time": opened, "created_at": opened}
    t.update(over)
    return t, now


def test_losing_trade_30h_old_is_not_time_expired() -> None:
    """The legacy case: a 30h-old losing OPEN trade used to be EXPIRED at
    market. Now it stays OPEN for its stop / thesis to decide."""
    manager = _mgr()
    trade, now = _old_trade()
    result = manager.evaluate_trade(trade, 4140.0, now=now)
    assert result["new_status"] != "EXPIRED"
    assert "EXPIRED" not in result["events"]


def test_protected_winner_30h_old_is_not_time_expired() -> None:
    manager = _mgr()
    trade, now = _old_trade(sl_moved_to_entry=True, stop_loss=4130.14)
    result = manager.evaluate_trade(trade, 4120.0, now=now)
    assert result["new_status"] != "EXPIRED"
    assert "EXPIRED" not in result["events"]


def test_explicit_config_key_is_ignored() -> None:
    """Hard removal, not a default flip: even an explicit
    expire_after_hours=24 can no longer close an open trade."""
    manager = _mgr(expire_after_hours=24, keep_protected_winners_open=False)
    trade, now = _old_trade()
    result = manager.evaluate_trade(trade, 4140.0, now=now)
    assert result["new_status"] != "EXPIRED"
    assert "EXPIRED" not in result["events"]


def test_pending_still_expires() -> None:
    """The KEPT rule: a stale UNFILLED pending order still hard-expires
    (pending_expire_after_hours) - this is not an open trade."""
    manager = OpenTradesManager({
        "order_execution": {"entry_style": "hybrid", "pending_expire_after_hours": 4,
                            "pending_order_max_cycles": 99},
    })
    trade = {"id": "TRADE_TEST_P", "type": "SELL", "entry_price": 2360.0,
             "entry_time": (datetime.now(timezone.utc) - timedelta(hours=5)).isoformat(),
             "created_at": (datetime.now(timezone.utc) - timedelta(hours=5)).isoformat(),
             "stop_loss": 2366.0, "tp1": 2354.0, "tp2": 2348.0,
             "status": "PENDING", "current_price": 2352.0, "current_pnl": 0,
             "sl_moved_to_entry": False, "partial_close": False,
             "updates_sent": [], "order_type": "SELL_LIMIT"}
    result = manager.evaluate_trade(trade, 2352.0, candle_high=2354.0, candle_low=2350.0)
    assert result["new_status"] == "EXPIRED"
    assert result["events"] == ["EXPIRED"]
