"""Rules A & B: who may rescue an all-trend book, and who may not.

Measured basis (agent_correlation_report, 740 cycles to 2026-08-17 14:26):

  * single-family (all-trend) books: 20% hit at +2h vs 47% for mixed books;
  * the four auction rescues of pure-trend books went 0/4 at BOTH horizons —
    worse than the unrescued books themselves (23%). Flow strength at a
    momentum extreme is a consequence of the very move the trend agents
    voted on: momentum confirming momentum.

Rule A — a demoted ALL-TREND book (>= min_agents supporters, all of
technical/multitimeframe/classical) may only enter through the confirmers
in family_diversity.single_family_confirmers (default: macro, the one voice
whose inputs are independent of the last hour of price action).

Rule B — Path 5's auction confirmation requires the two-agent pair to
include at least one structure agent. technical+multitimeframe agree 94.9%
of the time; auction stacked on that pair is the trend block wearing a
third hat.
"""

from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.thesis_consensus import (
    _all_trend_supporters,
    _single_family_confirmers,
    evaluate_directional_admission,
)


def _config(confirmers=None, rule_b=True, enabled=True):
    return {
        "agent_weights": {
            "classical": 0.25, "technical": 0.20, "smc": 0.20,
            "price_action": 0.20, "multitimeframe": 0.15,
        },
        "signal_requirements": {
            "min_agents_agree": 3,
            "min_consensus_confidence": 65,
            "agent_min_confidence": 65,
            "family_diversity": {
                "enabled": enabled,
                "families": {
                    "trend": ["technical", "multitimeframe", "classical"],
                    "structure": ["smc", "price_action"],
                },
                "single_family_confirmers": (
                    ["macro"] if confirmers is None else confirmers),
            },
            "two_agent_entry": {
                "enabled": True, "min_agents_agree": 2,
                "min_consensus_confidence": 65,
                "macro_confirmation": {"enabled": True, "min_confidence": 55},
                "gemini_confirmation": {"enabled": True, "min_confidence": 70},
            },
            "path5_two_agent_auction": {
                "enabled": True, "min_agents_agree": 2,
                "min_consensus_confidence": 65, "min_auction_confidence": 65,
                "require_family_diversity": rule_b,
            },
        },
    }


def _all_trend_book(side="BUY"):
    return {
        "technical": {"signal": side, "confidence": 70},
        "multitimeframe": {"signal": side, "confidence": 92},
        "classical": {"signal": side, "confidence": 68},
        "smc": {"signal": "WAIT", "confidence": 30},
        "price_action": {"signal": "WAIT", "confidence": 45},
    }


def _trend_pair(side="BUY"):
    return {
        "technical": {"signal": side, "confidence": 75},
        "multitimeframe": {"signal": side, "confidence": 88},
        "classical": {"signal": "WAIT", "confidence": 40},
        "smc": {"signal": "WAIT", "confidence": 30},
        "price_action": {"signal": "WAIT", "confidence": 45},
    }


def _mixed_pair(side="BUY"):
    return {
        "technical": {"signal": side, "confidence": 75},
        "smc": {"signal": side, "confidence": 70},
        "classical": {"signal": "WAIT", "confidence": 40},
        "multitimeframe": {"signal": "WAIT", "confidence": 35},
        "price_action": {"signal": "WAIT", "confidence": 45},
    }


# ── Rule A: the all-trend book and its confirmers ───────────────────────────

def test_r25_7f_macro_no_longer_rescues_a_single_family_book():
    """R25.7-F (operator 2026-08-28): paths 2/3 need TWO families among the
    qualified supporters — the confirmer ladder runs after that gate, so
    Rule A's rescue of a single-family book is closed (superseded)."""
    details = _all_trend_book("BUY")
    details["macro_fundamental"] = {"direction": "BUY", "confidence": 60}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is False
    assert admission["path23_single_family_refused"] == ["trend"]


def test_r25_7f_kill_switch_restores_the_macro_rescue():
    details = _all_trend_book("BUY")
    details["macro_fundamental"] = {"direction": "BUY", "confidence": 60}
    cfg = _config()
    cfg["signal_requirements"]["family_diversity"][
        "path23_require_two_families"] = False
    admission = evaluate_directional_admission("BUY", details, cfg)
    assert admission["allow"] is True
    assert admission["path"] == "TWO_AGENT_MACRO"


def test_auction_no_longer_rescues_an_all_trend_book():
    """The 0/4 rescue channel is closed."""
    details = _all_trend_book("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 85}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is False
    assert "family" in str(admission.get("reason", "")).lower()


def test_gemini_no_longer_rescues_an_all_trend_book_by_default():
    details = _all_trend_book("BUY")
    details["gemini"] = {"direction": "BUY", "confidence": 90, "available": True}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is False


def test_the_confirmer_list_is_config_not_code():
    """Adding 'gemini' to the list widens Rule A without a patch. Since
    R25.7-F the rescue itself needs the kill switch (paths 2/3 demand two
    families), so this pins the config-driven list UNDER that switch."""
    details = _all_trend_book("BUY")
    details["gemini"] = {"direction": "BUY", "confidence": 90, "available": True}
    cfg = _config(confirmers=["macro", "gemini"])
    cfg["signal_requirements"]["family_diversity"][
        "path23_require_two_families"] = False
    admission = evaluate_directional_admission("BUY", details, cfg)
    assert admission["allow"] is True
    assert admission["path"] == "TWO_AGENT_GEMINI"


def test_r25_7f_single_family_refusal_names_the_families():
    """R25.7-F: the single-family book is refused at the family gate before
    any confirmer is consulted — the refusal names the family seen."""
    details = _all_trend_book("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 85}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is False
    assert admission["path23_single_family_refused"] == ["trend"]


# ── Rule B: the all-trend pair and auction ──────────────────────────────────

def test_auction_refuses_an_all_trend_pair():
    details = _trend_pair("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 85}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is False
    assert "trend" in str(admission.get("reason", "")).lower()


def test_auction_confirms_a_mixed_pair_as_before():
    details = _mixed_pair("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 85}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is True
    assert admission["path"] == "TWO_AGENT_AUCTION"


def test_r25_7f_trend_pair_refused_but_mixed_pair_admitted():
    """R25.7-F: a same-family trend pair + macro is REFUSED on path 2 (the
    live EUR/USD 2026-08-28 card shape); a mixed-family pair + macro still
    enters as before."""
    details = _trend_pair("BUY")
    details["macro_fundamental"] = {"direction": "BUY", "confidence": 60}
    admission = evaluate_directional_admission("BUY", details, _config())
    assert admission["allow"] is False
    assert admission["path23_single_family_refused"] == ["trend"]

    mixed = _mixed_pair("BUY")
    mixed["macro_fundamental"] = {"direction": "BUY", "confidence": 60}
    admission = evaluate_directional_admission("BUY", mixed, _config())
    assert admission["allow"] is True
    assert admission["path"] == "TWO_AGENT_MACRO"


def test_rule_b_kill_switch():
    details = _trend_pair("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 85}
    admission = evaluate_directional_admission("BUY", details, _config(rule_b=False))
    assert admission["allow"] is True
    assert admission["path"] == "TWO_AGENT_AUCTION"


def test_both_rules_idle_when_family_gate_is_off():
    details = _all_trend_book("BUY")
    details["auction_flow"] = {"signal": "BUY", "confidence": 85}
    admission = evaluate_directional_admission("BUY", details, _config(enabled=False))
    assert admission["allow"] is True, "disabling the gate restores pre-gate behaviour"


# ── helpers ─────────────────────────────────────────────────────────────────

def test_all_trend_supporters_helper():
    cfg = _config()
    assert _all_trend_supporters(["technical", "classical"], cfg) is True
    assert _all_trend_supporters(["technical", "smc"], cfg) is False
    assert _all_trend_supporters([], cfg) is False


def test_default_confirmers_are_macro_only():
    assert _single_family_confirmers(_config()) == ["macro"]


def test_live_wiring_in_run_analysis():
    """VPS fix 2026-08-28: resolve via ROOT — the bat runs pytest from the
    EXTRACTED folder, so a CWD-relative path breaks there (the deployed
    round itself was fine; only this fragile open() failed, 107/108)."""
    src = (ROOT / "scripts" / "run_analysis.py").read_text(encoding="utf-8")
    assert "auction cannot confirm momentum with momentum" in src   # Rule B log
    assert "Rule A: demoted all-trend book" in src                  # Rule A log
    assert "_all_trend_supporters" in src


def test_shipped_config_carries_both_rules():
    import json
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    fd = cfg["signal_requirements"]["family_diversity"]
    # R25.6-G2 (operator 2026-08-28): gemini joined macro as an allowed
    # single-family confirmer.
    assert fd["single_family_confirmers"] == ["macro", "gemini"]
    assert cfg["signal_requirements"]["path5_two_agent_auction"]["require_family_diversity"] is True
    # R25.7-F (operator 2026-08-28): paths 2/3 require TWO families.
    assert fd["path23_require_two_families"] is True
