"""The correlation report's core math must be right before we trust it.

The family-diversity gate was turned on from the operator's read of one
live incident; the report is the instrument that will confirm or refute it
with history. An instrument with broken math is worse than none.
"""

from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from scripts.agent_correlation_report import _hit, _votes


def test_votes_applies_the_bar_and_drops_waits():
    row = {"agents": {
        "technical": {"direction": "BUY", "confidence": 70},
        "multitimeframe": {"direction": "BUY", "confidence": 64.9},  # below bar
        "classical": {"direction": "WAIT", "confidence": 90},        # not directional
        "smc": {"direction": "SELL", "confidence": 65},              # exactly at bar
    }}
    v = _votes(row, 65.0)
    assert set(v) == {"technical", "smc"}
    assert v["technical"] == ("BUY", 70)
    assert v["smc"] == ("SELL", 65)


def test_hit_is_directional_and_none_safe():
    assert _hit("BUY", 5.0) is True
    assert _hit("BUY", -5.0) is False
    assert _hit("SELL", -5.0) is True
    assert _hit("SELL", 5.0) is False
    assert _hit("BUY", None) is None


def test_families_cover_all_five_voters():
    from services.thesis_consensus import DEFAULT_AGENT_FAMILIES, VOTING_AGENTS
    assert set(DEFAULT_AGENT_FAMILIES) == set(VOTING_AGENTS)
    assert set(DEFAULT_AGENT_FAMILIES.values()) == {"trend", "structure"}


# ── section 4: the family-gate replay must mirror the live rescue order ─────

from scripts.agent_correlation_report import _rescue_source


def _blocked_row(macro_bias="", macro_conf=0.0, auction_dir="WAIT", auction_conf=0.0):
    return {
        "macro": {"bias": macro_bias, "confidence": macro_conf},
        "agents": {"auction_flow": {"direction": auction_dir, "confidence": auction_conf}},
    }


def test_macro_rescues_a_blocked_buy_book():
    row = _blocked_row(macro_bias="BULLISH_GOLD", macro_conf=60)
    assert _rescue_source(row, "BUY", 55, 65) == "macro"


def test_macro_against_the_side_does_not_rescue():
    """The 11:06 case: trend book BUY, macro BEARISH_GOLD 68 — no rescue."""
    row = _blocked_row(macro_bias="BEARISH_GOLD", macro_conf=68,
                       auction_dir="WAIT", auction_conf=50)
    assert _rescue_source(row, "BUY", 55, 65) is None


def test_auction_rescues_when_macro_is_silent():
    row = _blocked_row(auction_dir="SELL", auction_conf=72)
    assert _rescue_source(row, "SELL", 55, 65) == "auction"


def test_macro_outranks_auction_like_the_live_path_order():
    row = _blocked_row(macro_bias="BULLISH_GOLD", macro_conf=60,
                       auction_dir="BUY", auction_conf=80)
    assert _rescue_source(row, "BUY", 55, 65) == "macro"


def test_confirmer_floors_are_honoured():
    assert _rescue_source(_blocked_row(macro_bias="BULLISH_GOLD", macro_conf=54.9),
                          "BUY", 55, 65) is None
    assert _rescue_source(_blocked_row(auction_dir="BUY", auction_conf=64.9),
                          "BUY", 55, 65) is None


def test_measurement_rows_now_carry_the_macro_field():
    """Section 4 replays macro from the stored row; the writer must store it."""
    import io
    src = io.open("services/agent_measurement.py", encoding="utf-8").read()
    assert '"macro": {' in src
    assert "macro_direction" in src
