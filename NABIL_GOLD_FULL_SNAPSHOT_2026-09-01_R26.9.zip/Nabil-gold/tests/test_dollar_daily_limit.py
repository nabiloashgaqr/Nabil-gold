"""2026-08-19 upgrade tests: dollar-based daily loss limit + dynamic risk wiring."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from services.dynamic_risk import DynamicRiskManager  # noqa: E402
from services.risk_analytics import dollar_daily_limit  # noqa: E402


class TestDollarDailyLimit:
    def test_disabled_when_percent_not_set(self):
        r = dollar_daily_limit([], {"risk_settings": {"account_capital": 10000}})
        assert r["mode"] == "DISABLED"

    def test_halt_when_dollar_loss_exceeds_limit(self):
        cfg = {"risk_settings": {"account_capital": 10000, "max_daily_loss_percent": 3.0}}
        trades = [{"symbol": "XAU/USD", "final_pnl_usd": -350.0}]
        r = dollar_daily_limit(trades, cfg)
        assert r["mode"] == "DOLLARS"
        assert r["level"] == "HALT"
        assert r["limit_dollars"] == 300.0

    def test_points_and_lots_conversion_gold(self):
        cfg = {"risk_settings": {"account_capital": 10000, "max_daily_loss_percent": 3.0}}
        # gold: 400 points loss × $10/point × 0.05 lots = -$200 (STRICT band)
        trades = [{"symbol": "XAU/USD", "final_pnl": -400.0, "lots": 0.05}]
        r = dollar_daily_limit(trades, cfg)
        assert r["level"] == "STRICT"  # -200 <= -50% of 300
        assert r["daily_pnl_usd"] == -200.0

    def test_unpriced_trades_skipped_never_guessed(self):
        cfg = {"risk_settings": {"account_capital": 10000, "max_daily_loss_percent": 3.0}}
        trades = [{"symbol": "XAU/USD", "final_pnl": -400.0}]  # no lots, no usd
        r = dollar_daily_limit(trades, cfg)
        assert r["priced_trades"] == 0
        assert r["unpriced_trades"] == 1
        assert r["level"] == "NORMAL"


class FakeDB:
    def __init__(self, today_trades):
        self._today = today_trades

    def get_consecutive_losses(self):
        return 0

    def get_today_trades(self):
        return self._today

    def get_recent_trades(self, limit=20):
        return self._today


class TestDynamicRiskDollarWiring:
    def test_dollar_halt_sets_daily_halt_usd(self):
        cfg = {
            "risk_settings": {"account_capital": 10000, "max_daily_loss_percent": 3.0},
            "dynamic_risk_management": {"daily_loss_limit_points": 450, "halt_after_losses": 3},
        }
        db = FakeDB([{"symbol": "XAU/USD", "status": "SL_HIT", "final_pnl_usd": -400.0}])
        verdict = DynamicRiskManager(cfg).evaluate(db)
        assert verdict["level"] == "DAILY_HALT_USD"
        assert verdict["can_trade"] is False
        assert verdict["dollar_limit"]["mode"] == "DOLLARS"

    def test_no_percent_keeps_legacy_behaviour(self):
        cfg = {
            "risk_settings": {"account_capital": 10000},
            "dynamic_risk_management": {"daily_loss_limit_points": 450, "halt_after_losses": 3},
        }
        db = FakeDB([{"symbol": "XAU/USD", "status": "SL_HIT", "final_pnl": -500.0}])
        verdict = DynamicRiskManager(cfg).evaluate(db)
        assert verdict["level"] == "DAILY_HALT"  # legacy points path untouched
        assert verdict["dollar_limit"]["mode"] == "DISABLED"
