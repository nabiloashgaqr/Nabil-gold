"""2026-08-19: map support report (ready maps + agent supporters)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def _fixture(root: Path) -> None:
    storage = root / "storage"
    (storage / "agent_measurements").mkdir(parents=True, exist_ok=True)
    plans = [
        {
            "id": "PLAN_READY_BUY_1",
            "created_at": "2026-08-19T09:05:00+03:00",
            "analysis_run_at": "2026-08-19T09:05:00+03:00",
            "payload": {
                "plan_ready": True, "plan_status": "READY", "session_bias": "BUY",
                "planner_confidence": 74.0, "structure_quality": "STRONG",
                "primary_poi": {"thesis_dominance_score": 78, "return_probability_score": 61,
                                "quality_score": 76.5, "trigger_score": 72,
                                "setup_type": "DEMAND_OB", "setup_state": "ARMED"},
                "agent_opinions": [
                    {"key": "technical", "direction": "BUY", "confidence": 78},
                    {"key": "multitimeframe", "direction": "BUY", "confidence": 74},
                    {"key": "smc", "direction": "BUY", "confidence": 71},
                    {"key": "classical", "direction": "BUY", "confidence": 66},
                    {"key": "price_action", "direction": "SELL", "confidence": 41},
                ],
                "macro_plan": {"direction": "BUY", "confidence": 58},
            },
        },
        {
            "id": "PLAN_NOTREADY_3",
            "created_at": "2026-08-19T16:20:00+03:00",
            "analysis_run_at": "2026-08-19T16:20:00+03:00",
            "payload": {
                "plan_ready": False, "plan_status": "NOT_READY",
                "plan_reason": "quality 61 < floor 70", "session_bias": "BUY",
                "primary_poi": {"thesis_dominance_score": 58, "return_probability_score": 44,
                                "quality_score": 61.0, "trigger_score": 45},
                "agent_opinions": [
                    {"key": "technical", "direction": "BUY", "confidence": 73},
                    {"key": "multitimeframe", "direction": "BUY", "confidence": 70},
                ],
            },
        },
    ]
    (storage / "session_plans.json").write_text(json.dumps(plans), encoding="utf-8")
    rows = [{
        "generated_at": "2026-08-19T09:05:00+00:00",
        "snapshot_id": "PLAN_READY_BUY_1",
        "decision": "BUY",
        "agents": {
            "technical": {"direction": "BUY", "confidence": 78, "qualified": True},
            "multitimeframe": {"direction": "BUY", "confidence": 74, "qualified": True},
            "classical": {"direction": "BUY", "confidence": 66, "qualified": True},
            "smc": {"direction": "BUY", "confidence": 71, "qualified": True},
            "price_action": {"direction": "SELL", "confidence": 41, "qualified": False},
            "auction_flow": {"direction": "BUY", "confidence": 64, "qualified": False},
        },
        "macro": {"bias": "BULLISH_GOLD", "confidence": 58},
        "auction_measurement": {"state": "ACCEPTING", "confidence": 64},
        "map": {"ready": True, "status": "READY", "side": "BUY"},
        "smc_measurement": {"dominance": 78, "return_probability": 61, "quality": 76.5,
                            "trigger_score": 72, "setup_type": "DEMAND_OB", "setup_state": "ARMED"},
        "admission": {
            "BUY": {"allow": True, "path": "THREE_AGENT_CONSENSUS", "confidence": 68.4,
                    "supporters": ["technical", "multitimeframe", "classical", "smc"],
                    "opponents": []},
            "SELL": {"allow": False, "path": None, "confidence": 0.0,
                     "supporters": [], "opponents": []},
        },
    }]
    (storage / "agent_measurements" / "agent_system_2026-08-19.jsonl").write_text(
        "\n".join(json.dumps(r) for r in rows), encoding="utf-8")


class TestMapSupportReport:
    def test_ready_map_with_supporters(self, tmp_path, capsys):
        import scripts.map_support_report as msr

        _fixture(tmp_path)
        rc = msr.main.__wrapped__ if hasattr(msr.main, "__wrapped__") else None
        import subprocess

        out = subprocess.run(
            [sys.executable, str(Path(msr.__file__).resolve().parent / "map_support_report.py"),
             "--root", str(tmp_path), "--date", "2026-08-19"],
            capture_output=True, text=True, timeout=120,
        )
        assert out.returncode == 0, out.stderr
        assert "UNIQUE READY MAPS" in out.stdout  # collapsed view
        assert "READY CYCLES: 1" in out.stdout
        assert "technical" in out.stdout and "SUPPORTS" in out.stdout
        assert "auction_flow" in out.stdout
        assert "quality 61 < floor 70" in out.stdout  # refused map reason listed
        json_path = tmp_path / "diagnostics" / "map_support_report_2026-08-19.json"
        assert json_path.exists()
        data = json.loads(json_path.read_text(encoding="utf-8"))
        assert data["ready_count"] == 1
        assert data["reports"][0]["agents"][0]["role"] == "SUPPORTS"

    def test_no_data_graceful(self, tmp_path):
        import subprocess
        from pathlib import Path as P

        script = P(__file__).resolve().parents[1] / "scripts" / "map_support_report.py"
        (tmp_path / "storage").mkdir(parents=True, exist_ok=True)
        out = subprocess.run(
            [sys.executable, str(script), "--root", str(tmp_path), "--date", "2026-08-19"],
            capture_output=True, text=True, timeout=120,
        )
        assert out.returncode == 1
        assert "No session-plan or measurement rows" in out.stdout
