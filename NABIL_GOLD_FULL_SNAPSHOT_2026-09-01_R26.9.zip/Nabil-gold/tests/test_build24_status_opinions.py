"""BUILD 24 (2026-08-21): macro + Gemini opinions on the hourly status card.

BUILD 28 R2 (2026-08-22, operator order) re-pins the Gemini part:
  * the stored opinion is at most 30 minutes old (``stored_opinion_hours``);
  * the hourly status update fetches a NEW opinion whenever the stored one
    is older than the 30-minute TTL - the old even-UTC-hours gate is gone,
    it runs the whole trading week;
  * trade entries force a fresh opinion (run_tick_manager, force=True);
  * every other display reads the store only (no extra API call);
  * same model chain as before; failed refreshes never hammer the quota.
Macro lines stay LOCAL (no API cost).
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

import pytest

import scripts.run_analysis as ra
from services import llm_review as lr


def _cfg(tmp_path) -> dict:
    return {
        "symbol": "XAU/USD",
        "llm_review": {
            "status_cache_path": str(tmp_path / "gemini_status_cache.json"),
            "stored_opinion_hours": 0.5,
        },
    }


def _now(hour: int, minute: int = 0) -> datetime:
    return datetime(2026, 8, 21, hour, minute, tzinfo=timezone.utc)


def _verdict(bias="BULLISH", action="BUY", reason="DXY softening supports gold"):
    return {"bias": bias, "action": action, "reason": reason, "model": "gemini-3.5-flash-lite"}


# ── macro line (local, no network) ─────────────────────────────────────────
def test_macro_line_from_all_results():
    all_results = {"macro_fundamental": {
        "macro_direction": {"bias": "BULLISH_GOLD", "confidence": 61.0,
                            "summary": "Weaker USD supports gold"}}}
    line = ra._status_macro_line(all_results, {}, None)
    assert "Macro:" in line
    assert "Bullish Gold 61%" in line
    assert "Weaker USD supports gold" in line


def test_macro_line_missing_context_falls_back_to_database(monkeypatch):
    ctx = {"dxy_trend": "falling", "us10y_trend": "rising"}
    db = type("DB", (), {"get_macro_context": lambda self: ctx})()
    line = ra._status_macro_line({"macro_fundamental": {}}, {}, db)
    # a local computation ran; the line exists only if a bias resolves
    assert isinstance(line, str)
    assert line == "" or "Macro:" in line


def test_macro_line_no_bias_is_empty():
    assert ra._status_macro_line({}, {}, None) == ""
    assert ra._status_macro_line({"macro_fundamental": {}}, {}, None) == ""


# ── gemini stored-opinion store (30-min TTL, any hour) ─────────────────────
def test_fresh_cache_is_used_without_any_call(tmp_path, monkeypatch):
    """A verdict stored 10 minutes ago is fresh (30-min TTL): display it,
    do not touch the API."""
    cfg = _cfg(tmp_path)
    cache = tmp_path / "gemini_status_cache.json"
    gen = (_now(10, 20) - timedelta(minutes=10)).isoformat()
    cache.write_text(json.dumps({"XAU/USD": {"verdict": _verdict(),
                                             "generated_at": gen,
                                             "last_attempt_at": gen}}),
                     encoding="utf-8")

    def _boom(*a, **k):
        raise AssertionError("the API must not be called when the store is fresh")

    monkeypatch.setattr(lr, "get_gemini_review_service", _boom)
    line = ra._status_gemini_line(cfg, {}, "XAU/USD", now=_now(10, 20))
    assert "Gemini XAU/USD:" in line
    assert "BULLISH" in line
    assert "(BUY)" in line
    assert "(stored 0.2h)" in line


def test_stale_cache_refreshes_on_an_odd_hour(tmp_path, monkeypatch):
    """BUILD 28 R2: the even-hour gate is gone - a 3h-old stored verdict is
    refreshed at 11:30, not only on even hours."""
    cfg = _cfg(tmp_path)
    cache = tmp_path / "gemini_status_cache.json"
    old_gen = (_now(8) - timedelta(hours=3)).isoformat()
    cache.write_text(json.dumps({"XAU/USD": {
        "verdict": _verdict(), "generated_at": old_gen,
        "last_attempt_at": old_gen}}), encoding="utf-8")

    class _Gem:
        enabled = True
        model = "gemini-3.5-flash-lite"

        def analyze_market_context(self, payload):
            return {"available": True, "suppressed": False,
                    "market_bias": "NEUTRAL", "action": "WAIT",
                    "reason": "macro mixed, range-bound"}

    monkeypatch.setattr(lr, "get_gemini_review_service", lambda cfg: _Gem())
    line = ra._status_gemini_line(cfg, {}, "XAU/USD", now=_now(11, 30))
    assert "NEUTRAL" in line
    assert "(stored" not in line  # just refreshed, not a stored read
    stored = json.loads(cache.read_text(encoding="utf-8"))
    assert stored["XAU/USD"]["verdict"]["bias"] == "NEUTRAL"


def test_stale_cache_refreshes_and_stores(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    cache = tmp_path / "gemini_status_cache.json"
    old_gen = (_now(8) - timedelta(hours=3)).isoformat()
    cache.write_text(json.dumps({"XAU/USD": {
        "verdict": _verdict(), "generated_at": old_gen,
        "last_attempt_at": old_gen}}), encoding="utf-8")

    calls = []

    class _Gem:
        enabled = True
        model = "gemini-3.5-flash-lite"

        def analyze_market_context(self, payload):
            calls.append(payload)
            return {"available": True, "suppressed": False,
                    "market_bias": "NEUTRAL", "action": "WAIT",
                    "reason": "macro mixed, range-bound"}

    monkeypatch.setattr(lr, "get_gemini_review_service", lambda cfg: _Gem())
    line = ra._status_gemini_line(cfg, {"current_price": 4600.0}, "XAU/USD",
                                  now=_now(12))
    assert len(calls) == 1
    assert "NEUTRAL" in line
    assert "(stored" not in line  # live verdict, not a stored one
    stored = json.loads(cache.read_text(encoding="utf-8"))
    assert stored["XAU/USD"]["verdict"]["bias"] == "NEUTRAL"
    assert stored["XAU/USD"]["verdict"]["model"] == "gemini-3.5-flash-lite"


def test_failed_refresh_keeps_stored_verdict_and_marks_attempt(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    cache = tmp_path / "gemini_status_cache.json"
    old_gen = (_now(8) - timedelta(hours=3)).isoformat()
    cache.write_text(json.dumps({"XAU/USD": {
        "verdict": _verdict(), "generated_at": old_gen,
        "last_attempt_at": old_gen}}), encoding="utf-8")

    class _Gem:
        enabled = True

        def analyze_market_context(self, payload):
            raise RuntimeError("network down")

    monkeypatch.setattr(lr, "get_gemini_review_service", lambda cfg: _Gem())
    line = ra._status_gemini_line(cfg, {}, "XAU/USD", now=_now(12))
    # stored verdict survives the failed refresh
    assert "BULLISH" in line
    assert "(stored 7.0h)" in line
    stored = json.loads(cache.read_text(encoding="utf-8"))
    entry = stored.get("XAU/USD") or stored  # legacy or keyed format
    assert entry["last_attempt_at"]
    assert entry["verdict"]["bias"] == "BULLISH"
    # a second call inside the 30-minute window is skipped entirely
    def _boom(*a, **k):
        raise AssertionError("must not retry inside the same window")

    monkeypatch.setattr(lr, "get_gemini_review_service", _boom)
    line2 = ra._status_gemini_line(cfg, {}, "XAU/USD", now=_now(12, 15))
    assert "BULLISH" in line2


def test_gemini_disabled_shows_stored_only(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    cache = tmp_path / "gemini_status_cache.json"
    old_gen = (_now(8) - timedelta(hours=3)).isoformat()
    cache.write_text(json.dumps({"XAU/USD": {
        "verdict": _verdict(), "generated_at": old_gen,
        "last_attempt_at": old_gen}}), encoding="utf-8")

    class _Gem:
        enabled = False

    monkeypatch.setattr(lr, "get_gemini_review_service", lambda cfg: _Gem())
    line = ra._status_gemini_line(cfg, {}, "XAU/USD", now=_now(12))
    assert "BULLISH" in line


def test_no_cache_and_disabled_gemini_gives_no_line(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)

    def _boom(*a, **k):
        raise AssertionError("disabled gemini must not call the API")

    monkeypatch.setattr(lr, "get_gemini_review_service", _boom)
    assert ra._status_gemini_line(cfg, {}, "XAU/USD", now=_now(11)) == ""


# ── the full status card carries both lines ─────────────────────────────────
class _DB:
    def get_open_trades(self):
        return []


def test_status_message_contains_macro_and_gemini_lines(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    cache = tmp_path / "gemini_status_cache.json"
    gen = (_now(10) - timedelta(minutes=20)).isoformat()
    cache.write_text(json.dumps({"XAU/USD": {"verdict": _verdict(),
                                             "generated_at": gen,
                                             "last_attempt_at": gen}}),
                     encoding="utf-8")
    decision = {"symbol": "XAU/USD", "decision": "WAIT", "current_price": 4600.52}
    all_results = {
        "symbol": "XAU/USD",
        "macro_fundamental": {
            "macro_direction": {"bias": "BULLISH_GOLD", "confidence": 61.0,
                                "summary": "Weaker USD supports gold"}},
        "technical": {"signal": "BUY", "confidence": 85.0},
        "multitimeframe": {"signal": "WAIT", "confidence": 48.0},
        "classical": {"signal": "WAIT", "confidence": 0.0},
        "smc": {"signal": "WAIT", "confidence": 0.0},
        "price_action": {"signal": "WAIT", "confidence": 0.0},
        "auction_flow": {"signal": "WAIT", "confidence": 50.0},
    }

    class _FakeDatetime(datetime):
        @classmethod
        def now(cls, tz=None):
            return _now(11)

    monkeypatch.setattr("scripts.run_analysis.datetime", _FakeDatetime)
    text = ra._build_market_status_message(decision, all_results, _DB(), cfg)
    # the card is HTML: labels carry <b> tags, so assert on the values
    assert "Macro:" in text
    assert "Bullish Gold 61%" in text
    assert "Weaker USD supports gold" in text
    assert "Gemini XAU/USD:" in text
    assert "BULLISH (BUY)" in text
    assert "(stored" in text


# ── BUILD 25: per-symbol opinions + explicit-model-wins ────────────────────
def test_oil_macro_line_appears(monkeypatch):
    class _OilAgent:
        def __init__(self, cfg):
            pass

        def analyze(self, data):
            return {"agent": "oil_macro", "direction": "SELL", "confidence": 44,
                    "bias": "BEARISH_OIL", "score": -0.5,
                    "summary": "Brent-WTI spread widening beyond band"}

    monkeypatch.setattr(ra, "OilMacroAgent", _OilAgent)
    line = ra._status_oil_macro_line({})
    assert "Oil Macro:" in line
    assert "SELL 44%" in line
    assert "Brent-WTI spread widening" in line


def test_oil_macro_wait_line_shows_score(monkeypatch):
    class _OilAgent:
        def __init__(self, cfg):
            pass

        def analyze(self, data):
            return {"agent": "oil_macro", "direction": "WAIT", "confidence": 0,
                    "bias": "NEUTRAL_OIL", "score": -0.5, "summary": "in band"}

    monkeypatch.setattr(ra, "OilMacroAgent", _OilAgent)
    line = ra._status_oil_macro_line({})
    assert "WAIT (score -0.5)" in line


def test_gemini_cache_is_keyed_per_symbol(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    cache = tmp_path / "gemini_status_cache.json"
    gen = (_now(10) - timedelta(minutes=10)).isoformat()
    cache.write_text(json.dumps({
        "XAU/USD": {"verdict": _verdict("BULLISH", "BUY", "gold up"),
                    "generated_at": gen, "last_attempt_at": gen},
        "WTI/USD": {"verdict": _verdict("BEARISH", "SELL", "oil weak"),
                    "generated_at": gen, "last_attempt_at": gen},
    }), encoding="utf-8")

    def _boom(*a, **k):
        raise AssertionError("fresh caches: no API calls")

    monkeypatch.setattr(lr, "get_gemini_review_service", _boom)
    gold = ra._status_gemini_line(cfg, {}, "XAU/USD", now=_now(10, 20))
    oil = ra._status_gemini_line(cfg, {}, "WTI/USD", now=_now(10, 20))
    assert "Gemini XAU/USD:" in gold and "BULLISH" in gold
    assert "Gemini WTI/USD:" in oil and "BEARISH" in oil


def test_refresh_only_that_symbols_entry(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    cache = tmp_path / "gemini_status_cache.json"
    old_gen = (_now(8) - timedelta(hours=3)).isoformat()
    cache.write_text(json.dumps({
        "XAU/USD": {"verdict": _verdict("BULLISH", "BUY", "gold"),
                    "generated_at": (_now(9) - timedelta(minutes=10)).isoformat(),
                    "last_attempt_at": (_now(9) - timedelta(minutes=10)).isoformat()},
        "WTI/USD": {"verdict": _verdict("BEARISH", "SELL", "oil"),
                    "generated_at": old_gen, "last_attempt_at": old_gen},
    }), encoding="utf-8")

    class _Gem:
        enabled = True
        model = "gemini-3.5-flash-lite"

        def analyze_market_context(self, payload):
            assert payload["symbol"] == "WTI/USD"
            return {"available": True, "suppressed": False,
                    "market_bias": "NEUTRAL", "action": "WAIT", "reason": "range"}

    monkeypatch.setattr(lr, "get_gemini_review_service", lambda cfg: _Gem())
    line = ra._status_gemini_line(cfg, {}, "WTI/USD", now=_now(12), price=86.5)
    assert "Gemini WTI/USD:" in line
    stored = json.loads(cache.read_text(encoding="utf-8"))
    # the oil entry refreshed; the gold entry is untouched
    assert stored["WTI/USD"]["verdict"]["bias"] == "NEUTRAL"
    assert stored["XAU/USD"]["verdict"]["bias"] == "BULLISH"


def test_status_card_has_both_macro_lines_and_per_symbol_gemini(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    cfg["symbols"] = [{"symbol": "XAU/USD"}, {"symbol": "WTI/USD"}]
    cache = tmp_path / "gemini_status_cache.json"
    gen = (_now(10) - timedelta(minutes=20)).isoformat()
    cache.write_text(json.dumps({
        "XAU/USD": {"verdict": _verdict("BULLISH", "BUY", "dxy soft"),
                    "generated_at": gen, "last_attempt_at": gen},
        "WTI/USD": {"verdict": _verdict("BEARISH", "SELL", "spread wide"),
                    "generated_at": gen, "last_attempt_at": gen},
    }), encoding="utf-8")

    class _OilAgent:
        def __init__(self, cfg):
            pass

        def analyze(self, data):
            return {"agent": "oil_macro", "direction": "SELL", "confidence": 44,
                    "bias": "BEARISH_OIL", "score": -0.5,
                    "summary": "Brent-WTI spread widening beyond band"}

    monkeypatch.setattr(ra, "OilMacroAgent", _OilAgent)

    class _FakeDatetime(datetime):
        @classmethod
        def now(cls, tz=None):
            return _now(11)

    monkeypatch.setattr("scripts.run_analysis.datetime", _FakeDatetime)
    decision = {"symbol": "XAU/USD", "decision": "WAIT", "current_price": 4600.52}
    all_results = {
        "symbol": "XAU/USD",
        "macro_fundamental": {
            "macro_direction": {"bias": "BULLISH_GOLD", "confidence": 61.0,
                                "summary": "Weaker USD supports gold"}},
        "technical": {"signal": "BUY", "confidence": 85.0},
        "multitimeframe": {"signal": "WAIT", "confidence": 48.0},
        "classical": {"signal": "WAIT", "confidence": 0.0},
        "smc": {"signal": "WAIT", "confidence": 0.0},
        "price_action": {"signal": "WAIT", "confidence": 0.0},
        "auction_flow": {"signal": "WAIT", "confidence": 50.0},
    }
    text = ra._build_market_status_message(decision, all_results, _DB(), cfg)
    assert "Macro:" in text and "Bullish Gold 61%" in text
    assert "Oil Macro:" in text and "SELL 44%" in text
    assert "Gemini XAU/USD:" in text and "BULLISH" in text
    assert "Gemini WTI/USD:" in text and "BEARISH" in text
