"""BUILD 16.1 (2026-08-20): DEMO-ONLY dashboard/reports.

The VPS local fallback keeps paper-era rows and demo rows in ONE file, so
"demo only" means filtering rows by trading_mode/mt5_ticket - not just
skipping the paper table merge. These tests pin the filter and the flag.
"""
from __future__ import annotations

import json
from pathlib import Path

from services.dashboard import dashboard_demo_only, demo_only_rows
from services.dashboard_local_api import build_dashboard_payload


def _row(tid, status, pnl=0, **extra):
    row = {
        "id": tid, "symbol": "XAU/USD", "type": "BUY", "status": status,
        "entry_price": 4300.0, "stop_loss": 4260.0, "tp1": 4332.0,
        "tp2": 4364.0, "created_at": "2026-08-11T08:00:00+00:00",
        "closed_at": "2026-08-11T09:00:00+00:00" if status not in {"OPEN", "PENDING"} else None,
        "pnl_points": pnl,
    }
    row.update(extra)
    return row


# ── demo_only_rows ─────────────────────────────────────────────────────────
def test_keeps_mt5_demo_rows():
    rows = [_row("A", "TP2_HIT", 10, trading_mode="mt5_demo"),
            _row("B", "SL_HIT", -5, trading_mode="mt5_demo")]
    assert len(demo_only_rows(rows)) == 2


def test_keeps_broker_ticket_rows_without_mode():
    rows = [_row("A", "TP2_HIT", 10, mt5_ticket=475201659)]
    assert len(demo_only_rows(rows)) == 1


def test_drops_paper_flagged_rows():
    rows = [_row("A", "TP2_HIT", 10, trading_mode="mt5_demo"),
            _row("B", "TP2_HIT", 20, paper_trading=True),
            _row("C", "TP2_HIT", 30, trading_mode="paper"),
            _row("D", "TP2_HIT", 40, trading_mode="demo")]
    out = demo_only_rows(rows)
    assert [r["id"] for r in out] == ["A"]


def test_drops_unmarked_rows():
    # paper-era rows carry no mode and no ticket -> not demo evidence
    rows = [_row("A", "TP2_HIT", 10, trading_mode="mt5_demo"),
            _row("B", "TP2_HIT", 20)]
    assert [r["id"] for r in demo_only_rows(rows)] == ["A"]


def test_empty_and_none():
    assert demo_only_rows(None) == []
    assert demo_only_rows([]) == []


# ── dashboard_demo_only flag ───────────────────────────────────────────────
def test_flag_ignores_ambient_env(monkeypatch):
    """16.1 regression: a machine-level TRADES_TABLE=trades_demo on the VPS
    flipped the filter during the test suite and broke fixtures. The flag
    must answer to the explicit config key alone."""
    monkeypatch.setenv("TRADES_TABLE", "trades_demo")
    monkeypatch.setenv("EXECUTION_MODE", "mt5_demo")
    assert dashboard_demo_only({}) is False
    assert dashboard_demo_only({"dashboard": {}}) is False
    assert dashboard_demo_only({"dashboard": {"demo_only": True}}) is True


def test_flag_on_via_config(monkeypatch):
    monkeypatch.delenv("TRADES_TABLE", raising=False)
    assert dashboard_demo_only({"dashboard": {"demo_only": True}}) is True


def test_flag_off_by_default(monkeypatch):
    monkeypatch.delenv("TRADES_TABLE", raising=False)
    assert dashboard_demo_only({}) is False
    assert dashboard_demo_only({"dashboard": {}}) is False


# ── API payload respects demo-only ─────────────────────────────────────────
def test_api_filters_paper_rows_when_demo_only(tmp_path):
    (tmp_path / "storage").mkdir()
    rows = [
        _row("D1", "TP2_HIT", 100, trading_mode="mt5_demo"),
        _row("P1", "TP2_HIT", 200),                    # unmarked paper row
        _row("D2", "SL_HIT", -40, trading_mode="mt5_demo"),
        _row("P2", "TP2_HIT", 300, paper_trading=True),
    ]
    (tmp_path / "storage" / "trades.json").write_text(json.dumps(rows), encoding="utf-8")
    (tmp_path / "config.json").write_text(json.dumps({
        "dashboard": {"demo_only": True},
        "agent_weights": {"technical": 0.2},
    }), encoding="utf-8")

    payload = build_dashboard_payload(tmp_path)
    assert payload["ok"] is True
    ids = [t["id"] for t in payload["closedTrades"]]
    assert ids == ["D1", "D2"]
    assert payload["summary"]["netPoints"] == 60


def test_api_keeps_legacy_behaviour_without_flag(tmp_path):
    (tmp_path / "storage").mkdir()
    rows = [
        _row("D1", "TP2_HIT", 100, trading_mode="mt5_demo"),
        _row("P1", "TP2_HIT", 200),
    ]
    (tmp_path / "storage" / "trades.json").write_text(json.dumps(rows), encoding="utf-8")
    (tmp_path / "config.json").write_text(json.dumps({
        "agent_weights": {"technical": 0.2},
    }), encoding="utf-8")

    payload = build_dashboard_payload(tmp_path)
    assert len(payload["closedTrades"]) == 2
    assert payload["summary"]["netPoints"] == 300


# ── production config ships demo_only ──────────────────────────────────────
def test_config_ships_demo_only():
    cfg = json.loads((Path(__file__).resolve().parents[1] / "config.json").read_text(encoding="utf-8"))
    assert cfg["dashboard"]["demo_only"] is True
