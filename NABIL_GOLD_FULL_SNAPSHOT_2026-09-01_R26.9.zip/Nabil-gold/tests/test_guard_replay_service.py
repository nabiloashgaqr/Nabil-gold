# -*- coding: utf-8 -*-
"""BUILD31-R13: services/guard_replay.py is the ONE guard-replay engine.

Both the manual audit report (scripts/audit_recent_trades.py) and the guard
``would_block`` field written by services/database.py import it, so they can
never drift apart. These tests pin the semantics.
"""
import os
import sys
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from services.guard_replay import (  # noqa: E402
    collect_evidence,
    hebron_day,
    in_quiet_hours,
    outcome,
    replay_guards,
    trade_pnl_points,
    would_block_for,
    _deep_find_first,
)

U = timezone.utc


def _ts(hours_ago=2):
    return (datetime.now(U) - timedelta(hours=hours_ago)).replace(microsecond=0).isoformat()


def _chase(symbol="WTI/USD", hours_ago=1, direction="BUY"):
    # created_at is PINNED into the quiet window (03:00 UTC) so the guard
    # expectations hold at any wall-clock time the suite runs.
    return {
        "id": "SYN-9", "type": direction, "symbol": symbol,
        "entry_price": 75.50 if symbol == "WTI/USD" else 2648.0,
        "close_price": 74.90 if symbol == "WTI/USD" else 2642.0,
        "status": "SL_HIT",
        "created_at": "2026-08-27T03:00:00+00:00",
        "closed_at": "2026-08-27T04:00:00+00:00",
        "confidence": 75,
        "signal_snapshot": {
            "strategy_profile": {"resolved_setup_type": "BREAKOUT_EXPANSION"},
            "smc": {"direction": "WAIT", "confidence": 40},
            "auction_flow": {"direction": "WAIT", "confidence": 45},
            "technical": {"atr": 0.5},
            "market_regime": {"regime": "CONSOLIDATION_RANGE"},
        },
    }


class TestCanonicalEngine(unittest.TestCase):
    def test_quiet_hours_branches(self):
        self.assertTrue(in_quiet_hours(datetime(2026, 8, 26, 22, 0, tzinfo=U)))
        self.assertTrue(in_quiet_hours(datetime(2026, 8, 26, 6, 29, tzinfo=U)))
        self.assertFalse(in_quiet_hours(datetime(2026, 8, 26, 6, 30, tzinfo=U)))

    def test_hebron_day_rolls_at_03_local(self):
        # 03:30 Hebron already belongs to the same calendar day
        self.assertEqual(hebron_day(datetime(2026, 8, 27, 0, 30, tzinfo=U)).isoformat(),
                         "2026-08-27")
        # 00:00 Hebron (21:00 UTC) belongs to the trading day that started 03:00 the previous day
        self.assertEqual(hebron_day(datetime(2026, 8, 26, 21, 0, tzinfo=U)).isoformat(),
                         "2026-08-26")
        # 01:59 Hebron still previous day; 03:00 local (=00:00 UTC) starts the new day
        self.assertEqual(hebron_day(datetime(2026, 8, 26, 22, 59, tzinfo=U)).isoformat(),
                         "2026-08-26")
        self.assertEqual(hebron_day(datetime(2026, 8, 26, 23, 59, tzinfo=U)).isoformat(),
                         "2026-08-26")
        self.assertEqual(hebron_day(datetime(2026, 8, 27, 0, 0, tzinfo=U)).isoformat(),
                         "2026-08-27")

    def test_chase_during_quiet_hours_is_blocked(self):
        blocked, notes, unknown, arch, ev = replay_guards(_chase(), [])
        self.assertIn("QUIET_HOURS_21_06(chase)", blocked)
        self.assertIn("CONSOLIDATION_LOCKDOWN(chase)", blocked)
        self.assertEqual(arch, "BREAKOUT_EXPANSION")

    def test_row_level_evidence_kills_unknown(self):
        t = _chase()
        t["entry_vwap"], t["entry_atr"] = 75.9, 0.5
        t["range_high"], t["range_low"] = 76.5, 74.5
        _blocked, _notes, unknown, _arch, _ev = replay_guards(t, [])
        self.assertEqual(unknown, [])  # evidence present at row level
        ev = collect_evidence(t, t["signal_snapshot"])
        self.assertEqual(ev["vwap"], 75.9)
        self.assertEqual(ev["range_high"], 76.5)

    def test_would_block_for_returns_hard_blocks_only(self):
        t = _chase()
        blocked = would_block_for(t, [])
        self.assertIsInstance(blocked, list)
        self.assertIn("QUIET_HOURS_21_06(chase)", blocked)
        # a pullback in the quiet window gets a NOTE, not a hard block
        t2 = _chase()
        t2["signal_snapshot"]["strategy_profile"]["resolved_setup_type"] = "ORDER_BLOCK_PULLBACK"
        t2["signal_snapshot"]["smc"] = {"direction": "BUY", "confidence": 66}
        self.assertEqual(would_block_for(t2, []), [])

    def test_would_block_never_raises(self):
        self.assertTrue(would_block_for({"id": "X"}, None) is not None)


class TestAuditScriptUsesTheSameEngine(unittest.TestCase):
    def test_audit_script_delegates_to_service(self):
        src = (Path(ROOT) / "scripts" / "audit_recent_trades.py").read_text(encoding="utf-8")
        self.assertIn("from services.guard_replay import", src)
        # no local duplicate of the guard logic any more
        self.assertNotIn("def replay_guards(", src)
        self.assertNotIn("def open_same_direction_at(", src)

    def test_deep_find_first_skips_unrelated_keys(self):
        blob = {"candles": [{"high": 99}], "smc": {"dealing_range": {"high": 76.5}}}
        self.assertEqual(_deep_find_first(blob, "dealing_range")["high"], 76.5)


class TestOutcomeThresholds(unittest.TestCase):
    def test_win_loss_be_thresholds(self):
        self.assertEqual(outcome({"status": "TP2_HIT", "final_pnl": 10}), "WIN")
        self.assertEqual(outcome({"status": "SL_HIT", "final_pnl": -10}), "LOSS")
        self.assertEqual(outcome({"status": "BE_HIT", "final_pnl": 0}), "BE")
        self.assertEqual(outcome({"status": "OPEN", "current_pnl_points": -3}), "LOSS(OPEN)")

    def test_pnl_points_by_symbol_point_size(self):
        t = {"symbol": "XAU/USD", "type": "BUY", "entry_price": 2640.0,
             "close_price": 2642.0, "final_pnl": None, "current_pnl_points": None}
        self.assertAlmostEqual(trade_pnl_points(t), 20.0, places=6)


if __name__ == "__main__":
    unittest.main()
