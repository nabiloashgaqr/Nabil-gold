"""AGENT WATCH display card (operator 2026-08-17).

2026-08-17 09:46: technical BUY 71 + multitimeframe BUY 92 gave a blocked
two-agent book at net 80% with zero opposition — but the WATCH_MAP card
requires a structurally READY SMC map (quality was 59 < 70), so Telegram
stayed silent and the operator reasonably asked "where is my watch map?".

The AGENT WATCH card fills exactly that gap: display-only, fires on WAIT
cycles when >= 2 qualified agents agree at net >= the consensus floor with
<= 1 opponent and NO ready plan exists. Never creates orders/trades/plans.
"""
from __future__ import annotations

import io

from services.thesis_consensus import evaluate_directional_admission
from utils.helpers import load_config

CONFIG = load_config()
NET_FLOOR = float((CONFIG.get("signal_requirements") or {}).get("min_consensus_confidence") or 65)


def _fires(adm) -> bool:
    return (not adm.get("allow")
            and int(adm.get("support_count") or 0) >= 2
            and float(adm.get("confidence") or 0) >= NET_FLOOR
            and int(adm.get("opposition_count") or 0) <= 1)


def test_the_0946_book_triggers_the_card():
    book = {
        "technical": {"direction": "BUY", "confidence": 71.0},
        "multitimeframe": {"direction": "BUY", "confidence": 92.0},
        "classical": {"direction": "BUY", "confidence": 52.8},
        "smc": {"direction": "WAIT", "confidence": 33.5},
        "price_action": {"direction": "BUY", "confidence": 25.0},
        "auction_flow": {"direction": "WAIT", "confidence": 0.0},
    }
    adm = evaluate_directional_admission("BUY", book, CONFIG)
    assert adm.get("allow") is False          # 2 agents can't execute alone
    assert _fires(adm), adm                   # ...but the operator must SEE it


def test_single_supporter_stays_silent():
    book = {
        "technical": {"direction": "BUY", "confidence": 71.0},
        "multitimeframe": {"direction": "WAIT", "confidence": 40.0},
        "classical": {"direction": "WAIT", "confidence": 30.0},
        "smc": {"direction": "WAIT", "confidence": 30.0},
        "price_action": {"direction": "WAIT", "confidence": 30.0},
    }
    adm = evaluate_directional_admission("BUY", book, CONFIG)
    assert not _fires(adm)


def test_heavy_opposition_stays_silent():
    book = {
        "technical": {"direction": "BUY", "confidence": 80.0},
        "multitimeframe": {"direction": "BUY", "confidence": 80.0},
        "classical": {"direction": "SELL", "confidence": 80.0},
        "smc": {"direction": "SELL", "confidence": 80.0},
        "price_action": {"direction": "WAIT", "confidence": 30.0},
    }
    adm = evaluate_directional_admission("BUY", book, CONFIG)
    assert not _fires(adm)  # 2 opponents > limit of 1


def test_card_is_wired_display_only_and_gated():
    src = io.open("scripts/run_analysis.py", encoding="utf-8").read()
    assert "AGENT WATCH card" in src
    # Window widened 2000 -> 3000 on 2026-08-17b: the throttle documentation
    # block sits between the header and the gating code now.
    assert 'decision_type == "WAIT"' in src.split("AGENT WATCH card")[1][:3000]
    assert "plan_ready" in src.split("AGENT WATCH card")[1][:3000]
    block = src.split("AGENT WATCH card")[1][:6000]
    assert "save_trade" not in block            # words only
    assert "stamp_execution_path" not in block  # no admission side effects
    assert "agent_watch_enabled" in block       # operator kill switch
