"""BUILD 18 (2026-08-20): oil live tick feed + target distance caps.

Three fixes, pinned by tests:
  1. the tick manager feeds a suffixed auction store for EVERY enabled
     non-base instrument (e.g. live WTI/USD) - without this aux feed the
     WTI auction agent sees stale ticks, so Path 4/5 go silent for oil
     (LIVE_TICK_FEED_STALE).
  2. per-instrument absolute target distance caps: WTI max_tp1=150 /
     max_tp2=350 points. The liquidity law shipped TP2 477 pts (5.5% of
     price) on oil; far pools are dropped, the 0.8R rung / 2xTP1 fallbacks
     ship instead. Gold is untouched.
  3. agent measurement rows carry a symbol stamp.
"""
from __future__ import annotations

import json
import time
from types import SimpleNamespace
from pathlib import Path

import scripts.run_analysis as ra
import scripts.run_tick_manager as rtm
from utils.trading_rules import targets_law

WTI_TARGETS = {
    "min_tp1_rr": 0.8, "tp2_multiple": 2.0, "max_beyond_points": 60,
    "max_tp1_points": 150, "max_tp2_points": 350,
}


def _wti_cfg() -> dict:
    return {
        "symbol": "WTI/USD",
        "trading_rules": {"targets": dict(WTI_TARGETS)},
    }


def _gold_cfg() -> dict:
    return {
        "symbol": "XAU/USD",
        "trading_rules": {"targets": {"min_tp1_rr": 0.8, "tp2_multiple": 2.0,
                                      "max_beyond_points": 200}},
    }


def _decision(side, entry, stop, tp1, tp2, symbol="WTI/USD"):
    return {
        "decision": side, "symbol": symbol,
        "signal": {"entry": {"price": entry}, "stop_loss": stop,
                   "tp1": tp1, "tp2": tp2, "rr_ratio": 9.9},
    }


# ── 1) target distance caps (the 477-pt regression) ────────────────────────
def test_caps_clip_far_wti_targets():
    # the cancelled 2026-08-20 pending: entry 85.23, SL 84.13 (110 pts),
    # TP1 87.39 (216 pts), TP2 90.00 (477 pts) - shipped by the map.
    dec = ra.apply_target_distance_caps(
        _decision("BUY", 85.23, 84.13, 87.39, 90.00), _wti_cfg())
    sig = dec["signal"]
    assert sig["target_cap_applied"] is True
    d1_pts = abs(sig["tp1"] - 85.23) * 100  # oil: 1 point = $0.01
    d2_pts = abs(sig["tp2"] - 85.23) * 100
    # TP1 -> 0.8R rung (0.8 x 110 = 88 pts), TP2 -> 2x that
    assert abs(d1_pts - 88.0) < 0.5
    assert abs(d2_pts - 2 * d1_pts) < 0.5
    assert d2_pts <= 350.0  # never beyond the oil cap
    assert sig["tp2"] >= sig["tp1"]


def test_caps_leave_near_targets_alone():
    dec = _decision("BUY", 85.23, 84.13, 86.11, 86.99)
    out = ra.apply_target_distance_caps(dec, _wti_cfg())
    assert out["signal"].get("target_cap_applied") is None
    assert out["signal"]["tp1"] == 86.11
    assert out["signal"]["tp2"] == 86.99


def test_caps_do_not_touch_gold():
    dec = _decision("BUY", 4400.0, 4360.0, 4440.0, 4490.0, symbol="XAU/USD")
    out = ra.apply_target_distance_caps(dec, _gold_cfg())
    assert out is dec
    assert out["signal"]["tp2"] == 4490.0


def test_caps_ignore_wait_and_missing_signal():
    assert ra.apply_target_distance_caps({"decision": "WAIT"}, _wti_cfg())["decision"] == "WAIT"
    dec = {"decision": "BUY", "signal": {}}
    assert ra.apply_target_distance_caps(dec, _wti_cfg())["signal"] == {}


# ── 2) targets_law drops beyond-cap pools ───────────────────────────────────
def test_targets_law_drops_far_wti_pools():
    # 87.39 (216 pts) sits inside the 2x band -> still a legal TP2; the far
    # pool 90.00 (477 pts) is beyond the 350-pt cap and must be dropped.
    tp1, tp2, used = targets_law(
        direction="BUY", entry=85.23, risk_price=1.10,
        levels=[87.39, 90.00], cfg=_wti_cfg(), symbol="WTI/USD")
    assert abs(tp1 - 86.11) < 0.01       # 0.8R rung
    assert abs(tp2 - 87.39) < 0.01       # in-band pool, not 90.00
    assert abs(tp2 - 85.23) <= 3.50      # inside the oil cap in price terms


def test_targets_law_cap_clamps_wide_rung():
    # a wide 250-pt risk pushes the 2x rung (400 pts) past the cap -> clamp
    tp1, tp2, used = targets_law(
        direction="BUY", entry=85.23, risk_price=2.50,
        levels=[], cfg=_wti_cfg(), symbol="WTI/USD")
    assert abs(abs(tp2 - 85.23) - 3.50) < 0.01


def test_targets_law_pool_within_band_still_wins():
    tp1, tp2, used = targets_law(
        direction="BUY", entry=85.23, risk_price=1.10,
        levels=[85.98, 86.20], cfg=_wti_cfg(), symbol="WTI/USD")
    # 85.98 = 75 pts out: inside [0.8R=88?...] no - 75 < 88, below the rung
    # so the nearest eligible is the rung itself; 86.20 (97 pts) is inside
    # [88, 148] -> tp1 = 86.20
    assert abs(tp1 - 86.20) < 0.01
    assert used is True


def test_targets_law_gold_unchanged():
    tp1, tp2, used = targets_law(
        direction="BUY", entry=4400.0, risk_price=40.0,
        levels=[4430.0, 4490.0], cfg=_gold_cfg(), symbol="XAU/USD")
    # gold band: rung 32 pts (4432), pool band [4432, 4470]: 4430 below,
    # 4490 beyond -> no pool -> rung + 2x rung
    assert abs(tp1 - 4432.0) < 0.01
    assert abs(tp2 - 4464.0) < 0.01


# ── 3) live multi-symbol auction feed ───────────────────────────────────────
class FakeStore:
    instances = []

    def __init__(self, path, symbol=None):  # R21: stores carry a symbol stamp
        self.path = str(path)
        self.symbol = symbol
        self.ticks = 0
        self.hb = 0
        self._last = 0
        FakeStore.instances.append(self)

    def mark_heartbeat(self):
        self.hb += 1

    def meta(self):
        return {"last_tick_ts_ms": self._last}

    def record_tick(self, tick):
        self.ticks += 1
        self._last = int(getattr(tick, "time_msc", 0) or 0)
        return True


def test_aux_collector_covers_live_wti(monkeypatch, tmp_path):
    monkeypatch.setattr("services.auction_flow_store.AuctionFlowStore", FakeStore)
    FakeStore.instances = []
    cfg = {
        "symbol": "XAU/USD",
        "auction_flow": {"enabled": False,
                         "storage_path": str(tmp_path / "auction_flow.sqlite3")},
        "symbols": [{"symbol": "XAU/USD"}, {"symbol": "WTI/USD"}],  # LIVE
    }
    tm = rtm.TickManager(cfg)
    syms = [s for s, _ in tm._aux_ticks]
    assert "WTI/USD" in syms
    assert "XAU/USD" not in syms  # the base symbol keeps its own collector

    class FakeExec:
        def _sym(self, s):
            return {"WTI/USD": "WTI.s"}.get(s, s)

    class FakeMt5:
        def __init__(self):
            self.calls = 0

        def symbol_info_tick(self, sym):
            assert sym == "WTI.s"
            self.calls += 1
            return SimpleNamespace(time_msc=100000 + self.calls)

    mt5 = FakeMt5()
    tm._collect_aux_ticks(mt5, FakeExec(), time.time())
    store = dict(tm._aux_ticks)["WTI/USD"]
    assert store.ticks >= 1
    assert tm._aux_last_msc["WTI/USD"] >= 100001


def test_aux_collector_covers_all_non_base_symbols(monkeypatch, tmp_path):
    monkeypatch.setattr("services.auction_flow_store.AuctionFlowStore", FakeStore)
    FakeStore.instances = []
    cfg = {
        "symbol": "XAU/USD",
        "auction_flow": {"enabled": False,
                         "storage_path": str(tmp_path / "auction_flow.sqlite3")},
        "symbols": [{"symbol": "XAU/USD"},
                    {"symbol": "WTI/USD", "enabled": True}],
    }
    tm = rtm.TickManager(cfg)
    assert [s for s, _ in tm._aux_ticks] == ["WTI/USD"]


# ── 3b) BUILD 18.1: Market Watch selection + wall-clock fallback ────────────
def test_aux_collector_selects_symbol_and_records_zero_time_tick(monkeypatch, tmp_path):
    monkeypatch.setattr("services.auction_flow_store.AuctionFlowStore", FakeStore)
    FakeStore.instances = []
    cfg = {
        "symbol": "XAU/USD",
        "auction_flow": {"enabled": False,
                         "storage_path": str(tmp_path / "auction_flow.sqlite3")},
        "symbols": [{"symbol": "XAU/USD"}, {"symbol": "WTI/USD"}],
    }
    tm = rtm.TickManager(cfg)
    selected = []

    class FakeMt5:
        def symbol_select(self, sym, on):
            selected.append((sym, on))
            return True

        def symbol_info_tick(self, sym):
            # non-subscribed symbols return ticks with time_msc = 0
            return SimpleNamespace(time_msc=0, bid=85.10, ask=85.12)

    tm._collect_aux_ticks(FakeMt5(), _FakeExec(), time.time())
    assert ("WTI.s", True) in selected
    store = dict(tm._aux_ticks)["WTI/USD"]
    assert store.ticks >= 1  # wall-clock fallback let the quote record
    assert tm._aux_last_msc["WTI/USD"] > 0


def test_aux_collector_survives_none_tick_with_warning(monkeypatch, tmp_path):
    monkeypatch.setattr("services.auction_flow_store.AuctionFlowStore", FakeStore)
    FakeStore.instances = []
    cfg = {
        "symbol": "XAU/USD",
        "auction_flow": {"enabled": False,
                         "storage_path": str(tmp_path / "auction_flow.sqlite3")},
        "symbols": [{"symbol": "XAU/USD"}, {"symbol": "WTI/USD"}],
    }
    tm = rtm.TickManager(cfg)

    class FakeMt5:
        def symbol_select(self, sym, on):
            return True

        def symbol_info_tick(self, sym):
            return None

    now = time.time()
    tm._collect_aux_ticks(FakeMt5(), _FakeExec(), now)
    # second call inside the same hour must not re-warn
    tm._collect_aux_ticks(FakeMt5(), _FakeExec(), now + 10)
    store = dict(tm._aux_ticks)["WTI/USD"]
    assert store.ticks == 0
    assert store.hb >= 1  # heartbeat still written
    assert tm._aux_warned_at.get("WTI/USD")


class _FakeExec:
    def _sym(self, s):
        return {"WTI/USD": "WTI.s"}.get(s, s)


# ── 4) measurement symbol stamp ─────────────────────────────────────────────
def test_measurement_row_carries_symbol(monkeypatch, tmp_path):
    import services.agent_measurement as am
    out = tmp_path / "agent_system_t.jsonl"
    monkeypatch.setattr(am, "_path", lambda config, now: out)
    config = {"agent_measurement": {"enabled": True}}
    all_results = {
        "symbol": "WTI/USD",
        "current_price": 85.0,
        "shared_market_data": {"snapshot_id": "SNAP-WTI-1"},
        "session_plan": {},
    }
    am.record_agent_measurement(all_results, {"decision": "WAIT"}, config)
    rows = [json.loads(line) for line in out.read_text(encoding="utf-8").splitlines() if line.strip()]
    assert rows[-1]["symbol"] == "WTI/USD"
    assert rows[-1]["admission"]["BUY"]["allow"] is False
