"""BUILD 27 (2026-08-21): post-news cards - once per event per symbol.

Live incident: the SAME post-news card was re-sent every cycle (the operator
counted 8+ for a single double release). Root causes fixed here:
  1. the tracker FILE was referenced but never defined (a swallowed NameError
     made every load return {} and every save a no-op);
  2. the tracker key used the raw time string, which drifts between the
     merged news sources, so every cycle produced a new key;
  3. events released in the same minute each got their own card;
  4. WTI cards were answered by a gold-only prompt ("Gold Impact" on oil).

Pinned behaviour: ONE card per release-minute bucket per symbol; robust keys;
per-symbol content (Oil Impact + oil macro for WTI).
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

import scripts.run_analysis as ra
from services import telegram_bot as tb


@pytest.fixture(autouse=True)
def _tracker_in_tmp(tmp_path, monkeypatch):
    monkeypatch.setattr(tb, "_POST_NEWS_TRACKER_FILE",
                        tmp_path / "post_news_tracker.json")
    yield


def _events(minute_offset=-20):
    t0 = datetime(2026, 8, 21, 13, 45, tzinfo=timezone.utc)
    base = t0 + timedelta(minutes=minute_offset)
    return [
        {"event": "Flash Manufacturing PMI", "tier": "TIER_2",
         "time": base.strftime("%Y-%m-%dT%H:%M"), "minutes_until": minute_offset},
        {"event": "Flash Services PMI", "tier": "TIER_2",
         "time": base.strftime("%Y-%m-%d %H:%M:%S"), "minutes_until": minute_offset},
    ]


class _Gem:
    enabled = True

    def __init__(self):
        self.calls = []

    def interpret_post_news(self, payload):
        self.calls.append(payload)
        return {"available": True, "suppressed": False,
                "event": payload.get("event_name"),
                "surprise": "IN_LINE",
                "gold_impact": "BULLISH", "oil_impact": "BULLISH",
                "dxy_impact": "WEAKENING", "confidence": 80,
                "recommendation": "keep watching", "key_insight": "range"}


class _Tg:
    def __init__(self):
        self.sent = []

    def send_post_news_analysis(self, analysis, event_name, symbol):
        self.sent.append((analysis, event_name, symbol))
        return True


# ── 1) the tracker really persists now ─────────────────────────────────────
def test_tracker_round_trip_persists():
    assert tb.post_news_alert_sent("K1") is False
    tb.post_news_alert_record("K1")
    assert tb.post_news_alert_sent("K1") is True
    assert tb.post_news_alert_sent("K2") is False
    # the file is a real, defined path under storage
    assert "post_news_tracker.json" in str(tb._POST_NEWS_TRACKER_FILE.name)
    assert tb._POST_NEWS_TRACKER_FILE.exists()


def test_tracker_separates_symbols():
    tb.post_news_alert_record("XAU/USD_2026-08-21T13:45")
    assert tb.post_news_alert_sent("XAU/USD_2026-08-21T13:45") is True
    assert tb.post_news_alert_sent("WTI/USD_2026-08-21T13:45") is False


# ── 2) robust bucket keys ───────────────────────────────────────────────────
def test_bucket_immune_to_time_format_drift():
    now = datetime(2026, 8, 21, 14, 0, tzinfo=timezone.utc)
    a = ra._post_news_release_bucket(
        {"time": "2026-08-21 13:45:00"}, -20, now)
    b = ra._post_news_release_bucket(
        {"time": "2026-08-21T13:45"}, -20, now)
    assert a == b == "2026-08-21T13:45"


def test_bucket_falls_back_to_minutes_until():
    now = datetime(2026, 8, 21, 14, 0, tzinfo=timezone.utc)
    bucket = ra._post_news_release_bucket({"time": ""}, -20, now)
    assert bucket == "2026-08-21T13:40"


# ── 3) one card per bucket per symbol ──────────────────────────────────────
def test_same_minute_events_share_one_card(monkeypatch):
    gem = _Gem()
    tg = _Tg()
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events()}, "XAU/USD", 4600.0,
        {"symbol": "XAU/USD"}, database=None)
    assert len(gem.calls) == 1
    assert "Manufacturing" in gem.calls[0]["event_name"]
    assert "Services" in gem.calls[0]["event_name"]
    assert len(tg.sent) == 1


def test_second_cycle_is_silent(monkeypatch):
    gem = _Gem()
    tg = _Tg()
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events()}, "XAU/USD", 4600.0,
        {"symbol": "XAU/USD"}, database=None)
    assert len(gem.calls) == 1
    # a later cycle: SAME release minute, drifted time FORMATS only
    t0 = datetime(2026, 8, 21, 13, 45, tzinfo=timezone.utc)
    release = (t0 + timedelta(minutes=-20)).replace(tzinfo=timezone.utc)
    drifted = [
        {"event": "Flash Manufacturing PMI", "tier": "TIER_2",
         "time": release.strftime("%Y-%m-%dT%H:%M:%SZ"), "minutes_until": -25},
        {"event": "Flash Services PMI", "tier": "TIER_2",
         "time": release.strftime("%Y-%m-%d %H:%M:%S"), "minutes_until": -25},
    ]
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": drifted}, "XAU/USD", 4600.0,
        {"symbol": "XAU/USD"}, database=None)
    assert len(gem.calls) == 1
    assert len(tg.sent) == 1


def test_each_symbol_gets_its_own_card(monkeypatch):
    gem = _Gem()
    tg = _Tg()
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events()}, "XAU/USD", 4600.0,
        {"symbol": "XAU/USD"}, database=None)
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events()}, "WTI/USD", 86.0,
        {"symbol": "WTI/USD"}, database=None)
    assert len(gem.calls) == 2
    assert len(tg.sent) == 2
    assert {s for _, _, s in tg.sent} == {"XAU/USD", "WTI/USD"}


def test_wti_payload_carries_oil_macro(monkeypatch):
    class _OilAgent:
        def __init__(self, cfg):
            pass

        def analyze(self, data):
            return {"agent": "oil_macro", "direction": "SELL", "confidence": 44,
                    "bias": "BEARISH_OIL", "score": -0.5,
                    "summary": "Brent-WTI spread widening"}

    monkeypatch.setattr(ra, "OilMacroAgent", _OilAgent)
    gem = _Gem()
    tg = _Tg()
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events()}, "WTI/USD", 86.0,
        {"symbol": "WTI/USD"}, database=None)
    payload = gem.calls[0]
    assert payload["symbol"] == "WTI/USD"
    assert payload["oil_macro"]["direction"] == "SELL"
    assert "spread widening" in payload["oil_macro"]["summary"]


def test_outside_window_events_are_ignored(monkeypatch):
    gem = _Gem()
    tg = _Tg()
    ra._check_and_send_post_news(
        gem, tg, {"upcoming_events": _events(minute_offset=-90)}, "XAU/USD",
        4600.0, {"symbol": "XAU/USD"}, database=None)
    assert gem.calls == []


# ── 4) per-symbol card labels ──────────────────────────────────────────────
def _card_text(symbol, analysis):
    class _T:
        def send_message(self, text, urgent=False):
            self.last = text
            return True

    t = _T()
    svc = tb.TelegramService.__new__(tb.TelegramService)
    svc.send_message = t.send_message
    svc.send_post_news_analysis(analysis, "Flash PMI", symbol)
    return t.last


def test_wti_card_says_oil_impact():
    text = _card_text("WTI/USD", {"available": True, "surprise": "IN_LINE",
                                  "oil_impact": "BEARISH", "dxy_impact": "NEUTRAL",
                                  "confidence": 70, "recommendation": "oil weak",
                                  "key_insight": "spread"})
    assert "Oil Impact" in text
    assert "Gold Impact" not in text
    assert "BEARISH" in text


def test_gold_card_says_gold_impact():
    text = _card_text("XAU/USD", {"available": True, "surprise": "IN_LINE",
                                  "gold_impact": "BULLISH", "dxy_impact": "WEAKENING",
                                  "confidence": 70, "recommendation": "gold strong",
                                  "key_insight": "dxy"})
    assert "Gold Impact" in text
    assert "Oil Impact" not in text


# ── 5) the post-news prompt follows the symbol ─────────────────────────────
def test_post_news_prompt_names_wti(monkeypatch):
    import services.llm_review as llm
    svc = llm.GeminiReviewService({})
    svc.enabled = True
    prompts = []

    class _Resp:
        status_code = 200
        text = json.dumps({"candidates": [{"content": {"parts": [{"text": json.dumps(
            {"event": "x", "surprise": "IN_LINE", "oil_impact": "BULLISH",
             "dxy_impact": "NEUTRAL", "recommendation": "r", "confidence": 70,
             "key_insight": "k"})}]}}]})
        headers = {}

        def json(self):
            return json.loads(self.text)

    class _Sess:
        def post(self, url, params=None, json=None, timeout=None):
            prompts.append(json.get("contents")[0]["parts"][0]["text"])
            return _Resp()

    monkeypatch.setattr(svc, "session", _Sess())
    svc.interpret_post_news({"symbol": "WTI/USD", "event_name": "Flash PMI"})
    assert "Crude Oil (WTI/USD)" in prompts[0]
    assert '"oil_impact"' in prompts[0]
    assert "Gold Market Analyst" not in prompts[0]


def test_post_news_compact_payload_wti(monkeypatch):
    import services.llm_review as llm
    svc = llm.GeminiReviewService({})
    compact = svc._compact_post_news_payload(
        {"symbol": "WTI/USD", "event_name": "X",
         "oil_macro": {"direction": "SELL", "confidence": 44, "summary": "s"}})
    assert compact["oil_macro"]["direction"] == "SELL"
    compact_gold = svc._compact_post_news_payload({"symbol": "XAU/USD"})
    assert compact_gold["oil_macro"] is None


# ── 6) news-source dedup ───────────────────────────────────────────────────
def test_load_events_dedupes_across_sources(monkeypatch, tmp_path):
    from agents.news_risk_agent import NewsRiskAgent
    events_file = tmp_path / "events.json"
    events_file.write_text(json.dumps([
        {"event": "Flash Manufacturing PMI", "time": "2026-08-21 13:45:00", "tier": "TIER_2"},
        {"event": "Flash Manufacturing PMI", "time": "2026-08-21T13:45:00", "tier": "TIER_2"},
        {"event": "Flash Services PMI", "time": "2026-08-21 13:45:00", "tier": "TIER_2"},
    ]), encoding="utf-8")
    agent = NewsRiskAgent({"news_events_path": str(events_file)})
    monkeypatch.setattr(agent, "events_path", events_file)
    # block the live ForexFactory fetch + env/config sources
    monkeypatch.setenv("NEWS_EVENTS_JSON", "")
    monkeypatch.setattr(agent, "config", {"news_events_path": str(events_file)})
    from services import news_feed_forexfactory as nff
    monkeypatch.setattr(nff, "fetch_forexfactory_events", lambda: None)
    events = agent._load_events()
    names = [e.get("event") for e in events]
    assert names.count("Flash Manufacturing PMI") == 1
    assert names.count("Flash Services PMI") == 1
    assert len(events) == 2
