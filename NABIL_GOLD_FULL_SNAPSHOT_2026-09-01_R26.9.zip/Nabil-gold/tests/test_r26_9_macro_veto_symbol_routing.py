# -*- coding: utf-8 -*-
"""R26.9 (2026-09-01): the hard macro veto must be SYMBOL-ROUTED.

Production defect (operator report): oil (WTI) and the four forex pairs sent
no signals. Root cause - the hard macro veto (R26.2) and the mirrored thesis-
exit veto (R26.4) read a SINGLE fundamental key (``macro_fundamental``), which
is the dollar/gold macro-regime voice. Crude has its OWN fundamental agent
(``oil_macro``: EIA inventory surprise + OPEC tone + Brent-WTI spread) that the
Path-2 confirmation already routes to, but the hard veto ignored it - so a
dollar-strong tape made the gold macro say BEARISH_WTIUSD while oil
fundamentals said BULLISH_OIL, and the veto killed every correct oil BUY entry
and mirror-closed every correct open oil long (and refused to close wrong
shorts).

Fix under test:
  * oil symbol -> veto routes to ``oil_macro`` (its own fundamentals),
    fail-open when oil has no committed verdict.
  * gold + the configured ``macro_confirmation.symbols`` list -> keep reading
    ``macro_fundamental`` exactly as before.
  * any other known symbol -> fail-open (no veto), mirroring the Path-2
    confirmation routing which only judges listed symbols.
  * the nested-reader fallback now normalises ANY BULLISH*/BEARISH* token
    (BULLISH_EURUSD / BULLISH_USDCAD / BEARISH_WTIUSD ...), not a gold-only
    whitelist.
  * the R26.4 thesis-exit mirror passes the position symbol so the gate routes
    the correct voice; the exit agent book now carries ``oil_macro``.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services.admission_discipline_gates import (  # noqa: E402
    counter_macro_block, discipline_violations, _macro,
)


CFG = {"discipline_gates": {"enabled": True, "macro_block_conf": 55.0},
       "symbol": "XAU/USD",
       "signal_requirements": {"two_agent_entry": {"macro_confirmation": {
           "symbols": ["XAU/USD", "EUR/USD", "GBP/USD", "USD/CAD", "USD/JPY"]}}}}


def _dec(side, symbol, path="PATH_2_TWO_AGENT"):
    return {"decision": side, "symbol": symbol, "execution_path_id": path}


# ── 1) OIL routes to oil_macro, never to the dollar/gold macro ─────────────

def test_oil_entry_not_vetoed_by_gold_dollar_macro_when_oil_is_bullish():
    # dollar/gold macro reads bearish-for-oil at high conf, but oil
    # fundamentals are bullish -> a crude BUY must be allowed.
    allr = {
        "symbol": "WTI/USD",
        "macro_fundamental": {"macro_direction": {"bias": "BEARISH_WTIUSD", "confidence": 74}},
        "oil_macro": {"bias": "BULLISH_OIL", "direction": "BUY", "confidence": 76},
    }
    assert counter_macro_block(_dec("BUY", "WTI/USD"), CFG, allr) is None


def test_oil_entry_vetoed_by_oil_macro_against_it():
    # oil fundamentals bearish at >=55 -> an oil BUY is vetoed (correct voice).
    allr = {
        "symbol": "WTI/USD",
        "macro_fundamental": {"macro_direction": {"bias": "BULLISH_WTIUSD", "confidence": 70}},
        "oil_macro": {"bias": "BEARISH_OIL", "direction": "SELL", "confidence": 65},
    }
    res = counter_macro_block(_dec("BUY", "WTI/USD"), CFG, allr)
    assert res is not None and "HARD MACRO VETO" in res


def test_oil_fail_open_when_oil_macro_has_no_verdict():
    # oil agent WAIT / no files -> no oil verdict -> never veto on the dollar
    # macro for crude (category error removed).
    allr = {
        "symbol": "WTI/USD",
        "macro_fundamental": {"macro_direction": {"bias": "BEARISH_GOLD", "confidence": 90}},
        "oil_macro": {"bias": "NEUTRAL", "direction": "WAIT", "confidence": 0},
    }
    assert counter_macro_block(_dec("BUY", "WTI/USD"), CFG, allr) is None


def test_macro_voice_routes_oil_to_oil_macro():
    allr = {"symbol": "WTI/USD",
            "macro_fundamental": {"macro_direction": {"bias": "BEARISH_WTIUSD", "confidence": 80}},
            "oil_macro": {"bias": "BULLISH_OIL", "direction": "BUY", "confidence": 76}}
    voice = _macro(_dec("BUY", "WTI/USD"), allr, CFG)
    assert voice["bias"] == "BUY" and voice["conf"] == 76


# ── 2) GOLD is unchanged ───────────────────────────────────────────────────

def test_gold_still_judged_by_macro_fundamental():
    allr = {"symbol": "XAU/USD",
            "macro_fundamental": {"macro_direction": {"bias": "BEARISH_GOLD", "confidence": 74}}}
    res = counter_macro_block(_dec("BUY", "XAU/USD"), CFG, allr)
    assert res is not None and "HARD MACRO VETO" in res
    assert counter_macro_block(_dec("SELL", "XAU/USD"), CFG, allr) is None


def test_gold_aligned_passes():
    allr = {"symbol": "XAU/USD",
            "macro_fundamental": {"macro_direction": {"bias": "BULLISH_GOLD", "confidence": 80}}}
    assert counter_macro_block(_dec("BUY", "XAU/USD"), CFG, allr) is None


# ── 3) Forex symbol-suffixed tokens are normalised correctly ───────────────

def test_forex_suffixed_bias_normalises():
    # USD/CAD: dollar strength is BULLISH for USD/CAD; a SELL must veto, a
    # BUY pass. The token is BULLISH_USDCAD (not in any gold whitelist).
    allr = {"symbol": "USD/CAD",
            "macro_fundamental": {"macro_direction": {"bias": "BULLISH_USDCAD", "confidence": 86}}}
    assert counter_macro_block(_dec("SELL", "USD/CAD"), CFG, allr) is not None
    assert counter_macro_block(_dec("BUY", "USD/CAD"), CFG, allr) is None


def test_forex_eur_bearish_vetoes_buy():
    allr = {"symbol": "EUR/USD",
            "macro_fundamental": {"macro_direction": {"bias": "BEARISH_EURUSD", "confidence": 82}}}
    assert counter_macro_block(_dec("BUY", "EUR/USD"), CFG, allr) is not None
    assert counter_macro_block(_dec("SELL", "EUR/USD"), CFG, allr) is None


def test_below_floor_passes_even_for_routed_symbol():
    allr = {"symbol": "EUR/USD",
            "macro_fundamental": {"macro_direction": {"bias": "BEARISH_EURUSD", "confidence": 50}}}
    assert counter_macro_block(_dec("BUY", "EUR/USD"), CFG, allr) is None


# ── 4) PATH_9 / scalp remain exempt ────────────────────────────────────────

def test_path9_and_scalp_remain_exempt_for_oil():
    allr = {"symbol": "WTI/USD",
            "oil_macro": {"bias": "BEARISH_OIL", "direction": "SELL", "confidence": 80}}
    assert counter_macro_block(_dec("BUY", "WTI/USD", "PATH_9_LIQUIDITY_REVERSAL"), CFG, allr) is None
    assert counter_macro_block(_dec("BUY", "WTI/USD", "R25_SCALP"), CFG, allr) is None


# ── 5) the R26.4 exit mirror sees the correct voice for the symbol ─────────

def test_exit_mirror_oil_uses_oil_macro_via_manager():
    from agents.open_trades_manager import OpenTradesManager
    wti_cfg = {**CFG, "symbol": "WTI/USD"}
    mgr = OpenTradesManager(wti_cfg)
    # compacted exit book (oil_macro never votes -> direction WAIT, bias set)
    book = {
        "symbol": "WTI/USD",
        "macro_fundamental": {"label": "Macro", "direction": "SELL", "confidence": 74},
        "oil_macro": {"label": "Oil Macro", "direction": "WAIT",
                      "bias": "BULLISH_OIL", "confidence": 76},
    }
    # We HOLD an oil BUY (oil bullish). The opposite flip (SELL, i.e. closing
    # the long) is counter-oil-macro -> the mirror BLOCKS closing it.
    blocked, reason = mgr._opposite_exit_macro_blocked(book, "SELL", {"path": "PATH_2_TWO_AGENT"})
    assert blocked is True
    # HOLD an oil SELL (wrong vs bullish oil): the opposite flip (BUY = close
    # the short) is WITH oil -> not blocked, so the wrong trade can be closed.
    blocked2, _ = mgr._opposite_exit_macro_blocked(book, "BUY", {"path": "PATH_2_TWO_AGENT"})
    assert blocked2 is False


def test_discipline_violations_includes_routed_oil_veto():
    allr = {"symbol": "WTI/USD",
            "oil_macro": {"bias": "BEARISH_OIL", "direction": "SELL", "confidence": 65}}
    v = discipline_violations(_dec("BUY", "WTI/USD"), CFG, allr)
    assert any("MACRO VETO" in x for x in v)
