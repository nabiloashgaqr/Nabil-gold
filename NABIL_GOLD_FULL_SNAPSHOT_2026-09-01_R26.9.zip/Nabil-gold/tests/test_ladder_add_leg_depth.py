"""An add leg rests DEEPER than the lead leg — never chases market above it.

Live failure, 2026-08-18 01:26 XAU/USD (operator report: "الصفقة الإضافية
بالشراء تكون اسفل الاصلية وليس فوقها"):

    TRADE_..._9e237391  BUY LIMIT  4406.54  role PRIMARY  -> rested (correct)
    TRADE_..._448c910c  BUY MARKET 4423.08  role STANDBY  -> filled instantly,
                                                            stopped out

Two legs, one cycle. The PRIMARY was still a resting LIMIT below price,
while the STANDBY — the leg whose whole purpose is the DEEPER add — found
price inside its zone and market-converted 165 points ABOVE the lead. The
buy-the-dip rule that scale-in and cross-path enforce for later entries
was never applied inside the ladder's own assembly.

Two fixes, both pinned here:
  1. market conversion is PRIMARY-only: STANDBY/ADD_ON legs never convert
     to market (they rest deeper or they do not exist);
  2. ladder assembly drops any add leg whose entry is not deeper than the
     lead leg's entry (below for BUY, above for SELL).
"""

from __future__ import annotations

import io
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

SRC = io.open(ROOT / "scripts" / "run_analysis.py", encoding="utf-8").read()


# ── fix 1: market conversion is PRIMARY-only ────────────────────────────────

def test_add_legs_never_market_convert():
    block = SRC.split("market_conversion = False")[1][:2500]
    assert '_leg_role in {"STANDBY", "ADD_ON"}' in block
    assert "return None" in block.split('_leg_role in {"STANDBY", "ADD_ON"}')[1][:600]


def test_the_refusal_names_the_rule():
    assert "add legs never chase market" in SRC


def test_primary_conversion_still_exists():
    """The 11:06 fix (primary converts when price reaches the zone) must
    survive: only the add legs lost the conversion path."""
    assert "Session-plan leg converted to market" in SRC
    assert "convert_touched_zone_to_market" in SRC


# ── fix 2: ladder assembly enforces depth ───────────────────────────────────

def test_ladder_drops_add_legs_not_deeper_than_lead():
    assert "add legs must be the deeper price" in SRC
    block = SRC.split("Buy-the-dip invariant for the ladder itself")[1][:2500]
    assert '(_leg_entry < _lead_entry) if _lead_dir == "BUY" else (_leg_entry > _lead_entry)' in block


def test_the_drop_is_recorded_for_the_audit_trail():
    block = SRC.split("Buy-the-dip invariant for the ladder itself")[1][:2500]
    assert "_ladder_stop(" in block, "a silent drop is the old defect in new clothes"


def test_depth_check_runs_before_orders_are_created():
    invariant_at = SRC.index("Buy-the-dip invariant for the ladder itself")
    creation_at = SRC.index("created = 0", invariant_at)
    save_at = SRC.index("database.save_trade(ladder_decision)", invariant_at)
    assert invariant_at < creation_at < save_at
