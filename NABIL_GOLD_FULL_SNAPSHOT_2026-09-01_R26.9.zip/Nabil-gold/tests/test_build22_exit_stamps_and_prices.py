"""BUILD 22 (2026-08-21): close stamps + per-symbol prices.

Live incidents fixed here:
  1. the tick manager wrote TP2_HIT without closed_at, so the post-TP2 2.5h
     block (and WIN/LOSS cooldowns) measured from the OPEN time - a pending
     ADD leg slipped through five minutes after a real TP2 (2026-08-21
     09:11 TP2, 09:16 pending).
  2. rich cards shared one _last_price across rows - a gold TP2 card showed
     the oil price (85.93).
  3. the hourly status measured every open trade with the cycle's symbol
     price - a WTI row compared against the gold price printed fake PnL and
     a fake "✅TP1 reached" mark.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from types import SimpleNamespace

import pytest

import scripts.run_tick_manager as rtm
import scripts.run_analysis as ra


# ── 1) close stamps ─────────────────────────────────────────────────────────
def test_iso_from_epoch_converts_broker_seconds():
    # 2026-08-21 09:11:00 UTC
    ts = int(datetime(2026, 8, 21, 9, 11, 0, tzinfo=timezone.utc).timestamp())
    stamp = rtm._iso_from_epoch(ts)
    assert stamp == "2026-08-21T09:11:00Z"
    assert rtm._iso_from_epoch(0) is None
    assert rtm._iso_from_epoch(None) is None
    assert rtm._iso_from_epoch("junk") is None


def test_close_stamp_prefers_the_broker_deal_time():
    ts = int(datetime(2026, 8, 21, 9, 11, 0, tzinfo=timezone.utc).timestamp())
    stamp = rtm._close_stamp({"time": ts, "price": 4600.0})
    assert stamp == "2026-08-21T09:11:00Z"
    # no deal time -> now (still a valid ISO with Z)
    fallback = rtm._close_stamp({"price": 4600.0})
    assert fallback.endswith("Z")


def test_broker_close_writes_closed_at(monkeypatch):
    """The live mirror path must include closed_at/close_time."""
    import io
    src = io.open("scripts/run_tick_manager.py", encoding="utf-8").read()
    assert '"closed_at": _closed, "close_time": _closed' in src
    assert "_closed = _close_stamp(exit_info)" in src
    # the fallback (no deal) path stamps too
    assert '_closed = _now_iso_stamp()' in src


def test_thesis_exit_writes_closed_at():
    import io
    src = io.open("scripts/run_tick_manager.py", encoding="utf-8").read()
    assert '"closed_at": _closed, "close_time": _closed' in src


# ── 2) per-trade card prices ────────────────────────────────────────────────
def test_notify_uses_the_trades_own_price():
    tm = rtm.TickManager({"symbol": "XAU/USD",
                          "auction_flow": {"enabled": False}})
    captured = {}

    class _Tg:
        def send_trade_events(self, trade, events, current_price, pnl, evaluation):
            captured["price"] = current_price
            captured["events"] = events
            return True

        def send_message(self, body, urgent=False):
            return True

    tm.telegram = _Tg()
    tm._last_price = 4600.52  # the shared stale price (gold cycle)
    tm._last_prices["TRADE_WTI_1"] = 86.20  # this trade's real oil price
    tm._notify("🧪 DEMO: trailing stop moved to 86.80 (confirmed at broker)",
               {"id": "TRADE_WTI_1", "symbol": "WTI/USD", "status": "OPEN",
                "entry_price": 86.82, "stop_loss": 86.80, "pnl_points": 0.0})
    assert captured["price"] == 86.20
    assert captured["events"] == ["TRAILING_SL_UPDATED"]


def test_notify_uses_row_own_price_never_shared():
    """BUILD 31 (2026-08-24): the card price must come from the ROW's own
    symbol, never from a shared/foreign price. Unknown row with a stored
    current_price -> that stored price; with nothing -> 0.0 (no leak)."""
    tm = rtm.TickManager({"symbol": "XAU/USD",
                          "auction_flow": {"enabled": False}})
    captured = {}

    class _Tg:
        def send_trade_events(self, trade, events, current_price, pnl, evaluation):
            captured["price"] = current_price
            return True

        def send_message(self, body, urgent=False):
            return True

    tm.telegram = _Tg()
    # No per-trade tick registered, but the row carries its own price.
    tm._notify("🧪 DEMO: breakeven armed @ 4532.54 (confirmed at broker)",
               {"id": "TRADE_UNKNOWN", "symbol": "XAU/USD", "status": "OPEN",
                "entry_price": 4532.54, "current_price": 4531.10,
                "pnl_points": 0.0})
    assert captured["price"] == 4531.10
    # And with nothing at all, the card shows NO price rather than a foreign one.
    captured.clear()
    tm._notify("🧪 DEMO: breakeven armed @ 4532.54 (confirmed at broker)",
               {"id": "TRADE_EMPTY", "symbol": "XAU/USD", "status": "OPEN",
                "entry_price": 4532.54, "pnl_points": 0.0})
    assert captured["price"] == 0.0


# ── 3) hourly status per-symbol prices ──────────────────────────────────────
class _DB:
    def __init__(self, trades):
        self._trades = trades

    def get_open_trades(self):
        return self._trades


def _gold_trade():
    return {"id": "TRADE_G1", "symbol": "XAU/USD", "type": "BUY", "status": "OPEN",
            "entry_price": 4590.0, "tp1": 4625.0, "tp2": 4675.0,
            "created_at": "2026-08-21T09:16:39+00:00"}


def _wti_trade():
    return {"id": "TRADE_W1", "symbol": "WTI/USD", "type": "BUY", "status": "OPEN",
            "entry_price": 86.00, "tp1": 87.00, "tp2": 88.00,
            "created_at": "2026-08-21T08:00:00+00:00"}


def _status(trades, monkeypatch, prices):
    monkeypatch.setattr(
        ra, "_trade_row_price",
        lambda symbol, current_symbol, current_price, all_results, config:
            prices.get(symbol, 0.0))
    decision = {"symbol": "XAU/USD", "decision": "WAIT", "current_price": 4600.52}
    all_results = {"symbol": "XAU/USD"}
    cfg = {"symbol": "XAU/USD"}
    return ra._build_market_status_message(decision, all_results, _DB(trades), cfg)


def test_status_uses_each_symbols_own_price(monkeypatch):
    text = _status([_gold_trade(), _wti_trade()], monkeypatch,
                   {"XAU/USD": 4600.52, "WTI/USD": 86.50})    # gold row: (4600.52 - 4590) * 10 = +105.2 pts, 105/350 = 30% toward TP1
    assert "+105" in text
    assert "30%➜TP1" in text
    # oil row: (86.50 - 86.00) * 100 = +50 pts (oil point = $0.01), 50/100 = 50%
    assert "+50" in text
    assert "50%➜TP1" in text


def test_status_never_fakes_tp1_for_another_symbol(monkeypatch):
    # the gold cycle price (4600.52) must NOT make the WTI row claim TP1
    text = _status([_wti_trade()], monkeypatch, {"WTI/USD": 86.50})
    assert "✅TP1" not in text
    assert "50%➜TP1" in text  # real progress, not a fake completion


def test_status_falls_back_to_stored_pnl_without_live_price(monkeypatch):
    wti = _wti_trade()
    wti["current_pnl_points"] = 30.0
    text = _status([wti], monkeypatch, {"XAU/USD": 4600.52})  # no WTI price
    # stored fallback: +30 pts (oil) -> $0.3, NOT measured with the gold price
    assert "+30" in text
    assert "✅TP1" not in text


def test_trade_row_price_shared_snapshot_fallback(monkeypatch):
    monkeypatch.setattr(
        ra, "MarketDataService",
        lambda cfg: SimpleNamespace(get_ohlcv=lambda *a, **k: {"current_price": 86.60}))
    all_results = {"shared_market_data": {"prices": {"WTI/USD": 86.40}}}
    price = ra._trade_row_price("WTI/USD", "XAU/USD", 4600.0, all_results, {})
    assert price == 86.40  # shared snapshot wins before the live fetch


def test_trade_row_price_same_symbol_uses_cycle_price(monkeypatch):
    assert ra._trade_row_price("XAU/USD", "XAU/USD", 4600.0, {}, {}) == 4600.0


def test_trade_row_price_unknown_symbol_without_sources_is_zero(monkeypatch):
    monkeypatch.setattr(
        ra, "MarketDataService",
        lambda cfg: SimpleNamespace(get_ohlcv=lambda *a, **k: {"current_price": 0.0}))
    assert ra._trade_row_price("WTI/USD", "XAU/USD", 4600.0, {}, {}) == 0.0


# ── 4) backfill leaves live rows untouched ──────────────────────────────────
def test_backfill_candidate_filter():
    import scripts.backfill_close_stamps as bf
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    rows = [
        {"id": "T1", "status": "TP2_HIT", "created_at": f"{today}T05:31:27+00:00"},          # candidate
        {"id": "T2", "status": "OPEN", "created_at": f"{today}T09:16:39+00:00"},              # untouched
        {"id": "T3", "status": "TP2_HIT", "created_at": f"{today}T05:31:27+00:00",
         "closed_at": "2026-08-21T09:11:00Z"},                                                # already stamped
        {"id": "T4", "status": "CANCELLED", "created_at": f"{today}T02:00:00+00:00"},         # untouched
    ]
    candidates = [r for r in rows
                  if str(r.get("status") or "").upper() in bf.CLOSED_STATUSES
                  and str(r.get("status") or "").upper() not in bf.UNTOUCHABLE
                  and not (r.get("closed_at") or r.get("close_time"))]
    assert [r["id"] for r in candidates] == ["T1"]
    # statuses the backfill must never touch
    for status in ("OPEN", "PARTIAL", "TP1_HIT", "PENDING", "CANCELLED"):
        assert status in bf.UNTOUCHABLE


# ── 5) BUILD 22.1: broker clock +3h - stamps must never be future ───────────
def test_close_stamp_clamps_future_deal_time():
    import time as _time
    now = _time.time()
    future = now + 3 * 3600  # broker clock 3h ahead (observed live)
    stamp = rtm._close_stamp({"time": future, "price": 4600.0}, now_ts=now)
    # clamped to the discovery moment, never a future stamp
    parsed = datetime.fromisoformat(stamp.replace("Z", "+00:00")).timestamp()
    assert parsed <= _time.time() + 5
    assert abs(parsed - now) < 5  # discovery time, not the +3h deal time


def test_close_stamp_accepts_past_deal_time():
    now = float(int(datetime(2026, 8, 21, 11, 30, 0, tzinfo=timezone.utc).timestamp()))
    past = now - 600  # ten minutes ago - sane broker time
    stamp = rtm._close_stamp({"time": past, "price": 4600.0}, now_ts=now)
    assert stamp == "2026-08-21T11:20:00Z"


def test_close_stamp_within_tolerance_keeps_deal_time():
    now = float(int(datetime(2026, 8, 21, 11, 30, 0, tzinfo=timezone.utc).timestamp()))
    deal = now + 60  # one minute ahead - within the 5-minute tolerance
    stamp = rtm._close_stamp({"time": deal, "price": 4600.0}, now_ts=now)
    assert stamp == "2026-08-21T11:31:00Z"


def test_corrected_deal_stamp_subtracts_measured_skew():
    import scripts.backfill_close_stamps as bf
    # raw broker stamp 12:13:44, skew +3h -> 09:13:44 real
    raw = datetime(2026, 8, 21, 12, 13, 44, tzinfo=timezone.utc).timestamp()
    now = datetime(2026, 8, 21, 11, 30, 0, tzinfo=timezone.utc).timestamp()
    stamp = bf.corrected_deal_stamp(raw, skew=3 * 3600, now_ts=now)
    assert stamp == "2026-08-21T09:13:44Z"


def test_corrected_deal_stamp_ignores_absurd_skew():
    import scripts.backfill_close_stamps as bf
    raw = datetime(2026, 8, 21, 12, 13, 44, tzinfo=timezone.utc).timestamp()
    now = datetime(2026, 8, 21, 11, 30, 0, tzinfo=timezone.utc).timestamp()
    # skew below the 5-minute floor or above the 12-hour ceiling: no correction
    assert bf.corrected_deal_stamp(raw, skew=100, now_ts=now) == bf.corrected_deal_stamp(raw, skew=0, now_ts=now)
    # with a small skew the raw stamp stays FUTURE -> clamped to now
    stamp = bf.corrected_deal_stamp(raw, skew=100, now_ts=now)
    parsed = datetime.fromisoformat(stamp.replace("Z", "+00:00")).timestamp()
    assert abs(parsed - now) < 1
    # huge skew -> no correction -> still future -> clamp to now
    stamp2 = bf.corrected_deal_stamp(raw, skew=200 * 3600, now_ts=now)
    parsed2 = datetime.fromisoformat(stamp2.replace("Z", "+00:00")).timestamp()
    assert abs(parsed2 - now) < 1


def test_corrected_deal_stamp_no_skew_keeps_past_time():
    import scripts.backfill_close_stamps as bf
    raw = datetime(2026, 8, 21, 10, 0, 0, tzinfo=timezone.utc).timestamp()
    now = datetime(2026, 8, 21, 11, 30, 0, tzinfo=timezone.utc).timestamp()
    assert bf.corrected_deal_stamp(raw, skew=None, now_ts=now) == "2026-08-21T10:00:00Z"


def test_broker_clock_skew_measurement(monkeypatch):
    import scripts.backfill_close_stamps as bf
    now = float(int(datetime(2026, 8, 21, 11, 30, 0, tzinfo=timezone.utc).timestamp()))
    monkeypatch.setattr(bf.time, "time", lambda: now)
    tick = SimpleNamespace(time_msc=int((now + 3 * 3600) * 1000))
    fake_mt5 = SimpleNamespace(symbol_info_tick=lambda sym: tick)
    assert abs(bf.broker_clock_skew(fake_mt5) - 3 * 3600) < 1
    # dead tick -> None
    fake_mt5_dead = SimpleNamespace(symbol_info_tick=lambda sym: SimpleNamespace(time_msc=0))
    assert bf.broker_clock_skew(fake_mt5_dead) is None


# ── 6) BUILD 22.2: oil points in every close path ───────────────────────────
def test_no_gold_point_factor_remains_in_close_paths():
    import io
    src = io.open("scripts/run_tick_manager.py", encoding="utf-8").read()
    # the three close paths (reconciliation / thesis / broker mirror) must
    # divide by the row's point size, never the hardcoded gold *10
    assert "(close - entry) * 10.0" not in src
    assert "entry) * 10.0" not in src
    assert 'point_size(str(row.get("symbol") or "XAU/USD"), self.config)' in src


def test_oil_point_math_for_close_paths():
    from utils.instruments import point_size
    pv = point_size("WTI/USD", {})
    assert pv == 0.01
    # the -120$ live close: 85.62 - 86.82 = -1.20 -> -120 oil points
    pnl_pts = (85.62 - 86.82) / pv
    assert abs(pnl_pts - (-120.0)) < 0.01
    # gold stays unchanged: 4600 - 4532.54 = 67.46 -> +674.6 pts
    pnl_gold = (4600.0 - 4532.54) / point_size("XAU/USD", {})
    assert abs(pnl_gold - 674.6) < 0.01


def test_rich_card_carries_broker_usd():
    row = {"status": "OPEN", "stop_loss": 85.62, "entry_price": 86.82,
           "pnl_points": -120.0, "sl_moved_to_entry": False}
    event, updates, new_status, pnl = rtm.TickManager._rich_card_payload(
        "🧪 DEMO: MT5 applied: position closed @ 85.62 (SL_HIT) · vol 0.1 · "
        "ticket 489284781 -120 pts / -120.00$", row)
    assert event == "SL_HIT"
    assert updates["realized_usd"] == -120.0
    assert updates["close_price"] == 85.62


def test_rich_card_close_card_shows_usd():
    """The full card text for an oil close must contain points AND dollars."""
    import services.telegram_bot as tb

    class _Tg(tb.TelegramService):
        def __init__(self):
            self.sent = None

        def send_message(self, text, urgent=False):
            self.sent = text
            return True

    tg = _Tg()
    trade = {"id": "T_WTI", "symbol": "WTI/USD", "type": "BUY",
             "entry_price": 86.82, "stop_loss": 85.62}
    evaluation = {
        "old_status": "OPEN", "new_status": "SL_HIT",
        "updates": {"close_price": 85.62, "final_pnl": -120.0,
                    "realized_usd": -120.0},
        "pnl_points": -120.0,
        "cancel_reason_code": "", "reasons": [],
    }
    tg.send_trade_events(trade, ["SL_HIT"], 85.62, -120.0, evaluation)
    assert "Actual PnL" in tg.sent
    assert "-120.0 pts (-120.00$)" in tg.sent
    assert "Exit Price" in tg.sent
