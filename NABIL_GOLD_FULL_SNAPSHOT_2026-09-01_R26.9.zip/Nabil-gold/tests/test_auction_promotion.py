"""2026-08-19 phase-2 tests: auction_flow promotion mechanism (config-gated)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from agents.decision_agent import DecisionAgent  # noqa: E402
from services.thesis_consensus import (  # noqa: E402
    _agent_families,
    _voting_agents,
    evaluate_directional_admission,
)
from utils.helpers import get_agent_weights  # noqa: E402

FIVE = {
    "classical": 0.25,
    "technical": 0.20,
    "smc": 0.20,
    "price_action": 0.20,
    "multitimeframe": 0.15,
}


def _base(promotion_enabled=False, weight=0.05):
    return {
        "agent_weights": dict(FIVE),
        "auction_promotion": {"enabled": promotion_enabled, "weight": weight},
        "risk_settings": {"min_confidence": 65},
        "signal_requirements": {
            "min_agents_agree": 3,
            "min_consensus_confidence": 72,
            "agent_min_confidence": 65,
            "two_agent_entry": {"enabled": True, "min_agents_agree": 2, "min_consensus_confidence": 72},
            "path5_two_agent_auction": {"enabled": True, "min_agents_agree": 2,
                                        "min_consensus_confidence": 72, "min_auction_confidence": 72},
            "family_diversity": {
                "enabled": True,
                "families": {
                    "trend": ["technical", "multitimeframe", "classical"],
                    "structure": ["smc", "price_action"],
                },
                "single_family_confirmers": ["macro"],
            },
        },
    }


class TestPromotionOff:
    def test_weights_unchanged(self):
        w = get_agent_weights(_base(False))
        assert "auction_flow" not in w
        assert w == FIVE

    def test_voters_five(self):
        assert _voting_agents(_base(False)) == ("technical", "multitimeframe", "classical", "smc", "price_action")

    def test_decision_agent_excludes_auction(self):
        da = DecisionAgent(_base(False))
        assert "auction_flow" not in da.voting_agents

    def test_defaults_off(self):
        # no auction_promotion section at all -> off
        cfg = _base(False)
        cfg.pop("auction_promotion")
        assert "auction_flow" not in get_agent_weights(cfg)


class TestPromotionOn:
    def test_weights_include_auction_proportional(self):
        w = get_agent_weights(_base(True, 0.05))
        assert abs(w["auction_flow"] - 0.05) < 1e-9
        assert abs(sum(w.values()) - 1.0) < 1e-9
        # the five keep their RELATIVE ratios (classical: 0.25 * 0.95)
        assert abs(w["classical"] - 0.2375) < 1e-9
        assert abs(w["price_action"] - 0.19) < 1e-9

    def test_voters_six(self):
        assert _voting_agents(_base(True))[-1] == "auction_flow"

    def test_decision_agent_includes_auction(self):
        da = DecisionAgent(_base(True))
        assert "auction_flow" in da.voting_agents

    def test_family_map_auction_tape(self):
        assert _agent_families(_base(True))["auction_flow"] == "tape"

    def _details(self):
        return {
            "technical": {"signal": "BUY", "confidence": 75},
            "multitimeframe": {"signal": "BUY", "confidence": 75},
            "auction_flow": {"signal": "BUY", "confidence": 75},
        }

    def test_auction_supports_path1_when_promoted(self):
        cfg = _base(True)
        r = evaluate_directional_admission("BUY", self._details(), cfg)
        assert r["allow"] is True
        assert r["path"] == "THREE_AGENT_CONSENSUS"
        assert set(r["supporter_families"]) == {"trend", "tape"}

    def test_auction_remains_external_when_not_promoted(self):
        cfg = _base(False)
        # technical + smc (not an all-trend pair -> Rule B allows auction)
        details = {
            "technical": {"signal": "BUY", "confidence": 75},
            "smc": {"signal": "BUY", "confidence": 75},
            "auction_flow": {"signal": "BUY", "confidence": 75},
        }
        r = evaluate_directional_admission("BUY", details, cfg)
        assert r["allow"] is True
        # without promotion: only technical+smc vote -> auction confirms Path 5
        assert r["path"] == "TWO_AGENT_AUCTION"

    def test_rule_b_still_blocks_pure_trend_without_promotion(self):
        cfg = _base(False)
        details = {
            "technical": {"signal": "BUY", "confidence": 75},
            "multitimeframe": {"signal": "BUY", "confidence": 75},
            "auction_flow": {"signal": "BUY", "confidence": 75},
        }
        r = evaluate_directional_admission("BUY", details, cfg)
        assert r.get("path5_family_refused") is True
        assert r.get("allow") is False

    def test_promoted_auction_not_double_counted_in_path5(self):
        # book = technical + auction only: with promotion ON auction is a voter,
        # so it must NOT also confirm Path 5 (double counting guard)
        cfg = _base(True)
        details = {
            "technical": {"signal": "BUY", "confidence": 75},
            "auction_flow": {"signal": "BUY", "confidence": 75},
        }
        r = evaluate_directional_admission("BUY", details, cfg)
        assert r.get("path5_disabled_auction_is_voter") is True
        assert r.get("allow") is False

    def test_promotion_weight_cap(self):
        w = get_agent_weights(_base(True, 0.9))  # insane config gets capped to 0.20
        assert w["auction_flow"] <= 0.20 + 1e-9
