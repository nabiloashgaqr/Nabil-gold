"""Gemini asks the API once per quarter hour, and only for a two-agent book.

Operator 2026-08-18i. The quota kept dying before the trading day did:
  * a standing two-agent candidate asked Gemini every 5-minute cycle —
    12 near-identical asks in one hour on 2026-08-17;
  * hourly WAIT cycles burned 3 more calls each (market context + news +
    macro reviews) for display-only words no gate ever read;
  * on 2026-08-18 01:21 the daily quota (RPD) was exhausted before London.

Policy now: ONE consuming job — confirming a Path-3 two-agent candidate —
throttled via a disk cache (each cycle is a fresh process) to one API ask
per symbol+side per confirmation_cache_minutes. The cached verdict is
REUSED: a cached yes confirms, a cached no refuses. Open trade or not is
irrelevant. Post-news TIER_1/TIER_2 briefings survive; everything else in
the analysis cycle is retired.
"""

from __future__ import annotations

import io
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.gemini_confirm_cache import load_confirmation, store_confirmation

SRC = io.open(ROOT / "scripts" / "run_analysis.py", encoding="utf-8").read()

TTL = 15.0


def _review(verdict="BUY", confidence=80):
    return {"verdict": verdict, "confidence": confidence, "available": True}


# ── the cache itself ────────────────────────────────────────────────────────

def test_verdict_is_reused_inside_the_window(tmp_path: Path):
    store_confirmation("XAU/USD", "BUY", _review(), root=tmp_path, now=1000.0)
    cached = load_confirmation("XAU/USD", "BUY", max_age_minutes=TTL,
                               root=tmp_path, now=1000.0 + 14 * 60)
    assert cached is not None
    assert cached["verdict"] == "BUY"


def test_window_expiry_allows_a_fresh_ask(tmp_path: Path):
    store_confirmation("XAU/USD", "BUY", _review(), root=tmp_path, now=1000.0)
    assert load_confirmation("XAU/USD", "BUY", max_age_minutes=TTL,
                             root=tmp_path, now=1000.0 + 16 * 60) is None


def test_a_cached_no_is_also_reused(tmp_path: Path):
    """The throttle is symmetric: a refusal holds the window too, else a
    NO would retry every 5 minutes and the burn returns."""
    store_confirmation("XAU/USD", "BUY", _review(verdict="WAIT", confidence=40),
                       root=tmp_path, now=1000.0)
    cached = load_confirmation("XAU/USD", "BUY", max_age_minutes=TTL,
                               root=tmp_path, now=1000.0 + 300)
    assert cached is not None
    assert cached["verdict"] == "WAIT"


def test_side_flip_is_a_new_question(tmp_path: Path):
    store_confirmation("XAU/USD", "BUY", _review(), root=tmp_path, now=1000.0)
    assert load_confirmation("XAU/USD", "SELL", max_age_minutes=TTL,
                             root=tmp_path, now=1000.0 + 60) is None


def test_unavailable_results_are_never_cached(tmp_path: Path):
    """A 503/quota failure must not lock the door for 15 minutes."""
    store_confirmation("XAU/USD", "BUY",
                       {"available": False, "reason": "HTTP 503"},
                       root=tmp_path, now=1000.0)
    assert load_confirmation("XAU/USD", "BUY", max_age_minutes=TTL,
                             root=tmp_path, now=1000.0 + 60) is None


def test_symbols_are_isolated(tmp_path: Path):
    store_confirmation("XAU/USD", "BUY", _review(), root=tmp_path, now=1000.0)
    assert load_confirmation("WTI/USD", "BUY", max_age_minutes=TTL,
                             root=tmp_path, now=1000.0 + 60) is None


def test_corrupt_cache_reads_as_no_memory(tmp_path: Path):
    from services.gemini_confirm_cache import cache_path
    path = cache_path(tmp_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("{broken", encoding="utf-8")
    assert load_confirmation("XAU/USD", "BUY", root=tmp_path) is None


# ── the wiring ──────────────────────────────────────────────────────────────

def test_path3_confirmation_goes_through_the_cache():
    block = SRC.split("QUARTER-HOUR THROTTLE")[1][:2500]
    assert "load_confirmation(symbol, side" in block
    assert "store_confirmation(symbol, side, gemini_review)" in block
    assert "confirmation_cache_minutes" in block


def test_wait_cycle_reviews_are_retired():
    assert "GEMINI HAS ONE CONSUMING JOB" in SRC
    consuming_block = SRC.split("GEMINI HAS ONE CONSUMING JOB")[1][:3000]
    for retired in ("analyze_market_context", "interpret_news_context",
                    "interpret_macro_context"):
        assert retired not in consuming_block, (
            f"{retired} crept back into the analysis cycle")


def test_post_news_briefing_survives():
    consuming_block = SRC.split("GEMINI HAS ONE CONSUMING JOB")[1][:3000]
    assert "_check_and_send_post_news" in consuming_block


def test_shipped_config_carries_the_ttl():
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    assert float(cfg["llm_review"]["confirmation_cache_minutes"]) == 15
