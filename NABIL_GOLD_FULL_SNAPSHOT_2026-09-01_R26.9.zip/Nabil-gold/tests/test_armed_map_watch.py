"""The map that would have sold 4399 must never again die unseen.

Post-mortem 2026-08-19: the repaired SMC agent, replayed over the 4399
raid, produced a SELL LIQUIDITY_REVERSAL at 4396.5 — quality 76,
dominance 92.2, return 79, trigger 87 REJECTION_CONFIRMED — clearing
every Path-4 floor except the auction read (flow sat WAIT 57-62% all
afternoon). Under the old flow that map lived and died in silence while
six losing BUY adds went out; the operator saw the bleeding, never the
cure.

The ARMED MAP card fires when a Path-4-grade map is waiting on auction
ALONE, throttled on change (NEW / FLIP / LEVEL MOVED / hourly reminder),
display-only. Section 5 of the correlation report measures the waiting
maps' would-have outcomes so the auction bar itself faces Thursday's
numbers.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from services.armed_map_watch import (
    DEFAULTS,
    armed_map_review,
    decide_card,
    should_clear,
    watch_config,
)

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))

T0 = 1_000_000.0
CFG = dict(DEFAULTS)


def _raid_map(**overrides):
    """The exact 4399 replay candidate."""
    c = {
        "direction": "SELL",
        "setup_type": "LIQUIDITY_REVERSAL",
        "entry_price": 4396.5,
        "stop_loss": 4398.74,
        "quality_score": 76.0,
        "thesis_dominance_score": 92.2,
        "return_probability_score": 79.0,
        "trigger_score": 87.0,
        "trigger_ready": True,
    }
    c.update(overrides)
    return c


def _silent_auction(conf=58.0):
    return {"direction": "WAIT", "confidence": conf}


# ── the review: Path-4 grade, auction the only missing witness ──────────────

def test_the_4399_map_is_recognised_as_armed():
    review = armed_map_review(_raid_map(), _silent_auction(), 0, CONFIG)
    assert review["armed"] is True
    assert review["direction"] == "SELL"
    assert "auction" in review["reason"]


def test_a_map_below_the_floors_is_not_armed():
    review = armed_map_review(_raid_map(quality_score=55.0), _silent_auction(), 0, CONFIG)
    assert review["armed"] is False
    assert "quality" in review["reason"]


def test_an_unready_trigger_is_not_armed():
    review = armed_map_review(_raid_map(trigger_ready=False), _silent_auction(), 0, CONFIG)
    assert review["armed"] is False


def test_qualified_opposition_disarms_the_card():
    review = armed_map_review(_raid_map(), _silent_auction(), 1, CONFIG)
    assert review["armed"] is False


def test_a_confirming_auction_hands_the_map_to_path4():
    """When flow already confirms, Path 4 owns it — no card."""
    review = armed_map_review(
        _raid_map(), {"direction": "SELL", "confidence": 80.0}, 0, CONFIG)
    assert review["armed"] is False
    assert "Path 4" in review["reason"]


def test_the_card_names_what_it_waits_for():
    review = armed_map_review(_raid_map(), _silent_auction(58.0), 0, CONFIG)
    assert review["auction_now"] == "WAIT 58%"
    assert review["auction_needed"].startswith("SELL >=")


# ── the throttle ────────────────────────────────────────────────────────────

def test_first_armed_map_sends_new():
    review = armed_map_review(_raid_map(), _silent_auction(), 0, CONFIG)
    verdict = decide_card(None, review, CFG, now=T0)
    assert verdict["send"] is True
    assert verdict["kind"] == "NEW"


def test_unchanged_map_next_cycle_is_suppressed():
    review = armed_map_review(_raid_map(), _silent_auction(), 0, CONFIG)
    first = decide_card(None, review, CFG, now=T0)
    second = decide_card(first["state"], review, CFG, now=T0 + 300)
    assert second["send"] is False


def test_direction_flip_sends_immediately():
    sell = armed_map_review(_raid_map(), _silent_auction(), 0, CONFIG)
    first = decide_card(None, sell, CFG, now=T0)
    buy = armed_map_review(
        _raid_map(direction="BUY", entry_price=4360.0), _silent_auction(), 0, CONFIG)
    flip = decide_card(first["state"], buy, CFG, now=T0 + 300)
    assert flip["send"] is True
    assert flip["kind"] == "FLIP"


def test_material_entry_move_sends_after_floor():
    review = armed_map_review(_raid_map(), _silent_auction(), 0, CONFIG)
    first = decide_card(None, review, CFG, now=T0)
    moved = armed_map_review(
        _raid_map(entry_price=4396.5 - 3.5), _silent_auction(), 0, CONFIG)  # 35 gold pts
    verdict = decide_card(first["state"], moved, CFG,
                          now=T0 + float(CFG["min_minutes_between_cards"]) * 60 + 1)
    assert verdict["send"] is True
    assert verdict["kind"] == "MOVED"


def test_grace_window_keeps_state_for_flickers():
    review = armed_map_review(_raid_map(), _silent_auction(), 0, CONFIG)
    state = decide_card(None, review, CFG, now=T0)["state"]
    assert should_clear(state, CFG, now=T0 + 300) is False
    assert should_clear(state, CFG, now=T0 + float(CFG["clear_grace_minutes"]) * 60 + 60) is True


# ── wiring & measurement ────────────────────────────────────────────────────

def test_run_analysis_carries_the_card():
    import io
    src = io.open(ROOT / "scripts" / "run_analysis.py", encoding="utf-8").read()
    assert "ARMED MAP card" in src
    assert "armed_map_review" in src
    assert "ARMED MAP suppressed (unchanged)" in src
    block = src.split("ARMED MAP card (operator 2026-08-19)")[1][:6000]
    assert "save_trade" not in block, "the card must stay display-only"


def test_correlation_report_measures_waiting_maps():
    import io
    src = io.open(ROOT / "scripts" / "agent_correlation_report.py", encoding="utf-8").read()
    assert "ARMED MAPS THAT WAITED ON AUCTION" in src
    assert "min_auction_confidence" in src


def test_shipped_config_carries_the_watch():
    # 2026-08-30 (operator order): ARMED MAP watch cards OFF - PATH 9 now
    # trades the orphan-raid reversal live, so the display card is retired.
    watch = CONFIG["session_plan_delivery"]["armed_map_watch"]
    assert watch["enabled"] is False


def test_watch_config_reads_operator_overrides():
    cfg = watch_config({"session_plan_delivery": {"armed_map_watch": {
        "reminder_interval_minutes": 120}}})
    assert cfg["reminder_interval_minutes"] == 120
    assert cfg["min_minutes_between_cards"] == DEFAULTS["min_minutes_between_cards"]
