"""The provenance backfill lifts snapshot fields up — and only fills gaps.

The provenance patch fixed NEW rows; TRADE_20260817_110616 (saved minutes
before it) still answered null because its route lived only inside its own
signal_snapshot. The backfill copies those values to the top level once,
without ever overwriting a value the new save path already wrote, and
without touching rows that have no snapshot.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))

from scripts.backfill_trade_provenance import backfill  # noqa: E402


def _legacy_row() -> dict:
    """A pre-patch row: nulls at top level, full values in the snapshot."""
    return {
        "id": "TRADE_20260817_110616_156874_f4fa6668",
        "type": "BUY",
        "status": "OPEN",
        "entry_mode": None,
        "entry_path": None,
        "execution_path_id": None,
        "execution_path_name": None,
        "confirm_source": None,
        "warnings": None,
        "signal_snapshot": {
            "entry_mode": "session_plan_ladder_market",
            "entry_path": 1,
            "execution_path_id": "PATH_1_THREE_AGENT_CONSENSUS",
            "execution_path": {"id": "PATH_1_THREE_AGENT_CONSENSUS",
                               "name": "PATH 1 — THREE-AGENT CONSENSUS"},
            "warnings": ["Daily Bias advisory"],
        },
    }


def test_backfill_lifts_route_fields_from_the_snapshot():
    rows = [_legacy_row()]
    stats = backfill(rows, apply=True)

    row = rows[0]
    assert row["entry_mode"] == "session_plan_ladder_market"
    assert row["execution_path_id"] == "PATH_1_THREE_AGENT_CONSENSUS"
    assert row["execution_path_name"] == "PATH 1 — THREE-AGENT CONSENSUS"
    assert row["warnings"] == ["Daily Bias advisory"]
    assert stats["updated"] == 1


def test_backfill_never_overwrites_existing_values():
    row = _legacy_row()
    row["entry_mode"] = "two_agent_auction"  # already written by the new path
    rows = [row]
    backfill(rows, apply=True)

    assert rows[0]["entry_mode"] == "two_agent_auction", "existing value clobbered"
    # The gaps around it are still filled.
    assert rows[0]["execution_path_id"] == "PATH_1_THREE_AGENT_CONSENSUS"


def test_backfill_dry_run_changes_nothing():
    rows = [_legacy_row()]
    before = json.dumps(rows, sort_keys=True)
    stats = backfill(rows, apply=False)

    assert json.dumps(rows, sort_keys=True) == before
    assert stats["updated"] == 1, "dry run must still report what it WOULD fill"


def test_rows_without_snapshots_are_left_alone():
    rows = [{"id": "TRADE_MANUAL", "status": "CLOSED", "entry_mode": None}]
    stats = backfill(rows, apply=True)

    assert rows[0]["entry_mode"] is None
    assert stats["no_snapshot"] == 1
