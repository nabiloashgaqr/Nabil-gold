"""BUILD 17 (2026-08-20): dashboard language polish regression guards.

Operator order:
  * the dashboard opens in ENGLISH by default (first visit),
  * the English view must contain ZERO Arabic (labels, data source line,
    fallbacks), while the Arabic view keeps working.

These tests read the frontend files directly and pin the invariants so a
future edit cannot silently leak Arabic into the English UI again.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP_JS = ROOT / "dashboard" / "app.js"
INDEX_HTML = ROOT / "dashboard" / "index.html"

ARABIC = re.compile(r"[\u0600-\u06FF]")


def _app_js() -> str:
    return APP_JS.read_text(encoding="utf-8")


def _index_html() -> str:
    return INDEX_HTML.read_text(encoding="utf-8")


# ── default language: English on first open ────────────────────────────────
def test_default_language_is_english_with_fresh_key():
    js = _app_js()
    assert "localStorage.getItem('uiLang') || 'en'" in js
    # the legacy 'ar'-defaulting read is gone
    assert "getItem('lang') || 'ar'" not in js
    assert "getItem('lang')" not in js


def test_language_switch_persists_under_new_key():
    js = _app_js()
    assert "localStorage.setItem('uiLang', currentLang)" in js


# ── no Arabic in the English view ──────────────────────────────────────────
def test_tr_fallback_never_serves_arabic_into_english():
    # the fallback chain must prefer the EN dictionary, not AR
    js = _app_js()
    assert "|| I18N.en[key] || key" in js
    assert "|| I18N.ar[key] || key" not in js


def test_data_source_error_line_is_localized():
    # regression: the old hardcoded setText('dataSource', 'خطأ') showed Arabic
    # in the English dashboard on every API failure
    js = _app_js()
    assert "setText('dataSource', 'خطأ')" not in js
    assert "setText('dataSource', currentLang === 'ar' ? 'خطأ' : 'Error')" in js


def test_en_dictionary_has_no_arabic_and_matches_ar_keys():
    js = _app_js()
    m = re.search(r"const I18N = (\{.*?\n\};)", js, re.S)
    assert m, "I18N dictionary not found"
    block = m.group(1)
    en_m = re.search(r"en:\s*(\{.*?\n    \})", block, re.S)
    ar_m = re.search(r"ar:\s*(\{.*?\n    \})", block, re.S)
    assert en_m and ar_m, "en/ar dictionaries not found"
    en_body, ar_body = en_m.group(1), ar_m.group(1)
    assert not ARABIC.search(en_body), "Arabic text inside the EN dictionary"
    en_keys = set(re.findall(r"^\s{4,}(\w+):", en_body, re.M))
    ar_keys = set(re.findall(r"^\s{4,}(\w+):", ar_body, re.M))
    assert en_keys == ar_keys, f"dictionary key mismatch: {en_keys ^ ar_keys}"


def test_app_js_arabic_outside_dictionary_is_always_conditional():
    """Every Arabic string outside the I18N block must sit in an
    ar-branch (ternary/currentLang check/names array). A hardcoded leak
    like the old 'خطأ' line contains no 'ar' marker and fails here.
    Multi-line ternaries are allowed: the guard may sit on the previous
    line."""
    js = _app_js()
    m = re.search(r"const I18N = \{.*?\n\};", js, re.S)
    assert m, "I18N block not found"
    i18n_start, i18n_end = m.span()
    lines = js.split("\n")
    for i, line in enumerate(lines, start=1):
        if not ARABIC.search(line):
            continue
        pos = js.find(line)
        # skip the I18N dictionary itself (its Arabic lives in the ar dict)
        if i18n_start <= pos < i18n_end:
            continue
        window = line
        if i > 1:
            window = lines[i - 2] + "\n" + line
        assert re.search(r"ar", window, re.I), (
            f"app.js line {i}: Arabic string without an ar-conditional guard: "
            f"{line.strip()[:90]}"
        )


# ── index.html ─────────────────────────────────────────────────────────────
def test_html_language_buttons_default_to_english():
    html = _index_html()
    en_btn = re.search(r'<button id="langEn"[^>]*>', html)
    ar_btn = re.search(r'<button id="langAr"[^>]*>', html)
    assert en_btn and ar_btn
    assert "active" in en_btn.group(0)
    assert "active" not in ar_btn.group(0)


def test_html_arabic_only_inside_data_ar_attributes_or_conditionals():
    html = _index_html()
    for i, line in enumerate(html.split("\n"), start=1):
        # remove every data-ar="..." attribute; whatever Arabic remains must
        # be guarded by a language check
        stripped = re.sub(r'data-ar="[^"]*"', "", line)
        if not ARABIC.search(stripped):
            continue
        assert re.search(r"isAr\s*\?|currentLang\s*===\s*'ar'", stripped), (
            f"index.html line {i}: Arabic outside data-ar without a language "
            f"guard: {stripped.strip()[:90]}"
        )
