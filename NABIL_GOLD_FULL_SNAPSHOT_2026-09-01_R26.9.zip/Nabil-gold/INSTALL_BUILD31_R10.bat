@echo off
REM BUILD 31 R10 one-click installer (extract + tzdata + self-heal + full tests).
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy\install_build31_r10.ps1"
pause
