# =====================================================================
#  BUILD_PORTABLE_PACKAGE.ps1
#  Builds a small, clean, run-anywhere bundle of Nabil-gold FROM THIS
#  server. It keeps:   full CODE + your config.json + .env + the small
#  runtime state that matters (trade book, memory, path stats...).
#  It drops:          large / regenerable stuff (auction-flow tick DBs,
#  caches, logs, archives, PDFs, shadow leftovers).
#
#  Run on the live server from inside C:\Nabil-gold:
#     powershell -NoProfile -ExecutionPolicy Bypass -File .\BUILD_PORTABLE_PACKAGE.ps1
#
#  Output:  C:\Nabil-gold\_portable\Nabil-gold_PORTABLE_<timestamp>.zip
#  ASCII-only on purpose (Windows PowerShell 5.1 safe).
# =====================================================================
$ErrorActionPreference = "Stop"
$src = "C:\Nabil-gold"
if (-not (Test-Path $src)) { throw "Source folder not found: $src" }

$stamp   = Get-Date -Format "yyyyMMdd_HHmmss"
$build   = Join-Path $src ("_portable\build_" + $stamp)
$zipPath = Join-Path $src ("_portable\Nabil-gold_PORTABLE_" + $stamp + ".zip")
New-Item -ItemType Directory -Force -Path (Split-Path $zipPath) | Out-Null
New-Item -ItemType Directory -Force -Path $build | Out-Null

Write-Host "=== Building portable bundle ===" -ForegroundColor Cyan
Write-Host ("source : " + $src)
Write-Host ("staging: " + $build)

# ---------------------------------------------------------------------
# 1) Copy the tree with robocopy, excluding large/regenerable items.
#    robocopy exit codes 0..7 are SUCCESS (>=8 = error).
# ---------------------------------------------------------------------
$excludeDirs = @(
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    "node_modules", ".git", "_portable",
    "logs", "diagnostics",
    "storage\shadow", "storage\aux_cache",
    "storage\macro", "storage\oil", "storage\sentiment",
    "storage\correlation", "storage\model_calibration", "storage\llm"
)
$excludeFiles = @(
    "*.pyc", "*.pyo", "*.lock",
    "*.sqlite3", "*.db", "*.sqlite",
    "*.zip", "*.pdf", "*.7z", "*.rar",
    "*.backup_before_shadow_removal_*.json",
    "r25_scalp_shadow.jsonl", "pre_arm_ote_shadow_arms.jsonl"
)

$rcArgs = @($src, $build, "/E", "/R:1", "/W:1", "/NFL", "/NDL", "/NP",
            "/XD") + $excludeDirs + @("/XF") + $excludeFiles
& robocopy @rcArgs | Out-Null
if ($LASTEXITCODE -ge 8) { throw ("robocopy failed with exit code " + $LASTEXITCODE) }

# ---------------------------------------------------------------------
# 2) Safety: remove any shadow leftovers that robocopy might have copied
# ---------------------------------------------------------------------
$leftovers = @(
    "services\shadow_mode.py",
    "scripts\shadow_report.py",
    "scripts\review_shadow_trades.py",
    "scripts\run_demo_cycle.py",
    "scripts\demo_compare_report.py",
    "scripts\verify_r10_fixes.py",
    "tests\test_shadow_mode_wti.py",
    "tests\test_build31r6_path6_shadow.py",
    "tests\test_demo_compare.py",
    "tests\test_inspect_running_modes.py"
)
foreach ($rel in $leftovers) {
    $p = Join-Path $build $rel
    if (Test-Path $p) { Remove-Item $p -Force; Write-Host ("  removed leftover: " + $rel) }
}
Get-ChildItem -Path $build -Recurse -Directory -Filter "shadow" -ErrorAction SilentlyContinue |
    ForEach-Object { Remove-Item $_.FullName -Recurse -Force }

# ---------------------------------------------------------------------
# 3) Make sure the MUST-KEEP small state is present (report if missing)
# ---------------------------------------------------------------------
$keepState = @(
    "config.json",
    "storage\trades.json",
    "storage\decision_audit.json",
    "storage\reflection_memory.json",
    "storage\session_plans.json",
    "storage\path_performance\trades.json",
    "storage\learning_history.json"
)
Write-Host ""
Write-Host "=== Essential files check ===" -ForegroundColor Cyan
foreach ($rel in $keepState) {
    $p = Join-Path $build $rel
    if (Test-Path $p) { Write-Host ("  [keep] " + $rel) -ForegroundColor Green }
    else { Write-Host ("  [MISSING - will be created on first run] " + $rel) -ForegroundColor Yellow }
}
$envFile = Join-Path $build ".env"
if (Test-Path $envFile) { Write-Host "  [keep] .env" -ForegroundColor Green }
else { Write-Host "  [note] no .env found (copy .env.template to .env if you use env secrets)" -ForegroundColor Yellow }

# ---------------------------------------------------------------------
# 4) Drop an installer + a short readme into the bundle
# ---------------------------------------------------------------------
$readme = @'
NABIL-GOLD PORTABLE BUNDLE
==========================
Contents: full code (R26.7, shadow mode removed) + your config.json +
.env (if present) + small runtime state (trade book, memory, path stats).
Excluded (regenerate automatically): auction-flow tick DBs (*.sqlite3),
caches, logs, diagnostics, archives/PDFs.

INSTALL ON A NEW MACHINE (Windows)
----------------------------------
1. Copy this whole folder to  C:\Nabil-gold
2. Install Python 3.11+ (tick "Add to PATH").
3. Open PowerShell in C:\Nabil-gold and run:
       powershell -NoProfile -ExecutionPolicy Bypass -File .\INSTALL_ON_NEW_SERVER.ps1
   (this installs requirements and runs the test suite.)
4. Review config.json (telegram token, chat_id, data keys, capital).
   If you have no .env, copy .env.template to .env and fill secrets.
5. Start the bots (scheduler / RESTART_ALL_SERVICES.ps1 as usual).

NOTES
-----
- config.json and .env CONTAIN SECRETS (telegram token, API keys).
  Do NOT upload this zip to any public place.
- Auction-flow tick history is intentionally excluded; the tick manager
  rebuilds the *.sqlite3 stores from live ticks automatically.
- PATH 6 (OTE) is LIVE in this build (it places real pending LIMITs).
'@
[System.IO.File]::WriteAllText((Join-Path $build "README_PORTABLE.txt"), $readme, (New-Object System.Text.UTF8Encoding($false)))

$installer = @'
# INSTALL_ON_NEW_SERVER.ps1 - run once on the new machine inside C:\Nabil-gold
$ErrorActionPreference = "Stop"
Set-Location "C:\Nabil-gold"
Write-Host "=== Python version ===" -ForegroundColor Cyan
python --version
Write-Host "=== Installing requirements ===" -ForegroundColor Cyan
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
Write-Host "=== Quick checks ===" -ForegroundColor Cyan
python -c "import json; json.load(open('config.json', encoding='utf-8')); print('config.json OK')"
Write-Host "=== Running test suite ===" -ForegroundColor Cyan
python -m pytest -q
Write-Host "Done. Review config.json secrets, then start the bots." -ForegroundColor Green
'@
[System.IO.File]::WriteAllText((Join-Path $build "INSTALL_ON_NEW_SERVER.ps1"), $installer, (New-Object System.Text.UTF8Encoding($false)))

# ---------------------------------------------------------------------
# 5) Zip it
# ---------------------------------------------------------------------
Write-Host ""
Write-Host "=== Compressing ===" -ForegroundColor Cyan
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Compress-Archive -Path (Join-Path $build "*") -DestinationPath $zipPath -CompressionLevel Optimal

$sizeMB = [math]::Round((Get-Item $zipPath).Length / 1MB, 2)
Write-Host ""
Write-Host "=== DONE ===" -ForegroundColor Green
Write-Host ("Bundle : " + $zipPath)
Write-Host ("Size   : " + $sizeMB + " MB")
Write-Host ""
Write-Host "WARNING: this zip contains config.json / .env with SECRETS." -ForegroundColor Yellow
Write-Host "Transfer it privately; never post it publicly." -ForegroundColor Yellow
