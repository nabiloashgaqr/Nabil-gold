"""BUILD 31 (2026-08-24, operator report): two live card/management bugs.

1) A GOLD activation card printed the OIL price (85.33 on XAU/USD) because
   the tick manager's card fell back to a SHARED `_last_price` (the last row
   processed in the loop) whenever the row's own tick was momentarily empty.
   A card must never show another symbol's price.

2) A WTI SELL hit TP1 (+54 pts) but the stop was NOT moved to breakeven:
   in mt5_demo the tick manager OWNS trade management, and the
   "TP1 -> SL at entry" rule (auto_move_sl_to_entry_after_tp1, with the
   min_breakeven_rr noise floor) existed only in the 5-minute manager, which
   the demo mode bypasses. WTI's early-BE threshold (70 pts) was even ABOVE
   its TP1 (~63 pts), so no mechanism ever moved the stop.
   Fix: the tick manager applies the SAME resolved parameters as the paper
   path when TP1 is booked.
"""
from __future__ import annotations

import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

logging.disable(logging.CRITICAL)


def _config():
    from utils.helpers import load_config
    return load_config()


# ── card price selection (bug 1) ───────────────────────────────────────────

def _mgr():
    from scripts.run_tick_manager import TickManager
    return TickManager(_config(), telegram=None, database=None)


def test_no_shared_last_price_attribute_exists():
    """The cross-symbol hazard itself must be gone from the class."""
    mgr = _mgr()
    assert not hasattr(mgr, "_last_price"), \
        "shared _last_price reappeared - cards can leak another symbol's price"
    assert hasattr(mgr, "_last_prices")


def test_card_price_prefers_own_tick():
    mgr = _mgr()
    mgr._last_prices["T_XAU"] = 4633.4
    context = {"id": "T_XAU", "current_price": 85.33}  # deliberately wrong symbol
    assert mgr._card_price_for(context, "ORDER_FILLED", {}) == 4633.4


def test_card_price_activation_uses_actual_fill():
    """Activation card with no fresh tick -> the broker fill price, not a
    foreign symbol's price."""
    mgr = _mgr()
    context = {"id": "T_XAU", "symbol": "XAU/USD", "current_price": 85.33}
    px = mgr._card_price_for(context, "ORDER_FILLED", {"entry_price": 4633.38})
    assert px == 4633.38


def test_card_price_falls_back_to_own_stored_price():
    mgr = _mgr()
    context = {"id": "T_XAU", "symbol": "XAU/USD", "current_price": 4630.2}
    px = mgr._card_price_for(context, "TRAILING_SL_UPDATED", {})
    assert px == 4630.2


def test_card_price_never_invents_or_crosses_symbols():
    """Nothing registered -> 0.0 (card shows no price), NEVER another
    symbol's price."""
    mgr = _mgr()
    context = {"id": "T_UNKNOWN", "symbol": "XAU/USD"}
    assert mgr._card_price_for(context, "TRAILING_SL_UPDATED", {}) == 0.0
    assert mgr._card_price_for(context, "ORDER_FILLED", {}) == 0.0


# ── TP1 -> breakeven parity (bug 2) ────────────────────────────────────────

class _FakeExecutor:
    def __init__(self):
        self.calls = []

    def apply_stop(self, tid, new_sl, tp, symbol):
        self.calls.append((tid, new_sl, tp, symbol))
        return True


class _FakeDB:
    def __init__(self):
        self.updates = []

    def update_trade(self, tid, updates):
        self.updates.append((tid, dict(updates)))
        return True


def _wti_row(**over):
    row = {
        "id": "TRADE_WTI_1",
        "symbol": "WTI/USD",
        "type": "SELL",
        "entry_price": 85.36,
        "initial_stop_loss": 86.56,   # risk 1.20 = 120 pts (pv 0.01)
        "stop_loss": 86.56,
        "tp1": 84.73,                 # TP1 tagged at 63 pts (0.525R)
        "tp2": 84.67,
        "status": "TP1_HIT",
        "sl_moved_to_entry": False,
        "signal_snapshot": {},
    }
    row.update(over)
    return row


def _mgr_with_fakes():
    from scripts.run_tick_manager import TickManager
    db, ex = _FakeDB(), _FakeExecutor()
    mgr = TickManager(_config(), telegram=None, database=db)
    return mgr, db, ex


def test_tp1_breakeven_arms_at_entry_on_wti():
    """The live incident replay: SELL 85.36, TP1 at 84.73 (63 pts = 0.525R
    on a 120-pt risk) -> stop moves to entry, broker-confirmed, booked."""
    mgr, db, ex = _mgr_with_fakes()
    row = _wti_row()
    mgr._maybe_arm_tp1_breakeven(row, ex, row["id"], "SELL",
                                 entry=85.36, stop=86.56, tp2=84.67,
                                 price=84.73)
    assert ex.calls == [("TRADE_WTI_1", 85.16, 84.67, "WTI/USD")]
    assert db.updates and db.updates[0][1]["sl_moved_to_entry"] is True
    assert db.updates[0][1]["stop_loss"] == 85.16
    assert row["sl_moved_to_entry"] is True


def test_tp1_breakeven_deferred_below_min_rr():
    """TP1 closer than min_breakeven_rr (0.5R): the paper rule DELIBERATELY
    keeps the structural stop so noise cannot close a correct trade flat.
    Risk 200 pts, travel 63 pts = 0.315R -> no move (and it is logged)."""
    mgr, db, ex = _mgr_with_fakes()
    row = _wti_row(initial_stop_loss=87.36, stop_loss=87.36)
    mgr._maybe_arm_tp1_breakeven(row, ex, row["id"], "SELL",
                                 entry=85.36, stop=87.36, tp2=84.67,
                                 price=84.73)
    assert ex.calls == []
    assert db.updates == []
    assert row["sl_moved_to_entry"] is False


def test_tp1_breakeven_noop_when_already_moved():
    mgr, db, ex = _mgr_with_fakes()
    row = _wti_row(sl_moved_to_entry=True)
    mgr._maybe_arm_tp1_breakeven(row, ex, row["id"], "SELL",
                                 entry=85.36, stop=85.36, tp2=84.67,
                                 price=84.73)
    assert ex.calls == [] and db.updates == []


def test_tp1_breakeven_never_tightens_through_price():
    """BUY whose price is below entry (wrong side): moving to entry would
    close the position instantly -> refuse."""
    mgr, db, ex = _mgr_with_fakes()
    row = _wti_row(type="BUY", entry_price=85.36, initial_stop_loss=84.16,
                   stop_loss=84.16, tp1=85.99, tp2=86.05, symbol="WTI/USD")
    mgr._maybe_arm_tp1_breakeven(row, ex, row["id"], "BUY",
                                 entry=85.36, stop=84.16, tp2=86.05,
                                 price=85.10)
    assert ex.calls == [] and db.updates == []


def test_tp1_breakeven_respects_auto_be_off():
    import copy
    cfg = _config()
    cfg = copy.deepcopy(cfg)
    cfg.setdefault("trade_management", {})["auto_move_sl_to_entry_after_tp1"] = False
    from scripts.run_tick_manager import TickManager
    db, ex = _FakeDB(), _FakeExecutor()
    mgr = TickManager(cfg, telegram=None, database=db)
    row = _wti_row()
    mgr._maybe_arm_tp1_breakeven(row, ex, row["id"], "SELL",
                                 entry=85.36, stop=86.56, tp2=84.67,
                                 price=84.73)
    assert ex.calls == [] and db.updates == []


# ── status message per-symbol prices (bug 1, 5m-cycle half) ────────────────

def test_status_message_prices_each_trade_with_its_own_symbol():
    from scripts.run_trade_updates import _build_status_message
    trades = [
        {"id": "T_XAU", "symbol": "XAU/USD", "type": "BUY", "status": "OPEN",
         "entry_price": 4633.38},
        {"id": "T_WTI", "symbol": "WTI/USD", "type": "SELL", "status": "PENDING",
         "entry_price": 85.36, "order_type": "SELL_LIMIT",
         "entry_time": "2026-08-24T10:00:00+00:00"},
    ]
    msg = _build_status_message(
        trades, [], 85.33, {},   # 85.33 = the last loop price (oil)
        symbol_prices={"XAU/USD": 4633.38, "WTI/USD": 84.73})
    # The headline shows BOTH symbols at their own prices...
    assert "XAU 4633.38" in msg and "WTI 84.73" in msg
    # ...and the pending line is priced against OIL (84.73), not the
    # leaked 85.33: |84.73 - 85.36| = 63 pts.
    assert "63 pts" in msg or "63pts" in msg.replace(" ", "")
    assert "85.33" not in msg
