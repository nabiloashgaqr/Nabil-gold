"""R25.15 convoy step 1 — fill-truth reconciliation for legacy live rows.

Live case (operator screenshot 2026-08-28): GBPUSD SELL row carried the
planned entry 1.30000 while the broker filled 1.35504 — the row was
partial-closed and its stop "armed at breakeven" AT THE PHANTOM ENTRY, so a
496-pt real risk looked like zero risk and the reconciliation never ran
(protected row + blind 0.01/2dp comparison). These tests pin the one-time
bypass: write the broker fill, complete the interrupted protection at the
TRUE entry, and restore full protection from the next tick.
"""
from __future__ import annotations

import types

from scripts.run_tick_manager import TickManager


class _DB:
    def __init__(self):
        self.updates = []

    def update_trade(self, tid, updates):
        self.updates.append((tid, dict(updates)))


class _Executor:
    def __init__(self):
        self.stops = []

    def apply_stop(self, tid, stop, tp, symbol):
        self.stops.append((tid, stop, tp, symbol))
        return True


def _tm() -> TickManager:
    tm = TickManager({
        "trading_rules": {"stop": {
            "min_liquidity_points": 200,
            "safety_buffer_points": 70,
            "max_stop_points": 400,
        }},
    }, database=_DB())
    tm._notify = lambda text: None
    return tm


def _gbp_live_row() -> dict:
    """The operator's actual live row: protected + phantom-entry BE."""
    return {
        "id": "GBP-LIVE", "symbol": "GBP/USD", "type": "SELL",
        "entry_price": 1.36, "stop_loss": 1.36,
        "initial_stop_loss": 1.36504, "tp2": 1.35,
        "sl_moved_to_entry": True, "partial_close": True,
        "signal_snapshot": {},  # legacy row: no usable snapshot
    }


def test_protected_legacy_row_gets_entry_truth_and_true_entry_be():
    tm = _tm()
    row = _gbp_live_row()
    pos = types.SimpleNamespace(price_open=1.35504, sl=1.36)
    ex = _Executor()
    tm._normalize_execution_stop(row, pos, ex, "SELL")
    # 1. the broker fill replaces the planned entry (5 digits intact)
    assert row["entry_price"] == 1.35504
    assert row["entry_fill_reconciled"] is True
    # 2. the BE arm is COMPLETED at the true entry — tighten-only
    assert row["stop_loss"] == 1.35504
    assert ex.stops == [("GBP-LIVE", 1.35504, 1.35, "GBP/USD")]
    # 3. the original structural risk reference is preserved for R maths
    assert row["initial_stop_loss"] == 1.36504
    assert row["execution_stop_normalized"] is True


def test_reconciliation_runs_once_then_protection_resumes():
    tm = _tm()
    row = _gbp_live_row()
    pos = types.SimpleNamespace(price_open=1.35504, sl=1.35504)
    ex = _Executor()
    tm._normalize_execution_stop(row, pos, ex, "SELL")
    first = len(ex.stops)
    assert first == 1
    # second tick: the row is reconciled -> fully protected again, nothing moves
    ex2 = _Executor()
    tm._normalize_execution_stop(row, pos, ex2, "SELL")
    assert ex2.stops == []
    assert row["stop_loss"] == 1.35504
    assert row["entry_price"] == 1.35504


def test_structural_stop_row_uses_symbol_liquidity_law_from_true_fill():
    """No BE yet: the cap law re-derives the stop from the REAL fill.

    GBP law R26.9.3 [405..600]: the planned 504-pt stop sits inside the
    band, but measured from the REAL fill (1.35504) the shipped stop is
    1000 pts -> past the 600-pt cap:
    1.35504 + 600 pts (0.0060) = 1.36104 (cap clamps the wider protective).
    """
    tm = _tm()
    row = {
        "id": "GBP-NEW", "symbol": "GBP/USD", "type": "SELL",
        "entry_price": 1.36, "stop_loss": 1.36504,
        "initial_stop_loss": 1.36504, "tp2": 1.35,
        "sl_moved_to_entry": False, "partial_close": False,
        "signal_snapshot": {},
    }
    pos = types.SimpleNamespace(price_open=1.35504, sl=1.36504)
    ex = _Executor()
    tm._normalize_execution_stop(row, pos, ex, "SELL")
    assert row["entry_price"] == 1.35504
    assert row["stop_loss"] == 1.36104
    assert ex.stops == [("GBP-NEW", 1.36104, 1.35, "GBP/USD")]


def test_be_stop_is_never_widened_during_reconciliation():
    """A stop already trailed INTO profit (below the true BE for a SELL)
    must stay where it is — only the entry truth is written."""
    tm = _tm()
    row = _gbp_live_row()
    row["stop_loss"] = 1.33750  # trailed deep into profit
    pos = types.SimpleNamespace(price_open=1.35504, sl=1.345)
    ex = _Executor()
    tm._normalize_execution_stop(row, pos, ex, "SELL")
    assert ex.stops == []            # stop untouched
    assert row["stop_loss"] == 1.33750
    assert row["entry_price"] == 1.35504  # entry truth still lands


def test_matching_fill_is_untouched_protection_stands():
    """No mismatch -> the old gate behaves exactly as before."""
    tm = _tm()
    row = _gbp_live_row()
    row["entry_price"] = 1.35504
    row["stop_loss"] = 1.35504
    pos = types.SimpleNamespace(price_open=1.35504, sl=1.35504)
    ex = _Executor()
    out = tm._normalize_execution_stop(row, pos, ex, "SELL")
    assert out == 1.35504
    assert ex.stops == []
    assert "entry_fill_reconciled" not in row


def test_gold_row_without_mismatch_is_unchanged():
    """The existing gold repair path keeps its exact numbers (regression)."""
    tm = _tm()
    row = {
        "id": "LIVE", "symbol": "XAU/USD", "type": "BUY",
        "entry_price": 4392.63, "stop_loss": 4368.0,
        "initial_stop_loss": 4368.0, "tp2": 4375.0,
        "sl_moved_to_entry": False, "partial_close": False,
        "signal_snapshot": {"signal": {
            "entry": {"price": 4395.0}, "stop_loss": 4368.0,
        }},
    }
    pos = types.SimpleNamespace(price_open=4392.63, sl=4368.0)
    ex = _Executor()
    actual = tm._normalize_execution_stop(row, pos, ex, "BUY")
    assert actual == 4365.63
    assert row["stop_loss"] == 4365.63
    assert "entry_fill_reconciled" not in row
