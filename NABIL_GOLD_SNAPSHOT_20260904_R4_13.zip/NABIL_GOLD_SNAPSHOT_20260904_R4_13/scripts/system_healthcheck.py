"""Full-system health check: every vital organ, one pass, one verdict.

Checks, in pipeline order:
  1. ANALYSIS   scheduled cycles are running and completing (log freshness,
                no unexpected errors in the recent window)
  2. STORAGE    live files are being written (snapshot / plans / measurements
                timestamps) and are owned/writable by this account
  3. AGENTS     the six agents produce a fresh read from the stored snapshot
  4. MT5        terminal connection, account info, symbol subscription
  5. TICK FEED  auction sqlite heartbeat + tick recency
  6. TELEGRAM   bot token valid (getMe) and — with --send — a real test
                message to the demo chat
  7. TRADES     local trade book readable; open/pending counts; recent trades
  8. DASHBOARD  local API answering on its port and serving fresh data
  9. CONFIG     unified thresholds sane (bar=net=65), weights sum to 1
 10. VERSIONS   fingerprint of the critical patched files (so you can prove
                the VPS runs today's code)

Usage:
    python scripts\\system_healthcheck.py            (read-only checks)
    python scripts\\system_healthcheck.py --send     (also sends a Telegram
                                                     test message + latest
                                                     trades summary card)

Exit code 0 = all critical checks OK; 1 = at least one FAIL.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

try:  # load operator .env exactly like the production scripts do
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

RESULTS: List[Tuple[str, str, str]] = []   # (section, status, detail)
CRITICAL_FAIL = False


def report(section: str, ok: bool, detail: str, critical: bool = True, warn: bool = False) -> None:
    global CRITICAL_FAIL
    if ok:
        status = "OK  "
    elif warn:
        status = "WARN"
    else:
        status = "FAIL"
        if critical:
            CRITICAL_FAIL = True
    RESULTS.append((section, status, detail))
    print(f"[{status}] {section:<12} {detail}")


def _age_minutes(path: Path) -> float | None:
    try:
        mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
        return (datetime.now(timezone.utc) - mtime).total_seconds() / 60.0
    except OSError:
        return None


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def check_mt5_terminal() -> Tuple[bool, str]:
    """MT5 terminal reachability (2026-08-19 warning #6 fix).

    The VPS has ONE MT5 terminal: if it dies, trailing/BE management freezes
    while broker-side stops still protect the capital. This section surfaces
    the disconnect in the scheduled healthcheck so the operator is alerted.
    """
    try:
        from services.mt5_feed import connected as _connected, initialize as _initialize
    except Exception as exc:  # noqa: BLE001
        return False, f"services.mt5_feed unavailable: {exc}"
    try:
        if _connected():
            return True, "MT5 terminal connected"
        _initialize()
        if _connected():
            return True, "MT5 terminal connected (re-initialized this check)"
        return False, (
            "MT5 terminal NOT connected - trailing/BE management frozen "
            "(open positions still protected by broker-side stops)"
        )
    except Exception as exc:  # noqa: BLE001
        return False, f"MT5 check failed: {exc}"




def _execution_gate_status(root: Path) -> Tuple[bool, str, int]:
    """Read-only probe of the executor self-freeze + recent order refusals.

    The live incident (2026-08-19): the daily order cap was reached and every
    placement was refused for hours while the healthcheck showed nothing.
    Returns (halt_exists, halt_reason, refusals_in_log_tail).
    """
    halt_path = root / ".demo_halt"
    halt_exists = halt_path.exists()
    halt_reason = ""
    if halt_exists:
        try:
            halt_reason = halt_path.read_text(encoding="utf-8", errors="replace").strip()[:120]
        except Exception:  # noqa: BLE001
            halt_reason = "(unreadable)"
    refusals = 0
    tick_log = root / "logs" / "tick_manager.log"
    if tick_log.exists():
        try:
            with tick_log.open("rb") as fh:
                fh.seek(0, 2)
                size = fh.tell()
                fh.seek(max(0, size - 65536))
                tail = fh.read().decode("utf-8", errors="replace")
            refusals = tail.count("Demo order refused")
        except Exception:  # noqa: BLE001
            refusals = 0
    return halt_exists, halt_reason, refusals


def check_windows_tasks() -> None:
    """Audit the production Task Scheduler set and persistent singletons.

    Ready is healthy for periodic jobs; persistent services must be Running.
    Non-MT5 jobs should use the SYSTEM service account and Hidden setting so
    they survive logoff without opening console windows. MT5 is intentionally
    interactive because terminal64.exe requires the logged-on desktop.
    """
    if os.name != "nt":
        report("TASKS", True, "Windows Task Scheduler check skipped on non-Windows host",
               critical=False)
        return
    expected = {
        "Nabil Gold Dashboard": True,
        "SS_DemoLoop": True,
        "SS_TickManager": True,
        "SS_MT5Terminal": True,
        "SS_DemoAnalysis": False,
        "SS_DemoWatchdog": False,
        "SS_MacroContext": False,
        "SS_EIAFill": False,
        "SS_DailyReport": False,
        "SS_WeeklyReport": False,
        "SS_Dashboard": False,
        "SS_SubscriptionBot": False,
        "SS_AutoMaintenance": False,
    }
    ps = r"""
$names = @(%s)
$rows = foreach ($n in $names) {
  $t = Get-ScheduledTask -TaskName $n -ErrorAction SilentlyContinue
  if ($null -ne $t) {
    [pscustomobject]@{Name=$n; State=[string]$t.State; Enabled=($t.State -ne 'Disabled');
      User=[string]$t.Principal.UserId; LogonType=[string]$t.Principal.LogonType;
      Hidden=[bool]$t.Settings.Hidden}
  }
}
$procs = @(Get-CimInstance Win32_Process | Where-Object {
  $_.Name -match '^python(w)?\.exe$' -and
  ($_.CommandLine -match 'run_tick_manager\.py|run_dashboard_server\.py|run_demo_loop\.py')
} | ForEach-Object {[pscustomobject]@{Pid=$_.ProcessId; Command=[string]$_.CommandLine}})
[pscustomobject]@{Tasks=@($rows); Processes=$procs} | ConvertTo-Json -Depth 5 -Compress
""" % ",".join("'%s'" % n.replace("'", "''") for n in expected)
    try:
        cp = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", ps],
            capture_output=True, text=True, timeout=25, check=True,
        )
        data = json.loads(cp.stdout.strip())
        rows = {r["Name"]: r for r in (data.get("Tasks") or [])}
        counts = {"run_tick_manager.py": 0, "run_dashboard_server.py": 0, "run_demo_loop.py": 0}
        for proc in data.get("Processes") or []:
            cmd = str(proc.get("Command") or "").lower()
            for marker in counts:
                if marker in cmd:
                    counts[marker] += 1
        task_worker = {
            "SS_TickManager": "run_tick_manager.py",
            "SS_DemoLoop": "run_demo_loop.py",
            "Nabil Gold Dashboard": "run_dashboard_server.py",
        }
        missing = [n for n in expected if n not in rows]
        report("TASKS", not missing,
               "all required scheduled tasks exist" if not missing
               else "missing: " + ", ".join(missing))
        for name, persistent in expected.items():
            row = rows.get(name)
            if not row:
                continue
            state = str(row.get("State") or "")
            marker = task_worker.get(name)
            worker_live = bool(marker and counts.get(marker) == 1)
            # cmd/bat wrappers can finish while their Python child remains the
            # live worker. In that topology Task Scheduler says Ready/result=1
            # although the guarded singleton is healthy. Process identity is
            # the execution truth; task state remains the restart mechanism.
            healthy = ((state == "Running" or worker_live) if persistent
                       else state in {"Ready", "Running"})
            detail = f"{name}: state={state}"
            if marker:
                detail += f" worker_instances={counts.get(marker, 0)}"
            detail += f" user={row.get('User')} hidden={row.get('Hidden')}"
            report("TASKS", healthy, detail,
                   critical=persistent, warn=not persistent and not healthy)
            if name != "SS_MT5Terminal":
                background = str(row.get("User") or "").upper() in {"SYSTEM", "NT AUTHORITY\\SYSTEM"}
                report("TASKS", background,
                       f"{name}: background account={row.get('User')}",
                       critical=False, warn=not background)
        for marker, count in counts.items():
            report("TASKS", count == 1, f"{marker} instances={count}",
                   critical=marker == "run_tick_manager.py", warn=marker != "run_tick_manager.py")
    except Exception as exc:  # noqa: BLE001
        report("TASKS", False, f"Task Scheduler audit failed: {type(exc).__name__}: {exc}",
               critical=False, warn=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--send", action="store_true",
                        help="also send a Telegram test message + trades summary")
    args = parser.parse_args()

    print("=" * 74)
    print(f"SYSTEM HEALTH CHECK — {datetime.now(timezone.utc):%Y-%m-%d %H:%M} UTC")
    print("=" * 74)

    from utils.helpers import load_config, is_weekend_hebron
    config = load_config()
    weekend = is_weekend_hebron()
    if weekend:
        print("NOTE: weekend gate active (Sat, or Sun before 21:00 UTC) - analysis")
        print("      cycles are intentionally skipped; freshness checks are WARN-only.\n")

    # ------------------------------------------------------------------ 1
    log = ROOT / "logs" / "demo_analysis.log"
    age = _age_minutes(log)
    if age is None:
        report("ANALYSIS", False, "logs/demo_analysis.log missing — has SS_DemoAnalysis ever run?")
    else:
        fresh = age <= 12  # two 5-minute cycles of slack
        tail = log.read_text(encoding="utf-8", errors="replace").splitlines()[-120:]
        errors = [l for l in tail if "ERROR" in l or "WinError" in l]
        report("ANALYSIS", fresh or weekend, f"log updated {age:.0f} min ago "
               + ("(weekend skip cycles)" if weekend else
                  f"({'fresh' if fresh else 'STALE - cycles not running?'})"),
               warn=weekend and not fresh)
        report("ANALYSIS", not errors,
               f"{len(errors)} ERROR/WinError line(s) in recent log"
               + (f"; first: {errors[0][-110:]}" if errors else ""),
               critical=False, warn=bool(errors))

    # ------------------------------------------------------------------ 2
    live_files = {
        "storage/shared_market_data.json": 12,
        "storage/session_plans.json": 12,
        "storage/agent_measurements/agent_system_%s.jsonl"
        % datetime.now(timezone.utc).strftime("%Y-%m-%d"): 12,
    }
    for rel, max_age in live_files.items():
        p = ROOT / rel
        a = _age_minutes(p)
        if a is None:
            report("STORAGE", weekend, f"{rel} missing"
                   + (" (weekend: analysis writes resume at market open)" if weekend else ""),
                   warn=weekend)
        else:
            report("STORAGE", a <= max_age or weekend,
                   f"{rel} written {a:.0f} min ago"
                   + (" (weekend staleness is normal)" if weekend and a > max_age else ""),
                   warn=weekend and a > max_age)
    # write-permission probe in storage (catches the admin-owned ACL incident)
    probe = ROOT / "storage" / ".healthcheck_probe.tmp"
    try:
        probe.write_text("x", encoding="utf-8")
        target = ROOT / "storage" / ".healthcheck_probe.json"
        os.replace(probe, target)
        target.unlink()
        report("STORAGE", True, "write+replace probe in storage/ OK (ACL healthy)")
    except OSError as exc:
        report("STORAGE", False, f"cannot write/replace in storage/: {exc} "
               "(run icacls grant Users if this is WinError 5)")

    # ------------------------------------------------------------------ 3
    try:
        data = json.loads((ROOT / "storage" / "shared_market_data.json").read_text(encoding="utf-8"))
        from agents.technical_agent import TechnicalAgent
        from agents.multitimeframe_agent import MultiTimeframeAgent
        from agents.classical_agent import ClassicalAgent
        from agents.smc_agent import SMCAgent
        from agents.price_action_agent import PriceActionAgent
        from agents.auction_flow_agent import AuctionFlowAgent
        book = {}
        for name, cls in (("technical", TechnicalAgent), ("multitimeframe", MultiTimeframeAgent),
                          ("classical", ClassicalAgent), ("smc", SMCAgent),
                          ("price_action", PriceActionAgent), ("auction_flow", AuctionFlowAgent)):
            r = cls(config).analyze(data)
            book[name] = f"{r.get('signal') or r.get('direction')} {_f(r.get('confidence')):.0f}%"
        report("AGENTS", True, " | ".join(f"{k}:{v}" for k, v in book.items()))
        from services.thesis_consensus import evaluate_directional_admission
        for side in ("BUY", "SELL"):
            adm = evaluate_directional_admission(
                side, {k: {"direction": v.split()[0], "confidence": float(v.split()[1].rstrip('%'))}
                       for k, v in book.items()}, config)
            report("AGENTS", True,
                   f"{side} admission: allow={adm.get('allow')} path={adm.get('path')} "
                   f"net={adm.get('confidence')}%", critical=False)
    except Exception as exc:  # noqa: BLE001
        report("AGENTS", False, f"agent read failed: {type(exc).__name__}: {exc}")

    # ------------------------------------------------------------------ 4
    try:
        import MetaTrader5 as mt5  # type: ignore
        if not mt5.initialize():
            report("MT5", False, f"initialize failed: {mt5.last_error()}")
        else:
            info = mt5.account_info()
            term = mt5.terminal_info()
            sym = str(config.get("symbol", "XAU/USD")).replace("/", "")
            tick = mt5.symbol_info_tick(sym) if mt5.symbol_select(sym, True) else None
            report("MT5", info is not None and term is not None,
                   f"account={getattr(info, 'login', '?')} balance={getattr(info, 'balance', '?')} "
                   f"connected={getattr(term, 'connected', '?')}")
            if tick is not None:
                tick_age = datetime.now(timezone.utc).timestamp() - tick.time
                report("MT5", tick_age < 600,
                       f"{sym} last tick {tick_age:.0f}s ago bid={tick.bid} ask={tick.ask} "
                       "(weekend staleness is normal)", critical=False,
                       warn=tick_age >= 600)
            positions = mt5.positions_total()
            orders = mt5.orders_total()
            report("MT5", True, f"open positions={positions} pending orders={orders}", critical=False)
            mt5.shutdown()
    except ImportError:
        report("MT5", False, "MetaTrader5 module not installed in this Python", critical=False, warn=True)

    # ------------------------------------------------------------------ 5
    try:
        db_path = ROOT / "storage" / "auction_flow.sqlite3"
        with sqlite3.connect(str(db_path)) as con:
            row = con.execute(
                "SELECT value FROM meta WHERE key IN ('collector_heartbeat','heartbeat_ts') "
                "ORDER BY key LIMIT 1").fetchone()
            last_min = con.execute("SELECT MAX(ts) FROM minutes").fetchone()
        hb_age = (datetime.now(timezone.utc).timestamp() - float(row[0])) / 60 if row else None
        tick_min_age = (datetime.now(timezone.utc).timestamp() - float(last_min[0])) / 60 if last_min and last_min[0] else None
        hb_ok = hb_age is not None and (hb_age < 10 or weekend)
        report("TICKFEED", hb_ok,
               (f"auction heartbeat {hb_age:.1f} min ago"
                + (" (weekend idle normal)" if weekend and hb_age >= 10 else ""))
               if hb_age is not None else
               "no heartbeat row" + (" (weekend idle normal)" if weekend else ""),
               warn=(hb_age is None or hb_age >= 10) and weekend)
        if tick_min_age is not None:
            report("TICKFEED", True, f"latest minute bar {tick_min_age:.0f} min ago "
                   "(large on weekends is normal)", critical=False)
    except Exception as exc:  # noqa: BLE001
        report("TICKFEED", False, f"auction store unreadable: {exc}", critical=False, warn=True)

    # ------------------------------------------------------------------ 6
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    chat = os.environ.get("TELEGRAM_DEMO_CHAT_ID") or os.environ.get("TELEGRAM_CHAT_ID", "")
    if not token:
        report("TELEGRAM", False, "TELEGRAM_BOT_TOKEN not in environment (load .env?)")
    else:
        me = None
        try:
            with urllib.request.urlopen(
                    f"https://api.telegram.org/bot{token}/getMe", timeout=15) as resp:
                me = json.loads(resp.read().decode())
        except Exception:  # noqa: BLE001
            # Corporate AV/proxy replaces the TLS chain; requests carries its
            # own CA bundle (certifi) and is what production sends through.
            try:
                import requests
                me = requests.get(
                    f"https://api.telegram.org/bot{token}/getMe", timeout=15).json()
            except Exception as exc2:  # noqa: BLE001
                report("TELEGRAM", False, f"getMe failed on both stacks: {exc2}")
        if me is not None:
            ok = bool(me.get("ok"))
            report("TELEGRAM", ok, f"bot @{me.get('result', {}).get('username', '?')} token valid")
        if args.send and chat:
            try:
                from services.telegram_bot import TelegramService
                tg = TelegramService(config)
                sent = tg.send_message(
                    "\U0001F9EA HEALTHCHECK \u2014 all-systems test message "
                    f"({datetime.now(timezone.utc):%H:%M} UTC). If you can read "
                    "this, analysis\u2192telegram delivery works.")
                report("TELEGRAM", bool(sent), f"test message sent={sent} to demo chat")
            except Exception as exc:  # noqa: BLE001
                report("TELEGRAM", False, f"test send failed: {exc}")

    # ------------------------------------------------------------------ 7
    try:
        from services.database import DatabaseService
        db = DatabaseService(config)
        open_trades = db.get_open_trades() or []
        recent = []
        try:
            recent = db.get_recent_trades(5) or []
        except Exception:  # noqa: BLE001
            pass
        mode = "supabase" if getattr(db, "client", None) else "local-json"
        report("TRADES", True, f"book readable via {mode}; open={len(open_trades)} recent={len(recent)}")
        lines = []
        for t in (recent or open_trades)[:5]:
            lines.append(f"{t.get('id', '?')[:14]} {t.get('type', '?')} "
                         f"{t.get('status', '?')} pnl={t.get('pnl', t.get('pnl_points', '-'))}")
        if lines:
            report("TRADES", True, "latest: " + " || ".join(lines), critical=False)
        else:
            report("TRADES", True, "no trades recorded yet (system has not fired)", critical=False)
        if args.send and token and chat and (recent or open_trades):
            try:
                from services.telegram_bot import TelegramService
                tg = TelegramService(config)
                body = "\U0001F4CB HEALTHCHECK \u2014 latest trades:\n" + "\n".join(
                    f"\u2022 {l}" for l in lines)
                tg.send_message(body)
                report("TRADES", True, "latest-trades summary sent to Telegram", critical=False)
            except Exception as exc:  # noqa: BLE001
                report("TRADES", False, f"summary send failed: {exc}", critical=False, warn=True)
    except Exception as exc:  # noqa: BLE001
        report("TRADES", False, f"trade book unreadable: {exc}")

    # ------------------------------------------------------------------ 8
    port = int(os.environ.get("DASHBOARD_API_PORT", "8787"))
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/dashboard", timeout=10) as resp:
            payload = json.loads(resp.read().decode())
        agents_rows = payload.get("agentPerformance") or payload.get("agentWeights") or []
        names = {str(a.get("agent_name", "")).lower() for a in agents_rows if isinstance(a, dict)}
        expected = {"technical", "multitimeframe", "classical", "smc", "price_action"}
        report("DASHBOARD", True, f"API answering on :{port}; payload keys={len(payload)}")
        report("DASHBOARD", expected.issubset(names) if names else False,
               f"five-agent book on dashboard: {sorted(names) if names else 'EMPTY'}",
               critical=False, warn=not expected.issubset(names))
    except Exception as exc:  # noqa: BLE001
        report("DASHBOARD", False, f"API not answering on :{port}: {exc}",
               critical=False, warn=True)

    # Windows service/task topology: automatic background operation and
    # singleton guards for the three persistent Python workers.
    check_windows_tasks()

    # ------------------------------------------------------------------ 9
    sig = config.get("signal_requirements") or {}
    bar = _f(sig.get("agent_min_confidence"))
    net = _f(sig.get("min_consensus_confidence"))
    report("CONFIG", bar == 65 and net == 65,
           f"unified thresholds: agent bar={bar:.0f} net floor={net:.0f} (expected 65/65)")
    from utils.helpers import get_agent_weights
    w = get_agent_weights(config)
    report("CONFIG", abs(sum(w.values()) - 1.0) < 0.01 and "auction_flow" not in w,
           f"weights={ {k: round(v, 2) for k, v in w.items()} } sum={sum(w.values()):.2f}")
    p5 = sig.get("path5_two_agent_auction") or {}
    report("CONFIG", bool(p5.get("enabled")), f"Path 5 enabled={p5.get('enabled')} "
           f"auction floor={p5.get('min_auction_confidence')}")

    # ----------------------------------------------------------------- 10
    critical_files = [
        "services/shared_market_data.py", "utils/helpers.py",
        "agents/technical_agent.py", "agents/multitimeframe_agent.py",
        "agents/price_action_agent.py", "agents/classical_agent.py",
        "services/thesis_consensus.py", "services/auction_evidence.py",
    ]
    marks = {
        "services/shared_market_data.py": "store_error",          # WinError V2
        "utils/helpers.py": "for attempt in range(14)",           # lock retry v3
        "agents/technical_agent.py": "fuse_timeframe_results",    # 4-frame fusion fix
        "agents/price_action_agent.py": "single_candle_score",    # overlap fix
        "agents/classical_agent.py": "ascending_trend",           # trend-penalty fix
        "services/thesis_consensus.py": "TWO_AGENT_AUCTION",      # Path 5
        "services/auction_evidence.py": "composite_auction_edge", # shared edge
    }
    stale = []
    for rel in critical_files:
        p = ROOT / rel
        if not p.exists():
            stale.append(f"{rel} MISSING")
            continue
        body = p.read_text(encoding="utf-8", errors="replace")
        mark = marks.get(rel)
        if mark and mark not in body:
            stale.append(f"{rel} missing patch marker '{mark}'")
    digest = hashlib.sha256(
        b"".join((ROOT / r).read_bytes() for r in critical_files if (ROOT / r).exists())
    ).hexdigest()[:12]
    report("VERSIONS", not stale,
           f"patch markers OK, build fingerprint {digest}" if not stale
           else "OUTDATED FILES: " + "; ".join(stale))

    # ------------------------------------------------------------------ MT5 (2026-08-19 SPOF fix, warning #6)
    mt5_ok, mt5_detail = check_mt5_terminal()
    report("MT5", mt5_ok, mt5_detail, critical=False, warn=not mt5_ok)

    # ------------------------------------------------------------------ RESOURCES (2026-08-19 agent fix)
    try:
        import psutil

        vm = psutil.virtual_memory()
        disk = psutil.disk_usage(str(ROOT))
        cpu = psutil.cpu_percent(interval=0.3)
        report("RESOURCES", vm.percent < 90 and disk.percent < 95,
               f"CPU {cpu:.0f}% / RAM {vm.percent:.0f}% / disk {disk.percent:.0f}% used",
               critical=False, warn=(vm.percent >= 85 or disk.percent >= 92))
    except ImportError:
        report("RESOURCES", False, "psutil not installed — resource monitoring skipped (pip install psutil)",
               critical=False)

    # ------------------------------------------------------------------ EXECUTION (2026-08-19 fix)
    halt_exists, halt_reason, refusals = _execution_gate_status(ROOT)
    if halt_exists:
        report("EXECUTION", False, f".demo_halt EXISTS: {halt_reason}", warn=True)
    else:
        report("EXECUTION", True, ".demo_halt absent - executor not self-frozen")
    report("EXECUTION", refusals == 0,
           f"{refusals} order refusal(s) in recent tick log tail"
           + (" (daily cap reached?)" if refusals else ""),
           critical=False, warn=refusals > 0)

    # ------------------------------------------------------------------ verdict
    print()
    print("=" * 74)
    fails = [r for r in RESULTS if r[1] == "FAIL"]
    warns = [r for r in RESULTS if r[1] == "WARN"]
    if CRITICAL_FAIL:
        print(f"VERDICT: NOT HEALTHY — {len(fails)} failure(s), {len(warns)} warning(s)")
        for sec, st, d in fails:
            print(f"  !! {sec}: {d}")
    else:
        print(f"VERDICT: HEALTHY — all critical systems operational "
              f"({len(warns)} warning(s))")
        for sec, st, d in warns:
            print(f"  ~  {sec}: {d}")
    print("=" * 74)
    return 1 if CRITICAL_FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
