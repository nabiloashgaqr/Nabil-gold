# -*- coding: utf-8 -*-
"""Merge R1 unified per-symbol trading laws into config.json safely.

Run from the project root:
    python APPLY_UNIFIED_TRADING_LAWS_R1.py

The script preserves every unrelated setting, creates a timestamped backup,
and is idempotent (safe to run more than once).
"""
from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "config.json"
RATIOS = {
    "XAU/USD": 1.0,
    "WTI/USD": 0.5,
    "EUR/USD": 1.8,
    "GBP/USD": 1.8,
    "USD/CAD": 1.8,
    "USD/JPY": 1.8,
}


def scaled(value: float, ratio: float) -> int:
    return int(round(value * ratio))


def deep_update(target: dict, patch: dict) -> None:
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            deep_update(target[key], value)
        else:
            target[key] = value


def main() -> None:
    if not CONFIG.exists():
        raise SystemExit(f"ERROR: config not found: {CONFIG}")
    config = json.loads(CONFIG.read_text(encoding="utf-8-sig"))
    instruments = config.setdefault("instruments", [])
    rows = {str(row.get("symbol")): row for row in instruments if isinstance(row, dict)}

    for symbol, ratio in RATIOS.items():
        row = rows.get(symbol)
        if row is None:
            row = {"symbol": symbol, "enabled": True}
            instruments.append(row)
        law = {
            "distance_ratio": ratio,
            "min_sl_distance_points": scaled(400, ratio),
            "trailing_distance": scaled(150, ratio),
            "trailing_step": scaled(40, ratio),
            "early_breakeven_points": scaled(150, ratio),
            "trading_rules": {
                "stop": {
                    "enabled": True,
                    "min_liquidity_points": scaled(200, ratio),
                    "safety_buffer_points": scaled(70, ratio),
                    "max_stop_points": scaled(400, ratio),
                },
                "targets": {
                    "min_tp1_rr": 0.8,
                    "tp2_multiple": 2.0,
                    "max_beyond_points": scaled(200, ratio),
                },
                "trailing": {
                    "enabled": True,
                    "distance_points": scaled(150, ratio),
                    "step_points": scaled(40, ratio),
                    "activation_at": "BREAKEVEN",
                    "early_breakeven_points": scaled(150, ratio),
                },
                "protection": {"be_lock_points": scaled(40, ratio)},
                "post_tp2": {
                    "enabled": True,
                    "min_distance_points": scaled(250, ratio),
                    "window_hours": 2.5,
                },
            },
        }
        deep_update(row, law)

    root_rules = config.setdefault("trading_rules", {})
    root_rules["description"] = (
        "Canonical runtime laws live in instruments[].trading_rules. "
        "Root blocks are gold compatibility fallbacks only."
    )
    root_rules["protection"] = {
        "be_lock_points": 40,
        "description": (
            "Gold base. Every instrument explicitly owns its scaled value: "
            "XAU ×1, WTI ×0.5, FX ×1.8."
        ),
    }

    gates = config.setdefault("discipline_gates", {})
    bands = gates.setdefault("stop_band_by_symbol", {})
    for symbol, ratio in RATIOS.items():
        bands[symbol] = {
            "min_points": float(scaled(270, ratio)),
            "max_points": float(scaled(400, ratio)),
        }

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = CONFIG.with_name(f"config.backup_unified_laws_R1_{stamp}.json")
    shutil.copy2(CONFIG, backup)
    temporary = CONFIG.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(CONFIG)
    print(f"OK: merged unified laws into {CONFIG.name}")
    print(f"BACKUP: {backup.name}")
    for symbol, ratio in RATIOS.items():
        print(
            f"{symbol}: ratio={ratio:g}, stop={scaled(270, ratio)}-{scaled(400, ratio)}, "
            f"BE trigger={scaled(150, ratio)}, trail={scaled(150, ratio)}/{scaled(40, ratio)}, "
            f"BE lock={scaled(40, ratio)}"
        )


if __name__ == "__main__":
    main()
